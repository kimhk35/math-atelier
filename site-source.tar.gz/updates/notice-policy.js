export const NOTICE_KEY = 'mckay-notice-2026-11-06-hidden-day';
export function koreaDay(now = new Date()) {
  return new Date(now.getTime() + 9 * 60 * 60 * 1000).toISOString().slice(0, 10);
}
export function hiddenToday(storedDay, now = new Date()) {
  return storedDay === koreaDay(now);
}
