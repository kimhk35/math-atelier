import {NOTICE_TITLE, NOTICE_BODY} from './notice-content.js';
import {NOTICE_KEY, koreaDay, hiddenToday} from './notice-policy.js';
function readDay() {
  try { return localStorage.getItem(NOTICE_KEY); } catch {}
  return document.cookie.split('; ').find(x => x.startsWith(NOTICE_KEY + '='))?.split('=')[1] || null;
}
function rememberToday() {
  const day = koreaDay();
  try { localStorage.setItem(NOTICE_KEY, day); } catch {}
  document.cookie = `${NOTICE_KEY}=${day}; Max-Age=86400; Path=/; SameSite=Lax; Secure`;
}
if (!hiddenToday(readDay())) {
  const dialog = document.createElement('dialog');
  dialog.className = 'at-notice';
  dialog.setAttribute('aria-labelledby', 'at-notice-title');
  dialog.innerHTML = `<div class="an-head"><p class="an-eyebrow">McKay Math Atelier</p><h2 id="at-notice-title" tabindex="-1">${NOTICE_TITLE}</h2><p class="an-date">2026년 11월 5일~6일</p></div><div class="an-scroll" tabindex="0" aria-label="업데이트 내용"><div class="an-stats"><span><b>1029</b>개 전체 실험</span><span><b>267</b>개 초등 실험</span><span><b>6</b>종 GIF 메뉴</span></div>${NOTICE_BODY}<a class="an-more" href="/updates/#d1106">업데이트 소식에서 다시 읽기 →</a></div><div class="an-foot"><p>이 브라우저에서 한국 시간 기준 오늘 자정까지 숨겨집니다.</p><div class="an-actions"><button type="button" data-an-today>오늘 하루 보지 않기</button><button type="button" data-an-close autofocus>닫기</button></div></div>`;
  document.body.append(dialog);
  const priorOverflow = document.body.style.overflow;
  dialog.addEventListener('close', () => {
    document.body.style.overflow = priorOverflow;
    dialog.remove();
  }, {once:true});
  dialog.querySelector('[data-an-close]').addEventListener('click', () => dialog.close());
  dialog.querySelector('[data-an-today]').addEventListener('click', () => { rememberToday(); dialog.close(); });
  dialog.querySelector('.an-more').addEventListener('click', () => dialog.close());
  addEventListener('storage', event => {
    if (event.key === NOTICE_KEY && hiddenToday(event.newValue) && dialog.open) dialog.close();
  });
  dialog.showModal();
  document.body.style.overflow = 'hidden';
  dialog.querySelector('#at-notice-title').focus();
}
