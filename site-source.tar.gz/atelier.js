import {LABS as ELEMENTARY_LABS, UNIT_NAMES as ELEMENTARY_UNITS, scene as elementaryScene, clean as elementaryState} from './lab-chunks/elementary.js';
import {LABS as FRONTIER_LABS, scene as frontierThumbnail, clean as frontierState} from './lab-chunks/wave-frontiers.js';
import { scene as waveThumbnail, routeForState } from './lab-chunks/circle-waves.js';
import { readingHTML, lessonHTML, initStudentUI, mountStudentLab } from './student-view/student-view.js';
let STUDENT_LAB = null;
import { createStudyTools } from "./learning-tools/study-tools.js";
let STUDY_TOOLS = null;
import { e as q } from "./lab-chunks/chunk-VC7GJI5D.js";
import * as HS from "./lab-chunks/hs-lazy.js";
// ATELIER_PLUS_V1
import { LABS as PLUS_LABS } from "./atelier-plus/catalog.js";
import { mathHTML, mathBlock, onMathReady } from "./lab-chunks/mathtex.js";
import { MID_GLYPHS } from "./lab-chunks/glyphs-mid.js";
import * as SH from "./lab-chunks/sheet.js";
import { guideHTML } from "./lab-chunks/guide.js";
import { EN_UI, EN_PAT } from "./lab-chunks/en-ui.js";
import * as CK from "./learning-tools/class-kit.js";
// 과정(탭) 정보 — 1~3: 중학교, 4~7: 고등학교
var COURSES = {
  18: {short:"고급수학",name:"고급수학 (영재고)",en:"Advanced Mathematics",color:"#007c78",level:"고등학교"},
  1: { short: "중1", name: "중학교 1학년", en: "Grade 7", color: "#d0612b", level: "중학교" },
  2: { short: "중2", name: "중학교 2학년", en: "Grade 8", color: "#2b74c7", level: "중학교" },
  3: { short: "중3", name: "중학교 3학년", en: "Grade 9", color: "#178468", level: "중학교" },
  4: { short: "공통수학2", name: "공통수학2", en: "Common Math 2", color: "#0f8a8a", level: "고등학교" },
  5: { short: "대수", name: "대수", en: "Algebra", color: "#5a4fcf", level: "고등학교" },
  6: { short: "기하", name: "기하", en: "Geometry", color: "#c23b5e", level: "고등학교" },
  7: { short: "미적분Ⅰ", name: "미적분Ⅰ", en: "Calculus I", color: "#94651a", level: "고등학교" },
  14: { short: "공통수학1", name: "공통수학1", en: "Common Math 1", color: "#3f8f5a", level: "고등학교" },
  13: { short: "미적분Ⅱ", name: "미적분Ⅱ", en: "Calculus II", color: "#b8741f", level: "고등학교" },
  8: { short: "확률과 통계", name: "확률과 통계", en: "Probability & Statistics", color: "#6f7f16", level: "고등학교" },
  10: { short: "인공지능 수학", name: "인공지능 수학", en: "AI Mathematics", color: "#1570a6", level: "고등학교" },
  11: { short: "수학과 문화", name: "수학과 문화", en: "Mathematics and Culture", color: "#9a4a2e", level: "고등학교" },
  12: { short: "직무 수학", name: "직무 수학", en: "Mathematics for Work", color: "#4b6b8a", level: "고등학교" },
  9: { short: "수학실험실", name: "수학실험실", en: "Math Laboratory", color: "#b0468a", level: "탐구" },
  15: { short: "수학의 역설", name: "수학의 역설", en: "Paradoxes", color: "#7a3fb0", level: "특별관" },
  16: { short: "역사 속 실험", name: "역사 속 수학 실험", en: "Famous Experiments in History", color: "#8a5a14", level: "특별관" },
  17: { short: "퍼즐과 게임", name: "퍼즐과 게임", en: "Puzzles and Games", color: "#1f7a6a", level: "특별관" },
};
for(let i=1;i<=6;i++)COURSES[20+i]={short:'초'+i,name:'초등학교 '+i+'학년',en:'Elementary Grade '+i,color:['#287c69','#287ca0','#7264c5','#b56836','#b34f78','#357b83'][i-1],level:'초등학교'};
// 첫 화면 남색 띠의 떠다니는 수식·도형 (천천히 움직임, 움직임 줄이기 설정이면 멈춤)
// 첫 화면 '처음이라면' 안내 카드 (최근 실험이 4개보다 적으면 남는 칸도 이것으로 채움)
var START = [["#/guide", "guide", "사용설명서", "화면 구성과 쓰는 법을 차례로 안내해요"], ["#/list?grade=21", "course", "초등학교 1학년부터", "그림을 바꾸며 수학을 시작해요"], ["#/special", "star", "특별관 둘러보기", "역설 · 역사 · 퍼즐 실험"], ["#/sitemap", "home", "전체 사이트맵", "초등부터 고등까지 실험을 찾아요"]];
var startCard = ([h, ic, b, s]) => `<a class="v3-rc v3-start" href="${h}"><span class="v3-start-ic" aria-hidden="true">${IC[ic]}</span><span class="v3-rc-tx"><b>${b}</b><small>${s}</small></span></a>`;
var HERO_DECO = `<svg viewBox="0 0 1480 420" preserveAspectRatio="xMidYMid slice"><g fill="none" stroke="currentColor" stroke-width="1.4"><g class="hd hd1"><circle cx="1180" cy="90" r="54"/><path d="M1126 90h108M1180 36v108"/></g><g class="hd hd2"><path d="M60 360 Q 160 180 260 360"/></g><g class="hd hd3"><path d="M820 380 l70 -120 l70 120 z"/></g><g class="hd hd4"><path d="M1300 330 c 40 -60 80 60 120 0 s 80 60 120 0"/></g><g class="hd hd5"><ellipse cx="640" cy="60" rx="70" ry="28"/></g><g class="hd hd2"><rect x="1010" y="300" width="64" height="64" transform="rotate(18 1042 332)"/></g></g><g fill="currentColor" font-family="Georgia, serif" font-style="italic"><text class="hd hd3" x="420" y="390" font-size="44">∫</text><text class="hd hd1" x="1390" y="70" font-size="40">π</text><text class="hd hd4" x="980" y="70" font-size="34">Σ</text><text class="hd hd5" x="300" y="70" font-size="30">x²</text><text class="hd hd2" x="720" y="410" font-size="28">√2</text></g></svg>`;
var GRADES = [18,21,22,23,24,25,26,1, 2, 3, 14, 4, 5, 7, 8, 6, 13, 10, 12, 11, 9, 15, 16, 17];
// 2022 개정 교육과정의 과목 구분
var GROUPS = [["초등학교", [21,22,23,24,25,26]], ["중학교", [1, 2, 3]], ["공통 과목", [14, 4]], ["일반 선택", [5, 7, 8]], ["진로 선택", [6, 13, 10, 12]], ["융합 선택", [11]], ["영재고 심화 탐구", [18]], ["탐구", [9]], ["특별관", [15, 16, 17]]];
// 첫 화면 '내 학년': 고르면 그 학년의 과정을 첫 화면 맨 위에 보여 준다 (이 기기에만 저장)
var LEVELS = [...Array.from({length:6},(_,i)=>["e"+(i+1),"초"+(i+1),"초등학교 "+(i+1)+"학년",[21+i]]), ["m1", "중1", "중학교 1학년", [1]], ["m2", "중2", "중학교 2학년", [2]], ["m3", "중3", "중학교 3학년", [3]], ["h1", "고1", "고등학교 1학년", [14, 4]], ["h2", "고2", "고등학교 2학년", [5, 7, 8]], ["h3", "고3", "고등학교 3학년", [13, 6, 10, 12, 11]], ["advanced", "고급수학", "영재고 심화 탐구", [18]], ["all", "선생님·전체", "", []]];
// 큐브 실험실 카드 그림 (등각 투영 큐브)
var CUBE_THUMB = `<svg viewBox="0 0 900 550" aria-hidden="true"><rect width="900" height="550" fill="#eef4f1"/><g transform="translate(450 285)" stroke="#173e36" stroke-width="6" stroke-linejoin="round">${[0,1,2].map(i=>[0,1,2].map(j=>`<path d="M${(j-i)*78} ${(i+j)*45-210} l78 45 l-78 45 l-78 -45z" fill="${["#f5f0dc","#f6ca50","#f5f0dc","#3ba583","#f5f0dc","#e6574b","#f5f0dc","#528fda","#f5f0dc"][i*3+j]}"/>`).join("")).join("")}${[0,1,2].map(i=>[0,1,2].map(j=>`<path d="M${-234+j*78} ${-75+j*45+i*90} l78 45 l0 90 l-78 -45z" fill="${["#3ba583","#3ba583","#e6574b","#3ba583","#f19242","#3ba583","#528fda","#3ba583","#3ba583"][i*3+j]}"/>`).join("")).join("")}${[0,1,2].map(i=>[0,1,2].map(j=>`<path d="M${j*78} ${60-j*45+i*90} l78 -45 l0 90 l-78 45z" fill="${["#e6574b","#e6574b","#f6ca50","#e6574b","#e6574b","#3ba583","#f19242","#e6574b","#e6574b"][i*3+j]}"/>`).join("")).join("")}</g></svg>`;
var GL = (t) => COURSES[t]?.short || `중${t}`;
var O = [
    {
      id: "vertical-angles",
      grade: 1,
      unit: 5,
      lesson: "5.1",
      module: "foundations",
      title: "맞꼭지각",
      type: "2D",
      time: "8분",
      color: "#d77635",
      tags: ["맞꼭지각", "교점", "각"],
      desc: "한 각을 선택해 맞꼭지각을 찾고, 두 각이 맞꼭지각인지 판별합니다.",
      obs: [
        "각을 선택하면 반대편 맞꼭지각이 자동으로 표시됩니다.",
        "각의 크기나 두 직선의 방향을 바꾸어도 맞꼭지각의 크기는 같습니다.",
      ],
      q: "두 각의 크기가 같다는 사실만으로 맞꼭지각이라고 할 수 있을까요?",
      formula: "∠A = ∠C, ∠B = ∠D",
    },
    {
      id: "position-relations",
      grade: 1,
      unit: 5,
      lesson: "5.3",
      module: "positions",
      title: "평면과 공간의 위치 관계",
      type: "3D",
      time: "12분",
      color: "#d77635",
      tags: ["위치 관계", "평행", "꼬인 위치", "다양한 입체"],
      desc: "관계를 직접 그리며 살펴보고, 입체의 변과 면에서 같은 관계를 모두 찾습니다.",
      obs: [
        "평면과 공간에서 가능한 위치 관계를 비교합니다.",
        "선택한 변이나 면과 조건에 맞는 모든 요소가 색상과 목록으로 표시됩니다.",
      ],
      q: "만나지 않는 두 직선은 공간에서도 항상 평행할까요?",
      formula: "직선–직선 · 직선–평면 · 평면–평면",
    },
    {
      id: "pi-estimation",
      grade: 1,
      unit: 6,
      lesson: "6.5",
      module: "foundations",
      title: "원과 부채꼴 · 원주율 추정",
      type: "2D",
      time: "12분",
      color: "#2e79bd",
      tags: ["원주율", "내접·외접", "격자"],
      desc: "내접·외접 다각형으로 π의 범위를 좁히고, 90° 부채꼴의 격자 대표점으로 추정합니다.",
      obs: [
        "다각형의 변 수를 하나씩 늘리면 두 넓이 사이의 차이가 줄어듭니다.",
        "격자 중앙의 대표점이 원 안에 있는지 같은 기준으로 셉니다.",
      ],
      q: "격자를 더 촘촘히 할 때 추정값은 매번 π에 더 가까워질까요?",
      formula:
        "내접 넓이 < π < 외접 넓이 (반지름 1) · π ≈ 4 × 안쪽 점 / 전체 점",
    },
  ],
  I = {
    id: "sector",
    grade: 1,
    unit: 6,
    lesson: "6.6",
    module: "foundations",
    title: "부채꼴의 호의 길이와 넓이",
    type: "2D",
    time: "10분",
    color: "#2e79bd",
    tags: ["부채꼴", "호의 길이", "자르기"],
    desc: "원을 중심각만큼 나누고 부채꼴 조각을 엇갈려 붙여 호의 길이와 넓이를 비교합니다.",
    obs: [
      "자르고 옮겨도 조각의 호의 길이의 합과 넓이의 합은 같습니다.",
      "조각이 많을수록 직사각형에 가까워지지만 유한 개 조각의 경계는 곡선입니다.",
    ],
    q: "자르는 개수가 달라도 넓이가 달라지지 않는 이유를 설명해 보세요.",
    formula: "l = 2πr × θ/360 · S = πr² × θ/360 = ½rl",
  };
var G = [
    [
      2,
      5,
      "5.1",
      "isosceles",
      "이등변삼각형의 성질",
      "꼭짓점을 움직이고 두 밑각과 밑변의 이등분을 비교합니다.",
      "꼭짓점을 옆으로 옮기면 두 밑각은 언제 같아질까요?",
      "AB = AC ⇔ ∠B = ∠C",
    ],
    [
      2,
      5,
      "5.2",
      "right-congruence",
      "직각삼각형의 합동",
      "RHA·RHS 조건을 선택하고 빗변과 각 또는 변을 바꿔 포개 봅니다.",
      "빗변과 다른 한 변으로 나머지 변은 어떻게 정해질까요?",
      "RHA 합동 · RHS 합동",
    ],
    [
      2,
      5,
      "5.3",
      "circumcenter",
      "삼각형의 외심",
      "삼각형의 모양을 바꾸며 수직이등분선과 외접원을 관찰합니다.",
      "둔각삼각형의 외심은 어느 곳에 있을까요?",
      "OA = OB = OC",
    ],
    [
      2,
      5,
      "5.4",
      "incenter",
      "삼각형의 내심",
      "각의 이등분선과 내접원을 그리고 세 변까지 거리를 비교합니다.",
      "내심은 삼각형 밖으로 나갈 수 있을까요?",
      "내심에서 세 변까지의 거리는 같다",
    ],
    [
      2,
      6,
      "6.1",
      "parallelogram",
      "평행사변형의 성질",
      "기울기를 바꾸며 대변·대각·대각선의 이등분을 측정합니다.",
      "비스듬해져도 대각선이 서로를 이등분할까요?",
      "대변과 대각이 같고 대각선은 서로 이등분한다",
    ],
    [
      2,
      6,
      "6.2",
      "parallel-condition",
      "평행사변형 판별",
      "꼭짓점 C의 위치를 바꾸며 평행사변형이 되는 조건을 검사합니다.",
      "한 쌍의 대변 길이가 같기만 하면 충분할까요?",
      "두 쌍의 대변 평행 / 길이 같음 / 대각 같음 / 대각선 서로 이등분 / 한 쌍 대변 평행하고 같음",
    ],
    [
      2,
      6,
      "6.3",
      "quadrilaterals",
      "여러 가지 사각형",
      "직사각형·마름모·정사각형·등변사다리꼴의 대각선을 비교합니다.",
      "대각선의 길이가 같고 서로 수직이면 항상 정사각형일까요?",
      "정사각형은 직사각형이면서 마름모이다",
    ],
    [
      2,
      7,
      "7.1",
      "similarity",
      "닮음비와 넓이비·부피비",
      "확대 비율을 바꾸며 대응변과 넓이·부피의 변화를 비교합니다.",
      "길이가 3배면 넓이와 부피도 3배일까요?",
      "길이비 k · 넓이비 k² · 부피비 k³",
    ],
    [
      2,
      7,
      "7.2",
      "similar-triangles",
      "삼각형의 닮음 조건",
      "SSS·SAS·AA에 맞는 변과 각을 입력하고 두 삼각형의 조건 성립 여부를 비교합니다.",
      "대응각만 같아도 크기까지 같아질까요?",
      "SSS 닮음 · SAS 닮음 · AA 닮음",
    ],
    [
      2,
      7,
      "7.3",
      "parallel-ratios",
      "삼각형과 평행선",
      "평행선을 위아래로 옮기며 대응 선분의 비와 중점 연결 정리를 확인합니다.",
      "두 변의 중점을 이은 선분은 밑변의 몇 배일까요?",
      "DE ∥ BC ⇒ AD/AB = AE/AC = DE/BC",
    ],
    [
      2,
      7,
      "7.4",
      "centroid",
      "삼각형의 무게중심",
      "세 중선을 그리고 꼭짓점에서 무게중심까지의 거리 비를 측정합니다.",
      "삼각형을 변형해도 2:1의 비가 유지될까요?",
      "AG : GM = 2 : 1",
    ],
    [
      2,
      7,
      "7.5",
      "pythagoras",
      "피타고라스 정리",
      "직각을 풀어 삼각형의 변 위 정사각형 넓이를 비교하고 역을 확인합니다.",
      "각이 90°보다 크면 빗변 쪽 정사각형은 어떻게 될까요?",
      "직각삼각형 ⇔ a² + b² = c²",
    ],
    [
      2,
      8,
      "8.1",
      "counting",
      "경우의 수 탐색",
      "합·곱의 법칙과 순서의 구별을 선택하고 결과를 하나씩 그리며 셉니다.",
      "주사위의 합이 같으면 나올 가능성도 모두 같을까요?",
      "동시에 일어나는 선택: 곱의 법칙",
    ],
    [
      2,
      8,
      "8.2",
      "probability",
      "확률과 상대도수",
      "동전과 주사위 시행을 누적하며 상대도수의 변화를 그립니다.",
      "시행 횟수가 늘면 매번 이론적 확률에 더 가까워질까요?",
      "확률 = 해당 경우의 수 / 전체 경우의 수",
    ],
    [
      2,
      8,
      "8.3",
      "complement",
      "확률의 성질",
      "사건과 그 여사건을 색으로 나누고 확률의 합을 비교합니다.",
      "어떤 사건과 일어나지 않는 사건의 확률 합은 얼마일까요?",
      "0 ≤ P(A) ≤ 1 · P(A) + P(A가 아님) = 1",
    ],
    [
      2,
      8,
      "8.4",
      "probability-calc",
      "복원·비복원 추출",
      "번호가 붙은 공을 한 개씩 두 번 뽑고 복원·비복원 과정과 결과를 비교합니다.",
      "첫 공을 돌려놓지 않으면 두 번째 확률은 어떻게 달라질까요?",
      "두 번 모두 빨강: 첫 확률 × 첫 결과에 따른 둘째 확률",
    ],
    [
      3,
      5,
      "5.1",
      "trig-ratios",
      "삼각비의 뜻",
      "각과 빗변을 바꾸며 sin·cos·tan의 값이 무엇으로 결정되는지 탐구합니다.",
      "빗변을 늘리고 각을 유지하면 삼각비는 달라질까요?",
      "sin A = 높이/빗변 · cos A = 밑변/빗변 · tan A = 높이/밑변",
    ],
    [
      3,
      5,
      "5.2",
      "special-angles",
      "30°·45°·60°의 삼각비",
      "특수각을 선택하고 정확한 근호 값과 실제 길이를 비교합니다.",
      "정삼각형을 반으로 나누면 30°의 삼각비를 어떻게 얻을까요?",
      "sin 30° = 1/2 · sin 45° = √2/2 · sin 60° = √3/2",
    ],
    [
      3,
      5,
      "5.3",
      "acute-trig",
      "예각의 삼각비",
      "단위원 위 점을 움직여 sin·cos와 접선 위 tan의 길이를 관찰합니다.",
      "각이 90°에 가까워질 때 tan은 어떻게 변할까요?",
      "0° ≤ A ≤ 90°에서 sin 증가, cos 감소 · tan 90°는 정의하지 않음",
    ],
    [
      3,
      5,
      "5.4",
      "trig-height",
      "삼각비로 높이 재기",
      "거리·올려본 각·눈높이로 직접 닿지 못하는 물체의 높이를 계산합니다.",
      "눈높이를 빼먹으면 계산 결과는 어떻게 달라질까요?",
      "물체 높이 = 거리 × tan(올려본 각) + 눈높이",
    ],
    [
      3,
      5,
      "5.4",
      "trig-area",
      "삼각비와 삼각형 넓이",
      "두 변과 끼인각으로 높이를 만들고 삼각형의 넓이를 비교합니다.",
      "끼인각이 둔각이면 높이는 어느 쪽에 그려질까요?",
      "S = 1/2 × ab × sin C",
    ],
    [
      3,
      6,
      "6.1",
      "circle-chord",
      "원과 현",
      "현의 위치를 바꾸며 중심까지의 거리와 현의 길이를 비교합니다.",
      "중심에 더 가까운 현은 왜 더 길까요?",
      "중심에서 현에 내린 수선은 현을 이등분한다",
    ],
    [
      3,
      6,
      "6.2",
      "circle-tangent",
      "원과 접선",
      "원 밖의 점을 옮기고 두 접선의 길이와 반지름의 직각을 확인합니다.",
      "원 밖의 한 점에서 그은 두 접선의 길이는 같을까요?",
      "PA = PB · OA ⟂ PA",
    ],
    [
      3,
      6,
      "6.3",
      "inscribed-angle",
      "원주각과 중심각",
      "같은 호를 보는 원주각의 꼭짓점을 움직이며 중심각과 비교합니다.",
      "지름을 바라보는 원주각은 왜 직각일까요?",
      "같은 호에 대한 원주각 = 중심각의 1/2",
    ],
    [
      3,
      6,
      "6.4",
      "tangent-chord",
      "접선과 현이 이루는 각",
      "접점의 현을 바꾸고 같은 호를 보는 원주각과 비교합니다.",
      "접선과 현이 이루는 예각과 둔각은 각각 어느 호와 연결될까요?",
      "접선과 현이 이루는 각 = 그 각 안의 호에 대한 원주각",
    ],
    [
      3,
      6,
      "6.4",
      "cyclic-quad",
      "원에 내접하는 사각형",
      "네 꼭짓점의 위치를 바꾸며 마주 보는 내각의 합을 측정합니다.",
      "한 꼭짓점의 위치가 바뀌어도 대각의 합이 유지될까요?",
      "∠A + ∠C = ∠B + ∠D = 180°",
    ],
    [
      3,
      7,
      "7.1",
      "representative",
      "대푯값과 이상치",
      "CSV 자료의 평균·중앙값·최빈값을 구하고 이상치를 움직여 비교합니다.",
      "자료의 특징을 잘 나타내는 대푯값은 언제 달라질까요?",
      "평균 · 중앙값 · 최빈값",
    ],
    [
      3,
      7,
      "7.2",
      "dispersion",
      "분산과 표준편차",
      "자료를 입력하거나 CSV로 올리고 편차와 편차의 제곱을 시각화합니다.",
      "평균이 같아도 자료의 퍼진 정도는 다를 수 있을까요?",
      "분산 = 편차²의 평균 · 표준편차 = √분산",
    ],
    [
      3,
      7,
      "7.3",
      "scatter",
      "산점도와 상관관계",
      "두 열의 CSV로 산점도를 만들고 점을 옮겨 상관관계를 관찰합니다.",
      "양의 상관관계만으로 원인과 결과라고 말할 수 있을까요?",
      "양의 상관 · 음의 상관 · 상관관계 없음",
    ],
  ],
  B = G.map(([t, e, i, a, l, s, u, p]) => ({
    id: `g${t}-${a}`,
    key: a,
    grade: t,
    unit: e,
    lesson: i,
    title: l,
    desc: s,
    q: u,
    formula: p,
    module:
      a === "representative"
        ? "representative"
        : e === 8 || (t === 3 && e === 7)
          ? "advanced-data"
          : "advanced",
    tags: [
      `중${t}`,
      e === 8 ? "확률" : e === 7 && t === 3 ? "통계" : "기하",
      "조작",
    ],
    type: e === 8 || (t === 3 && e === 7) ? "데이터" : "2D",
    time: "10분",
    color:
      e === 5
        ? "#db712f"
        : e === 6
          ? "#2e79bd"
          : e === 7
            ? "#198574"
            : "#d75e59",
    obs: [
      s,
      "조건을 한 번에 하나씩 바꾸고, 달라지는 값과 유지되는 값을 기록하세요.",
    ],
  })),
  M = {
    1: [
      [1, "소인수분해"],
      [2, "정수와 유리수"],
      [3, "문자와 식"],
      [4, "좌표평면과 그래프"],
      [5, "기본 도형과 작도"],
      [6, "평면도형의 성질"],
      [7, "입체도형의 성질"],
      [8, "자료의 정리와 해석"],
    ],
    2: [
      [1, "유리수와 순환소수"],
      [2, "식의 계산"],
      [3, "부등식과 연립방정식"],
      [4, "일차함수와 그래프"],
      [5, "삼각형의 성질"],
      [6, "사각형의 성질"],
      [7, "도형의 닮음과 피타고라스 정리"],
      [8, "경우의 수와 확률"],
    ],
    3: [
      [1, "실수와 그 계산"],
      [2, "다항식의 곱셈과 인수분해"],
      [3, "이차방정식"],
      [4, "이차함수와 그래프"],
      [5, "삼각비"],
      [6, "원의 성질"],
      [7, "통계"],
    ],
    4: [
      [1, "평면좌표와 직선의 방정식"],
      [2, "원의 방정식과 도형의 이동"],
      [3, "집합"],
      [4, "명제"],
      [5, "함수"],
      [6, "유리함수와 무리함수"],
    ],
    14: [
      [1, "다항식"],
      [2, "복소수와 이차방정식"],
      [3, "이차방정식과 이차함수"],
      [4, "여러 가지 방정식과 부등식"],
      [5, "경우의 수"],
      [6, "행렬"],
    ],
    5: [
      [1, "지수와 로그"],
      [2, "지수함수와 로그함수"],
      [3, "삼각함수"],
      [4, "삼각함수의 활용"],
      [5, "등차수열과 등비수열"],
      [6, "수열의 합"],
      [7, "수학적 귀납법"],
    ],
    6: [
      [1, "이차곡선"],
      [2, "공간도형과 공간좌표"],
      [3, "벡터"],
      [4, "벡터의 활용"],
    ],
    7: [
      [1, "함수의 극한과 연속"],
      [2, "미분"],
      [3, "미분의 활용"],
      [4, "적분"],
    ],
    13: [
      [1, "수열의 극한"],
      [2, "미분법"],
      [3, "도함수의 활용"],
      [4, "적분법"],
    ],
    8: [
      [1, "경우의 수"],
      [2, "확률"],
      [3, "확률분포"],
      [4, "통계적 추정"],
    ],
    10: [
      [1, "데이터와 벡터"],
      [2, "이미지와 행렬"],
      [3, "예측과 최적화"],
    ],
    11: [
      [1, "예술과 수학"],
      [2, "생활과 수학"],
      [3, "사회와 수학"],
      [4, "환경과 수학"],
    ],
    12: [
      [1, "수와 연산"],
      [2, "변화와 관계"],
      [3, "도형과 측정"],
      [4, "자료와 가능성"],
    ],
    9: [
      [1, "곡선과 무늬"],
      [2, "프랙털과 무한"],
      [3, "삼각형의 신비"],
      [4, "우연과 통계 실험"],
      [5, "그래프와 알고리즘"],
      [6, "세상을 재는 수학"],
    ],
    15: [
      [1, "확률의 역설"],
      [2, "무한의 역설"],
      [3, "기하와 측정의 역설"],
      [4, "선택과 통계의 역설"],
    ],
    16: [
      [1, "고대의 실험"],
      [2, "중세·근대의 실험"],
      [3, "19세기 이후의 실험"],
    ],
    17: [
      [1, "논리 퍼즐"],
      [2, "수 퍼즐"],
      [3, "도형과 배치 퍼즐"],
      [4, "전략 게임"],
      [5, "큐브와 회전 퍼즐"],
    ],
  };
var g = [
  {
    id: "parallel-angles",
    unit: 5,
    lesson: "5.7",
    title: "평행선과 동위각·엇각",
    tags: ["평행선", "각", "2D"],
    type: "2D",
    time: "8분",
    color: "#db712f",
    desc: "횡단선을 움직여 동위각과 엇각의 관계를 직접 확인합니다.",
    obs: [
      "평행을 고정하면 같은 위치의 각이 항상 같습니다.",
      "횡단선의 기울기가 달라져도 대응 관계는 유지됩니다.",
    ],
    q: "두 직선이 평행하지 않을 때에는 어떤 각의 관계가 달라질까요?",
    formula: "동위각 = 동위각, 엇각 = 엇각 (두 직선이 평행할 때)",
  },
  {
    id: "compass",
    unit: 5,
    lesson: "5.9",
    title: "자와 컴퍼스 작도",
    tags: ["작도", "합동", "2D"],
    type: "조작",
    time: "10분",
    color: "#db712f",
    desc: "SSS·SAS·ASA 삼각형과 각·선분의 이등분 작도를 단계별로 확인합니다.",
    obs: [
      "원호의 반지름은 컴퍼스가 보존하는 길이입니다.",
      "두 원의 교점은 두 조건을 동시에 만족합니다.",
    ],
    q: "세 변의 길이가 주어지면 왜 삼각형의 모양이 하나로 정해질까요?",
    formula: "교점 P: PA = r₁, PB = r₂",
  },
  {
    id: "congruence",
    unit: 5,
    lesson: "5.10",
    title: "삼각형 합동 실험",
    tags: ["합동", "SSS", "SAS"],
    type: "2D",
    time: "8분",
    color: "#db712f",
    desc: "조건을 바꾸고 삼각형이 정확히 포개지는지 확인합니다.",
    obs: [
      "세 변 또는 두 변과 끼인각을 같게 하면 모양과 크기가 결정됩니다.",
      "한 조건이 부족하면 여러 모양이 가능합니다.",
    ],
    q: "SS만 같을 때 삼각형이 하나로 정해지지 않는 까닭은 무엇일까요?",
    formula: "SSS, SAS, ASA 합동",
  },
  {
    id: "polygon-diagonals",
    unit: 6,
    lesson: "6.1",
    title: "n각형 대각선 발생기",
    tags: ["다각형", "대각선", "2D"],
    type: "2D",
    time: "7분",
    color: "#2e79bd",
    desc: "꼭짓점 수와 선택 꼭짓점을 바꾸며 대각선의 수를 탐구합니다.",
    obs: [
      "한 꼭짓점에서는 자신과 양옆 꼭짓점을 연결할 수 없습니다.",
      "전체 대각선은 두 번씩 세어지므로 2로 나눕니다.",
    ],
    q: "n이 하나 늘면 전체 대각선 수는 얼마나 늘어날까요?",
    formula: "전체 대각선 = n(n−3) / 2",
  },
  {
    id: "interior-sum",
    unit: 6,
    lesson: "6.2",
    title: "다각형 삼각분할",
    tags: ["다각형", "내각", "2D"],
    type: "2D",
    time: "7분",
    color: "#2e79bd",
    desc: "한 꼭짓점에서 나눈 삼각형으로 내각의 합을 설명합니다.",
    obs: [
      "n각형은 n−2개의 삼각형으로 나뉩니다.",
      "삼각형 하나마다 180°가 더해집니다.",
    ],
    q: "12각형의 내각의 합은 몇 도일까요?",
    formula: "내각의 합 = 180° × (n−2)",
  },
  {
    id: "exterior-walk",
    unit: 6,
    lesson: "6.4",
    title: "다각형의 내각과 외각의 합",
    tags: ["다각형", "내각", "외각", "애니메이션"],
    type: "조작",
    time: "10분",
    color: "#2e79bd",
    desc: "꼭짓점 수를 바꾸고 내각·외각의 합을 비교한 뒤, 외각 조각을 모아 360°를 확인합니다.",
    obs: [
      "각 꼭짓점에서 내각과 외각의 합은 180°입니다.",
      "모든 내각과 외각의 합에서 내각의 합을 빼면 언제나 360°입니다.",
      "볼록다각형의 외각을 하나씩 모으면 한 바퀴를 이룹니다.",
    ],
    q: "다각형의 꼭짓점 수와 모양이 바뀌어도 외각의 합이 같은 이유는 무엇일까요?",
    formula: "180° × n − 180° × (n−2) = 360°",
  },
  {
    id: "sector",
    unit: 6,
    lesson: "6.7",
    title: "중심각–호–넓이 실험",
    tags: ["원", "부채꼴", "그래프"],
    type: "2D",
    time: "8분",
    color: "#2e79bd",
    desc: "반지름과 중심각을 바꾸어 호의 길이와 부채꼴 넓이를 비교합니다.",
    obs: [
      "중심각이 두 배면 호의 길이와 넓이도 두 배입니다.",
      "현의 길이는 중심각에 단순 비례하지 않습니다.",
    ],
    q: "반지름을 두 배로 하면 부채꼴 넓이는 몇 배가 될까요?",
    formula: "l = 2πr·θ/360,  S = πr²·θ/360",
  },
  {
    id: "revolution",
    unit: 7,
    lesson: "7.4",
    title: "회전체 생성기",
    tags: ["회전체", "3D", "회전"],
    type: "3D",
    time: "8분",
    color: "#198574",
    desc: "직선·곡선으로 윤곽을 그리고 회전축 둘레로 돌려 입체를 만듭니다.",
    obs: [
      "회전축에서의 거리만큼 반지름이 생깁니다.",
      "360°가 되면 회전체가 완성됩니다.",
    ],
    q: "직각삼각형의 어느 변을 축으로 잡으면 원뿔의 높이가 될까요?",
    formula: "회전각 θ: 0° → 360°",
  },
  {
    id: "cross-section",
    unit: 7,
    lesson: "7.6",
    title: "입체도형 단면 실험",
    tags: ["회전체", "단면", "3D"],
    type: "3D",
    time: "8분",
    color: "#198574",
    desc: "원기둥·원뿔·구와 각기둥·각뿔·각뿔대를 평면으로 잘라 단면을 관찰합니다.",
    obs: [
      "축에 수직으로 자르면 원 모양 단면이 생깁니다.",
      "원뿔은 꼭짓점으로 갈수록 단면 반지름이 작아집니다.",
    ],
    q: "원뿔을 꼭짓점 가까이 자르면 단면 넓이는 어떻게 변할까요?",
    formula: "원뿔 단면 반지름 r(z) = R(1 − z/h)",
  },
  {
    id: "net-fold",
    unit: 7,
    lesson: "7.3",
    title: "전개도 ↔ 입체도형",
    tags: ["전개도", "정육면체", "3D"],
    type: "3D",
    time: "9분",
    color: "#198574",
    desc: "정다면체·각기둥·각뿔·각뿔대와 원기둥·원뿔의 전개도를 접고 펼칩니다.",
    obs: [
      "면은 모서리를 중심으로 회전해 만납니다.",
      "서로 마주 보는 면은 한 모서리를 공유하지 않습니다.",
    ],
    q: "전개도에서 어느 면이 윗면과 마주 보게 될까요?",
    formula: "다각형 면은 모서리로 접고, 원기둥·원뿔의 옆면은 곡면으로 말기",
  },
  {
    id: "cone-volume",
    unit: 7,
    lesson: "7.10",
    title: "뿔의 부피 1/3",
    tags: ["부피", "원뿔", "3D"],
    type: "3D",
    time: "8분",
    color: "#198574",
    desc: "같은 밑면과 높이의 원뿔을 세 번 부어 원기둥을 채웁니다.",
    obs: [
      "세 번의 같은 원뿔 분량이 원기둥을 채웁니다.",
      "밑넓이와 높이가 같을 때만 비교가 가능합니다.",
    ],
    q: "원기둥의 부피가 150cm³이면 원뿔의 부피는 얼마일까요?",
    formula: "V원뿔 = ⅓πr²h",
  },
  {
    id: "histogram",
    unit: 8,
    lesson: "8.5",
    title: "히스토그램 · 도수분포다각형",
    tags: ["자료", "히스토그램", "데이터"],
    type: "데이터",
    time: "10분",
    color: "#d75e59",
    desc: "CSV 자료로 히스토그램·도수분포다각형·상대도수와 대푯값을 함께 탐구합니다.",
    obs: [
      "히스토그램 막대는 서로 붙어 있습니다.",
      "상대도수는 집단 크기가 달라도 분포를 비교하게 합니다.",
    ],
    q: "계급폭을 너무 작게 또는 크게 잡으면 어떤 정보가 사라질까요?",
    formula: "상대도수 = 도수 / 전체 도수",
  },
];
g.push(
  {
    id: "stem-leaf",
    unit: 8,
    lesson: "8.3",
    title: "줄기와 잎 그림",
    tags: ["자료", "줄기", "잎", "CSV"],
    type: "데이터",
    time: "7분",
    color: "#d75e59",
    desc: "원자료를 정렬하고 줄기와 잎으로 나누어 분포를 읽습니다.",
    obs: [
      "잎은 작은 수부터 정렬합니다.",
      "같은 잎이 반복되면 자료의 반복도 보존됩니다.",
    ],
    q: "어느 줄기에 자료가 가장 많이 모였나요?",
    formula: "자료 = 줄기 × 줄기 단위 + 잎 × 잎 단위",
  },
  {
    id: "averages",
    unit: 8,
    lesson: "8.2",
    title: "평균 · 중앙값 · 최빈값",
    tags: ["자료", "대푯값", "이상치", "CSV"],
    type: "데이터",
    time: "8분",
    color: "#d75e59",
    desc: "데이터를 업로드하고 수직선 위에서 대푯값과 이상치의 영향을 비교합니다.",
    obs: [
      "평균은 모든 자료의 영향을 받습니다.",
      "짝수 개 자료의 중앙값은 가운데 두 값의 평균입니다.",
      "최빈값은 여러 개이거나 없을 수 있습니다.",
    ],
    q: "가장 큰 값을 더 크게 바꾸면 평균과 중앙값 중 무엇이 더 많이 움직일까요?",
    formula: "평균 = 자료의 합 / 자료의 개수",
  },
);
var L = { averages: 0, "stem-leaf": 1, histogram: 2 };
g.sort((t, e) =>
  t.unit === 8 && e.unit === 8 ? L[t.id] - L[e.id] : t.unit - e.unit,
);
for (let t of g)
  ((t.grade = 1),
    (t.module = t.unit === 7 ? "solid" : t.unit === 8 ? "data" : "geometry"));
g.push(...B);
Object.assign(
  g.find((t) => t.id === "sector"),
  I,
);
g.push(...O);
var N = (t, e) => {
  let i = t.lesson.split(".").map(Number),
    a = e.lesson.split(".").map(Number);
  return t.grade - e.grade || i[0] - a[0] || (i[1] || 0) - (a[1] || 0);
};
g.sort(N);
g.push({
  id: "sphere-area",
  grade: 1,
  unit: 7,
  lesson: "7.5",
  module: "sphere-area",
  title: "구의 겉넓이와 원 4개",
  tags: ["구", "겉넓이", "애니메이션"],
  type: "3D",
  time: "8분",
  color: "#198574",
  desc: "귤껍질처럼 구의 표면을 벗겨 같은 반지름의 원 4개를 채우며 겉넓이를 비교합니다.",
  obs: [
    "구와 원의 반지름은 같아야 합니다.",
    "벗겨진 껍질 조각이 원 4개에 나뉘어 모입니다.",
    "원 하나에는 구의 겉넓이의 4분의 1이 대응합니다.",
  ],
  q: "반지름이 두 배가 되어도 원의 넓이에 대한 구의 겉넓이의 비는 같을까요?",
  formula: "S = 2πr × 2r = 4πr² = 4 × πr²",
});
g.sort(N);
// 중학교 실험의 이어지는 고등 실험(역방향 연결)을 함께 만든다
for (let t of HS.LABS) {
  let item = { ...t, module: "hs", color: t.color || COURSES[t.grade].color },
    ix = g.findIndex((o) => o.id === t.id);
  ix >= 0 ? (g[ix] = item) : g.push(item);
}
M[18]=[[1,"선형대수"],[2,"복소수"],[3,"곡선과 극좌표"],[4,"극한과 해석"],[5,"다변수 미적분"],[6,"수치해석과 모델링"],[7,"이산수학"]];
g.push(...[{"id":"advanced-linear","grade":18,"unit":1,"lesson":"1.1","module":"advanced-math","title":"선형변환과 행렬식","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","선형대수","선형변환과 행렬식"],"desc":"단위 정사각형이 어떻게 변하는지 살펴보세요. 넓이와 방향은 서로 다른 정보입니다.","obs":["선형변환은 원점을 고정합니다. 두 열벡터는 표준기저의 상입니다. 평행사변형 넓이는 |ad − bc|이며 행렬식의 부호는 방향의 보존 여부를 나타냅니다. det A = 0이면 차원이 줄어들고 역행렬은 존재하지 않습니다."],"q":"행렬식이 음수이면 넓이도 음수일까요? 먼저 예상해 보세요.","formula":"A = [a  b; c  d]　det A = ad − bc","links":["advanced-eigen","advanced-compose","advanced-inverse"],"npred":3},{"id":"advanced-eigen","grade":18,"unit":1,"lesson":"1.2","module":"advanced-math","title":"고유벡터와 불변 방향","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","선형대수","고유벡터와 불변 방향"],"desc":"대칭행렬의 두 고유방향을 보며 v와 Av가 같은 직선 위에 놓이는 순간을 찾아보세요.","obs":["이 실험은 실수 대칭 2×2 행렬에 한정합니다. λ± = (a+d)/2 ± √(((a−d)/2)²+b²)입니다. 서로 다른 고윳값의 고유벡터는 직교합니다. A = λI이면 모든 영벡터 아닌 벡터가 고유벡터입니다. λ = 0이면 Av = 0이므로 변환된 벡터의 방향은 정의되지 않습니다."],"q":"고유벡터는 변환 뒤 반드시 같은 쪽을 가리킬까요?","formula":"Av = λv　v ≠ 0","links":["advanced-linear","advanced-compose","advanced-inverse"],"npred":3},{"id":"advanced-compose","grade":18,"unit":1,"lesson":"1.3","module":"advanced-math","title":"행렬 합성의 순서","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","선형대수","행렬 합성의 순서"],"desc":"회전 R과 가로 밀기 S의 적용 순서를 바꾸어 같은 도형의 두 상을 비교합니다.","obs":["R은 평면 회전행렬이며 S=[1 k;0 1]입니다. k sin θ=0이면 두 행렬이 교환합니다. 두 다각형의 넓이는 모두 1이지만 모양이나 위치는 다를 수 있습니다."],"q":"도형을 돌린 뒤 미는 것과 민 뒤 돌리는 것은 같을까요?","formula":"RS ≠ SR인 경우가 존재한다","links":["advanced-linear","advanced-eigen","advanced-inverse"],"npred":3},{"id":"advanced-inverse","grade":18,"unit":1,"lesson":"1.4","module":"advanced-math","title":"역행렬과 민감도","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","선형대수","역행렬과 민감도"],"desc":"거의 평행한 두 열벡터가 작은 입력 오차를 얼마나 증폭하는지 비교합니다.","obs":["b=(1 1)이고 교란은 (0 δ)입니다. ε≠0일 때 해는 (1−δ/ε  δ/ε)입니다. ε=0이고 δ=0이면 해가 무수히 많고 δ≠0이면 해가 없습니다."],"q":"행렬식이 작으면 계산이 항상 안정적일까요?","formula":"A=[1 1;1 1+ε]　Ax=b","links":["advanced-linear","advanced-eigen","advanced-compose"],"npred":3},{"id":"advanced-matrix-power","grade":18,"unit":1,"lesson":"1.5","module":"advanced-math","title":"행렬의 거듭제곱과 수렴","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","선형대수","행렬의 거듭제곱과 수렴"],"desc":"두 고유방향의 성분이 반복 변환에서 어떻게 변하는지 추적합니다.","obs":["대칭행렬 A=Q diag(λ₁ λ₂)Qᵀ만 다룹니다. 모든 초기벡터가 0으로 가는 필요충분조건은 두 고윳값의 절댓값이 모두 1보다 작은 것입니다. 특정 초기벡터는 증가 고유공간 성분이 없으면 발산하지 않을 수 있습니다."],"q":"고윳값 하나가 1보다 크면 모든 초기벡터가 발산할까요?","formula":"Aⁿv = Q diag(λ₁ⁿ λ₂ⁿ)Qᵀv","links":["advanced-linear","advanced-eigen","advanced-compose"],"npred":3},{"id":"advanced-quadratic","grade":18,"unit":1,"lesson":"1.6","module":"advanced-math","title":"이차형식과 주축","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","선형대수","이차형식과 주축"],"desc":"회전된 좌표에서 이차형식의 등고선이 타원이나 쌍곡선이 되는 이유를 탐구합니다.","obs":["u와 v는 직교 회전좌표입니다. 양의 정부호에서는 q=1이 타원입니다. 부정부호에서는 쌍곡선입니다. 한 고윳값이 0이면 수준값에 따라 평행한 두 직선이나 공집합이 됩니다."],"q":"두 고윳값의 부호가 다르면 등고선은 어떤 모양일까요?","formula":"q = λ₁u² + λ₂v²","links":["advanced-linear","advanced-eigen","advanced-compose"],"npred":3},{"id":"advanced-projection","grade":18,"unit":1,"lesson":"1.7","module":"advanced-math","title":"직교사영과 최소거리","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","선형대수","직교사영과 최소거리"],"desc":"한 벡터를 직선 위로 내렸을 때 잔차와 방향벡터가 직교함을 확인합니다.","obs":["u는 단위벡터입니다. v−(v·u)u와 u의 내적은 0입니다. 직선 위 임의의 점 tu에 대해 |v−tu|²=|잔차|²+(t−v·u)²입니다."],"q":"직선 위에서 v에 가장 가까운 점은 어디일까요?","formula":"projᵤv=(v·u)u　|u|=1","links":["advanced-linear","advanced-eigen","advanced-compose"],"npred":3},{"id":"advanced-svd","grade":18,"unit":1,"lesson":"1.8","module":"advanced-math","title":"특잇값과 단위원의 상","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","선형대수","특잇값과 단위원의 상"],"desc":"단위원을 행렬로 옮겼을 때 타원의 반축 길이가 특잇값과 같음을 봅니다.","obs":["AᵀA는 양의 준정부호입니다. 특잇값은 항상 0 이상입니다. 밀기 행렬의 고윳값은 모두 1이어도 특잇값은 서로 다를 수 있습니다. 작은 특잇값이 0이면 단위원의 상은 선분이나 점으로 퇴화합니다."],"q":"행렬의 고윳값과 특잇값은 항상 같을까요?","formula":"σᵢ = √λᵢ(AᵀA)","links":["advanced-linear","advanced-eigen","advanced-compose"],"npred":3},{"id":"advanced-volume","grade":18,"unit":1,"lesson":"1.9","module":"advanced-math","title":"스칼라 삼중곱과 부피","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","선형대수","스칼라 삼중곱과 부피"],"desc":"세 벡터가 만드는 평행육면체를 사영 그림으로 보고 높이와 부피를 비교합니다.","obs":["u=(a 0 0)와 v=(0 b 0) 및 w=(k 0 h)를 사용합니다. 그림은 3차원을 평면으로 사영한 것이므로 화면의 길이나 각도는 실제 값과 다를 수 있습니다. 부피는 밀기 k와 무관합니다."],"q":"윗면을 옆으로 밀면 부피가 달라질까요?","formula":"V=|u·(v×w)|=|abh|","links":["advanced-linear","advanced-eigen","advanced-compose"],"npred":3},{"id":"advanced-least-squares","grade":18,"unit":1,"lesson":"1.10","module":"advanced-math","title":"최소제곱과 직교 조건","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","선형대수","최소제곱과 직교 조건"],"desc":"기울기와 절편을 바꾸며 잔차 제곱합의 최솟값을 찾습니다.","obs":["고정된 5개 점에 절편이 있는 직선을 적합합니다. 최소점에서 잔차는 상수벡터와 x벡터 모두에 직교합니다. 잔차 합 0만으로는 기울기의 최적성을 보장할 수 없습니다."],"q":"잔차의 합이 0이면 언제나 최적의 직선일까요?","formula":"Σrᵢ=0　Σxᵢrᵢ=0","links":["advanced-linear","advanced-eigen","advanced-compose"],"npred":3},{"id":"advanced-complex","grade":18,"unit":2,"lesson":"2.1","module":"advanced-math","title":"복소수의 거듭제곱","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","복소수","복소수의 거듭제곱"],"desc":"복소수의 곱셈을 회전과 확대에 연결합니다. z부터 zⁿ까지의 궤적을 관찰해 보세요.","obs":["z = r(cos θ + i sin θ)에서 r > 0입니다. 곱할 때 절댓값은 곱해지고 편각은 더해집니다. 단위원 위의 모든 복소수가 유한 번 곱해 1로 돌아오는 것은 아닙니다. θ/(2π)가 유리수일 때만 가능합니다. 이 화면의 각도 조절은 유리수 도 단위의 사례만 보여 줍니다."],"q":"절댓값이 1인 복소수를 계속 곱하면 어떤 곡선 위에 놓일까요?","formula":"zⁿ = rⁿ(cos nθ + i sin nθ)","links":["advanced-roots","advanced-multiply","advanced-reciprocal"],"npred":3},{"id":"advanced-roots","grade":18,"unit":2,"lesson":"2.2","module":"advanced-math","title":"복소수의 n제곱근","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","복소수","복소수의 n제곱근"],"desc":"wⁿ = z의 해는 어떻게 배치될까요? 모든 근을 한 번에 그려 대칭성을 찾아보세요.","obs":["z ≠ 0이며 n ≥ 2인 정수입니다. k는 0부터 n−1까지입니다. 근은 반지름 r^(1/n)인 원 위의 정n각형 꼭짓점에 놓입니다. z의 편각이 δ만큼 변하면 근의 배치는 δ/n만큼 회전합니다. n = 2에서는 서로 마주 보는 두 점입니다. z = 0일 때는 서로 다른 근이 하나뿐이므로 이 실험의 조절 범위에서 제외했습니다."],"q":"z의 편각을 60°만큼 바꾸면 모든 근도 60° 회전할까요?","formula":"wₖ = r^(1/n) exp(i(θ+2πk)/n)","links":["advanced-complex","advanced-multiply","advanced-reciprocal"],"npred":3},{"id":"advanced-multiply","grade":18,"unit":2,"lesson":"2.3","module":"advanced-math","title":"복소수 곱셈의 기하","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","복소수","복소수 곱셈의 기하"],"desc":"두 복소수의 절댓값과 편각을 독립적으로 바꾸며 곱의 위치를 관찰합니다.","obs":["0이 아닌 복소수만 다룹니다. 편각의 합은 2π의 정수배를 제외하고 같습니다. 하나의 복소수를 고정해 곱하는 사상은 회전과 확대의 합성입니다."],"q":"곱의 편각은 두 편각의 곱일까요?","formula":"|zw|=|z||w|　arg(zw)=arg z+arg w (mod 2π)","links":["advanced-complex","advanced-roots","advanced-reciprocal"],"npred":3},{"id":"advanced-reciprocal","grade":18,"unit":2,"lesson":"2.4","module":"advanced-math","title":"역수와 켤레복소수","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","복소수","역수와 켤레복소수"],"desc":"켤레와 역수를 비교해 반사와 반지름 역변환을 구별합니다.","obs":["r>0이며 역수는 반지름 1/r와 편각 −θ를 가집니다. 켤레는 반지름 r와 편각 −θ입니다. 둘이 같을 필요충분조건은 |z|=1입니다."],"q":"역수는 언제 켤레와 같을까요?","formula":"1/z = z̄/|z|²","links":["advanced-complex","advanced-roots","advanced-multiply"],"npred":3},{"id":"advanced-mobius","grade":18,"unit":2,"lesson":"2.5","module":"advanced-math","title":"분수선형변환과 원","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","복소수","분수선형변환과 원"],"desc":"z평면의 수직선을 w=(z−1)/(z+1)로 옮기고 원과 직선의 관계를 봅니다.","obs":["허수축은 단위원에서 w=1을 제외한 부분으로 옮겨집니다. Re z=−1은 극점을 지나므로 직선으로 옮겨집니다. 화면은 허수부 −12부터 12까지 표본을 그리므로 전체 자취의 일부입니다."],"q":"허수축은 어느 원으로 옮겨질까요?","formula":"w=(z−1)/(z+1)","links":["advanced-complex","advanced-roots","advanced-multiply"],"npred":3},{"id":"advanced-unity-sum","grade":18,"unit":2,"lesson":"2.6","module":"advanced-math","title":"단위근의 합과 직교성","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","복소수","단위근의 합과 직교성"],"desc":"단위근의 거듭제곱들을 더해 사라지는 합과 남는 합을 비교합니다.","obs":["j=0부터 n−1까지 더합니다. n이 k를 나누면 모든 항이 1이어서 합이 n입니다. 그렇지 않으면 공비의 n제곱이 1인 등비수열의 합이 0입니다. 같은 점에 여러 항이 겹칠 수 있습니다."],"q":"단위근을 같은 거듭제곱으로 올려 더하면 늘 0일까요?","formula":"Σⱼ exp(2πijk/n) = n 또는 0","links":["advanced-complex","advanced-roots","advanced-multiply"],"npred":3},{"id":"advanced-complex-exp","grade":18,"unit":2,"lesson":"2.7","module":"advanced-math","title":"복소지수와 격자의 상","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","복소수","복소지수와 격자의 상"],"desc":"직사각형 격자가 지수함수 아래에서 동심원과 방사선으로 변하는 모습을 봅니다.","obs":["실수부는 반지름의 로그이며 허수부는 라디안 편각입니다. 수직선은 원으로 가고 수평선은 원점을 제외한 반직선으로 갑니다. 복소지수함수의 값은 0이 될 수 없습니다."],"q":"허수부만 2π 늘리면 상은 달라질까요?","formula":"e^(x+iy)=eˣ(cos y+i sin y)","links":["advanced-complex","advanced-roots","advanced-multiply"],"npred":3},{"id":"advanced-complex-orbit","grade":18,"unit":2,"lesson":"2.8","module":"advanced-math","title":"복소수 반복과 궤도","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","복소수","복소수 반복과 궤도"],"desc":"zₖ₊₁=zₖ²+c의 궤도를 추적하며 유한 단계 관찰의 한계를 확인합니다.","obs":["z₀=0으로 고정합니다. |z|>max(2 |c|)이면 이후 절댓값이 증가하며 탈출합니다. 탈출하지 않은 유한 궤도만으로 망델브로 집합에 속한다고 단정할 수 없습니다."],"q":"60번 안에 벗어나지 않으면 영원히 유계라고 할 수 있을까요?","formula":"z₀=0　zₖ₊₁=zₖ²+c","links":["advanced-complex","advanced-roots","advanced-multiply"],"npred":3},{"id":"advanced-polar-conic","grade":18,"unit":3,"lesson":"3.1","module":"advanced-math","title":"이심률과 극좌표 이차곡선","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","곡선과 극좌표","이심률과 극좌표 이차곡선"],"desc":"초점과 준선을 고정하는 비율로 타원과 포물선 및 쌍곡선을 비교합니다.","obs":["e>0의 준선은 x=p/e입니다. 음의 r도 허용하여 쌍곡선의 두 가지를 그립니다. r의 분모가 0인 매개각은 제외합니다. e=0은 반지름 p인 원이며 유한한 준선은 없습니다."],"q":"e=1을 지날 때 곡선의 유형은 어떻게 달라질까요?","formula":"r=p/(1+e cos θ)","links":["advanced-rose","advanced-spiral","advanced-polar-area"],"npred":3},{"id":"advanced-rose","grade":18,"unit":3,"lesson":"3.2","module":"advanced-math","title":"장미곡선의 주기와 꽃잎","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","곡선과 극좌표","장미곡선의 주기와 꽃잎"],"desc":"r=cos(kθ)의 중복 추적과 꽃잎 수를 홀짝에 따라 비교합니다.","obs":["k가 홀수이면 꽃잎 k개이며 θ 구간 길이 π로 전체 자취를 추적합니다. k가 짝수이면 꽃잎 2k개이며 길이 2π가 필요합니다. k=1은 원을 그립니다."],"q":"꽃잎 수는 언제 k이고 언제 2k일까요?","formula":"r=cos(kθ)","links":["advanced-polar-conic","advanced-spiral","advanced-polar-area"],"npred":3},{"id":"advanced-spiral","grade":18,"unit":3,"lesson":"3.3","module":"advanced-math","title":"로그나선과 등각 성질","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","곡선과 극좌표","로그나선과 등각 성질"],"desc":"반지름의 지수 증가가 접선과 반지름 사이에 일정한 각을 만드는지 탐구합니다.","obs":["θ는 계산에서 라디안입니다. 접선벡터는 r(b eᵣ+eθ)입니다. 두 직선 사이의 예각은 arctan(1/|b|)이며 b=0일 때 90°입니다. 이 경우 자취는 단위원입니다."],"q":"중심에서 멀어져도 접선과 반지름 사이 각은 일정할까요?","formula":"r=e^(bθ)　tan α=1/|b|","links":["advanced-polar-conic","advanced-rose","advanced-polar-area"],"npred":3},{"id":"advanced-polar-area","grade":18,"unit":3,"lesson":"3.4","module":"advanced-math","title":"극좌표 넓이와 중복","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","곡선과 극좌표","극좌표 넓이와 중복"],"desc":"카디오이드의 부채꼴 근사로 넓이 적분의 1/2 계수를 확인합니다.","obs":["0≤β≤2π에서 카디오이드는 중복 없이 한 번 그려집니다. 정확한 넓이는 a²(3β/4+sin β+sin 2β/8)입니다. 화면의 근사는 중점 반지름을 쓰는 부채꼴 합입니다."],"q":"반지름을 두 배로 하면 넓이는 몇 배일까요?","formula":"넓이 = ½∫₀ᵝ [a(1+cos θ)]²dθ","links":["advanced-polar-conic","advanced-rose","advanced-spiral"],"npred":3},{"id":"advanced-ellipse-focus","grade":18,"unit":3,"lesson":"3.5","module":"advanced-math","title":"타원의 초점과 반사","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","곡선과 극좌표","타원의 초점과 반사"],"desc":"타원 위 한 점에서 두 초점으로 향하는 방향과 접선을 비교합니다.","obs":["a>b>0입니다. 초점은 (±√(a²−b²) 0)입니다. 법선은 (x/a² y/b²) 방향입니다. 한 초점에서 온 광선은 정반사 후 다른 초점을 향합니다. 그림은 경로를 나타내며 광학 에너지 모델은 아닙니다."],"q":"타원의 어느 점에서도 두 초점거리의 합은 같을까요?","formula":"PF₁+PF₂=2a","links":["advanced-polar-conic","advanced-rose","advanced-spiral"],"npred":3},{"id":"advanced-bezier","grade":18,"unit":3,"lesson":"3.6","module":"advanced-math","title":"베지에 곡선과 접선","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","곡선과 극좌표","베지에 곡선과 접선"],"desc":"드 카스텔조의 반복 선형보간으로 곡선 위 점을 구성합니다.","obs":["P₀=(−2 0)와 P₁=(−1 h₁) 및 P₂=(1 h₂)와 P₃=(2 0)입니다. 0≤t≤1에서 계수는 음이 아니고 합이 1이므로 곡선은 제어점의 볼록껍질 안에 있습니다."],"q":"곡선은 내부 제어점을 반드시 지날까요?","formula":"B(t)=Σ C(3 k)(1−t)³⁻ᵏtᵏPₖ","links":["advanced-polar-conic","advanced-rose","advanced-spiral"],"npred":3},{"id":"advanced-taylor","grade":18,"unit":4,"lesson":"4.1","module":"advanced-math","title":"테일러 근사와 오차","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","극한과 해석","테일러 근사와 오차"],"desc":"전개 중심을 0에 고정하고 다항식의 차수를 바꾸세요. 멀리 있는 점에서도 근사가 좋을까요?","obs":["맥클로린 다항식만 다룹니다. sin x와 exp x의 급수는 모든 실수에서 원래 함수로 수렴합니다. sin x의 짝수 차수 계수는 0이므로 N이 홀수에서 다음 짝수로 바뀔 때 다항식은 같습니다. 고정된 유한 차수의 다항식이 넓은 구간에서 정확하다는 뜻은 아닙니다. 점별 오차와 구간 전체 오차를 구별하세요."],"q":"차수를 한 단계 높일 때마다 sin x의 근사가 달라질까요?","formula":"Tₙ(x) = Σ f⁽ᵏ⁾(0)xᵏ/k!　0 ≤ k ≤ N","links":["advanced-series","advanced-geometric-power","advanced-fourier"],"npred":3},{"id":"advanced-series","grade":18,"unit":4,"lesson":"4.2","module":"advanced-math","title":"멱급수의 수렴 경계","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","극한과 해석","멱급수의 수렴 경계"],"desc":"ln(1+x)의 부분합을 따라가세요. 수렴반경이 같아도 양쪽 끝점의 결과는 다릅니다.","obs":["|x| < 1에서는 절대수렴합니다. x = 1에서는 교대조화급수로 조건수렴하며 합은 ln 2입니다. x = −1에서는 음의 조화급수로 발산합니다. |x| > 1에서는 일반항이 0으로 가지 않으므로 발산합니다. x ≤ −1에서는 실수 함수 ln(1+x)도 정의되지 않습니다. 유한한 그래프가 평평해 보이는 것만으로 수렴을 판정할 수 없습니다."],"q":"수렴반경이 1이면 x = −1과 x = 1에서 결과도 같을까요?","formula":"ln(1+x) = Σ (−1)ᵏ⁺¹xᵏ/k　k ≥ 1","links":["advanced-taylor","advanced-geometric-power","advanced-fourier"],"npred":3},{"id":"advanced-geometric-power","grade":18,"unit":4,"lesson":"4.3","module":"advanced-math","title":"기하 멱급수의 오차","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","극한과 해석","기하 멱급수의 오차"],"desc":"부분합 다항식과 나머지의 정확한 식을 함께 비교합니다.","obs":["유한 나머지 항등식은 x≠1에서 성립합니다. 무한급수가 함수에 수렴하는 것은 |x|<1에서입니다. x=1이면 함수는 정의되지 않지만 부분합은 N+1입니다."],"q":"|x|>1에서도 유한한 나머지 공식은 성립할까요?","formula":"1/(1−x)−Σ₀ᴺxᵏ=xᴺ⁺¹/(1−x)","links":["advanced-taylor","advanced-series","advanced-fourier"],"npred":3},{"id":"advanced-fourier","grade":18,"unit":4,"lesson":"4.4","module":"advanced-math","title":"푸리에 부분합과 기브스 현상","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","극한과 해석","푸리에 부분합과 기브스 현상"],"desc":"사각파의 홀수 고조파를 더하며 불연속점 근처의 넘침을 관찰합니다.","obs":["목표함수는 sin x의 부호이며 불연속점에서 푸리에급수는 양쪽 극한의 평균 0에 수렴합니다. 최대 넘침은 점프 크기의 약 9%로 남고 구간 폭은 줄어듭니다. 유한 표본의 최대값은 이론적 최댓값의 근사입니다."],"q":"항을 늘리면 불연속점 근처의 최대 넘침도 0이 될까요?","formula":"Sₙ(x)=(4/π)Σ sin((2k+1)x)/(2k+1)","links":["advanced-taylor","advanced-series","advanced-geometric-power"],"npred":3},{"id":"advanced-uniform","grade":18,"unit":4,"lesson":"4.5","module":"advanced-math","title":"점별수렴과 균등수렴","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","극한과 해석","점별수렴과 균등수렴"],"desc":"[0 1]에서 xⁿ이 각 점에서 어떻게 변하는지 보고 최댓값과 극한을 구별합니다.","obs":["점별극한은 x<1에서 0이며 x=1에서 1입니다. 모든 유한 n에 대해 x<1에서 xⁿ의 상한은 1이므로 극한함수와의 sup 오차가 1입니다. 끝점 1을 포함하지 않는 [0 a]에서는 a<1일 때 균등수렴합니다."],"q":"모든 고정된 x<1에서 0으로 가면 구간 전체에서도 동시에 작아질까요?","formula":"fₙ(x)=xⁿ on [0 1]","links":["advanced-taylor","advanced-series","advanced-geometric-power"],"npred":3},{"id":"advanced-improper","grade":18,"unit":4,"lesson":"4.6","module":"advanced-math","title":"이상적분의 수렴 경계","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","극한과 해석","이상적분의 수렴 경계"],"desc":"1부터 R까지 x⁻ᵖ의 넓이를 비교하고 R이 커지는 극한을 해석합니다.","obs":["p≠1이면 적분은 (R^(1−p)−1)/(1−p)입니다. p=1이면 ln R입니다. 무한구간의 적분은 p>1일 때만 수렴하며 값은 1/(p−1)입니다."],"q":"함숫값이 0으로 가면 무한한 넓이도 유한할까요?","formula":"∫₁ᴿx⁻ᵖdx　p=1은 ln R","links":["advanced-taylor","advanced-series","advanced-geometric-power"],"npred":3},{"id":"advanced-arc-length","grade":18,"unit":4,"lesson":"4.7","module":"advanced-math","title":"곡선 길이와 다각선 근사","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","극한과 해석","곡선 길이와 다각선 근사"],"desc":"포물선 구간의 다각선 길이를 늘려 곡선 길이 적분과 비교합니다.","obs":["곡선은 y=ax²이며 −2≤x≤2입니다. 정확한 길이는 a>0에서 2√(1+16a²)+asinh(4a)/(2a)이고 a=0에서 4입니다. 세분이 포함관계일 때 다각선 길이는 감소하지 않습니다."],"q":"끝점 사이 거리와 곡선 길이는 언제 같을까요?","formula":"L=∫₋₂²√(1+4a²x²)dx","links":["advanced-taylor","advanced-series","advanced-geometric-power"],"npred":3},{"id":"advanced-parametric","grade":18,"unit":4,"lesson":"4.8","module":"advanced-math","title":"매개변수 곡선의 속도와 접선","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","극한과 해석","매개변수 곡선의 속도와 접선"],"desc":"타원 위 점의 속도와 접선 방향을 매개변수의 미분으로 구합니다.","obs":["t는 미분할 때 라디안입니다. 속도는 (−a sin t  b cos t)입니다. 속력은 √(a²sin²t+b²cos²t)입니다. a=b일 때만 속력이 일정합니다."],"q":"매개각이 같은 속도로 변하면 점의 속력도 일정할까요?","formula":"x=a cos t　y=b sin t","links":["advanced-taylor","advanced-series","advanced-geometric-power"],"npred":3},{"id":"advanced-gradient","grade":18,"unit":5,"lesson":"5.1","module":"advanced-math","title":"등고선과 기울기벡터","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","다변수 미적분","등고선과 기울기벡터"],"desc":"타원형 등고선에서 기울기벡터가 가장 빠른 증가 방향임을 봅니다.","obs":["∇f≠0인 점에서 기울기벡터는 등고선의 법선입니다. 원점에서는 기울기벡터가 0이므로 증가 방향 하나를 지정할 수 없습니다. 화살표는 화면에 맞추어 일정 비율로 줄여 표시합니다."],"q":"기울기벡터는 등고선의 접선과 어떤 관계일까요?","formula":"f=x²+ay²　∇f=(2x 2ay)","links":["advanced-tangent-plane","advanced-directional","advanced-hessian"],"npred":3},{"id":"advanced-tangent-plane","grade":18,"unit":5,"lesson":"5.2","module":"advanced-math","title":"접평면과 국소 선형화","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","다변수 미적분","접평면과 국소 선형화"],"desc":"곡면 z=x²+y²와 접평면의 차이를 한 방향의 단면으로 살펴봅니다.","obs":["화면은 3차원 곡면 전체가 아니라 접점 P를 지나 단위방향 u로 자른 단면입니다. f(P+hu)=f(P)+2hP·u+h²이므로 접평면 근사의 오차는 h²입니다."],"q":"접점 근처의 오차는 이동거리 h에 비례할까요?","formula":"f(P+h u)≈f(P)+h∇f(P)·u","links":["advanced-gradient","advanced-directional","advanced-hessian"],"npred":3},{"id":"advanced-directional","grade":18,"unit":5,"lesson":"5.3","module":"advanced-math","title":"방향도함수와 최대 증가","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","다변수 미적분","방향도함수와 최대 증가"],"desc":"같은 점에서 방향을 돌리며 방향도함수가 내적임을 확인합니다.","obs":["단위방향벡터만 사용합니다. 최대 방향도함수는 |∇f|이며 반대 방향에서는 −|∇f|입니다. 기울기벡터에 수직이면 방향도함수가 0입니다."],"q":"방향도함수가 0이어도 기울기벡터가 0이어야 할까요?","formula":"f=x²+2y²　Dᵤf=∇f·u","links":["advanced-gradient","advanced-tangent-plane","advanced-hessian"],"npred":3},{"id":"advanced-hessian","grade":18,"unit":5,"lesson":"5.4","module":"advanced-math","title":"헤시안과 안장점","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","다변수 미적분","헤시안과 안장점"],"desc":"원점이 최소점인지 최대점인지 또는 안장점인지 방향별 단면으로 판정합니다.","obs":["원점은 항상 임계점입니다. 두 계수가 양수이면 엄격한 최소점이며 모두 음수이면 엄격한 최대점입니다. 부호가 다르면 안장점입니다. 한 계수가 0인 경우 일반 함수의 2차 판정법은 불충분하지만 이 정확한 이차함수의 비엄격 극값은 식으로 판정할 수 있습니다."],"q":"기울기벡터가 0이면 극값을 가진다고 할 수 있을까요?","formula":"f=ax²+by²　H=diag(2a 2b)","links":["advanced-gradient","advanced-tangent-plane","advanced-directional"],"npred":3},{"id":"advanced-lagrange","grade":18,"unit":5,"lesson":"5.5","module":"advanced-math","title":"제약조건과 라그랑주 승수","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","다변수 미적분","제약조건과 라그랑주 승수"],"desc":"단위원 위에서 선형함수의 최댓값과 최솟값을 접선 조건으로 찾습니다.","obs":["(a b)≠0이면 최대값은 √(a²+b²)이며 그 방향의 단위원 점에서 얻습니다. a=b=0이면 모든 점의 값이 0입니다. 제약곡선의 기울기벡터 ∇g는 단위원에서 0이 아닙니다."],"q":"제약이 있으면 ∇f=0이 아니어도 최댓값이 될까요?","formula":"f=ax+by　x²+y²=1","links":["advanced-gradient","advanced-tangent-plane","advanced-directional"],"npred":3},{"id":"advanced-double-integral","grade":18,"unit":5,"lesson":"5.6","module":"advanced-math","title":"이중적분과 중점 직사각형","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","다변수 미적분","이중적분과 중점 직사각형"],"desc":"직사각형 영역에서 f=x²+y²의 중점 리만합을 정확한 적분과 비교합니다.","obs":["화면은 위에서 본 직사각형 영역입니다. 각 칸의 색은 중점의 함수값입니다. n×n개 칸에서 함수값과 ΔxΔy를 곱해 더합니다. 이 볼록함수의 중점 근사는 정확한 적분보다 작습니다."],"q":"분할 수를 두 배로 하면 격자 칸 수는 몇 배가 될까요?","formula":"∫₀ᵃ∫₀ᵇ(x²+y²)dy dx=ba³/3+ab³/3","links":["advanced-gradient","advanced-tangent-plane","advanced-directional"],"npred":3},{"id":"advanced-newton","grade":18,"unit":6,"lesson":"6.1","module":"advanced-math","title":"뉴턴 방법의 수렴과 실패","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","수치해석과 모델링","뉴턴 방법의 수렴과 실패"],"desc":"접선의 x절편을 반복해 근을 찾고 도함수 0과 순환을 시험합니다.","obs":["f′(xₖ)=0이면 이 반복식은 정의되지 않습니다. x³−2x+2에서 0과 1은 2주기입니다. 근 근처에서 단순근과 충분한 매끄러움 등의 조건이 맞으면 빠르게 수렴하지만 일반적인 전역 보장은 없습니다."],"q":"뉴턴 방법은 어떤 초깃값에서도 근을 찾을까요?","formula":"xₖ₊₁=xₖ−f(xₖ)/f′(xₖ)","links":["advanced-bisection","advanced-euler","advanced-logistic"],"npred":3},{"id":"advanced-bisection","grade":18,"unit":6,"lesson":"6.2","module":"advanced-math","title":"이분법과 오차 보장","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","수치해석과 모델링","이분법과 오차 보장"],"desc":"x³−x−1의 근을 포함하는 구간이 반씩 줄어드는 과정을 봅니다.","obs":["초기구간은 [1 2]입니다. 함수는 이 구간에서 연속이며 양끝 부호가 다릅니다. 매번 근을 포함하는 반구간을 선택하므로 중점의 절대오차는 현재 구간 길이의 절반 이하입니다."],"q":"뉴턴 방법보다 느려도 이분법이 보장하는 것은 무엇일까요?","formula":"구간 길이 = 2⁻ⁿ　중점 오차 ≤ 2⁻ⁿ⁻¹","links":["advanced-newton","advanced-euler","advanced-logistic"],"npred":3},{"id":"advanced-euler","grade":18,"unit":6,"lesson":"6.3","module":"advanced-math","title":"오일러 방법과 수치 안정성","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","수치해석과 모델링","오일러 방법과 수치 안정성"],"desc":"연속계의 지수 감소와 이산 근사의 진동 및 발산을 비교합니다.","obs":["초깃값은 y(0)=1이고 정확한 해는 e^(kt)입니다. 명시적 오일러 방법의 h=T/n입니다. k<0일 때 |1+kh|<1이면 이산 해가 0으로 수렴합니다. 시간 유한구간의 정확도와 장시간 안정성을 구별하세요."],"q":"정확한 해가 감소하면 근사해도 반드시 감소할까요?","formula":"y′=ky　yⱼ₊₁=(1+kh)yⱼ","links":["advanced-newton","advanced-bisection","advanced-logistic"],"npred":3},{"id":"advanced-logistic","grade":18,"unit":6,"lesson":"6.4","module":"advanced-math","title":"로지스틱 성장과 변곡점","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","수치해석과 모델링","로지스틱 성장과 변곡점"],"desc":"제한된 자원 아래에서 해와 성장률의 변화를 함께 관찰합니다.","obs":["양의 초깃값에서 해는 K/[1+(K/y₀−1)e^(−rt)]입니다. y₀>K이면 단조감소하며 K로 접근합니다. 변곡점은 y=K/2를 지나가는 해에 해당하며 모든 양의 초기조건이 미래에 그 점을 지나지는 않습니다."],"q":"초기량이 수용한계보다 크면 어떻게 변할까요?","formula":"y′=ry(1−y/K)","links":["advanced-newton","advanced-bisection","advanced-euler"],"npred":3},{"id":"advanced-oscillator","grade":18,"unit":6,"lesson":"6.5","module":"advanced-math","title":"조화진동의 위상평면","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","수치해석과 모델링","조화진동의 위상평면"],"desc":"위치와 속도를 두 좌표로 보아 에너지 보존을 확인합니다.","obs":["초깃값은 x(0)=A와 v(0)=0입니다. x=A cos ωt와 v=−Aω sin ωt입니다. 좌표축의 단위가 다르므로 원처럼 보인다는 모양만으로 물리량을 동일시하면 안 됩니다."],"q":"위상평면의 궤적은 언제 원이 될까요?","formula":"x″+ω²x=0　v²+ω²x²=ω²A²","links":["advanced-newton","advanced-bisection","advanced-euler"],"npred":3},{"id":"advanced-quadrature","grade":18,"unit":6,"lesson":"6.6","module":"advanced-math","title":"수치적분과 오차 차수","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","수치해석과 모델링","수치적분과 오차 차수"],"desc":"eˣ의 적분에서 사다리꼴 공식과 심프슨 공식을 비교합니다.","obs":["등간격 합성 공식을 사용합니다. 심프슨 공식에는 짝수 분할이 필요합니다. 충분히 매끄러운 함수와 고정 구간에서 사다리꼴 오차는 O(h²)이며 심프슨 오차는 O(h⁴)입니다. 화면은 사다리꼴을 그리고 수치로 두 공식을 비교합니다."],"q":"같은 점 개수에서도 적분 근사의 정확도가 달라질까요?","formula":"∫₀ᵇeˣdx=eᵇ−1","links":["advanced-newton","advanced-bisection","advanced-euler"],"npred":3},{"id":"advanced-walks","grade":18,"unit":7,"lesson":"7.1","module":"advanced-math","title":"인접행렬과 보행 수","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","이산수학","인접행렬과 보행 수"],"desc":"네 꼭짓점 그래프에서 길이가 정해진 보행의 개수를 행렬 거듭제곱으로 셉니다.","obs":["무방향 단순그래프이며 시작점은 1입니다. 보행은 반복 방문을 허용합니다. n=0에서 A⁰=I입니다. 경로와 짝수 순환은 이분그래프이므로 출발점으로 돌아오는 홀수 길이 보행이 없습니다."],"q":"보행은 같은 변이나 꼭짓점을 다시 지나도 될까요?","formula":"(Aⁿ)ᵢⱼ = i에서 j로 가는 길이 n 보행 수","links":["advanced-markov","advanced-recurrence","advanced-modular"],"npred":3},{"id":"advanced-markov","grade":18,"unit":7,"lesson":"7.2","module":"advanced-math","title":"마르코프 연쇄와 정상분포","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","이산수학","마르코프 연쇄와 정상분포"],"desc":"두 상태 사이의 전이확률을 바꾸며 분포의 수렴과 주기성을 비교합니다.","obs":["p+q>0일 때 A의 정상확률은 q/(p+q)입니다. 0<p+q<2이면 모든 초기값이 그 값으로 수렴합니다. p=q=1은 주기2이며 특별한 초기분포 외에는 수렴하지 않습니다. p=q=0이면 모든 분포가 정상입니다."],"q":"정상분포가 존재하면 모든 초기분포가 그곳으로 수렴할까요?","formula":"xₙ₊₁=q+(1−p−q)xₙ","links":["advanced-walks","advanced-recurrence","advanced-modular"],"npred":3},{"id":"advanced-recurrence","grade":18,"unit":7,"lesson":"7.3","module":"advanced-math","title":"피보나치 점화식과 비율","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","이산수학","피보나치 점화식과 비율"],"desc":"초기조건이 달라도 같은 2차 점화식의 항 비율이 어떻게 변하는지 봅니다.","obs":["양의 초기조건만 사용합니다. 점화식의 특성근은 황금비와 −1/황금비입니다. 지배적인 특성근 성분이 양수이므로 비율은 황금비로 수렴합니다. 극한방정식을 푸는 것만으로 수렴 자체가 증명되는 것은 아닙니다."],"q":"초기조건이 달라도 항의 비율은 같아질까요?","formula":"aₙ₊₂=aₙ₊₁+aₙ","links":["advanced-walks","advanced-markov","advanced-modular"],"npred":3},{"id":"advanced-modular","grade":18,"unit":7,"lesson":"7.4","module":"advanced-math","title":"모듈러 곱셈과 순환","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","이산수학","모듈러 곱셈과 순환"],"desc":"유한한 나머지 집합에서 반복 곱셈의 순환과 붕괴를 살펴봅니다.","obs":["모든 궤도는 결국 주기적이지만 초기점 1로 돌아오는 것은 gcd(a m)=1일 때입니다. 서로소가 아니면 진입 구간 뒤의 순환이나 0으로의 붕괴가 생길 수 있습니다."],"q":"유한집합에서 반복하면 반드시 1로 돌아올까요?","formula":"x₀=1　xₖ₊₁≡a xₖ (mod m)","links":["advanced-walks","advanced-markov","advanced-recurrence"],"npred":3},{"id":"advanced-graph-spectrum","grade":18,"unit":7,"lesson":"7.5","module":"advanced-math","title":"그래프 라플라시안과 연결성","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","이산수학","그래프 라플라시안과 연결성"],"desc":"두 쌍의 꼭짓점을 잇는 변의 가중치를 바꾸어 연결성과 두 번째 고윳값을 봅니다.","obs":["네 꼭짓점 경로의 변 가중치는 1과 w 및 1입니다. 라플라시안 고윳값은 0과 2 및 1+w±√(1+w²)입니다. 영고윳값의 중복도는 연결성분 수입니다."],"q":"두 묶음을 잇는 가중치를 0으로 만들면 영고윳값은 몇 개가 될까요?","formula":"L=D−A　xᵀLx=Σₑwₑ(xᵢ−xⱼ)²","links":["advanced-walks","advanced-markov","advanced-recurrence"],"npred":3},{"id":"advanced-generating","grade":18,"unit":7,"lesson":"7.6","module":"advanced-math","title":"생성함수로 동전 경우 세기","type":"조작","time":"15분","color":"#007c78","tags":["고급수학","영재고","이산수학","생성함수로 동전 경우 세기"],"desc":"동전 종류의 생성함수를 곱해 순서를 무시한 지불 방법의 수를 계산합니다.","obs":["각 동전은 무한히 사용 가능하며 순서는 무시합니다. 목표차수까지 다항식을 잘라 계산해도 그 이하 계수는 정확합니다. 동전 종류를 바깥 반복으로 처리하는 동적계획법을 사용합니다."],"q":"동전의 순서까지 세면 같은 계수를 얻을까요?","formula":"∏₍c₎(1+xᶜ+x²ᶜ+…)","links":["advanced-walks","advanced-markov","advanced-recurrence"],"npred":3}]);
for (const lab of PLUS_LABS) { if (!g.some(x => x.id === lab.id)) g.push(lab); }
// 큐브 실험실 (cube-lab/index.html을 실험 화면 안에 띄움)
if (!g.some(x => x.id === "cube-lab")) g.push({ id: "cube-lab", grade: 17, unit: 5, lesson: "5.1", module: "cube", title: "큐브 실험실 — 2×2부터 7×7까지 돌리며 찾는 수학", type: "3D", time: "20분", color: "#1f7a6a", tags: ["큐브", "루빅스 큐브", "회전", "순열", "역연산", "주기", "최단 풀이", "공간 감각", "그림 큐브", "국기 큐브"], desc: "큐브 위 화살표로 층을 돌리고, 테마 50종으로 섞고 맞추며 회전의 순서·역연산·주기를 탐구합니다.", obs: ["같은 수순을 반복하면 언젠가 반드시 처음 상태로 돌아옵니다.", "R U와 U R처럼 순서를 바꾸면 결과가 달라집니다."], q: "같은 수순을 계속 반복하면 왜 언젠가 반드시 처음 상태로 돌아올까요?", formula: "(R U)를 105번 = 처음 상태 (색 큐브) · 2×2 상태 수 = 7! × 3⁶ = 3,674,160", links: ["alg-hanoi"] });
// Linked circle and wave studio
const circleWaves = { id: 'alg-circle-waves', grade: 5, unit: 3, lesson: 'Ⅲ-3 탐구', module: 'circle-waves', title: '회전에서 파동으로 — 단위원과 두 그래프', type: '입체 조작', time: '10분', color: '#6255c7', tags: ['삼각함수', '단위원', '사인', '코사인', '그래프', '회전'], desc: '단위원의 높이와 가로 좌표가 사인 및 코사인 그래프로 펼쳐지는 과정을 함께 관찰합니다.', obs: ['단위원 위 점의 높이는 sin θ이고 가로 좌표는 cos θ입니다.', '360° = 2π rad만큼 회전하면 두 그래프가 모두 한 주기를 완성합니다.', '0°에서 sin θ는 0이고 cos θ는 1입니다.'], q: '90°에서 사인과 코사인의 값은 각각 얼마일까요?', formula: 'sin²θ + cos²θ = 1', links: ['alg-unit-circle', 'alg-graph-wrap', 'alg-transform', 'alg-tan-graph'] };
g.push(circleWaves);
for(const lab of ELEMENTARY_LABS)g.push({...lab,formula:lab.formula||lab.obs[0],color:COURSES[lab.grade].color});
for(let grade=21;grade<=26;grade++)M[grade]=[...new Set(ELEMENTARY_LABS.filter(l=>l.grade===grade).map(l=>l.unit))].map(unit=>[unit,ELEMENTARY_UNITS[unit]]);
for(const lab of FRONTIER_LABS)g.push({...lab,links:[...lab.links,...FRONTIER_LABS.filter(x=>x.id!==lab.id).map(x=>x.id)]});
circleWaves.links.unshift(...FRONTIER_LABS.map(x=>x.id));
const waveExtensions = [
 {id:'alg-wave-transform',title:'회전으로 이해하는 진폭과 주기',desc:'원의 크기와 회전 배율 및 시작 각도를 바꾸며 변환된 사인 그래프를 기본 그래프와 비교합니다.',tags:['진폭','주기','위상','평행이동'],q:'회전 배율 B를 2로 바꾸면 주기는 어떻게 변할까요?',formula:'y = A sin(Bθ + φ) + D',obs:['진폭은 A입니다. 이 실험에서 A는 양수입니다.','주기는 360°/B이며 가로 이동량은 −φ/B입니다.','D는 그래프 중심선의 높이입니다.'],view:'transform'},
 {id:'alg-tangent-projection',title:'접선에서 펼쳐지는 탄젠트',desc:'단위원의 접선 위 길이를 탄젠트 그래프로 옮기고 점근선 근처에서 값이 어떻게 달라지는지 확인합니다.',tags:['탄젠트','접선','점근선','정의역'],q:'90°에서 탄젠트 값을 정할 수 없는 이유는 무엇일까요?',formula:'tan θ = sin θ / cos θ',obs:['cos θ가 0이면 탄젠트는 정의되지 않습니다.','90°와 270°의 점근선을 가로질러 곡선을 연결하지 않습니다.','탄젠트의 주기는 180°입니다.'],view:'tangent'},
 {id:'alg-wave-sum',title:'두 회전의 합 — 보강과 상쇄',desc:'두 회전 벡터를 이어 붙이고 높이를 더해 두 파동의 보강과 상쇄 및 배율 차이를 탐구합니다.',tags:['파동 합성','보강','상쇄','위상'],q:'크기가 같고 시작 각도가 180° 다른 두 파동을 더하면?',formula:'y = sin θ + A sin(Bθ + φ)',obs:['두 벡터를 이어 붙인 끝점의 높이가 두 파동의 합입니다.','A=1과 B=1일 때 위상 차이가 180°이면 완전히 상쇄됩니다.','B가 다르면 두 파동의 상대적인 위상이 계속 달라집니다.'],view:'sum'},
 {id:'alg-lissajous-waves',title:'리사주 곡선 — 두 진동이 그리는 도형',desc:'서로 수직인 두 진동의 좌표를 연결하고 진동 비와 위상 차이를 바꾸어 직선과 원 및 8자 곡선을 탐구합니다.',tags:['리사주','매개변수','위상','진동 비'],q:'진동 비가 같을 때 위상 차이를 0°에서 90°로 바꾸면?',formula:'x = sin θ / y = A sin(Bθ + φ)',obs:['위상 차이가 0°이고 B=1이면 자취는 직선입니다.','A=1과 B=1에서 위상 차이가 90°이면 단위원입니다.','B는 1부터 3까지 정수로 선택하므로 360°에서 자취가 닫힙니다.'],view:'lissajous'},
 {id:'alg-wave-beats',title:'맥놀이 — 비슷한 두 파동의 세기 변화',desc:'회전 배율이 조금 다른 두 파동을 더하고 합성파의 진폭 포락선과 세기가 반복되는 간격을 비교합니다.',tags:['맥놀이','합성파','포락선','삼각함수'],q:'두 회전 배율의 차이가 작아지면 세기 변화는 어떻게 될까요?',formula:'sin θ + sin((1+Δ)θ) = 2 cos(Δθ/2) sin((1+Δ/2)θ)',obs:['두 파동의 진폭은 각각 1입니다.','포락선의 크기는 2|cos(Δθ/2)|입니다.','세기가 반복되는 각도 간격은 360°/Δ입니다. 가로축은 시간 대신 각도를 표시합니다.'],view:'beats'},
 {id:'alg-wave-fourier',title:'푸리에 합성 — 작은 회전이 만드는 파형',desc:'홀수 고조파를 회전하는 원으로 연결하고 합성할 항의 개수를 바꾸며 사각파와 삼각파의 부분합을 비교합니다.',tags:['푸리에','고조파','사각파','삼각파','급수'],q:'항을 늘리면 사각파의 모서리 근처에서 어떤 일이 생길까요?',formula:'사각파 부분합: (4/π) Σ sin((2k+1)θ)/(2k+1)',obs:['이 실험은 k=0부터 N−1까지의 유한 부분합을 보여줍니다.','각 원의 반지름은 해당 고조파 계수의 절댓값입니다.','사각파의 불연속점 근처에는 기브스 현상에 의한 넘침이 남습니다.'],view:'fourier'},
 {id:'alg-wave-damped',title:'감쇠 진동 — 작아지는 원과 파동',desc:'지수적으로 줄어드는 회전 반지름을 파동의 진폭과 연결하고 감쇠 계수와 진폭이 절반이 되는 각도를 비교합니다.',tags:['감쇠','지수함수','삼각함수','포락선'],q:'감쇠 계수를 크게 하면 진폭이 절반이 되는 각도는 어떻게 될까요?',formula:'y = e^(−λθ) sin θ',obs:['θ는 라디안이며 화면의 각도 표시는 도 단위와 함께 제공됩니다.','진폭 포락선은 e^(−λθ)입니다. λ=0이면 감쇠가 없습니다.','진폭이 절반이 되는 각도는 ln(2)/λ 라디안입니다.'],view:'damped'},
 {id:'alg-traveling-wave',title:'진행파 — 파형은 이동하고 한 점은 진동한다',desc:'파동의 진행 방향과 파수를 바꾸고 관찰점의 위치를 고정해 파형의 이동과 한 점의 진동을 비교합니다.',tags:['진행파','파장','파수','삼각함수'],q:'파형이 오른쪽으로 이동할 때 한 점의 가로 위치도 함께 이동할까요?',formula:'y = A sin(kx − θ)',obs:['x는 위치를 나타내는 무차원 변수이고 θ는 라디안 위상입니다.','파장은 2π/k입니다. k가 커질수록 파장이 짧아집니다.','관찰점의 가로 위치는 고정되고 변위만 위아래로 바뀝니다.'],view:'traveling'},
 {id:'alg-standing-wave',title:'정상파 — 움직이지 않는 마디와 진동하는 배',desc:'반대 방향의 같은 진폭 진행파를 합성하고 항상 0인 마디와 가장 크게 진동하는 배를 찾아봅니다.',tags:['정상파','마디','배','파동 합성'],q:'모든 점이 순간적으로 0이 되면 모두 마디라고 할 수 있을까요?',formula:'A sin(kx−θ) + A sin(kx+θ) = 2A sin(kx) cos θ',obs:['마디는 x=mπ/k에서 항상 변위가 0인 위치입니다.','배는 x=(m+1/2)π/k이며 진폭은 2A입니다.','화면의 마디 개수에는 구간 0≤x≤2π의 양 끝점이 포함됩니다.'],view:'standing'}
];
for(const ext of waveExtensions)g.push({...circleWaves,...ext,time:'15분',links:['alg-circle-waves',...waveExtensions.filter(x=>x.id!==ext.id).map(x=>x.id),'alg-transform']});
circleWaves.links.unshift(...waveExtensions.map(x=>x.id));
for (const id of ['alg-unit-circle', 'alg-graph-wrap']) { const lab = g.find(x => x.id === id); if (lab) lab.links = [...new Set([...(lab.links || []), circleWaves.id])]; }
window.__atelierTitle = (id) => (g.find((x) => x.id === id) || {}).title || id;
// 중학교(1~3)는 차시 순서로, 고등·실험실은 입력 순서 그대로 정렬
g.sort((t, e) => t.grade - e.grade || (t.grade <= 3 ? N(t, e) : (t.unit || 0) - (e.unit || 0)));
var NEXT = {};
for (let t of HS.LABS)
  for (let p of t.links || []) (NEXT[p] = NEXT[p] || []).push(t.id);
var C = {
  "다각형의 한 꼭짓점에서 그 점을 포함하는 두 변 중 한 변의 연장선과 나머지 한 변이 이루는 각입니다":
    "An exterior angle is formed by extending one side at a vertex and the other side meeting at that vertex",
  "자동 생성을 끄면 두 삼각형의 값을 각각 입력하여 조건 성립 여부를 비교할 수 있습니다":
    "Turn off automatic generation to enter both triangles independently and test the condition",
  "구의 곡면은 늘이거나 찢지 않고 평면에 정확히 펼칠 수 없으므로 전개도가 없습니다":
    "A sphere has no exact flat net unless its surface is stretched or cut apart",
  "가장 큰 값을 더 크게 바꾸면 평균과 중앙값 중 무엇이 더 많이 움직일까요":
    "Which changes more when the largest value increases: the mean or the median",
  "평행선을 위아래로 옮기며 대응 선분의 비와 중점 연결 정리를 확인합니다":
    "Move the parallel line to compare segment ratios and explore the midpoint theorem",
  "데이터를 업로드하고 수직선 위에서 대푯값과 이상치의 영향을 비교합니다":
    "Upload data and explore measures of center and outliers on a number line",
  "엇각은 선택한 두 직선 사이에서 횡단선의 서로 반대쪽에 있는 각입니다":
    "Alternate interior angles lie between the selected lines on opposite sides of the transversal",
  "에 맞는 변과 각을 입력하고 두 삼각형의 조건 성립 여부를 비교합니다":
    "Enter the required sides and angles and compare whether the similarity condition holds",
  "직각을 풀어 삼각형의 변 위 정사각형 넓이를 비교하고 역을 확인합니다":
    "Vary the included angle, compare squares on the sides, and test the converse",
  "마우스나 손가락으로 회전하여 면과 모서리가 만나는 모습을 확인하세요":
    "Rotate with a mouse or finger to see how faces and edges meet",
  "복원 여부를 바꾸면 같은 공 구성의 누적 결과를 비교할 수 있습니다":
    "Switch replacement on or off to compare accumulated results for the same set of balls",
  "세 변 또는 두 변과 끼인각을 같게 하면 모양과 크기가 결정됩니다":
    "Three sides, or two sides and their included angle, determine a triangle's shape and size",
  "원 밖의 점을 옮기고 두 접선의 길이와 반지름의 직각을 확인합니다":
    "Move the external point to compare tangent lengths and perpendicular radii",
  "점이 다각형 바깥 경로를 걷고 외곽 모서리에서 외각만큼 회전합니다":
    "The point walks outside the polygon and turns through each exterior angle",
  "파란 삼각형을 직접 드래그하고 회전 슬라이더로 방향을 맞춰 보세요":
    "Drag the blue triangle and use the rotation slider to align it",
  "곱의 법칙과 순서의 구별을 선택하고 결과를 하나씩 그리며 셉니다":
    "Choose counting rules and whether order matters, then draw each outcome",
  "세 중선을 그리고 꼭짓점에서 무게중심까지의 거리 비를 측정합니다":
    "Draw the three medians and compare distances from a vertex to the centroid",
  "같은 호를 보는 원주각의 꼭짓점을 움직이며 중심각과 비교합니다":
    "Move the inscribed-angle vertex along the same arc and compare the central angle",
  "반지름과 중심각을 바꾸어 호의 길이와 부채꼴 넓이를 비교합니다":
    "Change radius and central angle to compare arc length and sector area",
  "세 변의 길이가 주어지면 왜 삼각형의 모양이 하나로 정해질까요":
    "Why do three side lengths determine a triangle's shape",
  "각의 이등분선과 내접원을 그리고 세 변까지 거리를 비교합니다":
    "Draw angle bisectors and the incircle, then compare distances to the three sides",
  "계급폭을 너무 작게 또는 크게 잡으면 어떤 정보가 사라질까요":
    "What information is lost when the class width is too small or too large",
  "네 꼭짓점의 위치를 바꾸며 마주 보는 내각의 합을 측정합니다":
    "Move the four vertices and measure the sums of opposite angles",
  "두 변과 끼인각으로 높이를 만들고 삼각형의 넓이를 비교합니다":
    "Construct the height from two sides and their included angle, then compare areas",
  "두 직선이 평행하지 않을 때에는 어떤 각의 관계가 달라질까요":
    "Which angle relationships change when the two lines are not parallel",
  "만 같을 때 삼각형이 하나로 정해지지 않는 까닭은 무엇일까요":
    "Why do these two side lengths alone fail to determine one triangle",
  "선택한 단위로 정확히 나타낼 수 없는 값은 알림을 표시합니다":
    "Values that cannot be represented exactly in the selected unit are flagged",
  "세 변을 한 변으로 하는 정사각형을 삼각형 바깥에 그렸습니다":
    "Squares are drawn outward on each side of the triangle",
  "위치에 따른 관계와 각의 크기가 같은지는 구분해서 생각하세요":
    "Distinguish the positional relationship from equality of angle measures",
  "접선과 현이 이루는 예각과 둔각은 각각 어느 호와 연결될까요":
    "Which arcs correspond to the acute and obtuse angles formed by the tangent and chord",
  "현의 위치를 바꾸며 중심까지의 거리와 현의 길이를 비교합니다":
    "Move the chord and compare its length with its distance from the center",
  "곡선으로 윤곽을 그리고 회전축 둘레로 돌려 입체를 만듭니다":
    "Draw an outline with a curve, then rotate it around an axis to form a solid",
  "꼭짓점 수와 선택 꼭짓점을 바꾸며 대각선의 수를 탐구합니다":
    "Change the number of vertices and the selected vertex to explore diagonals",
  "대응하는 세 변의 길이가 일치하지 않으므로 합동이 아닙니다":
    "The three corresponding side lengths do not match, so the triangles are not congruent",
  "직각삼각형의 어느 변을 축으로 잡으면 원뿔의 높이가 될까요":
    "Which side of a right triangle becomes the cone's height when used as the rotation axis",
  "첫 공을 돌려놓지 않으면 두 번째 확률은 어떻게 달라질까요":
    "How does the second probability change if the first ball is not replaced",
  "특수각을 선택하고 정확한 근호 값과 실제 길이를 비교합니다":
    "Select a special angle and compare exact radical values with measured lengths",
  "같은 밑면과 높이의 원뿔을 세 번 부어 원기둥을 채웁니다":
    "Pour three cone volumes into a cylinder with the same base and height",
  "계급값으로 근사하지 않고 입력한 원자료 전체로 계산합니다":
    "Calculations use all original data, without approximation by class midpoints",
  "동전과 주사위 시행을 누적하며 상대도수의 변화를 그립니다":
    "Accumulate coin and dice trials and plot the changing relative frequency",
  "사건과 그 여사건을 색으로 나누고 확률의 합을 비교합니다":
    "Color an event and its complement and compare the sum of their probabilities",
  "삼각형의 모양을 바꾸며 수직이등분선과 외접원을 관찰합니다":
    "Change the triangle and observe its perpendicular bisectors and circumcircle",
  "시행이 끝나면 다음 시행을 위해 모든 공을 다시 모읍니다":
    "All balls are collected again before the next trial",
  "원뿔을 꼭짓점 가까이 자르면 단면 넓이는 어떻게 변할까요":
    "How does a cone's cross-sectional area change near its apex",
  "좌표판에서 마우스나 손가락으로 드래그해 윤곽선을 그리세요":
    "Drag with a mouse or finger on the drawing board to create an outline",
  "한 꼭짓점에서는 자신과 양옆 꼭짓점을 연결할 수 없습니다":
    "A diagonal cannot connect a vertex to itself or either adjacent vertex",
  "각의 부채꼴이나 문자 버튼을 눌러도 선택할 수 있습니다":
    "You can also select an angle by clicking its sector or letter button",
  "꼭짓점을 움직이고 두 밑각과 밑변의 이등분을 비교합니다":
    "Move the vertex and compare the base angles and bisection of the base",
  "네 꼭짓점은 서로 다른 네 구간에서 원 위를 움직입니다":
    "The four vertices move on separate sections of the circle",
  "대각선의 길이가 같고 서로 수직이면 항상 정사각형일까요":
    "If the diagonals are equal and perpendicular, must the quadrilateral be a square",
  "복원에서는 첫 공을 돌려놓은 뒤 두 번째 공을 뽑습니다":
    "With replacement, return the first ball before drawing the second",
  "어떤 사건과 일어나지 않는 사건의 확률 합은 얼마일까요":
    "What is the sum of an event's probability and the probability that it does not occur",
  "원자료를 정렬하고 줄기와 잎으로 나누어 분포를 읽습니다":
    "Sort the original data into stems and leaves to read the distribution",
  "접점의 현을 바꾸고 같은 호를 보는 원주각과 비교합니다":
    "Move the chord through the contact point and compare the angle subtending the same arc",
  "조건을 선택하고 빗변과 각 또는 변을 바꿔 포개 봅니다":
    "Choose a condition, change the hypotenuse and angle or side, and superimpose the triangles",
  "첫 번째 칸의 점선 공은 돌려놓은 공의 결과 기록입니다":
    "The dashed ball in the first box records the ball that was returned",
  "횡단선을 움직여 동위각과 엇각의 관계를 직접 확인합니다":
    "Move the transversal to explore corresponding and alternate interior angles",
  "를 누르면 이 공을 다시 넣고 두 번째 공을 뽑습니다":
    "Press to return this ball and draw the second ball",
  "반지름을 두 배로 하면 부채꼴 넓이는 몇 배가 될까요":
    "If the radius doubles, by what factor does the sector area change",
  "빗변과 다른 한 변으로 나머지 변은 어떻게 정해질까요":
    "How do the hypotenuse and one leg determine the remaining side",
  "사람 아이콘은 위치를 나타내며 크기는 축척과 다릅니다":
    "The person icon marks the position; its size is not to scale",
  "상대도수는 집단 크기가 달라도 분포를 비교하게 합니다":
    "Relative frequency allows comparison between groups of different sizes",
  "시행 횟수가 늘면 매번 이론적 확률에 더 가까워질까요":
    "Does every additional trial bring the result closer to the theoretical probability",
  "양의 상관관계만으로 원인과 결과라고 말할 수 있을까요":
    "Does a positive correlation alone establish cause and effect",
  "의 위치를 바꾸며 평행사변형이 되는 조건을 검사합니다":
    "Move this vertex to test the conditions for a parallelogram",
  "평면을 위아래로 움직여 단면의 크기 변화를 관찰하세요":
    "Move the plane up and down to observe changes in the cross section",
  "한 꼭짓점에서 나눈 삼각형으로 내각의 합을 설명합니다":
    "Explain the interior-angle sum using triangles drawn from one vertex",
  "눈높이로 직접 닿지 못하는 물체의 높이를 계산합니다":
    "Use eye height to calculate the height of an inaccessible object",
  "대각선의 중점은 기울기와 높이가 달라져도 일치합니다":
    "The diagonal midpoints coincide even when the slant and height change",
  "로 산점도를 만들고 점을 옮겨 상관관계를 관찰합니다":
    "Create a scatter plot and move points to explore correlation",
  "서로 마주 보는 면은 한 모서리를 공유하지 않습니다":
    "Opposite faces do not share an edge",
  "세 변은 두 변의 합이 나머지 한 변보다 커야 하며":
    "The sum of any two sides must exceed the third side",
  "여러 열이 있으면 업로드 후 분석할 열을 선택하세요":
    "If the file has multiple columns, choose the column to analyze after uploading",
  "원 밖의 한 점에서 그은 두 접선의 길이는 같을까요":
    "Are the two tangents drawn from one external point equal in length",
  "자료의 특징을 잘 나타내는 대푯값은 언제 달라질까요":
    "When does a different measure of center better represent the data",
  "조건을 바꾸고 삼각형이 정확히 포개지는지 확인합니다":
    "Change the conditions and check whether the triangles overlap exactly",
  "짝수 개 자료의 중앙값은 가운데 두 값의 평균입니다":
    "For an even number of values, the median is the mean of the middle two",
  "평균이 같아도 자료의 퍼진 정도는 다를 수 있을까요":
    "Can datasets with the same mean have different spreads",
  "한 꼭짓점의 위치가 바뀌어도 대각의 합이 유지될까요":
    "Does the sum of opposite angles stay the same when one vertex moves",
  "꼭짓점을 옆으로 옮기면 두 밑각은 언제 같아질까요":
    "When are the base angles equal as you move the vertex sideways",
  "두 삼각형의 측정값을 비교하여 합동인지 선택하세요":
    "Compare the measurements and decide whether the triangles are congruent",
  "밑면과 높이가 같은 원뿔 한 분량은 원기둥 높이의":
    "One cone with the same base and height fills this fraction of the cylinder",
  "빗변과 다른 한 변을 같게 한 두 직각삼각형입니다":
    "These right triangles have equal hypotenuses and one equal leg",
  "원뿔은 꼭짓점으로 갈수록 단면 반지름이 작아집니다":
    "A cone's cross-sectional radius decreases toward the apex",
  "이 하나 늘면 전체 대각선 수는 얼마나 늘어날까요":
    "How many diagonals are added when the number of vertices increases by one",
  "주사위의 합이 같으면 나올 가능성도 모두 같을까요":
    "Are all possible sums of two dice equally likely",
  "중심각이 두 배면 호의 길이와 넓이도 두 배입니다":
    "Doubling the central angle doubles both arc length and sector area",
  "최빈값은 별도 줄에 표시되어 서로 가리지 않습니다":
    "Modes are shown on a separate row to prevent overlap",
  "횡단선의 기울기가 달라져도 대응 관계는 유지됩니다":
    "Corresponding positions remain the same when the transversal's slope changes",
  "눈높이를 빼먹으면 계산 결과는 어떻게 달라질까요":
    "What happens if you omit eye height from the calculation",
  "두 변의 중점을 이은 선분은 밑변의 몇 배일까요":
    "What fraction of the base is the segment joining the midpoints of two sides",
  "빗변을 늘리고 각을 유지하면 삼각비는 달라질까요":
    "Do trigonometric ratios change when the hypotenuse grows but the angle stays fixed",
  "업로드한 자료는 이 브라우저 안에서만 처리됩니다":
    "Uploaded data is processed only in this browser",
  "원호의 교점은 두 거리 조건을 동시에 만족합니다":
    "Intersections of arcs satisfy both distance conditions",
  "자료의 소수 자릿수에 맞게 잎의 단위를 바꾸세요":
    "Choose a leaf unit that matches the decimal precision of the data",
  "전체 결과와 사건의 결과 수를 비교해 설명하세요":
    "Explain your answer by comparing favorable outcomes with all outcomes",
  "평행을 고정하면 같은 위치의 각이 항상 같습니다":
    "When the lines are parallel, corresponding angles are equal",
  "꼭짓점 수와 상관없이 출발 방향으로 돌아옵니다":
    "The walker returns to its original direction regardless of the number of vertices",
  "끼인각이 둔각이면 높이는 어느 쪽에 그려질까요":
    "Where is the altitude when the included angle is obtuse",
  "높이는 밑변 또는 그 연장선에 내린 수선입니다":
    "The altitude is perpendicular to the base or its extension",
  "변하는 양과 일정한 양을 구분해 말하게 합니다":
    "Explain which quantities change and which remain constant",
  "빗변과 한 예각을 같게 한 두 직각삼각형입니다":
    "These right triangles have equal hypotenuses and one equal acute angle",
  "전개도에서 어느 면이 윗면과 마주 보게 될까요":
    "Which face of the net is opposite the top face",
  "축에 수직으로 자르면 원 모양 단면이 생깁니다":
    "A cut perpendicular to the axis produces a circular cross section",
  "한 사람이 두 역할을 동시에 맡을 수 없습니다":
    "One person cannot fill both roles",
  "같은 잎이 반복되면 자료의 반복도 보존됩니다":
    "Repeated leaves preserve repeated data values",
  "그린 윤곽과 회전축 사이의 영역이 회전합니다":
    "The region between the outline and the rotation axis revolves",
  "대변과 대각이 같고 대각선은 서로 이등분한다":
    "Opposite sides and angles are equal, and diagonals bisect each other",
  "두 변의 합은 나머지 한 변보다 커야 합니다":
    "The sum of two sides must exceed the remaining side",
  "두 원의 교점은 두 조건을 동시에 만족합니다":
    "The intersection of two circles satisfies both conditions",
  "로 올리고 편차와 편차의 제곱을 시각화합니다":
    "Upload data and visualize deviations and their squares",
  "모든 기본 결과의 가능성이 같다고 가정합니다":
    "All elementary outcomes are assumed equally likely",
  "밑넓이와 높이가 같을 때만 비교가 가능합니다":
    "The comparison applies only when base area and height are equal",
  "번호가 붙은 공을 한 개씩 두 번 뽑고 복원":
    "Draw two numbered balls one at a time, with replacement",
  "보다 크면 빗변 쪽 정사각형은 어떻게 될까요":
    "How does the square opposite the included angle compare when that angle is greater than",
  "세 번의 같은 원뿔 분량이 원기둥을 채웁니다":
    "Three equal cone volumes fill the cylinder",
  "시행 조건을 바꾸면 누적 기록이 초기화됩니다":
    "Changing trial conditions clears the accumulated results",
  "원호의 반지름은 컴퍼스가 보존하는 길이입니다":
    "Arc radii represent lengths preserved by the compass",
  "주황 점을 수직선 위에서 직접 옮겨도 됩니다":
    "You can also move the orange point directly along the number line",
  "한 쌍의 대변 길이가 같기만 하면 충분할까요":
    "Is equality of just one pair of opposite sides sufficient",
  "현의 길이는 중심각에 단순 비례하지 않습니다":
    "Chord length is not directly proportional to the central angle",
  "각 칸이 서로 구별되는 한 가지 결과입니다":
    "Each cell represents one distinct outcome",
  "두 도형에는 동일한 합동 조건이 적용됩니다":
    "The same congruence condition is applied to both shapes",
  "를 중심으로 같은 반지름의 원호를 그립니다":
    "Draw arcs with equal radius centered at",
  "마우스나 손가락으로 원하는 윤곽을 그립니다":
    "Draw the desired outline with a mouse or finger",
  "양 끝은 이웃한 빈 계급의 계급값에서 도수":
    "The endpoints use the midpoints of adjacent empty classes, with frequency",
  "역할 없이 뽑으면 순서를 구별하지 않습니다":
    "When selecting without assigned roles, order does not matter",
  "의 절반보다 큰 반지름으로 원호를 그립니다":
    "Draw arcs with a radius greater than half of",
  "입력한 조건으로 삼각형을 만들 수 없습니다":
    "These conditions do not form a triangle",
  "좌표판에 직선이나 곡선을 먼저 그려 주세요":
    "First draw a line or curve on the board",
  "중심에서 현에 내린 수선은 현을 이등분한다":
    "A perpendicular from the center to a chord bisects the chord",
  "첫 번째 공을 주머니에 다시 넣고 있습니다":
    "Returning the first ball to the bag",
  "최빈값을 구하고 이상치를 움직여 비교합니다":
    "Calculate the mode and move outliers to compare the results",
  "큰 파란 평면이 자르는 자리는 주황색입니다":
    "The orange region is the section cut by the large blue plane",
  "한 조건이 부족하면 여러 모양이 가능합니다":
    "Without enough conditions, multiple shapes are possible",
  "각뿔대를 평면으로 잘라 단면을 관찰합니다":
    "Cut pyramidal frustums with a plane to observe their sections",
  "공에는 번호가 있어 각 결과를 구별합니다":
    "Numbered balls make each outcome distinguishable",
  "두 대응변의 비가 같고 끼인각이 같습니다":
    "Two corresponding side ratios and the included angles are equal",
  "반올림 전 값으로 일치 여부를 판단합니다":
    "Equality is checked before rounding",
  "비스듬해져도 대각선이 서로를 이등분할까요":
    "Do the diagonals still bisect each other when the shape is slanted",
  "삼각형이 만들어지는 조건을 입력해 주세요":
    "Enter conditions that form a triangle",
  "선분의 이등분 작도를 단계별로 확인합니다":
    "Explore perpendicular-bisector constructions step by step",
  "슬라이더 또는 방향키로 값을 바꿔 보세요":
    "Change values with the sliders or arrow keys",
  "시작값이 계급폭의 배수가 되게 설정하세요":
    "Set the starting value to a multiple of the class width",
  "에서 밑변 길이는 그림의 크기를 정할 뿐":
    "The base length sets the drawing size only",
  "외곽 모서리에서 외각만큼 방향을 바꿉니다":
    "Turn by the exterior angle at each outside corner",
  "점은 다각형 바깥의 점선 경로를 걷습니다":
    "The point walks along the dashed path outside the polygon",
  "주머니에서 첫 번째 공을 꺼내고 있습니다":
    "Drawing the first ball from the bag",
  "최빈값은 여러 개이거나 없을 수 있습니다":
    "There may be multiple modes or no mode",
  "현의 길이는 중심각에 정비례하지 않습니다":
    "Chord length is not proportional to the central angle",
  "공의 개수를 바꾸면 기록을 초기화합니다":
    "Changing the number of balls clears the history",
  "내심은 삼각형 밖으로 나갈 수 있을까요":
    "Can the incenter ever lie outside the triangle",
  "달라지는 값과 유지되는 값을 기록하세요":
    "Record the quantities that change and those that stay constant",
  "둔각삼각형의 외심은 어느 곳에 있을까요":
    "Where is the circumcenter of an obtuse triangle",
  "를 누르면 그 꼭짓점에서 다시 그립니다": "Click to redraw from that vertex",
  "를 제외한 나머지 호 위에서 움직입니다":
    "The point moves along the remaining arc, excluding",
  "면은 모서리를 중심으로 회전해 만납니다":
    "Faces rotate around their shared edges to meet",
  "모양에 따라 조건이 자동으로 유지됩니다":
    "The relevant conditions are maintained for the selected shape",
  "비복원에서는 첫 공을 제외하고 뽑습니다":
    "Without replacement, exclude the first ball from the second draw",
  "상관관계가 인과관계를 뜻하지는 않습니다":
    "Correlation does not imply causation",
  "어느 줄기에 자료가 가장 많이 모였나요":
    "Which stem contains the most values",
  "에서 반지름과 접선이 수직으로 만납니다":
    "The radius and tangent meet at a right angle at",
  "의 값이 무엇으로 결정되는지 탐구합니다":
    "Explore what determines the values of",
  "이 전개 배치에는 겹치는 면이 있습니다":
    "Some unfolded faces overlap in this net",
  "잎을 클릭하면 해당 원자료가 강조됩니다":
    "Click a leaf to highlight its original data value",
  "지름을 바라보는 원주각은 왜 직각일까요":
    "Why is an inscribed angle subtending a diameter a right angle",
  "현재 설정을 포함한 링크를 복사했습니다":
    "Copied a link containing the current settings",
  "회전축에서의 거리만큼 반지름이 생깁니다":
    "Distance from the rotation axis determines the radius",
  "값은 소수 둘째 자리까지 반올림합니다":
    "Values are rounded to two decimal places",
  "같은 화면 축척에서 반지름이 변합니다":
    "The radius changes while the screen scale stays fixed",
  "꼭짓점을 클릭하거나 탭으로 선택한 뒤":
    "Click a vertex or select it with Tab, then",
  "는 두 선택이 겹치지 않는 경우입니다": "The two choices do not overlap",
  "두 번째 삼각형을 닮음비에 맞춰 생성":
    "Generate the second triangle using the scale factor",
  "두 쌍이 같으면 나머지 각도 같습니다":
    "If two pairs of angles match, the remaining pair matches too",
  "를 중심으로 같은 반지름 원호를 그려": "Draw equal-radius arcs centered at",
  "상대도수의 분모는 전체 자료 수입니다":
    "The denominator of relative frequency is the full dataset size",
  "세 쌍의 대응변의 길이비를 비교합니다":
    "Compare all three corresponding side ratios",
  "위치를 맞춰도 변이 일치하지 않습니다":
    "The sides do not match even after alignment",
  "자는 두 점을 지나는 직선을 만듭니다":
    "A ruler draws a straight line through two points",
  "전개한 면끼리 겹치지 않는 배치입니다": "The unfolded faces do not overlap",
  "중심에 더 가까운 현은 왜 더 길까요":
    "Why is a chord closer to the center longer",
  "중심축을 포함하는 평면으로 잘랐습니다":
    "The cutting plane includes the central axis",
  "히스토그램 막대는 서로 붙어 있습니다": "Histogram bars touch one another",
  "그림의 칸을 눌러 결과를 확인하세요": "Click a cell to inspect the outcome",
  "꼭짓점 번호는 도형 밖에 표시합니다":
    "Vertex numbers are placed outside the shape",
  "남은 공에서 두 번째 공을 뽑으세요":
    "Draw the second ball from those remaining",
  "대응각만 같아도 크기까지 같아질까요":
    "Do equal corresponding angles imply equal size",
  "로 맞추면 중점 연결 정리가 됩니다":
    "Set this value to apply the midpoint theorem",
  "반올림으로 원자료를 바꾸지 않습니다":
    "The original data is not changed by rounding",
  "부피비는 닮은 입체도형에 적용됩니다":
    "Volume ratios apply to similar solids",
  "분산은 편차 제곱의 합을 자료 개수":
    "Variance is the sum of squared deviations divided by the data count",
  "상대도수와 대푯값을 함께 탐구합니다":
    "Explore relative frequency and measures of center together",
  "외각을 확인한 뒤 걷기를 시작하세요":
    "Inspect the exterior angles before starting the walk",
  "은 같은 선택이므로 한 번만 셉니다":
    "These are the same selection, so count them once",
  "정사각형은 직사각형이면서 마름모이다":
    "A square is both a rectangle and a rhombus",
  "주황 선분은 세 변까지의 수선입니다":
    "The orange segments are perpendicular distances to the three sides",
  "첫 번째 공 뽑기를 눌러 시작하세요": "Start by pressing Draw first ball",
  "페이지 이미지는 재게시하지 않습니다":
    "Textbook page images are not republished",
  "평균은 모든 자료의 영향을 받습니다": "Every data value affects the mean",
  "표시 값은 소수 둘째 자리까지입니다":
    "Displayed values are rounded to two decimal places",
  "관찰하며 수학의 원리를 발견합니다":
    "Observe and discover mathematical principles",
  "그림 크기는 고정하고 실제 길이는":
    "The drawing size stays fixed; the actual length is",
  "내심에서 세 변까지의 거리는 같다":
    "The incenter is equidistant from the three sides",
  "대각선의 길이와 중점을 비교하세요": "Compare diagonal lengths and midpoints",
  "도수분포다각형은 각 계급의 계급값":
    "A frequency polygon uses class midpoints",
  "두 교점에서 같은 위치의 각입니다":
    "These angles occupy the same position at two intersections",
  "등변사다리꼴의 대각선을 비교합니다":
    "Compare the diagonals of an isosceles trapezoid",
  "를 넘으면 큰 중심각을 사용합니다":
    "Use the reflex central angle when the angle exceeds",
  "새로 그리면 이전 윤곽을 바꿉니다":
    "Drawing again replaces the previous outline",
  "엇각의 위치 조건에 맞지 않습니다":
    "The angles do not satisfy the positional condition for alternate interior angles",
  "이미지 저장을 완료하지 못했습니다": "Could not save the image",
  "전체 대각선은 두 번씩 세어지므로": "Each diagonal is counted twice, so",
  "중심에 가까울수록 현이 길어집니다":
    "A chord gets longer as it approaches the center",
  "첫 역할과 둘째 역할을 구별합니다":
    "The first and second roles are distinguished",
  "초기화를 눌러 다시 시도해 주세요": "Press Reset to try again",
  "측정값은 그림 아래에서 비교합니다": "Compare measurements below the diagram",
  "확대 비율을 바꾸며 대응변과 넓이":
    "Change the scale factor to compare corresponding sides and areas",
  "각형의 내각의 합은 몇 도일까요":
    "What is the sum of the interior angles of this polygon",
  "공을 한 개씩 두 번 뽑는 실험":
    "An experiment drawing two balls one at a time",
  "닮음 조건에는 사용하지 않습니다":
    "It is not part of the similarity condition",
  "돌리기를 눌러 회전체를 만드세요":
    "Press Rotate to generate the solid of revolution",
  "두 번째 각을 번갈아 선택합니다":
    "Alternate between selecting the first and second angles",
  "명 중 서로 다른 두 역할 뽑기":
    "Choose two distinct roles from this number of people",
  "밑면은 옆면의 경계에 연결됩니다":
    "The bases stay attached to the boundary of the lateral surface",
  "비복원 과정과 결과를 비교합니다":
    "Compare the process and results without replacement",
  "세 대응변의 비가 모두 같습니다":
    "All three corresponding side ratios are equal",
  "숫자를 하나 이상 입력해 주세요": "Enter at least one number",
  "시작점에서 끝점까지 드래그합니다":
    "Drag from the starting point to the endpoint",
  "점을 직접 드래그할 수 있습니다": "You can drag the points directly",
  "주황 회전축의 오른쪽에 그리세요":
    "Draw to the right of the orange rotation axis",
  "행에 숫자가 아닌 값이 있습니다": "These rows contain nonnumeric values",
  "개가 되도록 범위를 조정하세요":
    "Adjust the range to obtain this number of classes",
  "건물에서 눈과 같은 높이의 점": "The point on the building at eye level",
  "공유 모서리를 축으로 접습니다": "Fold around the shared edges",
  "그 각 안의 호에 대한 원주각":
    "The inscribed angle subtending the arc inside that angle",
  "끝값은 시작값보다 커야 합니다": "The end value must exceed the start value",
  "다른 밑면 변 수를 선택하세요": "Choose a different number of base sides",
  "도형의 닮음과 피타고라스 정리": "Similarity and the Pythagorean theorem",
  "두 번째 공을 꺼내고 있습니다": "Drawing the second ball",
  "두 쌍의 변의 길이비와 끼인각": "Two side ratios and their included angle",
  "두 직선과 횡단선에서 각 선택":
    "Select angles formed by two lines and a transversal",
  "명 중 역할 없이 두 명 뽑기": "Choose two people without assigning roles",
  "서로 다른 두 각을 선택하세요": "Select two different angles",
  "선분이 표시 범위를 넘었습니다":
    "The segment extends beyond the displayed range",
  "손을 떼면 윤곽선이 확정됩니다": "Release to finish the outline",
  "원뿔의 전개도를 접고 펼칩니다": "Fold and unfold cone nets",
  "이면 원뿔의 부피는 얼마일까요":
    "What is the cone's volume if the cylinder's volume is",
  "점선은 변의 수직이등분선입니다":
    "Dashed lines are perpendicular bisectors of the sides",
  "조건을 한 번에 하나씩 바꾸고": "Change one condition at a time",
  "첫 공과 다른 공을 뽑았습니다": "A different ball from the first was drawn",
  "한 시행은 두 번의 추출입니다": "One trial consists of two draws",
  "가 되면 회전체가 완성됩니다": "The solid of revolution is complete at",
  "값과 그림을 함께 관찰하세요": "Observe the values and diagram together",
  "값이 일정하여 그릴 수 없음":
    "Cannot draw a trend line because the values are constant",
  "검색어나 필터를 바꿔 주세요": "Try another search term or filter",
  "대각선의 이등분을 측정합니다": "Measure how the diagonals bisect each other",
  "대각선이 서로를 이등분합니다": "The diagonals bisect each other",
  "서로 구별되는 주사위 두 개": "Two distinguishable dice",
  "선택한 열에 숫자가 없습니다": "The selected column contains no numbers",
  "에서 옮겨 반직선을 그립니다": "Transfer it to draw a ray from",
  "열에 숫자 하나씩 입력합니다": "Enter one number per row in the column",
  "원뿔의 옆면은 곡면으로 말기":
    "Roll the cone's lateral face into a curved surface",
  "의 삼각비를 어떻게 얻을까요":
    "How can you obtain the trigonometric ratios of",
  "이 커질수록 어떻게 변할까요": "How does it change as the number increases",
  "인터랙티브 시각화 독자 제작": "Original interactive visualizations",
  "잎은 작은 수부터 정렬합니다": "Leaves are sorted in ascending order",
  "조건에 맞는 활동이 없습니다": "No activities match your selection",
  "직선 또는 곡선 직접 그리기": "Draw a straight line or curve directly",
  "휠 또는 두 손가락으로 확대": "Use the wheel or two fingers to zoom",
  "나머지 호 위 꼭짓점 위치": "Vertex position on the remaining arc",
  "다각형 면은 모서리로 접고": "Fold polygonal faces along their edges",
  "대응하는 두 각이 같습니다": "Two corresponding angles are equal",
  "대응하는 선분의 길이 비교": "Compare corresponding segment lengths",
  "두 삼각형의 변과 각 비교": "Compare the sides and angles of two triangles",
  "두 역할은 순서를 구별하고": "Assigned roles make the order matter",
  "따옴표가 닫히지 않았습니다": "The quotation mark is not closed",
  "를 모두 숫자로 입력하세요": "Enter both values as numbers",
  "를 보는 원주각과 같습니다": "It equals the inscribed angle subtending",
  "빗변에 대한 다른 변의 비": "Ratio of a leg to the hypotenuse",
  "삼각형을 만들 수 없습니다": "The values do not form a triangle",
  "세 번 부으면 가득 찹니다": "Three pours fill the cylinder",
  "유효한 수를 입력해 주세요": "Enter a valid number",
  "입력 조건을 확인해 주세요": "Check the input conditions",
  "입체를 드래그하면 회전하고": "Drag the solid to rotate it",
  "전체 원은 항상 표시합니다": "The full circle is always shown",
  "조건을 조작하는 수학 실험": "An interactive mathematics experiment",
  "첫 결과에 따른 둘째 확률":
    "Probability of the second result given the first",
  "초록 점선은 각의 이등분선": "Green dashed lines are angle bisectors",
  "파란 영역은 구하는 부채꼴": "The blue region is the selected sector",
  "한 바퀴 동안의 총 회전은": "The total turn during one circuit is",
  "한 쌍 대변 평행하고 같음": "One pair of opposite sides parallel and equal",
  "횡단선의 반대쪽에 있습니다": "They lie on opposite sides of the transversal",
  "값은 아래에서 확인하세요": "Read the value below the diagram",
  "개의 삼각형으로 나뉩니다": "The polygon is divided into this many triangles",
  "두 각은 어떤 관계일까요": "How are the two angles related",
  "두 번 모두 빨강이 아님": "The two balls are not both red",
  "두 번 뽑기를 진행하세요": "Complete the two draws",
  "두 번 추출을 마쳤습니다": "Both draws are complete",
  "부피의 변화를 비교합니다": "Compare changes in volume",
  "소수 둘째 자리까지 표시": "Displayed to two decimal places",
  "아래 교점을 연결해 중점":
    "Connect the intersections above and below to find the midpoint",
  "연한 주황은 여사건입니다": "Pale orange represents the complement",
  "이하의 자료를 사용하세요": "Use values at or below this limit",
  "저장할 시각화가 없습니다": "No visualization is available to save",
  "접점에서 현 끝점까지 호": "Arc from the contact point to the chord endpoint",
  "정삼각형을 반으로 나누면": "Bisect an equilateral triangle to obtain",
  "주황 부채꼴은 외각입니다": "The orange sector is an exterior angle",
  "주황 점선은 변의 연장선": "The orange dashed line extends a side",
  "직선적 상관이 거의 없음": "Almost no linear correlation",
  "첫 공을 따로 두었습니다": "The first ball has been set aside",
  "첫 번째 공을 다시 넣기": "Return the first ball",
  "컴퍼스는 길이를 보존하고": "A compass preserves lengths",
  "파랑은 사건에 속한 결과": "Blue represents outcomes in the event",
  "합이 이 수 이상인 사건": "Event: the sum is at least this value",
  "같은 공 구성에서 복원": "Compare replacement using the same set of balls",
  "같은 교점이거나 동위각":
    "The angles share an intersection or are corresponding",
  "같은 호에 대한 원주각": "Inscribed angles subtending the same arc",
  "단위원 위 점을 움직여": "Move the point on the unit circle",
  "두 끝점에서 같은 거리": "Equal distance from both endpoints",
  "두 번 뽑기 자동 재생": "Animate both draws",
  "변을 따라 이동한 다음": "Move along a side, then",
  "사이의 수를 입력하세요": "Enter a value in this range",
  "삼각형 입력 조건 확인": "Check the triangle's input conditions",
  "수정할 값을 입력하세요": "Enter a replacement value",
  "실험을 열지 못했습니다": "Could not open the experiment",
  "에서 곡면으로 말립니다": "Roll into a curved surface from",
  "에서도 원호를 그립니다": "Draw an arc from this point too",
  "외각을 먼저 관찰하세요": "Observe the exterior angles first",
  "이 있으면 잎의 단위를":
    "If the data contains this precision, set the leaf unit to",
  "이등변삼각형으로 맞추기": "Make an isosceles triangle",
  "이하로 업로드해 주세요": "Upload a file smaller than this limit",
  "자동으로 변화시킬 항목": "Choose what changes automatically",
  "접선과 현이 이루는 각": "Angle between a tangent and a chord",
  "조건이 같아 합동입니다":
    "The conditions match, so the triangles are congruent",
  "좌우 위치를 조절하세요": "Adjust its horizontal position",
  "주사위 두 개의 순서쌍": "Ordered pairs from two dice",
  "주황 선은 반지름입니다": "The orange line is a radius",
  "주황 호에 대한 중심각": "Central angle subtending the orange arc",
  "줄기 단위는 잎 단위의": "The stem unit is this multiple of the leaf unit",
  "중심축을 포함하는 평면": "Plane through the central axis",
  "직선들을 평행하게 고정": "Keep the lines parallel",
  "첫 결과를 확인했습니다": "The first result is ready",
  "학습 내용과 흐름 참고":
    "Based on the textbook's learning content and sequence",
  "개까지 입력해 주세요": "Enter up to this number of values",
  "경우를 차례로 그리기": "Draw outcomes in sequence",
  "공백으로 구분한 자료": "Data separated by spaces",
  "과 도수를 연결합니다": "Connect the midpoints with their frequencies",
  "관찰하는 호의 중심각": "Central angle of the selected arc",
  "그래프에서 제외됩니다": "Excluded from the chart",
  "기울기를 바꾸며 대변": "Change the slant and compare opposite sides",
  "꼭짓점에서 자른 비율": "Fraction of the distance from the vertex",
  "동시에 일어나는 선택": "Simultaneous choices",
  "두 넓이의 합이 일치": "The two areas have the same total",
  "두 번째 삼각형 이동": "Move the second triangle",
  "두 번째 삼각형 회전": "Rotate the second triangle",
  "두 직선이 평행할 때": "When the two lines are parallel",
  "를 드래그하거나 높이": "Drag the point or change the height",
  "링크를 복사해 주세요": "Copy the link below",
  "막대 위에 도수 표시": "Show frequencies above bars",
  "바깥 모서리에서 회전": "Turn at an outer corner",
  "사이로 입력해 주세요": "Enter a value within the range",
  "삼각비와 삼각형 넓이": "Trigonometric ratios and triangle area",
  "설정 범위 밖의 자료": "Data outside the specified range",
  "세 쌍의 변의 길이비": "Three corresponding side ratios",
  "에서 위쪽 접선과 현": "The angle between the upward tangent and chord at",
  "에서는 두 각의 합이": "The sum of the two angles must be",
  "오른쪽 도형은 왼쪽을": "The shape on the right is the left shape scaled by",
  "원에 내접하는 사각형": "Cyclic quadrilateral",
  "윤곽선이 준비됐습니다": "The outline is ready",
  "의 길이를 관찰합니다": "Observe the lengths of",
  "의 반직선을 그립니다": "Draw a ray at this angle",
  "의 수 또는 후보 수": "Number of choices or candidates",
  "이미지를 저장했습니다": "Image saved",
  "조건에 맞는 각 찾기": "Find angles matching a condition",
  "주황 선은 시선입니다": "The orange line is the line of sight",
  "중심에서 현까지 거리": "Distance from the center to the chord",
  "평면 이동 애니메이션": "Animate the cutting plane",
  "평행사변형으로 맞추기": "Make a parallelogram",
  "평행사변형이 아닙니다": "Not a parallelogram",
  "한 변수의 값이 일정": "One variable is constant",
  "각과 빗변을 바꾸며": "Change the angle and hypotenuse to explore",
  "각형 대각선 발생기": "Polygon diagonal generator",
  "공정한 동전 한 개": "One fair coin",
  "다시 비교해 보세요": "Compare again",
  "다시 확인해 보세요": "Check again",
  "닮음 조건과 측정값": "Similarity conditions and measurements",
  "대각선 서로 이등분": "Diagonals bisect each other",
  "대응값을 확인하세요": "Check the corresponding values",
  "두 각의 관계 판별": "Classify the pair of angles",
  "두 변의 중점 연결": "Join the midpoints of two sides",
  "두 쌍의 대변 평행": "Both pairs of opposite sides parallel",
  "를 업로드해 주세요": "Upload the file",
  "를 중심으로 반지름": "Centered at this point, with radius",
  "마지막 직선 기울기": "Slope of the last line",
  "모든 값이 한 번씩": "Each value occurs once",
  "모든 대각선 그리기": "Draw all diagonals",
  "바꿔 볼 자료 선택": "Choose a value to edit",
  "배면 넓이와 부피도":
    "If lengths scale by this factor, do areas and volumes also scale by",
  "보다 작아야 합니다": "Must be smaller than",
  "사이의 각을 봅니다": "Observe the angle between them",
  "삼각비로 높이 재기": "Measuring heights with trigonometry",
  "삼각형의 닮음 조건": "Triangle similarity criteria",
  "상대도수 눈금 간격": "Relative frequency tick interval",
  "선택한 자료의 편차": "Deviation of the selected value",
  "세 중선은 무게중심": "The three medians meet at the centroid",
  "소수 근삿값도 보기": "Also show decimal approximations",
  "수업용 자료는 최대": "Classroom datasets support up to",
  "아직 시행하지 않음": "No trials yet",
  "우리 반 자료 분포": "Our class data distribution",
  "원뿔 한 분량 붓기": "Pour one cone of water",
  "유효한 숫자 자료를": "Valid numeric data",
  "은 어떻게 변할까요": "How will this change",
  "의 비가 유지될까요": "Will the ratio stay constant",
  "의 연장선이 만나는": "Where the extension meets",
  "이등변삼각형의 성질": "Properties of isosceles triangles",
  "인 원호를 그립니다": "Draw an arc with this radius",
  "입체도형 단면 실험": "Solid cross-section experiment",
  "자동으로 변화 관찰": "Observe automatic changes",
  "자료의 정리와 해석": "Organizing and interpreting data",
  "정다각형 꼭짓점 수": "Number of regular polygon vertices",
  "직선들은 평행합니다": "The lines are parallel",
  "평균과 편차선 표시": "Show mean and deviation lines",
  "한 꼭짓점의 대각선": "Diagonals from one vertex",
  "회전과 관계없습니다": "Independent of rotation",
  "회전해 맞춰 보세요": "Rotate to align",
  "각뿔대의 면 수는": "Number of faces of the frustum",
  "각형의 한 외각은": "One exterior angle of the polygon",
  "경우의 수와 확률": "Counting and probability",
  "고리 모양 부채꼴": "Annular sector",
  "그 사이의 끼인각": "The included angle",
  "그림의 크기 설정": "Drawing size",
  "기본 도형과 작도": "Basic geometry and constructions",
  "길이 비교는 이동": "Length comparison is independent of translation",
  "꼭짓점 좌우 위치": "Horizontal vertex position",
  "는 정의하지 않음": "Undefined",
  "단위로 계산합니다": "Calculate in these units",
  "두 대각선의 중점": "Midpoints of the two diagonals",
  "두 도형의 반지름": "Radius of both solids",
  "두 반직선의 교점": "Intersection of the two rays",
  "두 번 모두 빨강": "Both draws are red",
  "두 번째 공 뽑기": "Draw the second ball",
  "두 삼각형은 닮음": "The two triangles are similar",
  "마지막 계급 끝값": "Final class endpoint",
  "무작위 합동 판별": "Random congruence quiz",
  "산점도와 상관관계": "Scatter plots and correlation",
  "삼각형 합동 실험": "Triangle congruence experiment",
  "삼각형을 변형해도": "Even when the triangle changes",
  "삼각형의 무게중심": "Centroid of a triangle",
  "상관이 없는 예시": "No-correlation example",
  "선택한 자료의 값": "Selected data value",
  "세 변까지의 거리": "Distances to the three sides",
  "시행 기록 지우기": "Clear trial history",
  "알 수 없는 실험": "Unknown experiment",
  "여러 가지 사각형": "Types of quadrilaterals",
  "원뿔 단면 반지름": "Cone cross-section radius",
  "자료로 히스토그램": "Data for the histogram",
  "자료를 입력하거나": "Enter data or",
  "자료의 퍼진 정도": "Spread of data",
  "자와 컴퍼스 작도": "Ruler and compass constructions",
  "주머니에 남은 공": "Balls remaining in the bag",
  "직각삼각형의 합동": "Right triangle congruence",
  "직접 그리기 도구": "Freehand drawing tools",
  "첫 번째 공 뽑기": "Draw the first ball",
  "초록 원은 외접원": "The green circle is the circumcircle",
  "칸을 눌러 보세요": "Select a cell",
  "편차 제곱 계산표": "Squared-deviation table",
  "평행사변형의 성질": "Properties of parallelograms",
  "각뿔대와 원기둥": "Frustums and cylinders",
  "각뿔의 면 수는": "Number of faces of the pyramid",
  "같은 반지름으로": "Using the same radius",
  "경우의 수 탐색": "Exploring counting",
  "공 두 번 뽑기": "Drawing two balls",
  "그리는 중입니다": "Drawing in progress",
  "눈높이 위 높이": "Height above eye level",
  "다각형 삼각분할": "Triangulating polygons",
  "다시 살펴보세요": "Try again",
  "닮음비와 넓이비": "Similarity and area ratios",
  "대푯값과 이상치": "Measures of center and outliers",
  "도수 눈금 간격": "Frequency tick interval",
  "두 도형의 높이": "Height of both solids",
  "두 변수의 관계": "Relationship between two variables",
  "두 변의 끼인각": "Included angle between the two sides",
  "두 원호의 교점": "Intersection of the two arcs",
  "두 접선의 길이": "Lengths of the two tangents",
  "많이 퍼진 자료": "More spread-out data",
  "배 확대했습니다": "Times larger",
  "분산과 표준편차": "Variance and standard deviation",
  "분석할 숫자 열": "Numeric column to analyze",
  "삼각형 하나마다": "For each triangle",
  "삼각형과 평행선": "Triangles and parallel lines",
  "상대도수로 보기": "Show relative frequency",
  "새 삼각형 생성": "Generate a new triangle",
  "색상 모드 전환": "Toggle color theme",
  "선택 자료 수정": "Edit selected data",
  "선택한 자료 값": "Selected data value",
  "설정 링크 복사": "Copy settings link",
  "아직 뽑지 않음": "Not drawn yet",
  "양 끝값의 평균": "Mean of the extreme values",
  "양의 상관 경향": "Positive correlation trend",
  "양의 상관 예시": "Positive correlation example",
  "에 가까워질 때": "As it approaches",
  "에서 각각 하나": "One from each",
  "에서 주어진 각": "The given angle at",
  "연속 시행 정지": "Stop repeated trials",
  "열을 선택하세요": "Select a column",
  "오른쪽으로 상승": "Rises to the right",
  "오른쪽으로 하강": "Falls to the right",
  "외각 먼저 보기": "Show the exterior angles first",
  "원기둥의 부피가": "Volume of the cylinder",
  "원자료의 대푯값": "Measures of center of the raw data",
  "원주각과 중심각": "Inscribed and central angles",
  "으로 연결합니다": "Connect",
  "음의 상관 경향": "Negative correlation trend",
  "음의 상관 예시": "Negative correlation example",
  "이번 시행 결과": "Current trial result",
  "이하여야 합니다": "Must be no greater than",
  "인접한 직각변은": "The adjacent leg is",
  "입력 자료 적용": "Apply entered data",
  "입체도형의 성질": "Properties of solids",
  "잎을 클릭하세요": "Select a leaf",
  "자동 변화 정지": "Stop automatic changes",
  "자료 직접 입력": "Enter data manually",
  "적게 퍼진 자료": "Less spread-out data",
  "전체 경우의 수": "Total number of outcomes",
  "접선과 현의 각": "Angle between a tangent and a chord",
  "줄기와 잎 그림": "Stem-and-leaf plot",
  "직각으로 맞추기": "Set to a right angle",
  "직접 입력 자료": "Manually entered data",
  "처음부터 그리기": "Draw from the beginning",
  "첫 계급 시작값": "First class starting value",
  "평면도형의 성질": "Properties of plane figures",
  "평행 고정 해제": "Unlock parallel lines",
  "평행사변형 판별": "Identifying parallelograms",
  평행사변형입니다: "It is a parallelogram",
  "평행선과 동위각": "Parallel lines and corresponding angles",
  "피타고라스 정리": "Pythagorean theorem",
  "합동 조건 조작": "Explore congruence criteria",
  "해당 경우의 수": "Number of favorable outcomes",
  "확률과 상대도수": "Probability and relative frequency",
  "가 더해집니다": "Is added",
  "각 관계 활동": "Angle relationships activity",
  "값의 절댓값은": "The absolute value is",
  "개 입력하세요": "Enter this many values",
  "개정 교육과정": "Revised curriculum",
  "과 구별하세요": "Distinguish from",
  "교과서의 본문": "Textbook content",
  "그려진 대각선": "Diagonals drawn",
  "기준각의 위치": "Reference angle position",
  "끝 직접 설정": "Set endpoint manually",
  "내접원 반지름": "Inradius",
  "누적 상대도수": "Cumulative relative frequency",
  "대각선의 중점": "Midpoint of the diagonal",
  도수분포다각형: "Frequency polygon",
  "두 각의 합은": "The sum of the two angles is",
  "두 번째 결과": "Second result",
  "두 번째 추출": "Second draw",
  "두 직선 사이": "Between the two lines",
  "로 선택하세요": "Select",
  "를 비교합니다": "Compare",
  "를 사용하세요": "Use",
  "를 연결합니다": "Connect",
  "를 표시합니다": "Show",
  "를 확인하세요": "Check",
  "를 확인합니다": "Check",
  "밑면의 변 수": "Number of base sides",
  "빨간 공 개수": "Number of red balls",
  "사각형의 성질": "Properties of quadrilaterals",
  "삼각형의 내심": "Incenter of a triangle",
  "삼각형의 성질": "Properties of triangles",
  "삼각형의 외심": "Circumcenter of a triangle",
  "상관관계 없음": "No correlation",
  "새 실험 준비": "Prepare a new experiment",
  "선분의 이등분": "Bisecting a segment",
  "선택한 기준각": "Selected reference angle",
  "성립하지 않음": "Does not hold",
  "에 수직입니다": "Perpendicular to",
  "에서 만납니다": "Meet at",
  "여사건의 확률": "Probability of the complement",
  "예각의 삼각비": "Trigonometric ratios of acute angles",
  "예제 불러오기": "Load example",
  "와 평행합니다": "Parallel to",
  "움직여 포개기": "Drag to superimpose",
  "으로 나눕니다": "Divide by",
  "의 가로 위치": "Horizontal position",
  "의 중점입니다": "Is the midpoint",
  "이등분할 선분": "Segment to bisect",
  "이전 그림으로": "Undo drawing",
  "자료 값 변경": "Change data value",
  "자료와 그래프": "Data and graphs",
  "접선과 반지름": "Tangent and radius",
  "정의하지 않음": "Undefined",
  "주머니 속 공": "Balls in the bag",
  "중심까지 거리": "Distance to the center",
  "첫 번째 결과": "First result",
  "첫 번째 추출": "First draw",
  "카메라 초기화": "Reset camera",
  "파란 공 개수": "Number of blue balls",
  "한 바퀴 완료": "One full circuit completed",
  "합동이 아니다": "Not congruent",
  "회 빠른 시행": "Quick trials",
  "회 추출 결과": "Draw results",
  "회전체 생성기": "Solid of revolution generator",
  "각의 이등분": "Bisecting an angle",
  "건물 꼭대기": "Top of the building",
  "관찰자의 눈": "Observer's eye",
  "교과서 연계": "Textbook connections",
  "교과서 활용": "Based on the textbook",
  "구와 각기둥": "Spheres and prisms",
  "그래프 제목": "Chart title",
  "그리기 도구": "Drawing tool",
  "그리기 속도": "Drawing speed",
  "그리기 정지": "Stop drawing",
  "그림 지우기": "Clear drawing",
  "기록 지우기": "Clear history",
  "는 주황 호": "Is the orange arc",
  "단면 반지름": "Cross-section radius",
  "대푯값 탐구": "Exploring measures of center",
  "두 각의 합": "Sum of the two angles",
  "두 번 빨강": "Two red balls",
  "두 번째 각": "Second angle",
  "두 변의 합": "Sum of two sides",
  "두 쌍의 각": "Two pairs of angles",
  "둘 다 아님": "Neither",
  등변사다리꼴: "Isosceles trapezoid",
  "로 나눕니다": "Divide by",
  "를 긋습니다": "Draw",
  "를 잡습니다": "Mark",
  "부채꼴 넓이": "Sector area",
  "비복원 비교": "Compare without replacement",
  "비복원 추출": "Without replacement",
  "빗변의 중점": "Midpoint of the hypotenuse",
  "사건에 속함": "Belongs to the event",
  "사건의 경우": "Favorable outcomes",
  "삼각비의 뜻": "Understanding trigonometric ratios",
  "삼각형 개수": "Number of triangles",
  "삼각형 회전": "Triangle rotation",
  "삼각형과 각": "Triangles and angles",
  "선택한 결과": "Selected outcome",
  "선택한 경우": "Selected case",
  "선택한 자료": "Selected data",
  "선택한 점의": "Of the selected point",
  "선택한 조건": "Selected criterion",
  "수정할 자료": "Data to edit",
  "수학 시각화": "Math visualization",
  "업로드 대상": "Upload target",
  "에서 반지름": "Radius from",
  "옆변 기울기": "Lateral edge slope",
  "와 접선 위": "And on the tangent",
  "외각의 정의": "Definition of an exterior angle",
  "외심의 위치": "Position of the circumcenter",
  "원호의 교점": "Intersection of the arcs",
  "을 얻습니다": "Obtain",
  "을 채웁니다": "Fill",
  "이 다릅니다": "Differ",
  이등변삼각형: "Isosceles triangle",
  "이등분한 각": "Bisected angle",
  "이론적 확률": "Theoretical probability",
  "자료 업로드": "Upload data",
  "자료는 최대": "Maximum dataset size",
  "자료의 개수": "Number of data values",
  "자료의 평균": "Mean of the data",
  "전개할 입체": "Solid to unfold",
  "전체 대각선": "Total diagonals",
  "전체 면 수": "Total number of faces",
  "절단면 높이": "Cutting plane height",
  "정확히 일치": "Exact match",
  "주어진 길이": "Given length",
  "중점의 성질": "Midpoint properties",
  "중학교 수학": "Middle school mathematics",
  "집단과 비교": "Compare with the group",
  "첫 번째 각": "First angle",
  "최빈값 계산": "Calculate mode",
  "추세선 방향": "Trend line direction",
  "추세선 표시": "Show trend line",
  "평균선 표시": "Show mean line",
  "표준 파일은": "The template file",
  "하나씩 세기": "Count one by one",
  "한 변 길이": "Side length",
  "확률의 성질": "Properties of probability",
  "횡단선 각도": "Transversal angle",
  "횡단선 제외": "Excluding the transversal",
  "개념 연결": "Concept connections",
  "거리의 비": "Distance ratio",
  "건물 높이": "Building height",
  "경우의 수": "Number of outcomes",
  "계급 경계": "Class boundaries",
  "계급 수가": "Number of classes",
  "계급 시작": "Class start",
  "계산 과정": "Calculation steps",
  "곡선 예제": "Curve example",
  "곱의 법칙": "Multiplication principle",
  "그린 경우": "When drawn",
  "그림 종류": "Figure type",
  "기준 선분": "Reference segment",
  "길이 같음": "Equal lengths",
  "길이 일치": "Lengths match",
  "꼭짓점 수": "Number of vertices",
  "나머지 변": "Remaining side",
  "내각의 합": "Sum of interior angles",
  "넓이 실험": "Area experiment",
  "누적 성공": "Cumulative successes",
  "눈금 간격": "Tick interval",
  "다시 분리": "Separate again",
  "다시 세기": "Count again",
  "다음 단계": "Next step",
  "단면 넓이": "Cross-section area",
  "단면 모양": "Cross-section shape",
  "단면 없음": "No cross section",
  "닮음 조건": "Similarity criterion",
  "대각 같음": "Equal opposite angles",
  "대응 요소": "Corresponding parts",
  맞았습니다: "Correct",
  "모두 일치": "All match",
  "모든 단원": "All units",
  "물체 높이": "Object height",
  "밑변 길이": "Base length",
  "보다 크고": "Greater than",
  "복원 추출": "With replacement",
  "빗변 길이": "Hypotenuse length",
  "뿔의 부피": "Pyramid/cone volume",
  "삼각형 밖": "Outside the triangle",
  "삼각형 안": "Inside the triangle",
  "상관 방향": "Correlation direction",
  생각해보기: "Think about it",
  "서로 다른": "Distinct",
  "서로 다름": "Different",
  "서로 일치": "Match",
  "선택 상황": "Selection scenario",
  "선택 확인": "Check selection",
  "선택한 점": "Selected point",
  "소수 확인": "Check decimal value",
  "수업 활용": "Classroom activity",
  "수평 거리": "Horizontal distance",
  "시행 조건": "Trial conditions",
  "시행 횟수": "Number of trials",
  "실험 목록": "Experiments",
  "실험 시작": "Start experiment",
  애니메이션: "Animation",
  "양 끝 각": "Angles at both ends",
  "양의 상관": "Positive correlation",
  "연속 시행": "Repeated trials",
  "예상 확인": "Check prediction",
  "올려본 각": "Angle of elevation",
  "완성 그림": "Completed construction",
  "외각의 합": "Sum of exterior angles",
  "외곽 걷기": "Walk around",
  "원과 접선": "Circles and tangents",
  "원의 성질": "Properties of circles",
  "음의 상관": "Negative correlation",
  "의 길이비": "Length ratio",
  "의 높이가": "Height",
  "의 대변은": "Opposite side",
  "의 삼각비": "Trigonometric ratios",
  "이유 설명": "Explain the reason",
  "이전 단계": "Previous step",
  "인 원호로": "Using an arc",
  "잎의 단위": "Leaf unit",
  "자동 시연": "Automatic demonstration",
  "자료 값은": "Data values",
  "자료 개수": "Number of values",
  "자료 번호": "Data index",
  "자료 적용": "Apply data",
  "자료의 합": "Sum of values",
  "자유 곡선": "Freehand curve",
  "작도 활동": "Construction activity",
  "재생 속도": "Playback speed",
  "전개 불가": "Cannot unfold",
  "전체 도수": "Total frequency",
  "전체 보기": "Show all",
  정답입니다: "Correct",
  정십이면체: "Regular dodecahedron",
  정이십면체: "Regular icosahedron",
  "조건 성립": "Criterion satisfied",
  "조건 조작": "Explore conditions",
  "주어진 각": "Given angle",
  "주황 선분": "Orange segment",
  "주황 점선": "Orange dashed line",
  "줄기 단위": "Stem unit",
  직각삼각형: "Right triangle",
  "직선 예제": "Straight-line example",
  "집단 자료": "Group data",
  "집단 적용": "Apply group data",
  "찾을 관계": "Relationship to find",
  "채운 부피": "Filled volume",
  "처음 위치": "Starting position",
  "초록 직선": "Green line",
  "총 회전각": "Total turning angle",
  축소합니다: "Scale down",
  "통계 검색": "Search statistics",
  "판단 불가": "Cannot determine",
  "편차의 합": "Sum of deviations",
  "학년 선택": "Select year",
  "학년 수학": "Mathematics",
  "합동 조건": "Congruence criterion",
  "합의 법칙": "Addition principle",
  "현의 길이": "Chord length",
  "호의 길이": "Arc length",
  "확률 예상": "Predict probability",
  "활동 검색": "Search activities",
  "활동 제목": "Activity title",
  "회전 속도": "Rotation speed",
  히스토그램: "Histogram",
  "가 아님": "Is not",
  "각 다름": "Angles differ",
  "각 일치": "Angles match",
  "각 표시": "Show angles",
  "각도 차": "Angle difference",
  "개 계급": "Classes",
  "개 실험": "Experiments",
  "개는 표": "Table entries",
  개입니다: "Items",
  "계급 수": "Number of classes",
  계급폭은: "Class width",
  관찰하기: "Observe",
  교육활동: "Educational activities",
  다운로드: "Download",
  단원부터: "And later units",
  돌아가기: "Go back",
  동아출판: "Dong-A Publishing",
  "두 밑각": "Two base angles",
  "두 열의": "Of the two columns",
  발표모드: "Presentation mode",
  배일까요: "Times as much",
  배입니다: "Times as much",
  "번 자료": "Data item",
  "번째 변": "Side",
  붙여넣기: "Paste",
  상대도수: "Relative frequency",
  수업자료: "Teaching materials",
  수학실험: "Math experiment",
  오름차순: "Ascending order",
  움직이고: "Move",
  "원과 현": "Circles and chords",
  "의 높이": "Height",
  "의 위치": "Position",
  "의 평균": "Mean",
  "인 선분": "Segment",
  일시정지: "Pause",
  "읽는 법": "How to read",
  입체도형: "Solid shapes",
  "잎 단위": "Leaf unit",
  "자료 수": "Data count",
  "자료 열": "Data column",
  정다면체: "Regular polyhedron",
  정사각형: "Square",
  정사면체: "Regular tetrahedron",
  정육면체: "Cube",
  정팔면체: "Regular octahedron",
  "주황 호": "Orange arc",
  "줄기 수": "Number of stems",
  "중 하나": "One of",
  중심각의: "Central angle",
  중심각이: "Central angle",
  즐겨찾기: "Favorites",
  직사각형: "Rectangle",
  "직선 수": "Number of lines",
  직육면체: "Cuboid",
  처음부터: "Restart",
  "첫 번째": "First",
  "첫 확률": "First probability",
  표본분산: "Sample variance",
  표준편차: "Standard deviation",
  "한 외각": "One exterior angle",
  "한 줄에": "On each line",
  합동이다: "Congruent",
  "회 시행": "Trials",
  각기둥: "Prism",
  각뿔대: "Pyramid frustum",
  각형은: "Polygon",
  계급폭: "Class width",
  관찰자: "Observer",
  그래프: "Graph",
  기준각: "Reference angle",
  길이가: "Length",
  길이비: "Length ratio",
  꼭짓점: "Vertex",
  끼인각: "Included angle",
  넓이비: "Area ratio",
  눈높이: "Eye height",
  다각형: "Polygon",
  닮음비: "Similarity ratio",
  대각선: "Diagonal",
  대응각: "Corresponding angle",
  대응변: "Corresponding side",
  대푯값: "Measures of center",
  데이터: "Data",
  돌리기: "Rotate",
  동위각: "Corresponding angles",
  "두 변": "Two sides",
  라이트: "Light",
  마름모: "Rhombus",
  "면 수": "Number of faces",
  바꾸고: "Change",
  반지름: "Radius",
  방향키: "Arrow keys",
  보조선: "Auxiliary line",
  부채꼴: "Sector",
  부피비: "Volume ratio",
  비복원: "Without replacement",
  비우기: "Clear",
  빗변은: "Hypotenuse",
  사각형: "Quadrilateral",
  삼각비: "Trigonometric ratios",
  삼각형: "Triangle",
  "세 변": "Three sides",
  여사건: "Complement",
  옆면은: "Lateral face",
  "와 각": "And angle",
  원기둥: "Cylinder",
  원뿔대: "Cone frustum",
  원자료: "Raw data",
  원주각: "Inscribed angle",
  "은 현": "Chord",
  "의 수": "Count",
  이상치: "Outlier",
  이하의: "At most",
  입니다: "Is",
  전개도: "Net",
  절댓값: "Absolute value",
  중심각: "Central angle",
  중앙값: "Median",
  중학교: "Middle school",
  직각은: "Right angle",
  초기화: "Reset",
  최빈값: "Mode",
  특수각: "Special angles",
  펼치기: "Unfold",
  평행선: "Parallel lines",
  포개기: "Superimpose",
  포개짐: "Alignment",
  학년도: "School year",
  "한 변": "One side",
  회전각: "Rotation angle",
  회전체: "Solid of revolution",
  각뿔: "Pyramid",
  각이: "Angle",
  각형: "Polygon",
  감소: "Decrease",
  거리: "Distance",
  검증: "Verify",
  계급: "Class",
  계산: "Calculate",
  곡선: "Curve",
  교점: "Intersection",
  기하: "Geometry",
  길이: "Length",
  끝값: "Endpoint",
  내각: "Interior angle",
  넓이: "Area",
  높이: "Height",
  다름: "Different",
  다크: "Dark",
  단면: "Cross section",
  단원: "Unit",
  닮음: "Similar",
  대각: "Opposite angle",
  도수: "Frequency",
  도형: "Figure",
  둔각: "Obtuse angle",
  뒷면: "Tails",
  또는: "Or",
  미만: "Less than",
  밑각: "Base angle",
  밑면: "Base",
  밑변: "Base side",
  방법: "Method",
  복원: "Replacement",
  부터: "From",
  부피: "Volume",
  분산: "Variance",
  비교: "Compare",
  빗변: "Hypotenuse",
  빨강: "Red",
  사건: "Event",
  삽화: "Illustrations",
  선택: "Select",
  설명: "Explanation",
  성공: "Success",
  성립: "Satisfied",
  수평: "Horizontal",
  쉼표: "Comma",
  시작: "Start",
  시행: "Trial",
  실험: "Experiment",
  아님: "No",
  앞면: "Heads",
  없음: "None",
  엇각: "Alternate interior angles",
  에서: "At",
  예각: "Acute angle",
  예측: "Predict",
  외각: "Exterior angle",
  원뿔: "Cone",
  이동: "Move",
  이상: "At least",
  일치: "Match",
  입체: "Solid",
  자료: "Data",
  작도: "Construction",
  재생: "Play",
  저장: "Save",
  전체: "All",
  접기: "Fold",
  접점: "Point of tangency",
  접힘: "Folded",
  정지: "Stop",
  조건: "Condition",
  조작: "Explore",
  좌표: "Coordinates",
  주황: "Orange",
  줄기: "Stem",
  증가: "Increase",
  직각: "Right angle",
  직선: "Straight line",
  진행: "Progress",
  집단: "Group",
  차이: "Difference",
  최근: "Recent",
  최대: "Maximum",
  통계: "Statistics",
  파랑: "Blue",
  판별: "Identify",
  편차: "Deviation",
  평균: "Mean",
  표준: "Template",
  학기: "Semester",
  합계: "Total",
  합동: "Congruent",
  행의: "Row",
  확률: "Probability",
  활동: "Activity",
  회전: "Rotate",
  회차: "Trial",
  힌트: "Hint",
  각: "Angle",
  값: "Value",
  강: "Kang",
  개: "Items",
  과: "And",
  구: "Sphere",
  끝: "End",
  는: "Is",
  를: "-",
  면: "Face",
  배: "Times",
  번: "Number",
  변: "Side",
  분: "Min",
  빈: "Empty",
  열: "Column",
  예: "Example",
  와: "And",
  원: "Circle",
  위: "Above",
  은: "Is",
  의: "Of",
  잎: "Leaf",
  점: "Point",
  정: "Regular",
  중: "Year",
  차: "Difference",
  초: "Sec",
  총: "Total",
  합: "Sum",
  호: "Arc",
  회: "Trials",
  "언어 선택": "Select language",
  "n각형은 n−2개의 삼각형으로 나뉩니다.":
    "An n-gon can be divided into n − 2 triangles.",
  "12각형의 내각의 합은 몇 도일까요?":
    "What is the sum of the interior angles of a 12-gon?",
  "SSS·SAS·ASA 삼각형과 각·선분의 이등분 작도를 단계별로 확인합니다.":
    "Construct SSS, SAS, and ASA triangles, angle bisectors, and perpendicular bisectors step by step.",
  "직선·곡선으로 윤곽을 그리고 회전축 둘레로 돌려 입체를 만듭니다.":
    "Draw an outline using straight lines or curves, then rotate it around an axis to make a solid.",
  "원기둥·원뿔·구와 각기둥·각뿔·각뿔대를 평면으로 잘라 단면을 관찰합니다.":
    "Cut cylinders, cones, spheres, prisms, pyramids, and pyramidal frustums with a plane to explore their cross sections.",
  "정다면체·각기둥·각뿔·각뿔대와 원기둥·원뿔의 전개도를 접고 펼칩니다.":
    "Fold and unfold nets of regular polyhedra, prisms, pyramids, frustums, cylinders, and cones.",
  "CSV 자료로 히스토그램·도수분포다각형·상대도수와 대푯값을 함께 탐구합니다.":
    "Use CSV data to explore histograms, frequency polygons, relative frequencies, and measures of center.",
  "평행선과 동위각·엇각":
    "Parallel lines: corresponding and alternate interior angles",
  "각의 부채꼴이나 문자 버튼을 눌러도 선택할 수 있습니다. 첫 번째·두 번째 각을 번갈아 선택합니다. 엇각은 선택한 두 직선 사이에서 횡단선의 서로 반대쪽에 있는 각입니다.":
    "Click an angle sector or letter button to select it. Selections alternate between the first and second angles. Alternate interior angles lie between the two selected lines on opposite sides of the transversal.",
  "컴퍼스는 길이를 보존하고, 자는 두 점을 지나는 직선을 만듭니다. 원호의 교점은 두 거리 조건을 동시에 만족합니다.":
    "A compass preserves lengths, and a ruler draws a straight line through two points. Intersections of arcs satisfy both distance conditions.",
  "길이 비교는 이동·회전과 관계없습니다. 반올림 전 값으로 일치 여부를 판단합니다.":
    "Translation and rotation do not affect side lengths. Equality is checked using values before rounding.",
  "SS만 같을 때 삼각형이 하나로 정해지지 않는 까닭은 무엇일까요?":
    "Why do two side lengths alone (SS) fail to determine a unique triangle?",
  "n각형 대각선 발생기": "Polygon diagonal generator",
  "꼭짓점을 클릭하거나 탭으로 선택한 뒤 Enter를 누르면 그 꼭짓점에서 다시 그립니다. 꼭짓점 번호는 도형 밖에 표시합니다.":
    "Click a vertex, or select it using Tab and press Enter, to draw from that vertex. Vertex numbers appear outside the polygon.",
  "주황 점선은 변의 연장선, 주황 부채꼴은 외각입니다. 외각을 확인한 뒤 걷기를 시작하세요.":
    "The orange dashed line extends a side, and the orange sector marks the exterior angle. Inspect the angles before starting the walk.",
  "점은 다각형 바깥의 점선 경로를 걷습니다. 변을 따라 이동한 다음, 외곽 모서리에서 외각만큼 방향을 바꿉니다.":
    "The point follows the dashed path outside the polygon. After moving along each side, it turns through the exterior angle at the next corner.",
  "전체 원은 항상 표시합니다. 파란 영역은 구하는 부채꼴, 주황 선은 반지름입니다. 그림 크기는 고정하고 실제 길이는 cm 단위로 계산합니다.":
    "The full circle remains visible. The blue region is the selected sector, and the orange line is a radius. The drawing size stays fixed; actual lengths are measured in cm.",
  "표준 파일은 value 열에 숫자 하나씩 입력합니다. 여러 열이 있으면 업로드 후 분석할 열을 선택하세요. 최대 1,000개.":
    "Enter one number per row in the template's value column. For files with multiple columns, select the column to analyze after uploading. Maximum: 1,000 values.",
  "주황 점을 수직선 위에서 직접 옮겨도 됩니다. 평균·중앙값·최빈값은 별도 줄에 표시되어 서로 가리지 않습니다.":
    "Drag the orange point along the number line. Mean, median, and mode appear on separate rows to avoid overlap.",
  "줄기 단위는 잎 단위의 10배입니다. 잎을 클릭하면 해당 원자료가 강조됩니다. 선택한 단위로 정확히 나타낼 수 없는 값은 알림을 표시합니다.":
    "The stem unit is 10 times the leaf unit. Click a leaf to highlight its original data value. An alert appears if the chosen unit cannot represent a value exactly.",
  "도수분포다각형은 각 계급의 계급값(양 끝값의 평균)과 도수를 연결합니다. 양 끝은 이웃한 빈 계급의 계급값에서 도수 0으로 연결합니다.":
    "A frequency polygon connects class midpoints at their corresponding frequencies. Each midpoint is the mean of the class endpoints. At both ends, the line meets frequency 0 at the midpoint of the neighboring empty class.",
  "RHA·RHS 조건을 선택하고 빗변과 각 또는 변을 바꿔 포개 봅니다.":
    "Choose RHA or RHS, adjust the hypotenuse and an angle or side, and superimpose the triangles.",
  "초록 점선은 각의 이등분선, 주황 선분은 세 변까지의 수선입니다.":
    "The green dashed lines are angle bisectors. The orange segments are perpendiculars to the three sides.",
  "오른쪽 도형은 왼쪽을 k배 확대했습니다. 부피비는 닮은 입체도형에 적용됩니다.":
    "The figure on the right is scaled by a factor of k. The volume ratio applies to similar solids.",
  "SSS·SAS·AA에 맞는 변과 각을 입력하고 두 삼각형의 조건 성립 여부를 비교합니다.":
    "Enter the sides and angles required for SSS, SAS, or AA, and test whether the triangles satisfy that similarity criterion.",
  "자동 생성을 끄면 두 삼각형의 값을 각각 입력하여 조건 성립 여부를 비교할 수 있습니다. AA에서 밑변 길이는 그림의 크기를 정할 뿐, 닮음 조건에는 사용하지 않습니다.":
    "Turn off automatic generation to enter the two triangles independently. For AA, the base length sets the drawing size and is not part of the similarity criterion.",
  "주황 선분 DE는 BC와 평행합니다. 0.5로 맞추면 중점 연결 정리가 됩니다.":
    "The orange segment DE is parallel to BC. Set the ratio to 0.5 to illustrate the midpoint theorem.",
  "M은 BC의 중점입니다. 세 중선은 무게중심 G에서 만납니다.":
    "M is the midpoint of BC. The three medians meet at the centroid G.",
  "합·곱의 법칙과 순서의 구별을 선택하고 결과를 하나씩 그리며 셉니다.":
    "Choose the addition or multiplication principle and whether order matters, then display and count outcomes one by one.",
  "A 또는 B는 두 선택이 겹치지 않는 경우입니다. 두 역할은 순서를 구별하고, 역할 없이 뽑으면 순서를 구별하지 않습니다.":
    "For A or B, the choices do not overlap. Assigned roles make order matter; selecting without roles does not distinguish order.",
  "P(A가 아님)": "P(not A)",
  "복원·비복원 추출": "Drawing with and without replacement",
  "번호가 붙은 공을 한 개씩 두 번 뽑고 복원·비복원 과정과 결과를 비교합니다.":
    "Draw two numbered balls one at a time. Compare the process and results with and without replacement.",
  "각과 빗변을 바꾸며 sin·cos·tan의 값이 무엇으로 결정되는지 탐구합니다.":
    "Change the angle and hypotenuse to explore what determines the sine, cosine, and tangent ratios.",
  "직각은 B입니다. A의 대변은 BC, 인접한 직각변은 AB, 빗변은 AC입니다.":
    "B is the right angle. For angle A, BC is opposite, AB is adjacent, and AC is the hypotenuse.",
  "직각은 B입니다. C의 대변은 AB, 인접한 직각변은 BC, 빗변은 AC입니다.":
    "B is the right angle. For angle C, AB is opposite, BC is adjacent, and AC is the hypotenuse.",
  "30°·45°·60°의 삼각비": "Trigonometric ratios of 30°, 45°, and 60°",
  "단위원 위 점을 움직여 sin·cos와 접선 위 tan의 길이를 관찰합니다.":
    "Move the point on the unit circle to explore sine and cosine, and the tangent length on the tangent line.",
  "초록 직선 x = 1과 OP의 연장선이 만나는 T의 높이가 tan A입니다.":
    "The height of T is tan A. T is where the extension of OP meets the green line x = 1.",
  "sin A = P의 y좌표": "sin A = y-coordinate of P",
  "cos A = P의 x좌표": "cos A = x-coordinate of P",
  "0° ≤ A ≤ 90°에서 sin 증가, cos 감소 · tan 90°는 정의하지 않음":
    "From 0° to 90°, sine increases and cosine decreases. tan 90° is undefined.",
  "거리·올려본 각·눈높이로 직접 닿지 못하는 물체의 높이를 계산합니다.":
    "Calculate an inaccessible object's height using distance, angle of elevation, and eye height.",
  "같은 화면 축척에서 반지름이 변합니다. OM은 현 AB에 수직입니다. 중심에 가까울수록 현이 길어집니다.":
    "The radius changes at a fixed screen scale. OM is perpendicular to chord AB. Chords become longer closer to the center.",
  "같은 화면 축척에서 반지름이 변합니다. 접점 A, B에서 반지름과 접선이 수직으로 만납니다.":
    "The radius changes at a fixed screen scale. The radius and tangent are perpendicular at each point of tangency, A and B.",
  "C는 주황 호 AB를 제외한 나머지 호 위에서 움직입니다. 중심각이 180°를 넘으면 큰 중심각을 사용합니다.":
    "C moves on the arc outside the orange arc AB. A reflex central angle is used when the central angle exceeds 180°.",
  "A에서 위쪽 접선과 현 AB 사이의 각을 봅니다. 주황 호 AB를 보는 원주각과 같습니다.":
    "Observe the angle between the upward tangent at A and chord AB. It equals the inscribed angle subtending the orange arc AB.",
  "CSV 자료의 평균·중앙값·최빈값을 구하고 이상치를 움직여 비교합니다.":
    "Calculate the mean, median, and mode of CSV data, then move outliers to compare their effects.",
  "자료를 입력하거나 CSV로 올리고 편차와 편차의 제곱을 시각화합니다.":
    "Enter data or upload a CSV file to visualize deviations and their squares.",
  "분산은 편차 제곱의 합을 자료 개수 n으로 나눕니다. 표본분산(n−1)과 구별하세요. 업로드한 자료는 이 브라우저 안에서만 처리됩니다.":
    "Variance divides the sum of squared deviations by the number of values, n. This differs from sample variance, which divides by n − 1. Uploaded data is processed only in this browser.",
  "두 열의 CSV로 산점도를 만들고 점을 옮겨 상관관계를 관찰합니다.":
    "Create a scatter plot from a two-column CSV file and move the points to explore correlation.",
  "본문으로 건너뛰기": "Skip to content",
  맞꼭지각: "Vertically opposite angles",
  "한 각을 선택해 맞꼭지각을 찾고, 두 각이 맞꼭지각인지 판별합니다.":
    "Select an angle to find its opposite angle, then classify pairs of angles.",
  "각을 선택하면 반대편 맞꼭지각이 자동으로 표시됩니다.":
    "Selecting an angle automatically highlights its vertically opposite angle.",
  "각의 크기나 두 직선의 방향을 바꾸어도 맞꼭지각의 크기는 같습니다.":
    "Vertically opposite angles remain equal as the angle or line direction changes.",
  "두 각의 크기가 같다는 사실만으로 맞꼭지각이라고 할 수 있을까요?":
    "Are equal angles necessarily vertically opposite?",
  "평면과 공간의 위치 관계": "Position relationships in a plane and in space",
  "위치 관계": "Position relationship",
  평행: "Parallel",
  "꼬인 위치": "Skew",
  "다양한 입체": "Various solids",
  "관계를 직접 그리며 살펴보고, 입체의 변과 면에서 같은 관계를 모두 찾습니다.":
    "Watch each relationship being drawn, then find all matching edges and faces of a solid.",
  "평면과 공간에서 가능한 위치 관계를 비교합니다.":
    "Compare the possible relationships in a plane and in space.",
  "선택한 변이나 면과 조건에 맞는 모든 요소가 색상과 목록으로 표시됩니다.":
    "Every element matching the selected edge or face relationship is highlighted and listed.",
  "만나지 않는 두 직선은 공간에서도 항상 평행할까요?":
    "Are non-intersecting lines always parallel in space?",
  "직선–직선 · 직선–평면 · 평면–평면": "Line–line · Line–plane · Plane–plane",
  "원과 부채꼴 · 원주율 추정": "Circles and sectors · Estimating pi",
  원주율: "Pi",
  "내접·외접": "Inscribed and circumscribed",
  격자: "Grid",
  "내접·외접 다각형으로 π의 범위를 좁히고, 90° 부채꼴의 격자 대표점으로 추정합니다.":
    "Bound pi using inscribed and circumscribed polygons, then estimate it with grid midpoints in a quarter-circle.",
  "다각형의 변 수를 하나씩 늘리면 두 넓이 사이의 차이가 줄어듭니다.":
    "Increasing the number of polygon sides by one reduces the gap between the two areas.",
  "격자 중앙의 대표점이 원 안에 있는지 같은 기준으로 셉니다.":
    "Use the same midpoint rule to count which cells lie inside the circle.",
  "격자를 더 촘촘히 할 때 추정값은 매번 π에 더 가까워질까요?":
    "Does every finer grid give a closer estimate of pi?",
  "내접 넓이 < π < 외접 넓이 (반지름 1) · π ≈ 4 × 안쪽 점 / 전체 점":
    "Inscribed area < pi < circumscribed area (radius 1) · pi ≈ 4 × inside points / all points",
  자르기: "Cutting",
  "원을 중심각만큼 나누고 부채꼴 조각을 엇갈려 붙여 호의 길이와 넓이를 비교합니다.":
    "Cut a circular sector into pieces and rearrange them to compare arc lengths and areas.",
  "자르고 옮겨도 조각의 호의 길이의 합과 넓이의 합은 같습니다.":
    "Cutting and moving pieces preserves the total original arc length and area.",
  "조각이 많을수록 직사각형에 가까워지지만 유한 개 조각의 경계는 곡선입니다.":
    "More pieces approach a rectangle, but finitely many pieces still have curved boundaries.",
  "자르는 개수가 달라도 넓이가 달라지지 않는 이유를 설명해 보세요.":
    "Explain why changing the number of cuts does not change the area.",
  "맞꼭지각 찾기": "Find opposite angles",
  "두 각 판별하기": "Classify two angles",
  "교차하는 각": "Intersection angle",
  "직선의 방향": "Line direction",
  "기준 각 선택": "Select an angle",
  "선택한 각은 주황색, 맞꼭지각은 파란색입니다. 그림의 각을 눌러도 선택됩니다.":
    "The selected angle is orange and its opposite is blue. You can also select angles in the diagram.",
  "직각으로 비교하기": "Compare right angles",
  "선택한 두 각": "Selected pair",
  "각의 크기": "Angle measures",
  맞꼭지각입니다: "Vertically opposite",
  "꼭짓점이 같고, 각을 이루는 두 쌍의 반직선이 각각 반대 방향입니다.":
    "They share a vertex and each pair of corresponding rays points in opposite directions.",
  "각을 누르면 맞꼭지각이 함께 표시됩니다.":
    "Select an angle to highlight its opposite.",
  "교차하는 두 직선과 네 각": "Two intersecting lines and four angles",
  "서로 다른 두 각 선택": "Select two different angles",
  "선택 지우기": "Clear selection",
  "그림 또는 버튼에서 두 각을 고르세요. 크기가 같아도 맞꼭지각이 아닐 수 있습니다.":
    "Choose two angles using the diagram or buttons. Equal angles need not be vertically opposite.",
  "맞꼭지각이 아닙니다": "Not vertically opposite",
  "두 각은 한 변을 공유하는 이웃한 각입니다. 크기가 같아도 맞꼭지각은 아닙니다.":
    "These adjacent angles share a ray. Even when equal, they are not vertically opposite.",
  "두 각을 골라 맞꼭지각인지 확인하세요.":
    "Select two angles to classify the pair.",
  "선택한 각": "Selected angles",
  "두 각을 선택하면 판별 결과와 이유를 보여줍니다.":
    "Select two angles to see the result and explanation.",
  "내접·외접 다각형": "Polygon bounds",
  "90° 부채꼴 격자": "Quarter-circle grid",
  "다각형의 변 수 n": "Number of sides n",
  "변 수 직접 입력": "Enter number of sides",
  "증가 간격": "Step interval",
  "n은 3부터 1024까지 1씩 증가합니다. 반지름 1인 원의 넓이는 π입니다.":
    "n increases by 1 from 3 to 1024. A unit circle has area pi.",
  "내접 다각형 넓이": "Inscribed polygon area",
  "외접 다각형 넓이": "Circumscribed polygon area",
  "범위의 폭": "Bound width",
  "내접 넓이": "Inscribed area",
  "외접 넓이": "Circumscribed area",
  "원의 넓이": "Circle area",
  "범위의 중간값": "Midpoint estimate",
  "π와의 절대오차": "Absolute error from pi",
  "π = 3.141592654… · 표시값은 반올림하였습니다.":
    "pi = 3.141592654… · Displayed values are rounded.",
  "내접·외접 정다각형으로 좁히는 원주율의 범위":
    "Bounds on pi from inscribed and circumscribed regular polygons",
  "한 변의 칸 수 n": "Cells per side n",
  "칸 수 직접 입력": "Enter cells per side",
  "각 칸의 중앙에 점을 하나 찍습니다. 중심에서 점까지의 거리가 반지름 이하이면 셉니다. 전체 칸 수는 n²입니다.":
    "Place a point at each cell midpoint. Count it if its distance from the center is at most the radius. There are n² cells.",
  "촘촘한 격자에서는 점 대신 칸의 색으로 표시합니다. 계산은 모든 대표점을 사용합니다.":
    "Dense grids use cell colors instead of visible dots. Every midpoint is still counted.",
  "원 안의 대표점": "Midpoints inside",
  "전체 대표점": "Total midpoints",
  "π 추정값": "Estimate of pi",
  "원 안: 세는 점": "Inside: counted",
  "원 밖: 세지 않는 점": "Outside: not counted",
  "격자가 촘촘해지면 π로 수렴하지만, 매 단계에서 오차가 작아지는 것은 아닙니다.":
    "Finer grids converge to pi, but the error need not decrease at every step.",
  "90도 부채꼴 격자 대표점 시각화":
    "Quarter-circle grid midpoint visualization",
  "중심각 직접 입력": "Enter central angle",
  "자르는 개수": "Number of pieces",
  "자르는 개수 직접 입력": "Enter number of pieces",
  "엇갈려 붙이기": "Rearrange alternately",
  "자르고 옮기기": "Cut and rearrange",
  "원래 위치": "Original position",
  "각 조각의 곡선인 호를 그대로 유지하여 자르고 옮깁니다. 조각이 겹치지 않도록 엇갈려 붙입니다.":
    "Keep each curved arc intact and alternate the pieces so the final arrangement has no overlaps.",
  "자르기 전후 넓이의 차이는 정확히 0입니다. 유한 개 조각을 직사각형으로 근사하는 오차와는 다릅니다.":
    "The area difference before and after cutting is exactly zero. Approximating finite pieces as a rectangle is a different issue.",
  "공식으로 계산": "Using the formula",
  "조각의 합으로 계산": "Sum of the pieces",
  "정확한 값의 차이": "Exact difference",
  "잘린 직선 경계는 원래의 호가 아닙니다. 위 표는 원래 호의 길이만 더합니다. 소수는 반올림하므로 표시된 조각의 값을 곱하면 끝자리가 다를 수 있습니다.":
    "New straight cut edges are not part of the original arc. Only original arc lengths are added. Multiplying rounded piece values may change the final digits.",
  "조각 수를 무한히 늘리면 밑변 l/2, 높이 r인 직사각형으로 수렴합니다.":
    "As the number of pieces tends to infinity, the arrangement approaches a rectangle with base l/2 and height r.",
  "원을 자르고, 조각을 움직여 보세요": "Cut the sector and move its pieces",
  "부채꼴을 자르고 엇갈려 붙이기": "Cut and rearrange a sector",
  "곡선 경계를 그대로 유지한 재배열":
    "Rearrangement preserves the curved boundaries",
  평면: "Plane",
  공간: "Space",
  "대상 선택": "Choose objects",
  "두 직선": "Two lines",
  "점이 직선 위에 있다": "The point lies on the line",
  "점이 직선 위에 있지 않다": "The point does not lie on the line",
  "다시 그리기": "Draw again",
  "한 평면 안에서 두 직선은 만나거나 일치하거나 평행합니다.":
    "Two lines in one plane intersect, coincide, or are parallel.",
  대상: "Objects",
  "점 A와 직선 l의 위치를 비교하세요.":
    "Compare the positions of point A and line l.",
  "관계를 고르면 선을 차례로 그려 보여줍니다.":
    "Choose a relationship to draw the lines in sequence.",
  "위치 관계를 차례로 그려보기": "Drawing a position relationship",
  "입체에서 찾기": "Explore a solid",
  "관계 그려보기": "Draw relationships",
  "기준 요소의 종류": "Reference element type",
  "기준 요소": "Reference element",
  "찾을 요소의 종류": "Target element type",
  "한 점에서 만난다": "Intersect at one point",
  평행하다: "Parallel",
  "꼬인 위치에 있다": "Skew",
  일치한다: "Coincident",
  수직이다: "Perpendicular",
  "선택한 기준": "Selected reference",
  "조건에 맞는 요소": "Matching elements",
  "좌우 회전": "Horizontal rotation",
  "상하 회전": "Vertical rotation",
  "처음 보는 방향": "Reset view",
  "그림을 끌어 회전하고, 변이나 면을 눌러 기준을 선택하세요. 가려진 요소는 목록에서도 선택할 수 있습니다.":
    "Drag to rotate, then select a reference edge or face. Hidden elements are also accessible from the list.",
  "변은 양쪽으로 연장한 직선, 면은 끝없이 펼친 평면으로 판단합니다. 수직인 관계는 만나는 관계에도 포함됩니다.":
    "Treat edges as infinite lines and faces as infinite planes. Perpendicular relationships also count as intersecting.",
  기준: "Reference",
  "관계가 일치하는 요소": "Matching elements",
  "그림을 끌어 회전 · 변 또는 면을 눌러 선택":
    "Drag to rotate · Select an edge or face",
  "선택한 입체의 변과 면 위치 관계":
    "Edge and face relationships of the selected solid",
  "기준으로 선택": "Use as reference",
  "구에는 직선 모서리와 평평한 면이 없습니다. 변·평면의 위치 관계를 탐구하려면 다면체를 선택하세요.":
    "A sphere has no straight edges or planar faces. Select a polyhedron to explore line and plane relationships.",
  "직선 모서리": "Straight edges",
  "평평한 면": "Planar faces",
  "전체 면": "Total faces",
  "직선이 평면에 포함된다": "The line lies in the plane",
  "한 직선에서 만난다": "Intersect along a line",
  "두 면이 그림에서 맞닿지 않아도, 평면을 연장하여 만나면 한 직선에서 만나는 관계입니다.":
    "Even if two faces do not touch, their extended planes may intersect along a line.",
  "공통인 점의 위치를 확인하세요.": "Locate the common point.",
  "두 대상이 완전히 겹쳐 하나의 대상이 됩니다.":
    "The two objects overlap completely.",
  "직선과 평면을 끝없이 연장해도 만나지 않습니다.":
    "The objects never meet, even when extended indefinitely.",
  "직선과 평면": "A line and a plane",
  "두 평면": "Two planes",
  "공간의 두 직선은 한 평면에 놓이지 않을 수도 있습니다. 만나지도, 평행하지도 않으면 꼬인 위치입니다.":
    "Lines in space need not lie in one plane. Lines that neither intersect nor are parallel are skew.",
  "두 직선은 만나지 않고, 평행하지 않으며, 한 평면에 있지 않습니다.":
    "These lines do not intersect, are not parallel, and do not lie in one plane.",
  "직선의 모든 점이 평면 위에 있습니다.":
    "Every point of the line lies in the plane.",
  "두 평면의 공통부분은 하나의 직선입니다.": "The two planes share a line.",
  "이 조건에 맞는 요소가 없습니다.": "No elements match this relationship.",
  옆면: "Lateral faces",
  "다각형의 내각과 외각의 합": "Interior and exterior angle sums",
  "꼭짓점 수를 바꾸고 내각·외각의 합을 비교한 뒤, 외각 조각을 모아 360°를 확인합니다.":
    "Change the number of vertices, compare angle sums, and gather the exterior angles to form 360°.",
  "각 꼭짓점에서 내각과 외각의 합은 180°입니다.":
    "At each vertex, the interior and exterior angles add up to 180°.",
  "모든 내각과 외각의 합에서 내각의 합을 빼면 언제나 360°입니다.":
    "Subtracting the interior angle sum from the total of all interior and exterior angles always gives 360°.",
  "볼록다각형의 외각을 하나씩 모으면 한 바퀴를 이룹니다.":
    "One exterior angle from each vertex of a convex polygon forms one full turn.",
  "다각형의 꼭짓점 수와 모양이 바뀌어도 외각의 합이 같은 이유는 무엇일까요?":
    "Why does the exterior angle sum stay the same when the number of vertices or the shape changes?",
  "외각 탐구 활동": "Exterior angle activities",
  "내각·외각의 합": "Angle sums",
  "다각형 모양": "Polygon shape",
  "다른 볼록다각형": "Irregular convex polygon",
  "외각의 합 보기": "Gather exterior angles",
  "원래 위치로": "Return to vertices",
  "모으기 진행 (%)": "Gathering progress (%)",
  "각 꼭짓점에서 한 변을 연장하면 내각과 외각의 합은 180°입니다. 외각은 꼭짓점마다 하나씩 선택합니다.":
    "Extend one side at each vertex: the interior and exterior angles add up to 180°. Choose one exterior angle per vertex.",
  "색칠한 외각을 잘라 옮긴 뒤, 같은 중심에 빈틈없이 모아 보세요. 마지막에는 모든 조각을 같은 비율로 확대합니다. 각의 크기는 변하지 않습니다.":
    "Cut and move the colored exterior angles to a shared center with no gaps. All pieces are then enlarged equally. Their angles stay unchanged.",
  "완성: 외각들이 모여 중심각 360°를 이룹니다.":
    "Complete: the exterior angles form a full 360° at the center.",
  "외각 조각을 잘라 한곳으로 옮기는 중입니다.":
    "Cutting and moving the exterior angles to one center.",
  "멈춘 위치에서 각 조각을 관찰하세요.":
    "Observe the pieces at this paused position.",
  "외각의 합 보기를 눌러 시작하세요.":
    "Select Gather exterior angles to begin.",
  "외각의 합 = 한 바퀴": "Exterior sum = one full turn",
  "외각을 잘라 한곳에 모으기": "Gather the exterior angles",
  "내각 + 외각 = 180°": "Interior + exterior = 180°",
  "다각형의 내각과 외각, 외각 조각을 모은 원":
    "Interior and exterior angles of a polygon, and gathered exterior sectors",
  "모든 내각과 외각의 합": "All interior + exterior angles",
  "꼭짓점 수에 따른 각의 합 비교": "Compare angle sums by vertex count",
  "두 합의 차 = 외각의 합": "Difference = exterior angle sum",
  "꼭짓점별 내각·외각 확인": "Angles at each vertex",
  "각도 표시는 소수 둘째 자리까지 반올림합니다. 합은 반올림 전 값으로 계산합니다.":
    "Angles are displayed to two decimal places. Sums use unrounded values.",
  "구의 겉넓이와 원 4개": "Sphere surface area and four circles",
  "구의 겉넓이": "Sphere surface area",
  "구의 표면을 띠로 나누어 원기둥 옆면과 비교하고, 같은 반지름의 원 4개 넓이와 같음을 확인합니다.":
    "Compare spherical bands with a cylinder and four circles of the same radius.",
  "구와 원의 반지름은 같아야 합니다.":
    "The sphere and circles must have the same radius.",
  "구의 각 띠와 같은 높이에 있는 원기둥의 띠는 넓이가 같습니다.":
    "Each spherical band has the same area as the cylinder band at the same height.",
  "원기둥의 옆면을 펼치면 가로 2πr, 세로 2r인 직사각형입니다.":
    "Unroll the cylinder side into a rectangle of width 2πr and height 2r.",
  "반지름이 두 배가 되어도 원의 넓이에 대한 구의 겉넓이의 비는 같을까요?":
    "Does the area ratio stay the same when the radius doubles?",
  "구의 표면을 같은 높이의 띠로 나누기":
    "Divide the sphere into equal-height bands",
  "같은 넓이의 원기둥 띠로 옮기기": "Map to cylinder bands of equal area",
  "원기둥 옆면 펼치기": "Unroll the cylinder side",
  "같은 반지름의 원 4개와 비교하기": "Compare four circles of the same radius",
  "반지름 r": "Radius r",
  "애니메이션 진행": "Animation progress",
  "띠의 넓이를 비교하는 모형입니다. 구의 표면을 변형 없이 평면으로 펼치는 전개도는 아닙니다.":
    "This model compares band areas. A sphere cannot be flattened without distortion.",
  "같은 반지름 r인 구와 원을 비교합니다. 구의 표면 전체를 높이가 같은 얇은 띠들로 나눕니다.":
    "Compare a sphere and circles of radius r. Divide the sphere into thin bands of equal height.",
  "구의 위쪽에서는 둘레가 짧지만 표면이 더 기울어져 있습니다. 이 두 효과가 상쇄되어 각 띠의 넓이는 원기둥의 같은 높이 띠와 같습니다.":
    "Near the poles, shorter circumference is balanced by greater surface slope. Each band has the same area as its cylinder band.",
  "윗면과 아랫면은 제외합니다. 옆면만 펼치면 가로는 원주 2πr, 세로는 구의 지름 2r입니다.":
    "Exclude the top and bottom. Unroll only the side: width 2πr and height 2r.",
  "구의 겉넓이 = 원기둥의 옆넓이 = 2πr × 2r = 4πr². 반지름이 같은 원 하나의 넓이 πr²의 정확히 4배입니다.":
    "Sphere area = cylinder lateral area = 2πr × 2r = 4πr², exactly four times the area of a circle of the same radius.",
  "넓이의 비": "Area ratio",
  "S구 = S원기둥 옆면": "S sphere = S cylinder side",
  "구의 띠를 원기둥 옆면으로 옮기고 같은 반지름의 원 네 개와 넓이를 비교하는 애니메이션":
    "Animation mapping sphere bands to a cylinder and comparing four equal-radius circles",
  겉넓이: "Surface area",
  "1. 구의 표면을 같은 높이의 띠로 나누기":
    "1. Divide the sphere into equal-height bands",
  "2. 같은 넓이의 원기둥 띠로 옮기기": "2. Map to cylinder bands of equal area",
  "3. 원기둥 옆면 펼치기": "3. Unroll the cylinder side",
  "4. 같은 반지름의 원 4개와 비교하기":
    "4. Compare four circles of the same radius",
  "구와 같은 반지름의 원 4개": "Four circles with the same radius",
  "귤껍질처럼 표면 벗기기": "Peel the surface like an orange",
  "껍질 조각으로 원 채우기": "Fill the circles with peel pieces",
  "원 4개의 넓이와 비교하기": "Compare the area of four circles",
  "껍질 조각의 모양을 조정해 넓이를 대응시킨 모형입니다. 실제 귤껍질을 빈틈없이 펼치는 전개도는 아닙니다.":
    "Pieces change shape to illustrate equal areas. This is not a distortion-free net of real orange peel.",
  "구와 아래의 원 4개는 반지름 r이 같습니다. 재생을 누르면 구의 표면이 귤껍질처럼 벗겨집니다.":
    "The sphere and four circles share radius r. Press play to peel the surface like an orange.",
  "위에서부터 껍질이 바깥으로 말려 나오고, 조각들이 아래로 떨어집니다. 벗겨진 자리에는 구의 속이 드러납니다.":
    "The peel curls outward from the top and falls, revealing the inside of the sphere.",
  "작게 나눈 껍질 조각을 아래의 원에 차례로 모읍니다. 원 하나마다 구의 겉넓이의 4분의 1이 대응합니다.":
    "Collect the small peel pieces in the circles. Each circle corresponds to one quarter of the sphere surface.",
  "껍질 전체가 반지름 r인 원 4개를 채웁니다. 구의 겉넓이 = 4 × πr² = 4πr²입니다.":
    "The whole peel fills four circles of radius r. Sphere area = 4 × πr² = 4πr².",
  "귤껍질처럼 벗겨진 구의 표면이 같은 반지름의 원 네 개를 채우는 애니메이션":
    "Animation of orange-like peel filling four circles of the same radius",
  "모인 껍질": "Collected peel",
  "S구 = 4 × S원": "S sphere = 4 × S circle",
  "S구 ÷ S원 = 4": "S sphere ÷ S circle = 4",
  "귤껍질처럼 구의 표면을 벗겨 같은 반지름의 원 4개를 채우며 겉넓이를 비교합니다.":
    "Peel a sphere like an orange and fill four circles of the same radius to compare areas.",
  "벗겨진 껍질 조각이 원 4개에 나뉘어 모입니다.":
    "The peeled pieces collect in four circles.",
  "원 하나에는 구의 겉넓이의 4분의 1이 대응합니다.":
    "Each circle corresponds to one quarter of the sphere area.",
  "1. 구와 같은 반지름의 원 4개": "1. Four circles with the same radius",
  "2. 귤껍질처럼 표면 벗기기": "2. Peel the surface like an orange",
  "3. 껍질 조각으로 원 채우기": "3. Fill the circles with peel pieces",
  "4. 원 4개의 넓이와 비교하기": "4. Compare the area of four circles",
  "π 100,000자리 여행": "Journey through 100,000 digits of π",
  "한 자리씩": "One digit",
  "현재 자리로 이동": "Jump to digit",
  "자리수 직접 입력": "Enter digit position",
  "초당 이동하는 자리수": "Digits per second",
  "현재 자리": "Current position",
  "현재 숫자": "Current digit",
  진행률: "Progress",
  "숫자별 누적 횟수": "Cumulative digit counts",
  "0부터 9까지 숫자별 누적 횟수": "Cumulative counts for digits 0 to 9",
  "첫째 자리부터 하나씩 진행합니다. 원 위에는 최근 60자리, 막대에는 지금까지 나온 각 숫자의 횟수가 표시됩니다.":
    "Follow digits from the first position. The circle shows the latest 60 digits, and the bars count every digit seen so far.",
  "전체 자리수": "Total digits",
  현재까지: "Reached",
  "최근 나타난 숫자": "Recently revealed digits",
  "지금까지 나타난 소수점 아래 숫자": "Decimal digits revealed so far",
  "지금까지 나타난 원주율 숫자": "Digits of π revealed so far",
  "현재까지 복사": "Copy revealed digits",
  "복사할 숫자 없음": "No digits to copy",
  "지금까지 나타난 원주율 숫자를 복사했습니다.":
    "Copied the revealed digits of π.",
  "원주율 소수점 아래 첫째 자리부터 100,000번째 자리까지 순서대로 진행하는 숫자 경로":
    "A digit path progressing through π from the first to the 100,000th decimal digit",
  "첫째 자리에서 출발": "Start at the first digit",
  "첫 번째 숫자가 곧 나타납니다.": "The first digit is about to appear.",
  "다시 재생": "Play again",
  "나선 보기": "Spiral view",
  확대: "Zoom",
  "따라가기 켜짐": "Following current digit",
  "현재 자리 따라가기": "Follow current digit",
  "중심 보기": "View center",
  "나선 전체 보기": "View whole spiral",
  "3.에서 시작해 숫자가 하나씩 나타나며 바깥쪽으로 돌아갑니다. 붉은 숫자는 방금 나온 자리입니다. 그림을 끌거나 확대해 따라가 보세요.":
    "Starting at 3., each digit appears one by one along the outward spiral. Red marks the newest digits. Drag or zoom to follow along.",
  "지금 읽는 자리": "Current digit",
  "원주율 숫자가 중심에서 바깥쪽으로 이어지는 나선":
    "Digits of π forming an outward spiral",
};
for (let t of HS.LABS) t.en && ((C[t.title] = t.en.title), (C[t.desc] = t.en.desc));
Object.assign(C, {
  "평면좌표와 직선의 방정식": "Coordinates and Lines",
  "원의 방정식과 도형의 이동": "Circles and Transformations",
  "삼각함수의 활용": "Applications of Trigonometric Functions",
  "공간도형과 공간좌표": "Space Figures and Coordinates",
  "벡터의 활용": "Applications of Vectors",
  "여러 가지 미분법·적분법": "Techniques of Differentiation and Integration",
  "경우의 수": "Counting",
  "함수의 극한과 연속": "Limits and Continuity",
  "집합": "Sets",
  "환경과 수학": "Environment and Mathematics",
  "미분의 활용": "Applications of Derivatives",
  "수열의 극한": "Limits of Sequences",
  "미분법": "Differentiation",
  "도함수의 활용": "Applications of Derivatives",
  "적분법": "Integration",
  "사이트맵": "Site map",
  "실험 목록": "Experiments",
  "확률분포": "Probability Distributions",
  "통계적 추정": "Statistical Estimation",
  "곡선과 무늬": "Curves and Patterns",
  "프랙털과 무한": "Fractals and Infinity",
  "삼각형의 신비": "Wonders of the Triangle",
  "우연과 통계 실험": "Chance and Statistics Experiments",
  "데이터와 벡터": "Data and Vectors",
  "이미지와 행렬": "Images and Matrices",
  "예측과 최적화": "Prediction and Optimization",
  "예술과 수학": "Art and Mathematics",
  "생활과 수학": "Everyday Mathematics",
  "사회와 수학": "Society and Mathematics",
  "도형과 측정": "Geometry and Measurement",
  "자료와 가능성": "Data and Chance",
  "주황 고리가 있는 점은 끌어서 옮길 수 있어요": "Drag points with an orange ring",
  "점을 누른 뒤 방향키로도 움직입니다": "or select one and use the arrow keys",
  "그림을 끌면 공간을 돌려 볼 수 있어요": "Drag the figure to rotate the space",
  "움직이는 도형으로 배우는 중·고등 수학 실험실": "A studio of moving figures for secondary mathematics",
  "이어서 해 볼 실험": "Continue with",
  "먼저 해 보면 좋은 실험": "Try first",
});
Object.assign(C, EN_UI);
for (let k of Object.keys(C)) if (k.trim().length <= 1) delete C[k]; // 수식 사이의 조사 한 글자가 바뀌지 않게
var Y = /[가-힣]/,
  K = new RegExp(
    Object.keys(C)
      .sort((t, e) => e.length - t.length)
      .map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
      .join("|"),
    "g",
  ),
  x = new Map(),
  Q = Object.keys(C)
    .filter((t) => t.length > 25)
    .sort((t, e) => e.length - t.length),
  Z = {
    "동아출판(강) 교과서 활용": "Based on Dong-A Publishing (Kang) textbooks",
    "2022 개정 교육과정": "2022 Revised Curriculum",
    "학습 내용과 흐름 참고. 실험실은 교과서 본문·삽화를 재게시하지 않으며, 입체도형 수업 스튜디오에서만 교사 수업용으로 교과서 7단원 페이지를 함께 보여 줍니다.":
      "The learning topics and sequence reference the textbooks. The labs do not republish textbook text or illustrations; only the Solid Figures Classroom Studio shows Unit 7 textbook pages for the teacher's own lessons.",
    "도형 · 설명 · 인터랙티브 시각화 독자 제작":
      "Original diagrams, explanations, and interactive visualizations",
    "예측 3분 → 조작·검증 7분 → 이유 설명 5분. 변하는 양과 일정한 양을 구분해 말하게 합니다.":
      "Predict for 3 minutes → explore and verify for 7 minutes → explain for 5 minutes. Identify which quantities change and which remain constant.",
    "평행선, 작도, 회전체, 통계 검색":
      "Search parallel lines, constructions, solids, statistics",
    "계급 경계 · 이상 ~ 미만":
      "Class boundaries · lower inclusive, upper exclusive",
    "계급 (이상 ~ 미만)": "Class [lower, upper)",
    "최빈값: 없음 (모든 값이 한 번씩)": "Mode: none (each value occurs once)",
    "A는 관찰자의 눈, B는 같은 높이의 점, C는 건물 꼭대기입니다.":
      "A is the observer’s eye, B is at the same height, and C is the top of the building.",
  };
function A(t) {
  x.size > 5e3 && x.clear();
  let e = String(t);
  if (!Y.test(e)) return e;
  if (x.has(e)) return x.get(e);
  let i = A1(e);
  return x.set(e, i), i;
}
// 영어 번역: ① 문장 전체가 사전에 있으면 그대로 ② 틀 규칙 ③ " · " 등으로 나뉜 글은 조각마다 ④ 없으면 한국어 그대로
function A1(e) {
  let k = e.trim();
  if (!k) return e;
  let L = ENL && ENCUR && ENL.TXL[ENCUR];
  if (L) {
    if (L.ex[k]) return e.replace(k, L.ex[k]);
    for (let [re, v] of L.pats) { let m = k.match(re); if (m) return e.replace(k, v.replace(/\$(\d)/g, (_, i) => (m[i] ? A2(m[i]) : ""))); }
  }
  if (C[k]) return e.replace(k, C[k]);
  for (let [re, f] of EN_PAT) { let m = k.match(re); if (m) { let r = f(m, A2); if (r != null) return e.replace(k, r); } }
  for (let sep of [" · ", " — ", " / ", " | ", ", ", ": ", "  "]) if (k.includes(sep)) { let parts = k.split(sep), tr = parts.map(A2); if (tr.every((p, j) => p !== parts[j] || !Y.test(p))) return e.replace(k, tr.join(sep)); }
  let z = k; for (let [a, l] of Object.entries(Z)) z = z.replaceAll(a, l);
  if (z !== k && !Y.test(z)) return e.replace(k, z);
  return e;
}
function A2(p) { let r = A1(p); return r; }
function F(t = document) {
  let e = "ko",
    i = new WeakMap(),
    a = new WeakMap(),
    l = new WeakMap(),
    s = new t.defaultView.MutationObserver((n) => {
      s.disconnect();
      for (let r of n)
        if (r.type === "characterData") c(r.target);
        else if (r.type === "attributes") o(r.target);
        else for (let b of r.addedNodes) c(b);
      m();
    });
  function u(n) {
    return n.parentElement?.closest(
      'script,style,textarea,[translate="no"],[data-user-content]',
    );
  }
  function p(n, r) {
    return !r || n !== r.applied ? { original: n, applied: n } : r;
  }
  function o(n) {
    if (n.closest?.('[translate="no"],[data-user-content]')) return;
    let r = a.get(n);
    r || ((r = {}), a.set(n, r));
    for (let b of ["aria-label", "title", "placeholder", "alt"]) {
      if (
        !n.hasAttribute(b) ||
        (b === "aria-label" && n.hasAttribute("data-user-label"))
      )
        continue;
      let S = p(n.getAttribute(b), r[b]);
      ((r[b] = S),
        (S.applied = e === "en" ? A(S.original) : S.original),
        n.getAttribute(b) !== S.applied && n.setAttribute(b, S.applied));
    }
  }
  function c(n) {
    if (n.nodeType === 3) {
      if (u(n)) return;
      let r = p(n.data, i.get(n));
      (i.set(n, r),
        (r.applied = e === "en" ? A(r.original) : r.original),
        n.data !== r.applied && (n.data = r.applied));
      return;
    }
    if (
      !(n.nodeType !== 1 && n.nodeType !== 9) &&
      !n.matches?.('script,style,[translate="no"],[data-user-content]') &&
      (n.nodeType === 1 && o(n), !n.matches?.("textarea"))
    ) {
      if (n.matches?.("input[data-i18n-value]")) {
        let r = p(n.value, l.get(n));
        (l.set(n, r),
          (r.applied = e === "en" ? A(r.original) : r.original),
          (n.value = r.applied));
      }
      for (let r of n.childNodes) c(r);
    }
  }
  function m() {
    s.observe(t.documentElement, {
      subtree: !0,
      childList: !0,
      characterData: !0,
      attributes: !0,
      attributeFilter: ["aria-label", "title", "placeholder", "alt"],
    });
  }
  function f() {
    (s.disconnect(),
      c(t.documentElement),
      (t.documentElement.lang = e),
      t
        .querySelectorAll("[data-language]")
        .forEach((n) =>
          n.setAttribute("aria-pressed", String(n.dataset.language === e)),
        ),
      m());
  }
  function w(n) {
    ((e = n === "en" ? "en" : "ko"), f());
  }
  return (
    t.addEventListener(
      "input",
      (n) => {
        n.target.matches?.("input[data-i18n-value]") &&
          n.target.removeAttribute("data-i18n-value");
      },
      !0,
    ),
    t.addEventListener("click", (n) => {
      let r = n.target.closest("[data-language]");
      r && w(r.dataset.language);
    }),
    f(),
    {
      get language() {
        return e;
      },
      setLanguage: w,
      refresh: f,
      destroy() {
        s.disconnect();
      },
    }
  );
}
// 영어판 실험 자료: EN을 처음 누를 때 불러와 실험 본문을 바꿔 끼운다
var ENL = null;
async function ensureEN() {
  if (ENL) return;
  ENL = await import("./lab-chunks/en-labs.js");
  HS.setEN(ENL.EN, (v) => A(v));
  for (const [k, v] of Object.entries(ENL.TX)) if (!(k in C)) C[k] = v; // 사이트 틀 번역은 실험 사전이 덮어쓰지 않게
  // 목록·사이트맵·이전/다음 실험 이름에도 쓰이도록 모든 실험의 제목과 설명을 사전에 올린다
  for (const t of g) { const e = ENL.EN[t.id]; if (!e) continue; if (e.t && !(t.title in C)) C[t.title] = e.t; if (e.d && t.desc && !(t.desc in C)) C[t.desc] = e.d; }
  x.clear();
}
// 지금 열린 실험: 그 실험 전용 사전을 먼저 쓴다 (실험이 바뀌면 번역 기억을 비움)
var ENCUR = null;
function setCur(t) { let id = t?.id ?? null; if (id !== ENCUR) { ENCUR = id; x.clear(); } return t; }
var LI = (t) => (t && ENL && H.language === "en" ? HS.loc(t) : t);
// 학습지에 담을 실험과 정보: 영어 모드면 제목·설명·조작 항목·예측 문항·과정 이름을 영어로 담는다
function SHM(lab, extra = {}) {
  const en = H.language === "en" && ENL, L0 = en ? { ...LI(lab), lesson: A(lab.lesson || ""), time: A(lab.time || "") } : lab, tr = (s) => (en ? A(s) : s), bank = lab.module !== "hs" && HS.bankFor(lab.id);
  return [L0, { course: tr(COURSES[lab.grade]?.name || ""), unit: tr(`${unitLabel(lab.grade, lab.unit)} ${unitName(lab.grade, lab.unit)}`.trim()), spec: lab.module === "hs" ? (HS.specOf(lab.id) ? (en ? LI(HS.specOf(lab.id)) : HS.specOf(lab.id)) : null) : null,
    pred: en && bank ? LI({ id: lab.id, predict: bank }).predict : null,
    prep: en ? () => { setCur(lab); H.refresh(); } : null, ...extra }]; // prep: 그림·측정값을 그 실험의 사전으로 번역
}
document.addEventListener("click", (ev) => { const b = ev.target.closest("[data-language]"); if (!b) return; (b.dataset.language === "en" ? ensureEN() : Promise.resolve()).then(() => $()); });
var H = F(),
  d = (t) => document.querySelector(t);
function U(t, e) {
  try {
    return JSON.parse(localStorage.getItem(t)) ?? e;
  } catch {
    return e;
  }
}
function W(t, e) {
  try {
    localStorage.setItem(t, JSON.stringify(e));
  } catch {}
}
var h = Number(U("lab-grade", 1)) || 1,
  y = U("math-lab-favs", []),
  D = "all",
  E = "",
  k = null,
  V = 0,
  R = null,
  v = !1,
  heroRaf = 0;
GRADES.includes(h) || (h = 1);
var IC = {"search":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><circle cx=\"9\" cy=\"9\" r=\"6\"/><path d=\"M14 14l4 4\"/></svg>","left":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M12 4l-6 6 6 6\"/></svg>","right":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M8 4l6 6-6 6\"/></svg>","down":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M5 8l5 5 5-5\"/></svg>","reset":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M4 10a6 6 0 1 0 2-4.5M4 3v4h4\"/></svg>","link":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M8 12l4-4M7 9l-2 2a3 3 0 0 0 4 4l2-2M13 11l2-2a3 3 0 0 0-4-4l-2 2\"/></svg>","img":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><rect x=\"3\" y=\"4\" width=\"14\" height=\"12\" rx=\"1.5\"/><path d=\"M3 13l4-4 3 3 2-2 5 5\"/></svg>","sheet":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M5 3h10v14l-5-3-5 3z\"/></svg>","present":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><rect x=\"2\" y=\"4\" width=\"16\" height=\"10\" rx=\"1\"/><path d=\"M7 18h6M10 14v4\"/></svg>","grid":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><rect x=\"3\" y=\"3\" width=\"6\" height=\"6\"/><rect x=\"11\" y=\"3\" width=\"6\" height=\"6\"/><rect x=\"3\" y=\"11\" width=\"6\" height=\"6\"/><rect x=\"11\" y=\"11\" width=\"6\" height=\"6\"/></svg>","list":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M3 5h14M3 10h14M3 15h14\"/></svg>","home":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M3 9l7-6 7 6v8H3z\"/></svg>","star":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M10 2.5l2.3 4.9 5.2.6-3.9 3.6 1.1 5.2L10 14.2l-4.7 2.6 1.1-5.2L2.5 8l5.2-.6z\"/></svg>","guide":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M3 4.5c2.5-1 4.8-1 7 .6 2.2-1.6 4.5-1.6 7-.6V16c-2.5-1-4.8-1-7 .6-2.2-1.6-4.5-1.6-7-.6zM10 5.1v11.5\"/></svg>","moon":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M16 12.5A6.5 6.5 0 0 1 7.5 4a6.5 6.5 0 1 0 8.5 8.5z\"/></svg>","sun":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><circle cx=\"10\" cy=\"10\" r=\"3.5\"/><path d=\"M10 2v2M10 16v2M2 10h2M16 10h2M4.3 4.3l1.4 1.4M14.3 14.3l1.4 1.4M4.3 15.7l1.4-1.4M14.3 5.7l1.4-1.4\"/></svg>","course":"<svg class=\"ic\" viewBox=\"0 0 20 20\" aria-hidden=\"true\"><path d=\"M4 4h12v12H4zM4 9h12M9 4v12\"/></svg>"},
  CU = 0,
  SORT = U("mckay-sort", "lesson"),
  VIEW = U("mckay-view", "grid"),
  VIS = U("mckay-visited", []);
Array.isArray(VIS) || (VIS = []);
try {
  let saved = localStorage.getItem("mckay-theme"),
    host = document.documentElement.dataset.theme;
  v = saved ? saved === "dark" : host ? host === "dark" : !!window.matchMedia?.("(prefers-color-scheme: dark)").matches;
} catch {
  v = !!window.matchMedia?.("(prefers-color-scheme: dark)").matches;
}
Array.isArray(y) || (y = []);
document.documentElement.dataset.theme = v ? "dark" : "light";
document.body.classList.add("at");
var TITLE = "McKay Math Atelier",
  ROMAN = ["", "Ⅰ", "Ⅱ", "Ⅲ", "Ⅳ", "Ⅴ", "Ⅵ", "Ⅶ", "Ⅷ"],
  unitLabel = (gr, u) => (gr>=21&&u===0 ? "전체" : gr <= 3 ? `${u}단원` : gr === 9 || gr >= 15 ? `주제 ${u}` : gr === 12 ? `${ROMAN[u]}단원` : gr === 11 ? `${ROMAN[u]}단원` : gr === 10 ? `${ROMAN[u + 1]}단원` : `${ROMAN[u]}단원`),
  unitName = (gr, u) => (M[gr].find(([o]) => o === u) || [0, ""])[1],
  byId = Object.fromEntries(g.map((t) => [t.id, t])),
  thumbCache = new Map();
function j() {
  let [t, e = ""] = location.hash.replace(/^#\/?/, "").split("?");
  return { parts: t.split("/"), query: new URLSearchParams(e) };
}
function T(t) {
  d("#lab-status").textContent = t;
}
// 중학교 실험 카드용 도안(단원별)
var GLYPH = {
  "1-5": `<line x1="120" y1="360" x2="520" y2="80" stroke="var(--pl-b)" stroke-width="7"/><line x1="110" y1="110" x2="530" y2="330" stroke="var(--pl-a)" stroke-width="7"/><path d="M372 184 A60 60 0 0 1 380 250" fill="none" stroke="var(--pl-ink)" stroke-width="5"/><path d="M268 257 A60 60 0 0 1 262 190" fill="none" stroke="var(--pl-ink)" stroke-width="5"/>`,
  "1-6": `<polygon points="320,70 470,160 440,330 200,330 170,160" fill="var(--pl-a)" fill-opacity=".14" stroke="var(--pl-a)" stroke-width="6"/><circle cx="320" cy="215" r="165" fill="none" stroke="var(--pl-b)" stroke-width="4" stroke-dasharray="10 10"/><line x1="320" y1="70" x2="440" y2="330" stroke="var(--pl-muted)" stroke-width="3"/><line x1="320" y1="70" x2="200" y2="330" stroke="var(--pl-muted)" stroke-width="3"/>`,
  "1-7": `<polygon points="210,150 360,110 470,160 320,200" fill="var(--pl-c)" fill-opacity=".22" stroke="var(--pl-c)" stroke-width="5"/><polygon points="210,150 320,200 320,360 210,310" fill="var(--pl-c)" fill-opacity=".12" stroke="var(--pl-c)" stroke-width="5"/><polygon points="320,200 470,160 470,320 320,360" fill="var(--pl-c)" fill-opacity=".3" stroke="var(--pl-c)" stroke-width="5"/><line x1="360" y1="110" x2="360" y2="270" stroke="var(--pl-c)" stroke-width="3" stroke-dasharray="8 8"/>`,
  "1-8": `<g fill="var(--pl-a)" fill-opacity=".3" stroke="var(--pl-a)" stroke-width="4"><rect x="130" y="260" width="70" height="100"/><rect x="200" y="170" width="70" height="190"/><rect x="270" y="110" width="70" height="250"/><rect x="340" y="190" width="70" height="170"/><rect x="410" y="280" width="70" height="80"/></g><polyline points="95,360 165,260 235,170 305,110 375,190 445,280 515,360" fill="none" stroke="var(--pl-b)" stroke-width="5"/>`,
  "2-5": `<polygon points="330,80 150,340 500,320" fill="var(--pl-b)" fill-opacity=".12" stroke="var(--pl-ink)" stroke-width="5"/><circle cx="330" cy="248" r="170" fill="none" stroke="var(--pl-b)" stroke-width="5"/><circle cx="330" cy="248" r="8" fill="var(--pl-a)"/>`,
  "2-6": `<polygon points="200,320 470,320 540,120 270,120" fill="var(--pl-b)" fill-opacity=".14" stroke="var(--pl-b)" stroke-width="6"/><line x1="200" y1="320" x2="540" y2="120" stroke="var(--pl-a)" stroke-width="4"/><line x1="470" y1="320" x2="270" y2="120" stroke="var(--pl-a)" stroke-width="4"/><circle cx="370" cy="220" r="8" fill="var(--pl-ink)"/>`,
  "2-7": `<polygon points="150,360 330,90 520,360" fill="var(--pl-c)" fill-opacity=".1" stroke="var(--pl-c)" stroke-width="6"/><polygon points="240,225 330,90 425,225" fill="var(--pl-c)" fill-opacity=".22" stroke="var(--pl-c)" stroke-width="4"/><line x1="240" y1="225" x2="425" y2="225" stroke="var(--pl-a)" stroke-width="6"/>`,
  "2-8": `<g fill="var(--pl-paper)" stroke="var(--pl-d)" stroke-width="5"><rect x="150" y="120" width="150" height="150" rx="24"/><rect x="340" y="170" width="150" height="150" rx="24"/></g><g fill="var(--pl-d)"><circle cx="190" cy="160" r="12"/><circle cx="225" cy="195" r="12"/><circle cx="260" cy="230" r="12"/><circle cx="380" cy="210" r="12"/><circle cx="450" cy="210" r="12"/><circle cx="380" cy="280" r="12"/><circle cx="450" cy="280" r="12"/></g>`,
  "3-5": `<polygon points="140,340 500,340 500,110" fill="var(--pl-a)" fill-opacity=".12" stroke="var(--pl-ink)" stroke-width="5"/><path d="M220 340 A80 80 0 0 0 207 297" fill="none" stroke="var(--pl-a)" stroke-width="6"/><polyline points="470,340 470,310 500,310" fill="none" stroke="var(--pl-ink)" stroke-width="3"/><line x1="500" y1="340" x2="500" y2="110" stroke="var(--pl-b)" stroke-width="7"/>`,
  "3-6": `<circle cx="320" cy="220" r="160" fill="var(--pl-b)" fill-opacity=".06" stroke="var(--pl-b)" stroke-width="5"/><polyline points="190,313 250,78 450,313" fill="none" stroke="var(--pl-a)" stroke-width="5"/><polyline points="190,313 320,220 450,313" fill="none" stroke="var(--pl-c)" stroke-width="5"/><circle cx="320" cy="220" r="7" fill="var(--pl-ink)"/>`,
  "3-7": `<line x1="110" y1="370" x2="540" y2="370" stroke="var(--pl-axis)" stroke-width="3"/><line x1="110" y1="370" x2="110" y2="70" stroke="var(--pl-axis)" stroke-width="3"/><g fill="var(--pl-d)">${[[150, 330], [190, 300], [215, 318], [250, 270], [280, 250], [300, 275], [340, 210], [370, 225], [400, 170], [430, 180], [460, 130], [500, 110]].map(([x, y]) => `<circle cx="${x}" cy="${y}" r="10" fill-opacity=".75"/>`).join("")}</g><line x1="130" y1="345" x2="520" y2="105" stroke="var(--pl-b)" stroke-width="4" stroke-dasharray="12 8"/>`,
};
function glyph(t) {
  let body = MID_GLYPHS[t.id] || GLYPH[`${t.grade}-${t.unit}`] || GLYPH["1-5"];
  return `<svg viewBox="0 0 640 440" xmlns="http://www.w3.org/2000/svg"><rect width="640" height="440" fill="var(--pl-paper)"/><g stroke="var(--pl-grid)" stroke-width="1">${Array.from({ length: 15 }, (e, i) => `<line x1="${i * 46}" y1="0" x2="${i * 46}" y2="440"/>`).join("")}${Array.from({ length: 10 }, (e, i) => `<line x1="0" y1="${i * 46}" x2="640" y2="${i * 46}"/>`).join("")}</g>${body}</svg>`;
}
function elementaryHighlights(gr){const labs=g.filter(l=>l.grade===gr),first=[...new Set(labs.map(l=>l.unit))].map(u=>labs.find(l=>l.unit===u));return [...first,...labs.filter(l=>!first.includes(l))].slice(0,6);}
function thumbOf(t) {
  if(t.module === "advanced-math") return `<svg viewBox="0 0 760 450"><image href="advanced-math/thumbs/${t.id.replace("advanced-", "")}.svg" width="760" height="450"/></svg>`;
  if(t.module==='elementary')return elementaryScene(t.id,elementaryState(t.id,{}));
  if(t.module==='wave-frontiers')return frontierThumbnail(frontierState(t.view,{u:.65}));
  if (t.module === 'circle-waves' && t.view) return waveThumbnail({view:t.view,angle:t.view==='beats'?3600:t.view==='damped'?1080:t.view==='sum'?720:360,a:1,b:1,phase:0,d:0,terms:5,shape:'square',decay:.15,waveK:2,probe:.125,direction:1,nodes:true,components:true,guides:false,ribbon:true});
  if (t.module === 'circle-waves') return `<svg viewBox="0 0 900 550"><rect width="900" height="550" fill="#faf7ef"/><circle cx="185" cy="270" r="105" fill="none" stroke="#263d5b" stroke-width="5"/><path d="M185 270L253 190L253 270Z" fill="#6255c71a" stroke="#6255c7" stroke-width="5"/><path d="M330 220C405 70 480 70 555 220S705 370 780 220" fill="none" stroke="#6255c7" stroke-width="8"/><path d="M330 320C405 320 405 470 480 470S555 170 630 170S705 470 780 470" fill="none" stroke="#c55337" stroke-width="7"/><path d="M253 190L330 220M253 270L330 320" fill="none" stroke="#263d5b" stroke-width="2" stroke-dasharray="6 9"/><text x="45" y="65" fill="#263d5b" font-size="29">CIRCLE → WAVES</text></svg>`;
  if (t.module === "hs" && !thumbCache.has(t.id)) { const svg = HS.thumb(t.id); if (!svg) return HS.thumbHolder(t.id); thumbCache.set(t.id, svg); }
  if (!thumbCache.has(t.id)) thumbCache.set(t.id, t.module === "atelier-plus" ? `<svg viewBox="0 0 900 550"><image href="atelier-plus/thumbs/${t.id}.svg" width="900" height="550"/></svg>` : t.module === "cube" ? CUBE_THUMB : t.module === "hs" ? HS.thumb(t.id) : glyph(t));
  return thumbCache.get(t.id);
}
function X() {
  return `<footer class="at-footer"><div><strong translate="no">McKay Math Atelier</strong><p>초등학교 1학년부터 6학년까지의 기초 탐구 | 2022 개정 중고등 교육과정 · 중학교 수학 1·2·3 · 고등학교 공통수학1·2 · 대수 · 기하 · 미적분Ⅰ·Ⅱ · 확률과 통계 · 인공지능 수학 · 수학과 문화 · 직무 수학 · 수학실험실</p></div><div><p><strong>동아출판(강) 교과서 활용</strong> — 학습 내용과 흐름 참고. 실험실은 교과서 본문·삽화를 재게시하지 않으며, 입체도형 수업 스튜디오에서만 교사 수업용으로 교과서 7단원 페이지를 함께 보여 줍니다.</p><p>도형 · 설명 · 인터랙티브 시각화 독자 제작 · McKay · Mathematics &amp; Education</p><a class="at-install at-news" href="updates/">업데이트 소식</a> <button type="button" class="at-install" data-install ${window.atInstall ? "" : "hidden"}>앱으로 설치하기 — 홈 화면에 추가하고 인터넷 없이도 열기</button> <button type="button" class="at-install" data-offline-all hidden>인터넷 없이 쓰도록 모두 받아 두기</button></div></footer>`;
}
function _() {
  let r0 = j().parts[0] || "dashboard", cur = (b) => (b ? ' aria-current="page"' : "");
  return `<header class="at-header v3-head"><div class="at-header-inner"><a class="at-brand" href="#/dashboard" aria-label="${TITLE} 처음으로"><svg class="at-mark" viewBox="0 0 40 40" aria-hidden="true"><rect width="40" height="40" rx="11" fill="var(--at-ink)"/><ellipse cx="20" cy="21" rx="13" ry="8" fill="none" stroke="var(--at-bg)" stroke-width="2"/><circle cx="12" cy="21" r="2.4" fill="var(--at-brass)"/><circle cx="28" cy="21" r="2.4" fill="var(--at-brass)"/><path d="M12 21 L22 13.3 L28 21" fill="none" stroke="var(--at-brass)" stroke-width="1.6"/></svg><span class="at-word" translate="no">McKay <em>Math Atelier</em></span></a><button class="v3-hsearch" type="button" data-action="find" aria-label="전체 실험 찾기 (Ctrl+K)">${IC.search}<span>실험·개념·단원 검색</span><kbd>Ctrl K</kbd></button><nav class="at-nav" aria-label="바로가기"><a href="#/dashboard"${cur(r0 === "dashboard")}>${IC.home}<span class="nv-t">처음</span><small class="nv-d">첫 화면</small></a><a href="#/list?grade=${h}"${cur((r0 === "list" || r0 === "lab") && ![15,16,17].includes(h))}>${IC.course}<span class="nv-t">과정</span><small class="nv-d">${COURSES[h]?.name || "단원 목차"}</small></a><a href="#/special"${cur(r0 === "special" || ((r0 === "list" || r0 === "lab") && [15,16,17].includes(h)))}>${IC.star}<span class="nv-t">특별관</span><small class="nv-d">역설 · 역사 · 퍼즐</small></a><a href="#/sheet"${cur(r0 === "sheet")}>${IC.sheet}<span class="nv-t">학습지</span><span class="at-sheet-n">${SH.count() || ""}</span><small class="nv-d">모아서 인쇄하기</small></a><a href="#/guide"${cur(r0 === "guide")}>${IC.guide}<span class="nv-t">사용설명서</span><small class="nv-d">쓰는 법 안내</small></a></nav><button class="at-menu" type="button" data-action="menu" aria-expanded="false" aria-controls="at-drawer" aria-label="메뉴 열기"><span></span><span></span><span></span></button><div class="at-tools" id="at-drawer"><button class="at-find v3-find-m" type="button" data-action="find" aria-label="전체 실험 찾기">${IC.search}<span class="at-find-t">실험·개념·단원 찾기</span></button><span class="nv-set">화면</span><div class="language-switch" role="group" aria-label="언어 선택"><button type="button" data-language="ko" translate="no" aria-pressed="${H.language === "ko"}" lang="ko">한국어</button><button type="button" data-language="en" translate="no" aria-pressed="${H.language === "en"}" lang="en">EN</button></div><button class="at-theme" type="button" data-action="theme" aria-label="${v ? "밝은 화면으로" : "어두운 화면으로"}" title="${v ? "밝은 화면으로" : "어두운 화면으로"}">${v ? IC.sun : IC.moon}<span>${v ? "라이트" : "다크"}</span></button></div></div></header>`;
}
function ee(t) {
  t = LI(t);
  let fav = y.includes(t.id), seen = VIS.includes(t.id), np = t.npred ?? (t.predict || HS.bankFor(t.id) || []).length;
  return `<article class="v3-card" style="--c:${t.color}"><div class="v3-thumb" aria-hidden="true">${thumbOf(t)}${seen ? '<span class="v3-seen">해 봄</span>' : ""}</div><button type="button" data-fav="${t.id}" class="v3-fav" aria-label="${q(t.title)} 즐겨찾기" aria-pressed="${fav}">${fav ? "★" : "☆"}</button><div class="v3-card-body"><span class="v3-meta">${t.lesson} · ${t.type} · ${t.time}</span><h2><a href="#/lab/${t.id}">${t.title}</a></h2><p>${t.desc}</p><span class="v3-sub">${np ? `${t.module === "elementary" ? "탐구 도전" : "예측"} ${np}${t.module === "elementary" ? "개" : "문항"}` : ""}${np && CK.predOk(t.id) ? `<b class="v3-ok" title="맞힌 예측 문항">✓ ${Math.min(CK.predOk(t.id), np)}/${np}</b>` : ""}${t.tags.slice(0, 2).map((x) => `<i>${x}</i>`).join("")}</span></div></article>`;
}
// 첫 화면: 최근 연 실험과 즐겨찾기
function resumeHTML() {
  let rc = [];
  try { rc = JSON.parse(localStorage.getItem("mckay-recent") || "[]"); } catch {}
  let row = (ids, title) => { let L = ids.map((i) => byId[i]).filter(Boolean).slice(0, 6); return L.length ? `<section class="at-resume-row"><h2>${title}</h2><div class="at-resume-list">${L.map((t) => `<a class="at-resume" href="#/lab/${t.id}" style="--c:${t.color}"><span class="at-resume-thumb" aria-hidden="true">${thumbOf(t)}</span><span><small>${GL(t.grade)} · ${t.lesson}</small><b>${t.title}</b></span></a>`).join("")}</div></section>` : ""; };
  let html = row(rc, "이어서 하기") + row(y.filter((i) => !rc.slice(0, 6).includes(i)), "즐겨찾기");
  return html ? `<div class="at-resume-wrap">${html}</div>` : "";
}
var lessonCmp = (a, b) => String(a).localeCompare(String(b), "ko", { numeric: true }),
  lessonBase = (l) => String(l).split(/\s/)[0].replace(/^III(?![A-Za-z])/, "Ⅲ").replace(/^II(?![A-Za-z])/, "Ⅱ").replace(/^I(?![A-Za-z])/, "Ⅰ");
function P() {
  let les = j().query.get("lesson") || "", w = E.trim().toLowerCase();
  let e = g.filter((i) => i.grade === h && (w ? KS.hit(KS.norm(w), KS.prep([i.title, i.desc, ...i.tags, A(i.title), ...i.tags.map(A), LI(i).title, LI(i).desc].join(" ")), false) > 0 : (h>=21&&CU===0||i.unit === CU) && (!les || lessonBase(i.lesson) === les)) && (D === "all" || (D === "fav" && y.includes(i.id)) || D === i.type));
  if (SORT === "short") e = e.slice().sort((a, b) => parseInt(a.time) - parseInt(b.time));
  else if (SORT === "long") e = e.slice().sort((a, b) => parseInt(b.time) - parseInt(a.time));
  else e = e.slice().sort((a, b) => (a.unit - b.unit) || lessonCmp(a.lesson, b.lesson));
  let box = d("#lab-results");
  if (!box) return;
  box.innerHTML = e.length ? e.map(ee).join("") : '<p class="empty">조건에 맞는 실험이 없습니다. 검색어를 지우거나 필터를 ‘전체’로 바꿔 보세요.</p>';
  d("#count") && (d("#count").textContent = w ? `‘${E}’ 검색 결과 ${e.length}개 (과정 전체)` : `${e.length}개`);
}
// 첫 화면 그림 — 실로 그리는 타원(두 초점까지 거리의 합이 일정)
function hero() {
  cancelAnimationFrame(heroRaf);
  let svg = d("#hero-svg"),
    cap = d("#hero-cap");
  if (!svg) return;
  let a = 190, c = 118, b = Math.sqrt(a * a - c * c), cx = 260, cy = 196,
    reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches,
    t0 = performance.now(),
    grid = "";
  for (let x = 20; x < 520; x += 40) grid += `<line x1="${x}" y1="0" x2="${x}" y2="392" />`;
  for (let yy = 16; yy < 392; yy += 40) grid += `<line x1="0" y1="${yy}" x2="520" y2="${yy}" />`;
  function frame(now) {
    if (!svg.isConnected) return;
    let T = reduce ? Math.PI * 2 * 0.72 : (((now - t0) / 1000) * 0.55) % (Math.PI * 2 + 1.4),
      th = Math.min(T, Math.PI * 2),
      P = [cx + a * Math.cos(th), cy - b * Math.sin(th)],
      pts = [];
    for (let i = 0; i <= 120; i++) {
      let u = (th * i) / 120;
      pts.push(`${(cx + a * Math.cos(u)).toFixed(1)},${(cy - b * Math.sin(u)).toFixed(1)}`);
    }
    let F1 = [cx - c, cy], F2 = [cx + c, cy],
      d1 = Math.hypot(P[0] - F1[0], P[1] - F1[1]), d2 = Math.hypot(P[0] - F2[0], P[1] - F2[1]);
    svg.innerHTML = `<g class="hero-grid">${grid}</g><ellipse cx="${cx}" cy="${cy}" rx="${a}" ry="${b}" class="hero-ghost"/><line x1="${cx - a - 20}" y1="${cy}" x2="${cx + a + 20}" y2="${cy}" class="hero-axis"/><polyline points="${pts.join(" ")}" class="hero-curve"/><line x1="${F1[0]}" y1="${F1[1]}" x2="${P[0].toFixed(1)}" y2="${P[1].toFixed(1)}" class="hero-string s1"/><line x1="${F2[0]}" y1="${F2[1]}" x2="${P[0].toFixed(1)}" y2="${P[1].toFixed(1)}" class="hero-string s2"/><circle cx="${F1[0]}" cy="${F1[1]}" r="6" class="hero-focus"/><circle cx="${F2[0]}" cy="${F2[1]}" r="6" class="hero-focus"/><text x="${F1[0]}" y="${F1[1] + 26}" class="hero-label">F′</text><text x="${F2[0]}" y="${F2[1] + 26}" class="hero-label">F</text><circle cx="${P[0].toFixed(1)}" cy="${P[1].toFixed(1)}" r="8" class="hero-pen"/><text x="${(P[0] + 14).toFixed(1)}" y="${(P[1] - 12).toFixed(1)}" class="hero-label">P</text>`;
    cap.innerHTML = `PF′ ${(d2 / 38).toFixed(2)} + PF ${(d1 / 38).toFixed(2)} = <b>${((d1 + d2) / 38).toFixed(2)}</b>`;
    reduce || (heroRaf = requestAnimationFrame(frame));
  }
  frame(performance.now());
}
var TAGN = null;
function similarOf(a) {
  // ‘중3’, ‘조작’처럼 실험 30개 넘게 쓰는 흔한 주제어는 비교하지 않는다
  if (!TAGN) { TAGN = {}; for (const o of g) for (const x of o.tags || []) TAGN[x] = (TAGN[x] || 0) + 1; }
  // 학년·실험 종류·과목 이름은 주제가 아니므로 뺀다
  const STOP = /^(중[123]|고[123]|조작|데이터|2D|3D|기하|대수|통계|확률|함수|도형|수와 연산|실생활|탐구|CSV)$/;
  const tg = new Set((a.tags || []).filter((x) => TAGN[x] <= 30 && !STOP.test(x))), words = new Set(String(a.title).split(/[\s—·,()]+/).filter((w) => w.length >= 2));
  return g.filter((o) => o.id !== a.id && byId[o.id])
    .map((o) => [o, 3 * (o.tags || []).filter((x) => tg.has(x)).length + String(o.title).split(/[\s—·,()]+/).filter((w) => words.has(w)).length + (o.grade === a.grade ? 2 : 0) + (o.grade === a.grade && o.unit === a.unit ? 2 : 0)])
    .filter(([o, sc]) => { const k = (o.tags || []).filter((x) => tg.has(x)).length; return sc >= 4 && tg.size && k >= 1 && ((o.grade === a.grade && o.unit === a.unit) || k >= 2); })
    .sort((x, y) => y[1] - x[1]).slice(0, 4).map(([o]) => o.id);
}
function linksOf(a) {
  let ids = [...new Set([...(a.links || []), ...(NEXT[a.id] || [])])].filter((i) => byId[i] && i !== a.id),
    before = ids.filter((i) => byId[i].grade < a.grade),
    after = ids.filter((i) => byId[i].grade >= a.grade),
    chip = (i) => `<a class="at-link-chip" style="--c:${byId[i].color}" href="#/lab/${i}"><small>${GL(byId[i].grade)} · ${byId[i].lesson}</small><b>${byId[i].title}</b></a>`;
  if (!ids.length) {
    // 연결이 하나도 없으면 주제(태그)가 겹치고 같은 과정·단원인 실험을 골라 보여 준다
    let auto = similarOf(a), head = "비슷한 주제의 실험";
    if (!auto.length) { // 주제어로 못 찾으면 같은 단원의 다른 실험(차시가 가까운 순)
      const sib = g.filter((o) => o.grade === a.grade && o.unit === a.unit && o.id !== a.id && byId[o.id]), me = g.indexOf(byId[a.id] || a);
      auto = sib.sort((x, y) => Math.abs(g.indexOf(x) - me) - Math.abs(g.indexOf(y) - me)).slice(0, 4).map((o) => o.id); head = "같은 단원의 다른 실험";
    }
    return auto.length ? `<section class="at-links"><div><h2>${head}</h2><div class="at-link-row">${auto.map(chip).join("")}</div></div></section>` : "";
  }
  return `<section class="at-links">${before.length ? `<div><h2>먼저 해 보면 좋은 실험</h2><div class="at-link-row">${before.map(chip).join("")}</div></div>` : ""}${after.length ? `<div><h2>이어서 해 볼 실험</h2><div class="at-link-row">${after.map(chip).join("")}</div></div>` : ""}</section>`;
}
async function $() {
  let t = ++V;
  STUDENT_LAB?.destroy(); STUDENT_LAB = null;
  STUDY_TOOLS?.destroy(); STUDY_TOOLS = null;
  (R?.abort(),
    (R = new AbortController()),
    k?.destroy?.(),
    (k = null),
    cancelAnimationFrame(heroRaf),
    document.body.classList.remove("presentation"));
  let { parts: e, query: i } = j(),
    a = LI(setCur(g.find((o) => o.id === e[1]))),
    l = Number(i.get("grade")),
    s = h;
  ((h = a?.grade || (GRADES.includes(l) ? l : h)),
    s !== h && ((D = "all"), (E = "")),
    GRADES.includes(h) || (h = 1),
    W("lab-grade", h));
  if(e[0] === "lab" && a?.module === "advanced-math") { location.replace("advanced-math/#" + a.id.replace("advanced-", "")); return; }
  // Old shared links can carry a different wave view from their original route.
  if (a?.module === 'circle-waves') {
    try {
      const saved = JSON.parse(i.get('s') || '{}');
      if (saved?.view) {
        const current = g.find(o => o.id === routeForState(saved));
        if (current && current.id !== a.id) {
          a = LI(setCur(current));
          history.replaceState(null, '', '#/lab/' + a.id + '?s=' + encodeURIComponent(JSON.stringify(saved)));
        }
      }
    } catch {}
  }
  let c = COURSES[h],
    unit = Number(i.get("unit")) || 0;
  d("#lab-app").innerHTML = _() + `<main id="main" class="at-main v3" style="--course:${c.color}">${readingHTML()}<div id="content"></div>${X()}<div id="lab-status" role="status" aria-live="polite"></div></main><nav class="v3-bottom" aria-label="아래 메뉴"><a href="#/dashboard"${(e[0] || "dashboard") === "dashboard" ? ' aria-current="page"' : ""}>${IC.home}<span>처음</span></a><a href="#/list?grade=${![15,16,17].includes(h) ? h : 1}"${(e[0] === "list" || e[0] === "lab") && ![15,16,17].includes(h) ? ' aria-current="page"' : ""}>${IC.course}<span>과정</span></a><a href="#/special"${e[0] === "special" || [15,16,17].includes(h) && (e[0] === "list" || e[0] === "lab") ? ' aria-current="page"' : ""}>${IC.star}<span>특별관</span></a><button type="button" data-action="find">${IC.search}<span>찾기</span></button><a href="#/sheet"${e[0] === "sheet" ? ' aria-current="page"' : ""}>${IC.sheet}<span>학습지</span></a></nav>`;
  let route = e[0] === "list" || e[0] === "sitemap" ? e[0] : "dashboard";
  if (e[0] === "elementary") {
    d("#content").innerHTML = `<section class="at-page-head"><p class="at-eyebrow">초등 수학 탐구</p><h1>그림을 바꾸며 발견하는 수학</h1><p class="at-desc">초1부터 초6까지 ${ELEMENTARY_LABS.length}개 실험을 단원별 학습 내용에 맞춰 준비했습니다. 먼저 예상하고 그림을 바꿔 확인한 뒤 내 말로 설명해 보세요.</p><nav class="em-jump" aria-label="초등 학년 바로가기">${[21,22,23,24,25,26].map(gr=>`<a href="#/list?grade=${gr}">${COURSES[gr].short} 과정 보기</a>`).join('')}</nav></section>${[21,22,23,24,25,26].map(gr=>`<section class="em-group" style="margin:32px 0"><div class="v3-sec-head"><h2>${COURSES[gr].name}</h2><a href="#/list?grade=${gr}">${g.filter(l=>l.grade===gr).length}개 전체 보기 →</a></div><div class="v3-grid">${elementaryHighlights(gr).map(ee).join('')}</div></section>`).join('')}`;
    document.title='초등 수학 실험실 | '+TITLE;
    return;
  }
  if (e[0] === "sitemap") {
    d("#content").innerHTML = `<section class="at-page-head"><p class="at-eyebrow">전체 ${g.length}개 실험 · ${GRADES.length}개 과정</p><h1>사이트맵</h1><p class="at-desc">과정과 단원별로 모든 실험을 한눈에 봅니다. 제목을 누르면 바로 실험으로 갑니다. <a class="std-link" href="#/standards">성취기준으로 찾기 →</a></p><label class="at-search at-search-wide" for="map-search"><span aria-hidden="true">⌕</span><input id="map-search" placeholder="실험 이름으로 찾기 ( / 키)" aria-label="사이트맵에서 찾기"></label></section><div class="at-map">${GRADES.map((o) => `<section class="at-map-course" style="--c:${COURSES[o].color}"><h2><a href="#/list?grade=${o}">${COURSES[o].short}</a><small>${COURSES[o].level} · ${g.filter((m) => m.grade === o).length}개</small></h2>${M[o].map(([u2, nm]) => { let list = g.filter((m) => m.grade === o && m.unit === u2); return list.length ? `<h3>${unitLabel(o, u2)} ${nm}</h3><ol>${list.map((m) => `<li data-t="${q(m.title)}"><a href="#/lab/${m.id}"><span class="at-map-code">${m.lesson}</span>${m.title}</a></li>`).join("")}</ol>` : ""; }).join("")}</section>`).join("")}</div>`;
    d("#map-search").oninput = (o) => { let w = o.target.value.trim().toLowerCase(); document.querySelectorAll(".at-map li").forEach((li) => (li.hidden = w && !KS.hit(KS.norm(w), KS.prep(li.dataset.t), false))); document.querySelectorAll(".at-map-course").forEach((sc) => (sc.hidden = w && !sc.querySelector("li:not([hidden])"))); };
    document.title = "사이트맵 · " + TITLE;
    return;
  }
  if (e[0] === "standards") {
    const m = await import("./lab-chunks/standards-ui.js");
    if (t !== V) return;
    await m.renderPage(d("#content"), g.map(LI), {
      query: i, match: (w, text) => KS.hit(KS.norm(w), KS.prep(text), false) > 0,
      // 그 성취기준의 실험을 순서대로 넘기는 수업 꾸러미 (학습지의 꾸러미와 같은 주소 형식)
      async onPack(ids, title) {
        const { openSendQR } = await import("./learning-tools/send-qr.js");
        const url = location.origin + location.pathname + "#/lab/" + encodeURIComponent(ids[0]) + "?pack=" + ids.map(encodeURIComponent).join(",") + "&pt=" + encodeURIComponent(title);
        await openSendQR({ url, shortUrl: url, title: "수업 꾸러미 · " + title + " (" + ids.length + "개)", notify: T });
      },
      async onSheet(ids, btn) {
        btn.disabled = true; let n = 0;
        try { await HS.ensure(ids.filter((id) => byId[id]?.module === "hs")); } catch {}
        for (const id of ids) { const lab = byId[id]; if (lab && SH.addStatic(...SHM(lab, { thumb: lab.module === "hs" ? null : thumbOf(lab) })) > 0) n++; }
        SH.updateBadge(); btn.disabled = false;
        T(n ? `실험 ${n}개를 학습지에 담았어요. 위쪽 ‘학습지’에서 볼 수 있어요.` : "학습지에 담지 못했어요. 브라우저 저장 공간이 가득 찼을 수 있어요.");
      },
    });
    document.title = "성취기준으로 찾기 · " + TITLE;
    return;
  }
  if (e[0] === "special") {
    // 한 번에 한 관만 보여 준다 (#/special?hall=9·15·16·17, 기본은 수학의 역설)
    const SPH = [9, 15, 16, 17].includes(Number(i.get("hall"))) ? Number(i.get("hall")) : 15;
    let hall = (gr, lead, rel) => { let c2 = COURSES[gr], L = g.filter((o) => o.grade === gr), R2 = rel.map((x) => g.find((o) => o.id === x)).filter(Boolean); const units = (M[gr] || []).filter(([u]) => L.some((o) => o.unit === u));
      return `<section class="sp-hall" style="--c:${c2.color}" id="sp-${gr}"><div class="sp-hall-head"><div><p class="v3-eyebrow">${c2.en}</p><h2>${c2.name}</h2><p>${lead}</p></div><a class="btn" href="#/list?grade=${gr}">단원 목차로 보기 · ${L.length}개 →</a></div><nav class="sp-topics" aria-label="주제 바로가기">${units.map(([u, nm]) => `<a href="#sp-u${gr}-${u}"><span>${unitLabel(gr, u)}</span>${nm}</a>`).join("")}</nav>${(M[gr] || []).map(([u, nm]) => { let U = L.filter((o) => o.unit === u); return U.length ? `<h3 class="sp-unit" id="sp-u${gr}-${u}"><span>${unitLabel(gr, u)}</span>${nm}<small>${U.length}개</small></h3><div class="v3-grid">${U.map(ee).join("")}</div>` : ""; }).join("")}${R2.length ? `<h3 class="sp-unit"><span>함께 보기</span>다른 과정에 있는 이야기<small>${R2.length}개</small></h3><div class="v3-grid">${R2.map(ee).join("")}</div>` : ""}</section>`; };
    d("#content").innerHTML = `<section class="sp-hero"><div class="sp-hero-in"><p class="v3-eyebrow">특별관</p><h1>상식을 뒤집는 역설,<br>역사를 바꾼 실험, 머리를 깨우는 퍼즐</h1><p>직관이 틀리는 순간, 수학자들이 세상을 처음 재어 본 순간, 그리고 이기는 전략을 찾는 순간을 직접 끌고 바꾸며 겪어 봅니다.</p><nav class="sp-jump sp-tabs" aria-label="관 고르기">${[[9, IC.course], [15, IC.star], [16, IC.guide], [17, IC.grid]].map(([gr, ic]) => `<a href="#/special?hall=${gr}"${gr === SPH ? ' aria-current="page"' : ""}>${ic}${COURSES[gr].name} <b>${g.filter((o) => o.grade === gr).length}</b></a>`).join("")}</nav></div></section><div class="sp-body">${SPH === 9 ? hall(9, "곡선과 무늬, 프랙털, 삼각형의 신비, 우연, 그래프와 알고리즘 — 교과서 밖의 아름다운 수학을 직접 그리며 탐구합니다.", []) : ""}${SPH !== 15 ? "" : hall(15, "몬티홀 문제부터 힐베르트 호텔까지 — 답을 먼저 예측하고, 실험으로 직관이 어디서 어긋나는지 확인합니다.", ["lab-monty-hall", "lab-birthday", "lab-zeno"])}${SPH !== 16 ? "" : hall(16, "에라토스테네스의 막대 그림자부터 나이팅게일의 장미 도표까지 — 역사 속 실험을 그대로 재현합니다.", ["lab-buffon", "lab-konigsberg", "lab-monte-pi", "lab-galton", "m1-ulam", "alg-slide-rule", "pst-lln"])}${SPH !== 17 ? "" : hall(17, "강 건너기, 가짜 동전, 100명의 죄수, 님 게임, 큐브 — 풀이 뒤에 숨은 수학과 이기는 전략을 찾습니다.", ["alg-hanoi", "lab-pick", "alg-circle-regions", "m1-paper-fold", "m2-rps"])}</div>`;
    d("#content").querySelectorAll(".sp-topics a").forEach((a) => (a.onclick = (ev) => { ev.preventDefault(); d(a.getAttribute("href"))?.scrollIntoView({ behavior: "smooth" }); }));
    document.title = "특별관 · " + TITLE;
    return;
  }
  if (e[0] === "plus") {
    d("#content").innerHTML = `<div class="ap-banner"><div><h1>교과서 심화 공방</h1><p>조건을 바꾸고 예측한 뒤 풀이와 기록을 함께 확인하세요.</p></div><a href="#/dashboard">전체 실험으로</a></div><div class="v3-grid">${PLUS_LABS.map(ee).join("")}</div>`;
    document.title = "교과서 심화 공방 | " + TITLE;
    return;
  }
  if (e[0] === "guide") {
    d("#content").innerHTML = guideHTML();
    let sec = i.get("s"), el = sec && d("#g-" + sec);
    document.querySelectorAll(".g-toc [data-guide]").forEach((x) => x.toggleAttribute("aria-current", x.dataset.guide === (sec || "about")));
    requestAnimationFrame(() => (el ? el.scrollIntoView({ block: "start" }) : scrollTo(0, 0)));
    document.title = "사용설명서 · " + TITLE;
    let io = new IntersectionObserver((es) => es.forEach((x) => x.isIntersecting && document.querySelectorAll(".g-toc [data-guide]").forEach((t) => t.toggleAttribute("aria-current", "g-" + t.dataset.guide === x.target.id))), { rootMargin: "-20% 0px -70% 0px" });
    document.querySelectorAll(".g-sec").forEach((x) => io.observe(x));
    R.signal.addEventListener("abort", () => io.disconnect());
    return;
  }
  if (e[0] === "sheet") {
    SH.render(d("#content"), T, {
      units: GRADES.flatMap((gr) => (M[gr] || []).map(([u, nm]) => [gr, u, nm, g.filter((o) => o.grade === gr && o.unit === u).length]).filter((x) => x[3]).map(([gr, u, nm, c]) => [`${gr}:${u}`, `${COURSES[gr].short} · ${unitLabel(gr, u)} ${nm} (${c}개)`])),
      unitLabs(v) { const [gr, u] = v.split(":").map(Number); return g.filter((o) => o.grade === gr && o.unit === u).map((o) => [o.id, LI(o).title, o.lesson]); },
      async addUnit(v, ids) {
        let [gr, u] = v.split(":").map(Number), labs = g.filter((o) => o.grade === gr && o.unit === u && (!ids || ids.includes(o.id))), k = 0;
        await HS.ensure(labs.filter((l) => l.module === "hs").map((l) => l.id));
        for (let lab of labs) if (SH.addStatic(...SHM(lab, { thumb: lab.module === "hs" ? null : thumbOf(lab) })) > 0) k++;
        return k;
      },
    });
    document.title = "학습지 · " + TITLE;
    return;
  }
  if (e[0] !== "lab" || !a) {
    let cnt = (o) => g.filter((m) => m.grade === o).length, seenIn = (o) => g.filter((m) => m.grade === o && VIS.includes(m.id)).length;
    if (route === "dashboard") {
      let nq = g.reduce((t, l) => t + (l.npred ?? (l.predict || HS.bankFor(l.id) || []).length), 0), rc = [];
      try { rc = JSON.parse(localStorage.getItem("mckay-recent") || "[]").map((x) => byId[x]).filter(Boolean).slice(0, 4); } catch {}
      let tile = (o) => `<a class="v3-ctile" href="#/list?grade=${o}" style="--c:${COURSES[o].color}">${o>=21?`<picture class="v3-course-motion"><source media="(prefers-reduced-motion: reduce)" srcset="course-gif/c${o}.png"><img class="v3-cgif" src="course-gif/c${o}.gif" alt="" width="56" height="56" loading="lazy" decoding="async"></picture>`:`<img class="v3-cgif" src="${o===18?"advanced-math/thumbs/linear.svg":"course-gif/c"+o+".gif"}" alt="" width="56" height="56" loading="lazy" decoding="async">`}<span class="v3-ctx"><b>${COURSES[o].name}</b><small>${cnt(o)}개 실험${seenIn(o) ? ` · ${seenIn(o)}개 해 봄` : ""}</small></span></a>`;
      let lv = LEVELS.find((x) => x[0] === U("mckay-level", ""));
      let lvHTML = !lv ? `<section class="v3-level"><div class="v3-sec-head"><h2>몇 학년인가요?</h2><span>고르면 맞는 과정을 첫 화면 맨 위에 보여 드려요</span></div><div class="v3-level-btns">${LEVELS.map(([k, sh]) => `<button type="button" data-level="${k}">${sh}</button>`).join("")}</div></section>`
        : lv[0] === "all" ? "" : `<section class="v3-mine"><div class="v3-sec-head"><h2>내 과정</h2><span>${lv[2]}</span><button type="button" class="v3-level-change" data-level="">학년 바꾸기</button></div><div class="v3-ctiles">${lv[3].map(tile).join("")}</div></section>`;
      let groupHTML = GROUPS.map(([gn, gs]) => `<div class="v3-cgroup"><h3>${gn}</h3><div class="v3-ctiles">${gs.map(tile).join("")}</div></div>`).join("");
      d("#content").innerHTML = `<section class="v3-hero"><div class="v3-hero-in"><div class="v3-hero-main"><p class="v3-eyebrow">McKay Math Atelier</p><div class="v3-title"><h1>끌고 바꾸고 예측하며<br>배우는 수학 실험실</h1></div><button class="v3-bigsearch" type="button" data-action="find">${IC.search}<span>실험과 개념 및 단원 이름으로 찾기</span><kbd>Ctrl K</kbd></button><div class="v3-popular"><span>자주 찾는 개념</span>${["피타고라스", "이차함수", "미분계수", "조건부확률", "벡터", "작도"].map((w) => `<button type="button" data-find="${w}">${w}</button>`).join("")}</div></div><dl class="v3-stats"><div><dt>실험</dt><dd>${g.length}</dd></div><div><dt>과정</dt><dd>${GRADES.length}</dd></div><div><dt>예측과 탐구 과제</dt><dd>${nq.toLocaleString("ko-KR")}</dd></div></dl></div></section><div class="v3-home">${lvHTML}<section class="v3-resume"><div class="v3-sec-head"><h2>${rc.length ? "이어서 하기" : "처음이라면"}</h2>${y.length ? `<span class="v3-favs">즐겨찾기 ${y.length}개</span>` : ""}</div><div class="v3-rcrow">${rc.length ? rc.map((t) => { const L = LI(t); return `<a class="v3-rc" href="#/lab/${t.id}" style="--c:${t.color}"><span class="v3-rc-thumb" aria-hidden="true">${thumbOf(t)}</span><span class="v3-rc-tx"><small>${COURSES[t.grade].short} ${t.lesson}</small><b>${L.title}</b></span></a>`; }).join("") + START.slice(0, Math.max(0, 4 - rc.length)).map(startCard).join("") : START.map(startCard).join("")}</div></section><section class="v3-courses"><div class="v3-sec-head"><h2>학년별 과정 고르기</h2><span>과정을 누르면 단원 목차가 열려요.</span>${lv && lv[0] === "all" ? `<button type="button" class="v3-level-change" data-level="">학년 고르기</button>` : ""}</div><div class="v3-cgrid">${groupHTML}</div></section><section><div class="v3-sec-head"><h2>새로 열린 곳</h2></div><div class="v3-rcrow"><a class="v3-rc v3-start" href="#/list?grade=18"><span class="v3-start-ic">${IC.course}</span><span class="v3-rc-tx"><b>고급수학 탐구실</b><small>영재고 심화 탐구 50개 실험과 탐구 기록</small></span></a><a class="v3-rc v3-start" href="#/lab/alg-circle-waves"><span class="v3-start-ic">${IC.course}</span><span class="v3-rc-tx"><b>단위원과 삼각함수 탐구</b><small>11가지 보기와 33개 탐구 미션</small></span></a><a class="v3-rc v3-start" href="#/elementary"><span class="v3-start-ic">${IC.course}</span><span class="v3-rc-tx"><b>초등 수학 실험실</b><small>학습 내용에 맞춘 초1부터 초6까지 ${ELEMENTARY_LABS.length}개 조작 실험</small></span></a><a class="v3-rc v3-start" href="#/lab/cube-lab"><span class="v3-start-ic">${IC.grid}</span><span class="v3-rc-tx"><b>큐브 실험실</b><small>2×2부터 7×7까지 큐브 돌리기</small></span></a><a class="v3-rc v3-start" href="solid-classroom/index.html?view=lab&amp;lab=slice"><span class="v3-start-ic">${IC.course}</span><span class="v3-rc-tx"><b>입체도형 수업 스튜디오</b><small>정육면체 자르기와 전개도 탐구</small></span></a><a class="v3-rc v3-start" href="#/plus"><span class="v3-start-ic">${IC.star}</span><span class="v3-rc-tx"><b>교과서 심화 공방</b><small>필기와 탐구 기록을 함께 남기는 심화 실험</small></span></a></div></section></div>`;
      document.title = TITLE;
      return;
    }
    let units = M[h].map(([u, nm]) => [u, nm, g.filter((m) => m.grade === h && m.unit === u)]).filter((x) => x[2].length);
    if(h>=21)units.unshift([0,"실험",g.filter(m=>m.grade===h)]);
    CU = units.some((x) => x[0] === unit) ? unit : units[0]?.[0] || 0;
    let ui = units.findIndex((x) => x[0] === CU), [, unm, UL] = units[ui] || [0, "", []], les = i.get("lesson") || "", gname = (GROUPS.find(([, gs]) => gs.includes(h)) || [""])[0];
    let lessons = [...new Set(UL.map((m) => lessonBase(m.lesson)))].sort(lessonCmp).map((l) => [l, UL.filter((m) => lessonBase(m.lesson) === l).length]), lname = (l) => (/[-.]/.test(l) ? l : "탐구·프로젝트");
    let total = cnt(h), seen = seenIn(h), mins = UL.reduce((t, m) => t + (parseInt(m.time) || 10), 0), uno = (u) => unitLabel(h, u).replace("단원", "");
    let types = [["all", "전체", UL.length], ...["조작", "2D", "3D", "데이터"].map((tp) => [tp, tp, UL.filter((m) => m.type === tp).length]).filter((x) => x[2]), ["fav", "★ 즐겨찾기", g.filter((m) => m.grade === h && y.includes(m.id)).length]];
    d("#content").innerHTML = `<div class="v3-course"><aside class="v3-side" aria-label="과정과 단원"><details class="v3-picker"><summary style="--c:${c.color}"><i></i><span><small>${c.level}${gname && gname !== c.level ? ` · ${gname}` : ""}</small><b>${c.name}</b></span>${IC.down}</summary><div class="v3-picker-list">${GROUPS.map(([gn, gs]) => `<div><h4>${gn}</h4>${gs.map((o) => `<a href="#/list?grade=${o}" style="--c:${COURSES[o].color}"${o === h ? ' aria-current="page"' : ""}><i></i><span>${COURSES[o].name}</span><small>${cnt(o)}</small></a>`).join("")}</div>`).join("")}</div></details><div class="v3-progress"><span>${total}개 실험 · ${units.length-(h>=21?1:0)}${h>=21?"개 주제":"단원"}</span><span>${seen}개 해 봄</span><div class="v3-bar"><i style="width:${total ? Math.round((100 * seen) / total) : 0}%"></i></div></div><nav class="v3-units" aria-label="단원 목차">${units.map(([u, nm, L]) => `<a class="v3-unit${u === CU ? " on" : ""}" href="#/list?grade=${h}&unit=${u}"${u === CU ? ' aria-current="page"' : ""}><span class="no">${uno(u)}</span><span class="nm">${nm}</span><span class="ct">${L.length}</span></a>${u === CU && CU!==0 && lessons.length > 1 ? `<div class="v3-lessons">${lessons.map(([l, n]) => `<a href="#/list?grade=${h}&unit=${u}${les === l ? "" : `&lesson=${encodeURIComponent(l)}`}"${les === l ? ' aria-current="true"' : ""}><span>${lname(l)}</span><small>${n}</small></a>`).join("")}</div>` : ""}`).join("")}</nav><a class="v3-maplink" href="#/sitemap">전체 사이트맵 →</a></aside><section class="v3-main"><p class="v3-crumbs"><a href="#/dashboard">처음</a> › <a href="#/list?grade=${h}">${c.name}</a> › ${unitLabel(h, CU)}</p><div class="v3-unit-head"><div><h1>${unitLabel(h, CU)} ${unm}</h1><p>${UL.length}개 실험 · 약 ${mins}분${les ? ` · <b>${/[-.]/.test(les) ? les : "탐구·프로젝트"}</b>만 보는 중 <a href="#/list?grade=${h}&unit=${CU}">모두 보기</a>` : ""}</p></div><button class="btn primary" type="button" data-action="unit-sheet" ${h>=21&&CU===0?"hidden":""} data-unit="${h}:${CU}">${IC.sheet}${h>=21?"주제":"단원"} 통째로 학습지에 담기</button></div><div class="v3-tools"><label class="v3-search" for="search">${IC.search}<input id="search" aria-label="이 과정에서 찾기" value="${q(E)}" placeholder="이 과정에서 찾기 ( / 키)"></label><div class="v3-chips" role="group" aria-label="유형">${types.map(([o, nm, n]) => `<button type="button" class="at-chip${D === o ? " active" : ""}" data-filter="${o}">${nm}<small>${n}</small></button>`).join("")}</div><label class="v3-sort">정렬 <select id="v3-sort" aria-label="정렬">${[["lesson", "차시 순"], ["short", "시간 짧은 순"], ["long", "시간 긴 순"]].map(([o, nm]) => `<option value="${o}"${SORT === o ? " selected" : ""}>${nm}</option>`).join("")}</select></label><div class="v3-view" role="group" aria-label="보기 방식"><button type="button" data-view="grid" aria-pressed="${VIEW === "grid"}" aria-label="카드로 보기">${IC.grid}</button><button type="button" data-view="list" aria-pressed="${VIEW === "list"}" aria-label="목록으로 보기">${IC.list}</button></div><span id="count" class="v3-count"></span></div><section id="lab-results" class="v3-grid${VIEW === "list" ? " is-list" : ""}"></section><nav class="v3-pager" aria-label="단원 이동">${ui > 0 ? `<a href="#/list?grade=${h}&unit=${units[ui - 1][0]}">${IC.left}<span><small>이전 단원</small><b>${unitLabel(h, units[ui - 1][0])} ${units[ui - 1][1]}</b></span></a>` : "<span></span>"}${ui < units.length - 1 ? `<a class="next" href="#/list?grade=${h}&unit=${units[ui + 1][0]}"><span><small>다음 단원</small><b>${unitLabel(h, units[ui + 1][0])} ${units[ui + 1][1]}</b></span>${IC.right}</a>` : "<span></span>"}</nav></section></div>`;
    P();
    d("#search").oninput = (o) => { E = o.target.value; P(); };
    d("#v3-sort").onchange = (o) => { SORT = o.target.value; W("mckay-sort", SORT); P(); };
    document.title = `${c.name} · ${TITLE}`;
    return;
  }
  if (a.module === "hs") {
    if (!HS.has(a.id)) { T("실험을 불러오는 중…"); try { await HS.ensure([a.id]); } catch (o) { console.error(o); T("실험을 불러오지 못했어요. 인터넷 연결을 확인하고 다시 열어 주세요."); return; } if (t !== V) return; if (d("#lab-status")?.textContent === "실험을 불러오는 중…") T(""); }
    // 원래 목록 항목에 채운 뒤 다시 번역한다 (영어 모드에서 번역된 질문을 한국어로 덮어쓰지 않게)
    const sp = HS.specOf(a.id), raw = g.find((o) => o.id === a.id);
    if (sp && raw) { for (const key of ["obs", "q", "formula"]) if (sp[key] !== undefined) raw[key] = sp[key]; a = LI(raw); }
  }
  try { let rc = JSON.parse(localStorage.getItem("mckay-recent") || "[]").filter((x) => x !== a.id); rc.unshift(a.id); localStorage.setItem("mckay-recent", JSON.stringify(rc.slice(0, 8))); } catch {}
  VIS.includes(a.id) || (VIS = [...VIS, a.id], W("mckay-visited", VIS));
  let seq = g.filter((m) => m.grade === a.grade),
    ix = seq.findIndex(m => m.id === a.id),
    prev = seq[ix - 1],
    next = seq[ix + 1],
    useq = seq.filter((m) => m.unit === a.unit),
    np = a.npred ?? (a.predict || HS.bankFor(a.id) || []).length,
    arrow = (m, dir) => (m ? `<a class="v3-arrow" href="#/lab/${m.id}" aria-label="${dir === "left" ? "이전" : "다음"} 실험: ${q(m.title)}" title="${q(m.title)}">${IC[dir]}</a>` : '<span class="v3-arrow off" aria-hidden="true"></span>'),
    navHTML = `<nav class="at-lab-nav" aria-label="이전·다음 실험">${prev ? `<a class="at-lab-nav-prev" href="#/lab/${prev.id}"><small>← 이전 실험</small><b>${prev.title}</b></a>` : "<span></span>"}<span class="at-lab-nav-pos">${GL(a.grade)} ${ix + 1} / ${seq.length}</span>${next ? `<a class="at-lab-nav-next" href="#/lab/${next.id}"><small>다음 실험 →</small><b>${next.title}</b></a>` : "<span></span>"}</nav>`;
  ((document.title = a.title + " · " + TITLE),
    (d("#content").innerHTML =
      `<div class="v3-labbar">${arrow(prev, "left")}<div class="v3-labtitle"><p class="v3-crumbs"><a href="#/list?grade=${a.grade}" class="at-back">${COURSES[a.grade].name}</a> › <a href="#/list?grade=${a.grade}&unit=${a.unit}">${unitLabel(a.grade, a.unit)} ${unitName(a.grade, a.unit)}</a></p><p class="v3-meta">${a.lesson} · ${a.type} · ${a.time} · 단원 안 ${useq.findIndex(m => m.id === a.id) + 1} / ${useq.length}</p><h1>${a.title}</h1><p class="v3-lead" data-m="${q(a.desc)}">${mathHTML(a.desc)}</p></div><div class="v3-labtools top-actions"><button class="btn" data-action="reset">${IC.reset}<span>초기화</span></button><button class="btn" data-action="share">${IC.link}<span>링크</span></button><button class="btn" data-action="qr" title="QR 코드로 학생 휴대폰에 이 실험 보내기"><svg class="ic" viewBox="0 0 20 20" aria-hidden="true"><rect x="3" y="3" width="5" height="5"/><rect x="12" y="3" width="5" height="5"/><rect x="3" y="12" width="5" height="5"/><path d="M12 12h2v2h-2zM15 15h2v2h-2zM12 16h1M16 12h1"/></svg><span>학생에게 보내기</span></button><button class="btn" data-action="tools" title="타이머와 번호 뽑기 (단축키 T, N)"><svg class="ic" viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="11" r="6.5"/><path d="M10 7.5V11l2.5 2M8 2.5h4"/></svg><span>수업 도구</span></button><button class="btn" data-action="capture">${IC.img}<span>그림 저장</span></button><button class="btn" data-action="sheet-add">${IC.sheet}<span>학습지에 담기</span></button><button class="btn" data-action="print-one" aria-haspopup="true"><svg class="ic" viewBox="0 0 20 20" aria-hidden="true"><path d="M5 7V3h10v4M5 14H3V8h14v6h-2M6 11h8v6H6z"/></svg><span>인쇄</span></button><button class="btn primary" data-action="present">${IC.present}<span class="v3-present-t">발표 모드</span></button></div>${arrow(next, "right")}</div>${lessonHTML(mathHTML(a.q || a.desc), mathHTML((a.obs || [])[0] || ""))}<section class="lab-layout v3-lab"><article class="panel stage-panel"><div class="stage-head"><strong>실험 화면</strong><span id="stage-hint">값과 그림을 함께 관찰하세요</span></div><p id="plot-caption" class="plot-caption" hidden></p><div id="stage" class="stage"></div><div id="metrics" class="metrics" aria-live="polite"></div></article><aside class="panel v3-sidepanel"><div class="v3-tabs" role="tablist" aria-label="실험 패널"><button type="button" role="tab" data-tab="ctl" aria-selected="true">조작${np ? `<small>${a.module === "elementary"?"탐구":"예측"} ${np}</small>` : ""}</button><button type="button" role="tab" data-tab="info" aria-selected="false">설명</button><button type="button" role="tab" data-tab="rel" aria-selected="false">관련 실험</button></div><div class="v3-tabpanel" data-panel="ctl" role="tabpanel"><div id="controls" class="control-panel"></div><div id="pred-slot"></div></div><div class="v3-tabpanel v3-info" data-panel="info" role="tabpanel" hidden><h2>관찰하기</h2><ul>${a.obs.map((o) => `<li data-m="${q(o)}">${mathHTML(o)}</li>`).join("")}</ul><h2>생각해보기</h2><p data-m="${q(a.q)}">${mathHTML(a.q)}</p><h2>개념 연결</h2><div class="formula" data-mb="${q(a.formula)}">${mathBlock(a.formula)}</div>${flowOf(a)}<div class="v3-std" id="v3-std" hidden></div></div><div class="v3-tabpanel" data-panel="rel" role="tabpanel" hidden>${linksOf(a) || '<p class="v3-empty">연결된 실험이 아직 없어요. 아래 ‘다음 실험’으로 이어 가세요.</p>'}</div>${next ? `<a class="v3-nextcard" href="#/lab/${next.id}"><span><small>다음 실험 · ${next.lesson}</small><b>${next.title}</b></span>${IC.right}</a>` : ""}</aside></section>${navHTML}`));
  a.module !== "hs" && watchMath();
  import("./lab-chunks/standards-ui.js").then((m) => m.fillLab(d("#v3-std"), a.id)).catch(() => {});
  let u = {};
  try {
    ((u = JSON.parse(i.get("s") || "{}")), (!u || typeof u != "object") && (u = {}));
  } catch {}
  let p = {
    stage: d("#stage"),
    controls: d("#controls"),
    metrics: d("#metrics"),
    hint: d("#stage-hint"),
    caption: d("#plot-caption"),
    preset: u,
    signal: R.signal,
    notice: T,
    navigateWave: state => {
      const hash = '#/lab/' + routeForState(state) + '?s=' + encodeURIComponent(JSON.stringify(state));
      if (location.hash === hash) return false;
      location.hash = hash;
      return true;
    },
  };
  try {
    let o =
      a.module === "elementary"
        ? await import("./lab-chunks/elementary.js")
        : a.module === "wave-frontiers"
        ? await import("./lab-chunks/wave-frontiers.js")
        : a.module === "circle-waves"
        ? await import("./lab-chunks/circle-waves.js")
        : a.module === "atelier-plus"
        ? await import("./atelier-plus/app.js")
        : a.module === "cube"
        ? await import("./lab-chunks/cube-lab.js")
        : a.module === "hs"
        ? HS
        : a.module === "sphere-area"
          ? await import("./lab-chunks/sphere-area-H7XOLRJP.js")
          : a.module === "foundations"
            ? await import("./lab-chunks/foundations-X4APGJAI.js")
            : a.module === "positions"
              ? await import("./lab-chunks/positions-GGWL6MP2.js")
              : a.module === "solid"
                ? await import("./lab-chunks/solid-SGKZTCIW.js")
                : ["data", "representative"].includes(a.module)
                  ? await import("./lab-chunks/data-RJLOKG5U.js")
                  : a.module === "advanced"
                    ? await import("./lab-chunks/advanced-IMW33JLZ.js")
                    : a.module === "advanced-data"
                      ? await import("./lab-chunks/advanced-data-GA674HMR.js")
                      : await import("./lab-chunks/geometry-DCAGPXXN.js");
    if (t !== V) return;
    k = await o.mount(a.module === "representative" ? "averages" : a.id, p);
    if (t !== V) { k?.destroy?.(); return; }
    if (a.module !== "elementary" && a.module !== "atelier-plus" && a.module !== "cube" && a.module !== "circle-waves" && a.module !== "wave-frontiers") STUDY_TOOLS = createStudyTools(a, p, k);
    // 옛 실험에는 문항 은행의 '예측하고 확인하기' 칸을 붙인다
    let pb = a.module !== "hs" && HS.bankFor(a.id);
    if (pb) pb = LI({ id: a.id, predict: pb }).predict; // 영어판이면 예측 문항도 영어로
    if (pb && d("#pred-slot") && !d("#legacy-pred")) { d("#pred-slot").innerHTML = `<section class="at-pred-panel" id="legacy-pred"></section>`; HS.mountPredict(d("#legacy-pred"), pb); }
    STUDENT_LAB = mountStudentLab();
  } catch (o) {
    (console.error(o), T("실험을 열지 못했습니다. 초기화를 눌러 다시 시도해 주세요."));
  }
}
function typesetStatic() {
  document.querySelectorAll("[data-m]").forEach((el) => (el.innerHTML = mathHTML(el.dataset.m)));
  document.querySelectorAll("[data-mb]").forEach((el) => (el.innerHTML = mathBlock(el.dataset.mb)));
}
var mathObs = null;
function mathLeaves(root) {
  root.querySelectorAll("strong, small, output, td, th, p, li, span").forEach((el) => {
    if (el.children.length || el.closest(".mx, [data-math-plain]")) return;
    let tx = el.textContent;
    if (!tx || el.dataset.mxs === tx) return;
    if (/^\s*\d+\s*\/\s*\d+\s*·/.test(tx)) return; // "1/5 · 단계 안내"의 앞 숫자는 단계 번호
    if (/^\s*[\d.]+(\s+\/\s+[\d.]+)+\s*$/.test(tx) || /\d\/\d+\s*(회|개|번|명)/.test(tx)) return; // "5 / 6 / 7", "0/3회" 같은 나열·개수
    let html = mathHTML(tx);
    if (html.includes("mx")) ((el.innerHTML = html), (el.dataset.mxs = tx));
  });
}
function watchMath() {
  mathObs?.disconnect();
  let roots = ["#metrics", "#controls", "#plot-caption"].map((s2) => d(s2)).filter(Boolean),
    pending = 0,
    run = () => {
      pending = 0;
      mathObs.disconnect();
      roots.forEach(mathLeaves);
      roots.forEach((r) => !r.hasAttribute("data-math-plain") && mathObs.observe(r, { childList: !0, subtree: !0, characterData: !0 }));
    };
  mathObs = new MutationObserver(() => pending || (pending = requestAnimationFrame(run)));
  run();
}
onMathReady(() => {
  typesetStatic();
  k?.theme?.(v);
  mathObs && d("#metrics") && watchMath();
});
function resolveVars(str, el) {
  let cs = getComputedStyle(el);
  return str.replace(/var\((--[\w-]+)\)/g, (m, n) => cs.getPropertyValue(n).trim() || "#183b48");
}
async function te() {
  let t = d("#stage canvas");
  if (t) {
    z(t.toDataURL("image/png"), "수학실험.png");
    return;
  }
  let e = d("#stage svg"),
    i = !!e;
  if (!e) {
    let o = d("#stage table");
    if (!o) throw Error("저장할 시각화가 없습니다.");
    let c = [...o.querySelectorAll("tr")].map((f) => [...f.children].map((w) => w.textContent.trim())),
      m = 70 + c.length * 34;
    ((e = document.createElementNS("http://www.w3.org/2000/svg", "svg")),
      e.setAttribute("xmlns", "http://www.w3.org/2000/svg"),
      e.setAttribute("viewBox", `0 0 600 ${m}`),
      (e.innerHTML =
        `<text x="25" y="30" fill="var(--plot-ink)">${q(d("#plot-caption")?.textContent || "줄기와 잎 그림")}</text>` +
        c.map((f, w) => `<text x="30" y="${65 + w * 34}" fill="var(--plot-ink)">${q(f.join(" │ "))}</text>`).join("")));
  }
  let a = e.cloneNode(!0),
    s = d("#plot-caption"),
    ink = getComputedStyle(d("#stage")).getPropertyValue("--plot-ink").trim() || "#183b48";
  if (i && s && !s.hidden && s.textContent) {
    let o = s.textContent.match(/.{1,28}/gu) || [],
      [c, m, f, w] = a.getAttribute("viewBox").split(/\s+/).map(Number),
      n = o.length * 24 + 16;
    (a.setAttribute("viewBox", `${c} ${m - n} ${f} ${w + n}`),
      a.insertAdjacentHTML(
        "afterbegin",
        o.map((r, b) => `<text x="${c + f / 2}" y="${m - n + 24 + b * 24}" text-anchor="middle" fill="${ink}" font-size="18">${q(r)}</text>`).join(""),
      ));
  }
  let vb = a.getAttribute("viewBox").split(/\s+/).map(Number),
    W2 = 1400,
    H2 = Math.round((W2 * vb[3]) / vb[2]);
  (a.setAttribute("width", W2),
    a.setAttribute("height", H2),
    a.setAttribute("style", `background:${getComputedStyle(document.body).backgroundColor};font-family:'IBM Plex Sans KR',sans-serif;font-size:16px`));
  let u = resolveVars(new XMLSerializer().serializeToString(a), d("#stage")),
    p = URL.createObjectURL(new Blob([u], { type: "image/svg+xml" }));
  try {
    let o = new Image();
    await new Promise((m, f) => {
      ((o.onload = m), (o.onerror = f), (o.src = p));
    });
    let c = document.createElement("canvas");
    ((c.width = W2), (c.height = H2), c.getContext("2d").drawImage(o, 0, 0), z(c.toDataURL("image/png"), "수학실험.png"));
  } finally {
    URL.revokeObjectURL(p);
  }
}
// 내려받기가 막힌 환경(아티팩트 등)에서도 저장할 수 있도록 그림을 크게 띄워 준다
function z(t, e) {
  try {
    let i = document.createElement("a");
    ((i.href = t), (i.download = e), document.body.append(i), i.click(), i.remove());
  } catch {}
  let ov = document.createElement("div");
  ov.className = "at-shot";
  ov.innerHTML = `<figure><img src="${t}" alt="저장할 실험 그림"><figcaption>그림을 길게 누르거나 마우스 오른쪽 버튼으로 눌러 저장하세요.</figcaption><button class="btn" type="button">닫기</button></figure>`;
  ov.onclick = (ev) => (ev.target === ov || ev.target.closest("button")) && ov.remove();
  document.body.append(ov);
}
document.addEventListener("click", async (t) => {
  let e = t.target.closest("[data-action],[data-fav],[data-filter]");
  if (!e) return;
  if (e.dataset.fav) {
    let a = e.dataset.fav;
    ((y = y.includes(a) ? y.filter((l) => l !== a) : [...y, a]), W("math-lab-favs", y), P());
    return;
  }
  if (e.dataset.filter) {
    ((D = e.dataset.filter), document.querySelectorAll("[data-filter]").forEach((a) => a.classList.toggle("active", a === e)), P());
    return;
  }
  let i = e.dataset.action;
  if (i === "find") { document.body.classList.remove("nav-open"); openFinder(); return; }
  if (i === "menu") { let open = document.body.classList.toggle("nav-open"); e.setAttribute("aria-expanded", String(open)); return; }
  if (i === "theme") {
    v = !v;
    try {
      localStorage.setItem("mckay-theme", v ? "dark" : "light");
    } catch {}
    ((document.documentElement.dataset.theme = v ? "dark" : "light"), (e.innerHTML = (v ? IC.sun : IC.moon) + `<span>${v ? "라이트" : "다크"}</span>`), e.setAttribute("aria-label", v ? "밝은 화면으로" : "어두운 화면으로"), (e.title = e.getAttribute("aria-label")), k?.theme?.(v));
  }
  if (
    (i === "reset" && (history.replaceState(null, "", location.href.split("?")[0]), $()),
    i === "present" &&
      (document.body.classList.toggle("presentation"),
      ((e.querySelector(".v3-present-t") || e).textContent = document.body.classList.contains("presentation") ? "돌아가기 (Esc)" : "발표 모드")),
    i === "share")
  ) {
    let l = location.href.split("?")[0] + "?s=" + encodeURIComponent(JSON.stringify(k?.state || {}));
    try {
      (await navigator.clipboard.writeText(l), T("현재 설정을 포함한 링크를 복사했습니다."));
    } catch {
      T("링크를 복사해 주세요.");
      let s = document.createElement("input");
      ((s.readOnly = !0), (s.value = l), d("#lab-status").append(s), s.select());
    }
  }
  if (i === "tools") { CK.toggleTools(); return; }
  if (i === "qr") {
    const base = location.href.split("?")[0], lab = g.find((o) => o.id === j().parts[1]);
    const { openSendQR } = await import("./learning-tools/send-qr.js");
    await openSendQR({ url: base + "?s=" + encodeURIComponent(JSON.stringify(k?.state || {})), shortUrl: base, title: lab ? lab.title : document.title, notify: T });
    return;
  }
  if (i === "print-one") {
    document.querySelector(".po-pick")?.remove();
    const lab = g.find((o) => o.id === j().parts[1]); if (!lab) return;
    const btn = document.querySelector('[data-action="print-one"]'), r = btn.getBoundingClientRect();
    const pick = document.createElement("div");
    pick.className = "po-pick"; pick.setAttribute("role", "dialog"); pick.setAttribute("aria-label", "인쇄할 학습지 고르기");
    pick.innerHTML = `<b>이 실험을 A4 한 장으로 인쇄</b><button type="button" class="btn" data-po="stu">학생용</button><button type="button" class="btn" data-po="tea">교사용 (답 포함)</button>`;
    pick.style.top = window.scrollY + r.bottom + 6 + "px"; pick.style.left = Math.max(8, Math.min(window.scrollX + r.left, window.scrollX + innerWidth - 230)) + "px";
    document.body.append(pick);
    pick.querySelector("button").focus();
    const close = (e) => { if (!e || (!pick.contains(e.target) && e.target !== btn) || e.key === "Escape") { pick.remove(); document.removeEventListener("pointerdown", close, true); document.removeEventListener("keydown", close, true); } };
    setTimeout(() => { document.addEventListener("pointerdown", close, true); document.addEventListener("keydown", close, true); });
    pick.onclick = async (e) => {
      const b = e.target.closest("[data-po]"); if (!b) return;
      close();
      const ok = await SH.printOne(...SHM(lab, { state: k?.state }), b.dataset.po === "tea");
      if (!ok) T("인쇄 창을 열지 못했어요. ‘학습지에 담기’ 뒤 학습지 화면에서 PDF로 내려받아 주세요.");
    };
    return;
  }
  if (i === "sheet-add") {
    let lab = g.find((o) => o.id === j().parts[1]);
    if (lab) {
      let n = SH.add(...SHM(lab, { state: k?.state }));
      SH.updateBadge();
      T(`학습지에 담았어요. 지금 ${n}개 — 위쪽 ‘학습지’에서 볼 수 있어요.`);
    }
    return;
  }
  if (i === "capture" && STUDY_TOOLS) { await STUDY_TOOLS.capture(); return; }
  if (i === "capture" && k?.capture) { k.capture(); T("필기를 포함한 그림을 저장했습니다."); return; }
  if (i === "capture")
    try {
      (await te(), T("그림을 만들었습니다."));
    } catch {
      T("그림 저장을 완료하지 못했습니다.");
    }
});
window.addEventListener("hashchange", () => {
  document.body.classList.remove("nav-open");
  ($(), window.scrollTo({ top: 0 }));
});
window.addEventListener("keydown", (t) => {
  if (t.key === "Escape") {
    document.body.classList.remove("presentation");
    let e = d('[data-action="present"] .v3-present-t');
    e && (e.textContent = "발표 모드");
    document.querySelector(".at-shot")?.remove();
  }
  if ((t.ctrlKey || t.metaKey) && (t.key === "k" || t.key === "K")) { t.preventDefault(); openFinder(); return; }
  if (t.key === "/" && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName || "")) {
    let s = d("#search");
    t.preventDefault();
    s ? s.focus() : openFinder();
  }
});
// ── 한글 찾기 도우미: 초성(ㅍㅌㄱㄹㅅ → 피타고라스), 치는 중인 글자(이차하 → 이차함수), 오타 한두 개 허용 ──
const KS = (() => {
  const CHO = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ", JUNG = "ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ", JONG = " ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ";
  // 겹받침·겹모음은 자판에서 두 번 치므로 둘로 나눈다
  const SPLIT = { ㄳ: "ㄱㅅ", ㄵ: "ㄴㅈ", ㄶ: "ㄴㅎ", ㄺ: "ㄹㄱ", ㄻ: "ㄹㅁ", ㄼ: "ㄹㅂ", ㄽ: "ㄹㅅ", ㄾ: "ㄹㅌ", ㄿ: "ㄹㅍ", ㅀ: "ㄹㅎ", ㅄ: "ㅂㅅ", ㅘ: "ㅗㅏ", ㅙ: "ㅗㅐ", ㅚ: "ㅗㅣ", ㅝ: "ㅜㅓ", ㅞ: "ㅜㅔ", ㅟ: "ㅜㅣ", ㅢ: "ㅡㅣ" };
  const sp = (ch) => SPLIT[ch] || ch;
  const norm = (x) => String(x || "").toLowerCase().replace(/\s+/g, "");
  const jamo = (s) => { let o = ""; for (const ch of norm(s)) { const c = ch.charCodeAt(0) - 0xac00; if (c >= 0 && c < 11172) o += CHO[Math.floor(c / 588)] + sp(JUNG[Math.floor((c % 588) / 28)]) + (c % 28 ? sp(JONG[c % 28]) : ""); else o += sp(ch); } return o; };
  const cho = (s) => { let o = ""; for (const ch of norm(s)) { const c = ch.charCodeAt(0) - 0xac00; o += c >= 0 && c < 11172 ? CHO[Math.floor(c / 588)] : ch; } return o; };
  const isCho = (w) => /^[ㄱ-ㅎ]{2,}$/.test(w);
  // 오타 허용: needle이 hay 어딘가와 편집 거리 k 이하로 맞는가 (근사 부분 문자열)
  const near = (needle, hay, k) => {
    const n = needle.length; if (!n || !hay) return false;
    let prev = Array.from({ length: n + 1 }, (_, i) => i);
    for (let j = 1; j <= hay.length; j++) {
      const cur = [0];
      for (let i = 1; i <= n; i++) cur[i] = Math.min(prev[i] + 1, cur[i - 1] + 1, prev[i - 1] + (needle[i - 1] === hay[j - 1] ? 0 : 1));
      if (cur[n] <= k) return true; prev = cur;
    }
    return false;
  };
  const slack = (wj) => (wj.length >= 10 ? 2 : wj.length >= 5 ? 1 : 0);
  // 찾을 글을 미리 풀어 둔다
  const prep = (s) => ({ n: norm(s), j: jamo(s), c: cho(s) });
  // 0: 안 맞음, 3: 그대로 맞음, 2: 치는 중인 글자·초성으로 맞음, 1: 오타 허용으로 맞음(fuzzy일 때만)
  const hit = (w, p, fuzzy) => {
    if (p.n.includes(w)) return 3;
    if (isCho(w)) return p.c.includes(w) ? 2 : 0;
    const wj = jamo(w);
    if (/[가-힣]/.test(w) && p.j.includes(wj)) return 2; // 자음 하나만 친 때는 쏟아지지 않게 완성 글자가 있을 때만
    if (fuzzy && !isCho(w)) { const k = slack(wj); if (k && near(wj, p.j, k)) return 1; }
    return 0;
  };
  return { norm, jamo, cho, isCho, prep, hit, near };
})();

initStudentUI();
$();

// ── 전체 실험 찾기 (Ctrl+K) — 모든 과정의 실험을 제목·개념·단원으로 찾아 바로 이동 ──
function flowOf(a) {
  const n = parseInt(a.time) || 10, p = Math.max(2, Math.round(n * 0.2)), c = Math.max(3, Math.round(n * 0.3)), e = Math.max(3, n - p - c);
  const o = (a.obs || [])[0] || "값을 바꾸며 변하는 양과 변하지 않는 양을 찾게 합니다.";
  return `<div class="lesson-guide"><h2>수업 흐름 <small>${n}분</small></h2><ol class="at-flow"><li><span>예측 · ${p}분</span><p>그림을 움직이기 전에 ‘생각해보기’ 질문의 답을 먼저 짐작해 적게 합니다.</p></li><li><span>탐구 · ${e}분</span><p data-m="${q(o)}">${mathHTML(o)}</p></li><li><span>정리 · ${c}분</span><p>짐작과 결과를 비교하고, 위의 식으로 이유를 설명하게 합니다.</p></li></ol></div>`;
}
function openFinder(q0) {
  if (document.querySelector(".at-finder")) return;
  const norm = (x) => String(x || "").toLowerCase().replace(/\s+/g, "");
  // 영어 모드면 영어 제목·설명·태그·과정 이름으로도 찾는다 (한국어 낱말도 그대로 찾힘)
  const en = H.language === "en" && ENL;
  const rows = g.map((l) => { const e = en ? LI(l) : null, cs = `${GL(l.grade)} ${COURSES[l.grade]?.name || ""} ${unitName(l.grade, l.unit)}`, tg = (l.tags || []).join(" ");
    return { l, t: KS.prep(l.title + (e ? " " + e.title : "")), k: KS.prep(tg + (e ? " " + (l.tags || []).map(A).join(" ") : "")), c: KS.prep(cs + (e ? " " + A(GL(l.grade)) + " " + A(COURSES[l.grade]?.name || "") + " " + A(unitName(l.grade, l.unit)) : "")), d: KS.prep(l.desc + (e ? " " + e.desc : "")) }; });
  const ov = document.createElement("div");
  ov.className = "at-finder";
  ov.innerHTML = `<div class="at-finder-box" role="dialog" aria-modal="true" aria-label="전체 실험 찾기"><label class="at-finder-in"><span aria-hidden="true">⌕</span><input type="search" placeholder="실험 이름, 개념, 과목으로 찾기 — 예: 타원, 확률, 중2 닮음, ㅍㅌㄱㄹㅅ" aria-label="찾을 말"><kbd>Esc</kbd></label><ul class="at-finder-list" role="listbox"></ul><p class="at-finder-foot"><span>↑↓ 고르기</span><span>Enter 열기</span><span>Esc 닫기</span></p></div>`;
  document.body.append(ov);
  const inp = ov.querySelector("input"), ul = ov.querySelector("ul");
  if (typeof q0 === "string") inp.value = q0;
  let sel = 0, cur = [], fuzzyN = 0, codeHit = null;
  const close = () => { ov.remove(); document.removeEventListener("keydown", onKey, true); };
  const go = (l) => { close(); location.hash = "#/lab/" + l.id; };
  const draw = () => {
    const q = inp.value.toLowerCase().split(/[\s,·]+/).filter(Boolean); // 띄어 쓴 낱말마다 따로 맞춘다 (예: 중2 닮음)
    const code = q.length === 1 && /^\[?\d{1,2}[가-힣ⅠⅡ]/.test(q[0]) ? q[0].replace(/[\[\]]/g, "") : ""; // 성취기준 번호 (예: 9수03-15)
    if (code && codeHit?.code !== code) { codeHit = { code, ids: null }; import("./lab-chunks/standards-ui.js").then((m) => m.labsByCode(code)).then((ids) => { if (codeHit?.code === code) { codeHit.ids = new Set(ids); draw(); } }).catch(() => {}); }
    if (code) { fuzzyN = 0; cur = codeHit.ids ? g.filter((l) => codeHit.ids.has(l.id)).slice(0, 60) : []; }
    else if (!q.length) cur = g.slice().sort((a, b) => (b.grade >= 4) - (a.grade >= 4)).slice(0, 0);
    else {
      // 그대로 맞는 것 > 치는 중인 글자·초성으로 맞는 것 순. 결과가 3개보다 적으면 오타 한두 개를 허용해 더 찾는다.
      const W = { t: 6, k: 4, c: 3, d: 1 };
      const score = (r, fuzzy) => { let sc = 0, fz = false; for (const w of q) { let best = 0; for (const f of ["t", "k", "c", "d"]) { if (fuzzy && f === "d") continue; const h = KS.hit(w, r[f], fuzzy); if (h) { const v = W[f] * (h === 3 ? 1 : h === 2 ? 0.8 : 0.5); if (v > best) { best = v; fz = h === 1; } } } if (!best) return null; sc += best + (r.t.n.startsWith(w) || (KS.isCho(w) ? r.t.c.startsWith(w) : r.t.j.startsWith(KS.jamo(w))) ? 2 : 0); } return [sc, r.l, fz]; };
      let hits = rows.map((r) => score(r, false)).filter(Boolean);
      fuzzyN = 0;
      if (hits.length < 3) { const have = new Set(hits.map((x) => x[1])); const more = rows.filter((r) => !have.has(r.l)).map((r) => score(r, true)).filter(Boolean); fuzzyN = more.length; hits = hits.concat(more.map((x) => [x[0] - 100, x[1]])); }
      cur = hits.sort((a, b) => b[0] - a[0]).slice(0, 40).map((x) => x[1]);
    }
    sel = Math.min(sel, Math.max(0, cur.length - 1));
    ul.innerHTML = (fuzzyN && q.length ? `<li class="at-finder-empty at-finder-fz">‘${inp.value.replace(/[<>&"]/g, "")}’와 똑같은 말은 적어서, 비슷한 말로 찾은 실험 ${fuzzyN}개도 함께 보여 줘요.</li>` : "") + (!q.length ? `<li class="at-finder-empty">과목 이름(예: 기하, 중3), 개념(예: 이차곡선, 표본), 실험 제목의 일부를 입력하세요. 전체 ${g.length}개 실험에서 찾습니다.</li>` : cur.length ? cur.map((l, i) => `<li role="option" aria-selected="${i === sel}" data-i="${i}" style="--c:${COURSES[l.grade]?.color}"><span class="at-finder-c">${GL(l.grade)}</span><span class="at-finder-t">${l.title}</span><span class="at-finder-u">${unitLabel(l.grade, l.unit)} ${unitName(l.grade, l.unit)}</span></li>`).join("") : `<li class="at-finder-empty">‘${inp.value.replace(/[<>&"]/g, "")}’와 맞는 실험이 없어요. 다른 낱말로 찾아보세요.</li>`);
    ul.querySelector('[aria-selected="true"]')?.scrollIntoView({ block: "nearest" });
  };
  const onKey = (e) => {
    if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); close(); }
    else if (e.key === "ArrowDown") { e.preventDefault(); sel = Math.min(cur.length - 1, sel + 1); draw(); }
    else if (e.key === "ArrowUp") { e.preventDefault(); sel = Math.max(0, sel - 1); draw(); }
    else if (e.key === "Enter" && cur[sel]) { e.preventDefault(); go(cur[sel]); }
  };
  document.addEventListener("keydown", onKey, true);
  inp.addEventListener("input", () => { sel = 0; draw(); });
  ov.addEventListener("click", (e) => { const li = e.target.closest("li[data-i]"); if (li) go(cur[+li.dataset.i]); else if (e.target === ov) close(); });
  draw();
  inp.focus();
}

// ── 새 화면(v3)의 탭·보기 전환·자주 찾는 낱말·단원 통째로 담기 ──
document.addEventListener("click", async (ev) => {
  const tab = ev.target.closest(".v3-tabs [data-tab]");
  if (tab) {
    const box = tab.closest(".v3-sidepanel");
    box.querySelectorAll(":scope > .v3-tabs > [data-tab]").forEach((b) => b.setAttribute("aria-selected", String(b === tab)));
    box.querySelectorAll(":scope > [data-panel]").forEach((p) => (p.hidden = p.dataset.panel !== tab.dataset.tab));
    return;
  }
  const vw = ev.target.closest(".v3-view [data-view]");
  if (vw) {
    VIEW = vw.dataset.view; W("mckay-view", VIEW);
    document.querySelectorAll(".v3-view [data-view]").forEach((b) => b.setAttribute("aria-pressed", String(b === vw)));
    d("#lab-results")?.classList.toggle("is-list", VIEW === "list");
    return;
  }
  const lvb = ev.target.closest("[data-level]");
  if (lvb) { W("mckay-level", lvb.dataset.level); $(); return; }
  const fw = ev.target.closest(".v3-popular [data-find]");
  if (fw) { openFinder(fw.dataset.find); return; }
  const us = ev.target.closest('[data-action="unit-sheet"]');
  if (us) {
    const [gr, u] = us.dataset.unit.split(":").map(Number);
    let n = 0;
    try { await HS.ensure(g.filter((o) => o.grade === gr && o.unit === u && o.module === "hs").map((o) => o.id)); } catch {}
    for (const lab of g.filter((o) => o.grade === gr && o.unit === u)) if (SH.addStatic(...SHM(lab, { thumb: lab.module === "hs" ? null : thumbOf(lab) })) > 0) n++;
    SH.updateBadge();
    T(n ? `이 단원의 실험 ${n}개를 학습지에 담았어요. 위쪽 ‘학습지’에서 볼 수 있어요.` : "이 단원의 실험은 이미 모두 학습지에 있어요.");
  }
});
