// McKay Math Atelier — 오프라인 지원(서비스 워커)
// 원칙: 인터넷이 되면 언제나 새 파일을 먼저 받는다(네트워크 우선). 받은 파일은 보관해 두었다가
// 인터넷이 끊기면 보관본으로 보여 준다. 그래서 사이트를 고쳐 올려도 옛 버전에 갇히지 않는다.
const VERSION = "2026-11-12-advanced-v1";
const CACHE = "atelier-" + VERSION;
const CORE = ["/advanced-math/", "/advanced-math/thumbs/linear.svg", "/advanced-math/thumbs/eigen.svg", "/advanced-math/thumbs/complex.svg", "/advanced-math/thumbs/roots.svg", "/advanced-math/thumbs/taylor.svg", "/advanced-math/thumbs/series.svg", "/lab-chunks/elementary-explore.js", "/lab-chunks/elementary-visuals.js", "/updates/notice.js", "/updates/notice-content.js", "/updates/notice-policy.js", "/updates/notice.css", "/updates/", "/course-gif/c21.gif", "/course-gif/c21.png", "/course-gif/c22.gif", "/course-gif/c22.png", "/course-gif/c23.gif", "/course-gif/c23.png", "/course-gif/c24.gif", "/course-gif/c24.png", "/course-gif/c25.gif", "/course-gif/c25.png", "/course-gif/c26.gif", "/course-gif/c26.png", "/lab-chunks/elementary-supplement-lower.js", "/lab-chunks/elementary-supplement-upper.js", "/lab-chunks/elementary-engine.js", "/lab-chunks/elementary-lower.js", "/lab-chunks/elementary-upper.js", "/lab-chunks/elementary.js", "/lab-chunks/circle-math.js", "/lab-chunks/wave-frontiers.js", "/lab-chunks/wave-missions.js", "/lab-chunks/wave-propagation.js", "/lab-chunks/wave-harmonics.js", "/lab-chunks/wave-extras.js", "/lab-chunks/wave-scenes.js", "/lab-chunks/circle-waves.js", "/", "/atelier.js", "/math-lab.css", "/atelier.css", "/atelier-plus/style.css", "/learning-tools/study-tools.css", "/student-view/student-view.css", "/home/home.css", "/home/home.js", "/favicon.svg", "/icon-192.png", "/manifest.webmanifest"];
// 너무 큰 파일은 보관하지 않는다(한 파일 버전 6.5MB)
const SKIP = [/\/solid-classroom\/offline\.html$/];
// 글꼴과 수식 도구(MathJax)는 바뀌지 않으므로 보관본을 먼저 쓴다
const CDN = [/^https:\/\/fonts\.(googleapis|gstatic)\.com\//, /^https:\/\/cdn\.jsdelivr\.net\/npm\/mathjax@3\.2\.2\//];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k.startsWith("atelier-") && k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

async function networkFirst(req) {
  const cache = await caches.open(CACHE);
  const net = fetch(req).then((res) => { if (res.ok && res.type === "basic" && !res.redirected) cache.put(req, res.clone()); return res; });
  const stored = () => cache.match(req, { ignoreSearch: req.mode === "navigate" }).then((hit) => hit || (req.mode === "navigate" ? cache.match("/") : undefined));
  // 교실 와이파이가 느릴 때: 8초가 지나도 응답이 없고 보관본이 있으면 보관본을 쓴다. 보관본이 없으면 계속 기다린다.
  const slow = new Promise((ok) => setTimeout(() => stored().then((hit) => hit && ok(hit)), 8000));
  try { return await Promise.race([net, slow]); }
  catch (err) { const hit = await stored(); if (hit) return hit; throw err; }
}
async function cacheFirst(req) {
  const cache = await caches.open(CACHE), hit = await cache.match(req);
  if (hit) return hit;
  const res = await fetch(req);
  if (res.ok || res.type === "opaque") cache.put(req, res.clone());
  return res;
}
self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin === location.origin) {
    if (SKIP.some((re) => re.test(url.pathname)) || url.pathname === "/sw.js") return;
    e.respondWith(networkFirst(req));
  } else if (CDN.some((re) => re.test(req.url))) {
    e.respondWith(cacheFirst(req));
  }
});
