// 사용자 요청으로 새로 만든 실험 — 같은 id의 기존 실험을 대신한다
import { fmt, frac, piFmt, dist, sub, add, mul, norm, dot, len, cross, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const V = { x: [-7, 7], y: [-5, 5] };
const ang = (v, p, q) => rad2deg(Math.acos(clamp(dot(sub(p, v), sub(q, v)) / (len(sub(p, v)) * len(sub(q, v)) || 1), -1, 1)));
const heading = (p, q) => Math.atan2(q[1] - p[1], q[0] - p[0]);
const COLS = ["a", "b", "c", "e", "f", "d"];

// 꼭짓점 v에서 방향각 a0부터 크기 w만큼(반시계) 부채꼴 조각
function wedge(g, v, a0, w, r, o) {
  const pts = [v]; for (let i = 0; i <= 36; i++) { const t = a0 + (w * i) / 36; pts.push([v[0] + r * Math.cos(t), v[1] + r * Math.sin(t)]); }
  g.poly(pts, { fill: o.color, fo: o.fo ?? 0.55, color: o.color, w: 1.6 });
  if (o.label) { const m = a0 + w / 2; g.text([v[0] + (r + 0.45) * Math.cos(m), v[1] + (r + 0.45) * Math.sin(m)], o.label, { color: o.color, bold: true, size: 13 }); }
}
// 두 방향 사이의 반시계 각(0~2π)과 시작각
function ccwFrom(v, p, q) { const a = heading(v, p), b = heading(v, q); let w = b - a; while (w < 0) w += 2 * Math.PI; while (w >= 2 * Math.PI) w -= 2 * Math.PI; return { a, w }; }
function interior(v, p, q) { const x = ccwFrom(v, p, q); return x.w <= Math.PI ? x : ccwFrom(v, q, p); }

export default [
  {
    id: "polygon-diagonals", grade: 1, unit: 6, lesson: "6.1", title: "n각형의 대각선 — 한 꼭짓점에서, 전체", type: "조작", time: "8분",
    tags: ["다각형", "대각선", "n(n − 3)/2"], color: "#2e79bd", links: ["interior-sum", "m1-points-lines"],
    desc: "꼭짓점의 수를 바꾸며 한 꼭짓점에서 그을 수 있는 대각선과 전체 대각선을 차례로 그려, 전체 대각선의 수가 n(n − 3)/2가 되는 이유를 봅니다.",
    obs: ["한 꼭짓점에서는 자신과 양옆 두 꼭짓점을 뺀 n − 3개의 대각선을 그을 수 있습니다.", "n개의 꼭짓점에서 각각 n − 3개씩 그으면 대각선 하나가 두 번씩 세어집니다.", "그래서 전체 대각선의 수는 n(n − 3)/2입니다."],
    q: "대각선이 35개인 다각형은 몇 각형일까요?",
    formula: "한 꼭짓점에서 n − 3개 · 전체 n(n − 3)/2개",
    en: { title: "Diagonals of an n-gon", desc: "Draw diagonals from one vertex and then all of them to see why there are n(n − 3)/2." },
    view: { x: [-7.5, 7.5], y: [-5, 5] },
    params: [
      { key: "mode", label: "보기", type: "seg", value: "all", options: [["one", "한 꼭짓점에서"], ["all", "전체 대각선"]] },
      { key: "n", label: "꼭짓점의 수 n", min: 3, max: 20, step: 1, value: 8 },
      { key: "v", label: "고른 꼭짓점", min: 1, max: 20, step: 1, value: 1, when: (s) => s.mode === "one" },
      { key: "m", label: "그린 대각선 수", min: 0, max: 170, step: 1, value: 170, when: (s) => s.mode === "all" },
      { key: "color", label: "출발 꼭짓점마다 색 다르게", type: "check", value: true, when: (s) => s.mode === "all" },
    ],
    anim: { key: "m", min: 0, max: 170, speed: 10, label: "하나씩 긋기" },
    derive(s) { const tot = (s.n * (s.n - 3)) / 2; if (s.v > s.n) s.v = 1; if (s.m > tot) s.m = tot; },
    onChange(s, k) { if (k === "n") s.m = (s.n * (s.n - 3)) / 2; },
    draw(s, g) {
      const n = s.n, R = 3.9, C = [-1.6, 0], P = Array.from({ length: n }, (_, i) => [C[0] + R * Math.cos(Math.PI / 2 - (2 * Math.PI * i) / n), C[1] + R * Math.sin(Math.PI / 2 - (2 * Math.PI * i) / n)]);
      g.poly(P, { fill: "b", fo: 0.06, color: "ink", w: 2.4 });
      if (s.mode === "one") {
        const v = s.v - 1;
        for (let j = 0; j < n; j++) if (j !== v && j !== (v + 1) % n && j !== (v + n - 1) % n) g.seg(P[v], P[j], { color: "a", w: 2.6 });
        [(v + 1) % n, (v + n - 1) % n].forEach((j) => g.seg(P[v], P[j], { color: "d", w: 4.5, opacity: 0.6 }));
      } else {
        let c = 0;
        for (let i = 0; i < n; i++) for (let j = i + 2; j < n; j++) { if (i === 0 && j === n - 1) continue; if (c++ >= s.m) break; g.seg(P[i], P[j], { color: s.color ? COLS[i % 6] : "a", w: 1.6, opacity: 0.85 }); }
      }
      P.forEach((p, i) => { g.point(p, "", { color: s.mode === "one" && i === s.v - 1 ? "a" : "ink", r: s.mode === "one" && i === s.v - 1 ? 7 : 4 }); if (n <= 14) g.text([C[0] + (R + 0.45) * Math.cos(Math.PI / 2 - (2 * Math.PI * i) / n), C[1] + (R + 0.45) * Math.sin(Math.PI / 2 - (2 * Math.PI * i) / n)], String(i + 1), { dy: 4, size: 12, color: "muted", bold: true }); });
      const rows = [3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20];
      const cx = [4.6, 5.9, 7.2];
      ["n", "한 꼭짓점", "전체"].forEach((h, c) => g.text([cx[c], 4.4], h, { size: 12, color: "muted", bold: true }));
      rows.forEach((k, i) => [k, k - 3, (k * (k - 3)) / 2].forEach((v, c) => g.text([cx[c], 3.7 - i * 0.66], String(v), { size: 12.5, color: k === n ? "d" : "ink", bold: k === n, mono: true })));
    },
    metrics(s) { const tot = (s.n * (s.n - 3)) / 2; return s.mode === "one" ? [["한 꼭짓점에서의 대각선", `${s.n} − 3 = ${s.n - 3}개`, "key"], ["양옆 꼭짓점과는", "변이므로 대각선이 아님"]] : [["그린 대각선", `${Math.min(s.m, tot)} / ${tot}개`], ["전체 n(n − 3)/2", `${s.n}(${s.n} − 3)/2 = ${tot}개`, "key"]]; },
  },
  {
    id: "sector", grade: 1, unit: 6, lesson: "6.6", title: "부채꼴의 호의 길이와 넓이 — 중심각에 정비례", type: "조작", time: "10분",
    tags: ["부채꼴", "정비례", "호의 길이"], color: "#2e79bd", links: ["pi-estimation", "alg-radian", "m1-circle-terms"],
    desc: "중심각을 바꾸며 호의 길이와 부채꼴의 넓이가 중심각에 정비례함을 그래프로 확인하고, 중심각을 2배·3배 하면 같은 부채꼴이 2개·3개 모인 것과 같음을 봅니다.",
    obs: ["중심각이 2배, 3배가 되면 호의 길이와 넓이도 2배, 3배가 됩니다.", "그래프는 원점을 지나는 직선이므로 정비례입니다.", "넓이는 호의 길이로도 S = ½rl로 구할 수 있습니다."],
    q: "반지름을 2배로 하면 호의 길이와 넓이는 각각 몇 배가 될까요?",
    formula: "l = 2πr × θ/360 · S = πr² × θ/360 · S = ½rl",
    en: { title: "Arc Length and Sector Area Are Proportional", desc: "Arc length and area grow in direct proportion to the central angle." },
    view: { x: [-7.2, 9.2], y: [-5, 5.4] },
    params: [
      { key: "r", label: "반지름 r", min: 1, max: 5, step: 1, value: 3 },
      { key: "t", label: "중심각 θ", min: 10, max: 360, step: 5, value: 60, unit: "°" },
      { key: "k", label: "같은 부채꼴 모으기 (배수)", min: 1, max: 6, step: 1, value: 1 },
    ],
    anim: { key: "t", min: 10, max: 360, speed: 60, label: "중심각 키우기" },
    drags: { T: { at: (s) => { const R = 0.8 * s.r, a = deg(s.t); return [-3.6 + R * Math.cos(a), R * Math.sin(a)]; }, move: (s, p) => { let a = rad2deg(Math.atan2(p[1], p[0] + 3.6)); if (a < 0) a += 360; s.t = Math.max(10, Math.round(a / 5) * 5); } } },
    draw(s, g) {
      const C = [-3.6, 0], R = 0.8 * s.r, th = deg(s.t);
      g.circle(C, R, { color: "muted", w: 1.4, dash: "4 5" });
      for (let k = 0; k < s.k; k++) { const a0 = k * th; if (a0 >= 2 * Math.PI - 1e-9) break; const w = Math.min(th, 2 * Math.PI - a0); const pts = [C]; for (let i = 0; i <= 40; i++) pts.push(add(C, [R * Math.cos(a0 + (w * i) / 40), R * Math.sin(a0 + (w * i) / 40)])); g.poly(pts, { fill: COLS[k % 6], fo: k ? 0.3 : 0.45, color: COLS[k % 6], w: 1.6 }); g.path(pts.slice(1), { color: COLS[k % 6], w: 4.5 }); }
      g.point(C, "O", { color: "ink", r: 4, dx: -12, anchor: "end" });
      g.arc(C, [C[0] + 1, 0], [C[0] + Math.cos(th), Math.sin(th)], { r: 20, color: "ink", label: `${s.t}°`, fo: 0 });
      const X0 = 1.6, X1 = 8.8, Y0 = -4.2, Y1 = 4.4, M = (a, v, max) => [X0 + (a / 360) * (X1 - X0), Y0 + (v / max) * (Y1 - Y0)];
      const lmax = 2 * Math.PI * 5, Smax = Math.PI * 25;
      g.seg([X0, Y0], [X1, Y0], { color: "axis", w: 1.3 }).seg([X0, Y0], [X0, Y1], { color: "axis", w: 1.3 });
      [0, 90, 180, 270, 360].forEach((a) => g.text(M(a, 0, 1), `${a}°`, { dy: 17, size: 11, color: "muted" }));
      g.seg(M(0, 0, 1), M(360, 2 * Math.PI * s.r, lmax), { color: "a", w: 2.6 }).seg(M(0, 0, 1), M(360, Math.PI * s.r * s.r, Smax), { color: "b", w: 2.6 });
      const lt = (2 * Math.PI * s.r * s.t) / 360, St = (Math.PI * s.r * s.r * s.t) / 360;
      g.point(M(s.t, lt, lmax), "", { color: "a", r: 6 }).point(M(s.t, St, Smax), "", { color: "b", r: 6 });
      g.text(M(360, 2 * Math.PI * s.r, lmax), "호의 길이", { dx: -4, dy: -8, anchor: "end", color: "a", bold: true, size: 12 }).text(M(360, Math.PI * s.r * s.r, Smax), "넓이", { dx: -4, dy: 16, anchor: "end", color: "b", bold: true, size: 12 });
      g.text([X0, Y1], "중심각에 따른 변화", { dy: -2, anchor: "start", size: 12, color: "muted", bold: true });
    },
    metrics(s) { const kk = Math.min(s.k, Math.floor(360 / s.t) || 1); const l = `2π × ${s.r} × ${s.t}/360`, S = `π × ${s.r}² × ${s.t}/360`; return [["호의 길이 l", `${l} = ${piFmt((Math.PI * s.r * s.t) / 180)}`], ["넓이 S", `${S} = ${piFmt((Math.PI * s.r * s.r * s.t) / 360)}`, "key"], [`중심각 ${kk}배`, `호 ${kk}배 · 넓이 ${kk}배`], ["½rl", `${piFmt((Math.PI * s.r * s.r * s.t) / 360)} (같음)`]]; },
  },
  {
    id: "revolution", grade: 1, unit: 7, lesson: "7.4", title: "회전체 만들기 — 겉면과 속면 구분", type: "3D", time: "10분",
    tags: ["회전체", "회전축", "단면"], color: "#198574", links: ["cross-section", "calc-volume-slice", "m1-sphere-volume"],
    desc: "평면도형을 회전축 둘레로 돌려 원기둥·원뿔·원뿔대·구와 속이 빈 회전체를 만들고, 바깥쪽 겉면(파랑)·안쪽 속면(보라)·위아래 면(노랑)을 색으로 구분해 봅니다.",
    obs: ["도형이 축에서 떨어져 있으면 가운데가 빈 회전체가 됩니다.", "회전축을 포함하는 평면으로 자른 단면은 축에 대해 선대칭입니다.", "회전축에 수직인 평면으로 자르면 원 또는 가운데가 빈 원(고리)이 나옵니다."],
    q: "직각삼각형의 빗변을 축으로 돌리면 어떤 회전체가 될까요?",
    formula: "직사각형 → 원기둥 · 직각삼각형 → 원뿔 · 사다리꼴 → 원뿔대 · 반원 → 구",
    en: { title: "Solids of Revolution: Outer and Inner Surfaces", desc: "Rotate plane figures about an axis and color outer, inner and cap surfaces." },
    space: true, cam: { yaw: 28, pitch: 20, scale: 56 },
    params: [
      { key: "shape", label: "돌릴 도형", type: "select", value: "tube", options: [["rect", "직사각형 → 원기둥"], ["tri", "직각삼각형 → 원뿔"], ["trap", "사다리꼴 → 원뿔대"], ["semi", "반원 → 구"], ["tube", "축에서 떨어진 직사각형 → 속이 빈 원기둥"], ["ring", "축에서 떨어진 원 → 도넛(원환체)"], ["cup", "ㄴ자 도형 → 컵"]] },
      { key: "t", label: "돌린 각", min: 0, max: 360, step: 5, value: 270, unit: "°" },
      { key: "cut", label: "축을 포함하는 단면 보기", type: "check", value: false },
    ],
    anim: { key: "t", min: 0, max: 360, speed: 70, label: "돌리기" },
    profile(s) {
      const P = { rect: [[0, -1.4], [1.5, -1.4], [1.5, 1.4], [0, 1.4]], tri: [[0, -1.4], [1.7, -1.4], [0, 1.6]], trap: [[0, -1.4], [1.8, -1.4], [0.9, 1.4], [0, 1.4]], semi: Array.from({ length: 25 }, (_, i) => [1.6 * Math.sin((Math.PI * i) / 24), -1.6 * Math.cos((Math.PI * i) / 24)]), tube: [[0.9, -1.4], [1.7, -1.4], [1.7, 1.4], [0.9, 1.4]], ring: Array.from({ length: 28 }, (_, i) => [1.35 + 0.55 * Math.cos((2 * Math.PI * i) / 28), 0.55 * Math.sin((2 * Math.PI * i) / 28)]), cup: [[0, -1.4], [1.7, -1.4], [1.7, 1.4], [1.3, 1.4], [1.3, -1], [0, -1]] }[s.shape];
      // 반시계 방향으로 맞추기
      let a2 = 0; for (let i = 0; i < P.length; i++) { const p = P[i], q = P[(i + 1) % P.length]; a2 += p[0] * q[1] - q[0] * p[1]; }
      return a2 < 0 ? [...P].reverse() : P;
    },
    draw(s, g) {
      const prof = this.profile(s), T = deg(s.t), N = Math.max(2, Math.round(s.t / 10)), R3 = (p, a) => [p[0] * Math.cos(a), p[0] * Math.sin(a), p[1]];
      g.seg([0, 0, -2.4], [0, 0, 2.4], { color: "ink", w: 2, dash: "6 4" }).text([0, 0, 2.55], "회전축", { color: "ink", bold: true, size: 12 });
      for (let e = 0; e < prof.length; e++) {
        const p = prof[e], q = prof[(e + 1) % prof.length], dr = q[0] - p[0], dz = q[1] - p[1], nr = dz;
        if (Math.abs(p[0]) < 1e-6 && Math.abs(q[0]) < 1e-6) continue;
        const kind = Math.abs(nr) < 1e-6 ? "cap" : nr > 0 ? "out" : "in";
        for (let i = 0; i < N; i++) {
          const a0 = (T * i) / N, a1 = (T * (i + 1)) / N, f = [R3(p, a0), R3(q, a0), R3(q, a1), R3(p, a1)];
          const nrm = cross(sub(f[1], f[0]), sub(f[3], f[0])), front = dot(nrm, g.d) < 0;
          const col = kind === "out" ? "b" : kind === "in" ? "e" : "f";
          g.face(f, { fill: col, color: col, fo: front ? 0.55 : 0.18, w: 0.4, stroke: false });
        }
      }
      g.face(prof.map((p) => R3(p, 0)), { fill: "a", color: "a", fo: 0.7, w: 2.4, bias: 2 });
      if (s.t > 0 && s.t < 360) g.face(prof.map((p) => R3(p, T)), { fill: "a", color: "a", fo: 0.35, w: 1.6, bias: 1 });
      if (s.cut) g.face(prof.map((p) => R3([-p[0], p[1]], 0)), { fill: "d", color: "d", fo: 0.5, w: 2, bias: 2 });
    },
    metrics(s) { const nm = { rect: "원기둥", tri: "원뿔", trap: "원뿔대", semi: "구", tube: "속이 빈 원기둥", ring: "원환체(도넛)", cup: "컵 모양" }[s.shape]; const hollow = ["tube", "ring", "cup"].includes(s.shape); return [["회전체", nm, "key"], ["축을 포함하는 단면", "축에 대해 선대칭인 도형"], ["축에 수직인 단면", hollow ? "고리 모양(가운데가 빈 원)" : "원"], ["색", hollow ? "파랑 = 겉면, 보라 = 속면, 노랑 = 위아래 면" : "파랑 = 옆면, 노랑 = 밑면"]]; },
  },
  {
    id: "m1-triangle-exterior", grade: 1, unit: 6, lesson: "6.3", title: "삼각형의 내각과 외각 — 두 내각이 외각으로", type: "조작", time: "10분",
    tags: ["외각", "평행선", "엇각·동위각"], color: "#2e79bd", links: ["exterior-walk", "parallel-angles"],
    desc: "꼭짓점을 고르면 그 꼭짓점의 내각과 외각이 자동으로 그려지고, 이웃하지 않는 두 내각이 평행선의 엇각·동위각을 따라 외각 자리로 옮겨 가 꼭 맞게 채우는 모습을 봅니다.",
    obs: ["한 꼭짓점에서 내각과 외각의 합은 180°입니다.", "평행선을 그으면 한 내각은 엇각으로, 다른 내각은 동위각으로 외각 안에 옮겨집니다.", "그래서 외각은 이웃하지 않는 두 내각의 합과 같습니다."],
    q: "삼각형의 세 외각의 합이 360°임을 이 성질로 설명해 보세요.",
    formula: "(∠C의 외각) = ∠A + ∠B · ∠A + ∠B + ∠C = 180°",
    en: { title: "Exterior Angle of a Triangle", desc: "Pick a vertex; its two remote interior angles slide into the exterior angle." },
    view: V, points: { A: [-1.2, 3.4], B: [-5.2, -2.6], C: [1.4, -2.6] },
    params: [{ key: "at", label: "외각을 볼 꼭짓점", type: "seg", value: "C", options: [["A", "A"], ["B", "B"], ["C", "C"]] }, { key: "t", label: "두 내각 옮기기", min: 0, max: 1, step: 0.01, value: 1, show: (v) => `${Math.round(v * 100)}%` }],
    anim: { key: "t", min: 0, max: 1, speed: 0.45, label: "옮겨 붙이기" },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const Pt = { A: s.A, B: s.B, C: s.C }, order = { A: ["B", "C"], B: ["C", "A"], C: ["A", "B"] }[s.at], X = Pt[s.at], Y = Pt[order[0]], Z = Pt[order[1]];
      // X에서 Z → X 방향으로 연장 (Z에서 X를 지나는 변 ZX의 연장)
      const Dd = add(X, mul(norm(sub(X, Z)), 3.4));
      g.seg(X, Dd, { color: "ink", w: 2, dash: "7 5" });
      g.poly([s.A, s.B, s.C], { fill: "b", fo: 0.05, color: "ink", w: 2.6 });
      const ext = interior(X, Dd, Y), inn = interior(X, Y, Z);
      wedge(g, X, inn.a, inn.w, 0.7, { color: "muted", fo: 0.25, label: `${fmt(rad2deg(inn.w), 0)}°` });
      g.arc(X, add(X, [Math.cos(ext.a), Math.sin(ext.a)]), add(X, [Math.cos(ext.a + ext.w), Math.sin(ext.a + ext.w)]), { r: 78, color: "d", fo: 0.08, label: `외각 ${fmt(rad2deg(ext.w), 1)}°`, lr: 26 });
      // 이웃하지 않는 두 내각: Y의 내각, Z의 내각
      const angY = interior(Y, Z, X), angZ = interior(Z, X, Y);
      // 목표: Z의 내각은 동위각 → X에서 (연장선, X + (Y − Z)) 사이 / Y의 내각은 엇각 → X에서 (X + (Y − Z), Y) 사이
      const E = add(X, sub(Y, Z)), tZ = interior(X, Dd, E), tY = interior(X, E, Y);
      if (s.t > 0.02) g.line(X, E, { color: "f", w: 1.4, dash: "4 5" });
      const tt = (1 - Math.cos(Math.PI * s.t)) / 2;
      const mv = (from, a0, to, a1) => ({ v: lerp(from, to, tt), a: a0 + (((a1 - a0 + 3 * Math.PI) % (2 * Math.PI)) - Math.PI) * tt });
      const mZ = mv(Z, angZ.a, X, tZ.a), mY = mv(Y, angY.a, X, tY.a);
      wedge(g, Z, angZ.a, angZ.w, 0.62, { color: "a", fo: 0.25 });
      wedge(g, Y, angY.a, angY.w, 0.62, { color: "c", fo: 0.25 });
      wedge(g, mZ.v, mZ.a, angZ.w, 0.62 + 0.4 * tt, { color: "a", fo: 0.7, label: `${fmt(rad2deg(angZ.w), 0)}°` });
      wedge(g, mY.v, mY.a, angY.w, 0.62 + 0.4 * tt, { color: "c", fo: 0.7, label: `${fmt(rad2deg(angY.w), 0)}°` });
      ["A", "B", "C"].forEach((k) => { g.point(Pt[k], k, { color: k === s.at ? "d" : "ink", r: k === s.at ? 6.5 : 5 }); g.handle(Pt[k], k); });
    },
    metrics(s) { const Pt = { A: s.A, B: s.B, C: s.C }, order = { A: ["B", "C"], B: ["C", "A"], C: ["A", "B"] }[s.at], X = Pt[s.at], Y = Pt[order[0]], Z = Pt[order[1]]; const y = ang(Y, Z, X), z = ang(Z, X, Y), x = ang(X, Y, Z); return [[`∠${s.at}의 내각`, `${fmt(x, 1)}°`], [`∠${s.at}의 외각`, `180° − ${fmt(x, 1)}° = ${fmt(180 - x, 1)}°`, "key"], [`∠${order[0]} + ∠${order[1]}`, `${fmt(y, 1)}° + ${fmt(z, 1)}° = ${fmt(y + z, 1)}°`]]; },
  },
  {
    id: "m1-why-five", grade: 1, unit: 7, lesson: "7.2", title: "정다면체는 왜 5가지뿐일까?", type: "조작", time: "10분",
    tags: ["정다면체", "꼭짓점에 모인 각", "360°"], color: "#198574", links: ["m1-polyhedra", "lab-tessellation"],
    desc: "한 꼭짓점에 정다각형을 q개 모아 붙이고, 각의 합이 360°보다 작을 때만 입체로 접어 올릴 수 있음을 확인합니다. 안 되는 경우는 왜 안 되는지 그림과 설명으로 봅니다.",
    obs: ["입체의 꼭짓점을 만들려면 한 점에 면이 3개 이상 모여야 하고, 각의 합이 360°보다 작아야 틈을 접어 올릴 수 있습니다.", "합이 정확히 360°이면 평면이 되어 꼭짓점이 솟아오르지 않습니다.", "합이 360°를 넘으면 면이 겹쳐 접을 수 없습니다. 정육각형 이상은 3개만 모여도 360° 이상입니다."],
    q: "정오각형 4개를 한 꼭짓점에 모으면 어떻게 될까요?",
    formula: "q × (180° − 360°/p) < 360°, q ≥ 3 ⇔ (p − 2)(q − 2) < 4",
    en: { title: "Why Only Five Platonic Solids?", desc: "Angles meeting at a vertex must total less than 360°; see why the other cases fail." },
    view: V,
    params: [{ key: "p", label: "정 p각형", min: 3, max: 8, step: 1, value: 4 }, { key: "q", label: "한 꼭짓점에 모이는 면의 수 q", min: 3, max: 7, step: 1, value: 4 }],
    why(p, q) {
      const inner = 180 - 360 / p, sum = inner * q;
      const name = { "3,3": "정사면체", "3,4": "정팔면체", "3,5": "정이십면체", "4,3": "정육면체", "5,3": "정십이면체" }[`${p},${q}`];
      if (sum < 360 - 1e-9) return { ok: true, sum, text: `${fmt(360 - sum)}°의 틈을 접어 올려 꼭짓점을 만들 수 있어요 → ${name}` };
      if (Math.abs(sum - 360) < 1e-9) return { ok: false, sum, text: "각의 합이 정확히 360°라 평면을 빈틈없이 덮을 뿐, 접어 올릴 틈이 없어 꼭짓점이 생기지 않아요." };
      return { ok: false, sum, text: `각의 합이 ${fmt(sum)}°로 360°를 넘어 ${fmt(sum - 360)}°만큼 면이 겹쳐요. 겹친 면은 접을 수 없어요.` };
    },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const inner = 180 - 360 / s.p, R = Math.min(2.6, 6.5 / s.p + 0.9), C = [-3, -0.3], W = this.why(s.p, s.q);
      for (let k = 0; k < s.q; k++) {
        const a0 = deg(k * inner + 90), pts = [C]; let cur = C, dir = a0;
        for (let i = 0; i < s.p - 1; i++) { cur = add(cur, [R * Math.cos(dir), R * Math.sin(dir)]); pts.push(cur); dir += deg(360 / s.p); }
        const over = (k + 1) * inner > 360 + 1e-9;
        g.poly(pts, { fill: over ? "d" : COLS[k % 5], fo: over ? 0.4 : 0.25, color: over ? "d" : "ink", w: 1.6 });
      }
      if (W.sum < 360 - 1e-9) g.arc(C, [C[0] + Math.cos(deg(90 + W.sum)), C[1] + Math.sin(deg(90 + W.sum))], [C[0], C[1] + 1], { r: 46, color: "c", label: `틈 ${fmt(360 - W.sum)}°` });
      g.point(C, "", { color: "ink" });
      // 전체 경우 표
      const tx = (c) => 3.1 + c * 0.95;
      g.text([tx(0), 4.4], "p＼q", { size: 12, color: "muted", bold: true });
      [3, 4, 5, 6].forEach((q, c) => g.text([tx(c + 1), 4.4], String(q), { size: 12.5, color: q === s.q ? "d" : "muted", bold: true }));
      [3, 4, 5, 6].forEach((p, i) => { const y = 3.6 - i * 0.72; g.text([tx(0), y], String(p), { size: 13, color: p === s.p ? "d" : "ink", bold: true }); [3, 4, 5, 6].forEach((q, c) => { const w = this.why(p, q), sym = w.ok ? "✓" : Math.abs(w.sum - 360) < 1e-9 ? "=" : "✕", on = p === s.p && q === s.q; g.text([tx(c + 1), y], sym, { size: 14, color: on ? "d" : w.ok ? "c" : "muted", bold: true }); if (on) g.circle([tx(c + 1), y + 0.1], 0.3, { color: "d", w: 1.6 }); }); });
      g.text([2.6, 0.4], "✓ 가능 · = 평면(360°) · ✕ 겹침", { anchor: "start", size: 11.5, color: "muted" });
    },
    metrics(s) { const W = this.why(s.p, s.q); return [["한 내각", `180° − 360°/${s.p} = ${fmt(180 - 360 / s.p)}°`], ["모인 각의 합", `${s.q} × ${fmt(180 - 360 / s.p)}° = ${fmt(W.sum)}°`], ["결과", W.ok ? "입체를 만들 수 있음" : "입체를 만들 수 없음", "key"], W.text]; },
  },
];
