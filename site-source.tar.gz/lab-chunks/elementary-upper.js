// Grade 4 to 6 starter extensions. Content descriptors for the shared elementary renderer.
export const EXTRA_UPPER = [
  {
    "id": "elem4-x-place-value",
    "year": 4,
    "title": "네 자리 수의 자리값",
    "desc": "천의 자리 하나는 1000을 뜻합니다. 백의 자리 하나는 100을 뜻하며 남은 두 자리는 0부터 99입니다.",
    "q": "천의 자리 숫자가 1 커지면 수는 얼마나 커질까요?",
    "kind": "number",
    "mode": "place",
    "controls": [
      {
        "key": "a",
        "label": "천의 자리",
        "min": 0,
        "max": 9,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "백의 자리",
        "min": 0,
        "max": 9,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "남은 두 자리",
        "min": 0,
        "max": 99,
        "value": 25,
        "step": 1
      }
    ],
    "obs": [
      "천의 자리 하나는 1000을 뜻합니다.",
      "백의 자리 하나는 100을 뜻하며 남은 두 자리는 0부터 99입니다."
    ],
    "targets": [
      {
        "label": "3425 만들기",
        "instruction": "천의 자리 3 / 백의 자리 4 / 남은 두 자리 25로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4,
          "c": 25
        }
      },
      {
        "label": "천의 자리만 바꾸기",
        "instruction": "천의 자리 4 / 백의 자리 4 / 남은 두 자리 25로 맞추세요.",
        "values": {
          "a": 4,
          "b": 4,
          "c": 25
        }
      }
    ],
    "unit": "thousands"
  },
  {
    "id": "elem4-x-place-zero",
    "year": 4,
    "title": "0이 지키는 자리",
    "desc": "숫자 0은 해당 자리에 묶음이 없음을 나타냅니다. 0을 없애서 다른 숫자를 옮기면 자리값이 달라집니다.",
    "q": "3025에서 백의 자리 0을 빼면 같은 수일까요?",
    "kind": "number",
    "mode": "place",
    "controls": [
      {
        "key": "a",
        "label": "천의 자리",
        "min": 1,
        "max": 9,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "백의 자리",
        "min": 0,
        "max": 9,
        "value": 0,
        "step": 1
      },
      {
        "key": "c",
        "label": "남은 두 자리",
        "min": 0,
        "max": 99,
        "value": 25,
        "step": 1
      }
    ],
    "obs": [
      "숫자 0은 해당 자리에 묶음이 없음을 나타냅니다.",
      "0을 없애서 다른 숫자를 옮기면 자리값이 달라집니다."
    ],
    "targets": [
      {
        "label": "백의 자리가 빈 수",
        "instruction": "천의 자리 3 / 백의 자리 0 / 남은 두 자리 25로 맞추세요.",
        "values": {
          "a": 3,
          "b": 0,
          "c": 25
        }
      },
      {
        "label": "백 묶음을 더한 수",
        "instruction": "천의 자리 3 / 백의 자리 2 / 남은 두 자리 25로 맞추세요.",
        "values": {
          "a": 3,
          "b": 2,
          "c": 25
        }
      }
    ],
    "unit": "thousands"
  },
  {
    "id": "elem4-x-large-compare",
    "year": 4,
    "title": "큰 수는 높은 자리부터 비교",
    "desc": "자리 수가 같으면 가장 높은 자리부터 비교합니다. 앞자리들이 같으면 처음 달라지는 자리의 숫자가 크기를 결정합니다.",
    "q": "34560과 34605는 어느 자리에서 크기가 결정될까요?",
    "kind": "number",
    "mode": "compare",
    "controls": [
      {
        "key": "a",
        "label": "첫째 수",
        "min": 10000,
        "max": 99999,
        "value": 34560,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 수",
        "min": 10000,
        "max": 99999,
        "value": 34605,
        "step": 1
      }
    ],
    "obs": [
      "자리 수가 같으면 가장 높은 자리부터 비교합니다.",
      "앞자리들이 같으면 처음 달라지는 자리의 숫자가 크기를 결정합니다."
    ],
    "targets": [
      {
        "label": "백의 자리 비교",
        "instruction": "첫째 수 34560 / 둘째 수 34605로 맞추세요.",
        "values": {
          "a": 34560,
          "b": 34605
        }
      },
      {
        "label": "십의 자리 비교",
        "instruction": "첫째 수 34560 / 둘째 수 34506로 맞추세요.",
        "values": {
          "a": 34560,
          "b": 34506
        }
      }
    ]
  },
  {
    "id": "elem4-x-addition-order",
    "year": 4,
    "title": "더하는 순서를 바꾸면",
    "desc": "두 수를 더하는 순서를 바꾸어도 합은 같습니다. 숫자의 자리값을 맞추어 같은 단위끼리 더합니다.",
    "q": "두 수를 더하는 순서를 바꾸어도 합이 같을까요?",
    "kind": "number",
    "mode": "add",
    "controls": [
      {
        "key": "a",
        "label": "첫째 수",
        "min": 0,
        "max": 999,
        "value": 248,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 수",
        "min": 0,
        "max": 999,
        "value": 175,
        "step": 1
      }
    ],
    "obs": [
      "두 수를 더하는 순서를 바꾸어도 합은 같습니다.",
      "숫자의 자리값을 맞추어 같은 단위끼리 더합니다."
    ],
    "targets": [
      {
        "label": "248에 175 더하기",
        "instruction": "첫째 수 248 / 둘째 수 175로 맞추세요.",
        "values": {
          "a": 248,
          "b": 175
        }
      },
      {
        "label": "순서 바꾸기",
        "instruction": "첫째 수 175 / 둘째 수 248로 맞추세요.",
        "values": {
          "a": 175,
          "b": 248
        }
      }
    ]
  },
  {
    "id": "elem4-x-subtraction-check",
    "year": 4,
    "title": "뺄셈으로 남은 수 확인",
    "desc": "전체에서 덜어 낸 수를 빼면 남은 수입니다. 남은 수와 덜어 낸 수를 더하면 전체가 됩니다.",
    "q": "전체 500개에서 178개를 쓰면 남은 수는 얼마일까요?",
    "kind": "number",
    "mode": "sub",
    "controls": [
      {
        "key": "a",
        "label": "전체 수",
        "min": 500,
        "max": 999,
        "value": 500,
        "step": 1
      },
      {
        "key": "b",
        "label": "덜어 낸 수",
        "min": 0,
        "max": 499,
        "value": 178,
        "step": 1
      }
    ],
    "obs": [
      "전체에서 덜어 낸 수를 빼면 남은 수입니다.",
      "남은 수와 덜어 낸 수를 더하면 전체가 됩니다."
    ],
    "targets": [
      {
        "label": "178개 덜어 내기",
        "instruction": "전체 수 500 / 덜어 낸 수 178로 맞추세요.",
        "values": {
          "a": 500,
          "b": 178
        }
      },
      {
        "label": "덜어 낸 수를 1 늘리기",
        "instruction": "전체 수 500 / 덜어 낸 수 179로 맞추세요.",
        "values": {
          "a": 500,
          "b": 179
        }
      }
    ]
  },
  {
    "id": "elem4-x-multiply-split",
    "year": 4,
    "title": "곱셈을 나누어 생각하기",
    "desc": "23는 20과 3으로 나눌 수 있습니다. 각 부분의 곱을 더하면 전체의 곱과 같습니다.",
    "q": "23묶음의 12개는 20묶음과 3묶음으로 나누어 셀 수 있을까요?",
    "kind": "number",
    "mode": "mul",
    "controls": [
      {
        "key": "a",
        "label": "묶음 수",
        "min": 10,
        "max": 30,
        "value": 23,
        "step": 1
      },
      {
        "key": "b",
        "label": "한 묶음의 수",
        "min": 2,
        "max": 20,
        "value": 12,
        "step": 1
      }
    ],
    "obs": [
      "23는 20과 3으로 나눌 수 있습니다.",
      "각 부분의 곱을 더하면 전체의 곱과 같습니다."
    ],
    "targets": [
      {
        "label": "23묶음 세기",
        "instruction": "묶음 수 23 / 한 묶음의 수 12로 맞추세요.",
        "values": {
          "a": 23,
          "b": 12
        }
      },
      {
        "label": "20묶음 먼저 세기",
        "instruction": "묶음 수 20 / 한 묶음의 수 12로 맞추세요.",
        "values": {
          "a": 20,
          "b": 12
        }
      }
    ]
  },
  {
    "id": "elem4-x-multiply-balance",
    "year": 4,
    "title": "묶음 수와 묶음 크기 바꾸기",
    "desc": "묶음 수와 한 묶음의 수를 곱하면 전체 수입니다. 한쪽을 두 배로 하고 다른 쪽을 반으로 하면 곱은 같습니다.",
    "q": "한 묶음을 두 배로 하고 묶음 수를 반으로 하면 전체가 달라질까요?",
    "kind": "number",
    "mode": "mul",
    "controls": [
      {
        "key": "a",
        "label": "묶음 수",
        "min": 1,
        "max": 24,
        "value": 6,
        "step": 1
      },
      {
        "key": "b",
        "label": "한 묶음의 수",
        "min": 1,
        "max": 24,
        "value": 8,
        "step": 1
      }
    ],
    "obs": [
      "묶음 수와 한 묶음의 수를 곱하면 전체 수입니다.",
      "한쪽을 두 배로 하고 다른 쪽을 반으로 하면 곱은 같습니다."
    ],
    "targets": [
      {
        "label": "6묶음에 8개씩",
        "instruction": "묶음 수 6 / 한 묶음의 수 8로 맞추세요.",
        "values": {
          "a": 6,
          "b": 8
        }
      },
      {
        "label": "3묶음에 16개씩",
        "instruction": "묶음 수 3 / 한 묶음의 수 16로 맞추세요.",
        "values": {
          "a": 3,
          "b": 16
        }
      }
    ]
  },
  {
    "id": "elem4-x-division-remainder",
    "year": 4,
    "title": "나머지는 나누는 수보다 작게",
    "desc": "몫은 같은 크기의 묶음을 만들 수 있는 수입니다. 나머지가 나누는 수 이상이면 묶음을 하나 더 만들 수 있습니다.",
    "q": "59개를 6개씩 담으면 상자와 남은 물건은 몇 개일까요?",
    "kind": "number",
    "mode": "div",
    "controls": [
      {
        "key": "a",
        "label": "나누어지는 수",
        "min": 0,
        "max": 99,
        "value": 59,
        "step": 1
      },
      {
        "key": "b",
        "label": "나누는 수",
        "min": 2,
        "max": 12,
        "value": 6,
        "step": 1
      }
    ],
    "obs": [
      "몫은 같은 크기의 묶음을 만들 수 있는 수입니다.",
      "나머지가 나누는 수 이상이면 묶음을 하나 더 만들 수 있습니다."
    ],
    "targets": [
      {
        "label": "1개 모자란 묶음",
        "instruction": "나누어지는 수 59 / 나누는 수 6로 맞추세요.",
        "values": {
          "a": 59,
          "b": 6
        }
      },
      {
        "label": "남김없이 담기",
        "instruction": "나누어지는 수 60 / 나누는 수 6로 맞추세요.",
        "values": {
          "a": 60,
          "b": 6
        }
      }
    ]
  },
  {
    "id": "elem4-x-division-zero",
    "year": 4,
    "title": "몫이 0인 나눗셈",
    "desc": "나누어지는 수가 나누는 수보다 작으면 자연수 몫은 0입니다. 이때 물건 수 전체가 나머지입니다.",
    "q": "물건이 한 묶음보다 적으면 몫은 얼마일까요?",
    "kind": "number",
    "mode": "div",
    "controls": [
      {
        "key": "a",
        "label": "물건 수",
        "min": 0,
        "max": 30,
        "value": 7,
        "step": 1
      },
      {
        "key": "b",
        "label": "한 묶음의 수",
        "min": 8,
        "max": 30,
        "value": 12,
        "step": 1
      }
    ],
    "obs": [
      "나누어지는 수가 나누는 수보다 작으면 자연수 몫은 0입니다.",
      "이때 물건 수 전체가 나머지입니다."
    ],
    "targets": [
      {
        "label": "한 묶음보다 적게",
        "instruction": "물건 수 7 / 한 묶음의 수 12로 맞추세요.",
        "values": {
          "a": 7,
          "b": 12
        }
      },
      {
        "label": "한 묶음 완성",
        "instruction": "물건 수 12 / 한 묶음의 수 12로 맞추세요.",
        "values": {
          "a": 12,
          "b": 12
        }
      }
    ]
  },
  {
    "id": "elem4-x-missing-addend",
    "year": 4,
    "title": "빈칸 덧셈을 거꾸로 풀기",
    "desc": "합에서 알고 있는 더할 수를 빼면 빈칸의 수입니다. 찾은 수를 다시 더해 처음의 합이 되는지 확인합니다.",
    "q": "어떤 수에 125를 더해 300이 되었다면 어떤 수는 얼마일까요?",
    "kind": "number",
    "mode": "equation",
    "controls": [
      {
        "key": "a",
        "label": "알고 있는 더할 수",
        "min": 0,
        "max": 200,
        "value": 125,
        "step": 1
      },
      {
        "key": "b",
        "label": "합",
        "min": 200,
        "max": 500,
        "value": 300,
        "step": 1
      }
    ],
    "obs": [
      "합에서 알고 있는 더할 수를 빼면 빈칸의 수입니다.",
      "찾은 수를 다시 더해 처음의 합이 되는지 확인합니다."
    ],
    "targets": [
      {
        "label": "합 300의 빈칸",
        "instruction": "알고 있는 더할 수 125 / 합 300로 맞추세요.",
        "values": {
          "a": 125,
          "b": 300
        }
      },
      {
        "label": "합이 50 커진 경우",
        "instruction": "알고 있는 더할 수 125 / 합 350로 맞추세요.",
        "values": {
          "a": 125,
          "b": 350
        }
      }
    ]
  },
  {
    "id": "elem4-x-fraction-parts",
    "year": 4,
    "title": "전체 하나보다 작은 분수",
    "desc": "분모는 전체를 똑같이 나눈 수입니다. 분자가 분모보다 작으면 전체 하나보다 작은 분수입니다.",
    "q": "7등분한 띠에서 5부분은 전체의 얼마일까요?",
    "kind": "fraction",
    "mode": "show",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 0,
        "max": 7,
        "value": 5,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 7,
        "max": 7,
        "value": 7,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 0,
        "max": 0,
        "value": 0,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      }
    ],
    "obs": [
      "분모는 전체를 똑같이 나눈 수입니다.",
      "분자가 분모보다 작으면 전체 하나보다 작은 분수입니다."
    ],
    "targets": [
      {
        "label": "5/7 나타내기",
        "instruction": "첫째 분자 5 / 첫째 분모 7 / 둘째 분자 0 / 둘째 분모 1로 맞추세요.",
        "values": {
          "a": 5,
          "b": 7,
          "c": 0,
          "d": 1
        }
      },
      {
        "label": "전체 하나 나타내기",
        "instruction": "첫째 분자 7 / 첫째 분모 7 / 둘째 분자 0 / 둘째 분모 1로 맞추세요.",
        "values": {
          "a": 7,
          "b": 7,
          "c": 0,
          "d": 1
        }
      }
    ]
  },
  {
    "id": "elem4-x-improper-mixed",
    "year": 4,
    "title": "가분수를 대분수로 읽기",
    "desc": "분자를 분모로 나누면 전체의 수와 남은 부분을 알 수 있습니다. 11/4는 전체 2개와 3/4를 합친 양입니다.",
    "q": "11/4에는 전체 하나가 몇 개 들어 있을까요?",
    "kind": "fraction",
    "mode": "mixed",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 0,
        "max": 16,
        "value": 11,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 4,
        "max": 4,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 0,
        "max": 0,
        "value": 0,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      }
    ],
    "obs": [
      "분자를 분모로 나누면 전체의 수와 남은 부분을 알 수 있습니다.",
      "11/4는 전체 2개와 3/4를 합친 양입니다."
    ],
    "targets": [
      {
        "label": "2와 3/4 읽기",
        "instruction": "첫째 분자 11 / 첫째 분모 4 / 둘째 분자 0 / 둘째 분모 1로 맞추세요.",
        "values": {
          "a": 11,
          "b": 4,
          "c": 0,
          "d": 1
        }
      },
      {
        "label": "전체 3개 읽기",
        "instruction": "첫째 분자 12 / 첫째 분모 4 / 둘째 분자 0 / 둘째 분모 1로 맞추세요.",
        "values": {
          "a": 12,
          "b": 4,
          "c": 0,
          "d": 1
        }
      }
    ]
  },
  {
    "id": "elem4-x-same-den-add",
    "year": 4,
    "title": "같은 조각끼리 분수 더하기",
    "desc": "같은 분모는 조각의 크기가 같다는 뜻입니다. 같은 크기의 조각 수만 더하므로 분모는 그대로입니다.",
    "q": "2/7과 3/7을 합치면 조각의 크기도 달라질까요?",
    "kind": "fraction",
    "mode": "add",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 0,
        "max": 7,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 7,
        "max": 7,
        "value": 7,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 0,
        "max": 7,
        "value": 3,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 7,
        "max": 7,
        "value": 7,
        "step": 1
      }
    ],
    "obs": [
      "같은 분모는 조각의 크기가 같다는 뜻입니다.",
      "같은 크기의 조각 수만 더하므로 분모는 그대로입니다."
    ],
    "targets": [
      {
        "label": "다섯 조각 합치기",
        "instruction": "첫째 분자 2 / 첫째 분모 7 / 둘째 분자 3 / 둘째 분모 7로 맞추세요.",
        "values": {
          "a": 2,
          "b": 7,
          "c": 3,
          "d": 7
        }
      },
      {
        "label": "전체 하나 합치기",
        "instruction": "첫째 분자 4 / 첫째 분모 7 / 둘째 분자 3 / 둘째 분모 7로 맞추세요.",
        "values": {
          "a": 4,
          "b": 7,
          "c": 3,
          "d": 7
        }
      }
    ]
  },
  {
    "id": "elem4-x-fraction-cross-one",
    "year": 4,
    "title": "분수를 더해 전체 1 넘기기",
    "desc": "조각 수가 분모보다 많으면 합은 전체 하나보다 큽니다. 분모만큼의 조각을 모으면 전체 하나가 됩니다.",
    "q": "5/6과 4/6을 합치면 전체 하나를 넘을까요?",
    "kind": "fraction",
    "mode": "add",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 0,
        "max": 6,
        "value": 5,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 6,
        "max": 6,
        "value": 6,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 0,
        "max": 6,
        "value": 4,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 6,
        "max": 6,
        "value": 6,
        "step": 1
      }
    ],
    "obs": [
      "조각 수가 분모보다 많으면 합은 전체 하나보다 큽니다.",
      "분모만큼의 조각을 모으면 전체 하나가 됩니다."
    ],
    "targets": [
      {
        "label": "9/6 만들기",
        "instruction": "첫째 분자 5 / 첫째 분모 6 / 둘째 분자 4 / 둘째 분모 6로 맞추세요.",
        "values": {
          "a": 5,
          "b": 6,
          "c": 4,
          "d": 6
        }
      },
      {
        "label": "전체 두 개 만들기",
        "instruction": "첫째 분자 6 / 첫째 분모 6 / 둘째 분자 6 / 둘째 분모 6로 맞추세요.",
        "values": {
          "a": 6,
          "b": 6,
          "c": 6,
          "d": 6
        }
      }
    ]
  },
  {
    "id": "elem4-x-same-den-sub",
    "year": 4,
    "title": "분수의 차이는 남은 조각",
    "desc": "같은 크기의 조각에서는 분자끼리 뺍니다. 남은 조각의 크기는 바뀌지 않으므로 분모는 그대로입니다.",
    "q": "7/8에서 3/8을 덜어 내면 몇 조각이 남을까요?",
    "kind": "fraction",
    "mode": "sub",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 4,
        "max": 8,
        "value": 7,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 8,
        "max": 8,
        "value": 8,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 0,
        "max": 4,
        "value": 3,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 8,
        "max": 8,
        "value": 8,
        "step": 1
      }
    ],
    "obs": [
      "같은 크기의 조각에서는 분자끼리 뺍니다.",
      "남은 조각의 크기는 바뀌지 않으므로 분모는 그대로입니다."
    ],
    "targets": [
      {
        "label": "네 조각 남기기",
        "instruction": "첫째 분자 7 / 첫째 분모 8 / 둘째 분자 3 / 둘째 분모 8로 맞추세요.",
        "values": {
          "a": 7,
          "b": 8,
          "c": 3,
          "d": 8
        }
      },
      {
        "label": "모두 덜어 내기",
        "instruction": "첫째 분자 4 / 첫째 분모 8 / 둘째 분자 4 / 둘째 분모 8로 맞추세요.",
        "values": {
          "a": 4,
          "b": 8,
          "c": 4,
          "d": 8
        }
      }
    ]
  },
  {
    "id": "elem4-x-same-den-compare",
    "year": 4,
    "title": "같은 분모의 크기 비교",
    "desc": "분모가 같으면 조각 하나의 크기가 같습니다. 색칠한 조각이 더 많은 분수가 더 큽니다.",
    "q": "분모가 같을 때 어느 부분을 비교하면 될까요?",
    "kind": "fraction",
    "mode": "compare",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 0,
        "max": 9,
        "value": 4,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 9,
        "max": 9,
        "value": 9,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 0,
        "max": 9,
        "value": 7,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 9,
        "max": 9,
        "value": 9,
        "step": 1
      }
    ],
    "obs": [
      "분모가 같으면 조각 하나의 크기가 같습니다.",
      "색칠한 조각이 더 많은 분수가 더 큽니다."
    ],
    "targets": [
      {
        "label": "4/9와 7/9",
        "instruction": "첫째 분자 4 / 첫째 분모 9 / 둘째 분자 7 / 둘째 분모 9로 맞추세요.",
        "values": {
          "a": 4,
          "b": 9,
          "c": 7,
          "d": 9
        }
      },
      {
        "label": "같은 크기 찾기",
        "instruction": "첫째 분자 7 / 첫째 분모 9 / 둘째 분자 7 / 둘째 분모 9로 맞추세요.",
        "values": {
          "a": 7,
          "b": 9,
          "c": 7,
          "d": 9
        }
      }
    ]
  },
  {
    "id": "elem4-x-unit-fraction-compare",
    "year": 4,
    "title": "단위분수는 왜 거꾸로 커질까",
    "desc": "전체의 크기가 같을 때 더 많이 나누면 한 조각은 작아집니다. 분자가 1인 분수는 분모가 클수록 작습니다.",
    "q": "전체를 더 많이 나누면 한 조각의 크기는 어떻게 될까요?",
    "kind": "fraction",
    "mode": "compare",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 10,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 2,
        "max": 10,
        "value": 6,
        "step": 1
      }
    ],
    "obs": [
      "전체의 크기가 같을 때 더 많이 나누면 한 조각은 작아집니다.",
      "분자가 1인 분수는 분모가 클수록 작습니다."
    ],
    "targets": [
      {
        "label": "1/3과 1/6",
        "instruction": "첫째 분자 1 / 첫째 분모 3 / 둘째 분자 1 / 둘째 분모 6로 맞추세요.",
        "values": {
          "a": 1,
          "b": 3,
          "c": 1,
          "d": 6
        }
      },
      {
        "label": "순서를 바꾸어 비교",
        "instruction": "첫째 분자 1 / 첫째 분모 6 / 둘째 분자 1 / 둘째 분모 3로 맞추세요.",
        "values": {
          "a": 1,
          "b": 6,
          "c": 1,
          "d": 3
        }
      }
    ]
  },
  {
    "id": "elem4-x-fraction-one-compare",
    "year": 4,
    "title": "분수를 1과 비교하기",
    "desc": "분자가 분모와 같으면 분수는 1입니다. 분자가 분모보다 크면 1보다 큰 분수입니다.",
    "q": "분자와 분모의 관계만 보고 1보다 큰지 알 수 있을까요?",
    "kind": "fraction",
    "mode": "compare",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 0,
        "max": 12,
        "value": 7,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 6,
        "max": 6,
        "value": 6,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      }
    ],
    "obs": [
      "분자가 분모와 같으면 분수는 1입니다.",
      "분자가 분모보다 크면 1보다 큰 분수입니다."
    ],
    "targets": [
      {
        "label": "1보다 큰 분수",
        "instruction": "첫째 분자 7 / 첫째 분모 6 / 둘째 분자 1 / 둘째 분모 1로 맞추세요.",
        "values": {
          "a": 7,
          "b": 6,
          "c": 1,
          "d": 1
        }
      },
      {
        "label": "1과 같은 분수",
        "instruction": "첫째 분자 6 / 첫째 분모 6 / 둘째 분자 1 / 둘째 분모 1로 맞추세요.",
        "values": {
          "a": 6,
          "b": 6,
          "c": 1,
          "d": 1
        }
      }
    ]
  },
  {
    "id": "elem4-x-acute-angle",
    "year": 4,
    "title": "예각을 찾아라",
    "desc": "0°보다 크고 90°보다 작은 각은 예각입니다. 각의 크기는 두 반직선이 벌어진 정도입니다.",
    "q": "90°보다 작은 각의 크기를 바꾸어 보세요.",
    "kind": "geometry",
    "mode": "angle",
    "controls": [
      {
        "key": "a",
        "label": "각도 °",
        "min": 5,
        "max": 175,
        "value": 45,
        "step": 5
      }
    ],
    "obs": [
      "0°보다 크고 90°보다 작은 각은 예각입니다.",
      "각의 크기는 두 반직선이 벌어진 정도입니다."
    ],
    "targets": [
      {
        "label": "45° 예각",
        "instruction": "각도 ° 45로 맞추세요.",
        "values": {
          "a": 45
        }
      },
      {
        "label": "예각의 끝과 직각",
        "instruction": "각도 ° 90로 맞추세요.",
        "values": {
          "a": 90
        }
      }
    ],
    "focus": "properties"
  },
  {
    "id": "elem4-x-obtuse-angle",
    "year": 4,
    "title": "직각을 지나 둔각으로",
    "desc": "90°보다 크고 180°보다 작은 각은 둔각입니다. 각을 더 벌릴수록 각도기의 숫자가 커집니다.",
    "q": "직각보다 크지만 평각보다 작은 각은 무엇일까요?",
    "kind": "geometry",
    "mode": "angle",
    "controls": [
      {
        "key": "a",
        "label": "각도 °",
        "min": 5,
        "max": 175,
        "value": 120,
        "step": 5
      }
    ],
    "obs": [
      "90°보다 크고 180°보다 작은 각은 둔각입니다.",
      "각을 더 벌릴수록 각도기의 숫자가 커집니다."
    ],
    "targets": [
      {
        "label": "120° 둔각",
        "instruction": "각도 ° 120로 맞추세요.",
        "values": {
          "a": 120
        }
      },
      {
        "label": "150° 둔각",
        "instruction": "각도 ° 150로 맞추세요.",
        "values": {
          "a": 150
        }
      }
    ],
    "focus": "properties"
  },
  {
    "id": "elem4-x-straight-angle",
    "year": 4,
    "title": "평각까지 펼치기",
    "desc": "180°인 각은 두 반직선이 일직선으로 놓인 평각입니다. 평각의 절반은 90°인 직각입니다.",
    "q": "180°로 펼쳐진 두 반직선은 어떤 모양일까요?",
    "kind": "geometry",
    "mode": "angle",
    "controls": [
      {
        "key": "a",
        "label": "각도 °",
        "min": 0,
        "max": 180,
        "value": 180,
        "step": 5
      }
    ],
    "obs": [
      "180°인 각은 두 반직선이 일직선으로 놓인 평각입니다.",
      "평각의 절반은 90°인 직각입니다."
    ],
    "targets": [
      {
        "label": "평각 만들기",
        "instruction": "각도 ° 180로 맞추세요.",
        "values": {
          "a": 180
        }
      },
      {
        "label": "평각의 절반",
        "instruction": "각도 ° 90로 맞추세요.",
        "values": {
          "a": 90
        }
      }
    ],
    "focus": "properties"
  },
  {
    "id": "elem4-x-rectangle-property",
    "year": 4,
    "title": "직사각형에서 정사각형 찾기",
    "desc": "직사각형은 네 각이 모두 직각입니다. 직사각형의 가로와 세로가 같으면 네 변이 같은 정사각형입니다.",
    "q": "직사각형의 가로와 세로가 같아지면 무엇이 될까요?",
    "kind": "geometry",
    "mode": "rectangle",
    "controls": [
      {
        "key": "a",
        "label": "가로",
        "min": 1,
        "max": 8,
        "value": 6,
        "step": 1
      },
      {
        "key": "b",
        "label": "세로",
        "min": 1,
        "max": 8,
        "value": 4,
        "step": 1
      }
    ],
    "obs": [
      "직사각형은 네 각이 모두 직각입니다.",
      "직사각형의 가로와 세로가 같으면 네 변이 같은 정사각형입니다."
    ],
    "targets": [
      {
        "label": "서로 다른 두 길이",
        "instruction": "가로 6 / 세로 4로 맞추세요.",
        "values": {
          "a": 6,
          "b": 4
        }
      },
      {
        "label": "같은 두 길이",
        "instruction": "가로 5 / 세로 5로 맞추세요.",
        "values": {
          "a": 5,
          "b": 5
        }
      }
    ],
    "focus": "properties"
  },
  {
    "id": "elem4-x-triangle-outline",
    "year": 4,
    "title": "삼각형의 높고 낮은 모양",
    "desc": "삼각형은 세 변과 세 꼭짓점을 가진 도형입니다. 높이를 바꾸어도 변의 수와 꼭짓점의 수는 같습니다.",
    "q": "밑변을 그대로 두고 높이를 바꾸면 모양은 어떻게 될까요?",
    "kind": "geometry",
    "mode": "triangle",
    "controls": [
      {
        "key": "a",
        "label": "밑변 길이",
        "min": 2,
        "max": 10,
        "value": 6,
        "step": 1
      },
      {
        "key": "b",
        "label": "높이",
        "min": 1,
        "max": 8,
        "value": 3,
        "step": 1
      }
    ],
    "obs": [
      "삼각형은 세 변과 세 꼭짓점을 가진 도형입니다.",
      "높이를 바꾸어도 변의 수와 꼭짓점의 수는 같습니다."
    ],
    "targets": [
      {
        "label": "낮은 삼각형",
        "instruction": "밑변 길이 6 / 높이 3로 맞추세요.",
        "values": {
          "a": 6,
          "b": 3
        }
      },
      {
        "label": "높은 삼각형",
        "instruction": "밑변 길이 6 / 높이 6로 맞추세요.",
        "values": {
          "a": 6,
          "b": 6
        }
      }
    ],
    "focus": "properties"
  },
  {
    "id": "elem4-x-quarter-turn",
    "year": 4,
    "title": "직각만큼 도형 돌리기",
    "desc": "90° 회전은 한 바퀴의 4분의 1입니다. 한 바퀴를 모두 돌면 처음의 위치와 방향으로 돌아옵니다.",
    "q": "도형을 90° 돌리면 어느 쪽을 향할까요?",
    "kind": "geometry",
    "mode": "rotate",
    "controls": [
      {
        "key": "a",
        "label": "돌린 각도 °",
        "min": 0,
        "max": 360,
        "value": 90,
        "step": 90
      }
    ],
    "obs": [
      "90° 회전은 한 바퀴의 4분의 1입니다.",
      "한 바퀴를 모두 돌면 처음의 위치와 방향으로 돌아옵니다."
    ],
    "targets": [
      {
        "label": "한 번 돌리기",
        "instruction": "돌린 각도 ° 90로 맞추세요.",
        "values": {
          "a": 90
        }
      },
      {
        "label": "한 바퀴 돌리기",
        "instruction": "돌린 각도 ° 360로 맞추세요.",
        "values": {
          "a": 360
        }
      }
    ],
    "focus": "properties"
  },
  {
    "id": "elem4-x-half-turn",
    "year": 4,
    "title": "반 바퀴와 한 바퀴 비교",
    "desc": "반 바퀴는 180°입니다. 180°를 두 번 더한 360°는 한 바퀴입니다.",
    "q": "반 바퀴를 두 번 돌리면 처음 모양으로 돌아올까요?",
    "kind": "geometry",
    "mode": "rotate",
    "controls": [
      {
        "key": "a",
        "label": "돌린 각도 °",
        "min": 0,
        "max": 360,
        "value": 180,
        "step": 90
      }
    ],
    "obs": [
      "반 바퀴는 180°입니다.",
      "180°를 두 번 더한 360°는 한 바퀴입니다."
    ],
    "targets": [
      {
        "label": "반 바퀴",
        "instruction": "돌린 각도 ° 180로 맞추세요.",
        "values": {
          "a": 180
        }
      },
      {
        "label": "반 바퀴 두 번",
        "instruction": "돌린 각도 ° 360로 맞추세요.",
        "values": {
          "a": 360
        }
      }
    ],
    "focus": "properties"
  },
  {
    "id": "elem4-x-mirror-distance",
    "year": 4,
    "title": "거울선에서 같은 거리",
    "desc": "선대칭인 두 점은 대칭축에서 같은 거리만큼 떨어져 있습니다. 대칭축 위의 점은 뒤집어도 제자리에 있습니다.",
    "q": "선을 사이에 두고 마주 보는 점은 얼마나 떨어져 있을까요?",
    "kind": "geometry",
    "mode": "symmetry",
    "controls": [
      {
        "key": "a",
        "label": "가로 위치",
        "min": -4,
        "max": 4,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "세로 위치",
        "min": -3,
        "max": 3,
        "value": 1,
        "step": 1
      },
      {
        "key": "c",
        "label": "대칭축 선택",
        "min": 0,
        "max": 1,
        "value": 0,
        "step": 1
      }
    ],
    "obs": [
      "선대칭인 두 점은 대칭축에서 같은 거리만큼 떨어져 있습니다.",
      "대칭축 위의 점은 뒤집어도 제자리에 있습니다."
    ],
    "targets": [
      {
        "label": "축 밖의 점",
        "instruction": "가로 위치 2 / 세로 위치 1 / 대칭축 선택 0로 맞추세요.",
        "values": {
          "a": 2,
          "b": 1,
          "c": 0
        }
      },
      {
        "label": "축 위의 점",
        "instruction": "가로 위치 0 / 세로 위치 1 / 대칭축 선택 0로 맞추세요.",
        "values": {
          "a": 0,
          "b": 1,
          "c": 0
        }
      }
    ],
    "focus": "properties"
  },
  {
    "id": "elem4-x-mass-unit",
    "year": 4,
    "title": "kg를 g로 바꾸어 읽기",
    "desc": "1 kg은 1000 g입니다. kg 부분을 g으로 바꾼 뒤 나머지 g을 더합니다.",
    "q": "2 kg 350 g은 모두 몇 g일까요?",
    "kind": "measure",
    "mode": "mass",
    "controls": [
      {
        "key": "a",
        "label": "kg 부분",
        "min": 0,
        "max": 8,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "g 부분",
        "min": 0,
        "max": 999,
        "value": 350,
        "step": 1
      }
    ],
    "obs": [
      "1 kg은 1000 g입니다.",
      "kg 부분을 g으로 바꾼 뒤 나머지 g을 더합니다."
    ],
    "targets": [
      {
        "label": "2350 g 읽기",
        "instruction": "kg 부분 2 / g 부분 350로 맞추세요.",
        "values": {
          "a": 2,
          "b": 350
        }
      },
      {
        "label": "g 부분이 0인 무게",
        "instruction": "kg 부분 3 / g 부분 0로 맞추세요.",
        "values": {
          "a": 3,
          "b": 0
        }
      }
    ]
  },
  {
    "id": "elem4-x-capacity-unit",
    "year": 4,
    "title": "L와 mL로 같은 양 읽기",
    "desc": "1 L는 1000 mL입니다. L 부분과 mL 부분을 같은 단위로 바꾸어 합칩니다.",
    "q": "1 L 750 mL는 모두 몇 mL일까요?",
    "kind": "measure",
    "mode": "capacity",
    "controls": [
      {
        "key": "a",
        "label": "L 부분",
        "min": 0,
        "max": 8,
        "value": 1,
        "step": 1
      },
      {
        "key": "b",
        "label": "mL 부분",
        "min": 0,
        "max": 999,
        "value": 750,
        "step": 1
      }
    ],
    "obs": [
      "1 L는 1000 mL입니다.",
      "L 부분과 mL 부분을 같은 단위로 바꾸어 합칩니다."
    ],
    "targets": [
      {
        "label": "1750 mL 읽기",
        "instruction": "L 부분 1 / mL 부분 750로 맞추세요.",
        "values": {
          "a": 1,
          "b": 750
        }
      },
      {
        "label": "2 L를 mL로",
        "instruction": "L 부분 2 / mL 부분 0로 맞추세요.",
        "values": {
          "a": 2,
          "b": 0
        }
      }
    ]
  },
  {
    "id": "elem4-x-length-unit",
    "year": 4,
    "title": "cm 속에 들어 있는 mm",
    "desc": "1 cm는 10 mm입니다. cm의 수가 1 늘면 mm로 나타낸 길이는 10 늘어납니다.",
    "q": "8 cm 6 mm를 mm만으로 나타낼 수 있을까요?",
    "kind": "measure",
    "mode": "length",
    "controls": [
      {
        "key": "a",
        "label": "cm 부분",
        "min": 0,
        "max": 20,
        "value": 8,
        "step": 1
      },
      {
        "key": "b",
        "label": "mm 부분",
        "min": 0,
        "max": 9,
        "value": 6,
        "step": 1
      }
    ],
    "obs": [
      "1 cm는 10 mm입니다.",
      "cm의 수가 1 늘면 mm로 나타낸 길이는 10 늘어납니다."
    ],
    "targets": [
      {
        "label": "86 mm 읽기",
        "instruction": "cm 부분 8 / mm 부분 6로 맞추세요.",
        "values": {
          "a": 8,
          "b": 6
        }
      },
      {
        "label": "cm만 1 늘리기",
        "instruction": "cm 부분 9 / mm 부분 6로 맞추세요.",
        "values": {
          "a": 9,
          "b": 6
        }
      }
    ]
  },
  {
    "id": "elem4-x-elapsed-hour",
    "year": 4,
    "title": "시간이 지나 다음 시각으로",
    "desc": "60분이 모이면 1시간이 됩니다. 분의 합이 60을 넘으면 시 부분을 올려 읽습니다.",
    "q": "10시 45분에서 30분이 지나면 몇 시 몇 분일까요?",
    "kind": "measure",
    "mode": "time",
    "controls": [
      {
        "key": "a",
        "label": "시",
        "min": 0,
        "max": 23,
        "value": 10,
        "step": 1
      },
      {
        "key": "b",
        "label": "분",
        "min": 0,
        "max": 59,
        "value": 45,
        "step": 1
      },
      {
        "key": "c",
        "label": "지나는 분",
        "min": 0,
        "max": 180,
        "value": 30,
        "step": 1
      }
    ],
    "obs": [
      "60분이 모이면 1시간이 됩니다.",
      "분의 합이 60을 넘으면 시 부분을 올려 읽습니다."
    ],
    "targets": [
      {
        "label": "정각을 넘는 30분",
        "instruction": "시 10 / 분 45 / 지나는 분 30로 맞추세요.",
        "values": {
          "a": 10,
          "b": 45,
          "c": 30
        }
      },
      {
        "label": "한 시간 뒤",
        "instruction": "시 10 / 분 45 / 지나는 분 60로 맞추세요.",
        "values": {
          "a": 10,
          "b": 45,
          "c": 60
        }
      }
    ],
    "unit": "elapsed-clock"
  },
  {
    "id": "elem4-x-clock-between",
    "year": 4,
    "title": "시침은 두 숫자 사이에도 있어요",
    "desc": "분침이 움직이는 동안 시침도 조금씩 움직입니다. 30분이 지나면 시침은 다음 숫자까지의 절반을 갑니다.",
    "q": "6시 30분의 짧은바늘은 6에 그대로 있을까요?",
    "kind": "measure",
    "mode": "clock",
    "controls": [
      {
        "key": "a",
        "label": "시",
        "min": 1,
        "max": 12,
        "value": 6,
        "step": 1
      },
      {
        "key": "b",
        "label": "분",
        "min": 0,
        "max": 55,
        "value": 30,
        "step": 1
      }
    ],
    "obs": [
      "분침이 움직이는 동안 시침도 조금씩 움직입니다.",
      "30분이 지나면 시침은 다음 숫자까지의 절반을 갑니다."
    ],
    "targets": [
      {
        "label": "6시 30분",
        "instruction": "시 6 / 분 30로 맞추세요.",
        "values": {
          "a": 6,
          "b": 30
        }
      },
      {
        "label": "6시 정각",
        "instruction": "시 6 / 분 0로 맞추세요.",
        "values": {
          "a": 6,
          "b": 0
        }
      }
    ]
  },
  {
    "id": "elem4-x-bar-survey",
    "year": 4,
    "title": "막대그래프로 선택 수 비교",
    "desc": "막대의 높이는 선택한 수를 나타냅니다. 같은 눈금을 쓰면 막대 길이로 수의 크기를 비교할 수 있습니다.",
    "q": "가장 긴 막대는 어떤 선택을 뜻할까요?",
    "kind": "chart",
    "mode": "bar",
    "controls": [
      {
        "key": "a",
        "label": "사과 선택",
        "min": 0,
        "max": 20,
        "value": 8,
        "step": 1
      },
      {
        "key": "b",
        "label": "배 선택",
        "min": 0,
        "max": 20,
        "value": 5,
        "step": 1
      },
      {
        "key": "c",
        "label": "포도 선택",
        "min": 0,
        "max": 20,
        "value": 3,
        "step": 1
      }
    ],
    "obs": [
      "막대의 높이는 선택한 수를 나타냅니다.",
      "같은 눈금을 쓰면 막대 길이로 수의 크기를 비교할 수 있습니다."
    ],
    "targets": [
      {
        "label": "선택 차이 읽기",
        "instruction": "사과 선택 8 / 배 선택 5 / 포도 선택 3로 맞추세요.",
        "values": {
          "a": 8,
          "b": 5,
          "c": 3
        }
      },
      {
        "label": "두 선택이 같게",
        "instruction": "사과 선택 8 / 배 선택 8 / 포도 선택 3로 맞추세요.",
        "values": {
          "a": 8,
          "b": 8,
          "c": 3
        }
      }
    ]
  },
  {
    "id": "elem4-x-line-change",
    "year": 4,
    "title": "꺾은선에서 늘어난 양 읽기",
    "desc": "점의 높이는 각 순서의 값을 나타냅니다. 선이 올라가면 값이 늘고 내려가면 값이 줄어듭니다.",
    "q": "값이 늘어나는 구간과 줄어드는 구간을 찾아보세요.",
    "kind": "chart",
    "mode": "line",
    "controls": [
      {
        "key": "a",
        "label": "첫째 날 기록",
        "min": 0,
        "max": 20,
        "value": 4,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 날 기록",
        "min": 0,
        "max": 20,
        "value": 9,
        "step": 1
      },
      {
        "key": "c",
        "label": "셋째 날 기록",
        "min": 0,
        "max": 20,
        "value": 7,
        "step": 1
      }
    ],
    "obs": [
      "점의 높이는 각 순서의 값을 나타냅니다.",
      "선이 올라가면 값이 늘고 내려가면 값이 줄어듭니다."
    ],
    "targets": [
      {
        "label": "늘다가 줄기",
        "instruction": "첫째 날 기록 4 / 둘째 날 기록 9 / 셋째 날 기록 7로 맞추세요.",
        "values": {
          "a": 4,
          "b": 9,
          "c": 7
        }
      },
      {
        "label": "계속 늘기",
        "instruction": "첫째 날 기록 4 / 둘째 날 기록 7 / 셋째 날 기록 10로 맞추세요.",
        "values": {
          "a": 4,
          "b": 7,
          "c": 10
        }
      }
    ]
  },
  {
    "id": "elem4-x-add-pattern",
    "year": 4,
    "title": "같은 수만큼 늘어나는 규칙",
    "desc": "앞의 수에 같은 수를 계속 더하는 규칙입니다. 이웃한 두 수의 차이는 일정합니다.",
    "q": "처음 3에서 4씩 늘리면 어떤 수들이 나올까요?",
    "kind": "sequence",
    "mode": "add",
    "controls": [
      {
        "key": "a",
        "label": "처음 수",
        "min": 0,
        "max": 20,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "늘어나는 수",
        "min": 1,
        "max": 10,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "나타낼 항 수",
        "min": 3,
        "max": 8,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "앞의 수에 같은 수를 계속 더하는 규칙입니다.",
      "이웃한 두 수의 차이는 일정합니다."
    ],
    "targets": [
      {
        "label": "4씩 늘리기",
        "instruction": "처음 수 3 / 늘어나는 수 4 / 나타낼 항 수 5로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4,
          "c": 5
        }
      },
      {
        "label": "차이만 바꾸기",
        "instruction": "처음 수 3 / 늘어나는 수 2 / 나타낼 항 수 5로 맞추세요.",
        "values": {
          "a": 3,
          "b": 2,
          "c": 5
        }
      }
    ]
  },
  {
    "id": "elem4-x-double-pattern",
    "year": 4,
    "title": "곱해서 자라는 수의 규칙",
    "desc": "앞의 수에 같은 수를 계속 곱합니다. 같은 수를 더하는 규칙과는 이웃한 수의 차이가 다릅니다.",
    "q": "처음 2를 계속 두 배로 하면 얼마나 빨리 커질까요?",
    "kind": "sequence",
    "mode": "mul",
    "controls": [
      {
        "key": "a",
        "label": "처음 수",
        "min": 1,
        "max": 5,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "곱하는 수",
        "min": 2,
        "max": 3,
        "value": 2,
        "step": 1
      },
      {
        "key": "c",
        "label": "나타낼 항 수",
        "min": 3,
        "max": 6,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "앞의 수에 같은 수를 계속 곱합니다.",
      "같은 수를 더하는 규칙과는 이웃한 수의 차이가 다릅니다."
    ],
    "targets": [
      {
        "label": "두 배 규칙",
        "instruction": "처음 수 2 / 곱하는 수 2 / 나타낼 항 수 5로 맞추세요.",
        "values": {
          "a": 2,
          "b": 2,
          "c": 5
        }
      },
      {
        "label": "세 배 규칙",
        "instruction": "처음 수 2 / 곱하는 수 3 / 나타낼 항 수 5로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 5
        }
      }
    ]
  },
  {
    "id": "elem4-x-rule-table",
    "year": 4,
    "title": "표에서 찾는 대응 규칙",
    "desc": "입력에 같은 수를 곱한 뒤 정한 수를 더합니다. 입력이 1 늘면 출력은 곱하는 수만큼 늘어납니다.",
    "q": "입력이 1 늘 때 출력은 얼마나 늘어날까요?",
    "kind": "sequence",
    "mode": "table",
    "controls": [
      {
        "key": "a",
        "label": "처음 더하는 수",
        "min": 0,
        "max": 10,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "입력에 곱하는 수",
        "min": 1,
        "max": 8,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "나타낼 입력 수",
        "min": 3,
        "max": 8,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "입력에 같은 수를 곱한 뒤 정한 수를 더합니다.",
      "입력이 1 늘면 출력은 곱하는 수만큼 늘어납니다."
    ],
    "targets": [
      {
        "label": "3배에 2 더하기",
        "instruction": "처음 더하는 수 2 / 입력에 곱하는 수 3 / 나타낼 입력 수 5로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 5
        }
      },
      {
        "label": "3배만 하기",
        "instruction": "처음 더하는 수 0 / 입력에 곱하는 수 3 / 나타낼 입력 수 5로 맞추세요.",
        "values": {
          "a": 0,
          "b": 3,
          "c": 5
        }
      }
    ],
    "unit": "offset-step"
  },
  {
    "id": "elem5-x-gcd-tiles",
    "year": 5,
    "title": "가장 큰 같은 묶음 찾기",
    "desc": "두 수를 모두 나누어떨어지게 하는 수는 공약수입니다. 공약수 가운데 가장 큰 수가 최대공약수입니다.",
    "q": "24개와 36개를 남김없이 같은 크기로 묶는 가장 큰 묶음은 무엇일까요?",
    "kind": "number",
    "mode": "gcd",
    "controls": [
      {
        "key": "a",
        "label": "첫째 수",
        "min": 1,
        "max": 60,
        "value": 24,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 수",
        "min": 1,
        "max": 60,
        "value": 36,
        "step": 1
      }
    ],
    "obs": [
      "두 수를 모두 나누어떨어지게 하는 수는 공약수입니다.",
      "공약수 가운데 가장 큰 수가 최대공약수입니다."
    ],
    "targets": [
      {
        "label": "24와 36 묶기",
        "instruction": "첫째 수 24 / 둘째 수 36로 맞추세요.",
        "values": {
          "a": 24,
          "b": 36
        }
      },
      {
        "label": "서로소 살펴보기",
        "instruction": "첫째 수 8 / 둘째 수 15로 맞추세요.",
        "values": {
          "a": 8,
          "b": 15
        }
      }
    ]
  },
  {
    "id": "elem5-x-gcd-divides",
    "year": 5,
    "title": "한 수가 다른 수의 약수일 때",
    "desc": "한 수가 다른 수의 약수이면 작은 수가 최대공약수입니다. 최대공약수는 두 수 가운데 작은 수보다 클 수 없습니다.",
    "q": "12와 48의 최대공약수는 왜 12일까요?",
    "kind": "number",
    "mode": "gcd",
    "controls": [
      {
        "key": "a",
        "label": "첫째 수",
        "min": 1,
        "max": 30,
        "value": 12,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 수",
        "min": 1,
        "max": 90,
        "value": 48,
        "step": 1
      }
    ],
    "obs": [
      "한 수가 다른 수의 약수이면 작은 수가 최대공약수입니다.",
      "최대공약수는 두 수 가운데 작은 수보다 클 수 없습니다."
    ],
    "targets": [
      {
        "label": "작은 수가 약수",
        "instruction": "첫째 수 12 / 둘째 수 48로 맞추세요.",
        "values": {
          "a": 12,
          "b": 48
        }
      },
      {
        "label": "약수가 아닌 작은 수",
        "instruction": "첫째 수 12 / 둘째 수 50로 맞추세요.",
        "values": {
          "a": 12,
          "b": 50
        }
      }
    ]
  },
  {
    "id": "elem5-x-lcm-meet",
    "year": 5,
    "title": "서로 다른 주기가 만나는 수",
    "desc": "두 수의 배수에 함께 들어 있는 수는 공배수입니다. 양의 공배수 가운데 가장 작은 수가 최소공배수입니다.",
    "q": "4씩 세기와 6씩 세기가 처음 만나는 양수는 무엇일까요?",
    "kind": "number",
    "mode": "lcm",
    "controls": [
      {
        "key": "a",
        "label": "첫째 묶음 크기",
        "min": 1,
        "max": 15,
        "value": 4,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 묶음 크기",
        "min": 1,
        "max": 15,
        "value": 6,
        "step": 1
      }
    ],
    "obs": [
      "두 수의 배수에 함께 들어 있는 수는 공배수입니다.",
      "양의 공배수 가운데 가장 작은 수가 최소공배수입니다."
    ],
    "targets": [
      {
        "label": "4와 6의 공통 배수",
        "instruction": "첫째 묶음 크기 4 / 둘째 묶음 크기 6로 맞추세요.",
        "values": {
          "a": 4,
          "b": 6
        }
      },
      {
        "label": "서로소 두 수",
        "instruction": "첫째 묶음 크기 5 / 둘째 묶음 크기 7로 맞추세요.",
        "values": {
          "a": 5,
          "b": 7
        }
      }
    ]
  },
  {
    "id": "elem5-x-lcm-package",
    "year": 5,
    "title": "묶음 포장을 모두 맞추기",
    "desc": "최소공배수는 두 포장 단위를 모두 맞추는 가장 작은 전체 수입니다. 한 포장 단위가 다른 포장 단위의 배수이면 큰 수가 답입니다.",
    "q": "6개 묶음과 8개 묶음으로 모두 남김없이 포장할 최소 개수는 얼마일까요?",
    "kind": "number",
    "mode": "lcm",
    "controls": [
      {
        "key": "a",
        "label": "첫째 포장 수",
        "min": 1,
        "max": 15,
        "value": 6,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 포장 수",
        "min": 1,
        "max": 15,
        "value": 8,
        "step": 1
      }
    ],
    "obs": [
      "최소공배수는 두 포장 단위를 모두 맞추는 가장 작은 전체 수입니다.",
      "한 포장 단위가 다른 포장 단위의 배수이면 큰 수가 답입니다."
    ],
    "targets": [
      {
        "label": "6개와 8개 포장",
        "instruction": "첫째 포장 수 6 / 둘째 포장 수 8로 맞추세요.",
        "values": {
          "a": 6,
          "b": 8
        }
      },
      {
        "label": "한쪽이 다른 쪽의 배수",
        "instruction": "첫째 포장 수 4 / 둘째 포장 수 12로 맞추세요.",
        "values": {
          "a": 4,
          "b": 12
        }
      }
    ]
  },
  {
    "id": "elem5-x-round-ten",
    "year": 5,
    "title": "반올림이 바뀌는 경계",
    "desc": "십의 자리까지 나타낼 때는 일의 자리 숫자를 봅니다. 일의 자리가 5 이상이면 십의 자리 수를 1 올립니다.",
    "q": "124와 125를 십의 자리까지 나타내면 왜 다른 수가 될까요?",
    "kind": "number",
    "mode": "round",
    "controls": [
      {
        "key": "a",
        "label": "반올림할 수",
        "min": 100,
        "max": 999,
        "value": 124,
        "step": 1
      },
      {
        "key": "b",
        "label": "반올림 단위",
        "min": 10,
        "max": 10,
        "value": 10,
        "step": 1
      }
    ],
    "obs": [
      "십의 자리까지 나타낼 때는 일의 자리 숫자를 봅니다.",
      "일의 자리가 5 이상이면 십의 자리 수를 1 올립니다."
    ],
    "targets": [
      {
        "label": "경계 바로 아래",
        "instruction": "반올림할 수 124 / 반올림 단위 10로 맞추세요.",
        "values": {
          "a": 124,
          "b": 10
        }
      },
      {
        "label": "경계에 도착",
        "instruction": "반올림할 수 125 / 반올림 단위 10로 맞추세요.",
        "values": {
          "a": 125,
          "b": 10
        }
      }
    ]
  },
  {
    "id": "elem5-x-round-hundred",
    "year": 5,
    "title": "어림으로 큰 수 비교",
    "desc": "백의 자리까지 나타낼 때는 십의 자리 숫자를 봅니다. 어림한 수가 같아도 원래 수는 서로 다를 수 있습니다.",
    "q": "149와 150을 백의 자리까지 반올림하면 어떻게 될까요?",
    "kind": "number",
    "mode": "round",
    "controls": [
      {
        "key": "a",
        "label": "반올림할 수",
        "min": 100,
        "max": 999,
        "value": 149,
        "step": 1
      },
      {
        "key": "b",
        "label": "반올림 단위",
        "min": 100,
        "max": 100,
        "value": 100,
        "step": 1
      }
    ],
    "obs": [
      "백의 자리까지 나타낼 때는 십의 자리 숫자를 봅니다.",
      "어림한 수가 같아도 원래 수는 서로 다를 수 있습니다."
    ],
    "targets": [
      {
        "label": "150보다 1 작게",
        "instruction": "반올림할 수 149 / 반올림 단위 100로 맞추세요.",
        "values": {
          "a": 149,
          "b": 100
        }
      },
      {
        "label": "반올림 경계",
        "instruction": "반올림할 수 150 / 반올림 단위 100로 맞추세요.",
        "values": {
          "a": 150,
          "b": 100
        }
      }
    ]
  },
  {
    "id": "elem5-x-multiples-distance",
    "year": 5,
    "title": "배수 사이의 간격",
    "desc": "어떤 수에 자연수를 곱해 얻는 수가 그 수의 배수입니다. 곱할 자연수가 1 커지면 배수는 기준 수만큼 커집니다.",
    "q": "7의 배수는 이웃한 수끼리 얼마나 차이 날까요?",
    "kind": "number",
    "mode": "multiple",
    "controls": [
      {
        "key": "a",
        "label": "배수의 기준 수",
        "min": 2,
        "max": 12,
        "value": 7,
        "step": 1
      },
      {
        "key": "b",
        "label": "곱할 자연수",
        "min": 1,
        "max": 10,
        "value": 6,
        "step": 1
      }
    ],
    "obs": [
      "어떤 수에 자연수를 곱해 얻는 수가 그 수의 배수입니다.",
      "곱할 자연수가 1 커지면 배수는 기준 수만큼 커집니다."
    ],
    "targets": [
      {
        "label": "7의 여섯 배",
        "instruction": "배수의 기준 수 7 / 곱할 자연수 6로 맞추세요.",
        "values": {
          "a": 7,
          "b": 6
        }
      },
      {
        "label": "다음 배수",
        "instruction": "배수의 기준 수 7 / 곱할 자연수 7로 맞추세요.",
        "values": {
          "a": 7,
          "b": 7
        }
      }
    ]
  },
  {
    "id": "elem5-x-equivalent-expand",
    "year": 5,
    "title": "같은 크기로 조각 수 늘리기",
    "desc": "분자와 분모에 같은 자연수를 곱해도 분수의 크기는 같습니다. 전체를 더 잘게 나누면 조각 수는 늘어도 색칠한 길이는 같습니다.",
    "q": "2/3과 6/9는 조각 수가 다른데 왜 같을까요?",
    "kind": "fraction",
    "mode": "equivalent",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 5,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 10,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 12,
        "value": 6,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 2,
        "max": 15,
        "value": 9,
        "step": 1
      }
    ],
    "obs": [
      "분자와 분모에 같은 자연수를 곱해도 분수의 크기는 같습니다.",
      "전체를 더 잘게 나누면 조각 수는 늘어도 색칠한 길이는 같습니다."
    ],
    "targets": [
      {
        "label": "3배로 잘게 나누기",
        "instruction": "첫째 분자 2 / 첫째 분모 3 / 둘째 분자 6 / 둘째 분모 9로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 6,
          "d": 9
        }
      },
      {
        "label": "2배로 잘게 나누기",
        "instruction": "첫째 분자 2 / 첫째 분모 3 / 둘째 분자 4 / 둘째 분모 6로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 4,
          "d": 6
        }
      }
    ]
  },
  {
    "id": "elem5-x-equivalent-reduce",
    "year": 5,
    "title": "약분해서 간단하게 읽기",
    "desc": "분자와 분모를 같은 공약수로 나누면 크기가 같은 분수가 됩니다. 분자와 분모의 공약수가 1뿐인 분수를 기약분수라고 합니다.",
    "q": "8/12를 같은 크기의 더 간단한 분수로 나타내세요.",
    "kind": "fraction",
    "mode": "equivalent",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 12,
        "value": 8,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 16,
        "value": 12,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 8,
        "value": 2,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 2,
        "max": 10,
        "value": 3,
        "step": 1
      }
    ],
    "obs": [
      "분자와 분모를 같은 공약수로 나누면 크기가 같은 분수가 됩니다.",
      "분자와 분모의 공약수가 1뿐인 분수를 기약분수라고 합니다."
    ],
    "targets": [
      {
        "label": "8/12와 2/3",
        "instruction": "첫째 분자 8 / 첫째 분모 12 / 둘째 분자 2 / 둘째 분모 3로 맞추세요.",
        "values": {
          "a": 8,
          "b": 12,
          "c": 2,
          "d": 3
        }
      },
      {
        "label": "6/10과 3/5",
        "instruction": "첫째 분자 6 / 첫째 분모 10 / 둘째 분자 3 / 둘째 분모 5로 맞추세요.",
        "values": {
          "a": 6,
          "b": 10,
          "c": 3,
          "d": 5
        }
      }
    ]
  },
  {
    "id": "elem5-x-fraction-cross-compare",
    "year": 5,
    "title": "분모가 다른 분수 비교",
    "desc": "분모가 다르면 같은 크기의 조각으로 통분해 비교할 수 있습니다. 분모가 같아진 뒤에는 분자의 크기를 비교합니다.",
    "q": "3/4와 5/6 중 어느 분수가 더 클까요?",
    "kind": "fraction",
    "mode": "compare",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 8,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 10,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 8,
        "value": 5,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 2,
        "max": 10,
        "value": 6,
        "step": 1
      }
    ],
    "obs": [
      "분모가 다르면 같은 크기의 조각으로 통분해 비교할 수 있습니다.",
      "분모가 같아진 뒤에는 분자의 크기를 비교합니다."
    ],
    "targets": [
      {
        "label": "3/4와 5/6",
        "instruction": "첫째 분자 3 / 첫째 분모 4 / 둘째 분자 5 / 둘째 분모 6로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4,
          "c": 5,
          "d": 6
        }
      },
      {
        "label": "크기가 같은 다른 표현",
        "instruction": "첫째 분자 3 / 첫째 분모 4 / 둘째 분자 6 / 둘째 분모 8로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4,
          "c": 6,
          "d": 8
        }
      }
    ]
  },
  {
    "id": "elem5-x-unit-fraction-sum",
    "year": 5,
    "title": "서로 다른 단위분수 더하기",
    "desc": "크기가 다른 조각은 그대로 개수만 더할 수 없습니다. 같은 크기의 조각으로 통분한 뒤 분자를 더합니다.",
    "q": "1/2와 1/3은 왜 2/5가 아닐까요?",
    "kind": "fraction",
    "mode": "add",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 8,
        "value": 2,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 2,
        "max": 8,
        "value": 3,
        "step": 1
      }
    ],
    "obs": [
      "크기가 다른 조각은 그대로 개수만 더할 수 없습니다.",
      "같은 크기의 조각으로 통분한 뒤 분자를 더합니다."
    ],
    "targets": [
      {
        "label": "1/2와 1/3",
        "instruction": "첫째 분자 1 / 첫째 분모 2 / 둘째 분자 1 / 둘째 분모 3로 맞추세요.",
        "values": {
          "a": 1,
          "b": 2,
          "c": 1,
          "d": 3
        }
      },
      {
        "label": "1/4와 1/6",
        "instruction": "첫째 분자 1 / 첫째 분모 4 / 둘째 분자 1 / 둘째 분모 6로 맞추세요.",
        "values": {
          "a": 1,
          "b": 4,
          "c": 1,
          "d": 6
        }
      }
    ]
  },
  {
    "id": "elem5-x-unlike-add",
    "year": 5,
    "title": "통분해서 합 만들기",
    "desc": "분모의 공배수를 공통 분모로 삼을 수 있습니다. 합이 전체 하나를 넘으면 대분수로도 읽을 수 있습니다.",
    "q": "2/3과 3/4를 합하면 전체 1보다 얼마나 클까요?",
    "kind": "fraction",
    "mode": "add",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 5,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 8,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 5,
        "value": 3,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 2,
        "max": 8,
        "value": 4,
        "step": 1
      }
    ],
    "obs": [
      "분모의 공배수를 공통 분모로 삼을 수 있습니다.",
      "합이 전체 하나를 넘으면 대분수로도 읽을 수 있습니다."
    ],
    "targets": [
      {
        "label": "분모 12로 통분",
        "instruction": "첫째 분자 2 / 첫째 분모 3 / 둘째 분자 3 / 둘째 분모 4로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 3,
          "d": 4
        }
      },
      {
        "label": "전체 1이 되는 합",
        "instruction": "첫째 분자 1 / 첫째 분모 3 / 둘째 분자 2 / 둘째 분모 3로 맞추세요.",
        "values": {
          "a": 1,
          "b": 3,
          "c": 2,
          "d": 3
        }
      }
    ]
  },
  {
    "id": "elem5-x-unlike-sub",
    "year": 5,
    "title": "통분해서 차이 찾기",
    "desc": "빼는 두 분수를 같은 분모로 나타내면 같은 크기의 조각을 비교할 수 있습니다. 분모는 그대로 두고 통분한 분자끼리 뺍니다.",
    "q": "2/3에서 1/4을 덜어 내면 얼마일까요?",
    "kind": "fraction",
    "mode": "sub",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 2,
        "max": 3,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 3,
        "max": 3,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 2,
        "value": 1,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 4,
        "max": 4,
        "value": 4,
        "step": 1
      }
    ],
    "obs": [
      "빼는 두 분수를 같은 분모로 나타내면 같은 크기의 조각을 비교할 수 있습니다.",
      "분모는 그대로 두고 통분한 분자끼리 뺍니다."
    ],
    "targets": [
      {
        "label": "2/3에서 1/4 빼기",
        "instruction": "첫째 분자 2 / 첫째 분모 3 / 둘째 분자 1 / 둘째 분모 4로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 1,
          "d": 4
        }
      },
      {
        "label": "빼는 수 늘리기",
        "instruction": "첫째 분자 2 / 첫째 분모 3 / 둘째 분자 2 / 둘째 분모 4로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 2,
          "d": 4
        }
      }
    ]
  },
  {
    "id": "elem5-x-mixed-to-improper",
    "year": 5,
    "title": "대분수 안에 있는 조각 세기",
    "desc": "분모만큼의 조각을 모으면 전체 하나입니다. 분자를 분모로 나눈 몫이 자연수 부분이며 나머지가 분자입니다.",
    "q": "17/5는 전체 몇 개와 몇 조각일까요?",
    "kind": "fraction",
    "mode": "mixed",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 0,
        "max": 25,
        "value": 17,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 5,
        "max": 5,
        "value": 5,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 0,
        "max": 0,
        "value": 0,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      }
    ],
    "obs": [
      "분모만큼의 조각을 모으면 전체 하나입니다.",
      "분자를 분모로 나눈 몫이 자연수 부분이며 나머지가 분자입니다."
    ],
    "targets": [
      {
        "label": "3과 2/5 읽기",
        "instruction": "첫째 분자 17 / 첫째 분모 5 / 둘째 분자 0 / 둘째 분모 1로 맞추세요.",
        "values": {
          "a": 17,
          "b": 5,
          "c": 0,
          "d": 1
        }
      },
      {
        "label": "전체만 남는 분수",
        "instruction": "첫째 분자 20 / 첫째 분모 5 / 둘째 분자 0 / 둘째 분모 1로 맞추세요.",
        "values": {
          "a": 20,
          "b": 5,
          "c": 0,
          "d": 1
        }
      }
    ]
  },
  {
    "id": "elem5-x-fraction-times-whole",
    "year": 5,
    "title": "분수 묶음을 여러 번 모으기",
    "desc": "분수에 자연수를 곱하면 같은 분수 묶음을 여러 번 모읍니다. 분자에 자연수를 곱하고 분모는 그대로 둡니다.",
    "q": "2/5을 3번 모으면 전체 하나를 넘을까요?",
    "kind": "fraction",
    "mode": "mul",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 5,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 5,
        "max": 5,
        "value": 5,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 6,
        "value": 3,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      }
    ],
    "obs": [
      "분수에 자연수를 곱하면 같은 분수 묶음을 여러 번 모읍니다.",
      "분자에 자연수를 곱하고 분모는 그대로 둡니다."
    ],
    "targets": [
      {
        "label": "2/5을 세 번",
        "instruction": "첫째 분자 2 / 첫째 분모 5 / 둘째 분자 3 / 둘째 분모 1로 맞추세요.",
        "values": {
          "a": 2,
          "b": 5,
          "c": 3,
          "d": 1
        }
      },
      {
        "label": "전체 하나 만들기",
        "instruction": "첫째 분자 1 / 첫째 분모 5 / 둘째 분자 5 / 둘째 분모 1로 맞추세요.",
        "values": {
          "a": 1,
          "b": 5,
          "c": 5,
          "d": 1
        }
      }
    ]
  },
  {
    "id": "elem5-x-fraction-of-fraction",
    "year": 5,
    "title": "부분의 부분은 얼마일까",
    "desc": "분수의 일부를 구할 때 두 분수를 곱합니다. 분자끼리 곱하고 분모끼리 곱한 뒤 약분할 수 있습니다.",
    "q": "3/4의 2/3만큼은 전체의 얼마일까요?",
    "kind": "fraction",
    "mode": "mul",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 6,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 8,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 6,
        "value": 2,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 2,
        "max": 8,
        "value": 3,
        "step": 1
      }
    ],
    "obs": [
      "분수의 일부를 구할 때 두 분수를 곱합니다.",
      "분자끼리 곱하고 분모끼리 곱한 뒤 약분할 수 있습니다."
    ],
    "targets": [
      {
        "label": "3/4의 2/3",
        "instruction": "첫째 분자 3 / 첫째 분모 4 / 둘째 분자 2 / 둘째 분모 3로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4,
          "c": 2,
          "d": 3
        }
      },
      {
        "label": "절반의 절반",
        "instruction": "첫째 분자 1 / 첫째 분모 2 / 둘째 분자 1 / 둘째 분모 2로 맞추세요.",
        "values": {
          "a": 1,
          "b": 2,
          "c": 1,
          "d": 2
        }
      }
    ]
  },
  {
    "id": "elem5-x-rectangle-area",
    "year": 5,
    "title": "단위넓이를 세어 직사각형 넓이 구하기",
    "desc": "가로 한 줄의 칸 수에 세로 줄 수를 곱하면 전체 칸 수입니다. 직사각형의 넓이는 가로와 세로의 곱입니다.",
    "q": "가로 7과 세로 4인 직사각형에는 단위 정사각형이 몇 개일까요?",
    "kind": "geometry",
    "mode": "rectangle",
    "controls": [
      {
        "key": "a",
        "label": "가로",
        "min": 1,
        "max": 12,
        "value": 7,
        "step": 1
      },
      {
        "key": "b",
        "label": "세로",
        "min": 1,
        "max": 10,
        "value": 4,
        "step": 1
      }
    ],
    "obs": [
      "가로 한 줄의 칸 수에 세로 줄 수를 곱하면 전체 칸 수입니다.",
      "직사각형의 넓이는 가로와 세로의 곱입니다."
    ],
    "targets": [
      {
        "label": "7칸씩 4줄",
        "instruction": "가로 7 / 세로 4로 맞추세요.",
        "values": {
          "a": 7,
          "b": 4
        }
      },
      {
        "label": "가로와 세로 바꾸기",
        "instruction": "가로 4 / 세로 7로 맞추세요.",
        "values": {
          "a": 4,
          "b": 7
        }
      }
    ]
  },
  {
    "id": "elem5-x-same-area-shape",
    "year": 5,
    "title": "넓이가 같은 다른 직사각형",
    "desc": "가로와 세로가 달라도 곱이 같으면 넓이는 같습니다. 넓이가 같다고 둘레까지 같은 것은 아닙니다.",
    "q": "넓이가 24인 직사각형은 한 가지 모양뿐일까요?",
    "kind": "geometry",
    "mode": "rectangle",
    "controls": [
      {
        "key": "a",
        "label": "가로",
        "min": 1,
        "max": 12,
        "value": 6,
        "step": 1
      },
      {
        "key": "b",
        "label": "세로",
        "min": 1,
        "max": 12,
        "value": 4,
        "step": 1
      }
    ],
    "obs": [
      "가로와 세로가 달라도 곱이 같으면 넓이는 같습니다.",
      "넓이가 같다고 둘레까지 같은 것은 아닙니다."
    ],
    "targets": [
      {
        "label": "6과 4의 직사각형",
        "instruction": "가로 6 / 세로 4로 맞추세요.",
        "values": {
          "a": 6,
          "b": 4
        }
      },
      {
        "label": "8과 3의 직사각형",
        "instruction": "가로 8 / 세로 3로 맞추세요.",
        "values": {
          "a": 8,
          "b": 3
        }
      }
    ]
  },
  {
    "id": "elem5-x-triangle-half",
    "year": 5,
    "title": "삼각형은 같은 밑변과 높이의 절반",
    "desc": "같은 삼각형 두 개로 평행사변형을 만들 수 있습니다. 삼각형의 넓이는 밑변 곱하기 높이의 절반입니다.",
    "q": "밑변 8과 높이 5인 삼각형의 넓이는 얼마일까요?",
    "kind": "geometry",
    "mode": "triangle",
    "controls": [
      {
        "key": "a",
        "label": "밑변",
        "min": 1,
        "max": 12,
        "value": 8,
        "step": 1
      },
      {
        "key": "b",
        "label": "높이",
        "min": 1,
        "max": 10,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "같은 삼각형 두 개로 평행사변형을 만들 수 있습니다.",
      "삼각형의 넓이는 밑변 곱하기 높이의 절반입니다."
    ],
    "targets": [
      {
        "label": "넓이 20 찾기",
        "instruction": "밑변 8 / 높이 5로 맞추세요.",
        "values": {
          "a": 8,
          "b": 5
        }
      },
      {
        "label": "높이를 두 배로",
        "instruction": "밑변 8 / 높이 10로 맞추세요.",
        "values": {
          "a": 8,
          "b": 10
        }
      }
    ]
  },
  {
    "id": "elem5-x-triangle-same-area",
    "year": 5,
    "title": "밑변과 높이를 바꾸어 같은 넓이 만들기",
    "desc": "삼각형 넓이는 밑변과 높이의 곱에 따라 정해집니다. 밑변과 높이의 곱이 같으면 넓이도 같습니다.",
    "q": "밑변을 두 배로 하고 높이를 반으로 하면 넓이는 어떻게 될까요?",
    "kind": "geometry",
    "mode": "triangle",
    "controls": [
      {
        "key": "a",
        "label": "밑변",
        "min": 1,
        "max": 12,
        "value": 4,
        "step": 1
      },
      {
        "key": "b",
        "label": "높이",
        "min": 1,
        "max": 12,
        "value": 6,
        "step": 1
      }
    ],
    "obs": [
      "삼각형 넓이는 밑변과 높이의 곱에 따라 정해집니다.",
      "밑변과 높이의 곱이 같으면 넓이도 같습니다."
    ],
    "targets": [
      {
        "label": "밑변 4와 높이 6",
        "instruction": "밑변 4 / 높이 6로 맞추세요.",
        "values": {
          "a": 4,
          "b": 6
        }
      },
      {
        "label": "밑변 8과 높이 3",
        "instruction": "밑변 8 / 높이 3로 맞추세요.",
        "values": {
          "a": 8,
          "b": 3
        }
      }
    ]
  },
  {
    "id": "elem5-x-parallelogram-height",
    "year": 5,
    "title": "평행사변형에서 높이를 바로 재기",
    "desc": "높이는 밑변에 수직으로 잰 거리입니다. 평행사변형의 넓이는 밑변과 수직 높이를 곱합니다.",
    "q": "기울어진 변의 길이와 높이는 같은 것일까요?",
    "kind": "geometry",
    "mode": "parallelogram",
    "controls": [
      {
        "key": "a",
        "label": "밑변",
        "min": 2,
        "max": 12,
        "value": 7,
        "step": 1
      },
      {
        "key": "b",
        "label": "수직 높이",
        "min": 1,
        "max": 8,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "기울어진 거리",
        "min": 0,
        "max": 5,
        "value": 2,
        "step": 1
      }
    ],
    "obs": [
      "높이는 밑변에 수직으로 잰 거리입니다.",
      "평행사변형의 넓이는 밑변과 수직 높이를 곱합니다."
    ],
    "targets": [
      {
        "label": "밑변 7과 높이 4",
        "instruction": "밑변 7 / 수직 높이 4 / 기울어진 거리 2로 맞추세요.",
        "values": {
          "a": 7,
          "b": 4,
          "c": 2
        }
      },
      {
        "label": "높이만 바꾸기",
        "instruction": "밑변 7 / 수직 높이 6 / 기울어진 거리 2로 맞추세요.",
        "values": {
          "a": 7,
          "b": 6,
          "c": 2
        }
      }
    ]
  },
  {
    "id": "elem5-x-parallelogram-shear",
    "year": 5,
    "title": "기울어져도 같은 넓이",
    "desc": "도형의 한쪽을 잘라 옮기면 같은 넓이의 직사각형을 만들 수 있습니다. 밑변과 높이가 같으면 기울어진 정도가 달라도 넓이는 같습니다.",
    "q": "밑변과 높이를 유지한 채 기울이면 넓이가 달라질까요?",
    "kind": "geometry",
    "mode": "parallelogram",
    "controls": [
      {
        "key": "a",
        "label": "밑변",
        "min": 2,
        "max": 10,
        "value": 6,
        "step": 1
      },
      {
        "key": "b",
        "label": "수직 높이",
        "min": 1,
        "max": 8,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "기울어진 거리",
        "min": 0,
        "max": 5,
        "value": 0,
        "step": 1
      }
    ],
    "obs": [
      "도형의 한쪽을 잘라 옮기면 같은 넓이의 직사각형을 만들 수 있습니다.",
      "밑변과 높이가 같으면 기울어진 정도가 달라도 넓이는 같습니다."
    ],
    "targets": [
      {
        "label": "기울이지 않은 모양",
        "instruction": "밑변 6 / 수직 높이 4 / 기울어진 거리 0로 맞추세요.",
        "values": {
          "a": 6,
          "b": 4,
          "c": 0
        }
      },
      {
        "label": "기울인 모양",
        "instruction": "밑변 6 / 수직 높이 4 / 기울어진 거리 4로 맞추세요.",
        "values": {
          "a": 6,
          "b": 4,
          "c": 4
        }
      }
    ]
  },
  {
    "id": "elem5-x-trapezoid-pair",
    "year": 5,
    "title": "사다리꼴 두 개를 합치면",
    "desc": "같은 사다리꼴 두 개를 합치면 밑변이 윗변과 아랫변의 합인 평행사변형이 됩니다. 한 사다리꼴의 넓이는 두 밑변의 합 곱하기 높이의 절반입니다.",
    "q": "윗변과 아랫변을 더하는 까닭은 무엇일까요?",
    "kind": "geometry",
    "mode": "trapezoid",
    "controls": [
      {
        "key": "a",
        "label": "아랫변",
        "min": 3,
        "max": 12,
        "value": 8,
        "step": 1
      },
      {
        "key": "b",
        "label": "높이",
        "min": 1,
        "max": 8,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "윗변",
        "min": 1,
        "max": 10,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "같은 사다리꼴 두 개를 합치면 밑변이 윗변과 아랫변의 합인 평행사변형이 됩니다.",
      "한 사다리꼴의 넓이는 두 밑변의 합 곱하기 높이의 절반입니다."
    ],
    "targets": [
      {
        "label": "윗변 5와 아랫변 8",
        "instruction": "아랫변 8 / 높이 4 / 윗변 5로 맞추세요.",
        "values": {
          "a": 8,
          "b": 4,
          "c": 5
        }
      },
      {
        "label": "두 밑변의 자리 바꾸기",
        "instruction": "아랫변 5 / 높이 4 / 윗변 8로 맞추세요.",
        "values": {
          "a": 5,
          "b": 4,
          "c": 8
        }
      }
    ]
  },
  {
    "id": "elem5-x-rhombus-diagonals",
    "year": 5,
    "title": "마름모를 대각선으로 나누기",
    "desc": "마름모의 대각선은 서로 수직으로 만나며 서로를 이등분합니다. 마름모의 넓이는 두 대각선 길이의 곱의 절반입니다.",
    "q": "두 대각선의 길이로 마름모의 넓이를 구할 수 있을까요?",
    "kind": "geometry",
    "mode": "rhombus",
    "controls": [
      {
        "key": "a",
        "label": "첫째 대각선",
        "min": 2,
        "max": 12,
        "value": 8,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 대각선",
        "min": 2,
        "max": 12,
        "value": 6,
        "step": 1
      }
    ],
    "obs": [
      "마름모의 대각선은 서로 수직으로 만나며 서로를 이등분합니다.",
      "마름모의 넓이는 두 대각선 길이의 곱의 절반입니다."
    ],
    "targets": [
      {
        "label": "대각선 8과 6",
        "instruction": "첫째 대각선 8 / 둘째 대각선 6로 맞추세요.",
        "values": {
          "a": 8,
          "b": 6
        }
      },
      {
        "label": "첫째 대각선을 반으로",
        "instruction": "첫째 대각선 4 / 둘째 대각선 6로 맞추세요.",
        "values": {
          "a": 4,
          "b": 6
        }
      }
    ]
  },
  {
    "id": "elem5-x-perimeter-fixed",
    "year": 5,
    "title": "둘레가 같아도 넓이가 다를까",
    "desc": "직사각형의 둘레는 가로와 세로의 합의 두 배입니다. 가로와 세로의 합이 같으면 둘레도 같습니다.",
    "q": "가로 7과 세로 3인 모양을 가로 5와 세로 5로 바꾸어 보세요.",
    "kind": "measure",
    "mode": "perimeter",
    "controls": [
      {
        "key": "a",
        "label": "가로",
        "min": 1,
        "max": 12,
        "value": 7,
        "step": 1
      },
      {
        "key": "b",
        "label": "세로",
        "min": 1,
        "max": 12,
        "value": 3,
        "step": 1
      }
    ],
    "obs": [
      "직사각형의 둘레는 가로와 세로의 합의 두 배입니다.",
      "가로와 세로의 합이 같으면 둘레도 같습니다."
    ],
    "targets": [
      {
        "label": "7과 3의 둘레",
        "instruction": "가로 7 / 세로 3로 맞추세요.",
        "values": {
          "a": 7,
          "b": 3
        }
      },
      {
        "label": "5와 5의 둘레",
        "instruction": "가로 5 / 세로 5로 맞추세요.",
        "values": {
          "a": 5,
          "b": 5
        }
      }
    ]
  },
  {
    "id": "elem5-x-average-level",
    "year": 5,
    "title": "세 자료를 고르게 나눈 평균",
    "desc": "평균은 자료의 합을 자료 수로 나눈 값입니다. 평균을 세 번 모으면 세 자료의 합과 같습니다.",
    "q": "4와 7과 10을 고르게 나누면 얼마씩일까요?",
    "kind": "chart",
    "mode": "average",
    "controls": [
      {
        "key": "a",
        "label": "첫째 자료",
        "min": 0,
        "max": 24,
        "value": 4,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 자료",
        "min": 0,
        "max": 24,
        "value": 7,
        "step": 1
      },
      {
        "key": "c",
        "label": "셋째 자료",
        "min": 0,
        "max": 24,
        "value": 10,
        "step": 1
      }
    ],
    "obs": [
      "평균은 자료의 합을 자료 수로 나눈 값입니다.",
      "평균을 세 번 모으면 세 자료의 합과 같습니다."
    ],
    "targets": [
      {
        "label": "평균 7 찾기",
        "instruction": "첫째 자료 4 / 둘째 자료 7 / 셋째 자료 10로 맞추세요.",
        "values": {
          "a": 4,
          "b": 7,
          "c": 10
        }
      },
      {
        "label": "이미 고른 자료",
        "instruction": "첫째 자료 7 / 둘째 자료 7 / 셋째 자료 7로 맞추세요.",
        "values": {
          "a": 7,
          "b": 7,
          "c": 7
        }
      }
    ]
  },
  {
    "id": "elem5-x-average-spread",
    "year": 5,
    "title": "같은 평균의 다른 자료",
    "desc": "자료의 합과 자료 수가 같으면 평균은 같습니다. 평균만으로 각 자료가 얼마나 퍼져 있는지는 알 수 없습니다.",
    "q": "평균이 같으면 각 자료도 모두 같을까요?",
    "kind": "chart",
    "mode": "average",
    "controls": [
      {
        "key": "a",
        "label": "첫째 자료",
        "min": 0,
        "max": 24,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 자료",
        "min": 0,
        "max": 24,
        "value": 8,
        "step": 1
      },
      {
        "key": "c",
        "label": "셋째 자료",
        "min": 0,
        "max": 24,
        "value": 14,
        "step": 1
      }
    ],
    "obs": [
      "자료의 합과 자료 수가 같으면 평균은 같습니다.",
      "평균만으로 각 자료가 얼마나 퍼져 있는지는 알 수 없습니다."
    ],
    "targets": [
      {
        "label": "퍼진 세 자료",
        "instruction": "첫째 자료 2 / 둘째 자료 8 / 셋째 자료 14로 맞추세요.",
        "values": {
          "a": 2,
          "b": 8,
          "c": 14
        }
      },
      {
        "label": "모여 있는 세 자료",
        "instruction": "첫째 자료 7 / 둘째 자료 8 / 셋째 자료 9로 맞추세요.",
        "values": {
          "a": 7,
          "b": 8,
          "c": 9
        }
      }
    ]
  },
  {
    "id": "elem5-x-average-target",
    "year": 5,
    "title": "평균을 맞추는 셋째 수",
    "desc": "목표 평균에 자료 수를 곱하면 필요한 전체 합을 알 수 있습니다. 이미 있는 두 수의 합을 빼면 나머지 수를 찾을 수 있습니다.",
    "q": "4와 8이 있을 때 평균이 7이 되려면 셋째 수는 얼마일까요?",
    "kind": "chart",
    "mode": "average",
    "controls": [
      {
        "key": "a",
        "label": "첫째 자료",
        "min": 0,
        "max": 24,
        "value": 4,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 자료",
        "min": 0,
        "max": 24,
        "value": 8,
        "step": 1
      },
      {
        "key": "c",
        "label": "셋째 자료",
        "min": 0,
        "max": 24,
        "value": 9,
        "step": 1
      }
    ],
    "obs": [
      "목표 평균에 자료 수를 곱하면 필요한 전체 합을 알 수 있습니다.",
      "이미 있는 두 수의 합을 빼면 나머지 수를 찾을 수 있습니다."
    ],
    "targets": [
      {
        "label": "평균 7 맞추기",
        "instruction": "첫째 자료 4 / 둘째 자료 8 / 셋째 자료 9로 맞추세요.",
        "values": {
          "a": 4,
          "b": 8,
          "c": 9
        }
      },
      {
        "label": "평균 8 맞추기",
        "instruction": "첫째 자료 4 / 둘째 자료 8 / 셋째 자료 12로 맞추세요.",
        "values": {
          "a": 4,
          "b": 8,
          "c": 12
        }
      }
    ]
  },
  {
    "id": "elem5-x-line-equal-increase",
    "year": 5,
    "title": "꺾은선의 같은 증가와 다른 증가",
    "desc": "같은 간격에서 같은 양만큼 늘면 선분의 기울기가 같습니다. 나중 구간에서 더 많이 늘면 그 구간의 선분이 더 가파릅니다.",
    "q": "값이 같은 양만큼 늘면 선분의 기울기는 어떻게 될까요?",
    "kind": "chart",
    "mode": "line",
    "controls": [
      {
        "key": "a",
        "label": "첫째 기록",
        "min": 0,
        "max": 24,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 기록",
        "min": 0,
        "max": 24,
        "value": 6,
        "step": 1
      },
      {
        "key": "c",
        "label": "셋째 기록",
        "min": 0,
        "max": 24,
        "value": 9,
        "step": 1
      }
    ],
    "obs": [
      "같은 간격에서 같은 양만큼 늘면 선분의 기울기가 같습니다.",
      "나중 구간에서 더 많이 늘면 그 구간의 선분이 더 가파릅니다."
    ],
    "targets": [
      {
        "label": "같은 양만큼 증가",
        "instruction": "첫째 기록 3 / 둘째 기록 6 / 셋째 기록 9로 맞추세요.",
        "values": {
          "a": 3,
          "b": 6,
          "c": 9
        }
      },
      {
        "label": "나중에 더 많이 증가",
        "instruction": "첫째 기록 3 / 둘째 기록 6 / 셋째 기록 12로 맞추세요.",
        "values": {
          "a": 3,
          "b": 6,
          "c": 12
        }
      }
    ]
  },
  {
    "id": "elem5-x-likely-choice",
    "year": 5,
    "title": "어느 색이 나올 가능성이 클까",
    "desc": "같은 조건에서 수가 더 많은 색은 나올 가능성이 더 큽니다. 전체 수가 같다면 한 색의 수가 늘수록 그 색이 나올 가능성이 커집니다.",
    "q": "같은 크기의 공을 하나 고르면 어떤 색이 더 나오기 쉬울까요?",
    "kind": "chart",
    "mode": "probability",
    "controls": [
      {
        "key": "a",
        "label": "초록 공",
        "min": 0,
        "max": 12,
        "value": 6,
        "step": 1
      },
      {
        "key": "b",
        "label": "주황 공",
        "min": 0,
        "max": 12,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "보라 공",
        "min": 0,
        "max": 12,
        "value": 1,
        "step": 1
      }
    ],
    "obs": [
      "같은 조건에서 수가 더 많은 색은 나올 가능성이 더 큽니다.",
      "전체 수가 같다면 한 색의 수가 늘수록 그 색이 나올 가능성이 커집니다."
    ],
    "targets": [
      {
        "label": "초록이 가장 많게",
        "instruction": "초록 공 6 / 주황 공 3 / 보라 공 1로 맞추세요.",
        "values": {
          "a": 6,
          "b": 3,
          "c": 1
        }
      },
      {
        "label": "초록과 주황이 같게",
        "instruction": "초록 공 4 / 주황 공 4 / 보라 공 2로 맞추세요.",
        "values": {
          "a": 4,
          "b": 4,
          "c": 2
        }
      }
    ]
  },
  {
    "id": "elem5-x-certain-impossible",
    "year": 5,
    "title": "확실한 일과 불가능한 일",
    "desc": "상자의 모든 공이 초록이면 초록 공을 고르는 일은 확실합니다. 상자에 없는 색의 공을 고르는 일은 불가능합니다.",
    "q": "상자에 초록 공만 있으면 어떤 일이 확실할까요?",
    "kind": "chart",
    "mode": "probability",
    "controls": [
      {
        "key": "a",
        "label": "초록 공",
        "min": 0,
        "max": 12,
        "value": 5,
        "step": 1
      },
      {
        "key": "b",
        "label": "주황 공",
        "min": 0,
        "max": 12,
        "value": 0,
        "step": 1
      },
      {
        "key": "c",
        "label": "보라 공",
        "min": 0,
        "max": 12,
        "value": 0,
        "step": 1
      }
    ],
    "obs": [
      "상자의 모든 공이 초록이면 초록 공을 고르는 일은 확실합니다.",
      "상자에 없는 색의 공을 고르는 일은 불가능합니다."
    ],
    "targets": [
      {
        "label": "초록만 있는 상자",
        "instruction": "초록 공 5 / 주황 공 0 / 보라 공 0로 맞추세요.",
        "values": {
          "a": 5,
          "b": 0,
          "c": 0
        }
      },
      {
        "label": "주황만 있는 상자",
        "instruction": "초록 공 0 / 주황 공 5 / 보라 공 0로 맞추세요.",
        "values": {
          "a": 0,
          "b": 5,
          "c": 0
        }
      }
    ]
  },
  {
    "id": "elem5-x-box-edge",
    "year": 5,
    "title": "직육면체의 세 방향 길이",
    "desc": "직육면체에는 서로 수직인 세 방향의 길이가 있습니다. 세 방향의 길이가 모두 같으면 정육면체입니다.",
    "q": "가로와 세로와 높이가 모두 같으면 어떤 입체도형일까요?",
    "kind": "solid",
    "mode": "box",
    "controls": [
      {
        "key": "a",
        "label": "가로",
        "min": 1,
        "max": 6,
        "value": 4,
        "step": 1
      },
      {
        "key": "b",
        "label": "세로",
        "min": 1,
        "max": 6,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "높이",
        "min": 1,
        "max": 6,
        "value": 2,
        "step": 1
      }
    ],
    "obs": [
      "직육면체에는 서로 수직인 세 방향의 길이가 있습니다.",
      "세 방향의 길이가 모두 같으면 정육면체입니다."
    ],
    "targets": [
      {
        "label": "세 길이가 다른 모양",
        "instruction": "가로 4 / 세로 3 / 높이 2로 맞추세요.",
        "values": {
          "a": 4,
          "b": 3,
          "c": 2
        }
      },
      {
        "label": "세 길이가 같은 모양",
        "instruction": "가로 3 / 세로 3 / 높이 3로 맞추세요.",
        "values": {
          "a": 3,
          "b": 3,
          "c": 3
        }
      }
    ],
    "focus": "properties"
  },
  {
    "id": "elem5-x-cube-layers",
    "year": 5,
    "title": "한 층의 개수로 쌓은 수 세기",
    "desc": "한 층의 개수는 한 줄의 수와 줄 수를 곱해 구합니다. 한 층의 개수가 같으면 층 수에 비례해 전체 개수가 늘어납니다.",
    "q": "한 층에 12개씩 3층을 쌓으면 모두 몇 개일까요?",
    "kind": "solid",
    "mode": "cubes",
    "controls": [
      {
        "key": "a",
        "label": "한 줄의 정육면체",
        "min": 1,
        "max": 5,
        "value": 4,
        "step": 1
      },
      {
        "key": "b",
        "label": "한 층의 줄 수",
        "min": 1,
        "max": 5,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "층 수",
        "min": 1,
        "max": 5,
        "value": 3,
        "step": 1
      }
    ],
    "obs": [
      "한 층의 개수는 한 줄의 수와 줄 수를 곱해 구합니다.",
      "한 층의 개수가 같으면 층 수에 비례해 전체 개수가 늘어납니다."
    ],
    "targets": [
      {
        "label": "12개씩 3층",
        "instruction": "한 줄의 정육면체 4 / 한 층의 줄 수 3 / 층 수 3로 맞추세요.",
        "values": {
          "a": 4,
          "b": 3,
          "c": 3
        }
      },
      {
        "label": "12개씩 4층",
        "instruction": "한 줄의 정육면체 4 / 한 층의 줄 수 3 / 층 수 4로 맞추세요.",
        "values": {
          "a": 4,
          "b": 3,
          "c": 4
        }
      }
    ],
    "focus": "count"
  },
  {
    "id": "elem5-x-table-two-rules",
    "year": 5,
    "title": "같이 늘지만 시작이 다른 표",
    "desc": "곱하는 수가 같으면 입력이 1 늘 때 출력이 늘어나는 양은 같습니다. 처음 더하는 수를 늘리면 모든 출력이 그만큼 커집니다.",
    "q": "같은 수를 곱해도 처음 더하는 수가 다르면 출력은 어떻게 달라질까요?",
    "kind": "sequence",
    "mode": "table",
    "controls": [
      {
        "key": "a",
        "label": "처음 더하는 수",
        "min": 0,
        "max": 12,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "입력에 곱하는 수",
        "min": 1,
        "max": 6,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "나타낼 입력 수",
        "min": 3,
        "max": 8,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "곱하는 수가 같으면 입력이 1 늘 때 출력이 늘어나는 양은 같습니다.",
      "처음 더하는 수를 늘리면 모든 출력이 그만큼 커집니다."
    ],
    "targets": [
      {
        "label": "4배에 2 더하기",
        "instruction": "처음 더하는 수 2 / 입력에 곱하는 수 4 / 나타낼 입력 수 5로 맞추세요.",
        "values": {
          "a": 2,
          "b": 4,
          "c": 5
        }
      },
      {
        "label": "4배에 5 더하기",
        "instruction": "처음 더하는 수 5 / 입력에 곱하는 수 4 / 나타낼 입력 수 5로 맞추세요.",
        "values": {
          "a": 5,
          "b": 4,
          "c": 5
        }
      }
    ],
    "unit": "offset-step"
  },
  {
    "id": "elem5-x-time-across-noon",
    "year": 5,
    "title": "시간 단위를 넘겨 계산하기",
    "desc": "95분은 1시간 35분입니다. 분을 더한 뒤 60분마다 시 부분을 하나 올립니다.",
    "q": "11시 50분에서 95분이 지나면 몇 시 몇 분일까요?",
    "kind": "measure",
    "mode": "time",
    "controls": [
      {
        "key": "a",
        "label": "시",
        "min": 0,
        "max": 23,
        "value": 11,
        "step": 1
      },
      {
        "key": "b",
        "label": "분",
        "min": 0,
        "max": 59,
        "value": 50,
        "step": 1
      },
      {
        "key": "c",
        "label": "지나는 분",
        "min": 0,
        "max": 180,
        "value": 95,
        "step": 1
      }
    ],
    "obs": [
      "95분은 1시간 35분입니다.",
      "분을 더한 뒤 60분마다 시 부분을 하나 올립니다."
    ],
    "targets": [
      {
        "label": "95분 뒤",
        "instruction": "시 11 / 분 50 / 지나는 분 95로 맞추세요.",
        "values": {
          "a": 11,
          "b": 50,
          "c": 95
        }
      },
      {
        "label": "35분 뒤",
        "instruction": "시 11 / 분 50 / 지나는 분 35로 맞추세요.",
        "values": {
          "a": 11,
          "b": 50,
          "c": 35
        }
      }
    ],
    "unit": "elapsed-clock"
  },
  {
    "id": "elem5-x-fraction-product-one",
    "year": 5,
    "title": "분수의 곱이 1이 되는 짝",
    "desc": "분자와 분모가 서로 뒤바뀐 두 분수의 곱은 1입니다. 곱의 분자와 분모가 같아지면 전체 하나가 됩니다.",
    "q": "2/3과 어떤 분수를 곱하면 1이 될까요?",
    "kind": "fraction",
    "mode": "mul",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 8,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 8,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 8,
        "value": 3,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 2,
        "max": 8,
        "value": 2,
        "step": 1
      }
    ],
    "obs": [
      "분자와 분모가 서로 뒤바뀐 두 분수의 곱은 1입니다.",
      "곱의 분자와 분모가 같아지면 전체 하나가 됩니다."
    ],
    "targets": [
      {
        "label": "2/3의 짝 찾기",
        "instruction": "첫째 분자 2 / 첫째 분모 3 / 둘째 분자 3 / 둘째 분모 2로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 3,
          "d": 2
        }
      },
      {
        "label": "3/4의 짝 찾기",
        "instruction": "첫째 분자 3 / 첫째 분모 4 / 둘째 분자 4 / 둘째 분모 3로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4,
          "c": 4,
          "d": 3
        }
      }
    ]
  },
  {
    "id": "elem6-x-divide-unit",
    "year": 6,
    "title": "단위분수가 몇 번 들어갈까",
    "desc": "분수로 나눈다는 것은 그 분수 크기의 묶음을 몇 개 만들 수 있는지 묻는 것입니다. 1/q로 나누면 q를 곱한 값과 같습니다.",
    "q": "3/4 안에 1/8이 몇 번 들어갈까요?",
    "kind": "fraction",
    "mode": "div",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 8,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 8,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 2,
        "max": 12,
        "value": 8,
        "step": 1
      }
    ],
    "obs": [
      "분수로 나눈다는 것은 그 분수 크기의 묶음을 몇 개 만들 수 있는지 묻는 것입니다.",
      "1/q로 나누면 q를 곱한 값과 같습니다."
    ],
    "targets": [
      {
        "label": "3/4를 1/8로 재기",
        "instruction": "첫째 분자 3 / 첫째 분모 4 / 둘째 분자 1 / 둘째 분모 8로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4,
          "c": 1,
          "d": 8
        }
      },
      {
        "label": "같은 양을 1/4로 재기",
        "instruction": "첫째 분자 3 / 첫째 분모 4 / 둘째 분자 1 / 둘째 분모 4로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4,
          "c": 1,
          "d": 4
        }
      }
    ]
  },
  {
    "id": "elem6-x-divide-proper",
    "year": 6,
    "title": "분수로 나누어 묶음 수 찾기",
    "desc": "나누는 분수의 분자와 분모를 뒤집어 곱할 수 있습니다. 묶음이 온전히 들어가지 않으면 몫도 분수가 될 수 있습니다.",
    "q": "3/4를 1/2씩 나누면 한 묶음보다 많을까요?",
    "kind": "fraction",
    "mode": "div",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 8,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 8,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 8,
        "value": 1,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 2,
        "max": 8,
        "value": 2,
        "step": 1
      }
    ],
    "obs": [
      "나누는 분수의 분자와 분모를 뒤집어 곱할 수 있습니다.",
      "묶음이 온전히 들어가지 않으면 몫도 분수가 될 수 있습니다."
    ],
    "targets": [
      {
        "label": "한 묶음 반",
        "instruction": "첫째 분자 3 / 첫째 분모 4 / 둘째 분자 1 / 둘째 분모 2로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4,
          "c": 1,
          "d": 2
        }
      },
      {
        "label": "두 묶음",
        "instruction": "첫째 분자 3 / 첫째 분모 4 / 둘째 분자 3 / 둘째 분모 8로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4,
          "c": 3,
          "d": 8
        }
      }
    ]
  },
  {
    "id": "elem6-x-divide-same",
    "year": 6,
    "title": "같은 분수끼리 나누기",
    "desc": "0이 아닌 같은 양은 서로 한 번 들어갑니다. 분수의 표현이 달라도 크기가 같으면 몫은 1입니다.",
    "q": "두 분수의 크기가 같으면 나눗셈의 몫은 얼마일까요?",
    "kind": "fraction",
    "mode": "div",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 9,
        "value": 4,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 10,
        "value": 5,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 9,
        "value": 4,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 2,
        "max": 10,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "0이 아닌 같은 양은 서로 한 번 들어갑니다.",
      "분수의 표현이 달라도 크기가 같으면 몫은 1입니다."
    ],
    "targets": [
      {
        "label": "같은 표현 나누기",
        "instruction": "첫째 분자 4 / 첫째 분모 5 / 둘째 분자 4 / 둘째 분모 5로 맞추세요.",
        "values": {
          "a": 4,
          "b": 5,
          "c": 4,
          "d": 5
        }
      },
      {
        "label": "다른 표현 같은 크기",
        "instruction": "첫째 분자 2 / 첫째 분모 3 / 둘째 분자 4 / 둘째 분모 6로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 4,
          "d": 6
        }
      }
    ]
  },
  {
    "id": "elem6-x-divide-less-one",
    "year": 6,
    "title": "나누는 수가 더 클 때",
    "desc": "나누어지는 양이 한 묶음보다 작으면 몫은 1보다 작습니다. 양의 수로 나눌 때 몫의 크기는 두 양의 상대적인 크기에 달려 있습니다.",
    "q": "2/5를 3/5로 나누면 왜 몫이 1보다 작을까요?",
    "kind": "fraction",
    "mode": "div",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 8,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 10,
        "value": 5,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 8,
        "value": 3,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 2,
        "max": 10,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "나누어지는 양이 한 묶음보다 작으면 몫은 1보다 작습니다.",
      "양의 수로 나눌 때 몫의 크기는 두 양의 상대적인 크기에 달려 있습니다."
    ],
    "targets": [
      {
        "label": "한 묶음보다 적은 양",
        "instruction": "첫째 분자 2 / 첫째 분모 5 / 둘째 분자 3 / 둘째 분모 5로 맞추세요.",
        "values": {
          "a": 2,
          "b": 5,
          "c": 3,
          "d": 5
        }
      },
      {
        "label": "두 양의 역할 바꾸기",
        "instruction": "첫째 분자 3 / 첫째 분모 5 / 둘째 분자 2 / 둘째 분모 5로 맞추세요.",
        "values": {
          "a": 3,
          "b": 5,
          "c": 2,
          "d": 5
        }
      }
    ]
  },
  {
    "id": "elem6-x-multiply-shrink",
    "year": 6,
    "title": "1보다 작은 수를 곱하면",
    "desc": "양의 수에 1보다 작은 양수를 곱하면 값은 작아집니다. 분수의 곱은 원래 양의 일부를 나타낼 수 있습니다.",
    "q": "3/4에 1/5을 곱하면 원래 양보다 커질까요?",
    "kind": "fraction",
    "mode": "mul",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 8,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 2,
        "max": 10,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 1,
        "max": 4,
        "value": 1,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 5,
        "max": 8,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "양의 수에 1보다 작은 양수를 곱하면 값은 작아집니다.",
      "분수의 곱은 원래 양의 일부를 나타낼 수 있습니다."
    ],
    "targets": [
      {
        "label": "3/4의 1/5",
        "instruction": "첫째 분자 3 / 첫째 분모 4 / 둘째 분자 1 / 둘째 분모 5로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4,
          "c": 1,
          "d": 5
        }
      },
      {
        "label": "3/4의 4/5",
        "instruction": "첫째 분자 3 / 첫째 분모 4 / 둘째 분자 4 / 둘째 분모 5로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4,
          "c": 4,
          "d": 5
        }
      }
    ]
  },
  {
    "id": "elem6-x-decimal-as-fraction",
    "year": 6,
    "title": "소수를 분수로 다시 보기",
    "desc": "소수 첫째 자리는 십분의 몇을 뜻합니다. 분모가 10인 분수는 소수 첫째 자리로 나타낼 수 있습니다.",
    "q": "0.4와 4/10은 어떤 관계일까요?",
    "kind": "fraction",
    "mode": "show",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 0,
        "max": 10,
        "value": 4,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 10,
        "max": 10,
        "value": 10,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 0,
        "max": 0,
        "value": 0,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      }
    ],
    "obs": [
      "소수 첫째 자리는 십분의 몇을 뜻합니다.",
      "분모가 10인 분수는 소수 첫째 자리로 나타낼 수 있습니다."
    ],
    "targets": [
      {
        "label": "0.4 나타내기",
        "instruction": "첫째 분자 4 / 첫째 분모 10 / 둘째 분자 0 / 둘째 분모 1로 맞추세요.",
        "values": {
          "a": 4,
          "b": 10,
          "c": 0,
          "d": 1
        }
      },
      {
        "label": "0.7 나타내기",
        "instruction": "첫째 분자 7 / 첫째 분모 10 / 둘째 분자 0 / 둘째 분모 1로 맞추세요.",
        "values": {
          "a": 7,
          "b": 10,
          "c": 0,
          "d": 1
        }
      }
    ]
  },
  {
    "id": "elem6-x-ratio-percent-part",
    "year": 6,
    "title": "전체의 몇 퍼센트 구하기",
    "desc": "백분율은 기준량을 100으로 보았을 때의 비교하는 양입니다. 전체에 백분율을 100으로 나눈 비율을 곱하면 부분을 구할 수 있습니다.",
    "q": "전체 80의 25%는 얼마일까요?",
    "kind": "ratio",
    "mode": "percent",
    "controls": [
      {
        "key": "a",
        "label": "전체 수",
        "min": 20,
        "max": 200,
        "value": 80,
        "step": 1
      },
      {
        "key": "b",
        "label": "백분율 %",
        "min": 0,
        "max": 100,
        "value": 25,
        "step": 1
      }
    ],
    "obs": [
      "백분율은 기준량을 100으로 보았을 때의 비교하는 양입니다.",
      "전체에 백분율을 100으로 나눈 비율을 곱하면 부분을 구할 수 있습니다."
    ],
    "targets": [
      {
        "label": "80의 25%",
        "instruction": "전체 수 80 / 백분율 % 25로 맞추세요.",
        "values": {
          "a": 80,
          "b": 25
        }
      },
      {
        "label": "80의 50%",
        "instruction": "전체 수 80 / 백분율 % 50로 맞추세요.",
        "values": {
          "a": 80,
          "b": 50
        }
      }
    ]
  },
  {
    "id": "elem6-x-percent-whole",
    "year": 6,
    "title": "비율이 같아도 실제 수는 달라요",
    "desc": "같은 백분율이라도 전체가 달라지면 부분의 수가 달라집니다. 비율을 고정하면 전체가 두 배일 때 부분도 두 배입니다.",
    "q": "같은 25%인데 전체가 두 배이면 부분은 어떻게 될까요?",
    "kind": "ratio",
    "mode": "percent",
    "controls": [
      {
        "key": "a",
        "label": "전체 수",
        "min": 20,
        "max": 200,
        "value": 60,
        "step": 1
      },
      {
        "key": "b",
        "label": "백분율 %",
        "min": 0,
        "max": 100,
        "value": 25,
        "step": 1
      }
    ],
    "obs": [
      "같은 백분율이라도 전체가 달라지면 부분의 수가 달라집니다.",
      "비율을 고정하면 전체가 두 배일 때 부분도 두 배입니다."
    ],
    "targets": [
      {
        "label": "전체 60의 25%",
        "instruction": "전체 수 60 / 백분율 % 25로 맞추세요.",
        "values": {
          "a": 60,
          "b": 25
        }
      },
      {
        "label": "전체를 두 배로",
        "instruction": "전체 수 120 / 백분율 % 25로 맞추세요.",
        "values": {
          "a": 120,
          "b": 25
        }
      }
    ]
  },
  {
    "id": "elem6-x-equivalent-ratio",
    "year": 6,
    "title": "같은 비를 만드는 두 배",
    "desc": "비의 앞 수와 뒤 수에 같은 양수를 곱하면 비율은 같습니다. 같은 비율을 가진 두 비를 등식으로 나타낼 수 있습니다.",
    "q": "2 대 3을 두 배로 늘리면 같은 비일까요?",
    "kind": "ratio",
    "mode": "proportion",
    "controls": [
      {
        "key": "a",
        "label": "비의 앞 수",
        "min": 1,
        "max": 12,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "비의 뒤 수",
        "min": 1,
        "max": 12,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "함께 곱할 수",
        "min": 1,
        "max": 6,
        "value": 2,
        "step": 1
      }
    ],
    "obs": [
      "비의 앞 수와 뒤 수에 같은 양수를 곱하면 비율은 같습니다.",
      "같은 비율을 가진 두 비를 등식으로 나타낼 수 있습니다."
    ],
    "targets": [
      {
        "label": "2 대 3의 두 배",
        "instruction": "비의 앞 수 2 / 비의 뒤 수 3 / 함께 곱할 수 2로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 2
        }
      },
      {
        "label": "2 대 3의 세 배",
        "instruction": "비의 앞 수 2 / 비의 뒤 수 3 / 함께 곱할 수 3로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 3
        }
      }
    ]
  },
  {
    "id": "elem6-x-ratio-base",
    "year": 6,
    "title": "비교하는 양과 기준량",
    "desc": "비율은 비교하는 양을 기준량으로 나눈 값입니다. 비교하는 양과 기준량을 바꾸면 일반적으로 비율이 달라집니다.",
    "q": "3 대 5에서 기준을 바꾸면 비율도 같을까요?",
    "kind": "ratio",
    "mode": "ratio",
    "controls": [
      {
        "key": "a",
        "label": "비교하는 양",
        "min": 1,
        "max": 12,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "기준량",
        "min": 1,
        "max": 12,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "비율은 비교하는 양을 기준량으로 나눈 값입니다.",
      "비교하는 양과 기준량을 바꾸면 일반적으로 비율이 달라집니다."
    ],
    "targets": [
      {
        "label": "3을 5와 비교",
        "instruction": "비교하는 양 3 / 기준량 5로 맞추세요.",
        "values": {
          "a": 3,
          "b": 5
        }
      },
      {
        "label": "5를 3과 비교",
        "instruction": "비교하는 양 5 / 기준량 3로 맞추세요.",
        "values": {
          "a": 5,
          "b": 3
        }
      }
    ]
  },
  {
    "id": "elem6-x-drawing-scale",
    "year": 6,
    "title": "축척으로 실제 길이 구하기",
    "desc": "축척이 1 대 n이면 실제 길이는 그림 길이의 n배입니다. 그림과 실제를 비교하기 전에 길이 단위를 같게 맞춥니다.",
    "q": "1 대 100인 그림에서 3 cm는 실제 몇 cm일까요?",
    "kind": "ratio",
    "mode": "scale",
    "controls": [
      {
        "key": "a",
        "label": "그림 길이 cm",
        "min": 1,
        "max": 10,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "축척의 뒤 수",
        "min": 10,
        "max": 500,
        "value": 100,
        "step": 1
      }
    ],
    "obs": [
      "축척이 1 대 n이면 실제 길이는 그림 길이의 n배입니다.",
      "그림과 실제를 비교하기 전에 길이 단위를 같게 맞춥니다."
    ],
    "targets": [
      {
        "label": "1 대 100의 3 cm",
        "instruction": "그림 길이 cm 3 / 축척의 뒤 수 100로 맞추세요.",
        "values": {
          "a": 3,
          "b": 100
        }
      },
      {
        "label": "1 대 200의 3 cm",
        "instruction": "그림 길이 cm 3 / 축척의 뒤 수 200로 맞추세요.",
        "values": {
          "a": 3,
          "b": 200
        }
      }
    ]
  },
  {
    "id": "elem6-x-circumference-radius",
    "year": 6,
    "title": "반지름으로 원주 구하기",
    "desc": "원주는 지름에 원주율을 곱해 구합니다. 지름은 반지름의 두 배이며 이 실험에서는 원주율을 3.14로 어림합니다.",
    "q": "반지름이 두 배이면 원주는 몇 배가 될까요?",
    "kind": "circle",
    "mode": "circumference",
    "controls": [
      {
        "key": "a",
        "label": "반지름 cm",
        "min": 1,
        "max": 12,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "원주율의 100배",
        "min": 314,
        "max": 314,
        "value": 314,
        "step": 1
      }
    ],
    "obs": [
      "원주는 지름에 원주율을 곱해 구합니다.",
      "지름은 반지름의 두 배이며 이 실험에서는 원주율을 3.14로 어림합니다."
    ],
    "targets": [
      {
        "label": "반지름 3의 원주",
        "instruction": "반지름 cm 3 / 원주율의 100배 314로 맞추세요.",
        "values": {
          "a": 3,
          "b": 314
        }
      },
      {
        "label": "반지름을 두 배로",
        "instruction": "반지름 cm 6 / 원주율의 100배 314로 맞추세요.",
        "values": {
          "a": 6,
          "b": 314
        }
      }
    ]
  },
  {
    "id": "elem6-x-circle-area",
    "year": 6,
    "title": "반지름으로 원의 넓이 구하기",
    "desc": "원의 넓이는 반지름 곱하기 반지름 곱하기 원주율입니다. 이 실험에서는 원주율을 3.14로 어림한 넓이를 비교합니다.",
    "q": "반지름 4 cm인 원의 넓이는 얼마일까요?",
    "kind": "circle",
    "mode": "area",
    "controls": [
      {
        "key": "a",
        "label": "반지름 cm",
        "min": 1,
        "max": 12,
        "value": 4,
        "step": 1
      },
      {
        "key": "b",
        "label": "원주율의 100배",
        "min": 314,
        "max": 314,
        "value": 314,
        "step": 1
      }
    ],
    "obs": [
      "원의 넓이는 반지름 곱하기 반지름 곱하기 원주율입니다.",
      "이 실험에서는 원주율을 3.14로 어림한 넓이를 비교합니다."
    ],
    "targets": [
      {
        "label": "반지름 4의 넓이",
        "instruction": "반지름 cm 4 / 원주율의 100배 314로 맞추세요.",
        "values": {
          "a": 4,
          "b": 314
        }
      },
      {
        "label": "반지름 5의 넓이",
        "instruction": "반지름 cm 5 / 원주율의 100배 314로 맞추세요.",
        "values": {
          "a": 5,
          "b": 314
        }
      }
    ]
  },
  {
    "id": "elem6-x-radius-diameter",
    "year": 6,
    "title": "반지름과 지름 구별하기",
    "desc": "반지름은 원의 중심에서 원 위의 점까지의 거리입니다. 지름은 원의 중심을 지나며 반지름의 두 배입니다.",
    "q": "지름은 반지름 몇 개를 이어 놓은 길이일까요?",
    "kind": "circle",
    "mode": "diameter",
    "controls": [
      {
        "key": "a",
        "label": "반지름 cm",
        "min": 1,
        "max": 12,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "반지름은 원의 중심에서 원 위의 점까지의 거리입니다.",
      "지름은 원의 중심을 지나며 반지름의 두 배입니다."
    ],
    "targets": [
      {
        "label": "반지름 5와 지름",
        "instruction": "반지름 cm 5로 맞추세요.",
        "values": {
          "a": 5
        }
      },
      {
        "label": "반지름 8과 지름",
        "instruction": "반지름 cm 8로 맞추세요.",
        "values": {
          "a": 8
        }
      }
    ]
  },
  {
    "id": "elem6-x-circle-square-growth",
    "year": 6,
    "title": "반지름 두 배와 넓이 네 배",
    "desc": "원의 넓이에는 반지름이 두 번 곱해집니다. 반지름이 두 배이면 넓이는 네 배가 됩니다.",
    "q": "반지름을 두 배로 하면 넓이도 두 배일까요?",
    "kind": "circle",
    "mode": "area",
    "controls": [
      {
        "key": "a",
        "label": "반지름 cm",
        "min": 1,
        "max": 12,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "원주율의 100배",
        "min": 314,
        "max": 314,
        "value": 314,
        "step": 1
      }
    ],
    "obs": [
      "원의 넓이에는 반지름이 두 번 곱해집니다.",
      "반지름이 두 배이면 넓이는 네 배가 됩니다."
    ],
    "targets": [
      {
        "label": "반지름 3의 기준",
        "instruction": "반지름 cm 3 / 원주율의 100배 314로 맞추세요.",
        "values": {
          "a": 3,
          "b": 314
        }
      },
      {
        "label": "반지름 6과 비교",
        "instruction": "반지름 cm 6 / 원주율의 100배 314로 맞추세요.",
        "values": {
          "a": 6,
          "b": 314
        }
      }
    ]
  },
  {
    "id": "elem6-x-box-volume",
    "year": 6,
    "title": "직육면체 부피를 세 방향으로",
    "desc": "직육면체의 부피는 가로와 세로와 높이의 곱입니다. 단위 길이가 cm이면 부피의 단위는 cm³입니다.",
    "q": "가로 5와 세로 3과 높이 4인 상자에는 단위 정육면체가 몇 개일까요?",
    "kind": "solid",
    "mode": "box",
    "controls": [
      {
        "key": "a",
        "label": "가로 cm",
        "min": 1,
        "max": 6,
        "value": 5,
        "step": 1
      },
      {
        "key": "b",
        "label": "세로 cm",
        "min": 1,
        "max": 6,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "높이 cm",
        "min": 1,
        "max": 6,
        "value": 4,
        "step": 1
      }
    ],
    "obs": [
      "직육면체의 부피는 가로와 세로와 높이의 곱입니다.",
      "단위 길이가 cm이면 부피의 단위는 cm³입니다."
    ],
    "targets": [
      {
        "label": "부피 60 cm³",
        "instruction": "가로 cm 5 / 세로 cm 3 / 높이 cm 4로 맞추세요.",
        "values": {
          "a": 5,
          "b": 3,
          "c": 4
        }
      },
      {
        "label": "높이를 반으로",
        "instruction": "가로 cm 5 / 세로 cm 3 / 높이 cm 2로 맞추세요.",
        "values": {
          "a": 5,
          "b": 3,
          "c": 2
        }
      }
    ]
  },
  {
    "id": "elem6-x-box-surface",
    "year": 6,
    "title": "겉넓이는 여섯 면의 합",
    "desc": "마주 보는 두 면은 같은 모양이고 넓이도 같습니다. 세 종류 면의 넓이를 더한 뒤 두 배 하면 겉넓이입니다.",
    "q": "직육면체의 마주 보는 면은 어떤 관계일까요?",
    "kind": "solid",
    "mode": "surface",
    "controls": [
      {
        "key": "a",
        "label": "가로 cm",
        "min": 1,
        "max": 8,
        "value": 5,
        "step": 1
      },
      {
        "key": "b",
        "label": "세로 cm",
        "min": 1,
        "max": 8,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "높이 cm",
        "min": 1,
        "max": 8,
        "value": 4,
        "step": 1
      }
    ],
    "obs": [
      "마주 보는 두 면은 같은 모양이고 넓이도 같습니다.",
      "세 종류 면의 넓이를 더한 뒤 두 배 하면 겉넓이입니다."
    ],
    "targets": [
      {
        "label": "5와 3과 4의 겉넓이",
        "instruction": "가로 cm 5 / 세로 cm 3 / 높이 cm 4로 맞추세요.",
        "values": {
          "a": 5,
          "b": 3,
          "c": 4
        }
      },
      {
        "label": "가로와 세로 바꾸기",
        "instruction": "가로 cm 3 / 세로 cm 5 / 높이 cm 4로 맞추세요.",
        "values": {
          "a": 3,
          "b": 5,
          "c": 4
        }
      }
    ]
  },
  {
    "id": "elem6-x-same-volume-box",
    "year": 6,
    "title": "부피가 같은 다른 상자",
    "desc": "세 길이의 곱이 같으면 직육면체의 부피도 같습니다. 부피가 같다고 겉넓이가 같지는 않습니다.",
    "q": "부피가 24인 상자는 한 가지 모양뿐일까요?",
    "kind": "solid",
    "mode": "box",
    "controls": [
      {
        "key": "a",
        "label": "가로 cm",
        "min": 1,
        "max": 8,
        "value": 4,
        "step": 1
      },
      {
        "key": "b",
        "label": "세로 cm",
        "min": 1,
        "max": 8,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "높이 cm",
        "min": 1,
        "max": 8,
        "value": 2,
        "step": 1
      }
    ],
    "obs": [
      "세 길이의 곱이 같으면 직육면체의 부피도 같습니다.",
      "부피가 같다고 겉넓이가 같지는 않습니다."
    ],
    "targets": [
      {
        "label": "4와 3과 2 상자",
        "instruction": "가로 cm 4 / 세로 cm 3 / 높이 cm 2로 맞추세요.",
        "values": {
          "a": 4,
          "b": 3,
          "c": 2
        }
      },
      {
        "label": "6과 2와 2 상자",
        "instruction": "가로 cm 6 / 세로 cm 2 / 높이 cm 2로 맞추세요.",
        "values": {
          "a": 6,
          "b": 2,
          "c": 2
        }
      }
    ]
  },
  {
    "id": "elem6-x-cube-surface",
    "year": 6,
    "title": "정육면체의 같은 여섯 면",
    "desc": "정육면체의 여섯 면은 모두 같은 정사각형입니다. 정육면체의 겉넓이는 한 면의 넓이에 6을 곱합니다.",
    "q": "한 모서리가 3 cm인 정육면체의 겉넓이는 얼마일까요?",
    "kind": "solid",
    "mode": "surface",
    "controls": [
      {
        "key": "a",
        "label": "가로 cm",
        "min": 1,
        "max": 6,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "세로 cm",
        "min": 1,
        "max": 6,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "높이 cm",
        "min": 1,
        "max": 6,
        "value": 3,
        "step": 1
      }
    ],
    "obs": [
      "정육면체의 여섯 면은 모두 같은 정사각형입니다.",
      "정육면체의 겉넓이는 한 면의 넓이에 6을 곱합니다."
    ],
    "targets": [
      {
        "label": "모서리 3인 정육면체",
        "instruction": "가로 cm 3 / 세로 cm 3 / 높이 cm 3로 맞추세요.",
        "values": {
          "a": 3,
          "b": 3,
          "c": 3
        }
      },
      {
        "label": "모서리 4인 정육면체",
        "instruction": "가로 cm 4 / 세로 cm 4 / 높이 cm 4로 맞추세요.",
        "values": {
          "a": 4,
          "b": 4,
          "c": 4
        }
      }
    ]
  },
  {
    "id": "elem6-x-hidden-cubes",
    "year": 6,
    "title": "보이지 않는 정육면체까지 세기",
    "desc": "앞에서 보이는 정육면체만 세면 안쪽의 수를 놓칠 수 있습니다. 한 층의 수와 층 수를 이용하면 가려진 정육면체도 셀 수 있습니다.",
    "q": "쌓은 모양의 안쪽에도 정육면체가 있을까요?",
    "kind": "solid",
    "mode": "cubes",
    "controls": [
      {
        "key": "a",
        "label": "가로 개수",
        "min": 1,
        "max": 5,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "세로 개수",
        "min": 1,
        "max": 5,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "높이 개수",
        "min": 1,
        "max": 5,
        "value": 3,
        "step": 1
      }
    ],
    "obs": [
      "앞에서 보이는 정육면체만 세면 안쪽의 수를 놓칠 수 있습니다.",
      "한 층의 수와 층 수를 이용하면 가려진 정육면체도 셀 수 있습니다."
    ],
    "targets": [
      {
        "label": "3개씩 세 방향",
        "instruction": "가로 개수 3 / 세로 개수 3 / 높이 개수 3로 맞추세요.",
        "values": {
          "a": 3,
          "b": 3,
          "c": 3
        }
      },
      {
        "label": "높이를 한 층 낮추기",
        "instruction": "가로 개수 3 / 세로 개수 3 / 높이 개수 2로 맞추세요.",
        "values": {
          "a": 3,
          "b": 3,
          "c": 2
        }
      }
    ]
  },
  {
    "id": "elem6-x-pie-share",
    "year": 6,
    "title": "원그래프에서 전체와 부분 보기",
    "desc": "원 전체는 자료 전체를 나타냅니다. 각 분류의 비율이 클수록 원그래프의 부채꼴도 큽니다.",
    "q": "전체에서 가장 큰 부분은 원의 어느 조각일까요?",
    "kind": "chart",
    "mode": "pie",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분류",
        "min": 0,
        "max": 20,
        "value": 6,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 분류",
        "min": 0,
        "max": 20,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "셋째 분류",
        "min": 0,
        "max": 20,
        "value": 1,
        "step": 1
      }
    ],
    "obs": [
      "원 전체는 자료 전체를 나타냅니다.",
      "각 분류의 비율이 클수록 원그래프의 부채꼴도 큽니다."
    ],
    "targets": [
      {
        "label": "60%인 분류",
        "instruction": "첫째 분류 6 / 둘째 분류 3 / 셋째 분류 1로 맞추세요.",
        "values": {
          "a": 6,
          "b": 3,
          "c": 1
        }
      },
      {
        "label": "두 분류가 절반씩",
        "instruction": "첫째 분류 5 / 둘째 분류 5 / 셋째 분류 0로 맞추세요.",
        "values": {
          "a": 5,
          "b": 5,
          "c": 0
        }
      }
    ]
  },
  {
    "id": "elem6-x-pie-scale",
    "year": 6,
    "title": "전체 수가 달라도 같은 원그래프",
    "desc": "각 자료와 전체가 같은 배수로 커지면 비율은 그대로입니다. 원그래프는 자료의 절대적인 수보다 구성 비율을 보여 줍니다.",
    "q": "각 자료를 모두 두 배로 하면 원그래프도 달라질까요?",
    "kind": "chart",
    "mode": "pie",
    "controls": [
      {
        "key": "a",
        "label": "첫째 자료",
        "min": 0,
        "max": 24,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 자료",
        "min": 0,
        "max": 24,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "셋째 자료",
        "min": 0,
        "max": 24,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "각 자료와 전체가 같은 배수로 커지면 비율은 그대로입니다.",
      "원그래프는 자료의 절대적인 수보다 구성 비율을 보여 줍니다."
    ],
    "targets": [
      {
        "label": "전체 10의 비율",
        "instruction": "첫째 자료 2 / 둘째 자료 3 / 셋째 자료 5로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 5
        }
      },
      {
        "label": "전체를 두 배로",
        "instruction": "첫째 자료 4 / 둘째 자료 6 / 셋째 자료 10로 맞추세요.",
        "values": {
          "a": 4,
          "b": 6,
          "c": 10
        }
      }
    ]
  },
  {
    "id": "elem6-x-bar-difference-ratio",
    "year": 6,
    "title": "차이와 몇 배는 다른 비교",
    "desc": "두 수의 차이는 뺄셈으로 구합니다. 몇 배인지는 기준이 되는 수로 나누어 구합니다.",
    "q": "8과 4는 차이가 4이고 몇 배 관계일까요?",
    "kind": "chart",
    "mode": "bar",
    "controls": [
      {
        "key": "a",
        "label": "첫째 자료",
        "min": 0,
        "max": 24,
        "value": 8,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 자료",
        "min": 0,
        "max": 24,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "셋째 자료",
        "min": 0,
        "max": 24,
        "value": 2,
        "step": 1
      }
    ],
    "obs": [
      "두 수의 차이는 뺄셈으로 구합니다.",
      "몇 배인지는 기준이 되는 수로 나누어 구합니다."
    ],
    "targets": [
      {
        "label": "차이와 두 배 관계",
        "instruction": "첫째 자료 8 / 둘째 자료 4 / 셋째 자료 2로 맞추세요.",
        "values": {
          "a": 8,
          "b": 4,
          "c": 2
        }
      },
      {
        "label": "같은 차이 다른 비율",
        "instruction": "첫째 자료 12 / 둘째 자료 8 / 셋째 자료 4로 맞추세요.",
        "values": {
          "a": 12,
          "b": 8,
          "c": 4
        }
      }
    ]
  },
  {
    "id": "elem6-x-line-steady",
    "year": 6,
    "title": "일정한 증가를 꺾은선으로",
    "desc": "같은 간격에서 증가량이 같으면 같은 기울기로 이어집니다. 증가량이 달라지면 선분이 꺾이는 모양도 달라집니다.",
    "q": "값이 일정하게 늘 때 그래프에는 어떤 특징이 있을까요?",
    "kind": "chart",
    "mode": "line",
    "controls": [
      {
        "key": "a",
        "label": "첫째 순서",
        "min": 0,
        "max": 30,
        "value": 5,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 순서",
        "min": 0,
        "max": 30,
        "value": 10,
        "step": 1
      },
      {
        "key": "c",
        "label": "셋째 순서",
        "min": 0,
        "max": 30,
        "value": 15,
        "step": 1
      }
    ],
    "obs": [
      "같은 간격에서 증가량이 같으면 같은 기울기로 이어집니다.",
      "증가량이 달라지면 선분이 꺾이는 모양도 달라집니다."
    ],
    "targets": [
      {
        "label": "5씩 증가",
        "instruction": "첫째 순서 5 / 둘째 순서 10 / 셋째 순서 15로 맞추세요.",
        "values": {
          "a": 5,
          "b": 10,
          "c": 15
        }
      },
      {
        "label": "마지막 증가량 바꾸기",
        "instruction": "첫째 순서 5 / 둘째 순서 10 / 셋째 순서 20로 맞추세요.",
        "values": {
          "a": 5,
          "b": 10,
          "c": 20
        }
      }
    ]
  },
  {
    "id": "elem6-x-average-large-value",
    "year": 6,
    "title": "한 자료가 커지면 평균도 움직여요",
    "desc": "자료 하나가 3 커지면 자료 3개의 평균은 1 커집니다. 평균은 모든 자료의 값에 영향을 받습니다.",
    "q": "다른 두 자료는 같은데 하나만 커지면 평균은 얼마나 커질까요?",
    "kind": "chart",
    "mode": "average",
    "controls": [
      {
        "key": "a",
        "label": "첫째 자료",
        "min": 0,
        "max": 30,
        "value": 6,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 자료",
        "min": 0,
        "max": 30,
        "value": 6,
        "step": 1
      },
      {
        "key": "c",
        "label": "셋째 자료",
        "min": 0,
        "max": 30,
        "value": 6,
        "step": 1
      }
    ],
    "obs": [
      "자료 하나가 3 커지면 자료 3개의 평균은 1 커집니다.",
      "평균은 모든 자료의 값에 영향을 받습니다."
    ],
    "targets": [
      {
        "label": "세 자료가 모두 6",
        "instruction": "첫째 자료 6 / 둘째 자료 6 / 셋째 자료 6로 맞추세요.",
        "values": {
          "a": 6,
          "b": 6,
          "c": 6
        }
      },
      {
        "label": "셋째 자료만 9",
        "instruction": "첫째 자료 6 / 둘째 자료 6 / 셋째 자료 9로 맞추세요.",
        "values": {
          "a": 6,
          "b": 6,
          "c": 9
        }
      }
    ]
  },
  {
    "id": "elem6-x-probability-ratio",
    "year": 6,
    "title": "가능성을 비율로 비교",
    "desc": "같은 크기의 공을 공평하게 뽑는 경우 해당 색 수를 전체 수로 나누어 가능성을 나타냅니다. 해당 색 수가 같아도 전체가 커지면 그 색을 뽑을 가능성은 작아집니다.",
    "q": "초록 공 3개가 있는 상자라도 전체 수가 다르면 가능성이 같을까요?",
    "kind": "chart",
    "mode": "probability",
    "controls": [
      {
        "key": "a",
        "label": "초록 공",
        "min": 0,
        "max": 20,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "주황 공",
        "min": 0,
        "max": 20,
        "value": 2,
        "step": 1
      },
      {
        "key": "c",
        "label": "보라 공",
        "min": 0,
        "max": 20,
        "value": 1,
        "step": 1
      }
    ],
    "obs": [
      "같은 크기의 공을 공평하게 뽑는 경우 해당 색 수를 전체 수로 나누어 가능성을 나타냅니다.",
      "해당 색 수가 같아도 전체가 커지면 그 색을 뽑을 가능성은 작아집니다."
    ],
    "targets": [
      {
        "label": "전체 6에서 초록 3",
        "instruction": "초록 공 3 / 주황 공 2 / 보라 공 1로 맞추세요.",
        "values": {
          "a": 3,
          "b": 2,
          "c": 1
        }
      },
      {
        "label": "전체 12에서 초록 3",
        "instruction": "초록 공 3 / 주황 공 5 / 보라 공 4로 맞추세요.",
        "values": {
          "a": 3,
          "b": 5,
          "c": 4
        }
      }
    ]
  },
  {
    "id": "elem6-x-rectangle-scale",
    "year": 6,
    "title": "가로와 세로를 함께 늘리기",
    "desc": "넓이는 두 방향 길이의 곱으로 구합니다. 두 길이가 모두 두 배이면 넓이는 네 배입니다.",
    "q": "직사각형의 두 길이를 모두 두 배로 하면 넓이는 몇 배일까요?",
    "kind": "geometry",
    "mode": "rectangle",
    "controls": [
      {
        "key": "a",
        "label": "가로",
        "min": 1,
        "max": 12,
        "value": 3,
        "step": 1
      },
      {
        "key": "b",
        "label": "세로",
        "min": 1,
        "max": 12,
        "value": 4,
        "step": 1
      }
    ],
    "obs": [
      "넓이는 두 방향 길이의 곱으로 구합니다.",
      "두 길이가 모두 두 배이면 넓이는 네 배입니다."
    ],
    "targets": [
      {
        "label": "3과 4의 넓이",
        "instruction": "가로 3 / 세로 4로 맞추세요.",
        "values": {
          "a": 3,
          "b": 4
        }
      },
      {
        "label": "6과 8의 넓이",
        "instruction": "가로 6 / 세로 8로 맞추세요.",
        "values": {
          "a": 6,
          "b": 8
        }
      }
    ]
  },
  {
    "id": "elem6-x-triangle-height-ratio",
    "year": 6,
    "title": "높이와 넓이의 비례",
    "desc": "밑변을 고정하면 삼각형의 넓이는 높이에 비례합니다. 높이가 세 배이면 밑변과 높이의 곱도 세 배가 됩니다.",
    "q": "밑변이 같은 삼각형의 높이가 세 배이면 넓이도 세 배일까요?",
    "kind": "geometry",
    "mode": "triangle",
    "controls": [
      {
        "key": "a",
        "label": "밑변",
        "min": 1,
        "max": 12,
        "value": 8,
        "step": 1
      },
      {
        "key": "b",
        "label": "높이",
        "min": 1,
        "max": 12,
        "value": 2,
        "step": 1
      }
    ],
    "obs": [
      "밑변을 고정하면 삼각형의 넓이는 높이에 비례합니다.",
      "높이가 세 배이면 밑변과 높이의 곱도 세 배가 됩니다."
    ],
    "targets": [
      {
        "label": "높이 2의 넓이",
        "instruction": "밑변 8 / 높이 2로 맞추세요.",
        "values": {
          "a": 8,
          "b": 2
        }
      },
      {
        "label": "높이를 세 배로",
        "instruction": "밑변 8 / 높이 6로 맞추세요.",
        "values": {
          "a": 8,
          "b": 6
        }
      }
    ]
  },
  {
    "id": "elem6-x-trapezoid-average-base",
    "year": 6,
    "title": "두 밑변의 평균으로 보는 사다리꼴",
    "desc": "두 밑변의 합을 2로 나눈 값은 두 밑변의 평균입니다. 사다리꼴 넓이는 두 밑변의 평균에 높이를 곱한 값으로도 구합니다.",
    "q": "윗변과 아랫변의 평균을 높이와 곱하면 무엇이 될까요?",
    "kind": "geometry",
    "mode": "trapezoid",
    "controls": [
      {
        "key": "a",
        "label": "아랫변",
        "min": 2,
        "max": 12,
        "value": 10,
        "step": 1
      },
      {
        "key": "b",
        "label": "높이",
        "min": 1,
        "max": 8,
        "value": 4,
        "step": 1
      },
      {
        "key": "c",
        "label": "윗변",
        "min": 2,
        "max": 12,
        "value": 6,
        "step": 1
      }
    ],
    "obs": [
      "두 밑변의 합을 2로 나눈 값은 두 밑변의 평균입니다.",
      "사다리꼴 넓이는 두 밑변의 평균에 높이를 곱한 값으로도 구합니다."
    ],
    "targets": [
      {
        "label": "밑변 평균 8",
        "instruction": "아랫변 10 / 높이 4 / 윗변 6로 맞추세요.",
        "values": {
          "a": 10,
          "b": 4,
          "c": 6
        }
      },
      {
        "label": "두 밑변이 모두 8",
        "instruction": "아랫변 8 / 높이 4 / 윗변 8로 맞추세요.",
        "values": {
          "a": 8,
          "b": 4,
          "c": 8
        }
      }
    ]
  },
  {
    "id": "elem6-x-rhombus-scale",
    "year": 6,
    "title": "대각선과 넓이의 변화",
    "desc": "마름모 넓이는 두 대각선 길이의 곱의 절반입니다. 한 대각선을 고정하면 넓이는 다른 대각선의 길이에 비례합니다.",
    "q": "한 대각선만 두 배로 하면 마름모의 넓이는 몇 배일까요?",
    "kind": "geometry",
    "mode": "rhombus",
    "controls": [
      {
        "key": "a",
        "label": "첫째 대각선",
        "min": 2,
        "max": 16,
        "value": 6,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 대각선",
        "min": 2,
        "max": 16,
        "value": 8,
        "step": 1
      }
    ],
    "obs": [
      "마름모 넓이는 두 대각선 길이의 곱의 절반입니다.",
      "한 대각선을 고정하면 넓이는 다른 대각선의 길이에 비례합니다."
    ],
    "targets": [
      {
        "label": "대각선 6과 8",
        "instruction": "첫째 대각선 6 / 둘째 대각선 8로 맞추세요.",
        "values": {
          "a": 6,
          "b": 8
        }
      },
      {
        "label": "첫째 대각선 두 배",
        "instruction": "첫째 대각선 12 / 둘째 대각선 8로 맞추세요.",
        "values": {
          "a": 12,
          "b": 8
        }
      }
    ]
  },
  {
    "id": "elem6-x-gcd-reduce-ratio",
    "year": 6,
    "title": "비를 간단히 만드는 공약수",
    "desc": "비의 두 수를 같은 공약수로 나누면 비율은 같습니다. 최대공약수로 나누면 서로소인 자연수의 비를 얻습니다.",
    "q": "18 대 24의 두 수를 어떤 가장 큰 수로 함께 나눌 수 있을까요?",
    "kind": "number",
    "mode": "gcd",
    "controls": [
      {
        "key": "a",
        "label": "비의 앞 수",
        "min": 1,
        "max": 60,
        "value": 18,
        "step": 1
      },
      {
        "key": "b",
        "label": "비의 뒤 수",
        "min": 1,
        "max": 60,
        "value": 24,
        "step": 1
      }
    ],
    "obs": [
      "비의 두 수를 같은 공약수로 나누면 비율은 같습니다.",
      "최대공약수로 나누면 서로소인 자연수의 비를 얻습니다."
    ],
    "targets": [
      {
        "label": "18 대 24 간단히",
        "instruction": "비의 앞 수 18 / 비의 뒤 수 24로 맞추세요.",
        "values": {
          "a": 18,
          "b": 24
        }
      },
      {
        "label": "35 대 49 간단히",
        "instruction": "비의 앞 수 35 / 비의 뒤 수 49로 맞추세요.",
        "values": {
          "a": 35,
          "b": 49
        }
      }
    ]
  },
  {
    "id": "elem6-x-lcm-common-den",
    "year": 6,
    "title": "통분에 필요한 공통 단위",
    "desc": "두 분모의 공배수로 분모를 맞출 수 있습니다. 최소공배수는 가장 작은 양의 공통 분모입니다.",
    "q": "분모가 6과 8인 분수를 비교할 때 가장 작은 공통 분모는 무엇일까요?",
    "kind": "number",
    "mode": "lcm",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분모",
        "min": 2,
        "max": 15,
        "value": 6,
        "step": 1
      },
      {
        "key": "b",
        "label": "둘째 분모",
        "min": 2,
        "max": 15,
        "value": 8,
        "step": 1
      }
    ],
    "obs": [
      "두 분모의 공배수로 분모를 맞출 수 있습니다.",
      "최소공배수는 가장 작은 양의 공통 분모입니다."
    ],
    "targets": [
      {
        "label": "6과 8의 공통 분모",
        "instruction": "첫째 분모 6 / 둘째 분모 8로 맞추세요.",
        "values": {
          "a": 6,
          "b": 8
        }
      },
      {
        "label": "5와 10의 공통 분모",
        "instruction": "첫째 분모 5 / 둘째 분모 10로 맞추세요.",
        "values": {
          "a": 5,
          "b": 10
        }
      }
    ]
  },
  {
    "id": "elem6-x-proportional-table",
    "year": 6,
    "title": "정비례와 처음 더하는 수",
    "desc": "출력이 입력에 일정한 수를 곱한 값이면 두 양은 정비례합니다. 처음 더하는 수가 0이 아니면 일반적으로 정비례가 아닙니다.",
    "q": "입력이 두 배가 되면 출력도 두 배가 되는 규칙은 무엇일까요?",
    "kind": "sequence",
    "mode": "table",
    "controls": [
      {
        "key": "a",
        "label": "처음 더하는 수",
        "min": 0,
        "max": 10,
        "value": 0,
        "step": 1
      },
      {
        "key": "b",
        "label": "입력에 곱하는 수",
        "min": 1,
        "max": 8,
        "value": 3,
        "step": 1
      },
      {
        "key": "c",
        "label": "나타낼 입력 수",
        "min": 3,
        "max": 8,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "출력이 입력에 일정한 수를 곱한 값이면 두 양은 정비례합니다.",
      "처음 더하는 수가 0이 아니면 일반적으로 정비례가 아닙니다."
    ],
    "targets": [
      {
        "label": "3배의 정비례",
        "instruction": "처음 더하는 수 0 / 입력에 곱하는 수 3 / 나타낼 입력 수 5로 맞추세요.",
        "values": {
          "a": 0,
          "b": 3,
          "c": 5
        }
      },
      {
        "label": "3배에 2 더하기",
        "instruction": "처음 더하는 수 2 / 입력에 곱하는 수 3 / 나타낼 입력 수 5로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 5
        }
      }
    ],
    "unit": "offset-step"
  },
  {
    "id": "elem6-x-midnight-time",
    "year": 6,
    "title": "하루를 넘는 시간 계산",
    "desc": "하루는 24시간입니다. 24시를 넘기면 다음 날의 시각으로 읽어야 합니다.",
    "q": "23시 40분에서 50분이 지나면 날짜는 어떻게 될까요?",
    "kind": "measure",
    "mode": "time",
    "controls": [
      {
        "key": "a",
        "label": "시",
        "min": 0,
        "max": 23,
        "value": 23,
        "step": 1
      },
      {
        "key": "b",
        "label": "분",
        "min": 0,
        "max": 59,
        "value": 40,
        "step": 1
      },
      {
        "key": "c",
        "label": "지나는 분",
        "min": 0,
        "max": 180,
        "value": 50,
        "step": 1
      }
    ],
    "obs": [
      "하루는 24시간입니다.",
      "24시를 넘기면 다음 날의 시각으로 읽어야 합니다."
    ],
    "targets": [
      {
        "label": "자정을 넘는 50분",
        "instruction": "시 23 / 분 40 / 지나는 분 50로 맞추세요.",
        "values": {
          "a": 23,
          "b": 40,
          "c": 50
        }
      },
      {
        "label": "자정 직전까지",
        "instruction": "시 23 / 분 40 / 지나는 분 15로 맞추세요.",
        "values": {
          "a": 23,
          "b": 40,
          "c": 15
        }
      }
    ],
    "unit": "elapsed-clock"
  },
  {
    "id": "elem6-x-discount-percent",
    "year": 6,
    "title": "할인하는 양과 남은 가격",
    "desc": "할인하는 양은 원래 가격에 할인율을 곱해 구합니다. 남은 가격은 원래 가격에서 할인하는 양을 뺀 값입니다.",
    "q": "전체 가격의 20%를 할인하면 남는 비율은 얼마일까요?",
    "kind": "ratio",
    "mode": "percent",
    "controls": [
      {
        "key": "a",
        "label": "원래 가격",
        "min": 100,
        "max": 1000,
        "value": 500,
        "step": 1
      },
      {
        "key": "b",
        "label": "할인율 %",
        "min": 0,
        "max": 100,
        "value": 20,
        "step": 1
      }
    ],
    "obs": [
      "할인하는 양은 원래 가격에 할인율을 곱해 구합니다.",
      "남은 가격은 원래 가격에서 할인하는 양을 뺀 값입니다."
    ],
    "targets": [
      {
        "label": "500의 20% 할인액",
        "instruction": "원래 가격 500 / 할인율 % 20로 맞추세요.",
        "values": {
          "a": 500,
          "b": 20
        }
      },
      {
        "label": "500의 40% 할인액",
        "instruction": "원래 가격 500 / 할인율 % 40로 맞추세요.",
        "values": {
          "a": 500,
          "b": 40
        }
      }
    ]
  },
  {
    "id": "elem6-x-fraction-difference-one",
    "year": 6,
    "title": "1에서 분수를 빼기",
    "desc": "전체 1은 분모와 분자가 같은 분수로 바꿀 수 있습니다. 1에서 뺀 부분과 남은 부분을 합하면 전체 1입니다.",
    "q": "전체 하나에서 5/8을 덜어 내면 얼마가 남을까요?",
    "kind": "fraction",
    "mode": "sub",
    "controls": [
      {
        "key": "a",
        "label": "첫째 분자",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 분모",
        "min": 1,
        "max": 1,
        "value": 1,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 분자",
        "min": 0,
        "max": 8,
        "value": 5,
        "step": 1
      },
      {
        "key": "d",
        "label": "둘째 분모",
        "min": 8,
        "max": 8,
        "value": 8,
        "step": 1
      }
    ],
    "obs": [
      "전체 1은 분모와 분자가 같은 분수로 바꿀 수 있습니다.",
      "1에서 뺀 부분과 남은 부분을 합하면 전체 1입니다."
    ],
    "targets": [
      {
        "label": "5/8을 덜어 내기",
        "instruction": "첫째 분자 1 / 첫째 분모 1 / 둘째 분자 5 / 둘째 분모 8로 맞추세요.",
        "values": {
          "a": 1,
          "b": 1,
          "c": 5,
          "d": 8
        }
      },
      {
        "label": "남은 부분과 역할 바꾸기",
        "instruction": "첫째 분자 1 / 첫째 분모 1 / 둘째 분자 3 / 둘째 분모 8로 맞추세요.",
        "values": {
          "a": 1,
          "b": 1,
          "c": 3,
          "d": 8
        }
      }
    ]
  }
];
