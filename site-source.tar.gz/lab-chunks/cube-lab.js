// 큐브 실험실 — cube-lab/index.html(단일 HTML)을 같은 사이트 안의 iframe으로 띄우고
// 아틀리에의 다크 모드·링크 공유·그림 저장·예측 문항과 연결한다.
import { mountPredict, norm } from "./predict-ui.js";

const SRC = "cube-lab/index.html";
// 정답은 cube-lab/core.js로 직접 계산해 확인한 값 (2026-10-15)
const PREDICT = [
  { q: "3×3 큐브에서 R(오른면 시계 방향 90°)만 계속 돌리면 몇 번 만에 처음 상태로 돌아올까요?", a: 4, why: "90°씩 4번 돌리면 360°가 되어 모든 조각이 제자리로 돌아옵니다." },
  { q: "R U와 U R은 같은 결과를 만들까요?", opt: [["same", "같다"], ["diff", "다르다"]], a: "diff", why: "두 수순을 각각 실행해 전개도를 비교하면 다릅니다. 큐브의 회전은 순서를 바꾸면 결과가 달라지는(교환법칙이 성립하지 않는) 연산입니다." },
  { q: "색 큐브(클래식 컬러)에서 R U R′ U′ 묶음을 몇 번 반복하면 처음 상태로 돌아올까요?", a: 6, why: "‘풀이와 수학’ 탭의 ‘반복 속에서 찾은 6’ 실험으로 확인할 수 있습니다. 이 묶음을 6번 반복하면 모든 조각이 제자리로 돌아옵니다." },
  { q: "색 큐브에서 R U 묶음을 몇 번 반복하면 처음 색 배열로 돌아올까요?", a: 105, why: "R U의 주기는 105입니다. 조각들은 서로 다른 길이의 고리를 이루며 돌고, 모든 조각이 동시에 제자리·제방향으로 오는 횟수는 각 고리 주기의 최소공배수입니다." },
  { q: "그림 큐브(예: 숲속 친구들·마방진)에서는 R U 묶음을 몇 번 반복해야 그림의 방향까지 처음 상태로 돌아올까요?", a: 420, why: "색만 보면 105번이지만, 그림 큐브는 가운데 조각이 돌아간 방향까지 구별합니다. 그래서 105의 4배인 420번이 필요합니다." },
  { q: "2×2 큐브가 만들 수 있는 서로 다른 상태는 모두 몇 가지일까요?", a: 3674160, why: "한 꼭짓점을 기준으로 고정하면 나머지 7개 조각의 자리는 7! = 5040가지, 방향은 3⁶ = 729가지입니다. 5040 × 729 = 3,674,160." },
  { q: "어떤 2×2 상태든 최대 몇 수(180° 회전도 1수) 안에 맞출 수 있을까요?", a: 11, why: "컴퓨터로 3,674,160가지 상태를 모두 조사하면 가장 먼 상태도 11수면 됩니다. 이 실험실의 2×2 힌트는 그 최단 경로를 직접 계산합니다." },
  { q: "3×3 큐브의 상태 수는 대략 얼마일까요?", opt: [["a", "약 4조 (4×10¹²)"], ["b", "약 4300경 (4.3×10¹⁹)"], ["c", "약 10¹⁰⁰"]], a: "b", why: "8!×3⁷×12!×2¹¹÷2 = 43,252,003,274,489,856,000가지입니다." },
].map(norm);

const CSS = `.cube-layout{grid-template-columns:1fr!important}
.cube-layout .v3-sidepanel{position:static!important;max-height:none!important}
.cube-stage{height:auto!important;min-height:0!important;padding:0!important;display:block!important;background:none!important;overflow:visible!important}
.cube-frame{display:block;width:100%;height:min(calc(100vh - 120px),980px);min-height:620px;border:0;border-radius:14px;background:var(--at-bg,#f7f6f1)}
.cube-ctl{display:grid;gap:12px}
.cube-ctl p{margin:0;line-height:1.6}
.cube-ctl ul{margin:0;padding-left:1.1em;line-height:1.7}
.cube-ctl .cube-open{display:inline-flex;align-items:center;justify-content:center;min-height:48px;padding:0 16px;border-radius:10px;border:1px solid currentColor;text-decoration:none;font-weight:600}
@media (max-width:700px){.cube-frame{height:calc(100vh - 70px);min-height:560px;border-radius:0}}`;

export function mount(id, ctx) {
  if (!document.getElementById("cube-lab-css")) {
    const st = document.createElement("style");
    st.id = "cube-lab-css";
    st.textContent = CSS;
    document.head.append(st);
  }
  const dark = () => document.documentElement.dataset.theme === "dark";
  ctx.stage.classList.add("cube-stage");
  ctx.stage.closest(".lab-layout")?.classList.add("cube-layout");
  ctx.stage.innerHTML = `<iframe class="cube-frame" src="${SRC}?embed=1" title="큐브 실험실 — 큐브를 직접 돌리는 화면" allow="fullscreen; clipboard-write; autoplay" allowfullscreen></iframe>`;
  if (ctx.hint) ctx.hint.textContent = "큐브 위 화살표를 누르거나 칸을 밀어서 돌려 보세요";
  ctx.metrics.innerHTML = "";
  ctx.controls.innerHTML = `<div class="cube-ctl"><p>2×2부터 7×7까지 크기를 고르고, 테마 50종(수학 탐구 23종 포함) 중 하나로 섞은 뒤 다시 맞춰 보세요.</p><ul><li><b>2×2</b>는 힌트가 지금 상태에서 가장 짧은 풀이를 계산해요.</li><li><b>3×3</b>은 한 층씩 맞추는 7단계 길잡이가 지금 몇 단계인지 알려 줘요.</li><li>왼쪽 위 <b>뒤에서 본 모습</b> 창으로 안 보이는 뒤·왼쪽·아래 면을 함께 봐요. ⟲ 단추는 큐브를 뒤로 돌려 줘요.</li><li>♪ 단추로 배경음악과 회전 소리를 켜고 끌 수 있어요.</li><li>‘풀이와 수학’ 탭에서 반복·역연산 실험을, ‘논문과 수업’ 탭에서 연구 요약을 볼 수 있어요.</li></ul><a class="cube-open" href="${SRC}" target="_blank" rel="noopener">큐브만 크게 열기 ↗</a></div>`;
  const frame = ctx.stage.querySelector("iframe");
  let api = null, destroyed = false;
  const preset = ctx.preset && ctx.preset.format ? ctx.preset : null;
  const onLoad = () => {
    if (destroyed) return;
    try { api = frame.contentWindow?.CubeLabAPI || null; } catch { api = null; }
    if (!api) return;
    api.theme(dark());
    if (preset && !api.load(preset)) ctx.notice?.("링크에 담긴 큐브 상태를 불러오지 못해 이 기기에 저장된 큐브로 시작합니다.");
  };
  frame.addEventListener("load", onLoad);
  const slot = document.getElementById("pred-slot");
  if (slot) { slot.innerHTML = `<section class="at-pred-panel" id="cube-pred"></section>`; mountPredict(slot.querySelector("#cube-pred"), PREDICT); }
  return {
    // 링크 공유·학습지에 담을 상태 — 기록이 너무 길면 크기와 테마만 담는다
    get state() {
      if (!api) return {};
      const s = api.state(), long = s.history.length > 300;
      if (long) ctx.notice?.("회전 기록이 300수를 넘어서 링크에는 크기와 테마만 담았어요. 전체 기록은 ‘실험 저장’ 파일로 보관하세요.");
      return { format: s.format, themeId: s.themeId, interaction: s.interaction, n: s.n, history: long ? [] : s.history, algorithm: "" };
    },
    capture() {
      if (!api) return;
      const a = document.createElement("a");
      a.href = api.png();
      a.download = "큐브-실험실.png";
      a.click();
    },
    theme(v) { api?.theme(!!v); },
    destroy() {
      destroyed = true;
      frame.removeEventListener("load", onLoad);
      ctx.stage.classList.remove("cube-stage");
      ctx.stage.closest(".lab-layout")?.classList.remove("cube-layout");
      api = null;
    },
  };
}
