// 특별관 1 — 수학의 역설 22개
import { fmt, frac, clamp } from "./hs-core.js";

const P = 15;
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const RNG = (seed) => { let x = (Math.abs(seed | 0) * 7919 + 104729) % 2147483647 || 1; return () => (x = (x * 16807) % 2147483647) / 2147483647; };
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
const SEED = { buttons: [["seed", "다시 뽑기"]], onDo(a, s) { if (a === "seed") s.seed = (s.seed % 97) + 1; } };
const memo = (fn) => { let k = null, v = null; return (...a) => { const kk = JSON.stringify(a); if (kk !== k) { k = kk; v = fn(...a); } return v; }; };

// 베르트랑 현
const chords = memo((m, n, seed) => { const r = RNG(seed), C = []; for (let i = 0; i < n; i++) { let A, B; if (m === "a") { const t1 = r() * 2 * Math.PI, t2 = r() * 2 * Math.PI; A = [Math.cos(t1), Math.sin(t1)]; B = [Math.cos(t2), Math.sin(t2)]; } else { let mx, my; if (m === "b") { const th = r() * 2 * Math.PI, d = r(); mx = d * Math.cos(th); my = d * Math.sin(th); } else { do { mx = 2 * r() - 1; my = 2 * r() - 1; } while (mx * mx + my * my > 1); } const d = Math.hypot(mx, my) || 1e-9, h = Math.sqrt(Math.max(0, 1 - d * d)), ux = -my / d, uy = mx / d; A = [mx + ux * h, my + uy * h]; B = [mx - ux * h, my - uy * h]; } C.push([A, B, Math.hypot(A[0] - B[0], A[1] - B[1]) > Math.sqrt(3)]); } return C; });
// 상트페테르부르크
const stp = memo((n, seed) => { const r = RNG(seed), avg = []; let S = 0, mx = 0; for (let i = 1; i <= n; i++) { let k = 1; while (r() < 0.5 && k < 40) k++; const w = 2 ** k; S += w; mx = Math.max(mx, w); if (i <= 400 || i % Math.ceil(n / 400) === 0) avg.push([i, S / i]); } return { avg, mean: S / n, mx }; });
// 도박사의 오류
const gamb = memo((n, seed) => { const r = RNG(seed), F = Array.from({ length: n }, () => r() < 0.5), out = []; for (let k = 1; k <= 6; k++) { let c = 0, h = 0; for (let i = k; i < n; i++) { let ok = true; for (let j = 1; j <= k; j++) if (!F[i - j]) { ok = false; break; } if (ok) { c++; if (F[i]) h++; } } out.push([k, c, c ? h / c : 0]); } return out; });
// 우정 역설 그래프 (선호적 연결)
const net = memo((n, seed) => { const r = RNG(seed), E = [[0, 1]], deg = [1, 1]; for (let v = 2; v < n; v++) { deg.push(0); const tot = deg.reduce((a, b) => a + b, 0) - 0, pick = () => { let x = r() * tot; for (let u = 0; u < v; u++) { x -= deg[u]; if (x <= 0) return u; } return 0; }; const a = pick(); let b = pick(); E.push([v, a]); deg[v]++; deg[a]++; if (r() < 0.45 && b !== a) { E.push([v, b]); deg[v]++; deg[b]++; } } return { E, deg }; });
// 버스 대기
const buses = memo((mode, seed) => { const r = RNG(seed), I = []; let t = 0; while (t < 120) { const d = mode === "reg" ? 10 : mode === "exp" ? -10 * Math.log(1 - r()) : r() < 0.5 ? 2 : 18; I.push([t, d]); t += d; } return I; });
// 리만 재배열
const rearr = (T, N) => { let p = 1, q = 2, S = 0; const pts = [[0, 0]]; for (let i = 1; i <= N; i++) { if (S <= T) { S += 1 / p; p += 2; } else { S -= 1 / q; q += 2; } pts.push([i, S]); } return pts; };
const koch = (k) => { let P0 = [[0, 0], [9, 0]]; for (let i = 0; i < k; i++) { const Q = []; for (let j = 0; j < P0.length - 1; j++) { const [a, b] = [P0[j], P0[j + 1]], d = [(b[0] - a[0]) / 3, (b[1] - a[1]) / 3], p1 = [a[0] + d[0], a[1] + d[1]], p2 = [a[0] + 2 * d[0], a[1] + 2 * d[1]], pk = [p1[0] + d[0] / 2 - (d[1] * Math.sqrt(3)) / 2, p1[1] + d[1] / 2 + (d[0] * Math.sqrt(3)) / 2]; Q.push(a, p1, pk, p2); } Q.push(P0.at(-1)); P0 = Q; } return P0; };
const FIBS = { a: [2, 3, 5], b: [3, 5, 8], c: [5, 8, 13] };
const DICE = { A: [4, 4, 4, 4, 0, 0], B: [3, 3, 3, 3, 3, 3], C: [6, 6, 2, 2, 2, 2], D: [5, 5, 5, 1, 1, 1] };
const braess = (N, sc) => { const no = N / 200 + 45; if (!sc) return { t: no, p: N / 2, q: N / 2, r: 0 }; if (N <= 4500) return { t: N / 50, p: 0, q: 0, r: N }; if (N < 9000) return { t: 90, p: N - 4500, q: N - 4500, r: 9000 - N }; return { t: no, p: N / 2, q: N / 2, r: 0 }; };

export default [
  // ── 1. 확률의 역설 ──
  {
    id: "par-boy-girl", grade: P, unit: 1, lesson: "주제 1", title: "두 아이 문제 — '적어도 한 명이 딸'이면 1/2이 아니다", type: "조작", time: "10분",
    tags: ["조건부확률", "역설", "표본공간"], links: ["lab-monty-hall", "pst-bayes"],
    desc: "아이가 둘인 집에서 '첫째가 딸'이라는 정보와 '적어도 한 명이 딸'이라는 정보는 다릅니다. 가능한 경우를 칸으로 늘어놓고 조건에 맞는 칸만 남기면, 둘 다 딸일 확률이 1/2, 1/3로 갈리고, '화요일에 태어난 딸이 있다'는 엉뚱해 보이는 정보는 13/27을 만듭니다.",
    obs: ["조건이 바뀌면 남는 칸(표본공간)이 바뀝니다.", "‘적어도 한 명’은 딸·아들, 아들·딸, 딸·딸 세 칸을 남깁니다.", "정보가 구체적일수록(화요일) 답이 1/2에 가까워집니다."],
    q: "‘적어도 한 명이 1월생 딸’이라면 둘 다 딸일 확률은 1/2에 더 가까워질까요?",
    formula: "P(둘 다 딸 | 적어도 한 명 딸) = 1/3",
    en: { title: "The Boy or Girl Paradox", desc: "Conditioning changes the sample space." },
    view: { x: [-1.6, 11.6], y: [-1.6, 10.4] },
    params: [{ key: "c", label: "알려진 정보", type: "select", value: "any", options: [["older", "첫째가 딸이다"], ["any", "적어도 한 명이 딸이다"], ["tue", "화요일에 태어난 딸이 적어도 한 명 있다"]] }],
    cnt(s) { const N = s.c === "tue" ? 14 : 2, girl = (i) => i < N / 2, tue = (i) => (N === 2 ? true : i % 7 === 1); let k = 0, f = 0; for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) { const ok = s.c === "older" ? girl(i) : s.c === "any" ? girl(i) || girl(j) : (girl(i) && tue(i)) || (girl(j) && tue(j)); if (ok) { k++; if (girl(i) && girl(j)) f++; } } return [f, k, N]; },
    draw(s, g) {
      const [, , N] = this.cnt(s), L = 9.6, c = L / N, girl = (i) => i < N / 2, tue = (i) => (N === 2 ? true : i % 7 === 1);
      for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) { const ok = s.c === "older" ? girl(i) : s.c === "any" ? girl(i) || girl(j) : (girl(i) && tue(i)) || (girl(j) && tue(j)); const both = girl(i) && girl(j); rect(g, i * c, L - (j + 1) * c, c, c, { fill: ok ? (both ? "a" : "b") : "muted", fo: ok ? 0.6 : 0.08, color: "paper", w: N > 2 ? 0.6 : 2 }); if (N === 2) g.text([i * c + c / 2, L - (j + 0.5) * c], `${girl(i) ? "딸" : "아들"}·${girl(j) ? "딸" : "아들"}`, { dy: 5, size: 16, bold: true }); }
      g.text([L / 2, -0.6], "첫째 →  (왼쪽 절반: 딸, 오른쪽 절반: 아들)", { size: 12, color: "muted" }).text([-0.4, L / 2], "둘째", { size: 12, color: "muted", anchor: "end" });
      if (N > 2) g.text([L / 2, L + 0.4], "한 칸 = (성별, 요일) 쌍 — 7칸마다 같은 성별, 두 번째 줄이 화요일", { size: 11, color: "muted" });
    },
    metrics(s) { const [f, k] = this.cnt(s); return [["조건에 맞는 칸", `${k}칸`], ["그중 둘 다 딸 (주황)", `${f}칸`], ["P(둘 다 딸 | 정보)", `${f}/${k} = ${fmt(f / k, 4)}`, "key"]]; },
    predict: [
      { q: "‘적어도 한 명이 딸’일 때 둘 다 딸일 확률은?", options: O("1/2", "1/3", "1/4"), set: (s) => (s.c = "older"), reveal: (s) => (s.c = "any"), answer: () => "b", why: "남는 칸은 딸딸, 딸아들, 아들딸 세 칸이고 그중 하나라 1/3입니다." },
      { q: "‘화요일에 태어난 딸이 있다’면 둘 다 딸일 확률은? (분수로)", set: (s) => (s.c = "any"), reveal: (s) => (s.c = "tue"), answer: () => 13 / 27, tol: 1e-6, show: () => "13/27", why: "196칸 중 조건 27칸, 그중 둘 다 딸 13칸입니다." },
    ],
  },
  {
    id: "par-bertrand", grade: P, unit: 1, lesson: "주제 1", title: "베르트랑의 역설 — '무작위 현'의 답은 셋", type: "조작", time: "12분",
    tags: ["기하확률", "역설", "시뮬레이션"], links: ["lab-buffon", "pst-geometric-prob"],
    desc: "원에 무작위로 현을 그을 때, 그 현이 내접 정삼각형의 한 변보다 길 확률은 얼마일까요? 1889년 베르트랑은 '무작위'를 어떻게 정하느냐에 따라 답이 1/3, 1/2, 1/4로 달라짐을 보였습니다. 세 방법으로 현을 직접 그어 비율을 비교합니다.",
    obs: ["원 위의 두 점을 고르면 약 1/3입니다.", "반지름 위의 한 점을 골라 수직인 현을 그으면 약 1/2입니다.", "원 안의 한 점을 중점으로 고르면 약 1/4입니다. '무작위'의 뜻을 먼저 정해야 합니다."],
    q: "세 방법 중 어느 것이 '진짜' 무작위일까요? 근거를 말해 봅시다.",
    formula: "현이 √3보다 길 확률: 1/3 · 1/2 · 1/4",
    en: { title: "Bertrand's Paradox", desc: "Three answers to one question." },
    view: { x: [-1.5, 1.5], y: [-1.25, 1.25] },
    params: [{ key: "m", label: "현을 고르는 방법", type: "select", value: "a", options: [["a", "원 위의 두 점을 고른다"], ["b", "반지름 위의 점을 골라 수직 현"], ["c", "원 안의 점을 중점으로"]] }, { key: "n", label: "현의 개수", min: 10, max: 3000, step: 10, value: 400 }, { key: "seed", label: "씨앗값", min: 1, max: 97, step: 1, value: 1 }],
    ...SEED,
    draw(s, g) { const C = chords(s.m, s.n, s.seed); C.slice(0, 260).forEach(([A, B, L]) => g.seg(A, B, { color: L ? "a" : "b", w: 0.8, opacity: 0.55 })); g.circle([0, 0], 1, { color: "ink", w: 2.4 }); const T = [0, 1, 2].map((k) => [Math.cos(Math.PI / 2 + (2 * Math.PI * k) / 3), Math.sin(Math.PI / 2 + (2 * Math.PI * k) / 3)]); g.poly(T, { color: "e", w: 2, fill: "none" }); g.text([-1.45, 1.15], "주황: 삼각형 변보다 긴 현 · 파랑: 짧은 현", { anchor: "start", size: 12, bold: true }); },
    metrics(s) { const C = chords(s.m, s.n, s.seed), k = C.filter((c) => c[2]).length, th = { a: "1/3", b: "1/2", c: "1/4" }[s.m]; return [["긴 현의 비율", `${k}/${s.n} = ${fmt(k / s.n, 3)}`, "key"], ["이론값", th]]; },
    predict: [
      { q: "원 위의 두 점을 무작위로 고르면 긴 현의 비율은?", options: O("1/2", "1/3", "1/4"), set: (s) => Object.assign(s, { m: "a", n: 10 }), reveal: (s) => (s.n = 3000), answer: () => "b", why: "한 점을 고정하면 다른 점이 맞은편 120° 호에 있어야 하므로 1/3입니다." },
      { q: "원 안의 점을 중점으로 고르면 긴 현의 비율은? (분수나 소수로)", set: (s) => Object.assign(s, { m: "b", n: 10 }), reveal: (s) => Object.assign(s, { m: "c", n: 3000 }), answer: () => 0.25, tol: 1e-9, why: "중점이 반지름 1/2인 원 안에 있어야 하므로 넓이 비 1/4입니다." },
    ],
  },
  {
    id: "par-base-rate", grade: P, unit: 1, lesson: "주제 1", title: "99% 정확한 검사, 양성이면 정말 병일까? — 기저율의 역설", type: "조작", time: "10분",
    tags: ["조건부확률", "베이즈", "기저율"], links: ["pst-bayes", "par-boy-girl"],
    desc: "환자를 99% 맞히고 건강한 사람도 99% 맞히는 검사가 있습니다. 병에 걸린 사람이 100명 중 1명이라면, 양성이 나온 사람이 실제로 병일 확률은 겨우 50%입니다. 1000명을 칸으로 그려 진짜 양성과 거짓 양성을 직접 셉니다.",
    obs: ["드문 병일수록 거짓 양성이 진짜 양성보다 많아집니다.", "검사의 정확도만 보고 판단하면 기저율(원래 비율)을 놓칩니다.", "두 번 검사해서 모두 양성이면 확률이 크게 올라갑니다."],
    q: "유병률 1%, 정확도 99%인 검사에서 두 번 연속 양성이면 병일 확률은 얼마일까요?",
    formula: "P(병 | 양성) = P(병)P(양성|병) / P(양성)",
    en: { title: "The Base Rate Fallacy", desc: "A 99% test can be 50% right." },
    view: { x: [-0.5, 40.5], y: [-3.5, 25.5] },
    params: [{ key: "p", label: "유병률 (%)", min: 0.2, max: 20, step: 0.2, value: 1 }, { key: "se", label: "환자를 양성으로 맞힐 확률 (%)", min: 80, max: 99.9, step: 0.1, value: 99 }, { key: "sp", label: "건강한 사람을 음성으로 맞힐 확률 (%)", min: 80, max: 99.9, step: 0.1, value: 99 }],
    calc(s) { const N = 1000, sick = (N * s.p) / 100, tp = (sick * s.se) / 100, fp = ((N - sick) * (100 - s.sp)) / 100; return { sick, tp, fp, ppv: tp / (tp + fp) }; },
    draw(s, g) { const C = this.calc(s), tp = Math.round(C.tp), sick = Math.round(C.sick), fp = Math.round(C.fp); for (let i = 0; i < 1000; i++) { const x = i % 40, y = 24 - Math.floor(i / 40); let col = "muted", fo = 0.12; if (i < sick) { col = i < tp ? "a" : "d"; fo = 0.9; } else if (i < sick + fp) { col = "b"; fo = 0.75; } rect(g, x + 0.08, y + 0.08, 0.84, 0.84, { fill: col, fo, stroke: false }); } g.text([0, -1.4], `주황 ${tp}명: 병 + 양성 · 파랑 ${fp}명: 건강 + 양성(거짓 양성)`, { anchor: "start", size: 13, bold: true }); },
    metrics(s) { const C = this.calc(s); return [["1000명 중 환자", `${fmt(C.sick, 1)}명`], ["양성 판정", `${fmt(C.tp + C.fp, 1)}명`], ["양성일 때 실제 병일 확률", `${fmt(C.ppv * 100, 1)}%`, "key"]]; },
    predict: [
      { q: "유병률 1%, 두 정확도 99%일 때 양성이면 실제 병일 확률은 몇 %?", set: (s) => Object.assign(s, { p: 10, se: 99, sp: 99 }), reveal: (s) => (s.p = 1), answer: () => 50, tol: 0.5, why: "1000명 중 환자 10명 → 진짜 양성 9.9명, 건강한 990명 중 거짓 양성 9.9명이라 50%입니다." },
      { q: "유병률을 10%로 올리면 이 확률은 커질까요?", options: O("커진다", "작아진다", "그대로"), set: (s) => Object.assign(s, { p: 1, se: 99, sp: 99 }), reveal: (s) => (s.p = 10), answer: () => "a", why: "환자가 많아질수록 진짜 양성의 몫이 커져 약 92%가 됩니다." },
    ],
  },
  {
    id: "par-st-petersburg", grade: P, unit: 1, lesson: "주제 1", title: "상트페테르부르크 역설 — 기댓값이 무한대인 게임", type: "조작", time: "12분",
    tags: ["기댓값", "무한급수", "역설"], links: ["pst-expectation", "par-gambler"],
    desc: "동전을 던져 앞면이 나올 때까지 계속하고, k번째에 처음 앞면이면 2ᵏ원을 받습니다. 기댓값은 1 + 1 + 1 + ⋯로 끝없이 커지지만, 실제로 수천 번 해 봐도 평균 상금은 아주 천천히 늘어날 뿐입니다. 1738년 다니엘 베르누이가 제기한 이 문제를 직접 시뮬레이션합니다.",
    obs: ["각 항 (1/2ᵏ) × 2ᵏ = 1이 끝없이 더해져 기댓값이 무한대입니다.", "대부분의 게임은 2원, 4원에 끝나고 아주 드물게 큰 상금이 나옵니다.", "평균은 게임 수의 로그에 비례하는 정도로만 커집니다."],
    q: "이 게임에 참가비를 얼마까지 낼 수 있을까요? 기댓값과 내 판단이 다른 까닭은?",
    formula: "E = Σ (1/2)ᵏ · 2ᵏ = 1 + 1 + 1 + ⋯ = ∞",
    en: { title: "The St. Petersburg Paradox", desc: "An infinite expected value." },
    view: { x: [-0.4, 5.6], y: [-0.6, 4.4] },
    params: [{ key: "e", label: "게임 횟수 (10의 거듭제곱)", min: 1, max: 5, step: 0.1, value: 3, show: (v) => `${fmt(10 ** v, 0)}번` }, { key: "seed", label: "씨앗값", min: 1, max: 97, step: 1, value: 1 }],
    ...SEED,
    draw(s, g) { const R = stp(Math.round(10 ** s.e), s.seed), top = Math.max(8, ...R.avg.map((p) => p[1])) * 1.15, Y = (v) => (v / top) * 4; g.seg([0, 0], [5.4, 0], { color: "axis", w: 1.4 }).seg([0, 0], [0, 4], { color: "axis", w: 1.4 }); g.text([0, 4], fmt(top, 0) + "원", { anchor: "end", dx: -4, size: 10, color: "muted" }); for (let k = 0; k <= 5; k++) g.text([k, 0], `10${"⁰¹²³⁴⁵"[k]}`, { dy: 16, size: 11, color: "muted" }); g.path(R.avg.map(([i, a]) => [Math.log10(i), Y(a)]), { color: "a", w: 2.4 }); g.fx((x) => Y(Math.log2(10 ** x) + 1), { color: "b", w: 1.6, dash: "6 4", from: 0, to: 5.2 }); g.text([0.1, 4.25], "주황: 평균 상금 · 파랑 점선: log₂(게임 수) + 1", { anchor: "start", size: 12, bold: true }); },
    metrics(s) { const n = Math.round(10 ** s.e), R = stp(n, s.seed); return [["평균 상금", `${fmt(R.mean, 2)}원`, "key"], ["가장 큰 상금", `${fmt(R.mx, 0)}원`], ["기댓값", "∞"]]; },
    predict: [
      { q: "처음 던진 동전이 앞면일 확률 1/2 × 상금 2원 = ? (첫째 항)", set: (s) => (s.e = 1), answer: () => 1, why: "모든 항이 1이 되어 합이 끝없이 커집니다." },
      { q: "게임을 10만 번 하면 평균 상금은 대략 얼마 근처일까요?", options: O("약 10~30원", "약 1000원", "무한대"), set: (s) => (s.e = 2), reveal: (s) => (s.e = 5), answer: () => "a", why: "평균은 대략 log₂ n 정도로만 커져 10만 번이면 십몇 원 수준입니다." },
    ],
  },
  {
    id: "par-gambler", grade: P, unit: 1, lesson: "주제 1", title: "도박사의 오류 — 앞면이 다섯 번 나왔으니 이번엔 뒷면?", type: "데이터", time: "8분",
    tags: ["독립", "확률", "오개념"], links: ["pst-independence", "par-st-petersburg"],
    desc: "1913년 몬테카를로 카지노에서 룰렛이 검은색에 26번 연속 멈추자 사람들은 '이제 빨간색 차례'라며 돈을 걸었다가 크게 잃었습니다. 동전을 수만 번 던져 앞면이 k번 연속 나온 직후 다시 앞면이 나온 비율을 세면, k가 몇이든 1/2 근처입니다.",
    obs: ["동전은 앞의 결과를 기억하지 않습니다(독립 시행).", "연속 횟수 k가 클수록 그런 경우가 드물어 비율이 더 흔들립니다.", "‘평균으로 돌아간다’는 것은 앞으로 많이 던질수록 비율이 1/2에 가까워진다는 뜻이지, 반대 결과가 더 나온다는 뜻이 아닙니다."],
    q: "앞면이 10번 연속 나온 동전이 있다면, 오히려 의심해야 할 것은 무엇일까요?",
    formula: "P(앞 | 직전 k번 앞) = P(앞) = 1/2",
    en: { title: "The Gambler's Fallacy", desc: "Coins have no memory." },
    view: { x: [-0.3, 7.2], y: [-0.9, 5.3] },
    params: [{ key: "e", label: "던진 횟수 (10의 거듭제곱)", min: 2, max: 5, step: 0.1, value: 4, show: (v) => `${fmt(10 ** v, 0)}번` }, { key: "seed", label: "씨앗값", min: 1, max: 97, step: 1, value: 1 }],
    ...SEED,
    draw(s, g) { const R = gamb(Math.round(10 ** s.e), s.seed); g.seg([0.2, 0], [7, 0], { color: "axis", w: 1.4 }); g.seg([0.2, 2.5], [7, 2.5], { color: "e", w: 1.6, dash: "6 4" }).text([7, 2.5], "1/2", { anchor: "end", dy: -6, bold: true, color: "e" }); R.forEach(([k, c, p]) => { rect(g, k - 0.35, 0, 0.7, p * 5, { fill: "b", fo: 0.6, stroke: false }); g.text([k, p * 5], fmt(p, 3), { dy: -6, size: 11, mono: true }).text([k, 0], `${k}번 연속 뒤`, { dy: 16, size: 11, color: "muted" }).text([k, 0], `${c}회`, { dy: 30, size: 10, color: "muted" }); }); },
    metrics(s) { const R = gamb(Math.round(10 ** s.e), s.seed); return [["1번 연속 앞면 뒤 앞면 비율", fmt(R[0][2], 3)], ["5번 연속 앞면 뒤 앞면 비율", fmt(R[4][2], 3), "key"], ["5번 연속 앞면이 나온 횟수", `${R[4][1]}회`]]; },
    predict: [
      { q: "앞면이 5번 연속 나온 직후 앞면이 나올 확률은?", options: O("1/2보다 작다", "1/2", "1/2보다 크다"), set: (s) => (s.e = 2), reveal: (s) => (s.e = 5), answer: () => "b", why: "독립 시행이므로 직전 결과와 관계없이 1/2입니다." },
      { q: "공정한 동전에서 앞면이 5번 연속 나올 확률은? (분수나 소수로)", answer: () => 1 / 32, tol: 1e-9, why: "(1/2)⁵ = 1/32입니다." },
    ],
  },
  // ── 2. 무한의 역설 ──
  {
    id: "par-hilbert", grade: P, unit: 2, lesson: "주제 2", title: "힐베르트의 호텔 — 꽉 찬 방에 손님을 더 받는 법", type: "조작", time: "10분",
    tags: ["무한집합", "일대일대응", "역설"], links: ["par-grandi", "cm2-subsets"],
    desc: "방이 무한히 많은 호텔이 손님으로 꽉 찼습니다. 그래도 n호 손님을 n + 1호로 옮기면 1호가 비고, 2n호로 옮기면 홀수 방이 모두 비어 무한히 많은 새 손님을 받을 수 있습니다. 1924년 힐베르트가 무한의 성질을 설명한 이야기를 손님이 옮겨 가는 장면으로 봅니다.",
    obs: ["유한한 호텔에서는 불가능한 일이 무한에서는 가능합니다.", "자연수 전체와 짝수 전체는 일대일로 짝지을 수 있어 ‘개수’가 같습니다.", "무한집합은 자기 자신의 일부와 일대일대응이 될 수 있습니다."],
    q: "무한히 많은 버스에 무한히 많은 손님이 타고 왔다면 어떻게 방을 내줄 수 있을까요?",
    formula: "n → n + 1, n → 2n (자연수와 짝수의 일대일대응)",
    en: { title: "Hilbert's Hotel", desc: "A full hotel can always take more guests." },
    view: { x: [-0.4, 12.8], y: [-1.6, 4.4] },
    params: [{ key: "m", label: "새 손님", type: "seg", value: "one", options: [["one", "1명"], ["k", "3명"], ["inf", "무한히 많이"]] }, { key: "t", label: "옮기기", min: 0, max: 1, step: 0.01, value: 0 }],
    anim: { key: "t", min: 0, max: 1, speed: 0.4, label: "방 옮기기" },
    to(s, n) { return s.m === "one" ? n + 1 : s.m === "k" ? n + 3 : 2 * n; },
    draw(s, g) {
      for (let r = 1; r <= 12; r++) { rect(g, r - 0.95, 0, 0.9, 1.2, { fill: "paper", color: "ink", w: 1.4 }); g.text([r - 0.5, 0], `${r}`, { dy: 16, size: 12, mono: true, color: "muted" }); }
      for (let n = 1; n <= 12; n++) { const m = this.to(s, n), x0 = n - 0.5, x1 = m - 0.5; if (m > 12 && s.t > 0.8) continue; const x = x0 + (x1 - x0) * s.t, y = 0.6 + Math.sin(Math.PI * s.t) * (0.8 + 0.15 * (m - n)); g.circle([x, y], 0.26, { fill: "b", fo: 0.9, color: "paper", w: 1 }); }
      if (s.t > 0.99) for (let r = 1; r <= 12; r++) { const used = [...Array(12)].some((_, i) => this.to(s, i + 1) === r); if (!used) g.circle([r - 0.5, 0.6], 0.26, { fill: "a", fo: 0.95, color: "paper", w: 1 }); }
      g.text([0, 3.9], s.m === "one" ? "n호 → n + 1호: 1호가 빕니다" : s.m === "k" ? "n호 → n + 3호: 1, 2, 3호가 빕니다" : "n호 → 2n호: 홀수 방이 모두 빕니다", { anchor: "start", bold: true, size: 14 });
    },
    metrics(s) { return [["옮기는 규칙", s.m === "one" ? "n → n + 1" : s.m === "k" ? "n → n + 3" : "n → 2n", "key"], ["새로 비는 방", s.m === "one" ? "1호" : s.m === "k" ? "1~3호" : "1, 3, 5, 7, …호"], ["쫓겨나는 손님", "없음"]]; },
    predict: [
      { q: "n호 손님을 2n호로 옮기면 7호 손님은 몇 호로 갈까요?", set: (s) => Object.assign(s, { m: "inf", t: 0 }), reveal: (s) => (s.t = 1), answer: () => 14, why: "2 × 7 = 14호입니다." },
      { q: "이렇게 옮긴 뒤 빈 방은 어떤 방일까요?", options: O("홀수 방 전부", "짝수 방 전부", "1호뿐"), answer: () => "a", why: "모든 손님이 짝수 방으로 가서 홀수 방이 모두 빕니다." },
    ],
  },
  {
    id: "par-gabriel", grade: P, unit: 2, lesson: "주제 2", title: "가브리엘의 나팔 — 페인트로 채울 수는 있지만 칠할 수는 없다", type: "조작", time: "12분",
    tags: ["이상적분", "회전체", "역설"], links: ["calc2-disk-volume", "calc2-series"],
    desc: "y = 1/x (x ≥ 1)을 x축 둘레로 돌린 나팔은 부피가 π로 유한하지만 겉넓이는 끝없이 커집니다. 끝 b를 늘리며 부피 π(1 − 1/b)는 π에 다가가고 겉넓이는 2π ln b보다도 커지는 것을 비교합니다. 1640년대 토리첼리가 발견해 당시 수학자들을 놀라게 한 결과입니다.",
    obs: ["부피 ∫π(1/x)²dx는 1/x²의 적분이라 수렴합니다.", "겉넓이는 2π∫(1/x)√(1 + 1/x⁴)dx ≥ 2π∫(1/x)dx라 발산합니다.", "‘페인트를 부어 채울 수는 있지만 안쪽 벽을 칠할 수는 없다’는 말이 생겼습니다."],
    q: "실제 페인트로 이 나팔을 채울 수 없는 까닭은 무엇일까요? (분자의 크기를 생각해 봅시다)",
    formula: "V=\\pi\\int_1^\\infty x^{-2}\\,dx=\\pi\\quad S\\ge2\\pi\\int_1^\\infty x^{-1}\\,dx=\\infty",
    en: { title: "Gabriel's Horn", desc: "Finite volume, infinite surface." },
    view: { x: [0, 11], y: [-1.6, 1.6] },
    params: [{ key: "e", label: "나팔의 길이 b (10의 거듭제곱)", min: 0.1, max: 4, step: 0.05, value: 1, show: (v) => `b = ${fmt(10 ** v, 1)}` }],
    anim: { key: "e", min: 0.1, max: 4, speed: 0.6, label: "나팔 늘이기" },
    draw(s, g) { const b = 10 ** s.e, X = (x) => 0.5 + (10 * Math.log10(x)) / Math.max(1, s.e), f = (x) => 1 / x; const pts = []; for (let i = 0; i <= 200; i++) { const x = 10 ** ((s.e * i) / 200); pts.push([X(x), f(x)]); } g.poly(pts.concat(pts.slice().reverse().map(([a, y]) => [a, -y])), { fill: "b", fo: 0.25, color: "b", w: 2 }); [1, 2, 5, 10, 100, 1000].filter((x) => x <= b).forEach((x) => { g.circle([X(x), 0], f(x), { color: "b", w: 1, dash: "3 3" }); g.text([X(x), -1.1], fmt(x, 0), { size: 11, color: "muted" }); }); g.text([0.5, 1.45], "가로: x (로그 눈금) · 세로: 반지름 1/x", { anchor: "start", size: 12, bold: true }); },
    metrics(s) { const b = 10 ** s.e, S = 2 * Math.PI * (() => { let h = Math.log(b) / 800, t = 0; for (let i = 0; i < 800; i++) { const u = (i + 0.5) * h, x = Math.exp(u); t += (1 / x) * Math.sqrt(1 + 1 / x ** 4) * x * h; } return t; })(); return [["부피 π(1 − 1/b)", fmt(Math.PI * (1 - 1 / b), 4), "key"], ["겉넓이", fmt(S, 3)], ["부피의 극한", "π ≈ 3.1416"]]; },
    predict: [
      { q: "나팔을 끝없이 늘리면 부피는 어디에 다가갈까요? (소수 둘째 자리까지)", set: (s) => (s.e = 0.3), reveal: (s) => (s.e = 4), answer: () => Math.PI, tol: 0.01, why: "π∫₁^∞ 1/x² dx = π입니다." },
      { q: "나팔을 끝없이 늘리면 겉넓이는?", options: O("유한한 값에 다가간다", "끝없이 커진다"), answer: () => "b", why: "2π ln b보다 커서 발산합니다." },
    ],
  },
  {
    id: "par-harmonic-stack", grade: P, unit: 2, lesson: "주제 2", title: "블록 쌓기 — 탁자 밖으로 얼마나 멀리 내밀 수 있을까", type: "조작", time: "10분",
    tags: ["조화급수", "무게중심", "발산"], links: ["calc2-series", "par-grandi"],
    desc: "길이 1인 블록을 맨 위부터 1/2, 1/4, 1/6, …씩 엇갈려 쌓으면 무너지지 않습니다. 내민 길이는 (1/2)(1 + 1/2 + 1/3 + ⋯)인 조화급수의 절반이라, 블록만 충분하면 탁자 끝에서 얼마든지 멀리 나갈 수 있습니다. 4개만 쌓아도 맨 위 블록이 탁자를 완전히 벗어납니다.",
    obs: ["위에서 k번째 블록은 그 아래 블록보다 1/(2k)만큼 더 나옵니다.", "위쪽 블록들의 무게중심이 아래 블록의 끝에 오도록 쌓은 것입니다.", "조화급수는 아주 느리게 발산합니다. 2칸을 내밀려면 블록 31개가 필요합니다."],
    q: "블록 3칸만큼 내밀려면 블록이 몇 개 필요할까요?",
    formula: "내민 길이 = Σₖ₌₁ⁿ 1/(2k) = Hₙ/2",
    en: { title: "The Block-Stacking Problem", desc: "The harmonic series overhangs forever." },
    view: (s) => ({ x: [-1.6, 3.4], y: [-0.4, Math.max(2.6, s.n * 0.2 + 0.6)] }),
    params: [{ key: "n", label: "블록의 수", min: 1, max: 40, step: 1, value: 4 }],
    anim: { key: "n", min: 1, max: 40, speed: 4, label: "쌓기" },
    draw(s, g) { const h = 0.2; rect(g, -1.6, -0.4, 1.6, 0.4, { fill: "muted", fo: 0.35, color: "ink", w: 1.4 }); let off = 0; const xs = []; for (let k = s.n; k >= 1; k--) { xs.push(off); off += 1 / (2 * k); } xs.reverse(); for (let k = 1; k <= s.n; k++) { const right = xs[k - 1] + 1 / (2 * k) + (k === 1 ? 0 : 0), base = (s.n - k) * h; let R = 0; for (let j = k; j <= s.n; j++) R += 1 / (2 * j); rect(g, R - 1, base, 1, h, { fill: k % 2 ? "b" : "c", fo: 0.65, color: "paper", w: 1 }); } let T = 0; for (let j = 1; j <= s.n; j++) T += 1 / (2 * j); g.seg([0, -0.4], [0, s.n * h + 0.4], { color: "e", w: 1.4, dash: "4 4" }).seg([0, s.n * h + 0.25], [T, s.n * h + 0.25], { color: "a", w: 2.4 }).text([T / 2, s.n * h + 0.25], `내민 길이 ${fmt(T, 3)}`, { dy: -8, bold: true, color: "a" }); },
    metrics(s) { let T = 0; for (let j = 1; j <= s.n; j++) T += 1 / (2 * j); return [["내민 길이", fmt(T, 4), "key"], ["블록 길이", "1"], ["맨 위 블록이 탁자를 완전히 벗어남", T > 1 ? "예" : "아니요"]]; },
    predict: [
      { q: "블록 4개를 쌓으면 내민 길이는 1보다 길까요?", options: O("예", "아니요"), set: (s) => (s.n = 2), reveal: (s) => (s.n = 4), answer: () => "a", why: "(1 + 1/2 + 1/3 + 1/4)/2 = 25/24 > 1입니다." },
      { q: "블록 3개의 내민 길이는? (분수나 소수로)", set: (s) => (s.n = 1), reveal: (s) => (s.n = 3), answer: () => 11 / 12, tol: 1e-6, show: () => "11/12", why: "1/2 + 1/4 + 1/6 = 11/12입니다." },
    ],
  },
  {
    id: "par-riemann", grade: P, unit: 2, lesson: "주제 2", title: "리만의 재배열 — 순서만 바꿨는데 합이 달라진다", type: "조작", time: "12분",
    tags: ["급수", "조건수렴", "역설"], links: ["calc2-series", "par-grandi"],
    desc: "1 − 1/2 + 1/3 − 1/4 + ⋯의 합은 ln 2 ≈ 0.693입니다. 그런데 같은 항들을 순서만 바꿔 더하면 원하는 어떤 값에도 가게 만들 수 있습니다. 목표보다 작으면 양수 항을, 크면 음수 항을 더하는 방법으로 부분합이 목표에 다가가는 것을 봅니다.",
    obs: ["양수 항만 더해도, 음수 항만 더해도 각각 무한대로 발산합니다(조건수렴).", "이런 급수는 순서를 바꾸면 합이 바뀔 수 있습니다.", "모든 항의 절댓값의 합이 수렴하면(절대수렴) 순서를 바꿔도 합이 같습니다."],
    q: "1 + 1/4 + 1/9 + ⋯처럼 양수 항뿐인 급수도 재배열하면 합이 바뀔까요?",
    formula: "1 − 1/2 + 1/3 − ⋯ = ln 2, 재배열하면 임의의 값 T",
    en: { title: "Riemann's Rearrangement Theorem", desc: "Reorder the terms, change the sum." },
    view: { x: [-0.3, 10.3], y: [-2.6, 3.6] },
    params: [{ key: "T", label: "목표값 T", min: -2, max: 3, step: 0.05, value: 1.5 }, { key: "N", label: "더한 항의 수", min: 10, max: 400, step: 10, value: 200 }],
    anim: { key: "N", min: 10, max: 400, speed: 60, label: "항 더하기" },
    draw(s, g) { g.seg([0, 0], [10, 0], { color: "axis", w: 1.2 }); const P0 = rearr(s.T, s.N).map(([i, v]) => [i / 40, v]); g.seg([0, s.T], [10, s.T], { color: "a", w: 1.6, dash: "6 4" }).text([10, s.T], `목표 ${fmt(s.T, 2)}`, { anchor: "end", dy: -6, bold: true, color: "a" }); g.seg([0, Math.LN2], [10, Math.LN2], { color: "muted", w: 1, dash: "3 4" }).text([10, Math.LN2], "원래 순서의 합 ln 2", { anchor: "end", dy: 14, size: 11, color: "muted" }); g.path(P0, { color: "b", w: 2 }); },
    metrics(s) { const P0 = rearr(s.T, s.N); return [["부분합", fmt(P0.at(-1)[1], 5), "key"], ["목표와의 차", fmt(Math.abs(P0.at(-1)[1] - s.T), 5)]]; },
    predict: [
      { q: "원래 순서 1 − 1/2 + 1/3 − ⋯의 합은? (소수 셋째 자리까지)", answer: () => Math.LN2, tol: 0.001, why: "ln 2 ≈ 0.693입니다." },
      { q: "목표를 −1로 정해도 재배열로 갈 수 있을까요?", options: O("예", "아니요"), set: (s) => Object.assign(s, { T: 1.5, N: 100 }), reveal: (s) => Object.assign(s, { T: -1, N: 400 }), answer: () => "a", why: "음수 항 쪽의 합도 무한대로 발산하므로 어떤 값이든 가능합니다." },
    ],
  },
  {
    id: "par-grandi", grade: P, unit: 2, lesson: "주제 2", title: "그란디 급수 1 − 1 + 1 − 1 + ⋯ — 0인가 1인가 1/2인가", type: "조작", time: "8분",
    tags: ["급수", "발산", "평균"], links: ["par-riemann", "calc2-seq-limit"],
    desc: "1703년 그란디는 (1 − 1) + (1 − 1) + ⋯ = 0이고 1 + (−1 + 1) + ⋯ = 1이라며 고민했습니다. 부분합은 1, 0, 1, 0, …으로 수렴하지 않지만, 부분합들의 평균은 1/2에 다가갑니다. 괄호를 묶는 방식이 왜 답을 바꾸는지 부분합 그래프로 확인합니다.",
    obs: ["부분합이 1과 0을 오가므로 이 급수는 발산합니다.", "발산하는 급수에서는 괄호를 마음대로 묶을 수 없습니다.", "부분합의 평균(체사로 합)은 1/2입니다."],
    q: "1 − 2 + 3 − 4 + ⋯의 부분합의 평균은 어떻게 될까요?",
    formula: "Sₙ = 1, 0, 1, 0, …, (S₁ + ⋯ + Sₙ)/n → 1/2",
    en: { title: "Grandi's Series", desc: "1 − 1 + 1 − … : 0, 1 or 1/2?" },
    view: { x: [-0.3, 10.5], y: [-0.8, 6.2] },
    params: [{ key: "n", label: "항의 수", min: 1, max: 40, step: 1, value: 12 }],
    anim: { key: "n", min: 1, max: 40, speed: 5, label: "항 더하기" },
    draw(s, g) { const X = (k) => k / 4, Y = (v) => v * 4; g.seg([0, 0], [10.4, 0], { color: "axis", w: 1.2 }); g.seg([0, Y(0.5)], [10.4, Y(0.5)], { color: "e", w: 1.4, dash: "6 4" }).text([10.4, Y(0.5)], "1/2", { anchor: "end", dy: -6, bold: true, color: "e" }); let S = 0, A = 0; const av = []; for (let k = 1; k <= s.n; k++) { S += k % 2 ? 1 : -1; A += S; av.push([X(k), Y(A / k)]); g.point([X(k), Y(S)], "", { color: "b", r: 4 }); } g.path(av, { color: "a", w: 2.4 }); g.text([0, 5.8], "파랑: 부분합 · 주황: 부분합의 평균", { anchor: "start", bold: true, size: 13 }); },
    metrics(s) { let S = 0, A = 0; for (let k = 1; k <= s.n; k++) { S += k % 2 ? 1 : -1; A += S; } return [["부분합 Sₙ", `${S}`], ["부분합의 평균", fmt(A / s.n, 4), "key"]]; },
    predict: [
      { q: "항을 12개 더한 부분합은?", set: (s) => (s.n = 3), reveal: (s) => (s.n = 12), answer: () => 0, why: "짝수 개를 더하면 0입니다." },
      { q: "부분합의 평균은 어디에 다가갈까요? (분수나 소수로)", set: (s) => (s.n = 3), reveal: (s) => (s.n = 40), answer: () => 0.5, tol: 1e-9, why: "1과 0을 번갈아 평균하므로 1/2입니다." },
    ],
  },
  // ── 3. 기하와 측정의 역설 ──
  {
    id: "par-missing-square", grade: P, unit: 3, lesson: "주제 3", title: "사라진 한 칸 — 똑같은 조각인데 구멍이 생긴다", type: "조작", time: "10분",
    tags: ["기울기", "넓이", "착시"], links: ["par-64-65", "c2-line-eq"],
    desc: "같은 네 조각을 다시 배치했을 뿐인데 한 칸이 비어 버립니다(커리의 역설). 사실 두 그림의 '빗변'은 직선이 아닙니다. 빨간 삼각형의 기울기 3/8과 파란 삼각형의 기울기 2/5가 달라 빗변이 살짝 꺾여 있고, 그 차이를 모으면 정확히 한 칸입니다.",
    obs: ["두 삼각형의 기울기 3/8 = 0.375와 2/5 = 0.4는 다릅니다.", "그래서 ‘큰 삼각형’은 사실 삼각형이 아니라 사각형입니다.", "한쪽은 안쪽으로, 다른 쪽은 바깥쪽으로 반 칸씩 꺾여 합하면 한 칸 차이가 납니다."],
    q: "조각들의 넓이를 모두 더해 13 × 5 ÷ 2 = 32.5와 비교해 봅시다.",
    formula: "3/8 ≠ 2/5, 조각 넓이의 합 32 ≠ 32.5",
    en: { title: "The Missing Square Puzzle", desc: "Same pieces, one square gone." },
    view: { x: [-0.6, 13.6], y: [-0.8, 6.2] },
    params: [{ key: "m", label: "배치", type: "seg", value: "A", options: [["A", "배치 1"], ["B", "배치 2"]] }, { key: "line", label: "진짜 직선 빗변 보기", type: "check", value: false }],
    draw(s, g) {
      for (let x = 0; x <= 13; x++) g.seg([x, 0], [x, 5], { color: "grid", w: 0.8 }); for (let y = 0; y <= 5; y++) g.seg([0, y], [13, y], { color: "grid", w: 0.8 });
      const cells = (L, col) => L.forEach(([x, y]) => rect(g, x, y, 1, 1, { fill: col, fo: 0.75, color: "paper", w: 1 }));
      const row = (y, a, b) => Array.from({ length: b - a + 1 }, (_, i) => [a + i, y]);
      if (s.m === "A") { g.poly([[0, 0], [8, 0], [8, 3]], { fill: "a", fo: 0.75, color: "paper", w: 1.4 }); g.poly([[8, 3], [13, 3], [13, 5]], { fill: "b", fo: 0.75, color: "paper", w: 1.4 }); cells([...row(0, 8, 12), ...row(1, 10, 12)], "c"); cells([...row(1, 8, 9), ...row(2, 8, 12)], "d"); }
      else { g.poly([[0, 0], [5, 0], [5, 2]], { fill: "b", fo: 0.75, color: "paper", w: 1.4 }); g.poly([[5, 2], [13, 2], [13, 5]], { fill: "a", fo: 0.75, color: "paper", w: 1.4 }); cells([...row(0, 8, 12), ...row(1, 10, 12)], "c"); cells([...row(0, 5, 6), ...row(1, 5, 9)], "d"); g.poly([[7, 0], [8, 0], [8, 1], [7, 1]], { fill: "none", color: "e", w: 2.6 }); g.text([7.5, 0.5], "?", { dy: 6, bold: true, size: 18, color: "e" }); }
      if (s.line) g.seg([0, 0], [13, 5], { color: "ink", w: 1.6, dash: "5 4" });
      g.text([0, 5.8], s.m === "A" ? "빨강 기울기 3/8 → 파랑 기울기 2/5 (빗변이 안쪽으로 꺾임)" : "파랑 기울기 2/5 → 빨강 기울기 3/8 (빗변이 바깥쪽으로 꺾임)", { anchor: "start", bold: true, size: 13 });
    },
    metrics(s) { return [["빨간 삼각형 기울기", "3/8 = 0.375"], ["파란 삼각형 기울기", "2/5 = 0.4", "key"], ["조각 넓이의 합", "12 + 5 + 8 + 7 = 32"], ["13 × 5 ÷ 2", "32.5"]]; },
    predict: [
      { q: "빨간 삼각형(밑변 8, 높이 3)과 파란 삼각형(밑변 5, 높이 2)의 기울기는 같을까요?", options: O("같다", "다르다"), set: (s) => Object.assign(s, { m: "A", line: false }), reveal: (s) => (s.line = true), answer: () => "b", why: "3/8 = 0.375, 2/5 = 0.4로 달라 빗변이 꺾입니다." },
      { q: "네 조각의 넓이를 모두 더하면?", answer: () => 32, why: "12 + 5 + 8 + 7 = 32로, 진짜 삼각형 넓이 32.5보다 작습니다." },
    ],
  },
  {
    id: "par-64-65", grade: P, unit: 3, lesson: "주제 3", title: "64 = 65? — 피보나치 수가 만든 착시", type: "조작", time: "10분",
    tags: ["피보나치 수열", "넓이", "착시"], links: ["par-missing-square", "lab-golden-spiral"],
    desc: "8 × 8 정사각형을 네 조각으로 잘라 5 × 13 직사각형으로 다시 붙이면 넓이가 64에서 65로 늘어난 것처럼 보입니다. 직사각형의 대각선 자리에 아주 얇은 평행사변형 틈이 숨어 있고, 그 넓이가 정확히 1입니다. 연속한 피보나치 수 a, b, c에서 b² − ac = ±1이기 때문입니다.",
    obs: ["조각의 빗변 기울기 3/8과 2/5가 달라 대각선이 한 직선이 아닙니다.", "틈(평행사변형)의 넓이는 |5 × 3 − 8 × 2| = 1입니다.", "피보나치 수 3, 5, 8 대신 5, 8, 13을 쓰면 반대로 한 칸이 겹칩니다."],
    q: "2, 3, 5로 만들면 정사각형 25와 직사각형 24 중 어느 쪽이 클까요?",
    formula: "Fₙ₋₁Fₙ₊₁ − Fₙ² = (−1)ⁿ",
    en: { title: "The 64 = 65 Paradox", desc: "Fibonacci numbers fool the eye." },
    view: (s) => { const [a, b, c] = FIBS[s.f]; return { x: [-0.6, c + b + c + 2], y: [-1.4, c + 1] }; },
    params: [{ key: "f", label: "피보나치 수", type: "seg", value: "b", options: [["a", "2, 3, 5"], ["b", "3, 5, 8"], ["c", "5, 8, 13"]] }, { key: "gap", label: "틈 강조", type: "check", value: true }],
    draw(s, g) {
      const [a, b, c] = FIBS[s.f], col = ["a", "b", "c", "d"], o = (k) => ({ fill: col[k], fo: 0.7, color: "paper", w: 1.4 });
      g.poly([[0, 0], [c, 0], [c, a]], o(0)); g.poly([[0, 0], [0, a], [c, a]], o(1)); g.poly([[0, a], [b, a], [a, c], [0, c]], o(2)); g.poly([[b, a], [c, a], [c, c], [a, c]], o(3));
      g.text([c / 2, 0], `${c} × ${c} = ${c * c}`, { dy: 18, bold: true });
      const X = c + 1.5, W = c + b;
      g.poly([[X, 0], [X + c, 0], [X + c, a]], o(0));
      g.poly([[X + c, 0], [X + W, 0], [X + W, b], [X + c, a]], o(3)); g.poly([[X + b, b - a], [X + W, b], [X + b, b]], o(1)); g.poly([[X, 0], [X + b, b - a], [X + b, b], [X, b]], o(2));
      if (s.gap) g.poly([[X, 0], [X + b, b - a], [X + W, b], [X + c, a]], { fill: "e", fo: 0.85, color: "e", w: 1.4 });
      g.text([X + W / 2, 0], `${W} × ${b} = ${W * b}`, { dy: 18, bold: true });
    },
    metrics(s) { const [a, b, c] = FIBS[s.f]; return [["정사각형", `${c * c}`], ["직사각형", `${b * (b + c)}`], ["틈(겹침)의 넓이", `${Math.abs(b * b - a * c) === 1 ? 1 : Math.abs(b * b - a * c)}`, "key"], [`${b}² − ${a}×${c}`, `${b * b - a * c}`]]; },
    predict: [
      { q: "3, 5, 8로 만든 직사각형(13 × 5)의 넓이는?", set: (s) => Object.assign(s, { f: "b", gap: false }), reveal: (s) => (s.gap = true), answer: () => 65, why: "13 × 5 = 65이고, 틈 넓이 1이 숨어 있습니다." },
      { q: "2, 3, 5로 만들면 직사각형(8 × 3)의 넓이는?", set: (s) => Object.assign(s, { f: "b", gap: false }), reveal: (s) => Object.assign(s, { f: "a", gap: true }), answer: () => 24, why: "8 × 3 = 24로 정사각형 25보다 1 작아 조각이 겹칩니다." },
    ],
  },
  {
    id: "par-staircase", grade: P, unit: 3, lesson: "주제 3", title: "계단의 역설 — √2 = 2?", type: "조작", time: "8분",
    tags: ["극한", "길이", "역설"], links: ["calc2-arc-length", "par-coastline"],
    desc: "한 변이 1인 정사각형의 대각선을 계단으로 따라가면 계단을 아무리 잘게 해도 길이는 늘 1 + 1 = 2입니다. 계단 모양은 대각선에 한없이 가까워지는데 길이는 √2 ≈ 1.414로 가지 않습니다. 모양이 가까워져도 길이가 가까워진다는 보장은 없다는 것을 확인합니다.",
    obs: ["계단의 가로 조각을 모두 더하면 1, 세로 조각을 모두 더하면 1입니다.", "계단과 대각선 사이의 거리는 0에 다가갑니다.", "길이는 ‘방향’까지 맞아야 수렴합니다(곡선의 길이 공식의 √(1 + f′²))."],
    q: "원을 둘러싼 정사각형의 귀퉁이를 계속 접어 넣으면 둘레가 4로 남는데, 이것으로 π = 4라고 할 수 있을까요?",
    formula: "계단 길이 = 2, 대각선 길이 = √2",
    en: { title: "The Staircase Paradox", desc: "Is √2 equal to 2?" },
    view: { x: [-0.25, 1.35], y: [-0.25, 1.2] },
    params: [{ key: "n", label: "계단의 수", min: 1, max: 64, step: 1, value: 4 }],
    anim: { key: "n", min: 1, max: 64, speed: 6, label: "잘게 하기" },
    draw(s, g) { const pts = [[0, 1]]; for (let k = 0; k < s.n; k++) { const x = (k + 1) / s.n, y = 1 - k / s.n; pts.push([x, y], [x, y - 1 / s.n]); } g.poly([[0, 0], [1, 0], [1, 1], [0, 1]], { fill: "none", color: "muted", w: 1 }); g.seg([0, 1], [1, 0], { color: "b", w: 3 }); g.path(pts, { color: "a", w: 2.4 }); g.text([0, 1.1], `주황 계단 길이 2 · 파랑 대각선 √2 ≈ 1.414`, { anchor: "start", bold: true, size: 13 }); },
    metrics(s) { return [["계단 길이", "2", "key"], ["대각선 길이", fmt(Math.SQRT2, 4)], ["계단과 대각선의 최대 거리", fmt(1 / s.n / Math.SQRT2, 4)]]; },
    predict: [
      { q: "계단을 64개로 잘게 하면 계단 길이는?", set: (s) => (s.n = 2), reveal: (s) => (s.n = 64), answer: () => 2, why: "가로 조각의 합 1, 세로 조각의 합 1로 늘 2입니다." },
      { q: "계단과 대각선 사이의 거리는 0에 다가갈까요?", options: O("예", "아니요"), answer: () => "a", why: "모양은 가까워지지만 길이는 그렇지 않은 것이 역설의 핵심입니다." },
    ],
  },
  {
    id: "par-coastline", grade: P, unit: 3, lesson: "주제 3", title: "해안선의 역설 — 자를 줄일수록 해안선이 길어진다", type: "조작", time: "10분",
    tags: ["프랙털", "측정", "역설"], links: ["lab-koch", "par-staircase"],
    desc: "1967년 망델브로는 '영국 해안선의 길이는 얼마인가'라고 물었습니다. 짧은 자로 잴수록 작은 굴곡까지 따라가 길이가 계속 늘어납니다. 코흐 곡선 모양의 해안을 길이 9, 3, 1, 1/3, …인 자로 재면 잴 때마다 길이가 4/3배씩 커집니다.",
    obs: ["자의 길이를 1/3로 줄이면 잰 길이가 4/3배가 됩니다.", "프랙털 곡선은 ‘길이’라는 하나의 값으로 나타낼 수 없습니다.", "대신 프랙털 차원 log 4 / log 3 ≈ 1.26으로 거칠기를 나타냅니다."],
    q: "실제 해안선의 길이를 지도마다 다르게 적는 까닭은 무엇일까요?",
    formula: "L = 9 × (4/3)ᵏ (자의 길이 9 × 3⁻ᵏ)",
    en: { title: "The Coastline Paradox", desc: "Shorter rulers, longer coasts." },
    view: { x: [-0.5, 9.5], y: [-0.6, 3.4] },
    params: [{ key: "k", label: "자를 줄인 횟수 (자 길이 = 9 ÷ 3ᵏ)", min: 0, max: 5, step: 1, value: 2 }],
    anim: { key: "k", min: 0, max: 5, speed: 1, label: "자 줄이기" },
    draw(s, g) { const C = koch(5); g.poly([...C, [9, -0.5], [0, -0.5]], { fill: "c", fo: 0.25, stroke: false }); g.path(C, { color: "c", w: 1.4 }); const M = koch(s.k); g.path(M, { color: "a", w: 2.2 }); if (s.k <= 3) M.forEach((p) => g.point(p, "", { color: "a", r: 3 })); g.text([0, 3.2], `자 길이 ${fmt(9 / 3 ** s.k, 3)} 로 잰 해안선`, { anchor: "start", bold: true }); },
    metrics(s) { return [["자의 길이", fmt(9 / 3 ** s.k, 4)], ["잰 길이", fmt(9 * (4 / 3) ** s.k, 3), "key"], ["프랙털 차원", fmt(Math.log(4) / Math.log(3), 3)]]; },
    predict: [
      { q: "자 길이 3으로 잰 길이 12에서, 자를 1로 줄이면 잰 길이는?", set: (s) => (s.k = 1), reveal: (s) => (s.k = 2), answer: () => 16, why: "12 × 4/3 = 16입니다." },
      { q: "자를 한없이 줄이면 잰 길이는?", options: O("일정한 값에 다가간다", "끝없이 커진다"), answer: () => "b", why: "(4/3)ᵏ → ∞입니다." },
    ],
  },
  {
    id: "par-aristotle-wheel", grade: P, unit: 3, lesson: "주제 3", title: "아리스토텔레스의 바퀴 — 큰 원과 작은 원이 같은 거리를 굴렀다?", type: "조작", time: "10분",
    tags: ["원의 둘레", "구름", "역설"], links: ["lab-cycloid", "par-staircase"],
    desc: "큰 바퀴에 붙은 작은 바퀴가 함께 한 바퀴 돌면 두 원 모두 같은 거리만큼 앞으로 나갑니다. 그럼 두 원의 둘레가 같을까요? 작은 원 위 점이 그리는 곡선을 보면 작은 원은 바닥을 미끄러지며 지나가고 있습니다. 고대 그리스의 문헌에 실린 오래된 역설입니다.",
    obs: ["큰 원은 미끄러지지 않고 구르므로 2πR만큼 나갑니다.", "작은 원 위의 점은 사이클로이드가 아닌 납작한 곡선을 그립니다.", "작은 원은 구르는 동시에 미끄러지므로 둘레와 나간 거리가 다릅니다."],
    q: "작은 원만 바닥에 닿게 굴리면 큰 원은 어떻게 움직일까요?",
    formula: "나간 거리 2πR ≠ 작은 원의 둘레 2πr",
    en: { title: "Aristotle's Wheel Paradox", desc: "Two circles, one distance." },
    view: { x: [-2.6, 15.4], y: [-0.6, 4.8] },
    params: [{ key: "t", label: "회전각 (바퀴)", min: 0, max: 1, step: 0.005, value: 0.4 }, { key: "r", label: "작은 원 반지름 r", min: 0.4, max: 1.6, step: 0.1, value: 1 }],
    anim: { key: "t", min: 0, max: 1, speed: 0.2, label: "굴리기" },
    draw(s, g) { const R = 2, th = 2 * Math.PI * s.t, cx = R * th; g.seg([-2.4, 0], [15.2, 0], { color: "ink", w: 1.6 }).seg([-2.4, R - s.r], [15.2, R - s.r], { color: "muted", w: 1, dash: "4 4" }); g.param((u) => [R * u - R * Math.sin(u), R - R * Math.cos(u)], 0, th, { color: "b", w: 2 }); g.param((u) => [R * u - s.r * Math.sin(u), R - s.r * Math.cos(u)], 0, th, { color: "a", w: 2 }); g.circle([cx, R], R, { color: "b", w: 2.4 }).circle([cx, R], s.r, { color: "a", w: 2.4 }); g.point([cx - R * Math.sin(th), R - R * Math.cos(th)], "", { color: "b" }).point([cx - s.r * Math.sin(th), R - s.r * Math.cos(th)], "", { color: "a" }); g.seg([0, 4.4], [cx, 4.4], { color: "c", w: 2.4 }).text([cx / 2, 4.4], `나간 거리 ${fmt(cx, 2)}`, { dy: -6, bold: true, color: "c" }); },
    metrics(s) { const th = 2 * Math.PI * s.t; return [["나간 거리 (두 원 공통)", fmt(2 * th, 3), "key"], ["큰 원이 굴러간 둘레", fmt(2 * th, 3)], ["작은 원이 굴러간 둘레", fmt(s.r * th, 3)]]; },
    predict: [
      { q: "반지름 2인 큰 원이 한 바퀴 구르면 나간 거리는? (소수 둘째 자리까지)", set: (s) => Object.assign(s, { t: 0.2, r: 1 }), reveal: (s) => (s.t = 1), answer: () => 4 * Math.PI, tol: 0.01, why: "2π × 2 = 4π ≈ 12.57입니다." },
      { q: "반지름 1인 작은 원의 둘레는 나간 거리와 같을까요?", options: O("같다", "다르다 — 작은 원은 미끄러진다"), answer: () => "b", why: "작은 원의 둘레는 2π로 나간 거리 4π의 절반입니다." },
    ],
  },
  {
    id: "par-rope-earth", grade: P, unit: 3, lesson: "주제 3", title: "지구에 감은 밧줄 — 1 m만 늘려도 고양이가 지나간다", type: "조작", time: "8분",
    tags: ["원의 둘레", "일차식", "직관"], links: ["m1-pizza-area", "par-aristotle-wheel"],
    desc: "지구 적도에 딱 맞게 감은 밧줄을 1 m만 늘려 고르게 띄우면 틈은 얼마나 될까요? 지구가 크니 거의 0일 것 같지만, 틈은 1/(2π) m ≈ 16 cm로 축구공에 감든 지구에 감든 똑같습니다. 둘레가 반지름에 정비례하기 때문입니다.",
    obs: ["둘레 2πR에 L을 더하면 반지름은 L/(2π)만큼 커집니다.", "틈은 원래 반지름 R과 상관이 없습니다.", "큰 수에 대한 직관이 일차식의 단순함을 놓치게 합니다."],
    q: "밧줄을 한 점에서 위로 당겨 올리면 얼마나 높이 올라갈까요? (이번엔 R이 상관있습니다)",
    formula: "2π(R + h) = 2πR + L ⇒ h = L/(2π)",
    en: { title: "A Rope Around the Earth", desc: "One extra metre lifts it 16 cm everywhere." },
    view: { x: [-1.6, 1.6], y: [-1.25, 1.25] },
    params: [{ key: "R", label: "감는 물체", type: "select", value: "earth", options: [["ball", "축구공 (반지름 0.11 m)"], ["room", "교실 기둥 (반지름 1 m)"], ["earth", "지구 (반지름 6 371 km)"]] }, { key: "L", label: "늘린 밧줄 L (m)", min: 0, max: 10, step: 0.1, value: 1 }],
    draw(s, g) { const h = s.L / (2 * Math.PI), vis = 0.9 + Math.min(0.32, h * 0.5); g.circle([0, 0], 0.9, { fill: s.R === "earth" ? "b" : s.R === "ball" ? "muted" : "d", fo: 0.25, color: "ink", w: 2 }); g.circle([0, 0], vis, { color: "a", w: 2.4, dash: "6 4" }); g.seg([0, 0.9], [0, vis], { color: "e", w: 2.4 }).text([0.04, (0.9 + vis) / 2], `틈 ${fmt(h * 100, 1)} cm`, { anchor: "start", dx: 6, bold: true, color: "e" }); g.text([0, -0.1], { ball: "축구공", room: "기둥", earth: "지구" }[s.R], { bold: true, size: 16 }); },
    metrics(s) { const R = { ball: 0.11, room: 1, earth: 6371000 }[s.R], h = s.L / (2 * Math.PI); return [["원래 둘레", `${fmt(2 * Math.PI * R, 2)} m`], ["틈 h = L/(2π)", `${fmt(h * 100, 2)} cm`, "key"], ["반지름에 따라 달라지나", "아니요"]]; },
    predict: [
      { q: "지구에 감은 밧줄을 1 m 늘리면 틈은 약 몇 cm? (정수로)", set: (s) => Object.assign(s, { R: "earth", L: 0 }), reveal: (s) => (s.L = 1), answer: () => 100 / (2 * Math.PI), tol: 0.6, why: "1/(2π) m ≈ 15.9 cm입니다." },
      { q: "축구공에 감은 밧줄을 1 m 늘렸을 때의 틈은 지구와 비교하면?", options: O("훨씬 크다", "같다", "훨씬 작다"), set: (s) => Object.assign(s, { R: "earth", L: 1 }), reveal: (s) => (s.R = "ball"), answer: () => "b", why: "h = L/(2π)로 반지름과 상관없습니다." },
    ],
  },
  // ── 4. 선택과 통계의 역설 ──
  {
    id: "par-condorcet", grade: P, unit: 4, lesson: "주제 4", title: "콩도르세의 투표 역설 — 다수결이 빙빙 돈다", type: "조작", time: "10분",
    tags: ["투표", "추이성", "사회 선택"], links: ["cul-voting", "par-nontransitive"],
    desc: "세 모둠의 선호가 A > B > C, B > C > A, C > A > B이면 다수결로 A는 B를, B는 C를, C는 A를 이깁니다. 개인은 모두 합리적인데 집단의 선택은 가위바위보처럼 순환합니다. 1785년 콩도르세가 발견했고, 훗날 애로의 불가능성 정리로 이어졌습니다.",
    obs: ["두 후보씩 맞붙이는 다수결은 순환할 수 있습니다.", "모둠의 인원을 바꾸면 순환이 깨지고 ‘콩도르세 승자’가 생기기도 합니다.", "투표 순서를 정하는 사람이 결과를 바꿀 수 있습니다."],
    q: "A 대 B를 먼저 하고 이긴 쪽과 C를 붙이면 누가 최종 승자가 될까요? 순서를 바꾸면?",
    formula: "A ≻ B, B ≻ C 이지만 C ≻ A (순환)",
    en: { title: "Condorcet's Voting Paradox", desc: "Majority preferences can cycle." },
    view: { x: [-2.2, 2.2], y: [-1.7, 1.9] },
    params: [{ key: "x", label: "모둠 1: A > B > C (명)", min: 1, max: 20, step: 1, value: 10 }, { key: "y", label: "모둠 2: B > C > A (명)", min: 1, max: 20, step: 1, value: 9 }, { key: "z", label: "모둠 3: C > A > B (명)", min: 1, max: 20, step: 1, value: 8 }],
    duel(s) { const AB = s.x + s.z - s.y, BC = s.x + s.y - s.z, CA = s.y + s.z - s.x; return { AB, BC, CA }; },
    draw(s, g) { const P0 = { A: [0, 1.3], B: [-1.4, -1.1], C: [1.4, -1.1] }, D = this.duel(s); Object.entries(P0).forEach(([k, p]) => { g.circle(p, 0.36, { fill: "b", fo: 0.18, color: "b", w: 2 }); g.text(p, k, { dy: 7, bold: true, size: 20 }); }); const arrow = (u, v, m) => { const [a, b] = m > 0 ? [P0[u], P0[v]] : [P0[v], P0[u]]; const d = [b[0] - a[0], b[1] - a[1]], L = Math.hypot(...d), e = [d[0] / L, d[1] / L]; if (m === 0) { g.seg([a[0] + e[0] * 0.45, a[1] + e[1] * 0.45], [b[0] - e[0] * 0.45, b[1] - e[1] * 0.45], { color: "muted", w: 2, dash: "4 4" }); return; } g.vec([a[0] + e[0] * 0.45, a[1] + e[1] * 0.45], [b[0] - e[0] * 0.45, b[1] - e[1] * 0.45], { color: "a" }); }; arrow("A", "B", D.AB); arrow("B", "C", D.BC); arrow("C", "A", D.CA); g.text([0, -1.6], "화살표: 이긴 쪽 → 진 쪽", { size: 12, color: "muted" }); },
    metrics(s) { const D = this.duel(s), w = (m, a, b) => (m > 0 ? `${a} 승` : m < 0 ? `${b} 승` : "동점"), cyc = D.AB > 0 && D.BC > 0 && D.CA > 0 || D.AB < 0 && D.BC < 0 && D.CA < 0; return [["A 대 B", w(D.AB, "A", "B")], ["B 대 C", w(D.BC, "B", "C")], ["C 대 A", w(D.CA, "C", "A")], ["순환?", cyc ? "예 — 승자 없음" : "아니요", "key"]]; },
    predict: [
      { q: "10, 9, 8명일 때 다수결 결과는 순환할까요?", options: O("예", "아니요"), set: (s) => Object.assign(s, { x: 10, y: 9, z: 8 }), answer: () => "a", why: "A가 B를 18:9, B가 C를 19:8, C가 A를 17:10으로 이깁니다." },
      { q: "모둠 1을 20명으로 늘리면 A 대 C에서 A는 몇 표를 얻을까요?", set: (s) => Object.assign(s, { x: 10 }), reveal: (s) => (s.x = 20), answer: () => 20, why: "A를 C보다 위에 둔 사람은 모둠 1뿐이라 20표입니다(모둠 3은 C > A)." },
    ],
  },
  {
    id: "par-braess", grade: P, unit: 4, lesson: "주제 4", title: "브라에스의 역설 — 길을 하나 더 냈더니 더 막힌다", type: "조작", time: "12분",
    tags: ["최적화", "게임 이론", "교통"], links: ["c2-shortest", "par-condorcet"],
    desc: "출발점에서 도착점까지 두 길이 있고, 각 길에는 차가 많을수록 느려지는 구간과 늘 45분 걸리는 구간이 있습니다. 두 길 사이에 0분짜리 지름길을 놓으면 모두가 자기에게 유리한 길을 고른 결과 전원이 더 늦어집니다. 1968년 브라에스가 보였고, 실제로 서울 청계고가 철거 뒤 교통이 오히려 나아진 사례도 함께 이야기됩니다.",
    obs: ["모두가 각자 가장 빠른 길을 고르는 상태(내시 균형)가 모두에게 최선은 아닙니다.", "지름길이 생기면 모두가 느려지는 구간 두 개를 지납니다.", "차가 아주 많아지면 지름길은 다시 쓰이지 않습니다."],
    q: "지름길에 통행료를 받으면 이 역설을 막을 수 있을까요?",
    formula: "지름길 없음: N/200 + 45분, 지름길 있음(N ≤ 4500): N/50분",
    en: { title: "Braess's Paradox", desc: "Adding a road can slow everyone." },
    view: { x: [-1, 11], y: [-1.6, 6.4] },
    params: [{ key: "N", label: "차량 수 N", min: 500, max: 9500, step: 100, value: 4000 }, { key: "sc", label: "A → B 지름길 (0분) 열기", type: "check", value: false }],
    draw(s, g) { const F = braess(s.N, s.sc), S0 = [0, 2.4], E0 = [10, 2.4], A0 = [5, 5.2], B0 = [5, -0.4], w = (f) => 1 + (6 * f) / Math.max(1, s.N); const node = (p, t) => { g.circle(p, 0.42, { fill: "paper", color: "ink", w: 2 }); g.text(p, t, { dy: 6, bold: true, size: 16 }); }; g.seg(S0, A0, { color: "a", w: w(F.p + F.r) }).seg(A0, E0, { color: "c", w: w(F.p) }).seg(S0, B0, { color: "c", w: w(F.q) }).seg(B0, E0, { color: "a", w: w(F.q + F.r) }); if (s.sc) g.seg(A0, B0, { color: "e", w: w(F.r) }); g.text([2.2, 4.4], `x/100분 · ${fmt(F.p + F.r, 0)}대`, { size: 12, bold: true, color: "a", anchor: "end" }).text([7.8, 4.4], `45분 · ${fmt(F.p, 0)}대`, { size: 12, bold: true, color: "c", anchor: "start" }).text([2.2, 0.4], `45분 · ${fmt(F.q, 0)}대`, { size: 12, bold: true, color: "c", anchor: "end" }).text([7.8, 0.4], `x/100분 · ${fmt(F.q + F.r, 0)}대`, { size: 12, bold: true, color: "a", anchor: "start" }); if (s.sc) g.text([5.2, 2.4], `0분 · ${fmt(F.r, 0)}대`, { anchor: "start", size: 12, bold: true, color: "e" }); node(S0, "출발"); node(E0, "도착"); node(A0, "A"); node(B0, "B"); },
    metrics(s) { const a = braess(s.N, false), b = braess(s.N, true); return [["지름길 없을 때 걸리는 시간", `${fmt(a.t, 1)}분`], ["지름길 있을 때 걸리는 시간", `${fmt(b.t, 1)}분`, "key"], ["현재", `${fmt(braess(s.N, s.sc).t, 1)}분`]]; },
    predict: [
      { q: "차 4000대, 지름길이 없을 때 모두 걸리는 시간은 몇 분?", set: (s) => Object.assign(s, { N: 4000, sc: false }), answer: () => 65, why: "두 길에 2000대씩, 20 + 45 = 65분입니다." },
      { q: "지름길을 열면 모두 걸리는 시간은 몇 분?", set: (s) => Object.assign(s, { N: 4000, sc: false }), reveal: (s) => (s.sc = true), answer: () => 80, why: "모두 출발→A→B→도착을 택해 40 + 0 + 40 = 80분으로 15분 늦어집니다." },
    ],
  },
  {
    id: "par-friendship", grade: P, unit: 4, lesson: "주제 4", title: "우정의 역설 — 내 친구들은 나보다 친구가 많다", type: "데이터", time: "10분",
    tags: ["평균", "네트워크", "표본 편향"], links: ["lab-konigsberg", "par-inspection"],
    desc: "대부분의 사람에게 '내 친구들의 평균 친구 수'는 '내 친구 수'보다 많습니다. 친구가 많은 사람일수록 여러 사람의 친구 목록에 등장하기 때문입니다. 1991년 사회학자 펠드가 밝힌 이 현상을 무작위로 만든 친구 관계망에서 직접 셉니다.",
    obs: ["사람의 평균 친구 수보다 ‘친구의 평균 친구 수’가 큽니다.", "인기 있는 사람이 평균을 끌어올립니다(표본 편향).", "감염병 조사에서 무작위로 고른 사람의 ‘친구’를 조사하면 감염을 더 일찍 발견할 수 있습니다."],
    q: "누구나 친구 수가 똑같은 관계망에서도 이 역설이 생길까요?",
    formula: "친구의 평균 친구 수 = Σd² / Σd ≥ Σd / n",
    en: { title: "The Friendship Paradox", desc: "Your friends have more friends than you." },
    view: { x: [-1.35, 1.35], y: [-1.2, 1.2] },
    params: [{ key: "n", label: "사람 수", min: 10, max: 40, step: 1, value: 24 }, { key: "seed", label: "씨앗값", min: 1, max: 97, step: 1, value: 3 }],
    ...SEED,
    stat(s) { const { E, deg } = net(s.n, s.seed), adj = deg.map(() => []); E.forEach(([a, b]) => { adj[a].push(b); adj[b].push(a); }); const avg = deg.reduce((a, b) => a + b, 0) / s.n, ff = deg.reduce((a, d) => a + d * d, 0) / deg.reduce((a, b) => a + b, 0); let less = 0; adj.forEach((L, i) => { const m = L.reduce((a, j) => a + deg[j], 0) / L.length; if (deg[i] < m) less++; }); return { E, deg, avg, ff, less }; },
    draw(s, g) { const { E, deg } = this.stat(s), P0 = deg.map((_, i) => [Math.cos((2 * Math.PI * i) / s.n), Math.sin((2 * Math.PI * i) / s.n)]); E.forEach(([a, b]) => g.seg(P0[a], P0[b], { color: "muted", w: 1, opacity: 0.6 })); P0.forEach((p, i) => g.circle(p, 0.03 + 0.012 * deg[i], { fill: deg[i] >= 5 ? "a" : "b", fo: 0.85, color: "paper", w: 1 })); g.text([-1.3, 1.12], "원의 크기 = 친구 수 · 주황 = 친구 5명 이상", { anchor: "start", size: 12, bold: true }); },
    metrics(s) { const S = this.stat(s); return [["사람들의 평균 친구 수", fmt(S.avg, 2)], ["친구들의 평균 친구 수", fmt(S.ff, 2), "key"], ["친구들보다 친구가 적은 사람", `${S.less}/${s.n}명`]]; },
    predict: [
      { q: "‘친구들의 평균 친구 수’는 ‘사람들의 평균 친구 수’보다 클까요?", options: O("크다", "같다", "작다"), set: (s) => Object.assign(s, { n: 24, seed: 3 }), answer: () => "a", why: "친구 많은 사람이 여러 번 세어져 Σd²/Σd ≥ Σd/n입니다." },
      { q: "친구 수가 1, 3, 3, 3인 4명(별 모양 아님)이 있다면 Σd²/Σd는? (분수나 소수로)", answer: () => 28 / 10, tol: 1e-6, why: "(1 + 9 + 9 + 9)/(1 + 3 + 3 + 3) = 28/10 = 2.8 > 평균 2.5입니다." },
    ],
  },
  {
    id: "par-inspection", grade: P, unit: 4, lesson: "주제 4", title: "버스 대기의 역설 — 평균 10분 간격인데 10분을 기다린다", type: "데이터", time: "10분",
    tags: ["기댓값", "표본 편향", "확률분포"], links: ["par-friendship", "pst-expectation"],
    desc: "버스가 평균 10분마다 온다면 아무 때나 정류장에 간 사람은 평균 5분을 기다릴 것 같습니다. 그러나 간격이 들쭉날쭉하면 긴 간격 안에 도착할 가능성이 더 커서 평균 대기 시간이 늘어나고, 완전히 무작위(지수분포)면 10분이 됩니다. 이를 '검사의 역설'이라 부릅니다.",
    obs: ["긴 간격일수록 그 안에 도착할 확률이 그 길이에 비례해 커집니다.", "평균 대기 시간 = E[간격²] / (2E[간격])입니다.", "간격이 일정할 때 대기 시간이 가장 짧습니다."],
    q: "‘우리 반 평균 인원’을 학생에게 물어 조사하면 실제 평균보다 크게 나오는 까닭은?",
    formula: "평균 대기 = E[I²] / (2E[I])",
    en: { title: "The Inspection Paradox", desc: "Why the bus always seems late." },
    view: { x: [-0.4, 10.4], y: [-1.6, 6] },
    params: [{ key: "m", label: "버스 간격", type: "seg", value: "exp", options: [["reg", "늘 10분"], ["mix", "2분 또는 18분"], ["exp", "완전 무작위"]] }, { key: "seed", label: "씨앗값", min: 1, max: 97, step: 1, value: 1 }],
    ...SEED,
    wait(s) { const I = buses(s.m, s.seed).filter(([t]) => t < 120); const E1 = I.reduce((a, [, d]) => a + d, 0) / I.length, E2 = I.reduce((a, [, d]) => a + d * d, 0) / I.length; return { I, mean: E1, w: E2 / (2 * E1) }; },
    draw(s, g) { const { I } = this.wait(s), X = (t) => t / 12; g.seg([0, 0], [10, 0], { color: "ink", w: 1.6 }); I.forEach(([t, d], k) => { const e = Math.min(120, t + d); rect(g, X(t), 0.4, X(e) - X(t), 1.6, { fill: k % 2 ? "b" : "c", fo: Math.min(0.85, 0.15 + d / 30), color: "paper", w: 1 }); g.seg([X(t), -0.4], [X(t), 2.4], { color: "a", w: 1.6 }); }); g.text([0, 0], "0분", { dy: 16, size: 11 }).text([10, 0], "120분", { dy: 16, size: 11 }); g.text([0, 5.2], "주황 세로선: 버스 도착 · 칸의 진하기: 간격의 길이", { anchor: "start", bold: true, size: 13 }); },
    metrics(s) { const { mean, w } = this.wait(s), th = { reg: 5, mix: 8.2, exp: 10 }[s.m]; return [["평균 간격 (이 2시간)", `${fmt(mean, 1)}분`], ["평균 대기 시간 (이 2시간)", `${fmt(w, 1)}분`, "key"], ["이론값", `${fmt(th, 1)}분`]]; },
    predict: [
      { q: "버스가 늘 10분 간격이면 평균 대기 시간은 몇 분?", set: (s) => (s.m = "exp"), reveal: (s) => (s.m = "reg"), answer: () => 5, why: "0~10분 중 고르게 기다리므로 5분입니다." },
      { q: "간격이 2분 또는 18분(반반)이면 평균 대기 시간은? (소수로)", set: (s) => (s.m = "reg"), reveal: (s) => (s.m = "mix"), answer: () => 8.2, tol: 0.01, why: "E[I²] = (4 + 324)/2 = 164, E[I] = 10이므로 164/20 = 8.2분입니다." },
    ],
  },
  {
    id: "par-nontransitive", grade: P, unit: 4, lesson: "주제 4", title: "이길 수 없는 주사위 — 에프론의 비추이적 주사위", type: "조작", time: "10분",
    tags: ["확률", "추이성", "게임"], links: ["par-condorcet", "pst-dice-sum"],
    desc: "통계학자 에프론이 만든 네 주사위 A, B, C, D는 A가 B를, B가 C를, C가 D를, D가 A를 각각 2/3의 확률로 이깁니다. 어떤 주사위를 골라도 그보다 센 주사위가 있습니다. 두 주사위를 골라 36가지 결과를 칸으로 나타내고 이긴 칸을 셉니다.",
    obs: ["‘A가 B보다 세고 B가 C보다 세면 A가 C보다 세다’(추이성)가 성립하지 않습니다.", "상대가 먼저 고르게 하면 늘 이길 주사위를 고를 수 있습니다.", "가위바위보와 같은 구조가 확률에서도 생깁니다."],
    q: "두 번 던져 합을 비교하는 게임으로 바꾸면 강약 순서가 그대로일까요?",
    formula: "P(A > B) = P(B > C) = P(C > D) = P(D > A) = 2/3",
    en: { title: "Efron's Nontransitive Dice", desc: "Every die has a stronger rival." },
    view: { x: [-1.6, 7.4], y: [-1.6, 7.2] },
    params: [{ key: "p", label: "맞붙는 두 주사위", type: "select", value: "AB", options: [["AB", "A (4,4,4,4,0,0) 대 B (3,3,3,3,3,3)"], ["BC", "B 대 C (6,6,2,2,2,2)"], ["CD", "C 대 D (5,5,5,1,1,1)"], ["DA", "D 대 A"], ["AC", "A 대 C"]] }],
    draw(s, g) { const [X, Y] = s.p.split(""), a = DICE[X], b = DICE[Y]; for (let i = 0; i < 6; i++) { g.text([i + 0.5, 6], `${a[i]}`, { dy: 14, bold: true, color: "a" }); g.text([-0.3, 5.5 - i], `${b[i]}`, { anchor: "end", dy: 5, bold: true, color: "b" }); for (let j = 0; j < 6; j++) { const w = a[i] > b[j] ? "a" : a[i] < b[j] ? "b" : "muted"; rect(g, i, 5 - j, 1, 1, { fill: w, fo: 0.6, color: "paper", w: 1.4 }); } } g.text([3, 6.8], `가로: 주사위 ${X} · 세로: 주사위 ${Y}`, { bold: true }); },
    metrics(s) { const [X, Y] = s.p.split(""), a = DICE[X], b = DICE[Y]; let w = 0, l = 0; a.forEach((x) => b.forEach((y) => (x > y ? w++ : x < y ? l++ : 0))); return [[`${X}가 이기는 칸`, `${w}/36`], [`${Y}가 이기는 칸`, `${l}/36`], [`P(${X} 승)`, fmt(w / 36, 4), "key"]]; },
    predict: [
      { q: "A(4,4,4,4,0,0)가 B(3,3,3,3,3,3)를 이길 확률은? (분수나 소수로)", set: (s) => (s.p = "AB"), answer: () => 2 / 3, tol: 1e-6, show: () => "2/3", why: "A가 4를 낼 확률 4/6 = 2/3이면 늘 이깁니다." },
      { q: "D(5,5,5,1,1,1)와 A가 붙으면 누가 더 셀까요?", options: O("D", "A", "같다"), set: (s) => (s.p = "CD"), reveal: (s) => (s.p = "DA"), answer: () => "a", why: "D가 24/36 = 2/3의 확률로 이깁니다. 강약이 한 바퀴 돕니다." },
    ],
  },
  {
    id: "par-simpson", grade: P, unit: 4, lesson: "주제 4", title: "심슨의 역설 — 각 학과에선 앞서는데 전체에선 뒤진다", type: "조작", time: "12분",
    tags: ["비율", "통계", "혼동 변수"], links: ["pst-bayes", "par-base-rate"],
    desc: "두 학과 모두에서 여학생의 합격률이 더 높은데, 전체를 합치면 남학생의 합격률이 더 높게 나올 수 있습니다. 여학생이 경쟁률 높은 학과에 더 많이 지원했기 때문입니다. 1973년 미국 버클리 대학 입시 자료에서 실제로 나타난 현상을 지원자 수를 바꾸며 재현합니다.",
    obs: ["합격률은 학과 A(쉬움): 남 80%, 여 90% / 학과 B(어려움): 남 20%, 여 25%로 고정했습니다.", "어느 학과에 지원했는지가 ‘숨은 변수’가 되어 전체 비율을 뒤집습니다.", "자료를 합치기 전에 집단별로 나누어 보아야 합니다."],
    q: "지원자를 두 학과에 똑같이 나누면 역설이 사라질까요?",
    formula: "전체 합격률 = (학과별 합격률)을 지원자 비율로 가중평균",
    en: { title: "Simpson's Paradox", desc: "Trends reverse when groups combine." },
    view: { x: [-0.6, 10.6], y: [-1.6, 11.6] },
    params: [{ key: "m", label: "남학생 120명 중 어려운 학과 B 지원", min: 0, max: 120, step: 5, value: 20 }, { key: "w", label: "여학생 120명 중 어려운 학과 B 지원", min: 0, max: 120, step: 5, value: 100 }],
    calc(s) { const mA = 120 - s.m, wA = 120 - s.w, M = 0.8 * mA + 0.2 * s.m, W = 0.9 * wA + 0.25 * s.w; return { M: M / 120, W: W / 120 }; },
    draw(s, g) { const C = this.calc(s), bar = (x, v, col, lab) => { rect(g, x, 0, 1.2, v * 10, { fill: col, fo: 0.7, stroke: false }); g.text([x + 0.6, v * 10], `${fmt(v * 100, 1)}%`, { dy: -6, size: 12, bold: true }); g.text([x + 0.6, 0], lab, { dy: 16, size: 12 }); }; bar(0.2, 0.8, "b", "남"); bar(1.5, 0.9, "a", "여"); bar(3.6, 0.2, "b", "남"); bar(4.9, 0.25, "a", "여"); bar(7.4, C.M, "b", "남"); bar(8.7, C.W, "a", "여"); g.text([1.45, 0], "학과 A", { dy: 34, bold: true }).text([4.85, 0], "학과 B", { dy: 34, bold: true }).text([8.65, 0], "전체", { dy: 34, bold: true, color: "e" }); g.seg([6.8, 0], [6.8, 11], { color: "muted", w: 1, dash: "4 4" }); },
    metrics(s) { const C = this.calc(s); return [["전체 합격률 — 남", `${fmt(C.M * 100, 1)}%`], ["전체 합격률 — 여", `${fmt(C.W * 100, 1)}%`, "key"], ["역설 발생?", C.M > C.W ? "예 — 전체에서 뒤집힘" : "아니요"]]; },
    predict: [
      { q: "남 20명, 여 100명이 어려운 학과에 지원하면 전체 합격률은 누가 더 높을까요?", options: O("남학생", "여학생"), set: (s) => Object.assign(s, { m: 60, w: 60 }), reveal: (s) => Object.assign(s, { m: 20, w: 100 }), answer: () => "a", why: "남 84/120 = 70%, 여 43/120 ≈ 35.8%로 뒤집힙니다." },
      { q: "두 성별 모두 60명씩 어려운 학과에 지원하면 여학생 전체 합격률은 몇 %? (소수 첫째 자리까지)", set: (s) => Object.assign(s, { m: 20, w: 100 }), reveal: (s) => Object.assign(s, { m: 60, w: 60 }), answer: () => 57.5, tol: 0.05, why: "(54 + 15)/120 = 57.5%로 남학생 50%보다 높아 역설이 사라집니다." },
    ],
  },
];
