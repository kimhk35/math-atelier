// Mathematical reading and comparison tools for the existing circle studio.
const PI=Math.PI,TAU=2*PI;
const fmt=n=>Math.abs(n)<1e-10?'0':String(Number(n.toFixed(3)));
const gcd=(a,b)=>b?gcd(b,a%b):Math.abs(a);
export const normalizeAngle=a=>((a%360)+360)%360;
export function exactAngle(angle){
 const a=normalizeAngle(angle),rounded=Math.round(a),special=Math.abs(a-rounded)<1e-7;
 const axis=special&&rounded%90===0;
 const q=axis?['양의 x축','양의 y축','음의 x축','음의 y축'][(rounded%360)/90]:`${Math.floor(a/90)+1}사분면`;
 const ref=a<=90?a:a<=180?180-a:a<=270?a-180:360-a;
 const r=Math.round(ref),known=special&&[0,30,45,60,90].includes(r);
 const sin0={0:'0',30:'1/2',45:'√2/2',60:'√3/2',90:'1'},cos0={0:'1',30:'√3/2',45:'√2/2',60:'1/2',90:'0'},tan0={0:'0',30:'√3/3',45:'1',60:'√3',90:null};
 const signed=(v,n)=>v==='0'?v:(n<0?'−':'')+v;
 const sn=Math.sin(angle*PI/180),cs=Math.cos(angle*PI/180),tn=Math.abs(cs)<1e-10?null:sn/cs;
 let rad;if(Math.abs(angle*1000-Math.round(angle*1000))<1e-6){const numerator=Math.round(angle*1000),denominator=180000,g=gcd(numerator,denominator),n=numerator/g,d=denominator/g;rad=n===0?'0':(n===1?'π':n+'π')+(d===1?'':'/'+d);}else rad='≈ '+fmt(angle/180)+'π';
 return {quadrant:q,reference:ref,rad,known,sin:known?signed(sin0[r],sn):'≈ '+fmt(sn),cos:known?signed(cos0[r],cs):'≈ '+fmt(cs),tan:tn===null?'정의되지 않음':known?signed(tan0[r],tn):'≈ '+fmt(tn),sinValue:sn,cosValue:cs};
}
export function symmetricAngle(angle,kind){return normalizeAngle(({opposite:180+angle,xaxis:-angle,yaxis:180-angle,complement:90-angle})[kind]??angle);}
export function mathCards(s){
 const e=exactAngle(s.angle);
 if(['space','flat','tangent'].includes(s.view))return [['각과 위치',e.rad+' rad / '+e.quadrant],['cos θ / sin θ',e.cos+' / '+e.sin],['tan θ',e.tan],['항상 성립하는 관계','cos²θ + sin²θ = 1']];
 if(s.view==='transform')return [['주기',fmt(360/s.b)+'° = '+fmt(2/s.b)+'π'],['가로 이동량',fmt(-s.phase/s.b)+'°'],['함숫값의 범위',fmt(s.d-s.a)+' ≤ y ≤ '+fmt(s.d+s.a)],['원의 회전각',fmt(s.b*s.angle+s.phase)+'°']];
 if(s.view==='sum'){const r=Math.hypot(1+s.a*Math.cos(s.phase*PI/180),s.a*Math.sin(s.phase*PI/180)),phase=Math.atan2(s.a*Math.sin(s.phase*PI/180),1+s.a*Math.cos(s.phase*PI/180))*180/PI;return [['첫 번째 식','sin θ'],['두 번째 식',fmt(s.a)+' sin('+fmt(s.b)+'θ '+(s.phase<0?'− ':'+ ')+fmt(Math.abs(s.phase))+'°)'],['같은 배율일 때 합성 진폭',s.b===1?fmt(r):'B = 1일 때 확인'],['하나의 사인식으로 표현',s.b!==1?'B가 다르면 이 공식을 쓰지 않아요':r<1e-10?'항상 0':fmt(r)+' sin(θ '+(phase<0?'− ':'+ ')+fmt(Math.abs(phase))+'°)']];}
 return null;
}
const line=(pts)=>`<polyline points="${pts.map(p=>p.map(fmt).join(',')).join(' ')}" fill="none" stroke="#087d75" stroke-width="2.5" stroke-dasharray="8 5" opacity=".7"/>`;
const point=(x,y)=>`<circle cx="${x}" cy="${y}" r="8" fill="none" stroke="#087d75" stroke-width="3"/>`;
export function compareScene(svg,s,ref){
 if(!ref||ref.view!==s.view)return svg;
 const t=ref.angle*PI/180,sn=Math.sin(t),cs=Math.cos(t);let out='';
 if(s.view==='space'){const P=(x,y,z)=>[245+77*x-90*y,280+24*x+37*y-100*z];for(const p of [P(0,cs,sn),P(t,0,sn),P(t,cs,0)])out+=point(...p);}
 if(s.view==='flat'){out+=point(170+104*cs,290-104*sn);for(const [v,y] of [[sn,220],[cs,450]])out+=line([[370+80*t,y-90],[370+80*t,y+90]])+point(370+80*t,y-74*v);}
 if(['transform','sum','tangent'].includes(s.view)){
  const end=s.view==='sum'?TAU*2:TAU,scale=s.view==='sum'?64:s.view==='tangent'?62:58,X=x=>376+535*x/end,Y=y=>345-scale*y;
  if(s.view==='tangent'){if(Math.abs(cs)>1e-10&&Math.abs(sn/cs)<=3)out+=point(X(t),Y(sn/cs));}
  else {const fn=x=>(s.view==='sum'?Math.sin(x):ref.d)+ref.a*Math.sin(ref.b*x+ref.phase*PI/180);out+=line(Array.from({length:501},(_,i)=>[X(i*end/500),Y(fn(i*end/500))]))+point(X(t),Y(fn(t)));}
 }
 if(!out)return svg;
 return svg.replace('</svg>',`<g aria-label="고정한 기준" data-reference-overlay>${out}<rect x="670" y="16" width="265" height="27" rx="6" fill="#e8f3ee"/><text x="682" y="35" fill="#087d75" font-size="14" font-family="system-ui">초록 점선과 빈 원: 고정한 기준</text></g></svg>`);
}
