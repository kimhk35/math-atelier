export const TAU = 2*Math.PI;
export const fmt=n=>Number.isFinite(n)?(Math.abs(n)<.00005?'0':Number(n.toFixed(3)).toString()):'정의되지 않음';
export const tangent=t=>Math.abs(Math.cos(t))<1e-10?null:Math.tan(t);
export function values(s,t=s.angle*Math.PI/180){const p=s.b*t+s.phase*Math.PI/180;return {t,phase:p,sin:Math.sin(t),cos:Math.cos(t),tan:tangent(t),wave:s.a*Math.sin(p)+s.d,second:s.a*Math.sin(p),sum:Math.sin(t)+s.a*Math.sin(p),period:TAU/s.b};}
const I='#263d5b',S='#6255c7',C='#c55337',G='#087d75';
const line=(p,c=I,w=2,dash='',op=1)=>p.length>1?`<polyline points="${p.map(x=>x.join(',')).join(' ')}" fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" opacity="${op}" stroke-dasharray="${dash}"/>`:'';
const txt=(x,y,t,c=I,z=17,a='start')=>`<text x="${x}" y="${y}" fill="${c}" font-size="${z}" text-anchor="${a}" font-family="system-ui, sans-serif">${t}</text>`;
const dot=(p,c=I,r=5)=>`<circle cx="${p[0]}" cy="${p[1]}" r="${r}" fill="${c}" stroke="#faf7ef" stroke-width="2"/>`;
const circle=(x,y,r,c=I)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="none" stroke="${c}" stroke-width="2"/>`;
export function segments(fn,end,max,breaks=[]){let chunks=[],p=[];for(let i=0;i<=720;i++){let x=end*i/720,y=fn(x),prev=p.at(-1);const crosses=prev&&breaks.some(b=>prev[0]<b&&x>=b);if(y===null||!Number.isFinite(y)||Math.abs(y)>max||crosses){if(p.length>1)chunks.push(p);p=[];if(y===null||!Number.isFinite(y)||Math.abs(y)>max)continue;}p.push([x,y]);}if(p.length>1)chunks.push(p);return chunks;}
export function advancedScene(s){
 const v=values(s),sum=s.view==='sum',tan=s.view==='tangent',end=sum?TAU*2:TAU,max=tan?3:sum?3:3.5;
 const x0=376,w=535,cy=345,ys=tan?62:sum?64:58,Q=(x,y)=>[x0+w*x/end,cy-ys*y];
 let out=`<rect width="960" height="640" rx="18" fill="#faf7ef"/><rect width="960" height="96" rx="18" fill="#263d5b"/>${txt(30,33,'MATH ATELIER / WAVE STUDIO','#cfdaeb',13)}${txt(30,72,tan?'접선 위의 길이가 탄젠트가 됩니다':sum?'두 회전의 높이를 더하면 어떤 파동이 될까요?':'원의 크기와 회전 속도가 그래프를 바꿉니다','#fffaf2',24)}`;
 for(let n=-3;n<=3;n++){out+=line([Q(0,n),Q(end,n)],I,n===0?1.5:1,'',n===0?.7:.12)+txt(x0-14,cy-ys*n+5,String(n),I,14,'end');}
 for(let j=0;j<=4;j++){let t=end*j/4;out+=line([Q(t,-max),Q(t,max)],I,1,'',.13)+txt(Q(t,0)[0],565,(sum?['0','π','2π','3π','4π']:['0','π/2','π','3π/2','2π'])[j],I,15,'middle');}
 out+=txt(922,cy+7,'θ',I,18)+txt(x0-12,123,'y',I,18);
 const plot=(fn,c,thick=3,dash='',op=1,upto=end,breaks=[])=>segments(fn,upto,max,breaks).map(p=>line(p.map(([x,y])=>Q(x,y)),c,thick,dash,op)).join('');
 const origin=[176,335],r=sum?46:70;
 out+=line([[45,335],[310,335]],I,1,'',.35)+line([[176,175],[176,495]],I,1,'',.35);
 if(tan){
  const a=[origin[0]+r*v.cos,origin[1]-r*v.sin],tx=origin[0]+r;
  out+=circle(...origin,r)+line([[tx,145],[tx,525]],C,2)+line([origin,a],I,3)+dot(a,S)+txt(38,150,'단위원과 접선',I,20)+txt(tx+10,520,'x = 1',C,16);
  const poles=[Math.PI/2,3*Math.PI/2];for(const t of poles)out+=line([Q(t,-max),Q(t,max)],C,2,'6 7',.7);
  out+=plot(tangent,C,2,'4 6',.25,end,poles)+plot(tangent,C,3.5,'',1,v.t,poles);
  if(v.tan!==null&&Math.abs(v.tan)<=2.55){const b=[tx,335-r*v.tan];out+=line([origin,b],I,1.5,'5 5')+line([[tx,335],b],C,4)+dot(b,C);if(s.guides)out+=line([b,Q(v.t,v.tan)],C,1.5,'5 6',.6);}
  if(v.tan!==null&&Math.abs(v.tan)<=max)out+=dot(Q(v.t,v.tan),C,6);
  out+=txt(395,150,'y = tan θ',C,25)+txt(35,570,v.tan===null?'이 각도에서는 값이 정의되지 않습니다':Math.abs(v.tan)>max?'현재 값은 그래프의 표시 범위 밖입니다':'접선 위의 부호 있는 길이를 읽어 보세요',I,17);
  out+=txt(35,609,'90°와 270°에서 그래프를 연결하지 않습니다. 주기는 180° = π입니다.',I,16);
 } else if(sum){
  const a=[176+r*Math.cos(v.t),335-r*Math.sin(v.t)],b=[a[0]+r*s.a*Math.cos(v.phase),a[1]-r*s.a*Math.sin(v.phase)];
  out+=circle(...origin,r,S)+circle(...a,r*s.a,C)+line([origin,a],S,3)+line([a,b],C,3)+line([origin,b],G,4)+dot(a,S)+dot(b,G,7);
  out+=plot(x=>Math.sin(x),S,2,'5 5',.55)+plot(x=>values(s,x).second,C,2,'5 5',.55)+plot(x=>values(s,x).sum,G,2,'4 6',.2)+plot(x=>values(s,x).sum,G,4,'',1,v.t);
  if(s.guides)out+=line([b,[340,b[1]],Q(v.t,v.sum)],G,1.5,'5 6',.6);
  out+=line([Q(v.t,0),Q(v.t,v.sin)],S,5)+line([Q(v.t,v.sin),Q(v.t,v.sum)],C,5)+dot(Q(v.t,v.sum),G,7);
  out+=txt(35,140,'회전 벡터를 끝에 이어 붙이기',I,19)+txt(390,142,'보라: sin θ',S,17)+txt(580,142,'주황: A sin(Bθ + φ)',C,17)+txt(390,172,'초록: 두 파동의 합',G,20);
  out+=txt(35,570,`높이 ${fmt(v.sin)} + (${fmt(v.second)}) = ${fmt(v.sum)}`,G,19)+txt(35,609,'같은 방향이면 커지고 반대 방향이면 줄어듭니다. 두 회전의 높이만 더합니다.',I,16);
 } else {
  const center=[176,335-s.d*ys],rr=s.a*ys,a=[176+rr*Math.cos(v.phase),center[1]-rr*Math.sin(v.phase)];
  out+=circle(...center,rr,S)+line([center,a],I,3)+line([[a[0],center[1]],a],S,4)+dot(a,S,7)+dot(center,I,3)+line([[45,center[1]],[310,center[1]]],C,1.5,'4 5');
  out+=plot(Math.sin,I,1.8,'5 6',.28)+plot(x=>values(s,x).wave,S,2,'4 6',.25)+plot(x=>values(s,x).wave,S,4,'',1,v.t);
  out+=line([Q(0,s.d),Q(end,s.d)],C,1.5,'5 6',.65)+line([Q(v.t,s.d),Q(v.t,v.wave)],S,4)+dot(Q(v.t,v.wave),S,7);
  if(s.guides)out+=line([a,Q(v.t,v.wave)],S,1.5,'5 6',.65);
  out+=txt(35,141,`반지름 A = ${fmt(s.a)}`,S,20)+txt(35,173,`회전각 Bθ + φ = ${fmt(v.phase*180/Math.PI)}°`,I,16)+txt(390,142,`y = ${fmt(s.a)} sin(${fmt(s.b)}θ ${s.phase<0?'−':'+'} ${fmt(Math.abs(s.phase)/180)}π) ${s.d<0?'−':'+'} ${fmt(Math.abs(s.d))}`,S,22);
  out+=txt(35,550,`중심 높이 D = ${fmt(s.d)}`,C,18)+txt(35,586,`진폭 ${fmt(s.a)}   /   주기 ${fmt(360/s.b)}°   /   중심선 y = ${fmt(s.d)}`,I,18)+txt(35,616,'회색 점선은 원래의 sin θ입니다. φ는 시작 각도이며 가로 이동량은 −φ/B입니다.',I,15);
 }
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 640" role="img" aria-label="${tan?'탄젠트':sum?'파동 합성':'삼각함수 변환'} 그래프와 회전각 ${fmt(s.angle)}도">${out}</svg>`;
}
