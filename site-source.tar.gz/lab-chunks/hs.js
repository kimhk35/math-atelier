// 고등 실험 목록과 연결 — 과목별 파일을 모아 셸에 넘긴다
import { mount as mountSpec, thumbSVG } from "./hs-core.js";
import c2 from "./hs-c2.js";
import alg from "./hs-alg.js";
import geo from "./hs-geo.js";
import calc from "./hs-calc.js";
import prob from "./hs-prob.js";
import mid from "./hs-mid.js";
import lab from "./hs-lab.js";
import more from "./hs-more.js";
import ext from "./hs-ext.js";
import calc2 from "./hs-calc2.js";
import remake from "./hs-remake.js";
import more2 from "./hs-more2.js";
import more3 from "./hs-more3.js";
import more4 from "./hs-more4.js";
import more5 from "./hs-more5.js";
import more6 from "./hs-more6.js";
import cm1 from "./hs-cm1.js";
import cm2 from "./hs-cm2.js";
import binom from "./hs-binom.js";
import alg2 from "./hs-alg2.js";
import calc3 from "./hs-calc3.js";
import calc4 from "./hs-calc4.js";
import new1 from "./hs-new1.js";
import new2 from "./hs-new2.js";
import new3 from "./hs-new3.js";
import mid1 from "./hs-mid1.js";
import mid2 from "./hs-mid2.js";
import mid3 from "./hs-mid3.js";
import lab2 from "./hs-lab2.js";
import mid1b from "./hs-mid1b.js";
import mid2b from "./hs-mid2b.js";
import mid3b from "./hs-mid3b.js";
import new4 from "./hs-new4.js";
import alg3 from "./hs-alg3.js";
import geo2 from "./hs-geo2.js";
import calc5 from "./hs-calc5.js";
import calc6 from "./hs-calc6.js";
import para from "./hs-para.js";
import para2 from "./hs-para2.js";
import hist from "./hs-hist.js";
import hist2 from "./hs-hist2.js";
import puz from "./hs-puz.js";
import puz2 from "./hs-puz2.js";
import last from "./hs-last.js";
import mix2 from "./hs-mix2.js";
import mid4 from "./hs-mid4.js";
import mix1 from "./hs-mix1.js";
import lab3 from "./hs-lab3.js";
import aicj from "./hs-aicj.js";
import pst3 from "./hs-pst3.js";
import y26 from "./hs-y26.js";
import cube2 from "./hs-cube2.js";
import y27 from "./hs-y27.js";
import { bankFor } from "./predict-ui.js";
export { bankFor, mountPredict } from "./predict-ui.js";

// 같은 id가 다시 나오면 뒤의 것(새로 만든 실험)으로 바꾼다
const ALL = new Map();
for (const l of [...c2, ...alg, ...geo, ...calc, ...prob, ...mid, ...lab, ...more, ...ext, ...calc2, ...more2, ...more3, ...more4, ...more5, ...more6, ...cm1, ...cm2, ...binom, ...alg2, ...calc3, ...calc4, ...new1, ...new2, ...new3, ...mid1, ...mid2, ...mid3, ...lab2, ...mid1b, ...mid2b, ...mid3b, ...new4, ...alg3, ...geo2, ...calc5, ...calc6, ...para, ...para2, ...hist, ...hist2, ...puz, ...puz2, ...pst3, ...aicj, ...lab3, ...mix1, ...mid4, ...mix2, ...last, ...remake, ...y26, ...cube2, ...y27]) ALL.set(l.id, l);
// 예측 문항이 없는 실험에는 문항 은행의 문항을 붙인다
for (const l of ALL.values()) if (!l.predict) { const b = bankFor(l.id); if (b) l.predict = b; }
export const LABS = [...ALL.values()];
const byId = Object.fromEntries(LABS.map((l) => [l.id, l]));
// 영어판 — en-labs.js가 불러와지면 setEN으로 넘겨받아 실험을 바꿔 끼운다
let EN = null, TR = null;
export function setEN(map, tr) { EN = map; TR = tr || null; }
export function loc(spec) { const e = EN && spec && EN[spec.id]; return e ? localize(spec, e) : spec; }
function localize(sp, e) {
  const o = { ...sp };
  if (e.t) o.title = e.t; if (e.d) o.desc = e.d; if (e.o) o.obs = e.o; if (e.q) o.q = e.q; if (e.f) o.formula = e.f;
  if (e.p && sp.params) o.params = sp.params.map((p) => { const v = e.p[p.key]; if (v == null) return p; const [l, ops] = Array.isArray(v) ? v : [v]; return { ...p, label: l || p.label, options: p.options && ops ? p.options.map(([k, t], i) => [k, ops[i] ?? t]) : p.options }; });
  if (e.a && sp.anim) o.anim = { ...sp.anim, label: e.a };
  if (e.b && Array.isArray(sp.buttons)) o.buttons = sp.buttons.map(([k, t], i) => [k, e.b[i] ?? t]);
  if (e.pr && sp.predict) o.predict = sp.predict.map((it, i) => { const r = e.pr[i]; if (!r) return it; const [q, w, ops] = r; return { ...it, q: q || it.q, why: w || it.why, options: it.options && ops ? it.options.map(([k, t], j) => [k, ops[j] ?? t]) : it.options }; });
  if (TR && typeof sp.metrics === "function") o.metrics = function (st) { const r = sp.metrics.call(this, st); const t = (v) => (typeof v === "string" ? TR(v) : v); return Array.isArray(r) ? r.map((row) => (Array.isArray(row) ? row.map(t) : t(row))) : t(r); };
  return o;
}
export const mount = (id, ctx) => mountSpec(loc(byId[id]), ctx);
export const thumb = (id) => (byId[id] ? thumbSVG(byId[id]) : "");
