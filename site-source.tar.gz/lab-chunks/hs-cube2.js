// 특별관 퍼즐과 게임 — 주제 5 큐브와 회전 퍼즐 (2026-10 추가 10개)
import { fmt, clamp, deg, add, sub, mul, norm, cross, dot, len } from "./hs-core.js";
import * as C from "./cube-math.js";

const Z = 17, U5 = 5, LES = "주제 5";
const EN = () => typeof document !== "undefined" && document.documentElement.lang === "en";
const T = (ko, en) => (EN() ? en : ko);
// 큰 수는 BigInt로 받아도 세 자리마다 쉼표를 찍는다
const big = (n) => (typeof n === "bigint" ? n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : n.toLocaleString(EN() ? "en-US" : "ko-KR"));
const SEQS = [["R", "R"], ["RU", "R U"], ["sexy", "R U R′ U′"], ["R2U2", "R2 U2"], ["RU2", "R U2"], ["FRU", "F R U"], ["RUp", "R U′"], ["long", "R U2 D′ B D′"]];
const seqOf = (k) => (SEQS.find((x) => x[0] === k) || SEQS[1])[1];
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y - h], [x, y - h]], o);
const memo = (fn) => { const m = new Map(); return (k) => { if (!m.has(k)) m.set(k, fn(k)); return m.get(k); }; };
const orderOf = memo((k) => C.order(C.parse(seqOf(k))));

// 정육면체 꼭짓점·면 (3D 회전용)
const CV = []; for (const x of [-1, 1]) for (const y of [-1, 1]) for (const z of [-1, 1]) CV.push([x, y, z]);
const CFACES = [
  { n: [0, 0, 1], c: "#f4f4ee", v: [[-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]], name: "1" },
  { n: [0, 0, -1], c: "#f2cc3a", v: [[-1, -1, -1], [-1, 1, -1], [1, 1, -1], [1, -1, -1]], name: "6" },
  { n: [1, 0, 0], c: "#d8433f", v: [[1, -1, -1], [1, 1, -1], [1, 1, 1], [1, -1, 1]], name: "3" },
  { n: [-1, 0, 0], c: "#ef8a2f", v: [[-1, -1, -1], [-1, -1, 1], [-1, 1, 1], [-1, 1, -1]], name: "4" },
  { n: [0, 1, 0], c: "#2f6fd6", v: [[-1, 1, -1], [-1, 1, 1], [1, 1, 1], [1, 1, -1]], name: "5" },
  { n: [0, -1, 0], c: "#2e9e5b", v: [[-1, -1, -1], [1, -1, -1], [1, -1, 1], [-1, -1, 1]], name: "2" },
];
// 로드리게스 회전
const rot = (v, a, t) => { a = norm(a); const c = Math.cos(t), s = Math.sin(t); return add(add(mul(v, c), mul(cross(a, v), s)), mul(a, dot(a, v) * (1 - c))); };
// 24가지 회전: [종류, 축, 각]
const ROTS = (() => {
  const out = [["id", [0, 0, 1], 0]];
  for (const a of [[1, 0, 0], [0, 1, 0], [0, 0, 1]]) for (const t of [90, 270]) out.push(["face90", a, t]);
  for (const a of [[1, 0, 0], [0, 1, 0], [0, 0, 1]]) out.push(["face180", a, 180]);
  for (const a of [[1, 1, 1], [1, 1, -1], [1, -1, 1], [-1, 1, 1]]) for (const t of [120, 240]) out.push(["vertex120", a, t]);
  for (const a of [[1, 1, 0], [1, -1, 0], [1, 0, 1], [1, 0, -1], [0, 1, 1], [0, 1, -1]]) out.push(["edge180", a, 180]);
  return out;
})();
const KIND = { id: ["항등 (돌리지 않음)", "Identity"], face90: ["면의 중심을 지나는 축 (90°·270°)", "Face axis (90°/270°)"], face180: ["면의 중심을 지나는 축 (180°)", "Face axis (180°)"], vertex120: ["꼭짓점을 지나는 축 (120°·240°)", "Vertex axis (120°/240°)"], edge180: ["모서리의 가운데를 지나는 축 (180°)", "Edge-midpoint axis (180°)"] };

// 헥소미노 35가지와 정육면체 전개도 판정
const HEX = (() => {
  const canon = (cells) => {
    const forms = [];
    for (let r = 0; r < 8; r++) {
      let c = cells.map(([x, y]) => { let p = [x, y]; for (let k = 0; k < r % 4; k++) p = [-p[1], p[0]]; if (r >= 4) p = [-p[0], p[1]]; return p; });
      const mx = Math.min(...c.map((p) => p[0])), my = Math.min(...c.map((p) => p[1]));
      c = c.map(([x, y]) => [x - mx, y - my]).sort((a, b) => a[0] - b[0] || a[1] - b[1]);
      forms.push(JSON.stringify(c));
    }
    return forms.sort()[0];
  };
  let level = new Map([[canon([[0, 0]]), [[0, 0]]]]);
  for (let n = 2; n <= 6; n++) {
    const next = new Map();
    for (const cells of level.values()) for (const [x, y] of cells) for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const q = [x + dx, y + dy]; if (cells.some((p) => p[0] === q[0] && p[1] === q[1])) continue;
      const nc = [...cells, q], k = canon(nc); if (!next.has(k)) next.set(k, JSON.parse(k));
    }
    level = next;
  }
  // 굴려 보기: 칸마다 바닥에 닿는 면(몸체 기준 법선)을 구한다
  const fold = (cells) => {
    const key = (p) => p.join(","), at = new Map(), start = cells[0];
    at.set(key(start), [[1, 0, 0], [0, 1, 0], [0, 0, 1]]); // 몸체 축 → 세계 방향
    const down = [0, 0, -1], queue = [start];
    const roll = (O, d) => O.map((v) => { const vd = dot(v, d), vz = dot(v, down); return add(add(sub(sub(v, mul(d, vd)), mul(down, vz)), mul(down, vd)), mul(d, -vz)); });
    while (queue.length) {
      const p = queue.shift(), O = at.get(key(p));
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const q = [p[0] + dx, p[1] + dy]; if (!cells.some((c) => c[0] === q[0] && c[1] === q[1]) || at.has(key(q))) continue;
        at.set(key(q), roll(O, [dx, dy, 0])); queue.push(q);
      }
    }
    // 바닥 면 = 세계 아래(0,0,-1)를 가리키는 몸체 면
    return cells.map((c) => { const O = at.get(key(c)); for (let i = 0; i < 3; i++) { const w = O[i][2]; if (Math.abs(w) > 0.5) return (i + 1) * (w < 0 ? 1 : -1); } return 0; });
  };
  const list = [...level.values()].map((cells) => { const f = fold(cells); return { cells, faces: f, ok: new Set(f).size === 6 }; });
  list.sort((a, b) => b.ok - a.ok || Math.max(...a.cells.map((c) => c[0])) - Math.max(...b.cells.map((c) => c[0])));
  return list;
})();

// 라이츠 아웃: 5×5, GF(2) 풀이
const LN = 5;
const press = (b, i) => { const r = Math.floor(i / LN), c = i % LN; for (const [dr, dc] of [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]]) { const rr = r + dr, cc = c + dc; if (rr >= 0 && rr < LN && cc >= 0 && cc < LN) b[rr * LN + cc] ^= 1; } };
function solveLO(board) {
  const n = LN * LN, A = [];
  for (let i = 0; i < n; i++) { const row = Array(n + 1).fill(0); for (let j = 0; j < n; j++) { const t = Array(n).fill(0); press(t, j); row[j] = t[i]; } row[n] = board[i]; A.push(row); }
  const piv = [], where = Array(n).fill(-1); let r = 0;
  for (let c = 0; c < n && r < n; c++) { let p = r; while (p < n && !A[p][c]) p++; if (p === n) continue; [A[p], A[r]] = [A[r], A[p]]; for (let i = 0; i < n; i++) if (i !== r && A[i][c]) for (let k = c; k <= n; k++) A[i][k] ^= A[r][k]; where[c] = r; piv.push(c); r++; }
  for (let i = r; i < n; i++) if (A[i][n]) return null;
  const free = [...Array(n).keys()].filter((c) => where[c] < 0);
  let best = null;
  for (let m = 0; m < 1 << free.length; m++) {
    const x = Array(n).fill(0); free.forEach((c, k) => (x[c] = (m >> k) & 1));
    for (const c of piv) { let v = A[where[c]][n]; for (const f of free) if (A[where[c]][f]) v ^= x[f]; x[c] = v; }
    const w = x.reduce((a, b) => a + b, 0); if (!best || w < best.w) best = { x, w };
  }
  return best;
}
const RNG = (seed) => { let x = (Math.abs(seed | 0) * 7919 + 104729) % 2147483647 || 1; return () => (x = (x * 16807) % 2147483647) / 2147483647; };
const loBoard = (s) => { const b = Array(LN * LN).fill(0), r = RNG(s.seed); for (let k = 0; k < 9; k++) press(b, Math.floor(r() * LN * LN)); (s.pressed || []).forEach((i) => press(b, i)); return b; };

// 신의 수: 거리별 상태 수 (2×2는 직접 계산, 3×3은 cube20.org 발표값 — 16~20수는 어림값)
const GOD2 = [1, 9, 54, 321, 1847, 9992, 50136, 227536, 870072, 1887748, 623800, 2644];
const GOD3 = [1, 18, 243, 3240, 43239, 574908, 7618438, 100803036, 1332343288, 17596479795, 232248063316, 3063288809012, 40374425656248, 531653418284628, 6989320578825358, 91365146187124313, 1.1e18, 1.2e19, 2.9e19, 1.5e18, 4.9e8];

export default [
  // ───────── 1. 수순의 주기 ─────────
  {
    id: "cube-period", grade: Z, unit: U5, lesson: LES, title: "수순의 주기 — 같은 수순을 몇 번 반복하면 처음으로 돌아올까", type: "조작", time: "12분",
    tags: ["큐브", "순열", "주기", "최소공배수"], links: ["cube-lab", "cube-commutator"],
    desc: "수순 하나를 계속 반복하면 큐브는 반드시 처음 상태로 돌아옵니다. 반복 횟수를 늘리며 전개도를 보고, 조각들이 만드는 고리의 길이와 방향으로 주기가 최소공배수로 정해지는 까닭을 확인합니다.",
    obs: ["조각들은 서로 겹치지 않는 고리를 따라 자리를 바꿉니다.", "고리 하나가 제자리·제방향으로 오는 횟수를 모두 구하면, 주기는 그 수들의 최소공배수입니다.", "R U는 105번, R U R′ U′는 6번 만에 돌아옵니다."],
    q: "R U를 105번 반복하면 처음 상태가 됩니다. 그런데 그 사이 어느 순간에도 처음 상태가 되지 않는 까닭은 무엇일까요?",
    formula: "주기 = lcm(고리마다 제자리로 오는 횟수)",
    view: { x: [-0.2, 12.2], y: [-9.8, 0.8], pad: 10 },
    params: [
      { key: "seq", label: "반복할 수순", type: "select", options: SEQS.map(([k, v]) => [k, v]), value: "RU" },
      { key: "k", label: "반복 횟수", min: 0, max: (s) => Math.min(orderOf(s.seq) || 1, 1260), step: 1, value: 0 },
    ],
    anim: { key: "k", speed: 6, label: "반복 재생" },
    state(s) { return C.apply(C.solved(), Array.from({ length: s.k }, () => C.parse(seqOf(s.seq))).flat()); },
    draw(s, g) {
      const st = this.state(s), f = C.facelets(st);
      C.drawNet(g, f, 0, 0, 1, C.movedStickers(st));
      g.text([9.5, -7.4], T(`${s.k}번 반복`, `${s.k} repetitions`), { bold: true, size: 18, color: C.isSolved(st) && s.k ? "a" : "ink" });
      g.text([9.5, -8.4], C.isSolved(st) ? (s.k ? T("처음 상태로 돌아왔어요!", "Back to the start!") : T("처음 상태", "Start")) : T(`제자리가 아닌 스티커 ${C.movedStickers(st).size}개`, `${C.movedStickers(st).size} stickers out of place`), { size: 14, color: "muted" });
    },
    metrics(s) {
      const g = C.apply(C.solved(), C.parse(seqOf(s.seq))), cy = C.cycles(g), ord = orderOf(s.seq);
      const show = (arr) => arr.length ? arr.map((c) => (c.twist ? `${c.len}(${T("방향", "twist")}→${c.period})` : c.len)).join(", ") : "—";
      return [[T("수순", "Sequence"), seqOf(s.seq)], [T("꼭짓점 고리", "Corner cycles"), show(cy.corners)], [T("모서리 고리", "Edge cycles"), show(cy.edges)], [T("주기", "Order"), fmt(ord), "key"], [T("지금 반복 횟수", "Repetitions now"), fmt(s.k)]];
    },
    predict: [
      { q: "R U를 반복하면 몇 번 만에 처음 상태로 돌아올까요?", answer: () => 105, why: "꼭짓점과 모서리가 만드는 고리의 주기가 각각 다르고, 모두가 동시에 제자리로 오는 횟수는 그 최소공배수 105입니다." },
      { q: "R U R′ U′를 반복하면 몇 번 만에 처음 상태로 돌아올까요?", set: (s) => Object.assign(s, { seq: "sexy", k: 0 }), answer: () => 6, why: "모서리 3개는 3번에, 꼭짓점 두 쌍은 2번에 제자리로 옵니다. lcm(3, 2) = 6입니다." },
    ],
  },
  // ───────── 2. 교환자 ─────────
  {
    id: "cube-commutator", grade: Z, unit: U5, lesson: LES, title: "교환자 A B A′ B′ — 조금만 바꾸는 수순 만들기", type: "조작", time: "12분",
    tags: ["큐브", "교환자", "비가환"], links: ["cube-period", "cube-lab"],
    desc: "A를 하고 B를 한 뒤 A와 B를 차례로 되돌리는 수순 A B A′ B′를 교환자라고 합니다. A와 B가 겹치는 조각이 적을수록 교환자는 큐브를 조금만 바꿉니다. 큐브를 맞추는 공식 대부분이 이 원리로 만들어졌습니다.",
    obs: ["A와 B가 서로 바꿔도 같으면(교환 가능하면) 교환자는 아무것도 바꾸지 않습니다.", "A와 B가 함께 움직이는 조각이 적을수록 바뀌는 조각도 적습니다.", "R과 U는 겹치는 조각이 5개뿐이라 R U R′ U′는 조각 7개만 움직입니다."],
    q: "R과 L은 서로 닿는 조각이 없습니다. R L R′ L′는 큐브를 어떻게 바꿀까요?",
    formula: "[A, B] = A B A⁻¹ B⁻¹,  AB = BA ⇔ [A, B] = e",
    view: { x: [-0.2, 12.2], y: [-9.8, 0.8], pad: 10 },
    params: [
      { key: "A", label: "A", type: "select", options: [["R", "R"], ["RUR", "R U R′"], ["F", "F"], ["L", "L"], ["R2", "R2"]], value: "R" },
      { key: "B", label: "B", type: "select", options: [["U", "U"], ["U2", "U2"], ["D", "D"], ["L", "L"], ["F", "F"]], value: "U" },
      { key: "show", label: "보기", type: "seg", options: [["comm", "A B A′ B′"], ["ab", "A B만"]], value: "comm" },
    ],
    seqs(s) { const a = C.parse({ R: "R", RUR: "R U R′", F: "F", L: "L", R2: "R2" }[s.A]), b = C.parse(s.B); return s.show === "ab" ? [...a, ...b] : [...a, ...b, ...C.inverse(a), ...C.inverse(b)]; },
    pieces(st) { let c = 0, e = 0; st.cp.forEach((v, i) => { if (v !== i || st.co[i]) c++; }); st.ep.forEach((v, i) => { if (v !== i || st.eo[i]) e++; }); return [c, e]; },
    draw(s, g) {
      const st = C.apply(C.solved(), this.seqs(s)), moved = C.movedStickers(st);
      C.drawNet(g, C.facelets(st), 0, 0, 1, moved);
      const [c, e] = this.pieces(st);
      g.text([9.5, -7.3], C.label(this.seqs(s)), { bold: true, size: 15 });
      g.text([9.5, -8.4], moved.size ? T(`움직인 조각: 꼭짓점 ${c} · 모서리 ${e}`, `Moved: ${c} corners · ${e} edges`) : T("아무것도 바뀌지 않았어요 (교환 가능)", "Nothing changed (they commute)"), { size: 14, color: moved.size ? "muted" : "a" });
    },
    metrics(s) { const st = C.apply(C.solved(), this.seqs(s)), [c, e] = this.pieces(st); return [[T("수순", "Sequence"), C.label(this.seqs(s))], [T("움직인 꼭짓점", "Corners moved"), fmt(c)], [T("움직인 모서리", "Edges moved"), fmt(e)], [T("움직인 조각 합계", "Pieces moved"), fmt(c + e), "key"], [T("이 수순의 주기", "Order"), fmt(C.order(this.seqs(s)))]]; },
    predict: [
      { q: "R U R′ U′는 꼭짓점과 모서리를 합해 조각 몇 개를 움직일까요?", answer: () => 7, why: "꼭짓점 4개와 모서리 3개, 모두 7개입니다. R과 U가 함께 움직이는 조각이 적어서 나머지 13개 조각은 그대로입니다." },
      { q: "R L R′ L′는 조각 몇 개를 움직일까요?", set: (s) => Object.assign(s, { A: "R", B: "L", show: "comm" }), answer: () => 0, why: "R과 L은 닿는 조각이 없어 순서를 바꿔도 같습니다(교환 가능). 그래서 교환자는 아무것도 바꾸지 않습니다." },
    ],
  },
  // ───────── 3. 경우의 수 ─────────
  {
    id: "cube-count", grade: Z, unit: U5, lesson: LES, title: "큐브의 경우의 수 — 4325경 가지를 세는 방법", type: "조작", time: "10분",
    tags: ["큐브", "경우의 수", "곱의 법칙"], links: ["cube-impossible", "cube-gods"],
    desc: "꼭짓점 조각의 자리와 방향, 모서리 조각의 자리와 방향을 곱의 법칙으로 세고, 실제로 돌려서 만들 수 없는 경우를 나누어 큐브가 만들 수 있는 상태의 수를 구합니다.",
    obs: ["꼭짓점 8개를 놓는 방법은 8!, 방향은 마지막 하나가 저절로 정해져 3⁷입니다.", "모서리 12개는 12!과 2¹¹입니다.", "두 순열의 홀짝이 같아야 해서 2로 나눕니다."],
    q: "1초에 큐브를 1조 가지씩 바꿔 본다면, 모든 상태를 한 번씩 보는 데 얼마나 걸릴까요?",
    formula: "8! × 3⁷ × 12! × 2¹¹ ÷ 2 = 43,252,003,274,489,856,000",
    view: { x: [0, 12], y: [-1.5, 8.5] },
    params: [
      { key: "size", label: "큐브", type: "seg", options: [["3", "3×3"], ["2", "2×2"]], value: "3" },
      { key: "cp", label: "꼭짓점 자리 바꾸기", type: "check", value: true },
      { key: "co", label: "꼭짓점 방향", type: "check", value: true },
      { key: "ep", label: "모서리 자리 바꾸기", type: "check", value: true },
      { key: "eo", label: "모서리 방향", type: "check", value: true },
      { key: "par", label: "만들 수 없는 경우 빼기", type: "check", value: true },
    ],
    factors(s) {
      const f = s.size === "2"
        ? [["cp", T("꼭짓점 자리 7!", "Corner places 7!"), 5040, "7!"], ["co", T("꼭짓점 방향 3⁶", "Corner twists 3⁶"), 729, "3⁶"]]
        : [["cp", T("꼭짓점 자리 8!", "Corner places 8!"), 40320, "8!"], ["co", T("꼭짓점 방향 3⁷", "Corner twists 3⁷"), 2187, "3⁷"], ["ep", T("모서리 자리 12!", "Edge places 12!"), 479001600, "12!"], ["eo", T("모서리 방향 2¹¹", "Edge flips 2¹¹"), 2048, "2¹¹"], ["par", T("홀짝 맞추기 ÷2", "Parity ÷2"), 0.5, "÷2"]];
      return f.filter(([k]) => s[k] !== false);
    },
    // 정확한 값은 BigInt로 (20자리 수는 보통 숫자로는 끝자리가 틀어진다)
    total(s) { let t = 1n, half = false; for (const [, , v] of this.factors(s)) { if (v < 1) half = true; else t *= BigInt(v); } return half ? t / 2n : t; },
    draw(s, g) {
      const fs = this.factors(s); let y = 7.6;
      g.text([6, 8.1], T("곱의 법칙으로 세기", "Counting with the product rule"), { bold: true, size: 16 });
      fs.forEach(([, lab, v], i) => { const w = Math.max(0.15, Math.log10(Math.max(v, 1)) * 1.1); rect(g, 0.4, y - 0.15, w, 0.7, { fill: ["a", "b", "c", "d", "e"][i % 5], fo: 0.7, stroke: false }); g.text([0.6 + w, y - 0.5], `${lab} = ${v < 1 ? "÷2" : big(v)}`, { anchor: "start", size: 13 }); y -= 1.1; });
      const t = this.total(s), digits = t.toString().length, tn = Number(t);
      g.text([6, 1.2], big(t), { bold: true, size: 20, color: "a" });
      g.text([6, 0.2], T(`${digits}자리 수 · 1초에 1조 가지씩 보면 약 ${fmt(tn / 1e12 / 3.15576e7, 2)}년`, `${digits} digits · about ${fmt(tn / 1e12 / 3.15576e7, 2)} years at a trillion per second`), { size: 13, color: "muted" });
    },
    metrics(s) { const t = this.total(s); return [[T("곱한 것", "Factors"), this.factors(s).map((x) => x[3]).join(" × ") || "1"], [T("상태의 수", "States"), big(t), "key"], [T("자릿수", "Digits"), fmt(t.toString().length)]]; },
    predict: [
      { q: "2×2 큐브가 만들 수 있는 상태는 모두 몇 가지일까요?", set: (s) => Object.assign(s, { size: "2" }), answer: () => 3674160, why: "한 꼭짓점을 고정하면 7! × 3⁶ = 5040 × 729 = 3,674,160입니다." },
      { q: "3×3 큐브의 상태 수는 몇 자리 수일까요?", answer: () => 20, why: "43,252,003,274,489,856,000은 20자리 수입니다." },
    ],
  },
  // ───────── 4. 불가능한 큐브 ─────────
  {
    id: "cube-impossible", grade: Z, unit: U5, lesson: LES, title: "불가능한 큐브 — 조각을 뜯어 다시 끼우면 맞출 수 있을까", type: "조작", time: "12분",
    tags: ["큐브", "불변량", "홀짝", "나머지"], links: ["cube-count", "puz-fifteen"],
    desc: "큐브를 아무리 돌려도 변하지 않는 세 가지 값(꼭짓점 방향의 합, 모서리 방향의 합, 두 순열의 홀짝)을 관찰합니다. 조각을 하나 뒤집거나 비틀어 다시 끼우면 이 값이 바뀌어, 어떤 수순으로도 맞출 수 없는 큐브가 됩니다.",
    obs: ["돌리기만 하면 꼭짓점 방향의 합은 3의 배수, 모서리 방향의 합은 짝수로 유지됩니다.", "꼭짓점 순열과 모서리 순열의 홀짝은 늘 같습니다.", "뜯어서 아무렇게나 끼우면 12번 중 1번만 맞출 수 있는 큐브가 됩니다."],
    q: "큐브를 바닥에 떨어뜨려 조각이 빠졌습니다. 아무렇게나 다시 끼우면 맞출 수 있을 확률은 얼마일까요?",
    formula: "Σ꼭짓점 방향 ≡ 0 (mod 3),  Σ모서리 방향 ≡ 0 (mod 2),  sgn(꼭짓점) = sgn(모서리)",
    view: { x: [-0.2, 12.2], y: [-9.8, 0.8], pad: 10 },
    params: [{ key: "seed", label: "섞은 정도", min: 0, max: 30, step: 1, value: 6 }],
    init: () => ({ flip: 0, twist: 0, swap: 0 }),
    buttons: [["flip", "모서리 하나 뒤집기"], ["twist", "꼭짓점 하나 비틀기"], ["swap", "모서리 두 개 바꾸기"], ["fix", "원래대로 끼우기"]],
    onDo(a, s) { if (a === "flip") s.flip = (s.flip + 1) % 2; if (a === "twist") s.twist = (s.twist + 1) % 3; if (a === "swap") s.swap = (s.swap + 1) % 2; if (a === "fix") { s.flip = 0; s.twist = 0; s.swap = 0; } },
    state(s) {
      const r = RNG(97 + s.seed), faces = "URFDLB", mv = Array.from({ length: s.seed }, () => [faces[Math.floor(r() * 6)], 1 + Math.floor(r() * 3)]);
      const st = C.apply(C.solved(), mv);
      if (s.flip) st.eo[0] ^= 1;
      if (s.twist) st.co[0] = (st.co[0] + s.twist) % 3;
      if (s.swap) [st.ep[1], st.ep[2]] = [st.ep[2], st.ep[1]];
      return st;
    },
    draw(s, g) {
      const st = this.state(s), ok = C.solvable(st);
      C.drawNet(g, C.facelets(st), 0, 0, 1, null);
      g.text([9.5, -7.3], ok ? T("맞출 수 있는 큐브", "Solvable") : T("어떤 수순으로도 맞출 수 없음", "Unsolvable by any sequence"), { bold: true, size: 16, color: ok ? "a" : "d" });
    },
    metrics(s) {
      const v = C.invariants(this.state(s));
      return [[T("꼭짓점 방향의 합 (mod 3)", "Corner twist sum (mod 3)"), `${v.twist} ${v.twist ? "✗" : "✓"}`], [T("모서리 방향의 합 (mod 2)", "Edge flip sum (mod 2)"), `${v.flip} ${v.flip ? "✗" : "✓"}`], [T("꼭짓점 · 모서리 순열의 홀짝", "Corner · edge permutation parity"), `${v.cpar ? T("홀", "odd") : T("짝", "even")} · ${v.epar ? T("홀", "odd") : T("짝", "even")} ${v.cpar === v.epar ? "✓" : "✗"}`], [T("판정", "Verdict"), C.solvable(this.state(s)) ? T("맞출 수 있음", "Solvable") : T("맞출 수 없음", "Unsolvable"), "key"]];
    },
    predict: [
      { q: "조각을 모두 빼서 아무렇게나 다시 끼우면 맞출 수 있는 큐브일 확률은?", options: [["a", "1/2"], ["b", "1/6"], ["c", "1/12"], ["d", "1/24"]], answer: () => "c", why: "꼭짓점 방향(3가지) × 모서리 방향(2가지) × 홀짝(2가지) = 12가지 묶음 중 하나만 맞출 수 있습니다." },
    ],
  },
  // ───────── 5. 신의 수 ─────────
  {
    id: "cube-gods", grade: Z, unit: U5, lesson: LES, title: "신의 수 — 어떤 상태든 몇 수 안에 맞출 수 있을까", type: "데이터", time: "10분",
    tags: ["큐브", "최단 경로", "분포", "컴퓨터 증명"], links: ["cube-count", "cube-lab"],
    desc: "모든 상태를 가장 짧게 맞추는 수를 거리별로 세면, 가장 먼 상태까지의 거리가 ‘신의 수’입니다. 2×2는 11수, 3×3은 20수입니다(180° 회전도 1수로 셈). 거리별 상태 수의 분포를 비교합니다.",
    obs: ["2×2의 3,674,160가지 상태는 이 사이트에서 직접 계산한 값입니다.", "3×3은 2010년 연구진이 구글 컴퓨터로 확인했습니다. 16수 이상은 어림값입니다.", "대부분의 상태는 가장 먼 거리보다 조금 가까운 곳에 몰려 있습니다."],
    q: "3×3 큐브 상태의 절반 이상은 몇 수 안에 맞출 수 있을까요?",
    formula: "2×2: 최대 11수,  3×3: 최대 20수 (반 바퀴 돌리기도 1수)",
    view: { x: [-1.5, 22], y: [-1.6, 10.5] },
    params: [
      { key: "size", label: "큐브", type: "seg", options: [["2", "2×2"], ["3", "3×3"]], value: "2" },
      { key: "d", label: "거리 (몇 수)", min: 0, max: (s) => (s.size === "2" ? 11 : 20), step: 1, value: 8 },
      { key: "logy", label: "로그 눈금으로 보기", type: "check", value: false },
    ],
    data(s) { return s.size === "2" ? GOD2 : GOD3; },
    draw(s, g) {
      const D = this.data(s), max = Math.max(...D), w = 20 / D.length;
      D.forEach((v, i) => { const h = s.logy ? (Math.log10(v + 1) / Math.log10(max + 1)) * 9 : (v / max) * 9; rect(g, i * w + 0.1, h, w * 0.8, h, { fill: i <= s.d ? "a" : "b", fo: i === s.d ? 0.95 : 0.5, stroke: false }); g.text([i * w + w / 2, -0.4], String(i), { size: 11, color: "muted" }); });
      g.text([10, 10], T(`거리 ${s.d}수 이하: 전체의 ${fmt(this.cum(s) * 100, 2)}%`, `Within ${s.d} moves: ${fmt(this.cum(s) * 100, 2)}% of all states`), { bold: true, size: 15 });
    },
    cum(s) { const D = this.data(s), t = D.reduce((a, b) => a + b, 0); return D.slice(0, s.d + 1).reduce((a, b) => a + b, 0) / t; },
    metrics(s) { const D = this.data(s); return [[T("이 거리의 상태 수", "States at this distance"), (s.size === "3" && s.d >= 16 ? "≈ " : "") + big(D[s.d])], [T("누적 비율", "Cumulative share"), fmt(this.cum(s) * 100, 3) + "%", "key"], [T("신의 수", "God's number"), s.size === "2" ? "11" : "20"]]; },
    predict: [
      { q: "3×3 큐브의 신의 수(어떤 상태든 이 수 안에 맞출 수 있는 가장 작은 수)는?", set: (s) => Object.assign(s, { size: "3", d: 20 }), answer: () => 20, why: "2010년 로키키, 코시엠바, 데이비드슨, 덱스리지가 모든 상태가 20수 이내임을 컴퓨터로 증명했습니다." },
      { q: "2×2 큐브의 신의 수는?", set: (s) => Object.assign(s, { size: "2", d: 11 }), answer: () => 11, why: "3,674,160가지를 모두 조사하면 가장 먼 상태는 11수 거리에 있는 2,644가지입니다." },
    ],
  },
  // ───────── 6. 정육면체 회전 24가지 ─────────
  {
    id: "cube-rotations", grade: Z, unit: U5, lesson: LES, title: "정육면체를 돌리는 24가지 방법 — 회전군", type: "3D", time: "10분",
    tags: ["정육면체", "회전", "대칭", "군"], links: ["cube-coloring", "cube-nets"],
    desc: "정육면체를 돌려 처음과 같은 자리에 놓는 방법을 축의 종류로 나누어 셉니다. 면을 지나는 축, 꼭짓점을 지나는 축, 모서리의 가운데를 지나는 축으로 나누면 1 + 9 + 8 + 6 = 24가지입니다.",
    obs: ["바닥에 올 면 6가지 × 앞에 올 면 4가지 = 24가지로도 셀 수 있습니다.", "면 축 3개 × (90°, 180°, 270°) = 9가지입니다.", "꼭짓점 축 4개 × (120°, 240°) = 8가지, 모서리 축 6개 × 180° = 6가지입니다."],
    q: "정사면체를 돌리는 방법은 몇 가지일까요?",
    formula: "1 + 3×3 + 4×2 + 6×1 = 24 = 6 × 4",
    space: true, cam: { yaw: 35, pitch: 24, scale: 70 },
    params: [
      { key: "i", label: "회전 번호 (1~24)", min: 1, max: 24, step: 1, value: 2 },
      { key: "t", label: "돌린 정도", min: 0, max: 1, step: 0.01, value: 1 },
    ],
    anim: { key: "t", min: 0, max: 1, speed: 0.45, loop: "wrap", label: "돌려 보기" },
    draw(s, g) {
      const [kind, axis, ang] = ROTS[s.i - 1], th = deg(ang) * s.t;
      if (kind !== "id") { const a = mul(norm(axis), 2.1); g.seg(mul(a, -1), a, { color: "d", w: 2.2, dash: "6 5" }); g.point(a, "", { color: "d", r: 4 }); }
      for (const f of CFACES) { const pts = f.v.map((v) => rot(v, axis, th)), n = rot(f.n, axis, th); g.face(pts, { fill: f.c, fo: 0.92, color: "#2b3440", w: 1.4 }); g.text(mul(n, 1.02), f.name, { bold: true, size: 15 }); }
      g.note(16, 26, (kind === "id" ? "" : T(`${ang}° 돌리기 · `, `Turn ${ang}° · `)) + T(KIND[kind][0], KIND[kind][1]), { bold: true });
    },
    metrics(s) { const kind = ROTS[s.i - 1][0], n = ROTS.filter((r) => r[0] === kind).length; return [[T("회전 종류", "Type"), T(KIND[kind][0], KIND[kind][1])], [T("같은 종류의 회전 수", "Rotations of this type"), fmt(n)], [T("모두", "Total"), "1 + 9 + 8 + 6 = 24", "key"]]; },
    predict: [
      { q: "꼭짓점과 그 반대 꼭짓점을 지나는 축으로 돌리는 방법(항등 제외)은 몇 가지일까요?", set: (s) => Object.assign(s, { i: 14 }), answer: () => 8, why: "그런 축은 4개이고, 축마다 120°와 240° 두 가지라 8가지입니다." },
      { q: "정사면체를 돌려 제자리에 놓는 방법은 모두 몇 가지일까요?", answer: () => 12, why: "바닥에 올 면 4가지 × 그 면을 돌리는 방법 3가지 = 12가지입니다." },
    ],
  },
  // ───────── 7. 색칠 30가지 ─────────
  {
    id: "cube-coloring", grade: Z, unit: U5, lesson: LES, title: "정육면체 색칠하기 — 돌려서 같은 것은 하나로 (번사이드)", type: "조작", time: "12분",
    tags: ["정육면체", "경우의 수", "대칭", "번사이드"], links: ["cube-rotations", "cube-count"],
    desc: "정육면체의 여섯 면을 칠할 때 돌려서 같아지는 것을 하나로 세려면, 24가지 회전마다 그 회전으로 바뀌지 않는 색칠의 수를 세어 평균을 냅니다(번사이드 보조정리). 서로 다른 6색을 모두 쓰면 6! ÷ 24 = 30가지입니다.",
    obs: ["항등 회전은 모든 색칠을 그대로 둡니다: k⁶.", "면 축 90° 회전은 옆면 4개가 같은 색이어야 합니다: k³.", "평균을 내면 (k⁶ + 3k⁴ + 12k³ + 8k²) ÷ 24 가지입니다."],
    q: "두 가지 색으로만 정육면체를 칠하면 돌려서 다른 색칠은 몇 가지일까요?",
    formula: "N = (1/24)·Σ fix(g) = (k⁶ + 3k⁴ + 12k³ + 8k²) / 24",
    view: { x: [0, 12], y: [-1, 8.6] },
    params: [
      { key: "mode", label: "색칠 규칙", type: "seg", options: [["any", "k가지 색 자유롭게"], ["all6", "서로 다른 6색 모두"]], value: "any" },
      { key: "k", label: "색의 수 k", min: 1, max: 8, step: 1, value: 2 },
    ],
    rows(s) {
      const k = s.k, fall = (n) => { let p = 1; for (let i = 0; i < 6; i++) p *= n - i; return Math.max(0, p); };
      return s.mode === "all6"
        ? [[T("항등", "Identity"), 1, fall(k)], [T("면 축 90°·270°", "Face 90°/270°"), 6, 0], [T("면 축 180°", "Face 180°"), 3, 0], [T("꼭짓점 축 120°·240°", "Vertex 120°/240°"), 8, 0], [T("모서리 축 180°", "Edge 180°"), 6, 0]]
        : [[T("항등", "Identity"), 1, k ** 6], [T("면 축 90°·270°", "Face 90°/270°"), 6, k ** 3], [T("면 축 180°", "Face 180°"), 3, k ** 4], [T("꼭짓점 축 120°·240°", "Vertex 120°/240°"), 8, k ** 2], [T("모서리 축 180°", "Edge 180°"), 6, k ** 3]];
    },
    count(s) { return this.rows(s).reduce((t, [, n, f]) => t + n * f, 0) / 24; },
    draw(s, g) {
      const R = this.rows(s); let y = 7.8;
      g.text([0.3, 8.3], T("회전 종류", "Rotation type"), { anchor: "start", bold: true, size: 13 }); g.text([6.6, 8.3], T("개수", "Count"), { bold: true, size: 13 }); g.text([9.6, 8.3], T("안 바뀌는 색칠", "Colorings fixed"), { bold: true, size: 13 });
      R.forEach(([nm, n, f]) => { y -= 1.1; rect(g, 0.2, y + 0.45, 11.6, 0.9, { fill: "b", fo: 0.06, stroke: false }); g.text([0.4, y - 0.1], nm, { anchor: "start", size: 13 }); g.text([6.6, y - 0.1], `×${n}`, { size: 13 }); g.text([9.6, y - 0.1], big(f), { size: 13, bold: true }); });
      g.text([6, 0.6], T(`합 ${big(R.reduce((t, [, n, f]) => t + n * f, 0))} ÷ 24 = ${big(this.count(s))}가지`, `Sum ${big(R.reduce((t, [, n, f]) => t + n * f, 0))} ÷ 24 = ${big(this.count(s))}`), { bold: true, size: 17, color: "a" });
    },
    metrics(s) { return [[T("색의 수", "Colors"), fmt(s.k)], [T("돌려서 다른 색칠", "Distinct colorings"), big(this.count(s)), "key"], [T("돌리는 방법", "Rotations"), "24"]]; },
    predict: [
      { q: "서로 다른 6가지 색을 한 면에 하나씩 모두 쓰면, 돌려서 다른 색칠은 몇 가지일까요?", set: (s) => Object.assign(s, { mode: "all6", k: 6 }), answer: () => 30, why: "6! = 720가지 색칠은 항등 회전만이 그대로 두므로 720 ÷ 24 = 30가지입니다." },
      { q: "두 가지 색으로 자유롭게 칠하면 돌려서 다른 색칠은 몇 가지일까요?", set: (s) => Object.assign(s, { mode: "any", k: 2 }), answer: () => 10, why: "(64 + 3·16 + 12·8 + 8·4) ÷ 24 = 240 ÷ 24 = 10가지입니다." },
    ],
  },
  // ───────── 8. 헥소미노와 전개도 ─────────
  {
    id: "cube-nets", grade: Z, unit: U5, lesson: LES, title: "헥소미노 35가지 중 정육면체 전개도는 11가지", type: "조작", time: "10분",
    tags: ["전개도", "헥소미노", "정육면체"], links: ["m1-cube-nets", "plus-net"],
    desc: "정사각형 6개를 변끼리 이어 붙인 모양(헥소미노)은 돌리거나 뒤집어 같은 것을 하나로 세면 35가지입니다. 각 모양을 바닥에서 굴려 보며 여섯 면이 모두 다른지 확인하면 정육면체 전개도는 11가지뿐입니다.",
    obs: ["같은 색은 접었을 때 서로 마주 보는 두 면입니다.", "전개도가 아닌 모양은 두 칸이 같은 면에 겹칩니다(빨간 테두리).", "한 줄에 정사각형이 5개 이상 이어지면 전개도가 될 수 없습니다."],
    q: "4칸이 한 줄로 이어진 헥소미노는 모두 전개도가 될까요?",
    formula: "헥소미노 35가지 = 전개도 11가지 + 전개도가 아닌 것 24가지",
    view: { x: [-0.5, 8.5], y: [-0.5, 6.5] },
    params: [
      { key: "filter", label: "보기", type: "seg", options: [["all", "35가지 모두"], ["yes", "전개도 11"], ["no", "아닌 것 24"]], value: "all" },
      { key: "i", label: "번호", min: 1, max: (s) => HEX.filter((h) => (s.filter === "yes" ? h.ok : s.filter === "no" ? !h.ok : true)).length, step: 1, value: 1 },
    ],
    list(s) { return HEX.filter((h) => (s.filter === "yes" ? h.ok : s.filter === "no" ? !h.ok : true)); },
    derive(s) { const n = this.list(s).length; if (s.i > n) s.i = n; },
    draw(s, g) {
      const L = this.list(s), h = L[Math.min(s.i, L.length) - 1]; if (!h) return;
      const mx = Math.max(...h.cells.map((c) => c[0])), my = Math.max(...h.cells.map((c) => c[1])), ox = (8 - mx - 1) / 2, oy = (6 - my - 1) / 2;
      const pair = { 1: "a", "-1": "a", 2: "b", "-2": "b", 3: "e", "-3": "e" }, dup = new Set(h.faces.filter((f, i) => h.faces.indexOf(f) !== i));
      h.cells.forEach(([x, y], k) => { const f = h.faces[k], bad = !h.ok && dup.has(f); g.poly([[ox + x, oy + y], [ox + x + 1, oy + y], [ox + x + 1, oy + y + 1], [ox + x, oy + y + 1]], { fill: h.ok ? pair[f] : "muted", fo: h.ok ? 0.55 : 0.2, color: bad ? "d" : "ink", w: bad ? 3.6 : 1.8 }); });
      g.note(16, 26, h.ok ? T("정육면체 전개도 ✓ (같은 색끼리 마주 봄)", "Cube net ✓ (same colours face each other)") : T("전개도가 아님 — 빨간 칸끼리 겹침", "Not a net — red squares overlap"), { bold: true, color: h.ok ? "a" : "d" });
    },
    metrics(s) { const L = this.list(s), h = L[Math.min(s.i, L.length) - 1]; return [[T("이 모양", "This shape"), h?.ok ? T("전개도", "Net") : T("전개도 아님", "Not a net"), "key"], [T("헥소미노", "Hexominoes"), String(HEX.length)], [T("정육면체 전개도", "Cube nets"), String(HEX.filter((x) => x.ok).length)]]; },
    predict: [{ q: "정사각형 6개로 만든 헥소미노 35가지 가운데 정육면체 전개도는 몇 가지일까요?", answer: () => 11, why: "모두 굴려 보면 여섯 면이 다른 것은 11가지뿐입니다." }],
  },
  // ───────── 9. 라이츠 아웃 ─────────
  {
    id: "puz-lights-out", grade: Z, unit: U5, lesson: LES, title: "라이츠 아웃 — 누르는 순서는 상관없다", type: "조작", time: "12분",
    tags: ["퍼즐", "일차방정식", "나머지 2", "교환법칙"], links: ["cube-commutator", "puz-binary-cards"],
    desc: "칸을 누르면 그 칸과 위아래·좌우 칸의 불이 바뀝니다. 같은 칸을 두 번 누르면 원래대로이고 누르는 순서는 결과와 상관없으므로, 어느 칸을 누를지(0 또는 1)만 정하면 됩니다. 25개의 일차방정식을 2로 나눈 나머지로 풀어 가장 적게 누르는 풀이를 찾습니다.",
    obs: ["누르기는 서로 교환 가능하고, 두 번 누르면 없던 일이 됩니다.", "5×5 판에서 만들 수 있는 2²⁵가지 불빛 중 4분의 1만 풀 수 있습니다.", "풀 수 있는 판에는 풀이가 4가지씩 있습니다."],
    q: "불이 하나만 켜진 판은 언제나 풀 수 있을까요?",
    formula: "A x ≡ b (mod 2),  rank A = 23",
    view: { x: [-0.3, 5.3], y: [-1.2, 5.3] },
    params: [{ key: "seed", label: "문제 번호", min: 1, max: 99, step: 1, value: 3 }, { key: "hint", label: "풀이 보기", type: "check", value: false }],
    init: () => ({ pressed: [] }),
    buttons: [["new", "새 문제"], ["undo", "한 번 되돌리기"], ["reset", "처음 판으로"]],
    onDo(a, s) { if (a === "new") { s.seed = (s.seed % 99) + 1; s.pressed = []; } if (a === "undo") s.pressed = (s.pressed || []).slice(0, -1); if (a === "reset") s.pressed = []; },
    onChange(s, k) { if (k === "seed") s.pressed = []; },
    tap(s, p) { const c = Math.floor(p[0]), r = 4 - Math.floor(p[1]); if (c < 0 || c >= LN || r < 0 || r >= LN) return false; s.pressed = [...(s.pressed || []), r * LN + c]; },
    draw(s, g) {
      const b = loBoard(s), sol = s.hint ? solveLO(b) : null, on = b.reduce((a, v) => a + v, 0);
      for (let i = 0; i < LN * LN; i++) { const r = Math.floor(i / LN), c = i % LN, x = c, y = 4 - r; g.poly([[x + 0.06, y + 0.06], [x + 0.94, y + 0.06], [x + 0.94, y + 0.94], [x + 0.06, y + 0.94]], { fill: b[i] ? "#f2cc3a" : "#2b3440", fo: b[i] ? 0.95 : 0.85, color: sol && sol.x[i] ? "d" : "#13294b", w: sol && sol.x[i] ? 4 : 1.2 }); if (sol && sol.x[i]) g.text([x + 0.5, y + 0.5], "●", { color: "d", size: 16, dy: 6 }); }
      g.text([2.5, -0.65], on ? T(`켜진 불 ${on}개 · 칸을 눌러 모두 끄세요`, `${on} lights on · tap cells to turn them all off`) : T("모두 껐어요! 🎉", "All off! 🎉"), { bold: true, size: 15, color: on ? "ink" : "a" });
    },
    metrics(s) { const b = loBoard(s), sol = solveLO(b); return [[T("켜진 불", "Lights on"), fmt(b.reduce((a, v) => a + v, 0))], [T("누른 횟수", "Presses"), fmt((s.pressed || []).length)], [T("남은 최소 누르기", "Fewest presses left"), sol ? fmt(sol.w) : T("풀 수 없음", "Unsolvable"), "key"]]; },
    predict: [
      { q: "같은 칸을 두 번 누르면 판은 어떻게 될까요?", options: [["a", "처음과 같다"], ["b", "옆 칸만 바뀐다"], ["c", "모든 불이 바뀐다"]], answer: () => "a", why: "누를 때마다 같은 칸들이 켜짐↔꺼짐으로 바뀌므로 두 번 누르면 원래대로입니다." },
      { q: "5×5 판의 2²⁵가지 불빛 중 풀 수 있는 것의 비율은?", options: [["a", "1"], ["b", "1/2"], ["c", "1/4"], ["d", "1/8"]], answer: () => "c", why: "25개 칸 누르기 중 서로 독립인 것이 23개뿐이라(계수 23) 2²³가지, 즉 4분의 1만 풀 수 있습니다." },
    ],
  },
  // ───────── 10. 피라밍크스 ─────────
  {
    id: "puz-pyraminx", grade: Z, unit: U5, lesson: LES, title: "피라밍크스 — 정사면체 퍼즐의 경우의 수", type: "3D", time: "10분",
    tags: ["퍼즐", "정사면체", "경우의 수", "홀짝"], links: ["cube-count", "cube-rotations"],
    desc: "정사면체 모양 퍼즐 피라밍크스는 모서리 조각 6개, 가운데 축 조각 4개, 꼭지 4개로 이루어집니다. 곱의 법칙으로 자리와 방향을 세고, 돌려서 만들 수 없는 경우를 나누어 상태의 수를 구합니다.",
    obs: ["모서리 6개의 자리는 6! 중 짝순열만 되어 6!/2 = 360가지입니다.", "모서리 방향은 마지막 하나가 정해져 2⁵, 축 조각과 꼭지는 각각 3⁴입니다.", "꼭지는 혼자 돌릴 수 있어 쉽게 맞추므로 빼고 말하기도 합니다."],
    q: "꼭지를 빼면 피라밍크스의 상태는 몇 가지일까요?",
    formula: "(6!/2) × 2⁵ × 3⁴ × 3⁴ = 75,582,720",
    space: true, cam: { yaw: 30, pitch: 18, scale: 74 },
    params: [{ key: "tips", label: "꼭지 4개도 세기", type: "check", value: true }, { key: "spin", label: "돌려 보기", min: 0, max: 360, step: 1, value: 20, unit: "°" }],
    anim: { key: "spin", min: 0, max: 360, speed: 40, loop: "wrap", label: "천천히 돌리기" },
    draw(s, g) {
      const V = [[0, 0, 1.9], [1.6, 0, -0.65], [-0.8, 1.39, -0.65], [-0.8, -1.39, -0.65]].map((v) => rot(v, [0, 0, 1], deg(s.spin)));
      const F = [[0, 1, 2, "#f2cc3a"], [0, 2, 3, "#2e9e5b"], [0, 3, 1, "#2f6fd6"], [1, 3, 2, "#d8433f"]];
      for (const [a, b, c, col] of F) {
        const P = (u, v) => add(V[a], add(mul(sub(V[b], V[a]), u / 3), mul(sub(V[c], V[a]), v / 3)));
        for (let u = 0; u < 3; u++) for (let v = 0; v < 3 - u; v++) { g.face([P(u, v), P(u + 1, v), P(u, v + 1)], { fill: col, fo: 0.9, color: "#1d242c", w: 1.2 }); if (u + v < 2) g.face([P(u + 1, v), P(u + 1, v + 1), P(u, v + 1)], { fill: col, fo: 0.9, color: "#1d242c", w: 1.2 }); }
      }
    },
    total(s) { return 360 * 32 * 81 * (s.tips ? 81 : 1); },
    metrics(s) { return [[T("모서리 자리 6!/2", "Edge places 6!/2"), "360"], [T("모서리 방향 2⁵", "Edge flips 2⁵"), "32"], [T("축 조각 3⁴", "Axial pieces 3⁴"), "81"], [T("꼭지 3⁴", "Tips 3⁴"), s.tips ? "81" : "—"], [T("상태의 수", "States"), big(this.total(s)), "key"]]; },
    predict: [{ q: "꼭지 4개를 빼고 세면 피라밍크스의 상태는 몇 가지일까요?", set: (s) => Object.assign(s, { tips: false }), answer: () => 933120, why: "360 × 32 × 81 = 933,120가지입니다. 꼭지까지 세면 81배인 75,582,720가지입니다." }],
  },
];
// 검산용: 라이츠 아웃 풀이 함수
export const _lightsOut = { solveLO, loBoard, press };
