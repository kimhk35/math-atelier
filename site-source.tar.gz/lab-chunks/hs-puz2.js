// 특별관 3 — 퍼즐과 게임 (도형·전략) 13개
import { fmt, frac, clamp } from "./hs-core.js";

const Z = 17;
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const RNG = (seed) => { let x = (Math.abs(seed | 0) * 7919 + 104729) % 2147483647 || 1; return () => (x = (x * 16807) % 2147483647) / 2147483647; };
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
const SEED = { buttons: [["seed", "다시 섞기"]], onDo(a, s) { if (a === "seed") s.seed = (s.seed % 97) + 1; } };
const memo = (fn) => { let k = null, v = null; return (...a) => { const kk = JSON.stringify(a); if (kk !== k) { k = kk; v = fn(...a); } return v; }; };

const TAN = [["큰 삼각형 1", [[0, 0], [4, 0], [2, 2]], 1 / 4, "a"], ["큰 삼각형 2", [[0, 0], [2, 2], [0, 4]], 1 / 4, "b"], ["중간 삼각형", [[4, 4], [2, 4], [4, 2]], 1 / 8, "c"], ["작은 삼각형 1", [[4, 0], [4, 2], [3, 1]], 1 / 16, "d"], ["작은 삼각형 2", [[2, 2], [3, 3], [1, 3]], 1 / 16, "e"], ["정사각형", [[2, 2], [3, 1], [4, 2], [3, 3]], 1 / 8, "f"], ["평행사변형", [[0, 4], [1, 3], [3, 3], [2, 4]], 1 / 8, "muted"]];
const knight = memo((n, sr, sc) => { const M = [[1, 2], [2, 1], [2, -1], [1, -2], [-1, -2], [-2, -1], [-2, 1], [-1, 2]], V = Array.from({ length: n }, () => Array(n).fill(0)), path = [[sr, sc]]; V[sr][sc] = 1; const deg = (r, c) => M.filter(([a, b]) => { const x = r + a, y = c + b; return x >= 0 && y >= 0 && x < n && y < n && !V[x][y]; }).length; let [r, c] = [sr, sc]; for (let k = 2; k <= n * n; k++) { let best = null, bd = 9; for (const [a, b] of M) { const x = r + a, y = c + b; if (x >= 0 && y >= 0 && x < n && y < n && !V[x][y]) { const d = deg(x, y); if (d < bd) { bd = d; best = [x, y]; } } } if (!best) break; [r, c] = best; V[r][c] = k; path.push(best); } return path; });
const queens = memo((n) => { const S = [], q = []; const ok = (r, c) => q.every((cc, rr) => cc !== c && Math.abs(cc - c) !== r - rr); const go = (r) => { if (r === n) { S.push(q.slice()); return; } for (let c = 0; c < n; c++) if (ok(r, c)) { q.push(c); go(r + 1); q.pop(); } }; go(0); return S; });
const fifteen = memo((mode, seed) => { let T = Array.from({ length: 15 }, (_, i) => i + 1).concat([0]); if (mode === "loyd") { T[13] = 15; T[14] = 14; } else { const r = RNG(seed); for (let i = 15; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [T[i], T[j]] = [T[j], T[i]]; } } const A = T.filter((v) => v), inv = A.reduce((s, v, i) => s + A.slice(i + 1).filter((w) => w < v).length, 0), blankRowFromBottom = 4 - Math.floor(T.indexOf(0) / 4); return { T, inv, solv: (inv + blankRowFromBottom) % 2 === 1 }; });
const MAPPTS = [[0.8, 0.9], [2.6, 0.6], [4.6, 1.0], [6.6, 0.7], [1.4, 2.6], [3.5, 2.3], [5.6, 2.6], [7.2, 2.4], [0.7, 4.3], [2.6, 4.0], [4.4, 4.5], [6.4, 4.2]];
const mapData = memo(() => { const N = 64, M = 40, W = 8, H = 5, cell = Array.from({ length: M }, (_, j) => Array.from({ length: N }, (_, i) => { const x = ((i + 0.5) * W) / N, y = ((j + 0.5) * H) / M; let b = 0, d = 1e9; MAPPTS.forEach((p, k) => { const e = (p[0] - x) ** 2 + (p[1] - y) ** 2; if (e < d) { d = e; b = k; } }); return b; })), adj = MAPPTS.map(() => new Set()); for (let j = 0; j < M; j++) for (let i = 0; i < N; i++) { const a = cell[j][i]; if (i + 1 < N && cell[j][i + 1] !== a) { adj[a].add(cell[j][i + 1]); adj[cell[j][i + 1]].add(a); } if (j + 1 < M && cell[j + 1][i] !== a) { adj[a].add(cell[j + 1][i]); adj[cell[j + 1][i]].add(a); } } return { cell, adj, N, M, W, H }; });
const colorMap = memo((k) => { const { adj } = mapData(), n = MAPPTS.length, C = Array(n).fill(-1); const go = (v) => { if (v === n) return true; for (let c = 0; c < k; c++) if ([...adj[v]].every((u) => C[u] !== c)) { C[v] = c; if (go(v + 1)) return true; C[v] = -1; } return false; }; return go(0) ? C : null; });
const cities = memo((n, seed) => { const r = RNG(seed); return Array.from({ length: n }, () => [0.6 + r() * 8.8, 0.4 + r() * 5.4]); });
const tourLen = (P, t) => t.reduce((s, v, i) => s + Math.hypot(P[v][0] - P[t[(i + 1) % t.length]][0], P[v][1] - P[t[(i + 1) % t.length]][1]), 0);
const tspBest = memo((n, seed) => { const P = cities(n, seed), rest = Array.from({ length: n - 1 }, (_, i) => i + 1); let best = null, bl = 1e9; const go = (cur, left) => { if (!left.length) { const t = [0, ...cur], L = tourLen(P, t); if (L < bl) { bl = L; best = t; } return; } left.forEach((v, i) => go([...cur, v], left.filter((_, j) => j !== i))); }; go([], rest); return { best, bl }; });
const tspNN = memo((n, seed) => { const P = cities(n, seed), t = [0], used = new Set([0]); while (t.length < n) { const a = t.at(-1); let b = -1, d = 1e9; P.forEach((p, i) => { if (!used.has(i)) { const e = Math.hypot(p[0] - P[a][0], p[1] - P[a][1]); if (e < d) { d = e; b = i; } } }); t.push(b); used.add(b); } return { t, L: tourLen(P, t) }; });
const PHI = (1 + Math.sqrt(5)) / 2;
const wythoffP = (a, b) => { const [x, y] = [Math.min(a, b), Math.max(a, b)]; const k = y - x; return Math.floor(k * PHI) === x; };
const secretaryP = (n, r) => { if (r === 0) return 1 / n; let s = 0; for (let k = r + 1; k <= n; k++) s += 1 / (k - 1); return (r / n) * s; };

export default [
  // ── 3. 도형과 배치 퍼즐 ──
  {
    id: "puz-tangram", grade: Z, unit: 3, lesson: "주제 3", title: "칠교판 — 일곱 조각의 넓이는 얼마일까", type: "조작", time: "8분",
    tags: ["넓이", "분수", "도형"], links: ["m1-pizza-area", "puz-domino-chess"],
    desc: "정사각형을 일곱 조각으로 나눈 칠교판은 중국에서 시작되어 세계로 퍼진 퍼즐입니다. 조각마다 넓이가 원래 정사각형의 몇 분의 몇인지 작은 삼각형을 단위로 세어 봅니다. 큰 삼각형은 1/4, 중간 삼각형·정사각형·평행사변형은 모두 1/8, 작은 삼각형은 1/16입니다.",
    obs: ["작은 삼각형 하나를 단위로 하면 전체는 16칸입니다.", "정사각형, 평행사변형, 중간 삼각형은 모양이 달라도 넓이가 같습니다.", "일곱 조각으로 1600가지가 넘는 모양을 만들 수 있다고 합니다."],
    q: "칠교판 조각으로 만든 두 모양은 넓이가 늘 같을까요?",
    formula: "1/4 + 1/4 + 1/8 + 1/8 + 1/8 + 1/16 + 1/16 = 1",
    en: { title: "The Tangram", desc: "Areas of the seven pieces." },
    view: { x: [-0.6, 9.6], y: [-0.6, 4.8] },
    params: [{ key: "p", label: "강조할 조각", type: "select", value: "5", options: TAN.map((t, i) => [String(i), t[0]]) }, { key: "grid", label: "작은 삼각형 눈금", type: "check", value: true }],
    draw(s, g) { TAN.forEach(([nm, P0, a, c], i) => g.poly(P0, { fill: c, fo: String(i) === s.p ? 0.85 : 0.35, color: "ink", w: 2 })); if (s.grid) { for (let k = 0; k <= 4; k++) { g.seg([k, 0], [k, 4], { color: "ink", w: 0.5, opacity: 0.35 }); g.seg([0, k], [4, k], { color: "ink", w: 0.5, opacity: 0.35 }); } g.seg([0, 0], [4, 4], { color: "ink", w: 0.5, opacity: 0.35 }).seg([0, 4], [4, 0], { color: "ink", w: 0.5, opacity: 0.35 }); } const T = TAN[+s.p]; g.text([6.8, 3.4], T[0], { bold: true, size: 16 }); g.text([6.8, 2.4], `넓이 = 전체의 ${frac(T[2], 16)}`, { bold: true, size: 15, color: "a" }); g.text([6.8, 1.5], `작은 삼각형 ${T[2] * 16}개`, { size: 13 }); },
    metrics(s) { const T = TAN[+s.p]; return [["조각", T[0]], ["넓이", frac(T[2], 16), "key"], ["일곱 조각의 합", "1"]]; },
    predict: [
      { q: "큰 삼각형 하나의 넓이는 전체의 몇 분의 몇?", set: (s) => (s.p = "5"), reveal: (s) => (s.p = "0"), answer: () => 0.25, tol: 1e-9, show: () => "1/4", why: "정사각형의 대각선 둘로 나눈 네 조각 중 하나입니다." },
      { q: "평행사변형의 넓이는 작은 삼각형 몇 개와 같을까요?", set: (s) => (s.p = "0"), reveal: (s) => (s.p = "6"), answer: () => 2, why: "1/8 = 2/16이므로 2개입니다." },
    ],
  },
  {
    id: "puz-domino-chess", grade: Z, unit: 3, lesson: "주제 3", title: "귀퉁이 잘린 체스판과 도미노 — 색칠하면 바로 보인다", type: "조작", time: "8분",
    tags: ["홀짝", "증명", "불변량"], links: ["puz-tangram", "alg-domino"],
    desc: "8 × 8 체스판에서 대각선으로 마주 보는 두 귀퉁이 칸을 잘라 내면 남은 62칸을 2칸짜리 도미노 31개로 빈틈없이 덮을 수 있을까요? 도미노 하나는 늘 검은 칸 하나와 흰 칸 하나를 덮는데, 마주 보는 귀퉁이는 같은 색이라 남은 판은 검은 칸 30개, 흰 칸 32개입니다. 그러니 불가능합니다.",
    obs: ["도미노는 놓는 방향과 상관없이 검은 칸 1개, 흰 칸 1개를 덮습니다.", "두 색의 칸 수가 다르면 덮을 수 없습니다(불변량).", "같은 변의 두 귀퉁이처럼 다른 색 두 칸을 자르면 덮을 수 있습니다."],
    q: "검은 칸 하나와 흰 칸 하나를 아무 데서나 잘라 내면 언제나 덮을 수 있을까요? (고모리의 정리)",
    formula: "도미노 k개가 덮는 칸: 검은 칸 k, 흰 칸 k",
    en: { title: "The Mutilated Chessboard", desc: "Colouring proves it impossible." },
    view: { x: [-0.6, 12.6], y: [-1.4, 8.6] },
    params: [{ key: "m", label: "잘라 낸 두 칸", type: "seg", value: "diag", options: [["diag", "대각선 반대 귀퉁이"], ["side", "같은 변의 두 귀퉁이"]] }, { key: "tile", label: "도미노 놓아 보기", type: "check", value: true }],
    draw(s, g) { const cut = s.m === "diag" ? ["0,0", "7,7"] : ["0,0", "0,7"]; for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) { if (cut.includes(r + "," + c)) { rect(g, c, 7 - r, 1, 1, { fill: "e", fo: 0.15, color: "e", w: 1, dash: "3 3" }); continue; } rect(g, c, 7 - r, 1, 1, { fill: (r + c) % 2 ? "ink" : "paper", fo: (r + c) % 2 ? 0.55 : 1, color: "muted", w: 0.5 }); } if (s.tile) { const doms = []; if (s.m === "side") { for (let c = 1; c < 7; c += 2) doms.push([0, c, 0, c + 1]); for (let r = 1; r < 8; r++) for (let c = 0; c < 8; c += 2) doms.push([r, c, r, c + 1]); } else { for (let c = 1; c < 7; c += 2) doms.push([0, c, 0, c + 1]); for (let r = 1; r < 7; r++) for (let c = 0; c < 8; c += 2) doms.push([r, c, r, c + 1]); for (let c = 0; c < 6; c += 2) doms.push([7, c, 7, c + 1]); } doms.forEach(([r1, c1, r2, c2]) => rect(g, Math.min(c1, c2) + 0.12, 7 - Math.max(r1, r2) + 0.12, Math.abs(c2 - c1) + 0.76, Math.abs(r2 - r1) + 0.76, { fill: "a", fo: 0.55, color: "a", w: 1.4 })); if (s.m === "diag") { g.text([10.2, 4.5], "남은 두 칸", { bold: true, color: "e" }); g.text([10.2, 3.8], "(0, 7)과 (7, 6)?", { size: 12 }); g.text([10.2, 3.1], "둘 다 검은 칸 →", { size: 12 }); g.text([10.2, 2.4], "덮을 수 없음!", { bold: true, color: "e" }); } } },
    metrics(s) { const cut = s.m === "diag" ? [[0, 0], [7, 7]] : [[0, 0], [0, 7]]; let b = 32, w = 32; cut.forEach(([r, c]) => ((r + c) % 2 ? b-- : w--)); return [["검은 칸", `${b}개`], ["흰 칸", `${w}개`], ["도미노로 덮기", b === w ? "가능" : "불가능", "key"]]; },
    predict: [
      { q: "대각선 반대 귀퉁이를 자르면 검은 칸과 흰 칸은 몇 개씩? (흰 칸 수를 답하세요)", set: (s) => Object.assign(s, { m: "side", tile: false }), reveal: (s) => (s.m = "diag"), answer: () => 30, why: "두 귀퉁이가 같은 색(흰 칸)이라 흰 칸 30개, 검은 칸 32개입니다." },
      { q: "같은 변의 두 귀퉁이를 자르면 덮을 수 있을까요?", options: O("있다", "없다"), set: (s) => Object.assign(s, { m: "diag" }), reveal: (s) => Object.assign(s, { m: "side", tile: true }), answer: () => "a", why: "두 칸의 색이 달라 31칸씩 같고, 실제로 덮을 수 있습니다." },
    ],
  },
  {
    id: "puz-knights-tour", grade: Z, unit: 3, lesson: "주제 3", title: "나이트 투어 — 말 하나로 모든 칸을 한 번씩", type: "조작", time: "10분",
    tags: ["그래프", "알고리즘", "경로"], links: ["lab-konigsberg", "puz-eight-queens"],
    desc: "체스의 나이트(L자로 움직이는 말)가 모든 칸을 정확히 한 번씩 지나갈 수 있을까요? 오일러도 연구한 이 문제는 1823년 바른스도르프가 제안한 '갈 수 있는 곳이 가장 적은 칸으로 먼저 간다'는 규칙으로 놀랍도록 잘 풀립니다. 판의 크기와 출발 칸을 바꾸며 한 단계씩 따라갑니다.",
    obs: ["구석 칸은 갈 길이 적어 나중에 가면 막히기 쉽습니다.", "바른스도르프 규칙은 막히기 쉬운 칸을 먼저 처리합니다.", "4 × 4 판에서는 나이트 투어가 불가능합니다."],
    q: "나이트가 늘 다른 색 칸으로 간다는 점을 이용해, 출발점으로 돌아오는 투어가 5 × 5 판에서 불가능한 까닭을 설명해 봅시다.",
    formula: "다음 칸 = 갈 수 있는 이웃이 가장 적은 칸 (바른스도르프 규칙)",
    en: { title: "The Knight's Tour", desc: "Warnsdorff's rule." },
    view: (s) => ({ x: [-0.4, +s.n + 0.4], y: [-1, +s.n + 0.4] }),
    params: [{ key: "n", label: "판의 크기", type: "seg", value: "8", options: [["5", "5 × 5"], ["6", "6 × 6"], ["8", "8 × 8"]] }, { key: "k", label: "움직인 횟수", min: 1, max: 64, step: 1, value: 64, max: (s) => (+s.n) ** 2 }],
    anim: { key: "k", min: 1, max: 64, speed: 8, label: "말 움직이기" },
    draw(s, g) { const n = +s.n, P0 = knight(n, 0, 0), k = Math.min(s.k, P0.length); for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) rect(g, c, n - 1 - r, 1, 1, { fill: (r + c) % 2 ? "muted" : "paper", fo: (r + c) % 2 ? 0.25 : 1, color: "muted", w: 0.5 }); const pts = P0.slice(0, k).map(([r, c]) => [c + 0.5, n - 0.5 - r]); g.path(pts, { color: "b", w: 1.8 }); pts.forEach((p, i) => { if (n <= 6 || i === k - 1 || i === 0) g.text(p, `${i + 1}`, { dy: 4, size: n > 6 ? 9 : 11, bold: i === k - 1, color: i === k - 1 ? "a" : "ink" }); }); g.circle(pts.at(-1), 0.32, { color: "a", w: 2.4 }); },
    metrics(s) { const n = +s.n, P0 = knight(n, 0, 0); return [["지나간 칸", `${Math.min(s.k, P0.length)} / ${n * n}`, "key"], ["바른스도르프 규칙 결과", P0.length === n * n ? "모든 칸 완주" : `${P0.length}칸에서 막힘`]]; },
    predict: [
      { q: "8 × 8 판의 칸은 모두 몇 개이고, 나이트는 몇 번 움직여야 투어를 마칠까요? (움직임 수)", set: (s) => Object.assign(s, { n: "8", k: 10 }), reveal: (s) => (s.k = 64), answer: () => 63, why: "64칸을 지나려면 63번 움직입니다." },
      { q: "나이트는 한 번 움직일 때마다 칸의 색이 어떻게 될까요?", options: O("늘 바뀐다", "늘 같다", "그때그때 다르다"), answer: () => "a", why: "L자 이동은 가로 + 세로 칸 수의 합이 3(홀수)이라 색이 바뀝니다." },
    ],
  },
  {
    id: "puz-eight-queens", grade: Z, unit: 3, lesson: "주제 3", title: "여덟 퀸 문제 — 서로 잡지 않게 놓는 92가지 (1848년)", type: "조작", time: "10분",
    tags: ["경우의 수", "알고리즘", "배치"], links: ["puz-knights-tour", "pst-perm-comb"],
    desc: "체스판에 퀸(가로·세로·대각선으로 움직이는 말) 8개를 서로 공격하지 않게 놓는 방법은 몇 가지일까요? 1848년 체스 선수 베첼이 낸 문제로, 가우스도 관심을 보였습니다. 한 줄씩 퀸을 놓고 막히면 되돌아가는 '되추적'으로 모든 해를 찾으면 92가지입니다. n을 바꾸며 해를 하나씩 살펴봅니다.",
    obs: ["각 가로줄과 세로줄에 퀸이 정확히 하나씩 있으므로 해는 순열입니다.", "되추적은 막히는 순간 바로 앞 줄로 돌아가 다른 칸을 시도합니다.", "회전·대칭으로 같은 것을 하나로 보면 8퀸의 본질적으로 다른 해는 12가지입니다."],
    q: "n = 2, 3일 때는 왜 해가 없을까요?",
    formula: "해의 수: n = 4 → 2, 5 → 10, 6 → 4, 7 → 40, 8 → 92",
    en: { title: "The Eight Queens Puzzle", desc: "92 solutions by backtracking." },
    view: (s) => ({ x: [-0.4, +s.n + 0.4], y: [-1, +s.n + 0.4] }),
    params: [{ key: "n", label: "판의 크기 n", type: "seg", value: "8", options: [["4", "4"], ["5", "5"], ["6", "6"], ["7", "7"], ["8", "8"]] }, { key: "i", label: "몇 번째 해", min: 1, max: 92, step: 1, value: 1, max: (s) => queens(+s.n).length }],
    anim: { key: "i", min: 1, max: 92, speed: 3, label: "해 넘겨 보기" },
    draw(s, g) { const n = +s.n, S = queens(n), q = S[Math.min(s.i, S.length) - 1]; for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) rect(g, c, n - 1 - r, 1, 1, { fill: (r + c) % 2 ? "muted" : "paper", fo: (r + c) % 2 ? 0.25 : 1, color: "muted", w: 0.5 }); q.forEach((c, r) => { g.circle([c + 0.5, n - 0.5 - r], 0.34, { fill: "a", fo: 0.9, color: "paper", w: 2 }); g.text([c + 0.5, n - 0.5 - r], "♛", { dy: 6, size: 16, color: "paper" }); }); g.text([n / 2, -0.6], `세로줄 순서: ${q.map((c) => c + 1).join(" ")}`, { size: 12, mono: true }); },
    metrics(s) { const S = queens(+s.n); return [[`${s.n}퀸 해의 수`, `${S.length}가지`, "key"], ["지금 보는 해", `${Math.min(s.i, S.length)}번째`]]; },
    predict: [
      { q: "8퀸 문제의 해는 모두 몇 가지?", set: (s) => Object.assign(s, { n: "4", i: 1 }), reveal: (s) => Object.assign(s, { n: "8", i: 1 }), answer: () => 92, why: "되추적으로 모두 세면 92가지입니다." },
      { q: "4퀸 문제의 해는 몇 가지?", set: (s) => Object.assign(s, { n: "8" }), reveal: (s) => Object.assign(s, { n: "4", i: 1 }), answer: () => 2, why: "(2, 4, 1, 3)과 (3, 1, 4, 2) 두 가지입니다." },
    ],
  },
  {
    id: "puz-fifteen", grade: Z, unit: 3, lesson: "주제 3", title: "15 퍼즐과 샘 로이드의 상금 — 홀짝으로 불가능을 증명하다 (1880년)", type: "조작", time: "10분",
    tags: ["순열", "홀짝", "불변량"], links: ["puz-domino-chess", "puz-eight-queens"],
    desc: "1880년 미국에서 대유행한 15 퍼즐에 퍼즐 작가 샘 로이드는 '14와 15만 바뀐 판'을 맞추면 1000달러를 주겠다고 했다는 이야기가 있습니다. 아무도 받지 못했습니다. 조각을 밀 때마다 '거꾸로 놓인 쌍의 수 + 빈칸의 줄'의 홀짝이 바뀌지 않기 때문에, 처음 상태와 홀짝이 다른 판은 절대 맞출 수 없습니다.",
    obs: ["순서가 거꾸로 된 쌍(역순)의 수를 셉니다.", "역순의 수 + 빈칸이 아래에서 몇째 줄인지의 합이 홀수일 때만 맞출 수 있습니다.", "무작위로 섞은 판의 딱 절반만 풀 수 있습니다."],
    q: "빈칸을 한 번 위아래로 움직이면 역순의 수는 어떻게 바뀔까요?",
    formula: "풀 수 있음 ⇔ (역순의 수 + 빈칸의 줄 번호(아래부터)) 이 홀수",
    en: { title: "The 15 Puzzle", desc: "Parity proves Sam Loyd's puzzle impossible." },
    view: { x: [-0.6, 8.6], y: [-1.4, 4.6] },
    params: [{ key: "m", label: "판", type: "seg", value: "loyd", options: [["loyd", "14·15를 바꾼 판"], ["rand", "무작위로 섞은 판"]] }, { key: "seed", label: "씨앗값", min: 1, max: 97, step: 1, value: 1 }],
    ...SEED,
    draw(s, g) { const F = fifteen(s.m, s.seed); F.T.forEach((v, i) => { const x = i % 4, y = 3 - Math.floor(i / 4); if (v) { rect(g, x + 0.05, y + 0.05, 0.9, 0.9, { fill: v === 14 || v === 15 ? "a" : "b", fo: 0.45, color: "ink", w: 1.4 }); g.text([x + 0.5, y + 0.5], `${v}`, { dy: 6, bold: true, size: 16 }); } }); g.text([6.2, 3], `역순의 수 ${F.inv}`, { bold: true }); g.text([6.2, 2.2], `빈칸 줄(아래부터) ${4 - Math.floor(F.T.indexOf(0) / 4)}`, { bold: true }); g.text([6.2, 1.2], F.solv ? "맞출 수 있음" : "맞출 수 없음", { bold: true, size: 18, color: F.solv ? "c" : "e" }); },
    metrics(s) { const F = fifteen(s.m, s.seed); return [["역순의 수", `${F.inv}`], ["풀 수 있나", F.solv ? "예" : "아니요", "key"]]; },
    predict: [
      { q: "14와 15만 바꾼 판에서 역순의 수는?", set: (s) => (s.m = "rand"), reveal: (s) => (s.m = "loyd"), answer: () => 1, why: "(15, 14) 한 쌍만 거꾸로입니다." },
      { q: "그 판은 맞출 수 있을까요?", options: O("있다", "없다"), answer: () => "b", why: "1 + 1(빈칸이 맨 아랫줄) = 2로 짝수라 맞출 수 없습니다." },
    ],
  },
  {
    id: "puz-four-color", grade: Z, unit: 3, lesson: "주제 3", title: "4색 지도 — 이웃한 나라는 다른 색으로 (1852년)", type: "조작", time: "10분",
    tags: ["그래프", "색칠", "증명"], links: ["lab-konigsberg", "puz-knights-tour"],
    desc: "1852년 거스리는 영국 지도를 칠하다 '이웃한 나라끼리 다른 색이 되게 하려면 네 가지 색이면 충분하다'고 추측했습니다. 이 4색 정리는 1976년에야 컴퓨터로 1936가지 경우를 확인해 증명되었습니다. 나라 12개짜리 지도를 정해진 색 수로 칠할 수 있는지, 되추적으로 찾아봅니다.",
    obs: ["세 나라가 서로 모두 맞닿아 있으면 적어도 세 색이 필요합니다.", "평면 지도는 언제나 네 색이면 충분합니다(4색 정리).", "4색 정리는 컴퓨터를 써서 증명한 최초의 유명한 정리입니다."],
    q: "네 나라가 서로 모두 맞닿는 지도를 그릴 수 있을까요? 다섯 나라라면?",
    formula: "평면 지도의 색칠 수 χ ≤ 4",
    en: { title: "The Four Colour Map", desc: "Neighbours get different colours." },
    view: { x: [-0.3, 8.3], y: [-1, 5.4] },
    params: [{ key: "k", label: "쓸 수 있는 색의 수", type: "seg", value: "4", options: [["2", "2색"], ["3", "3색"], ["4", "4색"]] }],
    draw(s, g) { const { cell, N, M, W, H } = mapData(), C = colorMap(+s.k), col = ["a", "b", "c", "d"]; for (let j = 0; j < M; j++) for (let i = 0; i < N; i++) { const r = cell[j][i]; rect(g, (i * W) / N, (j * H) / M, W / N + 0.005, H / M + 0.005, { fill: C ? col[C[r]] : "muted", fo: C ? 0.6 : 0.2, stroke: false }); if (i + 1 < N && cell[j][i + 1] !== r) g.seg([((i + 1) * W) / N, (j * H) / M], [((i + 1) * W) / N, ((j + 1) * H) / M], { color: "ink", w: 1.4 }); if (j + 1 < M && cell[j + 1][i] !== r) g.seg([(i * W) / N, ((j + 1) * H) / M], [((i + 1) * W) / N, ((j + 1) * H) / M], { color: "ink", w: 1.4 }); } g.text([4, -0.6], C ? `${s.k}색으로 칠할 수 있습니다` : `${s.k}색으로는 칠할 수 없습니다`, { bold: true, color: C ? "c" : "e" }); },
    metrics(s) { const C = colorMap(+s.k); return [["나라 수", `${MAPPTS.length}`], [`${s.k}색으로 칠하기`, C ? "가능" : "불가능", "key"]]; },
    predict: [
      { q: "이 지도를 2색으로 칠할 수 있을까요?", options: O("있다", "없다"), set: (s) => (s.k = "4"), reveal: (s) => (s.k = "2"), answer: () => "b", why: "서로 맞닿은 세 나라가 있으면 2색으로는 안 됩니다." },
      { q: "평면 지도라면 늘 몇 가지 색이면 충분할까요?", set: (s) => (s.k = "3"), reveal: (s) => (s.k = "4"), answer: () => 4, why: "4색 정리입니다." },
    ],
  },
  {
    id: "puz-tsp", grade: Z, unit: 3, lesson: "주제 3", title: "외판원 문제 — 모든 도시를 한 번씩 도는 가장 짧은 길", type: "조작", time: "12분",
    tags: ["최적화", "경우의 수", "알고리즘"], links: ["his-dijkstra", "puz-knights-tour"],
    desc: "외판원이 n개 도시를 한 번씩 들르고 출발지로 돌아오는 가장 짧은 길은? 가능한 길은 (n − 1)!/2가지라 도시가 조금만 늘어도 모두 따지기가 불가능해집니다. '가장 가까운 도시부터 가기'처럼 빠른 어림 방법은 대체로 좋지만 최선은 아닐 때가 많습니다. 두 방법의 길이를 비교합니다.",
    obs: ["도시 8개면 2520가지, 20개면 약 6 × 10¹⁶가지 길이 있습니다.", "가장 가까운 곳부터 가는 방법은 빠르지만 마지막에 먼 길을 돌아오기 쉽습니다.", "택배 경로, 반도체 회로 설계 등에 쓰이는 중요한 문제입니다."],
    q: "도시가 10개면 가능한 순회로는 몇 가지일까요?",
    formula: "순회로의 수 = (n − 1)! / 2",
    en: { title: "The Travelling Salesman Problem", desc: "Brute force versus nearest neighbour." },
    view: { x: [-0.4, 10.4], y: [-1, 6.4] },
    params: [{ key: "n", label: "도시 수", min: 4, max: 8, step: 1, value: 7 }, { key: "m", label: "경로", type: "seg", value: "best", options: [["nn", "가까운 곳부터"], ["best", "최단 경로"]] }, { key: "seed", label: "씨앗값", min: 1, max: 97, step: 1, value: 3 }],
    ...SEED,
    draw(s, g) { const P0 = cities(s.n, s.seed), t = s.m === "best" ? tspBest(s.n, s.seed).best : tspNN(s.n, s.seed).t; g.poly(t.map((i) => P0[i]), { fill: s.m === "best" ? "c" : "a", fo: 0.08, color: s.m === "best" ? "c" : "a", w: 2.6 }); P0.forEach((p, i) => { g.circle(p, 0.2, { fill: i === 0 ? "e" : "b", fo: 0.9, color: "paper", w: 1.6 }); g.text(p, i === 0 ? "출발" : `${i}`, { dy: -12, size: 11, bold: true }); }); },
    metrics(s) { const B = tspBest(s.n, s.seed), N0 = tspNN(s.n, s.seed); let f = 1; for (let k = 2; k < s.n; k++) f *= k; return [["가까운 곳부터", fmt(N0.L, 3)], ["최단 경로", fmt(B.bl, 3), "key"], ["따져 본 순회로", `${f / 2}가지`]]; },
    predict: [
      { q: "도시 8개의 서로 다른 순회로는 몇 가지?", set: (s) => (s.n = 5), reveal: (s) => (s.n = 8), answer: () => 2520, why: "7!/2 = 2520가지입니다." },
      { q: "‘가까운 곳부터’ 경로는 최단 경로보다 길 수 있을까요?", options: O("길 수 있다", "언제나 같다"), answer: () => "a", why: "어림 방법이라 최선을 보장하지 않습니다." },
    ],
  },
  // ── 4. 전략 게임 ──
  {
    id: "puz-nim", grade: Z, unit: 4, lesson: "주제 4", title: "님 게임 — 이진법 XOR로 반드시 이기기 (1901년)", type: "조작", time: "12분",
    tags: ["이진법", "전략", "게임"], links: ["puz-binary-cards", "puz-game-31"],
    desc: "돌무더기 몇 개에서 번갈아 한 무더기를 골라 돌을 1개 이상 가져가고, 마지막 돌을 가져가는 사람이 이깁니다. 1901년 부턴은 각 무더기의 돌 수를 이진법으로 쓰고 자리마다 1의 개수가 짝수인지 보는 '님 합(XOR)'이 0이 아니면 먼저 하는 사람이, 0이면 나중 사람이 반드시 이긴다는 것을 밝혔습니다.",
    obs: ["님 합이 0인 상태에서는 어떻게 가져가도 0이 아니게 됩니다.", "님 합이 0이 아닌 상태에서는 늘 0으로 만드는 한 수가 있습니다.", "그래서 상대에게 늘 님 합 0인 상태를 넘겨주면 이깁니다."],
    q: "무더기가 1, 2, 3개라면 먼저 하는 사람이 이길 수 있을까요?",
    formula: "님 합 = a ⊕ b ⊕ c (이진법 자리별 홀짝)",
    en: { title: "The Game of Nim", desc: "Bouton's XOR strategy." },
    view: { x: [-0.6, 12.6], y: [-1.4, 6.4] },
    params: [{ key: "a", label: "무더기 A", min: 0, max: 12, step: 1, value: 3 }, { key: "b", label: "무더기 B", min: 0, max: 12, step: 1, value: 5 }, { key: "c", label: "무더기 C", min: 0, max: 12, step: 1, value: 7 }],
    move(s) { const H = [s.a, s.b, s.c], x = H[0] ^ H[1] ^ H[2]; if (!x) return null; for (let i = 0; i < 3; i++) { const t = H[i] ^ x; if (t < H[i]) return [i, H[i] - t]; } return null; },
    draw(s, g) { const H = [s.a, s.b, s.c], mv = this.move(s); H.forEach((n, i) => { const y = 4.8 - i * 1.6; g.text([0, y], "ABC"[i], { bold: true, size: 16 }); for (let k = 0; k < n; k++) { const take = mv && mv[0] === i && k >= n - mv[1]; g.circle([1 + k * 0.9, y], 0.34, { fill: take ? "e" : "b", fo: take ? 0.35 : 0.75, color: take ? "e" : "paper", w: take ? 2 : 1, dash: take ? "3 3" : "" }); } g.text([12.4, y], `${n.toString(2).padStart(4, "0")}`, { anchor: "end", mono: true, bold: true }); }); const x = s.a ^ s.b ^ s.c; g.text([12.4, 0.2], `님 합 ${x.toString(2).padStart(4, "0")}`, { anchor: "end", mono: true, bold: true, color: x ? "a" : "c" }); },
    metrics(s) { const x = s.a ^ s.b ^ s.c, mv = this.move(s); return [["님 합 (십진법)", `${x}`], ["지금 차례인 사람", x ? "이길 수 있음" : "질 수밖에 없음 (상대가 실수하지 않으면)", "key"], ["이기는 수", mv ? `${"ABC"[mv[0]]}에서 ${mv[1]}개 가져가기` : "없음"]]; },
    predict: [
      { q: "무더기 3, 5, 7의 님 합은?", set: (s) => Object.assign(s, { a: 3, b: 5, c: 7 }), answer: () => 1, why: "011 ⊕ 101 ⊕ 111 = 001 = 1입니다." },
      { q: "무더기 1, 2, 3에서 먼저 하는 사람은 이길 수 있을까요?", options: O("있다", "없다"), set: (s) => Object.assign(s, { a: 3, b: 5, c: 7 }), reveal: (s) => Object.assign(s, { a: 1, b: 2, c: 3 }), answer: () => "b", why: "1 ⊕ 2 ⊕ 3 = 0이라 나중에 하는 사람이 이깁니다." },
    ],
  },
  {
    id: "puz-game-31", grade: Z, unit: 4, lesson: "주제 4", title: "31 게임 — 31을 외치면 진다, 이기는 수는 4의 규칙", type: "조작", time: "8분",
    tags: ["나머지", "전략", "게임"], links: ["puz-nim", "cm1-remainder"],
    desc: "두 사람이 1부터 차례로 수를 1~3개씩 이어서 외치고, 31을 외치는 사람이 집니다. 30을 내가 외치면 상대는 31을 외칠 수밖에 없습니다. 거꾸로 생각하면 30, 26, 22, …, 2처럼 4로 나눈 나머지가 2인 수를 늘 내가 외치면 반드시 이깁니다. 상대가 몇 개를 외치든 나는 '4 − 상대가 외친 개수'만큼 외치면 되니까요.",
    obs: ["안전한 수는 30, 26, 22, 18, 14, 10, 6, 2 (4로 나눈 나머지 2)입니다.", "먼저 하는 사람이 처음에 ‘1, 2’를 외치면 끝까지 이깁니다.", "한 번에 외칠 수 있는 개수가 m개까지면 m + 1의 규칙이 됩니다."],
    q: "한 번에 1~4개를 외칠 수 있다면 안전한 수는 무엇일까요?",
    formula: "안전한 수 ≡ 30 (mod 4), 즉 4k + 2",
    en: { title: "The 31 Game", desc: "Count to 31 and lose." },
    view: { x: [-0.6, 12.6], y: [-1, 6.4] },
    params: [{ key: "n", label: "지금까지 외친 마지막 수", min: 0, max: 30, step: 1, value: 5 }, { key: "m", label: "한 번에 외칠 수 있는 최대 개수", min: 2, max: 5, step: 1, value: 3 }],
    safe(m, v) { return v % (m + 1) === 30 % (m + 1); },
    draw(s, g) { for (let v = 1; v <= 31; v++) { const i = v - 1, x = 0.4 + (i % 11) * 1.1, y = 5 - Math.floor(i / 11) * 1.6, said = v <= s.n, sf = this.safe(s.m, v) && v < 31; g.circle([x, y], 0.42, { fill: v === 31 ? "e" : sf ? "c" : "b", fo: said ? 0.8 : 0.15, color: sf ? "c" : "muted", w: sf ? 2 : 1 }); g.text([x, y], `${v}`, { dy: 5, bold: true, size: 12 }); } g.text([0.2, -0.4], "초록 테두리: 내가 외치면 이기는 안전한 수 · 빨강: 31", { anchor: "start", size: 12 }); },
    metrics(s) { const target = [...Array(31).keys()].map((i) => i + 1).find((v) => v > s.n && v <= s.n + s.m && this.safe(s.m, v)); return [["다음에 외칠 수", target ? `${s.n + 1}~${target}까지 (${target - s.n}개)` : "안전한 수에 갈 수 없음 — 상대가 유리", "key"], ["안전한 수의 규칙", `${s.m + 1}로 나눈 나머지 ${30 % (s.m + 1)}`]]; },
    predict: [
      { q: "한 번에 1~3개일 때, 먼저 하는 사람이 처음에 어디까지 외쳐야 이길까요?", set: (s) => Object.assign(s, { n: 0, m: 3 }), answer: () => 2, why: "2는 4로 나눈 나머지가 2인 첫 안전한 수입니다." },
      { q: "상대가 23까지 외쳤다면 나는 어디까지 외쳐야 할까요?", set: (s) => Object.assign(s, { n: 5, m: 3 }), reveal: (s) => (s.n = 23), answer: () => 26, why: "다음 안전한 수 26까지 외칩니다." },
    ],
  },
  {
    id: "puz-wythoff", grade: Z, unit: 4, lesson: "주제 4", title: "와이토프 게임 — 지는 자리에 황금비가 숨어 있다 (1907년)", type: "조작", time: "12분",
    tags: ["황금비", "전략", "수열"], links: ["puz-nim", "lab-golden-spiral"],
    desc: "돌무더기 두 개에서 한 무더기의 돌을 원하는 만큼, 또는 두 무더기에서 같은 수만큼 가져갈 수 있고, 마지막 돌을 가져가면 이깁니다. 체스판의 퀸을 왼쪽 아래 구석으로 옮기는 게임과 같습니다. 지금 차례인 사람이 지는 자리는 (⌊kφ⌋, ⌊kφ²⌋) (φ는 황금비)로, (0, 0), (1, 2), (3, 5), (4, 7), (6, 10), …입니다.",
    obs: ["지는 자리에서는 어디로 움직여도 이기는 자리가 됩니다.", "지는 자리의 두 수의 차는 0, 1, 2, 3, …으로 하나씩 커집니다.", "두 수는 황금비 φ ≈ 1.618에 따라 정해집니다."],
    q: "(3, 5) 다음의 지는 자리를 황금비로 계산해 봅시다.",
    formula: "지는 자리 = (⌊kφ⌋, ⌊kφ²⌋), φ = (1 + √5)/2",
    en: { title: "Wythoff's Game", desc: "The golden ratio in losing positions." },
    view: { x: [-0.6, 13.6], y: [-1.2, 13.6] },
    params: [{ key: "a", label: "무더기 A", min: 0, max: 13, step: 1, value: 6 }, { key: "b", label: "무더기 B", min: 0, max: 13, step: 1, value: 9 }],
    draw(s, g) { for (let a = 0; a <= 13; a++) for (let b = 0; b <= 13; b++) rect(g, a, b, 1, 1, { fill: wythoffP(a, b) ? "a" : "paper", fo: wythoffP(a, b) ? 0.65 : 1, color: "grid", w: 0.5 }); const rays = [[1, 0], [0, 1], [1, 1]]; rays.forEach(([dx, dy]) => { let x = s.a, y = s.b; while (x - dx >= 0 && y - dy >= 0) { x -= dx; y -= dy; g.circle([x + 0.5, y + 0.5], 0.12, { fill: "b", fo: 0.6, stroke: false }); } }); g.circle([s.a + 0.5, s.b + 0.5], 0.36, { fill: "e", fo: 0.9, color: "paper", w: 2 }); g.text([6.5, 13.3], "주황 칸: 지금 차례인 사람이 지는 자리 · 파란 점: 갈 수 있는 곳", { size: 11, bold: true }); },
    metrics(s) { const P0 = wythoffP(s.a, s.b); return [["지금 자리", `(${s.a}, ${s.b})`], ["지금 차례인 사람", P0 ? "지는 자리" : "이기는 자리 — 주황 칸으로 보내세요", "key"]]; },
    predict: [
      { q: "(3, 5)는 지는 자리일까요?", options: O("예", "아니요"), set: (s) => Object.assign(s, { a: 6, b: 9 }), reveal: (s) => Object.assign(s, { a: 3, b: 5 }), answer: () => "a", why: "k = 2: ⌊2φ⌋ = 3, ⌊2φ²⌋ = 5입니다." },
      { q: "k = 4인 지는 자리 (⌊4φ⌋, ⌊4φ²⌋)에서 작은 수는?", answer: () => 6, why: "4 × 1.618 = 6.47이므로 6입니다(짝은 10)." },
    ],
  },
  {
    id: "puz-secretary", grade: Z, unit: 4, lesson: "주제 4", title: "비서 문제 — 37%를 보고 나서 결정하라", type: "조작", time: "12분",
    tags: ["확률", "최적화", "e"], links: ["par-hat-check", "calc2-e-limit"],
    desc: "지원자 n명을 무작위 순서로 한 명씩 면접하고, 그 자리에서 뽑을지 말지 정해야 합니다. 가장 뛰어난 사람을 뽑을 확률을 높이려면? 처음 r명은 무조건 보내며 기준만 보고, 그 뒤에 지금까지 본 누구보다 나은 첫 사람을 뽑습니다. r을 n/e ≈ 0.37n으로 정하면 성공 확률이 약 1/e ≈ 37%로 가장 큽니다.",
    obs: ["r이 너무 작으면 기준이 낮고, 너무 크면 최고를 이미 보낸 경우가 많습니다.", "성공 확률 P(r) = (r/n) Σ 1/(k − 1) (k = r + 1, …, n)입니다.", "n이 커져도 최적 비율과 성공 확률은 모두 약 1/e로 일정합니다."],
    q: "집 구하기, 주차 자리 찾기에도 이 전략을 쓸 수 있을까요?",
    formula: "최적 r ≈ n/e, 성공 확률 ≈ 1/e",
    en: { title: "The Secretary Problem", desc: "The 37% rule." },
    view: { x: [-0.6, 10.6], y: [-1.4, 6.4] },
    params: [{ key: "n", label: "지원자 수 n", min: 5, max: 100, step: 1, value: 50 }, { key: "r", label: "먼저 그냥 보낼 사람 수 r", min: 0, max: 99, step: 1, value: 18, max: (s) => s.n - 1 }],
    draw(s, g) { const X = (r) => 0.4 + (r / s.n) * 9.8, Y = (p) => p * 12; g.seg([0.4, 0], [10.2, 0], { color: "axis", w: 1.2 }); const pts = []; for (let r = 0; r < s.n; r++) pts.push([X(r), Y(secretaryP(s.n, r))]); g.path(pts, { color: "b", w: 2.4 }); g.point([X(s.r), Y(secretaryP(s.n, s.r))], "", { color: "a" }); g.seg([X(s.n / Math.E), 0], [X(s.n / Math.E), Y(1 / Math.E) + 0.3], { color: "e", w: 1.2, dash: "4 4" }).text([X(s.n / Math.E), Y(1 / Math.E) + 0.3], "n/e", { dy: -4, bold: true, color: "e" }); g.text([0.4, 6], "가로: 그냥 보낸 비율 r/n · 세로: 최고를 뽑을 확률", { anchor: "start", bold: true, size: 12 }); },
    metrics(s) { let best = 0, br = 0; for (let r = 0; r < s.n; r++) { const p = secretaryP(s.n, r); if (p > best) { best = p; br = r; } } return [["지금 전략의 성공 확률", fmt(secretaryP(s.n, s.r), 4), "key"], ["가장 좋은 r", `${br} (성공 ${fmt(best, 4)})`], ["n/e", fmt(s.n / Math.E, 1)]]; },
    predict: [
      { q: "지원자 100명이면 처음 몇 명쯤을 그냥 보내는 것이 가장 좋을까요? (정수로)", set: (s) => Object.assign(s, { n: 100, r: 10 }), reveal: (s) => (s.r = 37), answer: () => 37, tol: 1, why: "100/e ≈ 36.8이므로 37명입니다." },
      { q: "그때 최고를 뽑을 확률은 대략?", options: O("약 10%", "약 37%", "약 90%"), answer: () => "b", why: "1/e ≈ 0.37입니다." },
    ],
  },
  {
    id: "puz-rps-strategy", grade: Z, unit: 4, lesson: "주제 4", title: "가위바위보의 전략 — 상대의 버릇을 이용하라", type: "조작", time: "10분",
    tags: ["기댓값", "확률", "게임 이론"], links: ["m2-rps", "his-nash"],
    desc: "상대가 셋을 똑같이 1/3씩 낸다면 나는 무엇을 내든 기대 점수가 0입니다(내시 균형). 하지만 사람은 버릇이 있어, 예를 들어 바위를 자주 낸다면 보를 내는 것이 유리합니다. 상대가 낼 확률을 바꾸며 내가 가위·바위·보를 냈을 때의 기대 점수(이기면 +1, 지면 −1)를 비교합니다.",
    obs: ["상대가 1/3씩 고르게 내면 어떤 수를 내도 기대 점수는 0입니다.", "상대가 한쪽으로 치우치면 그 수를 이기는 수의 기대 점수가 커집니다.", "그래서 고르게 섞어 내는 것이 상대에게 이용당하지 않는 전략입니다."],
    q: "상대가 내가 낸 것을 보고 다음 수를 정한다면 어떻게 대응해야 할까요?",
    formula: "E(보) = P(바위) − P(가위), E(바위) = P(가위) − P(보), E(가위) = P(보) − P(바위)",
    en: { title: "Rock-Paper-Scissors Strategy", desc: "Exploiting a biased opponent." },
    view: { x: [-0.6, 10.6], y: [-4, 4.4] },
    params: [{ key: "r", label: "상대가 바위를 낼 확률", min: 0, max: 1, step: 0.01, value: 0.45 }, { key: "s", label: "상대가 가위를 낼 확률", min: 0, max: 1, step: 0.01, value: 0.3 }],
    probs(s) { const r = s.r, sc = Math.min(s.s, 1 - r), p = Math.max(0, 1 - r - sc); return { r, s: sc, p }; },
    draw(s, g) { const P0 = this.probs(s), E = { 가위: P0.p - P0.r, 바위: P0.s - P0.p, 보: P0.r - P0.s }; g.seg([0.4, 0], [10.2, 0], { color: "axis", w: 1.4 }); Object.entries(E).forEach(([k, v], i) => { const x = 1 + i * 3.2, best = v === Math.max(...Object.values(E)); rect(g, x, Math.min(0, v * 3.5), 1.8, Math.abs(v * 3.5), { fill: v >= 0 ? "c" : "e", fo: best ? 0.8 : 0.45, stroke: false }); g.text([x + 0.9, v * 3.5], fmt(v, 2), { dy: v >= 0 ? -6 : 16, bold: true }); g.text([x + 0.9, -3.6], `내가 ${k}`, { bold: best }); }); g.text([0.4, 4.1], `상대: 바위 ${fmt(P0.r, 2)} · 가위 ${fmt(P0.s, 2)} · 보 ${fmt(P0.p, 2)}`, { anchor: "start", bold: true, size: 12 }); },
    metrics(s) { const P0 = this.probs(s), E = { 가위: P0.p - P0.r, 바위: P0.s - P0.p, 보: P0.r - P0.s }, best = Object.entries(E).sort((a, b) => b[1] - a[1])[0]; return [["가장 좋은 수", `${best[0]} (기대 점수 ${fmt(best[1], 3)})`, "key"]]; },
    predict: [
      { q: "상대가 바위 1/2, 가위 1/4, 보 1/4로 낸다면 내가 보를 낼 때 기대 점수는? (분수나 소수로)", set: (s) => Object.assign(s, { r: 1 / 3, s: 1 / 3 }), reveal: (s) => Object.assign(s, { r: 0.5, s: 0.25 }), answer: () => 0.25, tol: 1e-6, why: "1/2 − 1/4 = 1/4입니다." },
      { q: "상대가 1/3씩 고르게 내면 가장 좋은 수는?", options: O("가위", "바위", "무엇이든 같다"), answer: () => "c", why: "모든 수의 기대 점수가 0입니다." },
    ],
  },
  {
    id: "puz-two-thirds", grade: Z, unit: 4, lesson: "주제 4", title: "평균의 2/3 맞히기 — 상대가 얼마나 생각할지 생각하기", type: "조작", time: "10분",
    tags: ["평균", "게임 이론", "등비수열"], links: ["his-nash", "puz-rps-strategy"],
    desc: "모두가 0부터 100까지 수를 하나씩 내고, 전체 평균의 2/3에 가장 가까운 사람이 이깁니다. 아무 생각 없이 내면 평균은 50, 그러면 33을 내야 하고, 모두가 그렇게 생각하면 22, … 끝까지 생각하면 0(내시 균형)입니다. 하지만 실제 사람들은 몇 단계만 생각하므로, 상대가 '몇 단계 생각할지'를 맞히는 것이 이기는 열쇠입니다.",
    obs: ["k단계 생각한 사람의 답은 50 × (2/3)ᵏ입니다.", "모두가 끝없이 생각하면 0이 균형이지만, 실제 실험의 평균은 보통 20~35 사이입니다.", "경제학자 케인스의 ‘미인 대회’ 비유와 같은 구조입니다."],
    q: "우리 반에서 해 보면 평균의 2/3는 얼마쯤 나올까요?",
    formula: "k단계 답 = 50 × (2/3)ᵏ → 0",
    en: { title: "Guess Two-Thirds of the Average", desc: "Thinking about how others think." },
    view: { x: [-0.6, 10.6], y: [-1.4, 6.4] },
    params: [{ key: "k", label: "생각한 단계 k", min: 0, max: 10, step: 1, value: 2 }, { key: "w", label: "아무 생각 없이(평균 50) 내는 사람 비율 (%)", min: 0, max: 100, step: 5, value: 40 }],
    draw(s, g) { const X = (v) => 0.4 + v * 0.098; g.seg([0.4, 0.6], [10.2, 0.6], { color: "axis", w: 1.4 }); [0, 25, 50, 75, 100].forEach((v) => g.text([X(v), 0.6], `${v}`, { dy: 16, size: 11, color: "muted" })); for (let k = 0; k <= 10; k++) { const v = 50 * (2 / 3) ** k; g.circle([X(v), 2 + k * 0.32], 0.12, { fill: k === s.k ? "a" : "b", fo: 0.8, stroke: false }); if (k <= 4) g.text([X(v), 2 + k * 0.32], `${k}단계 ${fmt(v, 1)}`, { anchor: "start", dx: 8, dy: 4, size: 11 }); } const mine = 50 * (2 / 3) ** s.k, avg = (s.w / 100) * 50 + (1 - s.w / 100) * mine, tgt = (2 / 3) * avg; g.seg([X(tgt), 0.2], [X(tgt), 6], { color: "e", w: 1.6, dash: "5 4" }).text([X(tgt), 6], `평균의 2/3 = ${fmt(tgt, 1)}`, { dy: -4, bold: true, color: "e" }); },
    metrics(s) { const mine = 50 * (2 / 3) ** s.k, avg = (s.w / 100) * 50 + (1 - s.w / 100) * mine; return [["내 답 (k단계)", fmt(mine, 2)], ["예상 평균", fmt(avg, 2)], ["정답(평균의 2/3)", fmt((2 / 3) * avg, 2), "key"]]; },
    predict: [
      { q: "2단계까지 생각한 사람의 답은? (소수 첫째 자리까지)", set: (s) => (s.k = 0), reveal: (s) => (s.k = 2), answer: () => 50 * (4 / 9), tol: 0.05, why: "50 × 4/9 ≈ 22.2입니다." },
      { q: "모두가 완벽하게 끝까지 생각한다면 정답은?", set: (s) => (s.k = 2), reveal: (s) => Object.assign(s, { k: 10, w: 0 }), answer: () => 0, tol: 1e-9, why: "50 × (2/3)ᵏ → 0이 내시 균형입니다. (k = 10에서도 아직 0.87)" },
    ],
  },
];
