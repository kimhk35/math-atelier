// Quantitative teaching pictures. All marks derive from the current model.
const ink='#203a59',grid='#cbd9df',green='#087f71',orange='#c36b29',purple='#7954b9';
const palette=[green,orange,purple];
const esc=v=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const f=v=>String(Number(v.toFixed(4)));
const rational=(n,d)=>{let a=Math.abs(n),b=Math.abs(d);while(b){[a,b]=[b,a%b];}const g=a||1;return d/g===1?String(n/g):`${n/g}/${d/g}`;};
const text=(x,y,value,size=24,color=ink,anchor='middle')=>`<text x="${x}" y="${y}" text-anchor="${anchor}" font-size="${size}" fill="${color}" paint-order="stroke" stroke="#fffaf0" stroke-width="5" stroke-linejoin="round">${esc(value)}</text>`;
const rect=(x,y,w,h,fill='white',stroke=grid,rx=4)=>`<rect x="${x}" y="${y}" width="${Math.max(0,w)}" height="${Math.max(0,h)}" rx="${rx}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`;
const line=(x,y,u,v,color=ink,width=2,dash='')=>`<line x1="${x}" y1="${y}" x2="${u}" y2="${v}" stroke="${color}" stroke-width="${width}" stroke-dasharray="${dash}"/>`;
const circle=(x,y,r=10,color=green)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${color}"/>`;
const poly=(points,fill,stroke=ink)=>`<polygon points="${points.map(p=>p.join(',')).join(' ')}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`;
const dimension=(x,y,u,v,label,color)=>line(x,y,u,v,color,2)+line(x-5,y-5,x+5,y+5,color,2)+line(u-5,v-5,u+5,v+5,color,2)+text((x+u)/2,(y+v)/2+(y===v?29:0),label,23,color,y===v?'middle':'end');
function units(x,y,n,cols=10,cell=25,color=green){let o='';for(let j=0;j<n;j++)o+=circle(x+j%cols*cell,y+Math.floor(j/cols)*cell,cell*.28,color);return o;}
function strip(n,d,y,color,max=1,label=''){
 const width=620/max,x=90,h=48;let o=text(x,y-13,label,23,color,'start');
 o+=rect(x,y,620,h,'white');
 o+=rect(x,y,Math.max(0,n/d)*width,h,color,color,0);
 for(let i=1;i<Math.ceil(max*d);i++)o+=line(x+i*width/d,y,x+i*width/d,y+h,i%d===0?ink:i<n?'#e9fff6':'#8ba5ae',i%d===0?3:1.8);
 for(let i=0;i<=Math.floor(max);i++)o+=line(x+i*width,y-4,x+i*width,y+h+4,ink,2);
 return o;
}
function barRows(values,labels,max=Math.max(1,...values.map(Math.abs)),start=174,step=96){
 return values.map((v,i)=>{
  const y=start+i*step,col=palette[i%3],w=Math.abs(v)/max*440;
  return text(65,y-13,labels[i],22,col,'start')+rect(65,y,440,35,'#eef2f0','none')+rect(65,y,w,35,col,col)+text(555,y+27,f(v),27,col,'start');
 }).join('');
}
export function percentBody(whole,percent,maxWhole,discount=false){
 let o='';const part=whole*percent/100;
 for(let i=0;i<100;i++)o+=rect(65+i%10*26,155+Math.floor(i/10)*26,26,26,i<percent?green:'white',grid,0);
 o+=text(530,184,`${percent}%`,40,green)+text(530,242,`전체 ${whole}`,27)+text(530,298,`${discount?'할인액':'부분'} ${f(part)}`,27,orange);
 const w=280*whole/Math.max(1,maxWhole),x=390,y=353;
 o+=text(x,y-18,'실제 양도 함께 비교해요',21,ink,'start')+rect(x,y,w,42,'#f1cda9',orange)+rect(x,y,w*percent/100,42,green,green);
 o+=text(530,441,discount?`남은 가격 ${f(whole-part)}`:'초록은 부분  주황은 나머지',23,purple)+text(195,463,'100칸은 비율을 나타내요',21);
 return o;
}
function auditBody(l,s,r){
 const a=s.a??0,b=s.b??1,c=s.c??1,d=s.d??1,m=l.mode;let o='';
 if(l.kind==='number'&&m==='count'){
  const slots=Math.max(10,a),cols=Math.min(10,b),rows=Math.ceil(slots/cols),cell=Math.min(48,250/rows),x=(800-cols*cell)/2;
  for(let i=0;i<slots;i++){const xx=x+i%cols*cell,yy=155+Math.floor(i/cols)*cell;o+=rect(xx,yy,cell-2,cell-2,'white');if(i<a)o+=circle(xx+(cell-2)/2,yy+(cell-2)/2,cell*.28,green);}
  return o+text(400,452,a===0?'놓인 물건이 없으면 0개예요':`빈칸은 세지 않고 물건 ${a}개만 세어요`,26,green);
 }
 if(l.kind==='number'&&m==='compare'&&l.year<=2){
  const n=Math.max(1,a,b),cell=Math.min(50,600/n),x=(800-n*cell)/2+cell/2;
  [a,b].forEach((v,i)=>{o+=text(400,145+i*140,`${i+1}번째 수 ${v}`,25,palette[i]);for(let j=0;j<v;j++)o+=circle(x+j*cell,195+i*140,Math.min(17,cell*.32),palette[i]);});
  for(let j=0;j<Math.min(a,b);j++)o+=line(x+j*cell,217,x+j*cell,313,grid,2,'4 5');
  return o+text(400,465,`짝을 짓고 남는 물건 ${Math.abs(a-b)}개`,26,purple);
 }
 if(l.kind==='number'&&m==='compare'&&l.year>=3){
  const digits=Math.max(String(a).length,String(b).length),left=String(a).padStart(digits,'0'),right=String(b).padStart(digits,'0'),first=[...left].findIndex((x,i)=>x!==right[i]),w=620/digits;
  for(let i=0;i<digits;i++){const x=90+i*w;o+=text(x+w/2,150,`${10**(digits-i-1)}의 자리`,19);
   for(let j=0;j<2;j++)o+=rect(x,190+j*105,w-8,75,i===first?'#f6dfc7':'#edf4ef',i===first?orange:grid)+text(x+(w-8)/2,242+j*105,(j?right:left)[i],40,j?purple:green);
  }return o+text(400,455,first<0?'모든 자리의 숫자가 같아요':`높은 자리부터 살펴서 ${10**(digits-first-1)}의 자리에서 달라요`,25);
 }
 if(l.kind==='money'&&m==='compose'){
  [500,100,50,10].forEach((value,i)=>{const n=[a,b,c,s.d??0][i],y=160+i*80;o+=text(65,y+8,`${value}원`,25,palette[i%3],'start');
   for(let j=0;j<n;j++)o+=`<circle cx="${240+j*43}" cy="${y}" r="17" fill="#f3deb0" stroke="#a97c39" stroke-width="2"/>`;
   o+=text(730,y+8,`${n}개`,23,palette[i%3],'end');
  });return o+text(400,479,`동전 ${a+b+c+(s.d??0)}개로 ${r.value}원`,27);
 }
 if(l.kind==='decimal'&&m==='place'){
  [a,b,c].forEach((n,i)=>{const y=170+i*95;o+=text(65,y+20,['0.1씩','0.01씩','0.001씩'][i],24,palette[i],'start');for(let j=0;j<10;j++)o+=rect(220+j*43,y-12,39,42,j<n?palette[i]:'white',grid);o+=text(735,y+20,n,28,palette[i],'end');});
  return o+text(400,479,'칸 1개의 값은 줄마다 달라요',24);
 }
 if(l.kind==='sequence'&&m!=='pattern'){
  const unit=l.modelUnit??l.unit;
  const largest=Math.max(1,...r.values),bound=largest<=5?5:Math.ceil(largest/5)*5,Y=v=>420-v/bound*205;
  o+=line(100,420,730,420,ink,2)+text(78,427,'0',18,ink,'end')+line(100,215,730,215,grid,1,'4 5')+text(78,222,bound,18,ink,'end');
  r.values.forEach((v,i)=>{const x=142+i*80;o+=text(x,155,f(v),String(f(v)).length>4?19:26,green)+text(x,188,m==='table'?`입력 ${unit==='start-groups'?b+i:i+1}`:`${i+1}번째`,17,purple)+rect(x-22,Y(v),44,420-Y(v),green,green);});
  return o+text(400,477,m==='table'?'입력에 대응하는 값의 크기를 비교해요':'값이 커지는 양을 같은 눈금에서 비교해요',24);
 }
 if(l.kind==='decimal'&&m==='mul'&&b>=10){
  const names=['1000','100','10','1','0.1','0.01','0.001'];
  names.forEach((name,i)=>o+=text(140+i*82,145,name,19,purple));
  [a,r.value].forEach((v,j)=>{const digits=String(Math.round(v*1000)).padStart(7,'0');for(let i=0;i<7;i++)o+=rect(103+i*82,170+j*104,74,68,digits[i]==='0'?'#f3f5f3':'#d6eae1',grid)+text(140+i*82,216+j*104,digits[i],33,j?orange:green);});
  const max=l.controls.find(x=>x.key==='a').max*l.controls.find(x=>x.key==='b').max;
  return o+barRows([a,r.value],['처음 수의 크기',`${b}배 한 크기`],max,393,62);
 }
 if(l.kind==='decimal'&&m==='mul'){
  const mx=Math.max(1,Math.ceil(a)),my=Math.max(1,Math.ceil(b)),k=Math.min(490/mx,240/my),X=(800-mx*k)/2,Y=175;
  o+=rect(X,Y,mx*k,my*k,'white')+`<rect data-role="decimal-product" x="${X}" y="${Y+(my-b)*k}" width="${a*k}" height="${b*k}" fill="#a2cdc2"/>`;
  for(let i=1;i<mx*10;i++)o+=line(X+i*k/10,Y,X+i*k/10,Y+my*k,i%10?grid:ink,i%10?1:2);for(let j=1;j<my*10;j++)o+=line(X,Y+j*k/10,X+mx*k,Y+j*k/10,j%10?grid:ink,j%10?1:2);
  return o+text(400,140,'가로와 세로의 작은 눈금은 0.1이에요',23)+text(400,Y+my*k+40,`가로 ${f(a)}`,24,green)+text(X-20,Y+(my-b/2)*k,f(b),24,purple,'end');
 }
 if(l.kind==='decimal'&&m==='div'&&l.controls.find(x=>x.key==='b')?.label==='같게 나눌 수'){
  const maximum=l.controls.find(x=>x.key==='a').max,w=620*a/maximum,x=90;
  o+=text(400,150,`전체 ${a}를 ${b}개의 같은 몫으로`,28)+rect(x,195,w,65,green,green);
  for(let j=1;j<b;j++)o+=line(x+j*w/b,195,x+j*w/b,260,'white',3);
  o+=text(90,320,'그중 한 몫의 크기',24,purple,'start')+rect(x,345,w/b,65,purple,purple);
  return o+text(400,475,`${b}개의 몫을 합하면 처음 양이 돼요`,25);
 }
 if(l.kind==='measure'&&['length','mass','capacity'].includes(m)){
  const length=m==='length',factor=length?((l.modelUnit??l.unit)==='m-cm'?100:10):1000,maximumA=l.controls.find(x=>x.key==='a').max,maximumB=l.controls.find(x=>x.key==='b').max;
  const max=Math.max(factor,Math.ceil((maximumA*factor+maximumB)/factor)*factor),k=620/max,x=90,y=205,unit=length?(factor===100?'cm':'mm'):m==='mass'?'g':'mL';
  o+=text(400,150,r.detail,28)+rect(x,y,a*factor*k,70,green,green)+rect(x+a*factor*k,y,b*k,70,orange,orange);
  o+=line(x,300,x+620,300,ink,2);for(let v=0;v<=max;v+=factor)o+=line(x+v*k,294,x+v*k,311,ink,2)+text(x+v*k,342,v,18);
  return o+text(400,405,`초록 ${a*factor} ${unit} + 주황 ${b} ${unit}`,25)+text(400,470,`눈금의 단위는 ${unit}예요`,23,purple);
 }
 if((l.kind==='number'||l.kind==='decimal')&&m==='round'){
  const low=r.low,high=r.high,mid=(low+high)/2,X=v=>90+(v-low)/(high-low)*620,y=325;
  o+=line(90,y,710,y,ink,3)+line(X(mid),190,X(mid),y,purple,2,'5 5');
  for(let i=0;i<=4;i++){const v=low+(high-low)*i/4;o+=line(X(v),y-9,X(v),y+12,ink,2)+text(X(v),375,f(v),21);}
  o+=circle(X(a),y-70,12,orange)+line(X(a),y-55,X(a),y-15,orange,2,'4 4')+text(X(a),y-100,f(a),30,orange);
  return o+text(400,155,`가운데 경계 ${f(mid)}`,27,purple)+text(400,460,a>=mid?'경계에 있거나 넘으면 큰 쪽으로':'경계보다 작으면 작은 쪽으로',25);
 }
 if(l.kind==='fraction'&&m==='mul'){
  const x=a/b,y=c/d,mx=Math.max(1,Math.ceil(x)),my=Math.max(1,Math.ceil(y)),k=Math.min(490/mx,240/my),X=(800-mx*k)/2,Y=170;
  o+=rect(X,Y,mx*k,my*k,'white')+rect(X,Y,x*k,my*k,'#cee7de')+rect(X,Y+(my-y)*k,mx*k,y*k,'#e5d5ef');
  o+=`<rect data-role="fraction-product" data-area="${x*y}" x="${X}" y="${Y+(my-y)*k}" width="${x*k}" height="${y*k}" fill="${green}"/>`;
  for(let i=1;i<mx*b;i++)o+=line(X+i*k/b,Y,X+i*k/b,Y+my*k,i%b?grid:ink,i%b?1:2);for(let j=1;j<my*d;j++)o+=line(X,Y+j*k/d,X+mx*k,Y+j*k/d,j%d?grid:ink,j%d?1:2);
  o+=text(400,140,`가로 ${a}/${b}  세로 ${c}/${d}`,26)+text(400,470,`겹친 넓이 ${a*c}/${b*d}`,29,green);return o;
 }
 if(l.kind==='solid'&&m==='surface'){
  const k=Math.min(560/(2*a+2*b),220/(c+2*b)),x=100,y=160+b*k,faceColors=['#bde5d9','#e4cdf0','#f1c89e'];
  o+=text(400,135,'여섯 면을 펼쳐서 비교해요',26);
  o+=rect(x,y-b*k,a*k,b*k,faceColors[0],green,0)+rect(x,y+c*k,a*k,b*k,faceColors[0],green,0);
  let offset=x;[a,b,a,b].forEach((w,i)=>{o+=rect(offset,y,w*k,c*k,faceColors[i%2?2:1],ink,0);offset+=w*k;});
  [`위와 아래  ${a} × ${b}인 면 2개`,`앞과 뒤  ${a} × ${c}인 면 2개`,`양옆  ${b} × ${c}인 면 2개`].forEach((label,i)=>o+=rect(130,401+i*32,20,20,faceColors[i],ink)+text(170,420+i*32,label,22,[green,purple,orange][i],'start'));
  return o;
 }
 if(l.kind==='circle'){
  const maximum=l.controls.find(x=>x.key==='a').max,k=130/maximum,rr=a*k,cx=280,cy=280;
  o+=`<circle cx="${cx}" cy="${cy}" r="130" fill="none" stroke="${grid}" stroke-dasharray="5 6"/><circle cx="${cx}" cy="${cy}" r="${rr}" fill="${m==='area'?'#bde5d9':'white'}" stroke="${green}" stroke-width="3"/>`;
  o+=circle(cx,cy,4,ink)+line(m==='diameter'?cx-rr:cx,cy,cx+rr,cy,orange,3)+text(570,218,`반지름 ${a} cm`,26,orange);
  o+=text(570,285,m==='area'?'넓이':m==='diameter'?'지름':'원주',25)+text(570,338,`${f(r.value)} ${m==='area'?'cm²':'cm'}`,28,green);
  o+=line(cx-130,440,cx+130,440,ink,2);for(let i=0;i<=maximum*2;i+=Math.max(1,Math.ceil(maximum/6)))o+=line(cx-130+i*k,435,cx-130+i*k,445,ink,2)+text(cx-130+i*k,469,i,16);
  return o+text(570,463,'같은 길이 눈금으로 비교해요',21);
 }
 if(l.kind==='ratio'&&m==='percent')return percentBody(a,b,l.controls.find(x=>x.key==='a').max,l.id.includes('discount'));
 return null;
}
export function enhancedBody(l,s,r){
 const audited=auditBody(l,s,r);if(audited!==null)return audited;
 const a=s.a??0,b=s.b??1,c=s.c??1,d=s.d??1,m=l.mode;let o='';
 if(l.kind==='number'&&m==='place'){
  const thousand=(l.modelUnit??l.unit)==='thousands',values=[a,b,c],labels=thousand?['1000의 묶음','100의 묶음','남은 수']:['100의 묶음','10의 묶음','낱개'];
  if(l.year===1&&a===0){values.shift();labels.shift();}
  const width=680/values.length;
  values.forEach((n,i)=>{const x=60+i*width,col=palette[i];o+=rect(x,140,width-18,320,'#f1f6f2')+text(x+(width-18)/2,172,labels[i],23,col);
   if(labels[i]==='낱개')o+=units(x+35,218,n,3,38,col);
   else if(!thousand&&labels[i]==='10의 묶음'){
    for(let j=0;j<n;j++){const xx=x+26+j%5*34,yy=200+Math.floor(j/5)*92;o+=rect(xx,yy,20,80,col,col);for(let k=1;k<10;k++)o+=line(xx,yy+k*8,xx+20,yy+k*8,'white',1);}
   }else if(thousand&&i===2){const tens=Math.floor(n/10),ones=n%10;for(let j=0;j<tens;j++)o+=rect(x+22+j%5*33,200+Math.floor(j/5)*65,22,52,col,col);o+=units(x+24,361,ones,5,32,col);}
   else{for(let j=0;j<n;j++){const xx=x+24+j%3*58,yy=200+Math.floor(j/3)*62;o+=rect(xx,yy,48,48,col,col);for(let k=1;k<10;k++)o+=line(xx+k*4.8,yy,xx+k*4.8,yy+48,'#ffffffb0',.7)+line(xx,yy+k*4.8,xx+48,yy+k*4.8,'#ffffffb0',.7);if(thousand&&i===0)o+=poly([[xx,yy],[xx+9,yy-9],[xx+57,yy-9],[xx+48,yy]],'#88bfb0',col)+poly([[xx+48,yy],[xx+57,yy-9],[xx+57,yy+39],[xx+48,yy+48]],'#4b9a89',col);}}
   o+=text(x+(width-18)/2,435,`${n}${labels[i]==='낱개'||thousand&&i===2?'개':'묶음'}`,29,col);
  });return o;
 }
 if(l.kind==='number'&&['add','sub','equation'].includes(m)){
  const second=m==='equation'?b-a:b,total=m==='sub'?a:a+second,scale=620/Math.max(1,a,b,total),x=90;
  if(second<0)return null;
  if(m==='sub'){
   const left=a-b;if(left<0)return null;
   o+=text(400,158,`처음 ${a}개`,28)+rect(x,195,620,82,'#e8efeb')+rect(x,195,left*scale,82,green,green)+rect(x+left*scale,195,b*scale,82,'#f7dfca',orange);
   for(let k=1;b>0&&k<=5;k++){const xx=x+left*scale+b*scale*k/6;o+=line(xx-8,211,xx+8,260,orange,2);}
   o+=text(245,328,`남은 양 ${left}`,29,green)+text(580,328,`덜어 낸 양 ${b}`,27,orange);
   if(a<=40){for(let j=0;j<a;j++)o+=circle(100+j%20*29,385+Math.floor(j/20)*29,8,j<left?green:orange);}
  }else{
   o+=text(200,156,`첫째 양 ${a}`,27,green)+text(600,156,`더할 양 ${second}`,27,orange);
   o+=rect(x,200,a*scale,80,green,green)+rect(x+a*scale,200,second*scale,80,orange,orange);
   if(total<=30){for(let j=1;j<total;j++)o+=line(x+j*scale,204,x+j*scale,276,'white',2);}
   o+=dimension(x,313,x+total*scale,313,`전체 ${total}`,purple);
   o+=text(400,415,'두 색의 길이를 이어서 전체를 확인해요',24);
  }return o;
 }
 if(l.kind==='number'&&['mul','multiple'].includes(m)&&Number.isInteger(a)&&Number.isInteger(b)&&a<=40&&b<=12){
  const cell=Math.min(50,600/Math.max(1,a),200/Math.max(1,b)),x=(800-a*cell)/2,y=175;
  o+=text(400,140,`한 줄 ${a}개를 ${b}줄`,28);
  for(let j=0;j<b;j++)for(let i=0;i<a;i++)o+=rect(x+i*cell,y+j*cell,cell,cell,i<Math.floor(a/10)*10?green:orange,'white',2);
  o+=dimension(x,y+b*cell+20,x+a*cell,y+b*cell+20,`모두 ${a*b}개`,purple);
  if(a>=10)o+=text(400,465,`${Math.floor(a/10)*10}개씩 ${b}줄 + ${a%10}개씩 ${b}줄`,23);
  return o;
 }
 if(l.kind==='number'&&m==='div'&&Number.isInteger(a)&&Number.isInteger(b)){
  const grouped=/묶음.*개수|한 묶음|한 번에/.test(l.controls.find(x=>x.key==='b')?.label||'');
  const groups=grouped?r.quotient:b,each=grouped?b:r.quotient,shown=Math.min(12,groups),cols=Math.min(4,Math.max(1,shown)),rows=Math.max(1,Math.ceil(shown/cols)),w=660/cols,h=240/rows;
  for(let i=0;i<shown;i++){const x=70+i%cols*w,y=145+Math.floor(i/cols)*h;const cell=Math.min(22,(w-30)/Math.min(8,Math.max(1,each)),(h-42)/Math.max(1,Math.ceil(Math.min(each,40)/8)));
   o+=rect(x,y,w-12,h-10,'#edf5f1')+text(x+(w-12)/2,y+25,`${i+1}${grouped?'묶음':'번 사람'}`,18,green);
   if(each<=40)o+=units(x+20,y+43,each,8,cell,green);
   else o+=text(x+(w-12)/2,y+h*.7,`${each}개`,30,green);
  }
  o+=text(70,427,`나머지 ${r.remainder}개`,24,orange,'start');
  if(groups===0){o+=text(400,200,`한 묶음에 ${b}개가 필요해요`,27,green);for(let j=0;j<b;j++)o+=rect(130+j%15*36,255+Math.floor(j/15)*42,32,36,'#edf5f1')+(j<r.remainder?circle(146+j%15*36,273+Math.floor(j/15)*42,9,orange):'');}
  if(groups>0&&r.remainder<=18)o+=units(270,420,r.remainder,18,24,orange);
  if(groups>12)o+=text(400,475,`전체 ${groups}묶음 중 12묶음을 보여요`,23);
  else o+=text(400,475,`${groups} × ${each} + ${r.remainder} = ${a}`,28);
  return o;
 }
 if(l.kind==='number'&&m==='lcm'){
  const max=Math.max(1,r.value),X=n=>100+n/max*600;
  [a,b].forEach((step,i)=>{const y=210+i*130;o+=text(70,y-52,`${step}씩 뛰어 세기`,24,palette[i],'start')+line(100,y,700,y,grid,3);
   const count=Math.floor(max/step),stride=Math.max(1,Math.ceil(count/60));for(let k=1;k<=count;k+=stride)o+=circle(X(k*step),y,4,palette[i]);
   o+=circle(X(max),y,13,palette[i])+text(X(max),y-20,max,24,palette[i]);
   const first=Array.from({length:Math.min(6,count)},(_,k)=>(k+1)*step);
   o+=text(400,y+40,first.join(' → ')+(count>6?' → … → '+max:''),22,palette[i]);
  });return o;
 }
 if(l.kind==='fraction'){
  const x=a/b,y=c/d,max=Math.max(1,Math.ceil(x),m==='equivalent'&&s.d===undefined?Math.ceil(x):Math.ceil(y),m==='add'?Math.ceil(x+y):0);
  if(m==='mul'){
   if(x>1||y>1)return null;
   const X=150,Y=155,W=440,H=250;
   o+=rect(X,Y,W,H,'white')+rect(X,Y,x*W,H,'#c4e8de')+rect(X,Y+(1-y)*H,W,y*H,'#e8d9f2')+rect(X,Y+(1-y)*H,x*W,y*H,green,green);
   for(let i=1;i<b;i++)o+=line(X+i*W/b,Y,X+i*W/b,Y+H,ink,1);for(let j=1;j<d;j++)o+=line(X,Y+j*H/d,X+W,Y+j*H/d,ink,1);
   o+=text(370,135,`가로의 ${a}/${b}`,25,green)+text(615,280,`${c}/${d}`,27,purple,'start')+text(400,462,`겹친 부분은 ${a*c}/${b*d}`,30,green);return o;
  }
  o+=strip(a,b,160,green,max,`첫째 양 ${a}/${b}`);
  if(['show','mixed'].includes(m))return o+text(400,304,`전체 1을 ${b}등분한 조각 ${a}개`,28)+text(400,390,`색칠한 양 ${a}/${b}`,34,green);
  const nn=m==='equivalent'&&s.d===undefined?a*c:c,dd=m==='equivalent'&&s.d===undefined?b*c:d;
  o+=strip(nn,dd,280,orange,max,`둘째 양 ${nn}/${dd}`);
  if(m==='add'||m==='sub'){
   let g=b,h=d;while(h){[g,h]=[h,g%h];}const den=b*d/g,n=a*(den/b)+(m==='add'?1:-1)*c*(den/d);if(n>=0)o+=strip(n,den,410,purple,max,`계산한 양 ${n}/${den}`);
   else o+=text(400,433,`결과 ${f(r.value)}`,31,purple);
  }else if(m==='div'){
   const count=Math.min(30,Math.floor(x/y)),unitWidth=y*620/max;
   for(let j=0;j<count;j++)o+=line(90+j*unitWidth,153,90+j*unitWidth,215,'white',4);
   o+=text(400,415,`첫째 양 안에 둘째 양이 ${rational(a*d,b*c)}번`,29,purple);
  }else o+=text(400,420,m==='equivalent'?'전체 길이가 같은지 비교해요':'같은 전체를 기준으로 색칠한 길이를 비교해요',24);
  return o;
 }
 if(l.kind==='geometry'&&m==='rectangle'||l.kind==='measure'&&m==='perimeter'){
  const k=Math.min(48,500/Math.max(1,l.controls.find(c=>c.key==='a')?.max??1),235/Math.max(1,l.controls.find(c=>c.key==='b')?.max??1)),w=a*k,h=b*k,x=(800-w)/2,y=160;
  o+=rect(x,y,w,h,'#dcefe9',green,0);
  if(l.year>=5)for(let i=1;i<a;i++)o+=line(x+i*k,y,x+i*k,y+h,grid,1);
  if(l.year>=5)for(let j=1;j<b;j++)o+=line(x,y+j*k,x+w,y+j*k,grid,1);
  for(const [xx,yy,dx,dy] of [[x,y,1,1],[x+w,y,-1,1],[x,y+h,1,-1],[x+w,y+h,-1,-1]])o+=line(xx+dx*14,yy,xx+dx*14,yy+dy*14,purple,2)+line(xx,yy+dy*14,xx+dx*14,yy+dy*14,purple,2);
  o+=line(x,y,x+w,y,green,5)+line(x,y+h,x+w,y+h,green,5)+line(x,y,x,y+h,orange,5)+line(x+w,y,x+w,y+h,orange,5);
  o+=text(400,y-17,`가로 ${a}`,25,green)+text(400,y+h+33,`가로 ${a}`,25,green)+text(x-18,y+h/2+7,b,26,orange,'end')+text(x+w+18,y+h/2+7,b,26,orange,'start');
  o+=text(400,475,m==='perimeter'?'네 변을 따라 길이를 모두 더해요':'같은 색의 마주 보는 변은 길이가 같아요',24);
  return o;
 }
 if(l.kind==='geometry'&&m==='angle'){
  const cx=400,cy=300,rr=145,t=a*Math.PI/180;
  for(let angle=0;angle<=360;angle+=30){const z=angle*Math.PI/180;o+=line(cx+(rr-10)*Math.cos(z),cy-(rr-10)*Math.sin(z),cx+rr*Math.cos(z),cy-rr*Math.sin(z),grid,2);if(angle<360)o+=text(cx+(rr+28)*Math.cos(z),cy-(rr+28)*Math.sin(z)+6,`${angle}°`,18);}
  const pts=[[cx,cy]];for(let j=0;j<=60;j++){const z=t*j/60;pts.push([cx+70*Math.cos(z),cy-70*Math.sin(z)]);}o+=poly(pts,'#d4e9e2','none')+line(cx,cy,cx+rr,cy,green,5)+line(cx,cy,cx+rr*Math.cos(t),cy-rr*Math.sin(t),orange,5)+circle(cx,cy,6,ink)+text(690,190,`${a}°`,36,purple);
  return o;
 }
 if(l.kind==='chart'&&['bar','average','line'].includes(m)){
  const vs=r.values,max=Math.max(1,...vs),top=Math.ceil(max/5)*5,Y=v=>425-v/top*245,X=[210,400,590];
  for(let i=0;i<=5;i++){const v=top*i/5,y=Y(v);o+=line(110,y,710,y,grid,1)+text(92,y+7,f(v),18,ink,'end');}
  o+=line(110,170,110,425,ink,2)+line(110,425,710,425,ink,2);
  if(m==='line')for(let i=0;i<2;i++)o+=line(X[i],Y(vs[i]),X[i+1],Y(vs[i+1]),green,4);
  vs.forEach((v,i)=>{o+=m==='line'?circle(X[i],Y(v),9,palette[i]):rect(X[i]-46,Y(v),92,425-Y(v),palette[i],palette[i]);o+=text(X[i],Y(v)-16,v,26,palette[i])+text(X[i],468,`${i+1}번째`,24);});
  if(m==='average')o+=line(110,Y(r.mean),710,Y(r.mean),purple,3,'7 5')+text(400,136,`합 ${r.total} ÷ 3 ${r.total%3?'≈':'='} 평균 ${f(r.mean)}`,27,purple);
  return o;
 }
 if(l.kind==='sequence'&&m!=='pattern'){
  const values=r.values,cols=4,w=164,h=108,x0=64,y0=158;
  values.forEach((v,i)=>{const x=x0+i%cols*174,y=y0+Math.floor(i/cols)*h;o+=rect(x,y,w,82,'#eff6f3')+text(x+w/2,y+25,`${i+1}번째`,17,purple)+text(x+w/2,y+62,f(v),String(f(v)).length>8?18:29,green);});return o;
 }
 if(l.kind==='ratio'&&!['percent','sharing'].includes(m)){
  if(m==='scale')return barRows([a,r.value],['그림의 길이','실제 길이'],Math.max(a,r.value,1),185,145)+text(400,460,`같은 비율로 ${s.c??b}배`,25,purple);
  const k=s.c===undefined?1:c,max=Math.max(a,b,a*k,b*k,1);
  return barRows([a,b,a*k,b*k],['처음의 첫째 양','처음의 둘째 양',`${k}배 한 첫째 양`,`${k}배 한 둘째 양`],max,148,83);
 }
 if(l.kind==='decimal'&&m==='show'){
  const count=Math.max(1,Math.ceil(a)),cell=Math.min(20,600/count/10),width=cell*10,gap=24,x0=(800-(count*width+(count-1)*gap))/2;
  for(let u=0;u<count;u++){const x=x0+u*(width+gap),filled=Math.min(100,Math.max(0,Math.round((a-u)*100)));o+=text(x+width/2,167,`전체 1`,23,green);
   for(let i=0;i<100;i++)o+=rect(x+i%10*cell,190+Math.floor(i/10)*cell,cell,cell,i<filled?green:'white',grid,0);
   o+=text(x+width/2,190+10*cell+35,`${filled}/100`,23,green);
  }return o+text(400,477,'전체 1마다 100칸으로 똑같이 나누어요',23);
 }
 if(l.kind==='decimal'&&['compare','add','sub'].includes(m)){
  const vs=m==='compare'?[a,b]:[a,b,r.value],max=Math.max(1,...vs.map(Math.abs));
  return barRows(vs,['첫째 소수','둘째 소수','계산 결과'],max,170,105);
 }
 if(l.kind==='measure'&&m==='compare')return barRows([a,b],['첫째 길이','둘째 길이'],Math.max(a,b,1),190,140)+text(400,460,`시작을 맞추고 차이 ${Math.abs(a-b)}를 비교해요`,24);
 if(l.kind==='measure'&&m==='time'){
  const elapsed=(l.modelUnit??l.unit)==='elapsed-clock',start=60*a+b,end=start+(s.c??0),cx=260,cy=285,rr=120;
  function clock(x,y,total,color){let q=`<circle cx="${x}" cy="${y}" r="${rr}" fill="white" stroke="${grid}" stroke-width="3"/>`;
   for(let i=1;i<=12;i++){const t=i*Math.PI/6;q+=text(x+rr*.8*Math.sin(t),y-rr*.8*Math.cos(t)+6,i,17);}
   for(const [angle,len,width] of [[(total%720)/2,65,7],[(total%60)*6,92,4]]){const t=angle*Math.PI/180;q+=line(x,y,x+len*Math.sin(t),y-len*Math.cos(t),color,width);}return q+circle(x,y,6,color);
  }
  if(elapsed){o+=clock(220,290,start,green)+clock(580,290,end,orange)+text(220,143,`${a}시 ${b}분`,27,green)+text(580,143,`${end>=1440?'다음 날 ':''}${Math.floor(end/60)%24}시 ${end%60}분`,27,orange)+text(400,290,'→',36,purple)+text(400,467,`${s.c??0}분이 지났어요`,28,purple);return o;}
  return barRows([60*a,b,s.c??0],['시간 부분을 분으로','분 부분','더 흐른 분'],Math.max(1,60*a,b,s.c??0),165,100);
 }
 if(l.kind==='solid'&&['box','surface','cubes'].includes(m)){
  const k=Math.min(34,500/Math.max(1,a+b),250/Math.max(1,c+(a+b)*.42)),mid=300+c*k/2;
  const p=(x,y,z)=>[400+(x-y-(a-b)/2)*k,mid+(x+y-(a+b)/2)*k*.42-z*k];
  o+=poly([p(0,0,c),p(a,0,c),p(a,b,c),p(0,b,c)],'#d4ebe3',green)+poly([p(a,0,0),p(a,b,0),p(a,b,c),p(a,0,c)],'#8fbdc8',green)+poly([p(0,b,0),p(a,b,0),p(a,b,c),p(0,b,c)],'#38978b',green);
  if(m!=='surface'){
   for(let x=1;x<a;x++)o+=line(...p(x,b,0),...p(x,b,c),'white',1.5)+line(...p(x,0,c),...p(x,b,c),'white',1.5);
   for(let y=1;y<b;y++)o+=line(...p(a,y,0),...p(a,y,c),'white',1.5)+line(...p(0,y,c),...p(a,y,c),'white',1.5);
   for(let z=1;z<c;z++)o+=line(...p(0,b,z),...p(a,b,z),'white',1.5)+line(...p(a,0,z),...p(a,b,z),'white',1.5);
  }
  o+=text(400,146,`가로 ${a}  세로 ${b}  높이 ${c}`,26);
  return o+text(400,468,m==='surface'?`같은 넓이의 면이 3쌍이에요`:`한 층 ${a*b}개 × ${c}층 = ${a*b*c}개`,26,purple);
 }
 return null;
}
