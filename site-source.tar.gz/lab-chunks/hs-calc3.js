import { criticalRoots } from "./critical-roots.js";
// 미적분Ⅰ — Ⅲ 도함수의 활용 · Ⅳ 적분 (17차 이후 추가)
import { fmt, frac, clamp } from "./hs-core.js";

const G = 7;
// 함수 모음: f, 도함수 d, 극값의 x좌표 crit, 표시 이름
const F = {
  c1: { f: (x) => x ** 3 - 3 * x, d: (x) => 3 * x * x - 3, crit: [-1, 1], name: "x³ − 3x" },
  c2: { f: (x) => x ** 3 - 3 * x * x, d: (x) => 3 * x * x - 6 * x, crit: [0, 2], name: "x³ − 3x²" },
  q4: { f: (x) => x ** 4 / 4 - 2 * x * x, d: (x) => x ** 3 - 4 * x, crit: [-2, 0, 2], name: "x⁴/4 − 2x²" },
  c3: { f: (x) => -(x ** 3) + 3 * x + 1, d: (x) => -3 * x * x + 3, crit: [-1, 1], name: "−x³ + 3x + 1" },
};
const opts = (keys) => keys.map((k) => [k, "y = " + F[k].name]);
function simpson(f, a, b, n = 400) { if (a === b) return 0; const h = (b - a) / n; let s = f(a) + f(b); for (let i = 1; i < n; i++) s += (i % 2 ? 4 : 2) * f(a + i * h); return (s * h) / 3; }
// f(x) = k의 실근 (부호 변화 + 극값에서 접하는 경우)
function rootsOf(fn, k, lo = -6, hi = 6) { return criticalRoots(x => fn.f(x) - k, fn.crit, lo, hi); }

export default [
  // ───────── Ⅲ 도함수의 활용 ─────────
  {
    id: "calc1-closed-maxmin", grade: G, unit: 3, lesson: "Ⅲ-4", title: "닫힌구간에서 함수의 최댓값과 최솟값", type: "조작", time: "12분",
    tags: ["최댓값", "최솟값", "극값"], links: ["calc-derivative-graph", "cm1-minmax-interval"],
    desc: "닫힌구간 [a, b]의 양 끝을 움직이며, 최댓값과 최솟값이 구간 안의 극값과 양 끝값 가운데에서 생긴다는 것을 후보 표로 확인합니다.",
    obs: ["닫힌구간에서 연속인 함수는 반드시 최댓값과 최솟값을 가집니다.", "후보는 구간 안의 극값(f′(x) = 0인 점)과 구간 양 끝의 함숫값입니다.", "극댓값이 항상 최댓값인 것은 아닙니다. 양 끝값이 더 클 수 있습니다."],
    q: "극댓값보다 큰 값이 구간 끝에서 나오려면 구간을 어떻게 잡아야 할까요?",
    formula: "최댓값·최솟값 후보: f(a), f(b), 구간 안에서 f′(x) = 0인 x의 함숫값",
    en: { title: "Extreme Values on a Closed Interval", desc: "Compare critical values with endpoint values." },
    view: { x: [-3.5, 4.5], y: [-6, 4] },
    params: [
      { key: "fn", label: "함수", type: "select", value: "c2", options: opts(["c2", "c1", "c3"]) },
      { key: "a", label: "구간의 왼쪽 끝 a", min: -3, max: 4, step: 0.25, value: -1 },
      { key: "b", label: "구간의 오른쪽 끝 b", min: -3, max: 4, step: 0.25, value: 3 },
    ],
    derive(s) { if (s.b < s.a) [s.a, s.b] = [s.b, s.a]; if (s.b === s.a) { if (s.b < 4) s.b += 0.25; else s.a -= 0.25; } },
    cand(s) { const fn = F[s.fn], c = [["a", s.a, fn.f(s.a)], ["b", s.b, fn.f(s.b)]]; fn.crit.filter((x) => x > s.a && x < s.b).forEach((x) => c.push(["극값", x, fn.f(x)])); return c; },
    drags: { A: { at: (s) => [s.a, 0], move: (s, p) => (s.a = clamp(Math.round(p[0] * 4) / 4, -3, s.b - 0.25)), color: "a", label: "a" }, B: { at: (s) => [s.b, 0], move: (s, p) => (s.b = clamp(Math.round(p[0] * 4) / 4, s.a + 0.25, 4)), color: "a", label: "b" } },
    draw(s, g) {
      const fn = F[s.fn], C = this.cand(s), mx = C.reduce((m, c) => (c[2] > m[2] + 1e-9 ? c : m)), mn = C.reduce((m, c) => (c[2] < m[2] - 1e-9 ? c : m));
      g.grid();
      g.fx(fn.f, { color: "muted", w: 1.6, dash: "6 5" }).fx(fn.f, { from: s.a, to: s.b, color: "b", w: 4 });
      g.seg([s.a, 0], [s.a, fn.f(s.a)], { color: "muted", w: 1.1, dash: "3 4" }).seg([s.b, 0], [s.b, fn.f(s.b)], { color: "muted", w: 1.1, dash: "3 4" });
      C.forEach(([t, x, y]) => g.point([x, y], "", { color: t === "극값" ? "e" : "muted", r: 4.5, hollow: true }));
      g.point([mx[1], mx[2]], `최대 ${fmt(mx[2])}`, { color: "d", r: 6.5 }).point([mn[1], mn[2]], `최소 ${fmt(mn[2])}`, { color: "c", r: 6.5, dy: 22 });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], `y = ${fn.name}`, { anchor: "start", bold: true, color: "b" });
    },
    metrics(s) {
      const C = this.cand(s), mx = Math.max(...C.map((c) => c[2])), mn = Math.min(...C.map((c) => c[2]));
      return [
        ["후보", C.map(([t, x, y]) => `f(${fmt(x)}) = ${fmt(y, 3)}`).join(",  ")],
        ["최댓값", fmt(mx, 3), "key"],
        ["최솟값", fmt(mn, 3), "key"],
      ];
    },
    predict: [
      { q: "f(x) = x³ − 3x²의 구간 [−1, 3]에서 최댓값은?", set: (s) => Object.assign(s, { fn: "c2", a: -1, b: 1 }), reveal: (s) => (s.b = 3), answer: () => 0, why: "후보 f(−1) = −4, f(0) = 0, f(2) = −4, f(3) = 0 가운데 가장 큰 값은 0입니다(x = 0, x = 3)." },
      { q: "같은 함수의 구간 [−1, 4]에서 최댓값은?", set: (s) => Object.assign(s, { fn: "c2", a: -1, b: 3 }), reveal: (s) => (s.b = 4), answer: () => 16, why: "f(4) = 64 − 48 = 16이 극댓값 f(0) = 0보다 큽니다. 최댓값이 구간 끝에서 생겼습니다." },
    ],
  },
  {
    id: "calc1-roots-k", grade: G, unit: 3, lesson: "Ⅲ-5", title: "방정식 f(x) = k의 실근의 개수", type: "조작", time: "12분",
    tags: ["실근의 개수", "극값", "교점"], links: ["calc-derivative-graph", "calc1-closed-maxmin", "cm1-quad-line"],
    desc: "방정식 f(x) = k의 실근의 개수를 곡선 y = f(x)와 직선 y = k의 교점의 개수로 바꾸어, 직선을 위아래로 움직이며 극댓값·극솟값에서 개수가 바뀌는 것을 확인합니다.",
    obs: ["f(x) = k의 실근은 y = f(x)와 y = k의 교점의 x좌표입니다.", "k가 극댓값이나 극솟값과 같을 때 직선이 곡선에 접해 실근의 개수가 바뀝니다.", "삼차함수 x³ − 3x에서 −2 < k < 2이면 서로 다른 실근이 3개입니다."],
    q: "x³ − 3x − k = 0이 서로 다른 세 실근을 가지려면 k의 범위는?",
    formula: "f(x) = k의 실근 ⇔ y = f(x)와 y = k의 교점",
    en: { title: "Number of Real Roots of f(x) = k", desc: "Slide the line y = k across the curve." },
    view: { x: [-4, 4], y: [-5.5, 5] },
    params: [
      { key: "fn", label: "함수", type: "select", value: "c1", options: opts(["c1", "q4", "c2"]) },
      { key: "k", label: "직선 y = k의 k", min: -5, max: 4.5, step: 0.25, value: 1 },
    ],
    anim: { key: "k", min: -5, max: 4.5, speed: 1.5, loop: "bounce", label: "직선 움직이기" },
    drags: { K: { at: (s) => [3.3, s.k], move: (s, p) => (s.k = clamp(Math.round(p[1] * 4) / 4, -5, 4.5)), color: "a", label: "y = k" } },
    draw(s, g) {
      const fn = F[s.fn], R = rootsOf(fn, s.k);
      g.grid();
      fn.crit.forEach((c) => { const v = fn.f(c); g.line([0, v], [1, v], { color: "e", w: 1, dash: "3 5", opacity: 0.8 }); g.text([g.xr[0], v], `y = ${fmt(v)}`, { anchor: "start", dx: 4, dy: -4, size: 11, color: "e" }); g.point([c, v], "", { color: "e", r: 4 }); });
      g.fx(fn.f, { color: "b", w: 3.2 });
      g.line([0, s.k], [1, s.k], { color: "a", w: 2.6 });
      R.forEach((x) => g.point([x, s.k], "", { color: "a", r: 6 }));
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], `y = ${fn.name}`, { anchor: "start", bold: true, color: "b" });
    },
    metrics(s) {
      const fn = F[s.fn], R = rootsOf(fn, s.k), ex = fn.crit.map((c) => fmt(fn.f(c))).join(", ");
      return [
        ["실근의 개수", `${R.length}개`, "key"],
        ["실근", R.length ? R.map((x) => fmt(x, 3)).join(", ") : "없음"],
        ["극값", ex],
      ];
    },
    predict: [
      { q: "x³ − 3x = 1의 서로 다른 실근은 몇 개일까요?", set: (s) => Object.assign(s, { fn: "c1", k: -4 }), reveal: (s) => (s.k = 1), answer: () => 3, why: "1은 극솟값 −2와 극댓값 2 사이에 있으므로 직선 y = 1은 곡선과 세 점에서 만납니다." },
      { q: "x³ − 3x = 2의 서로 다른 실근은 몇 개일까요?", set: (s) => Object.assign(s, { fn: "c1", k: -4 }), reveal: (s) => (s.k = 2), answer: () => 2, why: "k가 극댓값 2와 같으므로 x = −1에서 접하고 다른 한 점(x = 2)에서 만나 2개입니다." },
      { q: "x⁴/4 − 2x² = −1의 서로 다른 실근은 몇 개일까요?", set: (s) => Object.assign(s, { fn: "q4", k: 2 }), reveal: (s) => (s.k = -1), answer: () => 4, why: "극솟값 −4 < −1 < 극댓값 0이므로 W 모양 곡선과 네 점에서 만납니다." },
    ],
  },
  // ───────── Ⅳ 적분 ─────────
  {
    id: "calc1-antiderivative", grade: G, unit: 4, lesson: "Ⅳ-1", title: "부정적분과 적분상수 C — 기울기가 같은 곡선들", type: "조작", time: "10분",
    tags: ["부정적분", "적분상수", "도함수"], links: ["calc-derivative-graph", "calc1-definite-sign"],
    desc: "도함수가 f(x)인 함수는 하나가 아니라 위아래로 평행이동한 곡선 무리 F(x) + C임을 보고, 같은 x에서 모든 곡선의 접선 기울기가 f(x)로 같다는 것과 한 점의 조건으로 C가 정해지는 것을 확인합니다.",
    obs: ["F′(x) = f(x)이면 (F(x) + C)′ = f(x)이므로 부정적분은 F(x) + C 꼴입니다.", "같은 x에서 곡선 무리의 접선은 모두 평행합니다.", "곡선이 지나는 한 점을 정하면 적분상수 C가 하나로 정해집니다."],
    q: "f(x) = 2x이고 F(0) = 3인 함수 F(x)는 무엇일까요?",
    formula: "∫ f(x) dx = F(x) + C (F′(x) = f(x))",
    en: { title: "Antiderivatives and the Constant C", desc: "A family of curves with the same slopes." },
    view: { x: [-3.5, 3.5], y: [-4.5, 6.5] },
    params: [
      { key: "fn", label: "f(x)", type: "select", value: "lin", options: [["lin", "f(x) = 2x"], ["quad", "f(x) = 3x² − 3"], ["const", "f(x) = −1"]] },
      { key: "C", label: "적분상수 C", min: -3, max: 3, step: 0.25, value: 1 },
      { key: "t", label: "기울기를 볼 x", min: -2.5, max: 2.5, step: 0.1, value: 1 },
    ],
    anim: { key: "C", min: -3, max: 3, speed: 1.5, loop: "bounce", label: "C 바꾸기" },
    FN: { lin: { F: (x) => x * x, f: (x) => 2 * x, Fs: "x²", fs: "2x" }, quad: { F: (x) => x ** 3 - 3 * x, f: (x) => 3 * x * x - 3, Fs: "x³ − 3x", fs: "3x² − 3" }, const: { F: (x) => -x, f: () => -1, Fs: "−x", fs: "−1" } },
    drags: { P: { at: (s) => [0, s.C + (s.fn === "quad" || s.fn === "lin" || s.fn === "const" ? 0 : 0)], move: (s, p) => (s.C = clamp(Math.round(p[1] * 4) / 4, -3, 3)), color: "a", label: "(0, C)" } },
    draw(s, g) {
      const D = this.FN[s.fn];
      g.grid();
      for (let c = -3; c <= 3; c++) if (Math.abs(c - s.C) > 1e-9) { g.fx((x) => D.F(x) + c, { color: "muted", w: 1.3, opacity: 0.7 }); const y = D.F(s.t) + c, m = D.f(s.t), u = 0.5 / Math.sqrt(1 + m * m); g.seg([s.t - u, y - m * u], [s.t + u, y + m * u], { color: "e", w: 1.8 }); }
      g.fx((x) => D.F(x) + s.C, { color: "a", w: 3.4 });
      const y = D.F(s.t) + s.C, m = D.f(s.t), u = 0.8 / Math.sqrt(1 + m * m);
      g.seg([s.t - u, y - m * u], [s.t + u, y + m * u], { color: "d", w: 3 });
      g.line([s.t, 0], [s.t, 1], { color: "e", w: 1, dash: "3 4" });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], `F(x) = ${D.Fs} + C`, { anchor: "start", bold: true, color: "a" });
    },
    metrics(s) {
      const D = this.FN[s.fn];
      return [
        ["∫ f(x) dx", `∫ (${D.fs}) dx = ${D.Fs} + C`, "key"],
        ["지금 곡선", `y = ${D.Fs}${s.C ? ` ${s.C > 0 ? "+" : "−"} ${fmt(Math.abs(s.C))}` : ""}`],
        [`x = ${fmt(s.t)}에서 기울기`, `모든 곡선이 f(${fmt(s.t)}) = ${fmt(D.f(s.t), 3)}`],
        ["F(0)", fmt(D.F(0) + s.C)],
      ];
    },
    predict: [
      { q: "f(x) = 2x이고 F(0) = 3이면 적분상수 C는?", set: (s) => Object.assign(s, { fn: "lin", C: 0 }), reveal: (s) => (s.C = 3), answer: () => 3, why: "F(x) = x² + C에서 F(0) = C = 3이므로 F(x) = x² + 3입니다." },
      { q: "f(x) = 3x² − 3일 때, x = 2에서 곡선 무리의 접선 기울기는 모두 얼마일까요?", set: (s) => Object.assign(s, { fn: "quad", t: 0 }), reveal: (s) => (s.t = 2), answer: () => 9, why: "모든 곡선의 도함수가 f(x)이므로 기울기는 f(2) = 12 − 3 = 9로 같습니다." },
    ],
  },
  {
    id: "calc1-definite-sign", grade: G, unit: 4, lesson: "Ⅳ-4", title: "정적분의 부호 — x축 아래의 넓이는 빼진다", type: "조작", time: "12분",
    tags: ["정적분", "넓이", "부호"], links: ["calc-riemann", "calc-area-between", "calc1-antiderivative"],
    desc: "구간 [a, b]를 움직이며 x축 위의 부분(양수)과 아래의 부분(음수)이 정적분에서 서로 상쇄되는 것을 보고, 정적분 값과 실제 넓이 ∫|f(x)|dx를 비교합니다.",
    obs: ["f(x) ≥ 0인 구간의 정적분은 넓이와 같고, f(x) ≤ 0이면 넓이에 −를 붙인 값입니다.", "위아래 넓이가 같으면 정적분이 0이 될 수 있습니다.", "넓이를 구할 때는 x축과 만나는 점에서 구간을 나누어 |f(x)|를 적분합니다."],
    q: "∫₋₁¹ x³ dx가 0인 까닭을 그림으로 설명해 봅시다.",
    formula: "∫ₐᵇ f(x) dx = (위쪽 넓이) − (아래쪽 넓이) · 넓이 = ∫ₐᵇ |f(x)| dx",
    en: { title: "Sign of a Definite Integral", desc: "Areas below the x-axis count negatively." },
    view: { x: [-3, 3.5], y: [-3, 4] },
    params: [
      { key: "fn", label: "f(x)", type: "select", value: "cube", options: [["cube", "f(x) = x³ − x"], ["para", "f(x) = x² − 1"], ["line", "f(x) = x − 1"]] },
      { key: "a", label: "아래끝 a", min: -2.5, max: 3, step: 0.25, value: -1 },
      { key: "b", label: "위끝 b", min: -2.5, max: 3, step: 0.25, value: 1.5 },
    ],
    FN: { cube: { f: (x) => x ** 3 - x, F: (x) => x ** 4 / 4 - (x * x) / 2, n: "x³ − x" }, para: { f: (x) => x * x - 1, F: (x) => x ** 3 / 3 - x, n: "x² − 1" }, line: { f: (x) => x - 1, F: (x) => (x * x) / 2 - x, n: "x − 1" } },
    derive(s) { if (s.b < s.a) { const t = s.a; s.a = s.b; s.b = t; } },
    drags: { A: { at: (s) => [s.a, 0], move: (s, p) => (s.a = clamp(Math.round(p[0] * 4) / 4, -2.5, 3)), color: "a", label: "a" }, B: { at: (s) => [s.b, 0], move: (s, p) => (s.b = clamp(Math.round(p[0] * 4) / 4, -2.5, 3)), color: "a", label: "b" } },
    vals(s) { const D = this.FN[s.fn], I = D.F(s.b) - D.F(s.a), pos = simpson((x) => Math.max(0, D.f(x)), s.a, s.b, 2000), neg = simpson((x) => Math.max(0, -D.f(x)), s.a, s.b, 2000); return { I, pos, neg }; },
    draw(s, g) {
      const D = this.FN[s.fn];
      g.grid();
      g.region((x) => Math.max(0, D.f(x)), () => 0, s.a, s.b, { fill: "b", fo: 0.35, n: 300 });
      g.region(() => 0, (x) => Math.min(0, D.f(x)), s.a, s.b, { fill: "d", fo: 0.35, n: 300 });
      g.fx(D.f, { color: "ink", w: 3 });
      g.seg([s.a, 0], [s.a, D.f(s.a)], { color: "muted", w: 1, dash: "3 4" }).seg([s.b, 0], [s.b, D.f(s.b)], { color: "muted", w: 1, dash: "3 4" });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], `y = ${D.n}`, { anchor: "start", bold: true });
      g.text([g.xr[0] + 0.3, g.yr[1] - 1.4], "파랑: + 넓이 · 분홍: − 넓이", { anchor: "start", size: 12, color: "muted", bold: true });
    },
    metrics(s) {
      const { I, pos, neg } = this.vals(s);
      return [
        ["정적분 ∫ₐᵇ f(x) dx", frac(Math.round(I * 1e6) / 1e6, 64) + (Number.isInteger(Math.round(I * 64 * 1e6) / 1e6) && !Number.isInteger(I) ? ` ≈ ${fmt(I, 4)}` : ""), "key"],
        ["위쪽 넓이 − 아래쪽 넓이", `${fmt(pos, 4)} − ${fmt(neg, 4)} = ${fmt(pos - neg, 4)}`],
        ["실제 넓이 ∫|f|", fmt(pos + neg, 4)],
      ];
    },
    predict: [
      { q: "∫₋₁¹ (x³ − x) dx의 값은?", set: (s) => Object.assign(s, { fn: "cube", a: 0, b: 1 }), reveal: (s) => Object.assign(s, { a: -1, b: 1 }), answer: () => 0, why: "x³ − x는 원점 대칭인 함수라 [−1, 0]의 + 넓이와 [0, 1]의 − 넓이(각 1/4)가 상쇄됩니다." },
      { q: "∫₀² (x − 1) dx의 값은?", set: (s) => Object.assign(s, { fn: "line", a: 0, b: 1 }), reveal: (s) => Object.assign(s, { a: 0, b: 2 }), answer: () => 0, why: "[0, 1]의 아래 삼각형(−1/2)과 [1, 2]의 위 삼각형(+1/2)이 상쇄됩니다." },
      { q: "y = x² − 1과 x축으로 둘러싸인 부분의 넓이는? (분수나 소수로)", set: (s) => Object.assign(s, { fn: "para", a: 0, b: 1 }), reveal: (s) => Object.assign(s, { a: -1, b: 1 }), answer: () => 4 / 3, tol: 0.01, show: () => "4/3 ≈ 1.333", why: "∫₋₁¹ (x² − 1) dx = −4/3이므로 넓이는 그 절댓값 4/3입니다." },
    ],
  },
];
