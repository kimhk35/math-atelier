import {fmt} from './wave-scenes.js';
const TAU=2*Math.PI,I='#263d5b',P='#6255c7',O='#c55337',G='#087d75';
const text=(x,y,t,c=I,z=18,a='start')=>`<text x="${x}" y="${y}" fill="${c}" font-size="${z}" text-anchor="${a}" font-family="system-ui, sans-serif">${t}</text>`;
const line=(p,c=I,w=2,dash='',op=1)=>`<polyline points="${p.map(v=>v.join(',')).join(' ')}" fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="${dash}" opacity="${op}"/>`;
const dot=(p,c=G,r=6)=>`<circle cx="${p[0]}" cy="${p[1]}" r="${r}" fill="${c}" stroke="#faf7ef" stroke-width="2"/>`;
const curve=(f,end)=>Array.from({length:901},(_,i)=>f(end*i/900));
export function harmonics(s){return Array.from({length:s.terms??3},(_,k)=>{const n=2*k+1;return {n,c:s.shape==='triangle'?8/Math.PI**2*(-1)**k/n**2:4/Math.PI/n};});}
export function harmonicValues(s,t=s.angle*Math.PI/180){const terms=harmonics(s),decay=s.decay??.15,envelope=Math.exp(-decay*t);return {sum:terms.reduce((y,{n,c})=>y+c*Math.sin(n*t),0),envelope,damped:envelope*Math.sin(t),halfAngle:decay===0?null:Math.log(2)/decay*180/Math.PI};}
export function harmonicScene(s){
 const fourier=s.view==='fourier',end=fourier?TAU:3*TAU,t=s.angle*Math.PI/180,v=harmonicValues(s),Q=(x,y)=>[380+530*x/end,340-112*y],terms=harmonics(s);
 let out=`<rect width="960" height="640" rx="18" fill="#faf7ef"/><rect width="960" height="96" rx="18" fill="${I}"/>${text(30,33,'MATH ATELIER / HARMONIC LAB','#cfdaeb',13)}${text(30,72,fourier?'작은 회전들을 더해 새로운 파형을 만듭니다':'줄어드는 회전 반지름이 감쇠 진동이 됩니다','#fffaf2',24)}`;
 for(const y of [-1,0,1])out+=line([Q(0,y),Q(end,y)],I,y===0?1.5:1,'',.2)+text(363,Q(0,y)[1]+5,String(y),I,14,'end');
 for(let j=0;j<=6;j++)out+=line([Q(j*end/6,-1.5),Q(j*end/6,1.5)],I,1,'',.1)+text(Q(j*end/6,0)[0],535,fourier?['0','π/3','2π/3','π','4π/3','5π/3','2π'][j]:j===0?'0':`${j}π`,I,14,'middle');
 const plot=(f,c,w=2,dash='',op=1,upto=end)=>line(curve(u=>Q(u,f(u)),upto),c,w,dash,op);
 if(fourier){
  out+=text(35,135,`홀수 고조파 ${terms.length}개로 ${s.shape==='triangle'?'삼각파':'사각파'}에 다가가기`,G,22);
  let a=[165,330];
  for(const {n,c} of terms){const b=[a[0]+50*c*Math.cos(n*t),a[1]-50*c*Math.sin(n*t)];out+=`<circle cx="${a[0]}" cy="${a[1]}" r="${50*Math.abs(c)}" fill="none" stroke="${P}" stroke-width="1.5" opacity=".4"/>`+line([a,b],P,2)+dot(b,P,3);a=b;}
  out+=dot(a,G)+text(35,195,'각 원의 회전 배율',I,16)+text(35,224,terms.map(h=>h.n).join(' / '),P,15);
  if(s.guides)out+=line([a,[345,a[1]],Q(t,v.sum)],G,1.5,'5 6',.6);
  if(s.shape==='triangle')out+=plot(u=>2/Math.PI*Math.asin(Math.sin(u)),O,2,'6 6',.7);
  else for(let j=0;j<2;j++)out+=line([Q(j*Math.PI,j===0?1:-1),Q((j+1)*Math.PI,j===0?1:-1)],O,2,'6 6',.7);
  out+=plot(u=>harmonicValues(s,u).sum,G,2,'',.2)+plot(u=>harmonicValues(s,u).sum,G,3.5,'',1,t)+dot(Q(t,v.sum));
  out+=text(35,460,'각 성분의 계수',I,17);
  for(let k=0;k<terms.length;k++){const {n,c}=terms[k],x=45+k*31;out+=line([[x,512],[x,512-38*c]],c<0?O:P,12)+text(x,540,String(n),I,12,'middle');}
  out+=text(380,574,'초록: 부분합   /   주황 점선: 목표 파형',G,17);
  out+=text(35,610,s.shape==='triangle'?'삼각파 계수는 1/n²에 비례하며 부호가 번갈아 바뀝니다.':'사각파는 불연속점 근처에 넘침이 남습니다. 항을 늘려도 최대 넘침은 사라지지 않습니다.',I,16);
 }else{
  const R=u=>{const z=harmonicValues(s,u);return [165+90*z.envelope*Math.cos(u),330-90*z.envelope*Math.sin(u)];};
  out+=text(35,135,`y = e^(−${fmt(s.decay??.15)}θ) sin θ`,G,23)+text(35,167,'θ는 라디안입니다. 지수적으로 줄어드는 진폭을 관찰합니다.',I,16);
  out+=`<circle cx="165" cy="330" r="90" fill="none" stroke="${I}" stroke-dasharray="5 6" opacity=".25"/>`+line(curve(R,end),P,1.7,'',.2)+line(curve(R,t),P,3)+line([[165,330],R(t)],G,3)+dot(R(t));
  if(s.guides)out+=line([R(t),Q(t,v.damped)],G,1.5,'5 6',.6);
  out+=plot(Math.sin,I,1.5,'5 6',.2)+plot(u=>harmonicValues(s,u).envelope,O,2,'6 6',.8)+plot(u=>-harmonicValues(s,u).envelope,O,2,'6 6',.8)+plot(u=>harmonicValues(s,u).damped,G,2,'',.2)+plot(u=>harmonicValues(s,u).damped,G,3.5,'',1,t)+dot(Q(t,v.damped));
  out+=text(35,480,`현재 반지름 ${fmt(v.envelope)}`,P,20)+text(35,514,s.decay===0?'감쇠 없음':`진폭 절반: ${fmt(v.halfAngle)}°`,I,17)+text(380,574,'회색: sin θ   /   주황 점선: ±e^(−λθ)',I,17)+text(35,610,'λ가 클수록 더 빠르게 줄어듭니다. λ=0이면 반지름 1인 회전으로 돌아갑니다.',I,16);
 }
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 640" role="img" aria-label="${fourier?'푸리에 합성':'감쇠 진동'} 그래프">${out}</svg>`;
}
