// 23차 묶음 3 — 기하(이차곡선·벡터) + 미적분Ⅰ·Ⅱ + 확률과 통계
import { fmt, frac, clamp, piFmt, add, sub, mul, dot, len } from "./hs-core.js";

const GE = 6, C1 = 7, II = 13, PS = 8;
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const simpson = (f, a, b, n = 400) => { const h = (b - a) / n; let s = f(a) + f(b); for (let i = 1; i < n; i++) s += f(a + i * h) * (i % 2 ? 4 : 2); return (s * h) / 3; };
const fact = (n) => (n <= 1 ? 1 : n * fact(n - 1));

// 미분가능성
const DIF = {
  abs: { n: "y = |x|", f: Math.abs, L: -1, R: 1 },
  sq: { n: "y = x² + x", f: (x) => x * x + x, L: 1, R: 1 },
  xabs: { n: "y = x|x|", f: (x) => x * Math.abs(x), L: 0, R: 0 },
  kink: { n: "y = x (x ≥ 0), 2x (x < 0)", f: (x) => (x >= 0 ? x : 2 * x), L: 2, R: 1 },
  cbrt: { n: "y = ∛x", f: Math.cbrt, L: Infinity, R: Infinity },
};
// 미적분의 기본정리
const FTC = {
  a: { n: "f(t) = t − 1", f: (t) => t - 1, F: (x) => (x * x) / 2 - x },
  b: { n: "f(t) = (t − 1)(t − 3)", f: (t) => (t - 1) * (t - 3), F: (x) => x ** 3 / 3 - 2 * x * x + 3 * x },
  c: { n: "f(t) = 2cos(1.5t)", f: (t) => 2 * Math.cos(1.5 * t), F: (x) => (4 / 3) * Math.sin(1.5 * x) },
};
// 불연속
const DISC = {
  cont: { n: "y = x² + 1", f: (x) => x * x + 1, v: 2, L: 2, R: 2 },
  hole: { n: "y = (x² − 1)/(x − 1) (x ≠ 1), f(1) = 3", f: (x) => x + 1, v: 3, L: 2, R: 2 },
  jump: { n: "y = x + 1 (x < 1), x − 1 (x ≥ 1)", f: (x) => (x < 1 ? x + 1 : x - 1), v: 0, L: 2, R: 0 },
  inf: { n: "y = 1/(x − 1)²", f: (x) => 1 / (x - 1) ** 2, v: null, L: Infinity, R: Infinity },
};
// 뉴턴 방법
const NEW = {
  a: { n: "f(x) = x² − 2", f: (x) => x * x - 2, d: (x) => 2 * x, root: Math.SQRT2 },
  b: { n: "f(x) = x³ − x − 1", f: (x) => x ** 3 - x - 1, d: (x) => 3 * x * x - 1, root: 1.324717957 },
  c: { n: "f(x) = cos x − x", f: (x) => Math.cos(x) - x, d: (x) => -Math.sin(x) - 1, root: 0.739085133 },
};
// 원판 부피
const DISK = {
  rt: { n: "y = √x (0 ≤ x ≤ 4)", f: Math.sqrt, L: 4, V: 8 * Math.PI, Vs: "8π" },
  lin: { n: "y = 1 + x/4 (0 ≤ x ≤ 4)", f: (x) => 1 + x / 4, L: 4, V: (28 * Math.PI) / 3, Vs: "28π/3" },
  sin: { n: "y = sin x (0 ≤ x ≤ π)", f: Math.sin, L: Math.PI, V: (Math.PI * Math.PI) / 2, Vs: "π²/2" },
};
// 분산
const VX = [1, 2, 3, 4, 5], MID = [0.05, 0.2, 0.5, 0.2, 0.05], END = [0.42, 0.05, 0.06, 0.05, 0.42];

export default [
  // ───────── 기하 Ⅰ 이차곡선 ─────────
  {
    id: "geo-eccentricity", grade: GE, unit: 1, lesson: "Ⅰ-4", title: "이심률 e 하나로 — 원·타원·포물선·쌍곡선", type: "조작", time: "12분",
    tags: ["이심률", "이차곡선", "초점과 준선"], links: ["geo-parabola", "geo-ellipse", "geo-conic-section"],
    desc: "초점까지의 거리가 준선까지의 거리의 e배인 점들을 그리면, e < 1이면 타원, e = 1이면 포물선, e > 1이면 쌍곡선이 됩니다. e를 0에서 2까지 바꾸며 이차곡선이 하나의 가족임을 확인합니다. (이심률은 교과서의 탐구 활동 수준 보충 내용입니다.)",
    obs: ["곡선 위의 점 P에서 PF ÷ PH가 항상 e입니다.", "e = 1이면 포물선의 정의(PF = PH)와 같습니다.", "e가 0에 가까워질수록 준선이 멀어지며 원에 가까워집니다."],
    q: "e가 1보다 아주 조금 작을 때와 아주 조금 클 때, 곡선은 어떻게 다를까요?",
    formula: "PF = e · PH (e < 1 타원, e = 1 포물선, e > 1 쌍곡선)",
    en: { title: "Eccentricity", desc: "One number e for every conic." },
    view: { x: [-5, 8], y: [-4.8, 4.8] },
    params: [
      { key: "e", label: "이심률 e", min: 0, max: 2, step: 0.01, value: 0.6 },
      { key: "t", label: "점 P의 위치", min: -3.1, max: 3.1, step: 0.01, value: 1.2 },
    ],
    anim: { key: "e", min: 0, max: 2, speed: 0.35, loop: "bounce", label: "e 바꾸기" },
    r(s, th) { const d = 1 - s.e * Math.cos(th); return Math.abs(d) < 0.02 ? NaN : 2 / d; },
    draw(s, g) {
      g.grid();
      const P = (th) => { const r = this.r(s, th); return [r * Math.cos(th), r * Math.sin(th)]; };
      g.param(P, -Math.PI, Math.PI, { color: "b", w: 3, n: 1400 });
      if (s.e > 0.01) { const xd = -2 / s.e; if (xd > g.xr[0]) { g.seg([xd, g.yr[0]], [xd, g.yr[1]], { color: "e", w: 2, dash: "7 5" }); g.text([xd, g.yr[1] - 0.4], "준선", { dx: 6, anchor: "start", bold: true, color: "e", size: 13 }); } }
      g.point([0, 0], "F", { color: "a" });
      const Q = P(s.t);
      if (Number.isFinite(Q[0]) && Math.abs(Q[0]) < 12 && Math.abs(Q[1]) < 12) {
        g.seg([0, 0], Q, { color: "a", w: 2.2 });
        if (s.e > 0.01) g.seg(Q, [-2 / s.e, Q[1]], { color: "e", w: 2.2, dash: "4 3" });
        g.point(Q, "P", { color: "ink" });
      }
    },
    metrics(s) {
      const kind = s.e < 0.005 ? "원" : s.e < 0.995 ? "타원" : s.e <= 1.005 ? "포물선" : "쌍곡선", r = this.r(s, s.t);
      if (!Number.isFinite(r) || s.e < 0.005) return [["e", fmt(s.e, 2)], ["곡선", kind, "key"], s.e < 0.005 ? "e = 0이면 준선이 무한히 멀어져 원이 됩니다." : "P가 무한히 먼 곳에 있어요. 위치를 바꿔 보세요."];
      const Q = [r * Math.cos(s.t), r * Math.sin(s.t)], PF = Math.hypot(...Q), PH = Math.abs(Q[0] + 2 / s.e);
      return [["e", fmt(s.e, 2)], ["곡선", kind, "key"], ["PF", fmt(PF, 3)], ["PH", fmt(PH, 3)], ["PF ÷ PH", fmt(PF / PH, 3)]];
    },
    predict: [
      { q: "e = 1이면 어떤 곡선일까요?", options: O("포물선", "타원", "쌍곡선", "원"), set: (s) => (s.e = 0.6), reveal: (s) => (s.e = 1), answer: () => "a", why: "PF = PH, 곧 초점과 준선까지의 거리가 같은 점의 자취이므로 포물선입니다." },
      { q: "e = 0.5인 곡선 위의 점 P에서 PF ÷ PH의 값은?", set: (s) => Object.assign(s, { e: 0.5, t: 2 }), answer: () => 0.5, tol: 0.01, why: "이심률의 정의 그대로 PF = 0.5 × PH입니다." },
    ],
  },
  {
    id: "geo-aux-circle", grade: GE, unit: 1, lesson: "Ⅰ-2", title: "보조원으로 그리는 타원 — 원을 세로로 누르기", type: "조작", time: "10분",
    tags: ["타원", "보조원", "넓이"], links: ["geo-ellipse", "geo-eccentricity"],
    desc: "반지름 a인 원 위의 점 (a cos t, a sin t)의 y좌표만 b/a배로 줄이면 타원 x²/a² + y²/b² = 1 위의 점 (a cos t, b sin t)가 됩니다. 원을 세로로 납작하게 누른 것이 타원이므로, 넓이도 πa²의 b/a배인 πab임을 확인합니다.",
    obs: ["타원 위의 점은 같은 x좌표의 원 위의 점을 세로로 b/a배 한 것입니다.", "원의 방정식 x² + y² = a²에 y 대신 (a/b)y를 넣으면 타원의 방정식이 됩니다.", "모든 세로 길이가 b/a배이므로 넓이도 b/a배, 곧 πab입니다."],
    q: "타원을 가로로 늘여 원을 만들 수도 있을까요? 그때의 보조원은 무엇일까요?",
    formula: "(a cos t, a sin t) → (a cos t, b sin t), 타원의 넓이 = πab",
    en: { title: "Drawing an Ellipse from an Auxiliary Circle", desc: "Squash a circle vertically." },
    view: { x: [-6, 6], y: [-5.2, 5.2] },
    params: [
      { key: "a", label: "a (보조원의 반지름)", min: 1, max: 5, step: 0.1, value: 5 },
      { key: "b", label: "b", min: 0.5, max: 5, step: 0.1, value: 3 },
      { key: "t", label: "각 t", min: 0, max: 6.28, step: 0.01, value: 0.93 },
    ],
    anim: { key: "t", min: 0, max: 6.28, speed: 0.8, loop: "wrap", label: "점 돌리기" },
    draw(s, g) {
      const { a, b, t } = s, C = [a * Math.cos(t), a * Math.sin(t)], E = [a * Math.cos(t), b * Math.sin(t)];
      g.grid();
      g.circle([0, 0], a, { color: "muted", w: 1.6, dash: "6 5" });
      g.param((u) => [a * Math.cos(u), b * Math.sin(u)], 0, 2 * Math.PI, { color: "b", w: 3 });
      g.seg([0, 0], C, { color: "muted", w: 1.4 }).seg(C, [C[0], 0], { color: "muted", w: 1.2, dash: "3 3" });
      g.vec(C, E, { color: "a", w: 2.6 });
      g.point(C, "원 위의 점", { color: "muted" }).point(E, "타원 위의 점", { color: "a", dy: 18 });
    },
    metrics(s) { const { a, b, t } = s; return [["원 위의 점", `(${fmt(a * Math.cos(t), 2)}, ${fmt(a * Math.sin(t), 2)})`], ["타원 위의 점", `(${fmt(a * Math.cos(t), 2)}, ${fmt(b * Math.sin(t), 2)})`], ["세로 비율 b/a", fmt(b / a, 3)], ["타원의 넓이 πab", fmt(Math.PI * a * b, 3), "key"]]; },
    predict: [
      { q: "a = 5, b = 3인 타원의 넓이는? (소수 첫째 자리까지)", set: (s) => Object.assign(s, { a: 5, b: 5 }), reveal: (s) => (s.b = 3), answer: () => 15 * Math.PI, tol: 0.1, why: "πa² = 25π를 3/5배 하면 15π ≈ 47.1입니다." },
      { q: "a = 5, b = 3일 때 원 위의 점 (3, 4)에 대응하는 타원 위의 점의 y좌표는?", set: (s) => Object.assign(s, { a: 5, b: 3, t: 0.3 }), reveal: (s) => (s.t = Math.atan2(4, 3)), answer: () => 2.4, tol: 0.01, why: "y좌표를 3/5배 하므로 4 × 3/5 = 2.4입니다." },
    ],
  },

  // ───────── 기하 Ⅳ 벡터의 활용 ─────────
  {
    id: "geo-vector-circle", grade: GE, unit: 4, lesson: "Ⅳ-1", title: "벡터로 나타낸 원 — |p − c| = r과 (p − a)·(p − b) = 0", type: "조작", time: "12분",
    tags: ["벡터방정식", "원", "내적"], links: ["geo-vector-line", "geo-sphere-diameter"],
    desc: "중심의 위치벡터 c에서 거리가 r인 점 P의 위치벡터 p는 |p − c| = r을 만족합니다. 또 두 점 A, B에 대하여 (p − a)·(p − b) = 0이면 ∠APB = 90°이므로 P는 AB를 지름으로 하는 원 위에 있습니다. 두 벡터방정식이 같은 원을 나타내는지 확인합니다.",
    obs: ["p − c는 중심에서 P로 가는 벡터이고, 그 크기가 반지름입니다.", "PA ⊥ PB이면 (p − a)·(p − b) = 0입니다.", "지름의 양 끝 A, B의 중점이 중심 c, 지름의 절반이 반지름입니다."],
    q: "(p − a)·(p − b) = 0을 성분으로 풀어 쓰면 원의 방정식 꼴이 되는지 확인해 봅시다.",
    formula: "|p − c| = r ⇔ (x − c₁)² + (y − c₂)² = r²",
    en: { title: "Vector Equations of a Circle", desc: "|p − c| = r and (p − a)·(p − b) = 0." },
    view: { x: [-5.5, 5.5], y: [-4.2, 4.2] },
    init: () => ({ A: [-3, -1], B: [2, 2] }),
    params: [
      { key: "mode", label: "식", type: "seg", value: "r", options: [["r", "|p − c| = r"], ["d", "(p − a)·(p − b) = 0"]] },
      { key: "t", label: "점 P의 위치", min: 0, max: 6.28, step: 0.01, value: 1.1 },
    ],
    anim: { key: "t", min: 0, max: 6.28, speed: 0.8, loop: "wrap", label: "P 돌리기" },
    drags: {
      A: { at: (s) => s.A, move: (s, p) => (s.A = [clamp(Math.round(p[0] * 2) / 2, -5, 5), clamp(Math.round(p[1] * 2) / 2, -3.8, 3.8)]), color: "a", label: "A" },
      B: { at: (s) => s.B, move: (s, p) => (s.B = [clamp(Math.round(p[0] * 2) / 2, -5, 5), clamp(Math.round(p[1] * 2) / 2, -3.8, 3.8)]), color: "c", label: "B" },
    },
    geo(s) { const c = mul(add(s.A, s.B), 0.5), r = len(sub(s.B, s.A)) / 2, p = add(c, [r * Math.cos(s.t), r * Math.sin(s.t)]); return { c, r, p }; },
    draw(s, g) {
      const { c, r, p } = this.geo(s);
      g.grid();
      g.circle(c, r, { color: "b", w: 2.6 });
      g.vec([0, 0], p, { color: "ink", w: 2.4, label: "p" });
      if (s.mode === "r") { g.vec([0, 0], c, { color: "d", w: 2.4, label: "c" }); g.vec(c, p, { color: "a", w: 3, label: "p − c" }); g.seg(s.A, s.B, { color: "muted", w: 1.2, dash: "4 4" }); }
      else { g.vec(s.A, p, { color: "a", w: 2.6 }); g.vec(s.B, p, { color: "c", w: 2.6 }); g.seg(s.A, s.B, { color: "muted", w: 1.6 }); if (len(sub(p, s.A)) > 0.3 && len(sub(p, s.B)) > 0.3) g.right(p, s.A, s.B, { color: "e", size: 14 }); }
      g.point(c, "C", { color: "d", r: 4 }).point(s.A, "A", { color: "a" }).point(s.B, "B", { color: "c" }).point(p, "P", { color: "ink" });
    },
    metrics(s) {
      const { c, r, p } = this.geo(s), pa = sub(p, s.A), pb = sub(p, s.B);
      return s.mode === "r" ? [["c", `(${fmt(c[0], 2)}, ${fmt(c[1], 2)})`], ["|p − c|", fmt(len(sub(p, c)), 3), "key"], ["반지름 r", fmt(r, 3)], ["원의 방정식", `(x − ${fmt(c[0], 2)})² + (y − ${fmt(c[1], 2)})² = ${fmt(r * r, 2)}`]]
        : [["(p − a)·(p − b)", fmt(dot(pa, pb), 4), "key"], ["∠APB", `${fmt((Math.acos(clamp(dot(pa, pb) / (len(pa) * len(pb) || 1), -1, 1)) * 180) / Math.PI, 1)}°`], ["중심 (a + b)/2", `(${fmt(c[0], 2)}, ${fmt(c[1], 2)})`]];
    },
    predict: [
      { q: "A(−3, −1), B(2, 2)일 때 (p − a)·(p − b) = 0이 나타내는 원의 반지름의 제곱은?", set: (s) => Object.assign(s, { A: [-3, -1], B: [2, 2], mode: "d" }), answer: () => 8.5, tol: 0.01, why: "지름 AB = √(25 + 9) = √34이므로 반지름의 제곱은 34/4 = 8.5입니다." },
      { q: "P가 원 위에 있으면 ∠APB는 항상 몇 도일까요?", set: (s) => Object.assign(s, { mode: "d", t: 0.4 }), reveal: (s) => (s.t = 2.5), answer: () => 90, why: "(p − a)·(p − b) = 0은 PA와 PB가 수직이라는 뜻입니다. 지름에 대한 원주각이 90°입니다." },
    ],
  },

  // ───────── 미적분Ⅰ ─────────
  {
    id: "calc1-discontinuity", grade: C1, unit: 1, lesson: "Ⅰ-2", title: "연속과 세 가지 불연속 — 구멍·끊김·치솟음", type: "조작", time: "12분",
    tags: ["연속", "불연속", "극한"], links: ["calc1-limit", "calc1-continuity"],
    desc: "x = 1에서 함수가 연속이려면 ① f(1)이 정의되고 ② 극한값이 있고 ③ 둘이 같아야 합니다. 구멍이 있는 함수, 끊어진 함수, 한없이 치솟는 함수에서 x를 1에 가까이 가져가며 어느 조건이 깨지는지 확인합니다.",
    obs: ["구멍: 좌극한 = 우극한이지만 f(1)과 다릅니다.", "끊김: 좌극한과 우극한이 달라 극한값이 없습니다.", "치솟음: x → 1일 때 f(x)가 한없이 커져 극한값이 없습니다."],
    q: "구멍이 있는 불연속은 f(1)의 값만 바꾸면 연속이 됩니다. 다른 두 경우는 왜 그럴 수 없을까요?",
    formula: "x = a에서 연속 ⇔ lim(x→a) f(x) = f(a)",
    en: { title: "Continuity and Three Kinds of Discontinuity", desc: "Holes, jumps and blow-ups." },
    view: { x: [-2, 4], y: [-1.5, 5.5] },
    params: [
      { key: "fn", label: "함수", type: "select", value: "hole", options: Object.entries(DISC).map(([k, v]) => [k, v.n]) },
      { key: "h", label: "1까지의 거리 h", min: 0.01, max: 1, step: 0.01, value: 0.5 },
    ],
    anim: { key: "h", min: 0.01, max: 1, speed: 0.4, loop: "bounce", label: "1에 다가가기" },
    draw(s, g) {
      const D = DISC[s.fn];
      g.grid();
      g.fx(D.f, { color: "b", w: 3, to: 0.999 }); g.fx(D.f, { color: "b", w: 3, from: 1.001 });
      if (Number.isFinite(D.L) && s.fn !== "cont") g.point([1, D.L], "", { color: "b", hollow: true });
      if (Number.isFinite(D.R) && D.R !== D.L) g.point([1, D.R], "", { color: "b", hollow: true });
      if (D.v != null) g.point([1, D.v], "f(1)", { color: "e" });
      g.seg([1, g.yr[0]], [1, g.yr[1]], { color: "muted", w: 1, dash: "3 5" });
      [[1 - s.h, "a"], [1 + s.h, "c"]].forEach(([x, c]) => { const y = D.f(x); if (y < g.yr[1]) { g.point([x, y], "", { color: c }); g.seg([x, 0], [x, y], { color: c, w: 1.2, dash: "3 3" }); } });
    },
    metrics(s) {
      const D = DISC[s.fn], lv = (v) => (Number.isFinite(v) ? fmt(v) : "∞ (발산)"), cont = D.v != null && D.L === D.R && D.L === D.v;
      return [[`f(1 − ${fmt(s.h)})`, fmt(D.f(1 - s.h), 3)], [`f(1 + ${fmt(s.h)})`, fmt(D.f(1 + s.h), 3)], ["좌극한 · 우극한", `${lv(D.L)} · ${lv(D.R)}`], ["f(1)", D.v == null ? "정의되지 않음" : fmt(D.v)], ["x = 1에서", cont ? "연속" : "불연속", "key"]];
    },
    predict: [
      { q: "구멍이 있는 함수는 x = 1에서 연속일까요?", options: O("아니다", "그렇다"), set: (s) => Object.assign(s, { fn: "hole", h: 0.5 }), reveal: (s) => (s.h = 0.01), answer: () => "a", why: "극한값은 2인데 f(1) = 3이라 서로 다릅니다." },
      { q: "끊어진 함수에서 x → 1+일 때의 극한(우극한)은?", set: (s) => Object.assign(s, { fn: "jump", h: 0.6 }), reveal: (s) => (s.h = 0.01), answer: () => 0, why: "x ≥ 1에서 f(x) = x − 1이므로 오른쪽에서 다가가면 0에 가까워집니다." },
    ],
  },
  {
    id: "calc1-differentiable", grade: C1, unit: 2, lesson: "Ⅱ-1", title: "미분가능성 — 확대하면 직선이 될까", type: "조작", time: "12분",
    tags: ["미분가능", "미분계수", "연속"], links: ["calc-secant-tangent", "calc1-discontinuity"],
    desc: "x = 0 근처를 점점 크게 확대해 봅니다. 미분가능한 점에서는 그래프가 직선(접선)처럼 펴지지만, 뾰족한 점은 아무리 확대해도 뾰족하게 남습니다. 왼쪽과 오른쪽에서 구한 평균변화율이 같은 값으로 다가가는지도 비교합니다.",
    obs: ["미분가능하면 그 점 근처에서 그래프가 접선과 거의 같아집니다.", "|x|처럼 좌미분계수 −1과 우미분계수 1이 다르면 미분가능하지 않습니다.", "∛x는 연속이지만 접선이 세로로 서서 미분계수가 없습니다."],
    q: "미분가능하면 연속이지만, 연속이라고 미분가능한 것은 아닙니다. 이 실험의 예로 설명해 봅시다.",
    formula: "f′(0) = lim(h→0) (f(h) − f(0))/h (좌·우 극한이 같아야 함)",
    en: { title: "Differentiability", desc: "Zoom in: does the graph straighten out?" },
    view: (s) => { const w = 3 / 10 ** s.z; return { x: [-w, w], y: [-w * 0.75, w * 0.75] }; },
    params: [
      { key: "fn", label: "함수", type: "select", value: "abs", options: Object.entries(DIF).map(([k, v]) => [k, v.n]) },
      { key: "z", label: "확대 (10의 거듭제곱)", min: 0, max: 3, step: 0.05, value: 0, show: (v) => `${fmt(10 ** v, 0)}배` },
    ],
    anim: { key: "z", min: 0, max: 3, speed: 0.6, loop: "bounce", label: "확대하기" },
    draw(s, g) {
      const D = DIF[s.fn], w = g.xr[1], st = 10 ** Math.floor(Math.log10(w));
      g.grid({ step: st, labels: false });
      g.fx(D.f, { color: "b", w: 3.4, n: 800 });
      g.point([0, 0], "", { color: "a" });
      g.note(14, 26, `가로 폭 ${fmt(2 * w, 4)} · 눈금 한 칸 ${fmt(st, 4)}`, { bold: true });
    },
    metrics(s) {
      const D = DIF[s.fn], h = 1e-4, Lq = (D.f(-h) - D.f(0)) / -h, Rq = (D.f(h) - D.f(0)) / h, ok = Number.isFinite(D.L) && D.L === D.R;
      return [["왼쪽 평균변화율 (h = −0.0001)", fmt(Lq, 3)], ["오른쪽 평균변화율 (h = 0.0001)", fmt(Rq, 3)], ["x = 0에서", ok ? `미분가능 (f′(0) = ${fmt(D.L)})` : Number.isFinite(D.L) ? "미분가능하지 않음 (뾰족함)" : "미분가능하지 않음 (접선이 세로)", "key"]];
    },
    predict: [
      { q: "y = |x|는 x = 0에서 미분가능할까요?", options: O("아니다", "그렇다"), set: (s) => Object.assign(s, { fn: "abs", z: 0 }), reveal: (s) => (s.z = 3), answer: () => "a", why: "1000배로 확대해도 뾰족하고, 좌미분계수 −1과 우미분계수 1이 다릅니다." },
      { q: "y = x|x|의 x = 0에서의 미분계수는?", set: (s) => Object.assign(s, { fn: "xabs", z: 0 }), reveal: (s) => (s.z = 2), answer: () => 0, why: "(h|h| − 0)/h = |h| → 0이므로 f′(0) = 0입니다. 확대하면 x축과 겹치는 직선이 됩니다." },
    ],
  },
  {
    id: "calc1-product-rule", grade: C1, unit: 2, lesson: "Ⅱ-2", title: "곱의 미분 — 직사각형이 커지는 넓이", type: "조작", time: "12분",
    tags: ["곱의 미분법", "도함수", "넓이 모형"], links: ["calc-secant-tangent", "calc2-parts"],
    desc: "가로 f(x), 세로 g(x)인 직사각형에서 x가 h만큼 늘면 넓이가 f·Δg(오른쪽 띠), g·Δf(위쪽 띠), Δf·Δg(모서리)만큼 늘어납니다. h → 0이면 모서리는 다른 두 띠보다 훨씬 빨리 사라져 (fg)′ = f′g + fg′이 됨을 확인합니다.",
    obs: ["Δ(fg) = f·Δg + g·Δf + Δf·Δg입니다.", "h로 나누면 Δf·Δg/h = Δf·(Δg/h)는 Δf → 0 때문에 0으로 갑니다.", "그래서 (fg)′ = f′g + fg′이고, f′g′이 아닙니다."],
    q: "(fgh)′은 어떤 모양일까요? 직육면체가 커지는 부피로 생각해 봅시다.",
    formula: "{f(x)g(x)}′ = f′(x)g(x) + f(x)g′(x)",
    en: { title: "The Product Rule", desc: "How a rectangle's area grows." },
    view: { x: [-0.7, 5.6], y: [-0.7, 4.9] },
    params: [
      { key: "x", label: "x", min: 0, max: 2, step: 0.05, value: 1 },
      { key: "h", label: "늘린 양 h", min: 0.01, max: 1, step: 0.01, value: 0.6 },
    ],
    anim: { key: "h", min: 0.01, max: 1, speed: 0.3, loop: "bounce", label: "h 줄이기" },
    F: (x) => x + 1, G: (x) => (x * x) / 2 + 1,
    draw(s, g) {
      const f0 = this.F(s.x), g0 = this.G(s.x), f1 = this.F(s.x + s.h), g1 = this.G(s.x + s.h);
      g.poly([[0, 0], [f0, 0], [f0, g0], [0, g0]], { fill: "b", fo: 0.22, color: "b", w: 2 });
      g.poly([[f0, 0], [f1, 0], [f1, g0], [f0, g0]], { fill: "a", fo: 0.4, color: "a", w: 1.6 });
      g.poly([[0, g0], [f0, g0], [f0, g1], [0, g1]], { fill: "c", fo: 0.4, color: "c", w: 1.6 });
      g.poly([[f0, g0], [f1, g0], [f1, g1], [f0, g1]], { fill: "e", fo: 0.6, color: "e", w: 1.6 });
      g.text([f0 / 2, g0 / 2], "f·g", { bold: true, color: "b", size: 16 });
      if (f1 - f0 > 0.25) g.text([(f0 + f1) / 2, g0 / 2], "g·Δf", { bold: true, color: "a", size: 13 });
      if (g1 - g0 > 0.25) g.text([f0 / 2, (g0 + g1) / 2], "f·Δg", { dy: 5, bold: true, color: "c", size: 13 });
      g.text([f0 / 2, 0], `f(x) = x + 1 = ${fmt(f0, 2)}`, { dy: 18, size: 12, color: "muted" });
      g.text([0, g0 / 2], `g(x) = x²/2 + 1 = ${fmt(g0, 2)}`, { dx: -6, anchor: "end", size: 12, color: "muted" });
      g.text([f1, g1], "Δf·Δg", { dx: 6, dy: -6, anchor: "start", bold: true, color: "e", size: 12 });
    },
    metrics(s) {
      const f0 = this.F(s.x), g0 = this.G(s.x), f1 = this.F(s.x + s.h), g1 = this.G(s.x + s.h), df = f1 - f0, dg = g1 - g0;
      return [["Δ(fg) ÷ h", fmt((f1 * g1 - f0 * g0) / s.h, 4)], ["(g·Δf + f·Δg) ÷ h", fmt((g0 * df + f0 * dg) / s.h, 4)], ["모서리 Δf·Δg ÷ h", fmt((df * dg) / s.h, 4)], ["f′g + fg′ (h → 0)", fmt(1 * g0 + f0 * s.x, 4), "key"]];
    },
    predict: [
      { q: "f(x) = x + 1, g(x) = x²/2 + 1일 때 x = 1에서 (fg)′의 값은?", set: (s) => Object.assign(s, { x: 1, h: 0.8 }), reveal: (s) => (s.h = 0.01), answer: () => 3.5, tol: 0.01, why: "f′g + fg′ = 1 × 1.5 + 2 × 1 = 3.5입니다." },
      { q: "h → 0일 때 모서리 넓이 Δf·Δg를 h로 나눈 값은?", options: O("0으로 간다", "f′g′으로 간다", "한없이 커진다"), set: (s) => Object.assign(s, { x: 1, h: 0.8 }), reveal: (s) => (s.h = 0.01), answer: () => "a", why: "Δf·Δg/h = Δf × (Δg/h)에서 Δf → 0, Δg/h → g′이므로 0입니다." },
    ],
  },
  {
    id: "calc1-cubic-extrema", grade: C1, unit: 3, lesson: "Ⅲ-3", title: "삼차함수의 극값 — 도함수의 판별식으로", type: "조작", time: "12분",
    tags: ["극대", "극소", "삼차함수"], links: ["calc-derivative-graph", "calc1-closed-maxmin"],
    desc: "f(x) = x³ + ax² + bx의 도함수 f′(x) = 3x² + 2ax + b가 x축과 두 번 만나야 극댓값과 극솟값이 생깁니다. a, b를 바꾸며 f′의 판별식 D/4 = a² − 3b의 부호에 따라 그래프가 '언덕과 골짜기가 있는 모양'과 '계속 올라가는 모양'으로 나뉘는 것을 확인합니다.",
    obs: ["f′(x) = 0의 서로 다른 두 실근에서 부호가 바뀌면 극대·극소가 생깁니다.", "D/4 = a² − 3b ≤ 0이면 f′(x) ≥ 0이라 f는 계속 증가하고 극값이 없습니다.", "극대와 극소의 한가운데가 그래프의 변곡점입니다."],
    q: "삼차함수가 극값을 하나만 가질 수 있을까요? 그 까닭은?",
    formula: "f′(x) = 3x² + 2ax + b, D/4 = a² − 3b > 0 ⇔ 극값 2개",
    en: { title: "Extrema of a Cubic", desc: "The discriminant of f′ decides." },
    view: { x: [-4.5, 4.5], y: [-6, 6] },
    params: [
      { key: "a", label: "a", min: -3, max: 3, step: 0.5, value: 0 },
      { key: "b", label: "b", min: -4, max: 6, step: 0.5, value: -3 },
      { key: "showd", label: "도함수 y = f′(x)도 그리기", type: "check", value: true },
    ],
    anim: { key: "b", min: -4, max: 6, speed: 1.5, loop: "bounce", label: "b 바꾸기" },
    crit(s) { const D = s.a * s.a - 3 * s.b; if (D <= 1e-9) return []; const r = Math.sqrt(D); return [(-s.a - r) / 3, (-s.a + r) / 3]; },
    draw(s, g) {
      const f = (x) => x ** 3 + s.a * x * x + s.b * x, d = (x) => 3 * x * x + 2 * s.a * x + s.b, C = this.crit(s);
      g.grid({ every: 2 });
      if (s.showd) g.fx(d, { color: "a", w: 2, dash: "7 5" });
      g.fx(f, { color: "b", w: 3.2 });
      C.forEach((x, i) => { g.point([x, f(x)], i ? "극소" : "극대", { color: i ? "c" : "e", dy: i ? 22 : -10 }); if (s.showd) g.point([x, 0], "", { color: "a", r: 4 }); });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], `파랑: f(x) = x³${s.a ? ` ${s.a < 0 ? "−" : "+"} ${fmt(Math.abs(s.a))}x²` : ""}${s.b ? ` ${s.b < 0 ? "−" : "+"} ${fmt(Math.abs(s.b))}x` : ""}`, { anchor: "start", bold: true, color: "b" });
      if (s.showd) g.text([g.xr[0] + 0.3, g.yr[1] - 1.5], "주황 점선: f′(x)", { anchor: "start", bold: true, color: "a" });
    },
    metrics(s) {
      const f = (x) => x ** 3 + s.a * x * x + s.b * x, C = this.crit(s), D = s.a * s.a - 3 * s.b;
      return [["f′의 D/4 = a² − 3b", fmt(D, 2)], ["극값의 개수", C.length ? "2개" : "없음 (계속 증가)", "key"], ...(C.length ? [["극댓값", `f(${fmt(C[0], 2)}) = ${fmt(f(C[0]), 3)}`], ["극솟값", `f(${fmt(C[1], 2)}) = ${fmt(f(C[1]), 3)}`]] : [])];
    },
    predict: [
      { q: "f(x) = x³ − 3x의 극값은 몇 개?", set: (s) => Object.assign(s, { a: 0, b: 3 }), reveal: (s) => (s.b = -3), answer: () => 2, why: "f′(x) = 3x² − 3 = 0에서 x = ±1, 부호가 바뀌어 극댓값 2, 극솟값 −2가 있습니다." },
      { q: "f(x) = x³ + 3x² + bx가 극값을 갖지 않도록 하는 b의 최솟값은?", set: (s) => Object.assign(s, { a: 3, b: -2 }), reveal: (s) => (s.b = 3), answer: () => 3, why: "D/4 = 9 − 3b ≤ 0에서 b ≥ 3입니다." },
    ],
  },
  {
    id: "calc1-ftc", grade: C1, unit: 4, lesson: "Ⅳ-2", title: "미적분의 기본정리 — 넓이 함수의 기울기는 f(x)", type: "조작", time: "12분",
    tags: ["미적분의 기본정리", "정적분", "넓이 함수"], links: ["calc1-antiderivative", "calc-riemann", "calc1-definite-sign"],
    desc: "위 그림에서 0부터 x까지 y = f(t) 아래 넓이(아래쪽은 빼기)를 F(x)로 정하고, 아래 그림에 y = F(x)를 그립니다. x를 움직이며 F의 접선 기울기가 언제나 그 순간의 높이 f(x)와 같음을 확인합니다.",
    obs: ["x가 Δx만큼 늘면 넓이가 대략 f(x)·Δx만큼 늘어납니다.", "그래서 F′(x) = f(x), 곧 넓이 함수는 f의 부정적분 가운데 하나입니다.", "f(x) = 0인 곳에서 F는 극대 또는 극소가 됩니다."],
    q: "넓이를 0이 아닌 다른 점 a부터 재기 시작하면 아래 그래프는 어떻게 바뀔까요?",
    formula: "F(x) = ∫₀ˣ f(t) dt ⇒ F′(x) = f(x)",
    en: { title: "The Fundamental Theorem of Calculus", desc: "The slope of the area function is f(x)." },
    view: { x: [-1.2, 10.4], y: [-5.2, 5.6] },
    params: [
      { key: "fn", label: "f(t)", type: "select", value: "b", options: Object.entries(FTC).map(([k, v]) => [k, v.n]) },
      { key: "x", label: "x", min: 0, max: 3.6, step: 0.01, value: 1.6 },
    ],
    anim: { key: "x", min: 0, max: 3.6, speed: 0.5, loop: "bounce", label: "x 움직이기" },
    draw(s, g) {
      const K = FTC[s.fn], YT = 2.2, YB = -2.6, KX = 2.6, T = (x, y) => [x * KX, YT + y], B = (x, y) => [x * KX, YB + y];
      g.seg(T(-0.4, 0), T(4.1, 0), { color: "axis", w: 1.4 }).seg(B(-0.4, 0), B(4.1, 0), { color: "axis", w: 1.4 });
      g.seg(T(0, -1.4), T(0, 3.2), { color: "axis", w: 1.2 }).seg(B(0, -2.3), B(0, 2.6), { color: "axis", w: 1.2 });
      const N = 160; for (let i = 0; i < N; i++) { const a = (s.x * i) / N, b = (s.x * (i + 1)) / N, y = K.f((a + b) / 2); g.poly([T(a, 0), T(b, 0), T(b, y), T(a, y)], { fill: y >= 0 ? "b" : "e", fo: 0.35, stroke: false }); }
      g.param((t) => T(t, K.f(t)), 0, 3.6, { color: "ink", w: 2.6 });
      g.param((t) => B(t, K.F(t)), 0, 3.6, { color: "muted", w: 1.6, dash: "5 5" });
      g.param((t) => B(t, K.F(t)), 0, s.x, { color: "a", w: 3 });
      const fx = K.f(s.x), Fx = K.F(s.x), d = 0.55;
      g.seg(B(s.x - d, Fx - d * fx), B(s.x + d, Fx + d * fx), { color: "c", w: 2.6 });
      g.seg(T(s.x, K.f(s.x)), B(s.x, Fx), { color: "muted", w: 1, dash: "3 4" });
      g.point(T(s.x, fx), "", { color: "ink" }).point(B(s.x, Fx), "", { color: "a" });
      g.text(T(0.1, 3.1), `위: y = ${K.n.replace("f(t) = ", "")} 아래의 넓이 (0부터 x까지)`, { anchor: "start", bold: true }).text(B(0.04, 2.5), "아래: y = F(x) = ∫₀ˣ f(t) dt  (초록: 접선)", { anchor: "start", bold: true, color: "a" });
    },
    metrics(s) { const K = FTC[s.fn], h = 1e-4; return [["F(x) = 넓이", fmt(K.F(s.x), 4)], ["F의 접선 기울기", fmt((K.F(s.x + h) - K.F(s.x - h)) / (2 * h), 4)], ["f(x)", fmt(K.f(s.x), 4), "key"]]; },
    predict: [
      { q: "F(x) = ∫₀ˣ (t − 1) dt가 가장 작아지는 x는?", set: (s) => Object.assign(s, { fn: "a", x: 0.2 }), reveal: (s) => (s.x = 1), answer: () => 1, why: "F′(x) = x − 1의 부호가 x = 1에서 음에서 양으로 바뀌므로 x = 1에서 최소입니다." },
      { q: "F(x) = ∫₀ˣ f(t) dt일 때 F′(x)는?", options: O("f(x)", "f′(x)", "F(x) + C"), set: (s) => Object.assign(s, { fn: "c", x: 0.5 }), answer: () => "a", why: "아래 그래프의 접선 기울기가 언제나 위 그래프의 높이 f(x)와 같습니다." },
    ],
  },

  // ───────── 미적분Ⅱ ─────────
  {
    id: "calc2-geo-limit", grade: II, unit: 1, lesson: "Ⅰ-2", title: "등비수열 rⁿ의 극한 — r에 따라 네 갈래", type: "조작", time: "10분",
    tags: ["등비수열의 극한", "수렴", "발산"], links: ["calc2-seq-limit", "calc2-geo-series"],
    desc: "공비 r을 바꾸며 rⁿ의 점을 n = 1부터 30까지 찍어 봅니다. |r| < 1이면 0으로, r = 1이면 1로 수렴하고, r > 1이면 양의 무한대로, r ≤ −1이면 진동하며 발산함을 확인합니다.",
    obs: ["−1 < r < 1이면 rⁿ → 0입니다.", "r = 1이면 모든 항이 1이고, r = −1이면 1과 −1을 오가며 진동합니다.", "r > 1이면 한없이 커지고, r < −1이면 부호를 바꾸며 크기가 한없이 커집니다."],
    q: "lim(n→∞) rⁿ/(1 + rⁿ)의 값을 r의 범위에 따라 나누어 구해 봅시다.",
    formula: "lim rⁿ = 0 (|r| < 1), 1 (r = 1), 발산 (r ≤ −1 또는 r > 1)",
    en: { title: "Limits of Geometric Sequences", desc: "Four behaviors of rⁿ." },
    view: { x: [-1, 31], y: [-3.2, 3.2] },
    params: [
      { key: "r", label: "공비 r", min: -1.5, max: 1.5, step: 0.01, value: 0.85 },
      { key: "N", label: "찍을 항의 수", min: 1, max: 30, step: 1, value: 30 },
    ],
    anim: { key: "r", min: -1.5, max: 1.5, speed: 0.4, loop: "bounce", label: "r 바꾸기" },
    draw(s, g) {
      g.seg([0, 0], [30.5, 0], { color: "axis", w: 1.4 }).seg([0, -3], [0, 3], { color: "axis", w: 1.4 });
      [-2, -1, 1, 2].forEach((y) => { g.seg([0, y], [30.5, y], { color: "grid", w: 1 }); g.text([0, y], String(y).replace("-", "−"), { dx: -6, anchor: "end", dy: 4, size: 11, color: "muted" }); });
      [10, 20, 30].forEach((n) => g.text([n, 0], String(n), { dy: 16, size: 11, color: "muted" }));
      for (let n = 1; n <= s.N; n++) { const v = s.r ** n; if (Math.abs(v) <= 3.1) g.point([n, v], "", { color: v >= 0 ? "b" : "e", r: 3.8 }); else g.vec([n, Math.sign(v) * 2.5], [n, Math.sign(v) * 3.1], { color: "e", w: 2 }); }
      g.text([1, 2.8], `rⁿ (r = ${fmt(s.r, 2)})`, { anchor: "start", bold: true });
    },
    metrics(s) {
      const r = s.r, k = Math.abs(r) < 1 - 1e-9 ? "0으로 수렴" : Math.abs(r - 1) < 1e-9 ? "1로 수렴" : r > 1 ? "양의 무한대로 발산" : "진동하며 발산";
      return [[`r^${s.N}`, fmt(r ** s.N, 4)], ["판정", k, "key"]];
    },
    predict: [
      { q: "lim(n→∞) (−0.8)ⁿ의 값은?", set: (s) => Object.assign(s, { r: 0.3, N: 5 }), reveal: (s) => Object.assign(s, { r: -0.8, N: 30 }), answer: () => 0, why: "|−0.8| < 1이므로 부호는 바뀌어도 크기가 0으로 줄어듭니다." },
      { q: "r = −1이면 수열 rⁿ은?", options: O("진동하며 발산한다", "0으로 수렴한다", "−1로 수렴한다"), set: (s) => Object.assign(s, { r: -0.5, N: 10 }), reveal: (s) => (s.r = -1), answer: () => "a", why: "−1, 1, −1, 1, …을 되풀이해 한 값에 다가가지 않습니다." },
    ],
  },
  {
    id: "calc2-cycloid", grade: II, unit: 2, lesson: "Ⅱ-8", title: "매개변수로 나타낸 함수의 미분 — 사이클로이드의 접선", type: "조작", time: "12분",
    tags: ["매개변수", "미분법", "사이클로이드"], links: ["calc-param-motion", "calc-implicit"],
    desc: "반지름 1인 바퀴가 굴러갈 때 바퀴 위의 한 점이 그리는 사이클로이드 x = t − sin t, y = 1 − cos t의 접선 기울기를 dy/dx = (dy/dt)/(dx/dt)로 구합니다. 접선이 언제나 바퀴의 꼭대기를 지난다는 사실도 확인합니다.",
    obs: ["dx/dt = 1 − cos t, dy/dt = sin t이므로 dy/dx = sin t/(1 − cos t)입니다.", "t = π에서 dy/dx = 0, 점이 가장 높이 올라갑니다.", "t가 0이나 2π에 가까워지면 접선이 세로에 가까워집니다."],
    q: "dy/dx = sin t/(1 − cos t)를 반각 공식으로 간단히 하면 어떤 식이 될까요?",
    formula: "dy/dx = (dy/dt) ÷ (dx/dt) = sin t / (1 − cos t)",
    en: { title: "Derivatives of Parametric Curves — the Cycloid", desc: "Tangent lines of a rolling-wheel curve." },
    view: { x: [-0.6, 13.2], y: [-1, 3.6] },
    params: [{ key: "t", label: "매개변수 t", min: 0.05, max: 12.5, step: 0.01, value: 2.2 }],
    anim: { key: "t", min: 0.05, max: 12.5, speed: 1.2, loop: "bounce", label: "바퀴 굴리기" },
    draw(s, g) {
      const t = s.t, P = [t - Math.sin(t), 1 - Math.cos(t)], C = [t, 1], top = [t, 2], dx = 1 - Math.cos(t), dy = Math.sin(t);
      g.seg([-0.5, 0], [13, 0], { color: "axis", w: 1.6 });
      g.param((u) => [u - Math.sin(u), 1 - Math.cos(u)], 0, 4 * Math.PI, { color: "muted", w: 1.4, dash: "5 5" });
      g.param((u) => [u - Math.sin(u), 1 - Math.cos(u)], 0, t, { color: "b", w: 3 });
      g.circle(C, 1, { color: "ink", w: 2 }).seg(C, P, { color: "ink", w: 1.4 });
      const L = 2.2, n = Math.hypot(dx, dy); g.seg([P[0] - (L * dx) / n, P[1] - (L * dy) / n], [P[0] + (L * dx) / n, P[1] + (L * dy) / n], { color: "a", w: 2.6 });
      g.point(P, "P", { color: "a" }).point(top, "바퀴 꼭대기", { color: "c", r: 4.5, dy: -10 }).point(C, "", { color: "ink", r: 3 });
    },
    metrics(s) { const t = s.t, dx = 1 - Math.cos(t), dy = Math.sin(t); return [["dx/dt = 1 − cos t", fmt(dx, 3)], ["dy/dt = sin t", fmt(dy, 3)], ["dy/dx", Math.abs(dx) < 1e-6 ? "정의되지 않음" : fmt(dy / dx, 3), "key"]]; },
    predict: [
      { q: "t = π/2일 때 접선의 기울기 dy/dx는?", set: (s) => (s.t = 0.6), reveal: (s) => (s.t = Math.PI / 2), answer: () => 1, why: "sin(π/2)/(1 − cos(π/2)) = 1/1 = 1입니다." },
      { q: "t = π일 때 접선의 기울기는?", set: (s) => (s.t = 2), reveal: (s) => (s.t = Math.PI), answer: () => 0, why: "sin π = 0이고 1 − cos π = 2이므로 0입니다. 점이 가장 높은 곳에 있습니다." },
    ],
  },
  {
    id: "calc2-newton", grade: II, unit: 3, lesson: "Ⅲ 탐구", title: "뉴턴 방법 — 접선을 따라 근에 다가가기", type: "조작", time: "12분",
    tags: ["뉴턴 방법", "접선", "근삿값"], links: ["calc1-bisection", "calc-secant-tangent"],
    desc: "x₀에서 그은 접선이 x축과 만나는 점을 x₁로, 다시 x₁에서 접선을 그어 x₂를 얻는 일을 되풀이합니다. 몇 번 만에 √2 같은 근의 소수점 아래 여러 자리가 맞아지는지 이분법과 비교하며 확인합니다.",
    obs: ["접선 y = f(xₙ) + f′(xₙ)(x − xₙ)이 x축과 만나는 점이 xₙ₊₁ = xₙ − f(xₙ)/f′(xₙ)입니다.", "근 가까이에서는 한 번 할 때마다 맞는 자릿수가 거의 두 배로 늘어납니다.", "f′(xₙ)이 0에 가까우면 다음 점이 아주 멀리 튀어 나갈 수 있습니다."],
    q: "f(x) = x² − 2에서 x₀ = 0으로 시작하면 왜 뉴턴 방법이 실패할까요?",
    formula: "xₙ₊₁ = xₙ − f(xₙ)/f′(xₙ)",
    en: { title: "Newton's Method", desc: "Follow tangent lines to a root." },
    view: { x: [-1, 3.6], y: [-2.6, 4.4] },
    params: [
      { key: "fn", label: "함수", type: "select", value: "a", options: Object.entries(NEW).map(([k, v]) => [k, v.n]) },
      { key: "x0", label: "출발점 x₀", min: 0.2, max: 3.2, step: 0.05, value: 3 },
      { key: "n", label: "되풀이 횟수", min: 0, max: 6, step: 1, value: 2 },
    ],
    anim: { key: "n", min: 0, max: 6, speed: 1, label: "한 번씩 되풀이" },
    seq(s) { const K = NEW[s.fn], x = [s.x0]; for (let i = 0; i < s.n; i++) { const d = K.d(x[i]); if (Math.abs(d) < 1e-9) break; x.push(x[i] - K.f(x[i]) / d); } return x; },
    draw(s, g) {
      const K = NEW[s.fn], X = this.seq(s);
      g.grid();
      g.fx(K.f, { color: "b", w: 3 });
      X.forEach((x, i) => {
        if (Math.abs(x) > 8) return;
        const y = K.f(x);
        g.seg([x, 0], [x, y], { color: "muted", w: 1.2, dash: "3 4" });
        if (i < X.length - 1 && Math.abs(X[i + 1]) < 8) g.seg([x, y], [X[i + 1], 0], { color: "a", w: 2.4 });
        g.point([x, 0], i < 4 ? `x${"₀₁₂₃"[i]}` : "", { color: i === X.length - 1 ? "c" : "a", dy: 18, r: 4.5 });
      });
      g.text([g.xr[0] + 0.2, g.yr[1] - 0.4], K.n, { anchor: "start", bold: true, color: "b" });
    },
    metrics(s) { const K = NEW[s.fn], X = this.seq(s), x = X[X.length - 1]; return [["지금까지의 점", X.map((v) => fmt(v, 6)).join(" → ")], [`x${s.n}`, fmt(x, 9), "key"], ["참값과의 차", fmt(Math.abs(x - K.root), 9)]]; },
    predict: [
      { q: "f(x) = x² − 2, x₀ = 1이면 x₁은?", set: (s) => Object.assign(s, { fn: "a", x0: 1, n: 0 }), reveal: (s) => (s.n = 1), answer: () => 1.5, tol: 1e-6, why: "x₁ = 1 − (1 − 2)/2 = 1.5입니다." },
      { q: "같은 조건에서 x₂는? (소수 넷째 자리까지)", set: (s) => Object.assign(s, { fn: "a", x0: 1, n: 1 }), reveal: (s) => (s.n = 2), answer: () => 17 / 12, tol: 0.0005, why: "x₂ = 1.5 − 0.25/3 = 17/12 ≈ 1.4167, √2 ≈ 1.4142에 아주 가깝습니다." },
    ],
  },
  {
    id: "calc2-ln-area", grade: II, unit: 4, lesson: "Ⅳ-1", title: "∫1/x dx = ln x — 넓이가 곱셈을 덧셈으로 바꾼다", type: "조작", time: "12분",
    tags: ["로그함수의 적분", "넓이", "ln"], links: ["calc2-e-slope", "calc-riemann"],
    desc: "y = 1/x 아래에서 1부터 a까지의 넓이(파랑)와 a부터 ab까지의 넓이(주황)를 더하면 1부터 ab까지의 넓이가 됩니다. 주황 영역은 1부터 b까지의 넓이(초록 점선)를 가로로 a배 늘이고 세로로 1/a배 줄인 것이라 넓이가 같습니다. 그래서 넓이 함수가 ln처럼 곱을 합으로 바꿉니다.",
    obs: ["∫ₐᵃᵇ 1/x dx = ∫₁ᵇ 1/x dx입니다. 가로 a배, 세로 1/a배라 넓이가 그대로입니다.", "그래서 L(ab) = L(a) + L(b), 곧 넓이 함수 L(x) = ∫₁ˣ 1/t dt는 로그의 성질을 가집니다.", "L(e) = 1이 되는 수가 e이고, L(x) = ln x입니다."],
    q: "∫₁² 1/x dx + ∫₂⁸ 1/x dx를 계산 없이 하나의 넓이로 바꾸어 봅시다.",
    formula: "∫₁ᵃᵇ 1/x dx = ∫₁ᵃ 1/x dx + ∫₁ᵇ 1/x dx, ∫ 1/x dx = ln|x| + C",
    en: { title: "∫1/x dx = ln x", desc: "Area turns products into sums." },
    view: { x: [-0.4, 9.6], y: [-0.4, 2.6] },
    params: [
      { key: "a", label: "a", min: 1, max: 3, step: 0.05, value: 2 },
      { key: "b", label: "b", min: 1, max: 3, step: 0.05, value: 2.5 },
    ],
    draw(s, g) {
      const f = (x) => 1 / x, ab = s.a * s.b;
      g.grid({ every: 1 });
      g.region(f, () => 0, 1, s.b, { fill: "c", fo: 0.12 });
      g.path([[1, 0], [1, 1], ...Array.from({ length: 41 }, (_, i) => { const x = 1 + ((s.b - 1) * i) / 40; return [x, f(x)]; }), [s.b, 0]], { color: "c", w: 2, dash: "6 4" });
      g.region(f, () => 0, 1, s.a, { fill: "b", fo: 0.4 });
      g.region(f, () => 0, s.a, ab, { fill: "a", fo: 0.4 });
      g.fx(f, { color: "ink", w: 2.8, from: 0.4 });
      g.text([1, 0], "1", { dy: 16, size: 12 }).text([s.a, 0], `a = ${fmt(s.a)}`, { dy: 30, size: 12, color: "b", bold: true }).text([ab, 0], `ab = ${fmt(ab, 2)}`, { dy: 16, size: 12, color: "a", bold: true }).text([s.b, 0], `b = ${fmt(s.b)}`, { dy: 44, size: 12, color: "c", bold: true });
      g.text([4.8, 2.2], "파랑 + 주황 = 1부터 ab까지 · 주황 = 초록 점선", { bold: true, size: 13 });
    },
    metrics(s) { const A1 = Math.log(s.a), A2 = Math.log(s.a * s.b) - A1, A3 = Math.log(s.b); return [["파랑 ∫₁ᵃ 1/x dx", fmt(A1, 4)], ["주황 ∫ₐᵃᵇ 1/x dx", fmt(A2, 4)], ["초록 ∫₁ᵇ 1/x dx", fmt(A3, 4)], ["합 = ln ab", fmt(Math.log(s.a * s.b), 4), "key"]]; },
    predict: [
      { q: "∫₁ᵉ 1/x dx의 값은?", set: (s) => Object.assign(s, { a: 2, b: 1 }), reveal: (s) => Object.assign(s, { a: Math.E, b: 1 }), answer: () => 1, why: "ln e − ln 1 = 1입니다. 넓이가 1이 되는 끝점이 e입니다." },
      { q: "∫₂⁶ 1/x dx와 ∫₁³ 1/x dx는 같을까요?", options: O("같다", "∫₂⁶이 더 크다", "∫₁³이 더 크다"), set: (s) => Object.assign(s, { a: 2, b: 3 }), answer: () => "a", why: "2부터 6까지의 영역은 1부터 3까지의 영역을 가로 2배, 세로 1/2배 한 것이라 넓이가 같습니다. 둘 다 ln 3입니다." },
    ],
  },
  {
    id: "calc2-disk-volume", grade: II, unit: 4, lesson: "Ⅳ-6", title: "원판을 쌓은 입체의 부피 — 단면의 넓이 πf(x)²", type: "3D", time: "12분",
    tags: ["입체의 부피", "단면", "정적분"], links: ["calc-volume-slice", "calc-riemann"],
    desc: "곡선 y = f(x)를 x축 둘레로 돌려 만든 입체를 얇은 원판으로 잘라 봅니다. 단면이 반지름 f(x)인 원이므로 단면의 넓이는 πf(x)²이고, 원판 부피의 합이 원판을 얇게 할수록 ∫π f(x)² dx에 다가감을 확인합니다. (단면의 넓이로 부피를 구하는 교과 내용을 회전체에 적용한 보충 예입니다.)",
    obs: ["원판 하나의 부피는 π{f(xᵢ)}²Δx입니다. (여기서는 원판 왼쪽 끝의 높이를 반지름으로 씁니다.)", "원판을 얇게 하면 합이 정적분 ∫ₐᵇ π{f(x)}² dx로 다가갑니다.", "단면의 넓이 S(x)를 알면 부피는 ∫ₐᵇ S(x) dx입니다."],
    q: "y = √x를 돌린 입체의 부피가 같은 높이·밑면의 원기둥 부피의 몇 배인지 구해 봅시다.",
    formula: "V = ∫ₐᵇ S(x) dx = ∫ₐᵇ π{f(x)}² dx",
    en: { title: "Volume by Disks", desc: "Stack thin disks with area πf(x)²." },
    space: true,
    cam: { yaw: -62, pitch: 18, scale: 62, center: [2, 0, 0.2] },
    params: [
      { key: "fn", label: "곡선", type: "select", value: "rt", options: Object.entries(DISK).map(([k, v]) => [k, v.n]) },
      { key: "n", label: "원판의 개수", min: 2, max: 40, step: 1, value: 8 },
    ],
    anim: { key: "n", min: 2, max: 40, speed: 6, label: "원판 늘리기" },
    sum(s) { const K = DISK[s.fn], dx = K.L / s.n; let v = 0; for (let i = 0; i < s.n; i++) v += Math.PI * K.f(i * dx) ** 2 * dx; return v; },
    draw(s, g) {
      const K = DISK[s.fn], dx = K.L / s.n, Y = [0, 1, 0], Z = [0, 0, 1];
      g.axes(K.L + 1, { names: ["x", "y", "z"] });
      for (let i = 0; i < s.n; i++) {
        const x0 = i * dx, x1 = x0 + dx, r = K.f(x0), col = i % 2 ? "b" : "c";
        g.circle([x0, 0, 0], Y, Z, r, { color: col, w: 1, fill: col, fo: 0.18, n: 40 });
        g.circle([x1, 0, 0], Y, Z, r, { color: col, w: 1.2, n: 40 });
        [[0, r], [0, -r], [r, 0], [-r, 0]].forEach(([a, b]) => g.seg([x0, a, b], [x1, a, b], { color: col, w: 1, opacity: 0.7 }));
      }
      const pts = []; for (let i = 0; i <= 80; i++) { const x = (K.L * i) / 80; pts.push([x, 0, K.f(x)]); }
      g.path(pts, { color: "a", w: 3, bias: 3 });
    },
    metrics(s) { const K = DISK[s.fn], v = this.sum(s); return [[`원판 ${s.n}개의 부피 합`, fmt(v, 4)], ["정적분 ∫π f(x)² dx", `${K.Vs} ≈ ${fmt(K.V, 4)}`, "key"], ["차", fmt(Math.abs(v - K.V), 4)]]; },
    predict: [
      { q: "y = √x (0 ≤ x ≤ 4)를 x축 둘레로 돌린 입체의 부피는? (소수 첫째 자리까지)", set: (s) => Object.assign(s, { fn: "rt", n: 4 }), reveal: (s) => (s.n = 40), answer: () => 8 * Math.PI, tol: 0.1, why: "∫₀⁴ π(√x)² dx = π∫₀⁴ x dx = 8π ≈ 25.1입니다." },
      { q: "원판을 한없이 얇게 하면 원판 부피의 합은?", options: O("정적분 ∫π f(x)² dx에 다가간다", "점점 커져 발산한다", "0에 다가간다"), set: (s) => Object.assign(s, { fn: "sin", n: 3 }), reveal: (s) => (s.n = 40), answer: () => "a", why: "구분구적법과 같은 생각입니다. 원판 하나는 얇아져도 개수가 늘어 합이 정적분으로 다가갑니다." },
    ],
  },

  // ───────── 확률과 통계 ─────────
  {
    id: "pst-circular", grade: PS, unit: 1, lesson: "Ⅰ-1", title: "원순열 — 원탁에서 돌리면 같은 자리", type: "조작", time: "10분",
    tags: ["원순열", "순열", "회전"], links: ["cm1-books", "pst-rep-perm"],
    desc: "n명이 원탁에 앉는 방법을 셉니다. 한 배치를 한 칸씩 돌린 n가지는 서로의 위치 관계가 같아 한 가지로 봅니다. 일렬로 세우는 n!가지를 n개씩 묶으면 원순열의 수 (n − 1)!이 됨을 확인하고, 목걸이처럼 뒤집어도 같은 경우도 생각해 봅니다.",
    obs: ["원탁의 배치를 한 칸 돌려도 각 사람의 왼쪽·오른쪽 이웃은 그대로입니다.", "일렬로 읽는 시작점이 n곳이므로 일렬 배치 n!가지가 원 배치 하나에 n개씩 대응합니다.", "뒤집어도 같은 것으로 보면(목걸이) 다시 2로 나눕니다."],
    q: "5명 가운데 두 사람이 반드시 이웃하게 원탁에 앉는 방법의 수를 구해 봅시다.",
    formula: "원순열의 수 = n!/n = (n − 1)!",
    en: { title: "Circular Permutations", desc: "Rotations of a round table are the same." },
    view: { x: [-5.6, 5.6], y: [-3.9, 3.9] },
    params: [
      { key: "n", label: "사람 수 n", min: 3, max: 7, step: 1, value: 5 },
      { key: "k", label: "돌린 칸 수", min: 0, max: 6, step: 1, value: 0 },
      { key: "flip", label: "뒤집어도 같은 것으로 (목걸이)", type: "check", value: false },
    ],
    anim: { key: "k", min: 0, max: 6, speed: 1, loop: "wrap", label: "한 칸씩 돌리기" },
    onChange(s) { s.k = s.k % s.n; },
    draw(s, g) {
      const C = [-2.2, 0.3], R = 2.1, names = "ABCDEFG".slice(0, s.n).split(""), cl = ["a", "b", "c", "d", "e", "f", "a"];
      g.circle(C, R * 0.62, { fill: "muted", fo: 0.08, color: "muted", w: 1.4 });
      g.text(C, "원탁", { dy: 5, size: 13, color: "muted" });
      names.forEach((nm, i) => { const ang = Math.PI / 2 - (2 * Math.PI * (i + s.k)) / s.n, p = [C[0] + R * Math.cos(ang), C[1] + R * Math.sin(ang)]; g.circle(p, 0.42, { fill: cl[i], fo: 0.45, color: cl[i], w: 2 }); g.text(p, nm, { dy: 5, bold: true, size: 15 }); });
      g.text([C[0], C[1] + R + 0.75], "1번 자리", { size: 11, color: "muted" });
      // 1번 자리부터 읽은 일렬 배치들
      g.text([1.2, 3.3], "1번 자리부터 시계 방향으로 읽기", { anchor: "start", bold: true, size: 13 });
      for (let j = 0; j < s.n; j++) {
        const seq = names.map((_, i) => names[(i - j + s.n * 2) % s.n]).join(" ");
        g.text([1.2, 2.5 - j * 0.68], `${j}칸: ${seq}`, { anchor: "start", size: 14, bold: j === s.k, color: j === s.k ? "a" : "muted", mono: true });
      }
    },
    metrics(s) { const L = fact(s.n), C = fact(s.n - 1); return [["일렬로 세우기 n!", String(L)], ["원순열 (n − 1)!", String(C), "key"], ...(s.flip ? [["목걸이 (n − 1)!/2", String(C / 2)]] : [])]; },
    predict: [
      { q: "5명이 원탁에 둘러앉는 방법의 수는?", set: (s) => Object.assign(s, { n: 5, k: 0 }), reveal: (s) => (s.k = 2), answer: () => 24, why: "5!/5 = 4! = 24입니다." },
      { q: "서로 다른 구슬 6개로 목걸이를 만드는 방법의 수는? (뒤집어도 같은 것으로 봄)", set: (s) => Object.assign(s, { n: 6, flip: false }), reveal: (s) => (s.flip = true), answer: () => 60, why: "원순열 5! = 120을 뒤집기 때문에 2로 나누어 60입니다." },
    ],
  },
  {
    id: "pst-variance", grade: PS, unit: 3, lesson: "Ⅲ-2", title: "확률변수의 분산 — 평균이 같아도 퍼짐은 다르다", type: "조작", time: "12분",
    tags: ["분산", "표준편차", "이산확률변수"], links: ["pst-expectation"],
    desc: "1부터 5까지의 값을 가지는 확률변수 X의 확률분포를 가운데에 몰리게, 고르게, 양 끝에 몰리게 바꾸어 봅니다. 평균은 모두 3이지만 분산 V(X) = E((X − m)²)이 퍼진 정도에 따라 달라짐을 막대와 편차 제곱의 넓이로 확인합니다.",
    obs: ["분산은 편차의 제곱 (x − m)²을 확률로 가중 평균한 값입니다.", "값들이 평균에서 멀리 퍼질수록 분산이 커집니다.", "V(X) = E(X²) − {E(X)}²으로 계산해도 같은 값입니다."],
    q: "X의 모든 값에 2를 곱하면 분산은 몇 배가 될까요?",
    formula: "V(X) = Σ(xᵢ − m)²pᵢ = E(X²) − {E(X)}², σ(X) = √V(X)",
    en: { title: "Variance of a Random Variable", desc: "Same mean, different spread." },
    view: { x: [-0.2, 6.8], y: [-0.85, 4.2] },
    params: [{ key: "w", label: "퍼짐 (가운데 몰림 → 양 끝 몰림)", min: 0, max: 1, step: 0.01, value: 0.3 }],
    anim: { key: "w", min: 0, max: 1, speed: 0.3, loop: "bounce", label: "퍼뜨리기" },
    P(s) { return MID.map((m, i) => (1 - s.w) * m + s.w * END[i]); },
    draw(s, g) {
      const P = this.P(s), m = VX.reduce((t, x, i) => t + x * P[i], 0), V = VX.reduce((t, x, i) => t + (x - m) ** 2 * P[i], 0), sd = Math.sqrt(V), k = 6;
      g.seg([0.3, 0], [6.3, 0], { color: "axis", w: 1.6 });
      VX.forEach((x, i) => { g.poly([[x - 0.32, 0], [x + 0.32, 0], [x + 0.32, P[i] * k], [x - 0.32, P[i] * k]], { fill: "b", fo: 0.45, color: "b", w: 1.4 }); g.text([x, P[i] * k], fmt(P[i], 2), { dy: -6, size: 12, color: "b", bold: true }); g.text([x, 0], String(x), { dy: 18, size: 13, bold: true }); });
      g.poly([[m - sd, -0.55], [m + sd, -0.55], [m + sd, -0.3], [m - sd, -0.3]], { fill: "a", fo: 0.35, stroke: false });
      g.text([m + sd, -0.42], "m ± σ", { dx: 6, anchor: "start", size: 12, color: "a", bold: true });
      g.seg([m, -0.6], [m, 3.9], { color: "e", w: 2, dash: "6 4" }).text([m, 3.9], "평균 m = 3", { dy: -4, bold: true, color: "e", size: 13 });
    },
    metrics(s) { const P = this.P(s), m = VX.reduce((t, x, i) => t + x * P[i], 0), E2 = VX.reduce((t, x, i) => t + x * x * P[i], 0), V = VX.reduce((t, x, i) => t + (x - m) ** 2 * P[i], 0); return [["E(X)", fmt(m, 3)], ["V(X) = Σ(x − m)²p", fmt(V, 3), "key"], ["E(X²) − {E(X)}²", fmt(E2 - m * m, 3)], ["σ(X)", fmt(Math.sqrt(V), 3)]]; },
    predict: [
      { q: "X가 1, 2, 3, 4, 5를 각각 확률 1/5로 가질 때 V(X)는?", answer: () => 2, why: "편차의 제곱 4, 1, 0, 1, 4의 평균이므로 10/5 = 2입니다." },
      { q: "평균이 같을 때 분산이 더 큰 쪽은?", options: O("양 끝에 몰린 분포", "가운데에 몰린 분포"), set: (s) => (s.w = 0), reveal: (s) => (s.w = 1), answer: () => "a", why: "값들이 평균 3에서 멀리 있을수록 편차의 제곱이 커집니다." },
    ],
  },
];
