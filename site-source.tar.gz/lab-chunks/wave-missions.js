const near=(a,b)=>Math.abs(a-b)<.0001;
const angle=(s,n)=>near(s.angle,n);
const phase=(s,n)=>near(Math.abs(s.phase),n);
const task=(title,goal,hint,why,check)=>({title,goal,hint,why,check});
export const MISSIONS={
 space:[
  task('가장 높은 점','θ를 90°로 맞추어 높이가 1인 점을 찾으세요.','90° 버튼을 누르고 원 위 점의 높이를 보세요.','90°에서 sin θ=1이고 cos θ=0입니다.',s=>angle(s,90)),
  task('왼쪽 끝점','θ를 180°로 맞추어 가로 좌표가 −1인 점을 찾으세요.','180° 버튼을 사용하세요.','180°에서 높이는 0이고 가로 좌표는 −1입니다.',s=>angle(s,180)),
  task('아래쪽 끝점','θ를 270°로 맞추어 사인값 −1을 확인하세요.','270° 버튼을 사용하세요.','사인의 부호는 단위원 위 점의 높이와 같습니다.',s=>angle(s,270))],
 flat:[
  task('서로 다른 시작','θ를 0°로 맞추고 두 그래프의 시작값을 비교하세요.','0°에서 sin과 cos 값을 보세요.','사인은 0에서 시작하고 코사인은 1에서 시작합니다.',s=>angle(s,0)),
  task('한쪽이 최대일 때','θ를 90°로 맞추어 사인과 코사인을 비교하세요.','90° 버튼을 누르세요.','사인이 1일 때 코사인은 0입니다.',s=>angle(s,90)),
  task('한 주기 완성','θ를 360°로 맞추어 두 그래프를 한 주기 그리세요.','360° 버튼을 사용하세요.','360°=2π rad 후 두 값이 처음과 같아집니다.',s=>angle(s,360))],
 transform:[
  task('높이 두 배','A=2로 바꾸어 진폭을 2로 만드세요.','진폭 A 또는 진폭 2배 버튼을 사용하세요.','중심선에서 최댓값까지의 거리가 진폭 A입니다.',s=>near(s.a,2)),
  task('주기 절반','B=2로 바꾸어 주기를 180°로 만드세요.','회전 배율 B 또는 주기 절반 버튼을 사용하세요.','주기는 360°/B입니다.',s=>near(s.b,2)),
  task('코사인과 만나기','A=1과 B=1 및 D=0을 두고 φ=90°로 맞추세요.','90° 앞서기 버튼이 이 조건을 만듭니다.','sin(θ+90°)=cos θ입니다.',s=>near(s.a,1)&&near(s.b,1)&&near(s.d,0)&&near(s.phase,90))],
 tangent:[
  task('높이와 가로가 같을 때','θ=45°에서 탄젠트 1을 찾으세요.','각도 직접 입력에 45를 넣으세요.','sin 45°와 cos 45°가 같아서 비는 1입니다.',s=>angle(s,45)),
  task('정의되지 않는 곳','θ=90°로 맞추어 값이 정의되지 않는 이유를 확인하세요.','90° 버튼을 사용하세요.','분모 cos 90°가 0이므로 탄젠트는 정의되지 않습니다.',s=>angle(s,90)),
  task('음수인 비','θ=135°에서 탄젠트 −1을 찾으세요.','9각도 직접 입력에 45를 넣으세요.','높이는 양수이고 가로 좌표는 음수이므로 비는 −1입니다.',s=>angle(s,135))],
 sum:[
  task('완전 보강','A=1과 B=1 및 φ=0°에서 θ=90°로 맞추세요.','보강 버튼 다음에 90°를 누르세요.','1+1=2이므로 합성값은 2입니다.',s=>near(s.a,1)&&near(s.b,1)&&near(s.phase,0)&&angle(s,90)),
  task('완전 상쇄','A=1과 B=1 및 위상 차이 180°를 만드세요.','상쇄 버튼을 사용하세요.','두 파동은 모든 각도에서 크기가 같고 부호가 반대입니다.',s=>near(s.a,1)&&near(s.b,1)&&phase(s,180)),
  task('다른 배율','A=1과 B=2 및 φ=0°를 만드세요.','2배 진동 버튼을 사용하세요.','둘째 파동은 첫 파동이 한 번 진동할 때 두 번 진동합니다.',s=>near(s.a,1)&&near(s.b,2)&&near(s.phase,0))],
 lissajous:[
  task('직선 만들기','B=1과 φ=0°로 직선을 만드세요.','직선 버튼을 사용하세요.','x=sin θ와 y=A sin θ이므로 y=Ax입니다.',s=>near(s.b,1)&&near(s.phase,0)),
  task('원 만들기','A=1과 B=1 및 φ=90°로 원을 만드세요.','원 버튼을 사용하세요.','x²+y²=sin²θ+cos²θ=1입니다.',s=>near(s.a,1)&&near(s.b,1)&&phase(s,90)),
  task('8자 만들기','A=1과 B=2 및 φ=0°로 8자 자취를 만드세요.','8자 버튼을 사용하세요.','세로 진동이 가로 진동보다 2배 빠릅니다.',s=>near(s.a,1)&&near(s.b,2)&&near(s.phase,0))],
 beats:[
  task('느린 변화','Δ=0.1로 느린 맥놀이를 만드세요.','느린 맥놀이 버튼을 사용하세요.','세기 반복 간격은 360°/0.1=3600°입니다.',s=>near(s.delta,.1)),
  task('빠른 변화','Δ=0.5로 빠른 맥놀이를 만드세요.','빠른 맥놀이 버튼을 사용하세요.','배율 차이가 커지면 반복 간격은 720°로 짧아집니다.',s=>near(s.delta,.5)),
  task('포락선이 0인 순간','Δ=0.2와 θ=900°를 맞추세요.','차이 슬라이더를 0.2로 바꾼 뒤 900°를 누르세요.','θ=5π일 때 2|cos(0.2θ/2)|=0입니다.',s=>near(s.delta,.2)&&angle(s,900))],
 fourier:[
  task('첫 성분','사각파를 선택하고 항의 개수를 1로 만드세요.','사각파 다음에 1개 합성을 누르세요.','사각파의 첫 성분은 (4/π)sin θ입니다.',s=>s.shape==='square'&&s.terms===1),
  task('모서리에 다가가기','사각파를 9개 항으로 합성하세요.','사각파 다음에 9개 합성을 누르세요.','모양이 사각파에 가까워져도 불연속점 근처의 넘침은 남습니다.',s=>s.shape==='square'&&s.terms===9),
  task('계수가 바뀌면','삼각파를 9개 항으로 합성하세요.','삼각파 다음에 9개 합성을 누르세요.','삼각파의 홀수 고조파 계수는 1/n²에 비례합니다.',s=>s.shape==='triangle'&&s.terms===9)],
 damped:[
  task('감쇠 없애기','λ=0으로 반지름 1의 회전을 되찾으세요.','감쇠 없음 버튼을 사용하세요.','지수 인자가 1이 되어 기본 사인 곡선이 됩니다.',s=>near(s.decay,0)),
  task('천천히 줄이기','λ=0.1로 완만하게 줄어드는 진동을 만드세요.','천천히 감소 버튼을 사용하세요.','반지름은 e^(−0.1θ)로 감소합니다.',s=>near(s.decay,.1)),
  task('한 바퀴 후 비교','λ=0.4와 θ=360°를 맞추어 포락선을 확인하세요.','빠르게 감소 다음에 각도 직접 입력에 360을 넣으세요.','한 바퀴 후 포락선은 e^(−0.8π)로 약 0.081입니다.',s=>near(s.decay,.4)&&angle(s,360))],
 traveling:[
  task('오른쪽 전달','방향을 오른쪽으로 두고 k=1로 맞추세요.','오른쪽 진행과 k=1을 누르세요.','sin(kx−θ)의 같은 위상은 θ가 커질수록 오른쪽으로 이동합니다.',s=>s.direction===1&&s.waveK===1),
  task('왼쪽 전달','방향을 왼쪽으로 두고 k=2로 맞추세요.','왼쪽 진행과 k=2를 누르세요.','sin(kx+θ)는 왼쪽으로 진행하며 파장은 π입니다.',s=>s.direction===-1&&s.waveK===2),
  task('더 짧은 파장','k=3으로 파장을 2π/3으로 만드세요.','k=3 버튼을 사용하세요.','같은 길이 2π에 3개의 파장이 들어갑니다.',s=>s.waveK===3)],
 standing:[
  task('항상 고정된 점','관찰점을 마디로 옮겨 이 점의 진폭을 0으로 만드세요.','마디 선택 버튼을 사용하세요.','마디는 sin(kx)=0이므로 위상과 관계없이 움직이지 않습니다.',s=>Math.abs(Math.sin(s.waveK*s.probe*2*Math.PI))<.0001),
  task('가장 크게 진동','A=1에서 배를 선택하고 θ=0°로 맞추세요.','진폭을 1로 두고 배 선택 다음에 겹침 최대를 누르세요.','배에서는 두 진행파가 더해져 진폭이 2입니다.',s=>near(s.a,1)&&Math.abs(Math.abs(Math.sin(s.waveK*s.probe*2*Math.PI))-1)<.0001&&angle(s,0)),
  task('순간 수평과 마디','배를 선택한 상태에서 θ=90°로 맞추세요.','배 선택 다음에 순간 수평을 누르세요.','현재 높이는 0이어도 배의 진폭은 2A로 남습니다. 마디와 다릅니다.',s=>Math.abs(Math.abs(Math.sin(s.waveK*s.probe*2*Math.PI))-1)<.0001&&angle(s,90))]
};
export const MISSION_COUNT=Object.values(MISSIONS).reduce((n,x)=>n+x.length,0);
export function mountMissions(host,{getState,pause,onProgress}){
 const key='atelier-wave-missions-v1',valid=new Set(Object.entries(MISSIONS).flatMap(([v,ms])=>ms.map((_,i)=>v+':'+i)));let done=new Set(),selected={};
 try{const saved=JSON.parse(localStorage.getItem(key)||'[]');if(Array.isArray(saved))done=new Set(saved.filter(x=>valid.has(x)));}catch{}
 host.className='cw-missions';host.dataset.mathPlain='';
 const count=()=>onProgress?.(done.size,MISSION_COUNT);
 function render(){const view=getState().view,ms=MISSIONS[view];if(!ms)return;const opened=host.querySelector('details')?.open??true;const i=selected[view]??0,m=ms[i];
 host.innerHTML=`<details ${opened?'open':''}><summary><b>직접 풀어보는 탐구 미션</b><span>전체 ${done.size} / ${MISSION_COUNT} 완료</span></summary><div class="cw-mission-body"><div class="cw-mission-tabs" role="group" aria-label="탐구 미션 선택">${ms.map((m,j)=>`<button data-mission-index="${j}" aria-pressed="${i===j}">${done.has(view+':'+j)?'✓ ':''}${j+1}. ${m.title}</button>`).join('')}</div><p class="cw-mission-goal">${m.goal}</p><div class="cw-buttons"><button data-mission-check>현재 조건 확인</button><button data-mission-hint>힌트 보기</button></div><p class="cw-mission-response" role="status">${done.has(view+':'+i)?'완료한 미션입니다. 다른 조건으로 다시 탐구해 보세요.':'그림과 조작 패널로 조건을 만든 뒤 확인해 보세요.'}</p></div></details>`;
 host.querySelectorAll('[data-mission-index]').forEach(b=>b.onclick=()=>{selected[view]=Number(b.dataset.missionIndex);render();});
 host.querySelector('[data-mission-hint]').onclick=()=>host.querySelector('.cw-mission-response').textContent=m.hint;
 host.querySelector('[data-mission-check]').onclick=()=>{pause();const current=getState();if(current.view!==view){render();return;}if(!m.check(current)){host.querySelector('.cw-mission-response').textContent='아직 조건이 맞지 않습니다. '+m.hint;return;}done.add(view+':'+i);let saved=true;try{localStorage.setItem(key,JSON.stringify([...done]));}catch{saved=false;}render();host.querySelector('.cw-mission-response').textContent='성공했습니다. '+m.why+(saved?'':' 이 브라우저에는 완료 기록을 저장할 수 없습니다.');count();};count();}
 render();return {render,count:()=>done.size,get completed(){return [...done];},destroy(){host.remove();}};
}
