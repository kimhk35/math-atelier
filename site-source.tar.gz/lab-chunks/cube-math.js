// 3×3 큐브의 조각 모형 — 꼭짓점 8개와 모서리 12개의 자리·방향으로 상태를 나타낸다 (코치엠바 표기)
// 꼭짓점 자리: URF UFL ULB UBR DFR DLF DBL DRB / 모서리 자리: UR UF UL UB DR DF DL DB FR FL BL BR
const M = {
  U: { cp: [3, 0, 1, 2, 4, 5, 6, 7], co: [0, 0, 0, 0, 0, 0, 0, 0], ep: [3, 0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11], eo: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
  R: { cp: [4, 1, 2, 0, 7, 5, 6, 3], co: [2, 0, 0, 1, 1, 0, 0, 2], ep: [8, 1, 2, 3, 11, 5, 6, 7, 4, 9, 10, 0], eo: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
  F: { cp: [1, 5, 2, 3, 0, 4, 6, 7], co: [1, 2, 0, 0, 2, 1, 0, 0], ep: [0, 9, 2, 3, 4, 8, 6, 7, 1, 5, 10, 11], eo: [0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0] },
  D: { cp: [0, 1, 2, 3, 5, 6, 7, 4], co: [0, 0, 0, 0, 0, 0, 0, 0], ep: [0, 1, 2, 3, 5, 6, 7, 4, 8, 9, 10, 11], eo: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
  L: { cp: [0, 2, 6, 3, 4, 1, 5, 7], co: [0, 1, 2, 0, 0, 2, 1, 0], ep: [0, 1, 10, 3, 4, 5, 9, 7, 8, 2, 6, 11], eo: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0] },
  B: { cp: [0, 1, 3, 7, 4, 5, 2, 6], co: [0, 0, 1, 2, 0, 0, 2, 1], ep: [0, 1, 2, 11, 4, 5, 6, 10, 8, 9, 3, 7], eo: [0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1] },
};
export const solved = () => ({ cp: [0, 1, 2, 3, 4, 5, 6, 7], co: Array(8).fill(0), ep: [...Array(12).keys()], eo: Array(12).fill(0) });
export const clone = (c) => ({ cp: c.cp.slice(), co: c.co.slice(), ep: c.ep.slice(), eo: c.eo.slice() });
// a 다음에 b를 한 결과 (a * b)
export function mul(a, b) {
  return {
    cp: b.cp.map((j) => a.cp[j]), co: b.cp.map((j, i) => (a.co[j] + b.co[i]) % 3),
    ep: b.ep.map((j) => a.ep[j]), eo: b.ep.map((j, i) => (a.eo[j] + b.eo[i]) % 2),
  };
}
export const equal = (a, b) => ["cp", "co", "ep", "eo"].every((k) => a[k].every((v, i) => v === b[k][i]));
export const isSolved = (c) => equal(c, solved());
// 수순 글자 → 수 목록. R, R', R2 / 공백 구분
export function parse(str) {
  const out = [];
  for (const t of String(str).trim().split(/\s+/).filter(Boolean)) {
    const f = t[0].toUpperCase(); if (!M[f]) throw new Error("모르는 면: " + t);
    const k = /2/.test(t) ? 2 : /['’′]/.test(t) ? 3 : 1;
    out.push([f, k]);
  }
  return out;
}
export function apply(c, moves) {
  let s = clone(c);
  for (const [f, k] of moves) for (let i = 0; i < k; i++) s = mul(s, M[f]);
  return s;
}
// 역수순: 거꾸로 읽고 방향을 바꾼다 (R → R′, R2 → R2)
export const inverse = (moves) => moves.slice().reverse().map(([f, k]) => [f, 4 - k]);
export const label = (moves) => moves.map(([f, k]) => f + (k === 2 ? "2" : k === 3 ? "′" : "")).join(" ");
// 수순 하나의 상태(순열)로 바꾼 뒤 반복 횟수 = 주기
export function order(moves, cap = 2000) {
  const g = apply(solved(), moves); let s = clone(g), n = 1;
  while (!isSolved(s) && n < cap) { s = mul(s, g); n++; }
  return isSolved(s) ? n : null;
}
// 조각의 고리 구조: 자리 이동 고리 길이와 방향이 쌓이는 정도
export function cycles(c) {
  const out = { corners: [], edges: [] };
  const walk = (perm, ori, mod, list) => {
    const seen = Array(perm.length).fill(false);
    for (let i = 0; i < perm.length; i++) {
      if (seen[i]) continue;
      let j = i, len = 0, tw = 0;
      while (!seen[j]) { seen[j] = true; tw += ori[j]; j = perm[j]; len++; }
      tw %= mod;
      if (len > 1 || tw) list.push({ len, twist: tw, period: len * (tw ? mod / gcd(mod, tw) : 1) });
    }
  };
  walk(c.cp, c.co, 3, out.corners); walk(c.ep, c.eo, 2, out.edges);
  return out;
}
export const gcd = (a, b) => (b ? gcd(b, a % b) : a);
export const lcm = (a, b) => (a / gcd(a, b)) * b;
// 불변량: 꼭짓점 방향 합(mod 3), 모서리 방향 합(mod 2), 두 순열의 홀짝
export function parity(p) { let s = 0; const seen = Array(p.length).fill(false); for (let i = 0; i < p.length; i++) { if (seen[i]) continue; let j = i, l = 0; while (!seen[j]) { seen[j] = true; j = p[j]; l++; } s += l - 1; } return s % 2; }
export function invariants(c) {
  return { twist: c.co.reduce((a, b) => a + b, 0) % 3, flip: c.eo.reduce((a, b) => a + b, 0) % 2, cpar: parity(c.cp), epar: parity(c.ep) };
}
export const solvable = (c) => { const v = invariants(c); return v.twist === 0 && v.flip === 0 && v.cpar === v.epar; };
// 스티커 54개 색 (U R F D L B 순, 면마다 9칸)
const CF = [[8, 9, 20], [6, 18, 38], [0, 36, 47], [2, 45, 11], [29, 26, 15], [27, 44, 24], [33, 53, 42], [35, 17, 51]];
const EF = [[5, 10], [7, 19], [3, 37], [1, 46], [32, 16], [28, 25], [30, 43], [34, 52], [23, 12], [21, 41], [50, 39], [48, 14]];
const CC = [[0, 1, 2], [0, 2, 4], [0, 4, 5], [0, 5, 1], [3, 2, 1], [3, 4, 2], [3, 5, 4], [3, 1, 5]];
const EC = [[0, 1], [0, 2], [0, 4], [0, 5], [3, 1], [3, 2], [3, 4], [3, 5], [2, 1], [2, 4], [5, 4], [5, 1]];
export function facelets(c) {
  const f = Array(54).fill(0);
  for (let i = 0; i < 6; i++) f[i * 9 + 4] = i;
  for (let i = 0; i < 8; i++) for (let n = 0; n < 3; n++) f[CF[i][(n + c.co[i]) % 3]] = CC[c.cp[i]][n];
  for (let i = 0; i < 12; i++) for (let n = 0; n < 2; n++) f[EF[i][(n + c.eo[i]) % 2]] = EC[c.ep[i]][n];
  return f;
}
export const FACE_COLORS = ["#f4f4ee", "#d8433f", "#2e9e5b", "#f2cc3a", "#ef8a2f", "#2f6fd6"]; // U흰 R빨 F초 D노 L주 B파
export const FACE_NAMES = ["U", "R", "F", "D", "L", "B"];
// 전개도 그리기 (십자 모양): g는 Plot, 왼쪽 위 (x0, y0), 칸 크기 k, hi = 강조할 스티커 번호 집합
export function drawNet(g, f, x0, y0, k, hi) {
  const at = { U: [3, 0], L: [0, 3], F: [3, 3], R: [6, 3], B: [9, 3], D: [3, 6] };
  ["U", "R", "F", "D", "L", "B"].forEach((name, fi) => {
    const [cx, cy] = at[name];
    for (let r = 0; r < 3; r++) for (let q = 0; q < 3; q++) {
      const idx = fi * 9 + r * 3 + q, x = x0 + (cx + q) * k, y = y0 - (cy + r) * k;
      const lit = hi && hi.has(idx);
      g.poly([[x, y], [x + k, y], [x + k, y - k], [x, y - k]], { fill: FACE_COLORS[f[idx]], fo: 1, color: lit ? "#13294b" : "#3b4450", w: lit ? 3.4 : 1.2 });
    }
    g.text([x0 + (cx + 1.5) * k, y0 - (cy + 1.5) * k], name, { size: 11, color: "#13294b", dy: 4, bold: true });
  });
}
// 한 상태에서 제자리가 아닌 스티커
export function movedStickers(c) { const f = facelets(c), s = new Set(); f.forEach((v, i) => { if (v !== Math.floor(i / 9)) s.add(i); }); return s; }
