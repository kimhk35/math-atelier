// 교과서를 한 번 더 훑어 추가한 실험 (8차) — 기본수학1·2 · 중3 창의UP · 기하 공학 도구 · 확통 탐구 & 융합 · 대수 탐구 & 융합
import { fmt, frac, surd, dist, sub, add, mul, norm, dot, len, cross, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const V = { x: [-7, 7], y: [-5, 5] };
const lcg = (seed) => { let x = seed % 2147483647 || 7; return () => ((x = (x * 16807) % 2147483647) / 2147483647); };
const C = (n, r) => { if (r < 0 || r > n) return 0; let v = 1; for (let i = 1; i <= r; i++) v = (v * (n - r + i)) / i; return Math.round(v); };
const FACT = (n) => (n <= 1 ? 1 : n * FACT(n - 1));
const PAPER = [[841, 1189], [594, 841], [420, 594], [297, 420], [210, 297], [148, 210], [105, 148], [74, 105], [52, 74]];
const LEVEL = ["a", "b", "c", "e", "f", "d", "a", "b", "c"];
// 원 위 두 점 사이에서, away 방향을 지나는 쪽 호의 각 범위
function wrapArc(c, p, q, away) {
  let a1 = Math.atan2(p[1] - c[1], p[0] - c[0]), a2 = Math.atan2(q[1] - c[1], q[0] - c[0]);
  while (a2 < a1) a2 += 2 * Math.PI;
  const m = (a1 + a2) / 2;
  if (Math.cos(m) * away[0] + Math.sin(m) * away[1] < 0) { const t = a1; a1 = a2; a2 = t + 2 * Math.PI; }
  return [a1, a2];
}
const GENE = { AA: ["A", "A"], AO: ["A", "O"], BB: ["B", "B"], BO: ["B", "O"], AB: ["A", "B"], OO: ["O", "O"] };
const blood = (x, y) => { const s = new Set([x, y]); return s.has("A") && s.has("B") ? "AB" : s.has("A") ? "A" : s.has("B") ? "B" : "O"; };
const BCOL = { A: "a", B: "b", AB: "c", O: "f" };
// 하노이 탑 최소 이동 목록
function hanoiMoves(n) { const m = []; const go = (k, a, b, c) => { if (!k) return; go(k - 1, a, c, b); m.push([k, a, c]); go(k - 1, b, a, c); }; go(n, 0, 1, 2); return m; }
// 스마트 팜: 종자 배열 전체
const SEEDS = { 청: ["청치마", "c"], 적: ["적치마", "a"], 로: ["로메인", "b"], 아: ["아이스버그", "e"] };
const FARM = (() => { const out = [], cnt = { 청: 3, 적: 2, 로: 1, 아: 1 }, cur = []; const rec = () => { if (cur.length === 7) { out.push(cur.join("")); return; } for (const k of Object.keys(cnt)) if (cnt[k]) { cnt[k]--; cur.push(k); rec(); cur.pop(); cnt[k]++; } }; rec(); return out; })();
// 정팔면체 꼭짓점
const OCT = { A: [0, 0, 2.2], F: [0, 0, -2.2], B: [2.2, 0, 0], C: [0, 2.2, 0], D: [-2.2, 0, 0], E: [0, -2.2, 0] };
const OCT_EDGES = ["AB", "AC", "AD", "AE", "FB", "FC", "FD", "FE", "BC", "CD", "DE", "EB"];
const OCT_FACES = ["ABC", "ACD", "ADE", "AEB", "FBC", "FCD", "FDE", "FEB"];

export default [
  {
    id: "m2-a4-paper", grade: 2, unit: 7, lesson: "7.1 탐구 & 융합", title: "A4 용지 탄생의 비밀 — 반으로 잘라도 닮은 종이", type: "조작", time: "10분",
    tags: ["닮음", "√2", "A판 규격"], color: "#2b74c7", links: ["m2-pizza", "m2-right-similar", "cul-golden-card"],
    desc: "A0 용지를 반으로 자르면 A1, 다시 반으로 자르면 A2가 됩니다. 긴 변과 짧은 변의 비가 √2 : 1이면 반으로 잘라도 처음 종이와 닮은 도형이 된다는 것을 확인하고, 3 : 2 비율의 종이와 비교합니다.",
    obs: ["반으로 자른 종이가 처음 종이와 닮으려면 x : 1 = 1 : x/2, 즉 x² = 2여야 합니다.", "√2 : 1 비율의 종이는 몇 번을 잘라도 같은 모양이 나옵니다.", "3 : 2 비율의 종이는 자를 때마다 3 : 2와 4 : 3이 번갈아 나타납니다.", "A0의 넓이는 1 m²이므로 A4의 넓이는 1/16 m²입니다."],
    q: "A4 용지 두 장을 나란히 붙이면 어떤 규격의 종이가 될까요?",
    formula: "x : 1 = 1 : x/2 ⇒ x² = 2 ⇒ x = √2",
    en: { title: "The Secret of A4 Paper", desc: "Halving an √2 : 1 sheet gives a similar sheet; compare with a 3 : 2 sheet." },
    view: BOX,
    params: [{ key: "n", label: "자른 횟수", min: 0, max: 8, step: 1, value: 4 }, { key: "r", label: "처음 종이의 비율", type: "seg", value: "root2", options: [["root2", "√2 : 1 (A판)"], ["32", "3 : 2"]] }],
    anim: { key: "n", min: 0, max: 8, speed: 1.2, label: "차례로 자르기" },
    ratio(s) { return s.r === "root2" ? Math.SQRT2 : 1.5; },
    pieces(s) {
      const k = this.ratio(s), W0 = 10.4, out = [];
      let R = [0.8, 1.2, W0, W0 / k];
      for (let i = 1; i <= s.n; i++) {
        const [x, y, w, h] = R;
        if (w >= h) { out.push([x, y, w / 2, h, i]); R = [x + w / 2, y, w / 2, h]; }
        else { out.push([x, y + h / 2, w, h / 2, i]); R = [x, y, w, h / 2]; }
      }
      out.push([...R, s.n]);
      return out;
    },
    draw(s, g) {
      const P = this.pieces(s);
      P.forEach(([x, y, w, h, i], j) => {
        const last = j === P.length - 1;
        g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], { fill: LEVEL[i], fo: last ? 0.42 : 0.14, color: last ? LEVEL[i] : "ink", w: last ? 2.6 : 1.4 });
        if (w > 0.7 && h > 0.45) g.text([x + w / 2, y + h / 2], s.r === "root2" ? `A${i}` : `${i}번`, { dy: 5, bold: true, size: Math.max(10, Math.min(24, 9 + h * 3.2)), color: last ? LEVEL[i] : "muted" });
      });
      const L = P[P.length - 1], long = Math.max(L[2], L[3]), short = Math.min(L[2], L[3]);
      const x0 = 12.3, sw = 2.6, sh = sw / (long / short);
      g.text([13.6, 10.2], "마지막 조각", { bold: true, size: 13, color: "muted" });
      g.poly([[x0, 8.6 - sh], [x0 + sw, 8.6 - sh], [x0 + sw, 8.6], [x0, 8.6]], { fill: LEVEL[s.n], fo: 0.42, color: LEVEL[s.n], w: 2.2 });
      g.text([13.6, 8.6 - sh - 0.2], `긴 변 : 짧은 변 = ${fmt(long / short, 3)} : 1`, { dy: 14, size: 12.5, bold: true });
      if (s.r === "root2") { const [a, b] = PAPER[s.n]; g.text([13.6, 5.2], `A${s.n} = ${a} × ${b} mm`, { size: 14, bold: true, color: "ink" }); g.text([13.6, 4.4], `넓이 1/${2 ** s.n} m²`, { size: 13, color: "muted" }); }
      else g.text([13.6, 5.2], s.n % 2 ? "4 : 3 — 처음과 닮지 않음" : "3 : 2 — 처음과 닮음", { size: 13, bold: true, color: s.n % 2 ? "d" : "c" });
    },
    metrics(s) { const P = this.pieces(s), L = P[P.length - 1], r = Math.max(L[2], L[3]) / Math.min(L[2], L[3]); return [["자른 횟수", `${s.n}번 → 조각 ${2 ** s.n}개`], ["마지막 조각의 비", `${fmt(r, 4)} : 1`, "key"], ["처음 종이와 닮음?", Math.abs(r - this.ratio(s)) < 1e-6 ? "닮음" : "닮지 않음"], s.r === "root2" ? [`A${s.n} 크기`, `${PAPER[s.n][0]} × ${PAPER[s.n][1]} mm`] : ["넓이", `처음의 1/${2 ** s.n}`]]; },
  },
  {
    id: "m2-isosceles-spiral", grade: 2, unit: 7, lesson: "7.5 과제", title: "직각이등변삼각형으로 만드는 나선", type: "조작", time: "8분",
    tags: ["피타고라스 정리", "√2", "나선"], color: "#2b74c7", links: ["lab-theodorus", "g2-pythagoras", "m2-a4-paper"],
    desc: "빗변을 다음 삼각형의 한 변으로 삼아 직각이등변삼각형을 계속 붙여 나선을 만듭니다. 선분의 길이가 1, √2, 2, 2√2, 4, …로 √2배씩 커지는 것을 피타고라스 정리로 확인합니다.",
    obs: ["직각이등변삼각형의 빗변은 한 변의 √2배입니다.", "두 번 붙이면 길이가 정확히 2배가 되어 정수가 나타납니다.", "8번 붙이면 한 바퀴를 돌아 처음 방향으로 돌아오고 길이는 16배가 됩니다."],
    q: "처음 선분의 길이가 1 cm일 때, 10번째 삼각형의 빗변의 길이는 몇 cm일까요?",
    formula: "빗변 = √2 × 변 · OPₙ = (√2)ⁿ",
    en: { title: "Spiral of Right Isosceles Triangles", desc: "Lengths grow by a factor √2 each step: 1, √2, 2, 2√2, 4, …" },
    view(s) { const R = Math.max(1.5, Math.SQRT2 ** s.n * 1.08); return { x: [-R * 1.35, R * 1.35], y: [-R, R] }; },
    params: [{ key: "n", label: "붙인 삼각형 수", min: 1, max: 10, step: 1, value: 5 }],
    anim: { key: "n", min: 1, max: 10, speed: 1.3, label: "하나씩 붙이기" },
    pts(s) { const P = [[1, 0]]; for (let i = 0; i < s.n; i++) { const p = P[P.length - 1]; P.push(add(p, [-p[1], p[0]])); } return P; },
    draw(s, g) {
      const P = this.pts(s), O = [0, 0], cols = ["a", "b", "c", "e", "f", "d"];
      for (let i = 0; i < s.n; i++) g.poly([O, P[i], P[i + 1]], { fill: cols[i % 6], fo: 0.2 + 0.25 * (i === s.n - 1), color: cols[i % 6], w: 1.6 });
      g.seg(O, P[0], { color: "ink", w: 3 });
      for (let i = 0; i < s.n; i++) { g.right(P[i], O, P[i + 1], { size: 10 }); g.seg(P[i], P[i + 1], { color: "ink", w: 2.2 }); }
      g.seg(O, P[s.n], { color: "d", w: 3.4 });
      const last = P[s.n], mid = mul(last, 0.55);
      g.text(mid, surd(2 ** s.n), { dy: -8, bold: true, color: "d", size: 15 });
      g.point(O, "O", { r: 4, dx: -14, dy: 16 });
    },
    metrics(s) { const L = [...Array(s.n + 1).keys()].map((k) => surd(2 ** k)); return [["OP 길이", L.join(", ")], [`${s.n}번째 빗변`, surd(2 ** s.n), "key"], ["정수가 되는 경우", "붙인 수가 짝수일 때"], ["넓이의 합", `${fmt((2 ** s.n - 1) / 2, 1)} (처음 삼각형 ½의 ${2 ** s.n - 1}배)`]]; },
  },
  {
    id: "m2-punnett", grade: 2, unit: 8, lesson: "8 과제", title: "유전자형으로 보는 혈액형의 확률", type: "데이터", time: "10분",
    tags: ["확률", "경우의 수", "다항식의 곱"], color: "#2b74c7", links: ["pst-dice-sum", "pst-total-prob", "cm1-sum-product"],
    desc: "부모의 혈액형 유전자형을 고르면 아이가 받을 수 있는 유전자 조합 4가지를 표로 만들고, 아이의 혈액형이 A, B, AB, O형일 확률을 구합니다. 표는 다항식의 곱 (A + O)(B + O)를 전개하는 것과 같습니다.",
    obs: ["부모에게서 유전자를 하나씩 받으므로 모든 경우는 2 × 2 = 4가지입니다.", "네 경우가 일어날 가능성은 모두 같습니다.", "AO형과 BO형 부모에게서는 네 가지 혈액형이 모두 나올 수 있습니다."],
    q: "부모가 모두 A형인데 O형 아이가 태어날 수 있을까요? 확률은 얼마일까요?",
    formula: "(A + O)(B + O) = AB + AO + BO + OO",
    en: { title: "Blood Types from Genotypes", desc: "A Punnett square gives the probability of each blood type." },
    view: BOX,
    params: [{ key: "m", label: "어머니 유전자형", type: "select", value: "AO", options: Object.keys(GENE).map((k) => [k, `${k} (${blood(...GENE[k])}형)`]) }, { key: "f", label: "아버지 유전자형", type: "select", value: "BO", options: Object.keys(GENE).map((k) => [k, `${k} (${blood(...GENE[k])}형)`]) }],
    init: () => ({ kids: null }),
    buttons: [["sim", "아이 100명 시뮬레이션"], ["clear", "지우기"]],
    onDo(k, s) { if (k === "clear") { s.kids = null; return; } const c = { A: 0, B: 0, AB: 0, O: 0 }; for (let i = 0; i < 100; i++) c[blood(GENE[s.m][Math.random() < 0.5 ? 0 : 1], GENE[s.f][Math.random() < 0.5 ? 0 : 1])]++; s.kids = c; },
    onChange(s) { s.kids = null; },
    prob(s) { const c = { A: 0, B: 0, AB: 0, O: 0 }; for (const x of GENE[s.m]) for (const y of GENE[s.f]) c[blood(x, y)] += 0.25; return c; },
    draw(s, g) {
      const M = GENE[s.m], F = GENE[s.f], x0 = 1.8, y0 = 1.6, cs = 2.6;
      g.text([x0 + cs, y0 + 2 * cs + 1.1], `아버지 ${s.f}`, { bold: true, size: 14 });
      g.text([x0 - 0.9, y0 + cs], `어머니 ${s.m}`, { bold: true, size: 14, anchor: "middle", dy: 0 });
      F.forEach((a, j) => g.text([x0 + cs * (j + 0.5), y0 + 2 * cs + 0.35], a, { bold: true, size: 20, color: "ink" }));
      M.forEach((a, i) => g.text([x0 - 0.3, y0 + cs * (1.5 - i)], a, { bold: true, size: 20, color: "ink", dy: 7 }));
      M.forEach((a, i) => F.forEach((b, j) => { const bt = blood(a, b), p = [x0 + cs * j, y0 + cs * (1 - i)]; g.poly([p, add(p, [cs, 0]), add(p, [cs, cs]), add(p, [0, cs])], { fill: BCOL[bt], fo: 0.3, color: "ink", w: 1.4 }); g.text(add(p, [cs / 2, cs / 2 + 0.25]), [a, b].sort().join(""), { bold: true, size: 18 }); g.text(add(p, [cs / 2, cs / 2 - 0.55]), `${bt}형`, { size: 13, color: BCOL[bt], bold: true }); }));
      const pr = this.prob(s), X = 9.4, bw = 1.3;
      g.seg([X - 0.3, 1.6], [15.6, 1.6], { color: "axis", w: 1.2 });
      ["A", "B", "AB", "O"].forEach((t, i) => { const x = X + i * 1.6, h = pr[t] * 7.2; if (h > 0) g.poly([[x, 1.6], [x + bw, 1.6], [x + bw, 1.6 + h], [x, 1.6 + h]], { fill: BCOL[t], fo: 0.55, color: BCOL[t], w: 1.4 }); g.text([x + bw / 2, 1.6], `${t}형`, { dy: 16, bold: true, size: 12.5 }); g.text([x + bw / 2, 1.6 + h], frac(pr[t], 4), { dy: -6, bold: true, size: 13 }); if (s.kids) { const hk = (s.kids[t] / 100) * 7.2; g.seg([x - 0.08, 1.6 + hk], [x + bw + 0.08, 1.6 + hk], { color: "ink", w: 2.6 }); } });
      g.text([12.4, 10.4], s.kids ? "막대: 확률 · 검은 선: 100명의 비율" : "아이의 혈액형 확률", { size: 12.5, bold: true, color: "muted" });
    },
    metrics(s) { const p = this.prob(s); const r = [["P(A) · P(B) · P(AB) · P(O)", ["A", "B", "AB", "O"].map((t) => frac(p[t], 4)).join(" · "), "key"], ["모든 경우", "2 × 2 = 4가지"]]; if (s.kids) r.push(["100명 중 (A · B · AB · O)", ["A", "B", "AB", "O"].map((t) => s.kids[t]).join(" · ")]); return r; },
  },
  {
    id: "m3-belt", grade: 3, unit: 6, lesson: "6.2 창의UP", title: "두 바퀴를 잇는 벨트 — 접선과 호의 길이", type: "조작", time: "12분",
    tags: ["접선", "호의 길이", "공통접선"], color: "#178468", links: ["g3-circle-tangent", "g3-tangent-chord", "sector"],
    desc: "크기가 다른 두 바퀴를 벨트로 이을 때 벨트는 두 원의 공통접선과 바퀴에 닿는 호로 이루어집니다. 바퀴의 크기와 거리를 바꾸며 벨트가 바퀴에 닿는 각과 벨트 전체의 길이를 구합니다.",
    obs: ["원의 접선은 접점을 지나는 반지름과 수직입니다.", "바로 걸면(평행 벨트) 큰 바퀴에 더 넓게 감기고, 엇걸면(X자 벨트) 두 바퀴에 같은 각만큼 감깁니다.", "벨트의 길이 = 접선 부분 2개 + 두 호의 길이입니다."],
    q: "작은 바퀴 쪽 벨트가 이루는 각이 36°일 때, 큰 바퀴에서 벨트가 닿지 않는 호의 중심각은 몇 도일까요?",
    formula: "호의 길이 = 2πr × (중심각)/360° · 벨트 = 접선 2개 + 두 호",
    en: { title: "A Belt Around Two Wheels", desc: "Common tangents and contact arcs make up the belt; compute its length." },
    view: V,
    params: [{ key: "R", label: "큰 바퀴 반지름", min: 1, max: 3, step: 0.1, value: 2.4 }, { key: "r", label: "작은 바퀴 반지름", min: 0.4, max: 2, step: 0.1, value: 1.1 }, { key: "d", label: "두 중심 사이 거리", min: 3, max: 9, step: 0.1, value: 6.2 }, { key: "type", label: "벨트 거는 방법", type: "seg", value: "open", options: [["open", "바로 걸기"], ["cross", "엇걸기 (X자)"]] }],
    derive(s) { if (s.r > s.R) s.r = s.R; if (s.d < s.R + s.r + 0.3) s.d = +(s.R + s.r + 0.3).toFixed(1); },
    geo(s) {
      const C1 = [-s.d / 2 + (s.R - s.r) * 0.3, 0], C2 = add(C1, [s.d, 0]), u = [1, 0], v = [0, 1], cr = s.type === "cross";
      const sa = cr ? (s.R + s.r) / s.d : (s.R - s.r) / s.d, ca = Math.sqrt(1 - sa * sa);
      const nP = add(mul(u, sa), mul(v, ca)), nM = add(mul(u, sa), mul(v, -ca));
      const T1 = [add(C1, mul(nP, s.R)), add(C1, mul(nM, s.R))], T2 = cr ? [add(C2, mul(nP, -s.r)), add(C2, mul(nM, -s.r))] : [add(C2, mul(nP, s.r)), add(C2, mul(nM, s.r))];
      const A1 = wrapArc(C1, T1[0], T1[1], [-1, 0]), A2 = wrapArc(C2, T2[0], T2[1], [1, 0]);
      const tl = Math.sqrt(s.d * s.d - (cr ? (s.R + s.r) ** 2 : (s.R - s.r) ** 2));
      return { C1, C2, T1, T2, A1, A2, tl, th1: A1[1] - A1[0], th2: A2[1] - A2[0] };
    },
    draw(s, g) {
      const G = this.geo(s);
      g.grid({ labels: false, axes: false });
      g.circle(G.C1, s.R, { color: "muted", fill: "paper", fo: 1, w: 2 }).circle(G.C2, s.r, { color: "muted", fill: "paper", fo: 1, w: 2 });
      for (let k = 0; k < 6; k++) { const a = (k * Math.PI) / 3; g.seg(G.C1, add(G.C1, [s.R * 0.8 * Math.cos(a), s.R * 0.8 * Math.sin(a)]), { color: "grid", w: 2 }); g.seg(G.C2, add(G.C2, [s.r * 0.8 * Math.cos(a), s.r * 0.8 * Math.sin(a)]), { color: "grid", w: 1.6 }); }
      g.param((t) => add(G.C1, [s.R * Math.cos(t), s.R * Math.sin(t)]), G.A1[0], G.A1[1], { color: "a", w: 4.5 });
      g.param((t) => add(G.C2, [s.r * Math.cos(t), s.r * Math.sin(t)]), G.A2[0], G.A2[1], { color: "a", w: 4.5 });
      g.seg(G.T1[0], G.T2[0], { color: "a", w: 4.5 }).seg(G.T1[1], G.T2[1], { color: "a", w: 4.5 });
      [0, 1].forEach((i) => { g.seg(G.C1, G.T1[i], { color: "b", w: 1.4, dash: "5 4" }).seg(G.C2, G.T2[i], { color: "b", w: 1.4, dash: "5 4" }); g.right(G.T1[i], G.C1, G.T2[i], { size: 9 }); g.right(G.T2[i], G.C2, G.T1[i], { size: 9 }); });
      g.point(G.C1, "", { r: 4, color: "ink" }).point(G.C2, "", { r: 4, color: "ink" });
      g.text(G.C1, `${fmt(rad2deg(G.th1), 1)}°`, { dy: 5, bold: true, size: 14, color: "a" });
      g.text(G.C2, `${fmt(rad2deg(G.th2), 1)}°`, { dy: 5, bold: true, size: 13, color: "a" });
    },
    metrics(s) { const G = this.geo(s), L = 2 * G.tl + s.R * G.th1 + s.r * G.th2; return [["접선 부분 한 개", fmt(G.tl, 3)], ["감긴 중심각 (큰 · 작은)", `${fmt(rad2deg(G.th1), 1)}° · ${fmt(rad2deg(G.th2), 1)}°`], ["벨트 전체 길이", fmt(L, 3), "key"]]; },
  },
  {
    id: "c2-line-art", grade: 4, unit: 1, lesson: "I-2 공학 도구", title: "평행선과 수직선으로 그리는 추상화", type: "조작", time: "10분",
    tags: ["평행", "수직", "기울기"], links: ["c2-parallel-perp", "c2-line-eq", "cul-perspective"],
    desc: "몬드리안의 ‘빨강, 파랑, 노랑의 구성’처럼 서로 평행한 직선과 수직인 직선만으로 작품을 만듭니다. 기울기를 정하면 평행선은 같은 기울기, 수직선은 기울기의 곱이 −1인 직선이 되는 것을 확인합니다.",
    obs: ["평행한 두 직선은 기울기가 같고 y절편이 다릅니다.", "수직인 두 직선의 기울기의 곱은 −1입니다.", "기울기가 0인 직선에 수직인 직선은 x = k 꼴입니다."],
    q: "친구의 작품에서 직선 하나의 식이 y = 2x + 1이라면, 이와 수직인 직선들의 식은 어떤 꼴일까요?",
    formula: "평행: m₁ = m₂ · 수직: m₁m₂ = −1",
    en: { title: "Abstract Art with Parallel and Perpendicular Lines", desc: "Build a Mondrian-style composition from line families with slopes m and −1/m." },
    view: V,
    params: [{ key: "m", label: "첫째 무리의 기울기 m", type: "seg", value: 0, options: [[0, "0"], [0.5, "½"], [1, "1"], [2, "2"], [-1, "−1"]] }, { key: "k", label: "무리마다 직선 수", min: 2, max: 6, step: 1, value: 4 }, { key: "seed", label: "색칠 배치", min: 1, max: 12, step: 1, value: 3 }],
    fam(s) {
      const r = lcg(s.seed * 97 + s.k), b = [], c = [];
      let y = -4.2; for (let i = 0; i < s.k; i++) { y += 0.9 + r() * 1.6; b.push(+y.toFixed(1)); }
      let x = -6.4; for (let i = 0; i < s.k; i++) { x += 1.1 + r() * 1.9; c.push(+x.toFixed(1)); }
      return { b, c, r };
    },
    meet(s, b, c) { const m = s.m; if (m === 0) return [c, b]; const x = (c - b) / (m + 1 / m); return [x, m * x + b]; },
    draw(s, g) {
      const { b, c } = this.fam(s), m = s.m, pal = ["a", "b", "f", "paper", "paper", "paper", "paper"], r = lcg(s.seed * 31 + 7);
      const B = [-9, ...b, 9], Cc = [-12, ...c, 12];
      for (let i = 0; i < B.length - 1; i++) for (let j = 0; j < Cc.length - 1; j++) { const col = pal[Math.floor(r() * pal.length)]; if (col === "paper") continue; const q = [this.meet(s, B[i], Cc[j]), this.meet(s, B[i], Cc[j + 1]), this.meet(s, B[i + 1], Cc[j + 1]), this.meet(s, B[i + 1], Cc[j])]; g.poly(q, { fill: col, fo: 0.75, stroke: false }); }
      b.forEach((bb) => (m === 0 ? g.line([0, bb], [1, bb], { color: "ink", w: 5 }) : g.line([0, bb], [1, m + bb], { color: "ink", w: 5 })));
      c.forEach((cc) => (m === 0 ? g.line([cc, 0], [cc, 1], { color: "ink", w: 5 }) : g.line([cc, 0], [cc + 1, -1 / m], { color: "ink", w: 5 })));
      const eq1 = m === 0 ? `y = ${fmt(b[0])}` : `y = ${frac(m, 4)}x ${b[0] < 0 ? "−" : "+"} ${fmt(Math.abs(b[0]))}`;
      const eq2 = m === 0 ? `x = ${fmt(c[0])}` : `y = ${frac(-1 / m, 4)}(x ${c[0] < 0 ? "+" : "−"} ${fmt(Math.abs(c[0]))})`;
      g.note(16, 26, `예: ${eq1}   ⟂   ${eq2}`, { bold: true, color: "ink" });
    },
    metrics(s) { const m = s.m; return [["첫째 무리 기울기", frac(m, 4)], ["둘째 무리 기울기", m === 0 ? "없음 (x = k 꼴)" : frac(-1 / m, 4)], ["기울기의 곱", m === 0 ? "수직선: 기울기 0 과 x = k" : "−1", "key"], ["직선 수", `${2 * s.k}개`]]; },
  },
  {
    id: "geo-octa-relations", grade: 6, unit: 2, lesson: "II-1 공학 도구", title: "정팔면체 속 직선과 평면의 위치 관계", type: "3D", time: "12분",
    tags: ["직선과 평면", "두 평면", "정팔면체"], links: ["position-relations", "geo-plane-angle", "geo-three-perp"],
    desc: "정팔면체의 세 꼭짓점으로 평면을, 두 꼭짓점으로 직선을 정한 뒤 ‘포함된다 · 한 점에서 만난다 · 평행하다’ 중 어떤 관계인지 확인합니다. 두 평면의 관계도 비교할 수 있습니다.",
    obs: ["직선 위의 두 점이 모두 평면 위에 있으면 직선은 평면에 포함됩니다.", "정팔면체의 마주 보는 두 면은 서로 평행합니다.", "평행하지 않은 두 평면은 한 직선에서 만납니다."],
    q: "평면 ABC와 평행한 직선을 정팔면체의 모서리 중에서 모두 찾아보세요.",
    formula: "직선과 평면: 포함 · 한 점에서 만남 · 평행 / 두 평면: 만남(교선) · 평행",
    en: { title: "Lines and Planes in an Octahedron", desc: "Classify line–plane and plane–plane relations using octahedron vertices." },
    space: true, cam: { yaw: 28, pitch: 20, scale: 62 },
    params: [{ key: "mode", label: "비교할 것", type: "seg", value: "line", options: [["line", "평면과 직선"], ["plane", "두 평면"]] }, { key: "P", label: "평면 (세 꼭짓점)", type: "select", value: "ABC", options: ["ABC", "ABE", "FBC", "BCD", "ACE", "FDE"].map((x) => [x, `평면 ${x}`]) }, { key: "L", label: "직선 (두 꼭짓점)", type: "select", value: "DE", when: (s) => s.mode === "line", options: ["DE", "FD", "BC", "AF", "FE", "BD", "CE"].map((x) => [x, `직선 ${x}`]) }, { key: "Q", label: "둘째 평면", type: "select", value: "FDE", when: (s) => s.mode === "plane", options: ["FDE", "ACD", "BCD", "FBC", "ADE", "AEB"].map((x) => [x, `평면 ${x}`]) }],
    nrm(P) { const [a, b, c] = [...P].map((k) => OCT[k]); return [a, cross(sub(b, a), sub(c, a))]; },
    rel(s) {
      const [a, n] = this.nrm(s.P);
      if (s.mode === "line") { const [p, q] = [...s.L].map((k) => OCT[k]), d1 = dot(n, sub(p, a)), d2 = dot(n, sub(q, a)); if (Math.abs(d1) < 1e-9 && Math.abs(d2) < 1e-9) return ["포함된다", null]; if (Math.abs(d1 - d2) < 1e-9) return ["평행하다", null]; return ["한 점에서 만난다", lerp(p, q, d1 / (d1 - d2))]; }
      const [b, m] = this.nrm(s.Q), cr = cross(n, m);
      if (len(cr) < 1e-9) return [Math.abs(dot(n, sub(b, a))) < 1e-9 ? "일치한다" : "평행하다", null];
      return ["한 직선에서 만난다", cr];
    },
    planeDraw(g, P, col) { const [a, n] = this.nrm(P), pts = [...P].map((k) => OCT[k]), c = mul(add(add(pts[0], pts[1]), pts[2]), 1 / 3), u = norm(sub(pts[1], pts[0])), v = norm(cross(norm(n), u)); g.plane(c, u, v, 3.3, 3.3, { fill: col, color: col, fo: 0.13 }); g.face(pts, { fill: col, color: col, fo: 0.4, w: 2.4, bias: 0.2 }); },
    draw(s, g) {
      OCT_FACES.forEach((f) => g.face([...f].map((k) => OCT[k]), { fill: "muted", color: "muted", fo: 0.05, w: 0.6 }));
      OCT_EDGES.forEach((e) => g.seg(OCT[e[0]], OCT[e[1]], { color: "ink", w: 1.6 }));
      this.planeDraw(g, s.P, "b");
      const [rel, X] = this.rel(s);
      if (s.mode === "line") { const [p, q] = [...s.L].map((k) => OCT[k]), d = norm(sub(q, p)); g.seg(add(p, mul(d, -2.2)), add(q, mul(d, 2.2)), { color: "a", w: 3.6, bias: 0.4 }); if (X) g.point(X, "교점", { color: "d", r: 7, bias: 1 }); }
      else { this.planeDraw(g, s.Q, "c"); if (X) { const [a1, n1] = this.nrm(s.P), [a2, n2] = this.nrm(s.Q), dir = norm(X), h1 = dot(n1, a1), h2 = dot(n2, a2), A = [[n1[0], n1[1], n1[2]], [n2[0], n2[1], n2[2]], [dir[0], dir[1], dir[2]]], det = (M) => M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1]) - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0]) + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]), D = det(A), rhs = [h1, h2, 0], col = (i) => A.map((row, r) => row.map((v, c2) => (c2 === i ? rhs[r] : v))), P0 = [det(col(0)) / D, det(col(1)) / D, det(col(2)) / D]; g.seg(add(P0, mul(dir, -4)), add(P0, mul(dir, 4)), { color: "d", w: 3.6, bias: 1 }); } }
      Object.entries(OCT).forEach(([k, p]) => g.point(p, k, { r: 4, color: "ink" }));
      g.note(20, 30, rel, { color: "d", bold: true });
    },
    metrics(s) { const [rel] = this.rel(s); return [["비교", s.mode === "line" ? `평면 ${s.P} 와 직선 ${s.L}` : `평면 ${s.P} 와 평면 ${s.Q}`], ["위치 관계", rel, "key"]]; },
  },
  {
    id: "pst-bread-bags", grade: 8, unit: 1, lesson: "I-1 탐구 & 융합", title: "빵 나누어 담기 — 빈 가방이 없도록", type: "데이터", time: "12분",
    tags: ["중복순열", "여사건", "포함과 배제"], links: ["pst-rep-perm", "pst-perm-comb", "cm1-sum-product"],
    desc: "서로 다른 빵을 서로 다른 가방에 나누어 담는 모든 경우를 한 줄씩 그려 봅니다. 전체 경우는 중복순열로 kⁿ가지이고, 빈 가방이 생기는 경우를 빼면 빈 가방이 없는 경우의 수가 됩니다.",
    obs: ["빵마다 가방을 하나씩 고르므로 전체 경우의 수는 kⁿ입니다.", "가방이 2개이면 한쪽이 빈 경우 2가지를 빼서 2ⁿ − 2입니다.", "가방이 3개이면 빈 가방이 1개, 2개인 경우를 차례로 빼고 더해 줍니다."],
    q: "서로 다른 빵 5개를 서로 다른 가방 2개에 빈 가방 없이 담는 경우의 수는 얼마일까요?",
    formula: "전체 kⁿ · 가방 2개: 2ⁿ − 2 · 가방 3개: 3ⁿ − 3 × 2ⁿ + 3",
    en: { title: "Packing Bread into Bags", desc: "Enumerate all kⁿ assignments and remove those with an empty bag." },
    view: BOX,
    params: [{ key: "n", label: "서로 다른 빵 수 n", min: 2, max: 6, step: 1, value: 5 }, { key: "k", label: "서로 다른 가방 수 k", type: "seg", value: 2, options: [[2, "2개"], [3, "3개"]] }, { key: "empty", label: "빈 가방 허용", type: "check", value: false }],
    count(s) { let v = 0; for (let i = 0; i <= s.k; i++) v += (-1) ** i * C(s.k, i) * (s.k - i) ** s.n; return v; },
    draw(s, g) {
      const tot = s.k ** s.n, cols = Math.ceil(Math.sqrt((tot * s.n * 1.9) / 1.45) / s.n) || 1, rows = Math.ceil(tot / cols);
      const cw = Math.min(15 / (cols * (s.n + 1)), 9.2 / rows, 0.6), bag = ["a", "b", "c"];
      for (let t = 0; t < tot; t++) {
        const dig = []; let x = t; for (let i = 0; i < s.n; i++) { dig.push(x % s.k); x = Math.floor(x / s.k); }
        const ok = new Set(dig).size === s.k, cx = t % cols, cy = Math.floor(t / cols), X0 = 0.5 + cx * (s.n + 1) * cw, Y0 = 10.2 - (cy + 1) * cw * 1.25;
        dig.forEach((d, i) => g.poly([[X0 + i * cw, Y0], [X0 + (i + 0.9) * cw, Y0], [X0 + (i + 0.9) * cw, Y0 + cw * 0.9], [X0 + i * cw, Y0 + cw * 0.9]], { fill: bag[d], fo: ok || s.empty ? 0.8 : 0.12, stroke: false }));
        if (!ok && !s.empty) g.seg([X0, Y0 + cw * 0.45], [X0 + s.n * cw * 0.95, Y0 + cw * 0.45], { color: "d", w: 1 });
      }
      g.note(16, 430, `한 줄 = 빵 ${s.n}개를 담은 한 가지 방법 · 색 = 가방 (${["주황", "파랑", "초록"].slice(0, s.k).join(", ")})`, { color: "muted" });
    },
    metrics(s) { const tot = s.k ** s.n, ok = this.count(s); return [["전체 경우 kⁿ", `${s.k}^${s.n} = ${tot}`], ["빈 가방이 생기는 경우", String(tot - ok)], [s.empty ? "빈 가방 허용" : "빈 가방 없음", String(s.empty ? tot : ok), "key"], ["10종류 중 서로 다른 빵 n개 고르기", `C(10, ${s.n}) = ${C(10, s.n)}`]]; },
  },
  {
    id: "pst-smart-farm", grade: 8, unit: 1, lesson: "I-3 탐구 & 융합", title: "스마트 팜 선반에 종자 심기 — 조건이 있는 배열", type: "조작", time: "12분",
    tags: ["같은 것이 있는 순열", "조건", "대칭"], links: ["pst-grid-path", "pst-rep-comb", "pst-bread-bags"],
    desc: "7층 선반에 청치마 3개, 적치마 2개, 로메인 1개, 아이스버그 1개 종자를 심습니다. 조건을 하나씩 켜며 가능한 배열이 몇 가지로 줄어드는지 세고, 가능한 배열을 하나씩 넘겨 봅니다.",
    obs: ["같은 종자끼리는 바꾸어도 같은 배열이므로 7!/(3!2!)가지입니다.", "맨 아래를 청치마로 정하면 나머지 6칸에 청치마 2개를 포함해 배열합니다.", "아이스버그와 로메인의 위아래는 반반씩이므로 조건 ㈏는 경우의 수를 절반으로 만듭니다."],
    q: "두 조건을 모두 만족하는 배열의 수를 식으로 나타내 보세요.",
    formula: "7!/(3!2!) = 420 · 6!/(2!2!) = 180 · 180 ÷ 2 = 90",
    en: { title: "Planting Seeds on a Smart-Farm Rack", desc: "Count arrangements with repeated items under extra conditions." },
    view: BOX,
    params: [{ key: "c1", label: "㈎ 맨 아래 선반은 청치마", type: "check", value: true }, { key: "c2", label: "㈏ 아이스버그가 로메인보다 아래", type: "check", value: true }, { key: "i", label: "배열 번호", min: 1, max: (s) => Math.max(1, this_farm(s).length), step: 1, value: 1 }],
    anim: { key: "i", speed: 6, loop: "wrap", label: "배열 넘겨 보기" },
    list(s) { return this_farm(s); },
    derive(s) { const n = this_farm(s).length; if (s.i > n) s.i = n; },
    draw(s, g) {
      const L = this.list(s), a = L[Math.max(0, s.i - 1)] || "", x0 = 2.4, w = 5.8;
      for (let k = 0; k < 7; k++) { const y = 0.8 + k * 1.35; g.poly([[x0, y], [x0 + w, y], [x0 + w, y + 0.16], [x0, y + 0.16]], { fill: "muted", fo: 0.8, stroke: false }); g.text([x0 - 0.3, y + 0.55], `${k + 1}층`, { anchor: "end", size: 12, color: "muted" }); const sd = SEEDS[a[k]]; if (sd) { for (let j = 0; j < 3; j++) g.circle([x0 + 1.2 + j * 1.7, y + 0.62], 0.42, { color: sd[1], fill: sd[1], fo: 0.55, w: 1.6 }); g.text([x0 + w + 0.3, y + 0.55], sd[0], { anchor: "start", size: 13.5, bold: true, color: sd[1] }); } }
      g.seg([x0, 0.8], [x0, 10.4], { color: "muted", w: 3 }).seg([x0 + w, 0.8], [x0 + w, 10.4], { color: "muted", w: 3 });
      const X = 11.6, rows = [["조건 없음", 420], ["㈎만", 180], ["㈏만", 210], ["㈎ 그리고 ㈏", 90]], cur = s.c1 && s.c2 ? 3 : s.c1 ? 1 : s.c2 ? 2 : 0;
      rows.forEach(([t, v], i) => { const y = 9 - i * 1.5, on = i === cur; g.poly([[X, y - 0.5], [X + (v / 420) * 3.6, y - 0.5], [X + (v / 420) * 3.6, y + 0.1], [X, y + 0.1]], { fill: on ? "d" : "muted", fo: on ? 0.6 : 0.2, stroke: false }); g.text([X, y + 0.45], `${t}: ${v}가지`, { anchor: "start", size: 13, bold: on, color: on ? "d" : "muted" }); });
    },
    metrics(s) { const n = this_farm(s).length; return [["가능한 배열", `${n}가지`, "key"], ["지금 보는 배열", `${s.i}번째`], ["세는 방법", s.c1 && s.c2 ? "6!/(2!2!) ÷ 2 = 90" : s.c1 ? "6!/(2!2!) = 180" : s.c2 ? "7!/(3!2!) ÷ 2 = 210" : "7!/(3!2!) = 420"]]; },
  },
  {
    id: "alg-hanoi", grade: 5, unit: 7, lesson: "Ⅶ 탐구 & 융합", title: "하노이 탑 — 원판을 옮기는 최소 횟수", type: "조작", time: "12분",
    tags: ["귀납적 정의", "점화식", "2ⁿ − 1"], links: ["lab-figurate", "calc2-geo-series"],
    desc: "큰 원판을 작은 원판 위에 올리지 않고 한 번에 하나씩 옮겨 탑 전체를 다른 기둥으로 옮깁니다. 원판이 n개일 때 최소 이동 횟수 aₙ이 aₙ₊₁ = 2aₙ + 1을 만족하고 aₙ = 2ⁿ − 1임을 확인합니다.",
    obs: ["n + 1개를 옮기려면 위의 n개를 옮기고, 가장 큰 원판을 옮긴 뒤, n개를 다시 옮깁니다.", "그래서 aₙ₊₁ = 2aₙ + 1이 성립합니다.", "가장 작은 원판은 두 번에 한 번씩 움직입니다."],
    q: "원판이 64개라면 1초에 한 번씩 옮겨도 몇 년이 걸릴까요?",
    formula: "a₁ = 1 · aₙ₊₁ = 2aₙ + 1 · aₙ = 2ⁿ − 1",
    en: { title: "The Tower of Hanoi", desc: "Minimum moves satisfy aₙ₊₁ = 2aₙ + 1, so aₙ = 2ⁿ − 1." },
    view: BOX,
    params: [{ key: "n", label: "원판 수 n", min: 1, max: 7, step: 1, value: 4 }, { key: "k", label: "이동 횟수", min: 0, max: (s) => 2 ** s.n - 1, step: 1, value: 0 }],
    anim: { key: "k", speed: 2.4, label: "차례로 옮기기" },
    onChange(s, key) { if (key === "n") s.k = 0; },
    state(s) { const pegs = [[...Array(s.n).keys()].map((i) => s.n - i), [], []], M = hanoiMoves(s.n); for (let i = 0; i < Math.min(s.k, M.length); i++) { const [, a, c] = M[i]; pegs[c].push(pegs[a].pop()); } return { pegs, last: s.k ? M[s.k - 1] : null }; },
    draw(s, g) {
      const { pegs, last } = this.state(s), X = [3, 8, 13], cols = ["a", "b", "c", "e", "f", "d", "a"];
      g.poly([[0.6, 2], [15.4, 2], [15.4, 2.4], [0.6, 2.4]], { fill: "muted", fo: 0.6, stroke: false });
      X.forEach((x, i) => { g.poly([[x - 0.1, 2.4], [x + 0.1, 2.4], [x + 0.1, 8.2], [x - 0.1, 8.2]], { fill: "muted", fo: 0.8, stroke: false }); g.text([x, 2], "ABC"[i], { dy: 22, bold: true, size: 15 }); });
      pegs.forEach((p, i) => p.forEach((d, j) => { const w = 0.45 + d * (1.85 / s.n), y = 2.4 + j * 0.72, moved = last && last[0] === d && i === last[2]; g.poly([[X[i] - w, y], [X[i] + w, y], [X[i] + w, y + 0.62], [X[i] - w, y + 0.62]], { fill: cols[d - 1], fo: 0.75, color: moved ? "ink" : cols[d - 1], w: moved ? 2.6 : 1.4 }); }));
      g.text([8, 10.1], `이동 ${s.k} / 최소 ${2 ** s.n - 1}회`, { bold: true, size: 16, color: s.k === 2 ** s.n - 1 ? "c" : "ink" });
      if (last) g.text([8, 9.3], `방금: ${last[0]}번 원판 ${"ABC"[last[1]]} → ${"ABC"[last[2]]}`, { size: 13, color: "muted" });
    },
    metrics(s) { const seq = [...Array(7).keys()].map((i) => 2 ** (i + 1) - 1); return [["aₙ (n = 1, 2, …, 7)", seq.join(", ")], [`a${String(s.n).replace(/\d/g, (c) => "₀₁₂₃₄₅₆₇₈₉"[c])}`, `2^${s.n} − 1 = ${2 ** s.n - 1}`, "key"], ["지금까지 이동", `${s.k}회`]]; },
  },
  {
    id: "alg-tablet", grade: 5, unit: 2, lesson: "Ⅱ 탐구 & 융합", title: "3년 사용한 태블릿 PC의 가치 — 지수함수로 감소", type: "조작", time: "10분",
    tags: ["지수함수", "감가상각", "로그"], links: ["cul-population", "alg-transform"],
    desc: "새 제품의 가치가 해마다 일정한 비율로 줄어들면 t년 후의 가치는 P(1 − r)ᵗ인 지수함수가 됩니다. 처음 가격과 감소율을 바꾸며 가치의 변화를 보고, 가치가 절반이 되는 때를 로그로 구합니다.",
    obs: ["해마다 r만큼 줄면 1년 뒤 가치는 (1 − r)배가 됩니다.", "그래프는 점점 완만하게 줄어들지만 0이 되지는 않습니다.", "절반이 되는 시간은 처음 가격과 관계없이 감소율만으로 정해집니다."],
    q: "해마다 가치가 20 %씩 줄어든다면 3년 뒤의 가치는 처음의 몇 %일까요?",
    formula: "P(t) = P₀(1 − r)ᵗ · 절반이 되는 때 t = log(1/2) / log(1 − r)",
    en: { title: "Depreciation of a Tablet", desc: "Value falls exponentially: P(t) = P₀(1 − r)ᵗ; find the half-value time with logs." },
    view: BOX,
    params: [{ key: "P", label: "처음 가격 P₀ (만 원)", min: 40, max: 150, step: 10, value: 100 }, { key: "r", label: "해마다 줄어드는 비율 r (%)", min: 5, max: 40, step: 1, value: 20 }, { key: "t", label: "사용한 햇수 t", min: 0, max: 10, step: 0.1, value: 3 }],
    anim: { key: "t", min: 0, max: 10, speed: 1.5, label: "시간 흐르기" },
    draw(s, g) {
      const q = 1 - s.r / 100, M = (t, v) => [1.4 + (t / 10) * 14, 1.2 + (v / 150) * 8.8];
      g.seg(M(0, 0), M(10, 0), { color: "axis", w: 1.2 }).seg(M(0, 0), M(0, 150), { color: "axis", w: 1.2 });
      for (let t = 0; t <= 10; t++) g.text(M(t, 0), `${t}년`, { dy: 15, size: 11, color: "muted" });
      [0, 50, 100, 150].forEach((v) => { g.seg(M(0, v), M(10, v), { color: "grid", w: 1 }); g.text(M(0, v), `${v}`, { dx: -5, dy: 4, anchor: "end", size: 11, color: "muted" }); });
      g.seg(M(0, s.P / 2), M(10, s.P / 2), { color: "e", w: 1.4, dash: "6 4" }).text(M(10, s.P / 2), "처음의 절반", { dy: -6, anchor: "end", size: 12, color: "e", bold: true });
      for (let t = 0; t <= 10; t++) { const v = s.P * q ** t; g.poly([add(M(t, 0), [-0.22, 0]), add(M(t, 0), [0.22, 0]), add(M(t, v), [0.22, 0]), add(M(t, v), [-0.22, 0])], { fill: "b", fo: 0.25, stroke: false }); }
      g.param((t) => M(t, s.P * q ** t), 0, 10, { color: "a", w: 2.8 });
      const v = s.P * q ** s.t, th = Math.log(0.5) / Math.log(q);
      if (th <= 10) g.seg(M(th, 0), M(th, s.P / 2), { color: "e", w: 1.4, dash: "3 4" }).point(M(th, s.P / 2), "", { color: "e", r: 4 });
      g.seg(M(s.t, 0), M(s.t, v), { color: "d", w: 1.6, dash: "4 4" }).point(M(s.t, v), `${fmt(v, 1)}만 원`, { color: "d", r: 6 });
    },
    metrics(s) { const q = 1 - s.r / 100, v = s.P * q ** s.t; return [["P(t)", `${s.P} × ${fmt(q, 2)}^t`], [`${fmt(s.t, 1)}년 뒤 가치`, `${fmt(v, 1)}만 원 (${fmt(q ** s.t * 100, 1)}%)`, "key"], ["절반이 되는 때", `${fmt(Math.log(0.5) / Math.log(q), 2)}년`]]; },
  },
  {
    id: "c2-ladder", grade: 4, unit: 5, lesson: "Ⅴ 탐구 & 융합", title: "사다리 타기와 일대일대응", type: "조작", time: "10분",
    tags: ["함수", "일대일대응", "역함수"], links: ["cm2-venn", "pst-perm-comb"],
    desc: "사다리 타기에서 출발점과 도착점을 짝 지으면 함수가 됩니다. 가로선을 아무리 많이 그어도 서로 다른 출발점은 서로 다른 도착점에 닿는 일대일대응이 되고, 아래에서 거꾸로 올라가면 역함수가 됩니다.",
    obs: ["가로선을 만나면 옆 세로선으로 옮겨 가므로 두 경로가 같은 곳에서 만나지 않습니다.", "그래서 출발점 n개와 도착점 n개가 하나씩 짝 지어집니다.", "가로선 하나는 이웃한 두 도착점을 서로 바꾸는 역할을 합니다."],
    q: "원하는 짝(예: 1 → 다)이 되도록 하려면 가로선을 어디에 추가해야 할까요?",
    formula: "f : X → Y 일대일대응 ⇒ 역함수 f⁻¹ : Y → X 존재",
    en: { title: "Ladder Game and Bijections", desc: "Any ladder pairs starts and ends one-to-one; climbing back up gives the inverse." },
    view: BOX,
    params: [{ key: "n", label: "세로선 수", min: 3, max: 6, step: 1, value: 4 }, { key: "sel", label: "따라갈 출발점", min: 1, max: (s) => s.n, step: 1, value: 1 }, { key: "rev", label: "아래에서 거꾸로 (역함수)", type: "check", value: false }],
    init: () => ({ rungs: null, seed: 11 }),
    buttons: [["new", "새 사다리"], ["add", "가로선 하나 더"]],
    onDo(k, s) { if (k === "new") { s.seed = Math.floor(Math.random() * 1e6); s.rungs = null; } if (k === "add") { const R = this.rungs(s), r = Math.random; for (let tries = 0; tries < 40; tries++) { const i = Math.floor(r() * (s.n - 1)), y = 1 + Math.floor(r() * 14); if (!R.some(([j, yy]) => yy === y && Math.abs(j - i) <= 1)) { R.push([i, y]); break; } } s.rungs = R; } },
    onChange(s, key) { if (key === "n") s.rungs = null; if (s.sel > s.n) s.sel = s.n; },
    rungs(s) { if (s.rungs) return s.rungs; const r = lcg(s.seed + s.n * 13), R = []; for (let y = 1; y <= 14; y++) { if (r() < 0.45) continue; const i = Math.floor(r() * (s.n - 1)); if (!R.some(([j, yy]) => yy === y && Math.abs(j - i) <= 1)) R.push([i, y]); } s.rungs = R; return R; },
    trace(s, start, rev) { const R = this.rungs(s), pts = []; let col = start; const ys = [...Array(16).keys()]; const order = rev ? ys.slice().reverse() : ys; for (const y of order) { pts.push([col, y]); const h = R.find(([i, yy]) => yy === y && (i === col || i === col - 1)); if (h) { col = h[0] === col ? col + 1 : col - 1; pts.push([col, y]); } } return { pts, end: col }; },
    draw(s, g) {
      const R = this.rungs(s), X = (i) => 2 + (i * 12) / (s.n - 1), Y = (y) => 9.4 - (y / 15) * 7.6, ends = "가나다라마바";
      for (let i = 0; i < s.n; i++) { g.seg([X(i), Y(0)], [X(i), Y(15)], { color: "ink", w: 2.4 }); g.text([X(i), Y(0)], String(i + 1), { dy: -12, bold: true, size: 17 }); g.text([X(i), Y(15)], ends[i], { dy: 24, bold: true, size: 17 }); }
      R.forEach(([i, y]) => g.seg([X(i), Y(y)], [X(i + 1), Y(y)], { color: "ink", w: 2.4 }));
      const map = [...Array(s.n).keys()].map((i) => this.trace(s, i, false).end);
      const start = s.rev ? map[s.sel - 1] : s.sel - 1, T = this.trace(s, start, s.rev);
      g.path(T.pts.map(([c, y]) => [X(c), Y(y)]), { color: s.rev ? "c" : "a", w: 5 });
      g.point([X(start), Y(s.rev ? 15 : 0)], "", { color: s.rev ? "c" : "a", r: 7 });
    },
    metrics(s) { const map = [...Array(s.n).keys()].map((i) => this.trace(s, i, false).end), ends = "가나다라마바"; return [["대응", map.map((e, i) => `${i + 1}→${ends[e]}`).join("  ")], ["일대일대응?", new Set(map).size === s.n ? "예 — 도착점이 모두 다름" : "아니요", "key"], ["가로선 수", `${this.rungs(s).length}개`]]; },
  },
];

function this_farm(s) { return FARM.filter((a) => (!s.c1 || a[0] === "청") && (!s.c2 || a.indexOf("아") < a.indexOf("로"))); }
