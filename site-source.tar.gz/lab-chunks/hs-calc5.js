import { criticalRoots } from "./critical-roots.js";
// 23차 묶음 14 — 미적분Ⅰ 추가 실험 16개
import { fmt, frac, poly, clamp } from "./hs-core.js";

const C1 = 7;
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const simpson = (f, a, b, n = 400) => { if (a === b) return 0; const h = (b - a) / n; let s = f(a) + f(b); for (let i = 1; i < n; i++) s += f(a + i * h) * (i % 2 ? 4 : 2); return (s * h) / 3; };
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
function shade(g, f, a, b, n = 160) { for (let i = 0; i < n; i++) { const x0 = a + ((b - a) * i) / n, x1 = a + ((b - a) * (i + 1)) / n, y = f((x0 + x1) / 2); g.poly([[x0, 0], [x1, 0], [x1, y], [x0, y]], { fill: y >= 0 ? "b" : "e", fo: 0.3, stroke: false }); } }
const RAT = {
  a: { n: "y = (2x + 1)/(x − 1)", f: (x) => (2 * x + 1) / (x - 1), L: 2, V: 1 },
  b: { n: "y = 3x²/(x² + 1)", f: (x) => (3 * x * x) / (x * x + 1), L: 3, V: null },
  c: { n: "y = (x + 2)/(x² + 1)", f: (x) => (x + 2) / (x * x + 1), L: 0, V: null },
};
const EVT = {
  cont: { n: "y = −x² + 2x + 2 (연속)", f: (x) => -x * x + 2 * x + 2, jump: null },
  jump: { n: "x = 1에서 끊긴 함수", f: (x) => (x < 1 ? x + 1 : x - 1.5), jump: 1 },
};
const SK = {
  cub: { n: "y = x³/3 − x", f: (x) => x ** 3 / 3 - x, d: (x) => x * x - 1 },
  quad: { n: "y = −x²/2 + x + 1", f: (x) => (-x * x) / 2 + x + 1, d: (x) => -x + 1 },
  wave: { n: "y = x⁴/8 − x²", f: (x) => x ** 4 / 8 - x * x, d: (x) => x ** 3 / 2 - 2 * x },
};
const EO = {
  even: { n: "y = x² − 1 (우함수)", f: (x) => x * x - 1, k: "even" },
  odd: { n: "y = x³ − 2x (기함수)", f: (x) => x ** 3 - 2 * x, k: "odd" },
  none: { n: "y = x² + x (어느 쪽도 아님)", f: (x) => x * x + x, k: "none" },
};

export default [
  {
    id: "calc1-hole", grade: C1, unit: 1, lesson: "Ⅰ-1", title: "0/0 꼴의 극한 — 구멍 난 직선에 다가가기", type: "조작", time: "10분",
    tags: ["함수의 극한", "0/0 꼴", "약분"], links: ["calc1-limit", "calc1-discontinuity"],
    desc: "f(x) = (x² − a²)/(x − a)는 x = a에서 분모가 0이라 정의되지 않지만, x ≠ a에서는 약분하여 x + a와 같습니다. 그래프는 한 점에 구멍이 난 직선이고, x를 a에 가까이 가져갈수록 함숫값이 2a에 다가가는 것을 표로 확인합니다.",
    obs: ["x = a를 대입하면 0/0이 되어 값을 바로 알 수 없습니다.", "x ≠ a이면 (x − a)(x + a)/(x − a) = x + a입니다.", "그래서 x → a일 때 극한값은 2a입니다(함숫값은 없어도 극한값은 있음)."],
    q: "lim(x→2) (x³ − 8)/(x − 2)를 같은 방법으로 구해 봅시다.",
    formula: "lim(x→a) (x² − a²)/(x − a) = lim(x→a) (x + a) = 2a",
    en: { title: "Limits of the Form 0/0", desc: "A line with a hole." },
    view: { x: [-4, 5], y: [-2, 7] },
    params: [{ key: "a", label: "a", min: -2, max: 3, step: 0.5, value: 2 }, { key: "h", label: "a까지의 거리 h", min: 0.001, max: 1, step: 0.001, value: 0.5 }],
    anim: { key: "h", min: 0.001, max: 1, speed: 0.35, loop: "bounce", label: "a에 다가가기" },
    draw(s, g) { const f = (x) => x + s.a; g.grid(); g.fx(f, { color: "b", w: 3 }); g.point([s.a, 2 * s.a], "", { color: "b", hollow: true, r: 6 }); [[s.a - s.h, "a"], [s.a + s.h, "c"]].forEach(([x, c]) => { g.point([x, f(x)], "", { color: c }); g.seg([x, 0], [x, f(x)], { color: c, w: 1.2, dash: "3 4" }); }); g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], `y = (x² − ${fmt(s.a * s.a)})/(x − ${fmt(s.a)})`.replace("− −", "+ "), { anchor: "start", bold: true, color: "b" }); },
    metrics(s) { const F = (x) => (x * x - s.a * s.a) / (x - s.a); return [[`f(a − h)`, fmt(F(s.a - s.h), 5)], [`f(a + h)`, fmt(F(s.a + s.h), 5)], ["f(a)", "정의되지 않음"], ["극한값", fmt(2 * s.a), "key"]]; },
    predict: [
      { q: "lim(x→2) (x² − 4)/(x − 2)의 값은?", set: (s) => Object.assign(s, { a: 2, h: 0.8 }), reveal: (s) => (s.h = 0.001), answer: () => 4, why: "약분하면 x + 2이므로 2 + 2 = 4입니다." },
      { q: "lim(x→2) (x³ − 8)/(x − 2)의 값은?", answer: () => 12, why: "(x − 2)(x² + 2x + 4)/(x − 2) = x² + 2x + 4 → 4 + 4 + 4 = 12입니다." },
    ],
  },
  {
    id: "calc1-inf-limit", grade: C1, unit: 1, lesson: "Ⅰ-2", title: "x → ∞일 때의 극한 — 그래프가 다가가는 가로선", type: "조작", time: "10분",
    tags: ["극한", "무한대", "점근선"], links: ["calc1-hole", "cm2-rational"],
    desc: "x가 한없이 커질 때 분수식의 값이 어디로 가는지 그래프와 값으로 살펴봅니다. 분자와 분모의 최고차항의 차수가 같으면 최고차항의 계수의 비, 분모의 차수가 더 크면 0으로 수렴함을 x를 10배씩 키우며 확인합니다.",
    obs: ["x가 커지면 최고차항이 나머지 항보다 훨씬 커집니다.", "차수가 같으면 극한값은 최고차항 계수의 비입니다.", "분모의 차수가 더 크면 0으로 수렴합니다."],
    q: "lim(x→∞) (√(x² + x) − x)는 얼마일까요? 그래프로 짐작해 봅시다.",
    formula: "lim(x→∞) (2x + 1)/(x − 1) = 2",
    en: { title: "Limits at Infinity", desc: "Horizontal asymptotes." },
    view: { x: [-8, 10], y: [-4, 6] },
    params: [{ key: "f", label: "함수", type: "select", value: "a", options: Object.entries(RAT).map(([k, v]) => [k, v.n]) }, { key: "e", label: "x의 크기 (10의 거듭제곱)", min: 0, max: 6, step: 0.1, value: 1, show: (v) => `x = ${fmt(10 ** v, 0)}` }],
    draw(s, g) { const K = RAT[s.f]; g.grid(); if (K.V != null) { g.fx(K.f, { color: "b", w: 3, to: K.V - 0.01 }); g.fx(K.f, { color: "b", w: 3, from: K.V + 0.01 }); g.seg([K.V, g.yr[0]], [K.V, g.yr[1]], { color: "muted", w: 1.2, dash: "4 4" }); } else g.fx(K.f, { color: "b", w: 3 }); g.seg([g.xr[0], K.L], [g.xr[1], K.L], { color: "e", w: 1.8, dash: "7 5" }).text([g.xr[1] - 0.2, K.L], `y = ${K.L}`, { anchor: "end", dy: -6, bold: true, color: "e" }); const x = 10 ** s.e, y = K.f(x); if (!Number.isFinite(y)) g.note(18, 36, "이 x에서는 함수가 정의되지 않습니다.", { color: "a" }); else if (x <= g.xr[1] && y >= g.yr[0] && y <= g.yr[1]) g.point([x, y], "", { color: "a" }); else g.note(18, 36, "선택한 점은 화면 밖입니다. 아래 수치를 확인하세요.", { color: "a" }); g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], K.n, { anchor: "start", bold: true, color: "b" }); },
    metrics(s) { const K = RAT[s.f], x = 10 ** s.e; return [[`f(${fmt(x, 0)})`, Number.isFinite(K.f(x)) ? fmt(K.f(x), 7) : "정의되지 않음"], ["극한값", String(K.L), "key"], ["극한값과의 차", fmt(Math.abs(K.f(x) - K.L), 7)]]; },
    predict: [
      { q: "lim(x→∞) (2x + 1)/(x − 1)의 값은?", set: (s) => Object.assign(s, { f: "a", e: 0.5 }), reveal: (s) => (s.e = 6), answer: () => 2, why: "분자·분모를 x로 나누면 (2 + 1/x)/(1 − 1/x) → 2입니다." },
      { q: "lim(x→∞) (x + 2)/(x² + 1)의 값은?", set: (s) => Object.assign(s, { f: "c", e: 0.3 }), reveal: (s) => (s.e = 6), answer: () => 0, why: "분모의 차수가 더 커서 0으로 수렴합니다." },
    ],
  },
  {
    id: "calc1-evt", grade: C1, unit: 1, lesson: "Ⅰ-3", title: "최대·최소 정리 — 닫힌 구간과 연속이 함께 있어야", type: "조작", time: "10분",
    tags: ["최대·최소 정리", "연속", "닫힌구간"], links: ["calc1-continuity", "calc1-closed-maxmin"],
    desc: "닫힌구간 [a, b]에서 연속인 함수는 반드시 최댓값과 최솟값을 가집니다. 구간을 열린구간으로 바꾸거나 끊긴 함수를 고르면 '가장 높은 점'이 구간 끝에서 빠져나가 최댓값이 없을 수 있음을 확인합니다.",
    obs: ["닫힌구간에서 연속이면 그래프가 끊기지 않고 양 끝까지 포함됩니다.", "열린구간에서는 끝점이 빠져서 최댓값이 없을 수 있습니다.", "끊긴 함수는 닫힌구간에서도 최댓값이 없을 수 있습니다."],
    q: "열린구간 (0, 1)에서 f(x) = x는 최댓값을 가질까요?",
    formula: "f가 [a, b]에서 연속 ⇒ 최댓값과 최솟값이 존재",
    en: { title: "The Extreme Value Theorem", desc: "Closed interval + continuity." },
    view: { x: [-1.6, 3.6], y: [-1.6, 3.8] },
    params: [{ key: "f", label: "함수", type: "select", value: "cont", options: Object.entries(EVT).map(([k, v]) => [k, v.n]) }, { key: "a", label: "a", min: -1, max: 1, step: 0.1, value: -0.5 }, { key: "b", label: "b", min: 1.2, max: 3, step: 0.1, value: 2.6 }, { key: "open", label: "열린구간 (a, b)로", type: "check", value: false }],
    ext(s) { const K = EVT[s.f], N = 2000; let mx = -1e9, mn = 1e9, xm, xn; for (let i = 0; i <= N; i++) { const x = s.a + ((s.b - s.a) * i) / N; if (s.open && (i === 0 || i === N)) continue; const y = K.f(x); if (y > mx) { mx = y; xm = x; } if (y < mn) { mn = y; xn = x; } } return { mx, mn, xm, xn }; },
    draw(s, g) {
      const K = EVT[s.f];
      g.grid();
      if (K.jump != null) { g.fx(K.f, { color: "b", w: 3, from: s.a, to: K.jump - 0.001 }); g.fx(K.f, { color: "b", w: 3, from: K.jump, to: s.b }); g.point([K.jump, K.jump + 1], "", { color: "b", hollow: true }); g.point([K.jump, K.f(K.jump)], "", { color: "b", r: 4 }); }
      else g.fx(K.f, { color: "b", w: 3, from: s.a, to: s.b });
      [s.a, s.b].forEach((x) => g.point([x, K.f(x)], "", { color: "b", hollow: s.open, r: 5 }));
      const E = this.ext(s), noMax = (K.jump != null && E.xm > K.jump - 0.01 && E.xm < K.jump) || (s.open && (Math.abs(E.xm - s.a) < 0.01 || Math.abs(E.xm - s.b) < 0.01));
      if (!noMax) g.point([E.xm, E.mx], "최대", { color: "a" });
      const noMin = s.open && (Math.abs(E.xn - s.a) < 0.01 || Math.abs(E.xn - s.b) < 0.01);
      if (!noMin) g.point([E.xn, E.mn], "최소", { color: "c", dy: 20 });
    },
    metrics(s) { const K = EVT[s.f], E = this.ext(s), noMax = (K.jump != null && E.xm > K.jump - 0.01 && E.xm < K.jump) || (s.open && (Math.abs(E.xm - s.a) < 0.01 || Math.abs(E.xm - s.b) < 0.01)), noMin = s.open && (Math.abs(E.xn - s.a) < 0.01 || Math.abs(E.xn - s.b) < 0.01); return [["구간", s.open ? `(${fmt(s.a)}, ${fmt(s.b)})` : `[${fmt(s.a)}, ${fmt(s.b)}]`], ["최댓값", noMax ? "없음 (다가가기만 함)" : fmt(E.mx, 3), "key"], ["최솟값", noMin ? "없음" : fmt(E.mn, 3)]]; },
    predict: [
      { q: "끊긴 함수(x < 1에서 x + 1)는 [−0.5, 2.6]에서 최댓값을 가질까요?", options: O("가지지 않는다", "가진다"), set: (s) => Object.assign(s, { f: "cont", a: -0.5, b: 2.6, open: false }), reveal: (s) => (s.f = "jump"), answer: () => "a", why: "x가 1에 왼쪽에서 다가가면 값이 2에 다가가지만 x = 1에서는 −0.5라 2에 닿지 못합니다." },
      { q: "y = −x² + 2x + 2의 [−0.5, 2.6]에서의 최댓값은?", set: (s) => Object.assign(s, { f: "cont", a: -0.5, b: 2.6, open: false }), answer: () => 3, why: "꼭짓점 x = 1에서 3이고, 닫힌구간 안에 있습니다." },
    ],
  },
  {
    id: "calc1-tangent-normal", grade: C1, unit: 2, lesson: "Ⅱ-3", title: "접선과 법선 — 기울기의 곱은 −1", type: "조작", time: "10분",
    tags: ["접선의 방정식", "법선", "수직"], links: ["calc-secant-tangent", "calc1-tangent-from-point"],
    desc: "곡선 y = f(x) 위의 점 P에서 접선의 기울기는 f′(a)이고, P에서 접선과 수직인 직선(법선)의 기울기는 −1/f′(a)입니다. 점 P를 움직이며 두 직선의 방정식과 기울기의 곱이 −1임을 확인합니다.",
    obs: ["접선: y − f(a) = f′(a)(x − a)입니다.", "법선은 접선에 수직이므로 기울기가 −1/f′(a)입니다.", "f′(a) = 0이면 법선은 세로 직선 x = a입니다."],
    q: "y = x² 위의 점 (1, 1)에서의 법선이 곡선과 다시 만나는 점을 구해 봅시다.",
    formula: "접선 y = f′(a)(x − a) + f(a), 법선 y = −(x − a)/f′(a) + f(a)",
    en: { title: "Tangent and Normal Lines", desc: "Slopes multiply to −1." },
    view: { x: [-4, 4], y: [-2, 5.5] },
    params: [{ key: "a", label: "점 P의 x좌표 a", min: -2, max: 2, step: 0.05, value: 1 }],
    anim: { key: "a", min: -2, max: 2, speed: 0.8, loop: "bounce", label: "P 움직이기" },
    draw(s, g) { const f = (x) => x * x, m = 2 * s.a, P = [s.a, f(s.a)]; g.grid(); g.fx(f, { color: "b", w: 3 }); g.line(P, [s.a + 1, f(s.a) + m], { color: "a", w: 2.4 }); if (Math.abs(m) > 1e-9) g.line(P, [s.a + 1, f(s.a) - 1 / m], { color: "c", w: 2.4 }); else g.seg([s.a, g.yr[0]], [s.a, g.yr[1]], { color: "c", w: 2.4 }); g.right(P, [s.a + 1, f(s.a) + m], [s.a - m, f(s.a) + 1], { color: "e", size: 12 }); g.point(P, "P", { color: "ink" }); g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], "주황: 접선   초록: 법선", { anchor: "start", bold: true }); },
    metrics(s) { const m = 2 * s.a, b = s.a * s.a; return [["접선", `y = ${poly([[m, "x"]], b - m * s.a)}`], ["법선", Math.abs(m) < 1e-9 ? `x = ${fmt(s.a)}` : `y = ${poly([[-1 / m, "x"]], b + s.a / m)}`], ["기울기의 곱", Math.abs(m) < 1e-9 ? "—" : "−1", "key"]]; },
    predict: [
      { q: "y = x² 위의 점 (1, 1)에서 법선의 기울기는?", set: (s) => (s.a = 0.3), reveal: (s) => (s.a = 1), answer: () => -0.5, why: "접선의 기울기가 2이므로 법선은 −1/2입니다." },
      { q: "그 법선의 y절편은?", set: (s) => (s.a = 1), answer: () => 1.5, why: "y − 1 = −(1/2)(x − 1)에서 x = 0이면 y = 3/2입니다." },
    ],
  },
  {
    id: "calc1-power-rule", grade: C1, unit: 2, lesson: "Ⅱ-2", title: "xⁿ의 미분 — 기울기가 nxⁿ⁻¹이 되는 까닭", type: "조작", time: "10분",
    tags: ["도함수", "거듭제곱", "미분법"], links: ["calc-secant-tangent", "calc1-sketch-deriv"],
    desc: "y = xⁿ 위의 점에서 할선의 기울기 {(x + h)ⁿ − xⁿ}/h를 구하면 nxⁿ⁻¹ + (h를 포함한 항)이 됩니다. h를 0에 가까이 하며 할선 기울기가 nxⁿ⁻¹로 다가가는 것을 확인하고, n을 바꾸어 규칙을 찾습니다.",
    obs: ["(x + h)ⁿ을 전개하면 xⁿ + nxⁿ⁻¹h + (h²을 포함한 항)입니다.", "h로 나누고 h → 0이면 nxⁿ⁻¹만 남습니다.", "상수함수의 도함수는 0, (cxⁿ)′ = cnxⁿ⁻¹입니다."],
    q: "(x⁵)′을 같은 방법으로 설명해 봅시다.",
    formula: "(xⁿ)′ = nxⁿ⁻¹",
    en: { title: "The Power Rule", desc: "Why the slope is nxⁿ⁻¹." },
    view: { x: [-2.5, 2.5], y: [-3, 5] },
    params: [{ key: "n", label: "n", min: 1, max: 5, step: 1, value: 3 }, { key: "x", label: "x", min: -1.5, max: 1.5, step: 0.05, value: 1 }, { key: "h", label: "h", min: 0.01, max: 1, step: 0.01, value: 0.5 }],
    anim: { key: "h", min: 0.01, max: 1, speed: 0.3, loop: "bounce", label: "h 줄이기" },
    draw(s, g) { const f = (x) => x ** s.n, P = [s.x, f(s.x)], Q = [s.x + s.h, f(s.x + s.h)], m = s.n * s.x ** (s.n - 1); g.grid(); g.fx(f, { color: "b", w: 3 }); g.line(P, Q, { color: "a", w: 2 }); g.line(P, [s.x + 1, f(s.x) + m], { color: "c", w: 2, dash: "6 4" }); g.point(P, "P", { color: "ink" }).point(Q, "Q", { color: "a" }); g.text([g.xr[0] + 0.2, g.yr[1] - 0.4], `y = x${"⁰¹²³⁴⁵"[s.n]}   주황: 할선 · 초록: 접선`, { anchor: "start", bold: true }); },
    metrics(s) { const f = (x) => x ** s.n, m = s.n * s.x ** (s.n - 1); return [["할선의 기울기", fmt((f(s.x + s.h) - f(s.x)) / s.h, 5)], [`n x^(n−1) = ${s.n}·${fmt(s.x)}^${s.n - 1}`, fmt(m, 5), "key"]]; },
    predict: [
      { q: "y = x³의 x = 2에서의 미분계수는?", set: (s) => Object.assign(s, { n: 3, x: 1, h: 0.5 }), answer: () => 12, why: "3x² = 3 × 4 = 12입니다." },
      { q: "y = x⁴의 x = −1에서의 미분계수는?", set: (s) => Object.assign(s, { n: 4, x: -1, h: 0.8 }), reveal: (s) => (s.h = 0.01), answer: () => -4, why: "4x³ = 4 × (−1) = −4입니다." },
    ],
  },
  {
    id: "calc1-sketch-deriv", grade: C1, unit: 2, lesson: "Ⅱ-2 탐구", title: "f의 그래프에서 f′의 그래프 그리기 — 기울기를 찍어 가며", type: "조작", time: "12분",
    tags: ["도함수", "그래프", "기울기"], links: ["calc-derivative-graph", "calc1-power-rule"],
    desc: "위 그래프 y = f(x) 위를 점이 지나가며 그 점의 접선 기울기를 아래 좌표평면에 높이로 찍습니다. 찍힌 점들이 이어져 y = f′(x)의 그래프가 됩니다. f가 올라가는 곳에서는 f′ > 0, 꼭대기·골짜기에서는 f′ = 0임을 확인합니다.",
    obs: ["접선이 오른쪽 위로 기울면 f′(x) > 0입니다.", "극대·극소인 점에서 접선이 수평이라 f′(x) = 0입니다.", "f가 가장 가파르게 올라가는 곳에서 f′이 가장 큽니다."],
    q: "f′의 그래프만 보고 f의 극댓점과 극솟점을 찾는 방법을 설명해 봅시다.",
    formula: "f′(x) = (x에서 접선의 기울기)",
    en: { title: "Sketching f′ from f", desc: "Plot slopes as heights." },
    view: { x: [-3.4, 3.4], y: [-5.2, 3.6] },
    params: [{ key: "f", label: "f(x)", type: "select", value: "cub", options: Object.entries(SK).map(([k, v]) => [k, v.n]) }, { key: "x", label: "점의 위치 x", min: -3, max: 3, step: 0.02, value: 1.5 }],
    anim: { key: "x", min: -3, max: 3, speed: 0.9, label: "지나가며 찍기", loop: "wrap" },
    draw(s, g) {
      const K = SK[s.f], YT = 1.4, YB = -2.8, clip = (y, h) => clamp(y, -h, h);
      g.seg([-3.3, YT], [3.3, YT], { color: "axis", w: 1.2 }).seg([-3.3, YB], [3.3, YB], { color: "axis", w: 1.2 }).seg([0, -5], [0, 3.5], { color: "axis", w: 1 });
      g.param((x) => [x, YT + clip(K.f(x) * 0.6, 2.1)], -3.2, 3.2, { color: "b", w: 3 });
      g.param((x) => [x, YB + clip(K.d(x) * 0.6, 2.3)], -3.2, 3.2, { color: "muted", w: 1.2, dash: "4 4" });
      g.param((x) => [x, YB + clip(K.d(x) * 0.6, 2.3)], -3.2, s.x, { color: "a", w: 3 });
      const y = YT + K.f(s.x) * 0.6, m = K.d(s.x); g.seg([s.x - 0.7, y - 0.7 * m * 0.6], [s.x + 0.7, y + 0.7 * m * 0.6], { color: "c", w: 2.4 });
      g.point([s.x, y], "", { color: "ink" }).point([s.x, YB + clip(m * 0.6, 2.3)], "", { color: "a" });
      g.seg([s.x, y], [s.x, YB + clip(m * 0.6, 2.3)], { color: "muted", w: 1, dash: "3 4" });
      g.text([-3.3, 3.4], `위: ${K.n}`, { anchor: "start", bold: true, color: "b" }).text([-3.3, -0.3], "아래: y = f′(x) (주황 = 지금까지 찍은 기울기)", { anchor: "start", bold: true, color: "a", size: 12 });
    },
    metrics(s) { const K = SK[s.f], m = K.d(s.x); return [["x", fmt(s.x, 2)], ["접선의 기울기 = f′(x)", fmt(m, 3), "key"], ["f는 지금", Math.abs(m) < 0.03 ? "수평 (극대·극소 후보)" : m > 0 ? "증가" : "감소"]]; },
    predict: [
      { q: "f(x) = x³/3 − x에서 f′(x) = 0이 되는 양수 x는?", set: (s) => Object.assign(s, { f: "cub", x: -3 }), reveal: (s) => (s.x = 1), answer: () => 1, why: "f′(x) = x² − 1 = 0에서 x = ±1입니다." },
      { q: "f가 감소하는 구간에서 f′의 그래프는?", options: O("x축 아래에 있다", "x축 위에 있다", "x축과 겹친다"), set: (s) => Object.assign(s, { f: "cub", x: -0.5 }), answer: () => "a", why: "접선이 오른쪽 아래로 기울어 기울기가 음수입니다." },
    ],
  },
  {
    id: "calc1-rolle", grade: C1, unit: 3, lesson: "Ⅲ-1", title: "롤의 정리 — 같은 높이의 두 점 사이에 수평 접선", type: "조작", time: "10분",
    tags: ["롤의 정리", "평균값 정리", "접선"], links: ["calc-mean-value"],
    desc: "y = x³ − 3x와 가로선 y = k가 만나는 두 점 a, b에서 f(a) = f(b)입니다. 그 사이 어딘가에 접선이 수평인 점 c가 반드시 있음을 가로선을 위아래로 움직이며 확인합니다. 평균값 정리의 특별한 경우입니다.",
    obs: ["f가 [a, b]에서 연속, (a, b)에서 미분가능하고 f(a) = f(b)이면 f′(c) = 0인 c가 (a, b)에 있습니다.", "올라갔다 내려오려면(또는 반대) 어디선가 한 번 멈춰야 합니다.", "평균값 정리에서 할선이 수평인 경우가 롤의 정리입니다."],
    q: "y = |x|는 [−1, 1]에서 f(−1) = f(1)인데 수평 접선이 없습니다. 어느 조건이 깨졌을까요?",
    formula: "f(a) = f(b) ⇒ f′(c) = 0 (a < c < b)",
    en: { title: "Rolle's Theorem", desc: "A horizontal tangent between equal heights." },
    view: { x: [-3, 3], y: [-3.4, 3.4] },
    params: [{ key: "k", label: "가로선 y = k", min: -1.9, max: 1.9, step: 0.05, value: 0.6 }],
    anim: { key: "k", min: -1.9, max: 1.9, speed: 0.8, loop: "bounce", label: "가로선 움직이기" },
    roots(s) { return criticalRoots(x => x ** 3 - 3 * x - s.k, [-1, 1], -2.5, 2.5); },
    draw(s, g) { const f = (x) => x ** 3 - 3 * x, R = this.roots(s); g.grid(); g.fx(f, { color: "b", w: 3 }); g.seg([g.xr[0], s.k], [g.xr[1], s.k], { color: "a", w: 1.6, dash: "6 4" }); R.forEach((x) => g.point([x, s.k], "", { color: "a" })); [-1, 1].forEach((c) => { const ok = R.length >= 2 && R.some((x) => x < c) && R.some((x) => x > c); g.seg([c - 0.6, f(c)], [c + 0.6, f(c)], { color: ok ? "c" : "muted", w: ok ? 3 : 1.4 }); g.point([c, f(c)], ok ? "c" : "", { color: ok ? "c" : "muted", r: ok ? 5 : 3 }); }); },
    metrics(s) { const R = this.roots(s); return [["f(x) = k의 실근", R.map((x) => fmt(x, 3)).join(", ")], ["그 사이의 수평 접선", R.length === 3 ? "x = −1과 x = 1 (두 군데)" : "—", "key"]]; },
    predict: [
      { q: "f(x) = x³ − 3x에서 f′(c) = 0인 c 가운데 양수는?", answer: () => 1, why: "f′(x) = 3x² − 3 = 0에서 x = ±1입니다." },
      { q: "y = |x|가 [−1, 1]에서 롤의 정리를 만족하지 않는 까닭은?", options: O("x = 0에서 미분가능하지 않다", "연속이 아니다", "f(−1) ≠ f(1)이다"), answer: () => "a", why: "뾰족한 점 x = 0에서 미분계수가 없습니다." },
    ],
  },
  {
    id: "calc1-sign-chart", grade: C1, unit: 3, lesson: "Ⅲ-2", title: "증감표 만들기 — f′의 부호로 그래프의 모양 읽기", type: "조작", time: "12분",
    tags: ["증가와 감소", "증감표", "극값"], links: ["calc-derivative-graph", "calc1-cubic-extrema"],
    desc: "f′(x) = 3(x − α)(x − β)인 삼차함수에서 α, β를 정하면 f′의 부호가 +, −, +로 바뀝니다. 그래프 아래에 증감표를 자동으로 만들어 ↗, ↘ 화살표와 극대·극소가 그래프와 맞는지 확인합니다.",
    obs: ["f′(x) > 0인 구간에서 증가(↗), f′(x) < 0이면 감소(↘)합니다.", "f′의 부호가 +에서 −로 바뀌는 곳이 극대, −에서 +로 바뀌면 극소입니다.", "증감표만 있으면 그래프의 대략적인 모양을 그릴 수 있습니다."],
    q: "f′의 부호가 바뀌지 않는 f′(x) = 0인 점은 어떤 모양일까요?",
    formula: "f′(x) = 3(x − α)(x − β)",
    en: { title: "Sign Charts", desc: "Read the graph from the sign of f′." },
    view: { x: [-4, 4], y: [-6.4, 5] },
    params: [{ key: "al", label: "α", min: -3, max: 1, step: 0.5, value: -1 }, { key: "be", label: "β", min: -1, max: 3, step: 0.5, value: 1.5 }],
    onChange(s) { if (s.be <= s.al) s.be = s.al + 0.5; },
    f(s, x) { const { al: a, be: b } = s; return x ** 3 - 1.5 * (a + b) * x * x + 3 * a * b * x; },
    draw(s, g) {
      const f = (x) => this.f(s, x), off = f(0), F = (x) => clamp((f(x) - off) * 0.35 + 1.4, -1.6, 4.8);
      g.seg([-3.9, 1.4], [3.9, 1.4], { color: "axis", w: 1 }); g.param((x) => [x, F(x)], -3.8, 3.8, { color: "b", w: 3 });
      [[s.al, "극대", "a"], [s.be, "극소", "c"]].forEach(([x, t, c]) => { g.point([x, F(x)], t, { color: c, dy: t === "극대" ? -10 : 20 }); g.seg([x, F(x)], [x, -5.6], { color: "muted", w: 1, dash: "3 4" }); });
      const Y = -3.4, cells = [[-3.8, s.al, "+", "↗"], [s.al, s.be, "−", "↘"], [s.be, 3.8, "+", "↗"]];
      g.seg([-3.9, Y + 0.7], [3.9, Y + 0.7], { color: "ink", w: 1.4 }).seg([-3.9, Y - 0.7], [3.9, Y - 0.7], { color: "ink", w: 1.4 }).seg([-3.9, Y - 2.1], [3.9, Y - 2.1], { color: "ink", w: 1.4 });
      g.text([-3.85, Y], "f′(x)", { anchor: "start", dy: 5, size: 12, bold: true }).text([-3.85, Y - 1.4], "f(x)", { anchor: "start", dy: 5, size: 12, bold: true });
      cells.forEach(([a, b, sg, ar]) => { const m = (Math.max(a, -3) + b) / 2; g.text([m, Y], sg, { dy: 6, bold: true, size: 18, color: sg === "+" ? "c" : "e" }).text([m, Y - 1.4], ar, { dy: 7, bold: true, size: 22, color: sg === "+" ? "c" : "e" }); });
      [s.al, s.be].forEach((x) => g.text([x, Y], "0", { dy: 6, bold: true, size: 15 }));
    },
    metrics(s) { return [["증가 구간", `x < ${fmt(s.al)}, x > ${fmt(s.be)}`], ["감소 구간", `${fmt(s.al)} < x < ${fmt(s.be)}`], ["극대 · 극소", `x = ${fmt(s.al)} · x = ${fmt(s.be)}`, "key"]]; },
    predict: [
      { q: "f′(x) = 3(x + 1)(x − 2)이면 f가 극소인 x는?", set: (s) => Object.assign(s, { al: -1, be: 1 }), reveal: (s) => (s.be = 2), answer: () => 2, why: "x = 2에서 f′의 부호가 −에서 +로 바뀝니다." },
      { q: "같은 함수에서 감소하는 구간에 들어 있는 정수는 몇 개?", set: (s) => Object.assign(s, { al: -1, be: 2 }), answer: () => 2, why: "−1 < x < 2에서 감소하므로 0과 1의 2개입니다." },
    ],
  },
  {
    id: "calc1-quartic", grade: C1, unit: 3, lesson: "Ⅲ-3", title: "사차함수의 개형 — W자와 U자", type: "조작", time: "10분",
    tags: ["사차함수", "극값", "개형"], links: ["calc1-cubic-extrema", "calc1-sign-chart"],
    desc: "y = x⁴ + px² + qx의 도함수 4x³ + 2px + q는 삼차식이라 실근이 1개 또는 3개입니다. p, q를 바꾸며 극값이 1개인 U자 모양과 3개인 W자 모양을 만들고, q = 0일 때 그래프가 y축에 대하여 대칭이 되는 것도 확인합니다.",
    obs: ["최고차항의 계수가 양수인 사차함수는 양 끝이 모두 위로 올라갑니다.", "f′(x) = 0의 실근이 3개이면 극소-극대-극소의 W자입니다.", "p ≥ 0이고 q = 0이면 극값이 하나뿐인 U자입니다."],
    q: "y = x⁴ − 2x²의 극댓값과 극솟값을 구해 봅시다.",
    formula: "f′(x) = 4x³ + 2px + q",
    en: { title: "Shapes of Quartics", desc: "W-shape or U-shape." },
    view: { x: [-3, 3], y: [-4.5, 4.5] },
    params: [{ key: "p", label: "p", min: -4, max: 2, step: 0.25, value: -2 }, { key: "q", label: "q", min: -3, max: 3, step: 0.25, value: 0 }],
    crit(s) { const d = (x) => 4 * x ** 3 + 2 * s.p * x + s.q, R = []; for (let i = 0; i < 2000; i++) { const a = -3 + (6 * i) / 2000, b = a + 6 / 2000; if (d(a) * d(b) <= 0) R.push((a + b) / 2); } return R.filter((x, i, A) => !i || x - A[i - 1] > 0.01); },
    draw(s, g) { const f = (x) => x ** 4 + s.p * x * x + s.q * x, C = this.crit(s); g.grid(); g.fx(f, { color: "b", w: 3 }); C.forEach((x, i) => g.point([x, f(x)], C.length === 3 && i === 1 ? "극대" : "극소", { color: C.length === 3 && i === 1 ? "a" : "c", dy: C.length === 3 && i === 1 ? -10 : 20 })); g.text([g.xr[0] + 0.2, g.yr[1] - 0.4], `y = x⁴ ${s.p < 0 ? "−" : "+"} ${fmt(Math.abs(s.p))}x² ${s.q < 0 ? "−" : "+"} ${fmt(Math.abs(s.q))}x`, { anchor: "start", bold: true, color: "b" }); },
    metrics(s) { const f = (x) => x ** 4 + s.p * x * x + s.q * x, C = this.crit(s); return [["극값의 개수", `${C.length}개`, "key"], ["모양", C.length === 3 ? "W자" : "U자"], ["극값", C.map((x) => `f(${fmt(x, 2)}) = ${fmt(f(x), 2)}`).join(", ")]]; },
    predict: [
      { q: "y = x⁴ − 2x²의 극솟값은?", set: (s) => Object.assign(s, { p: 1, q: 0 }), reveal: (s) => Object.assign(s, { p: -2, q: 0 }), answer: () => -1, why: "f′ = 4x(x² − 1)에서 x = ±1일 때 1 − 2 = −1입니다." },
      { q: "y = x⁴ + x²의 극값은 몇 개?", set: (s) => Object.assign(s, { p: -2, q: 0 }), reveal: (s) => Object.assign(s, { p: 1, q: 0 }), answer: () => 1, why: "f′ = 2x(2x² + 1) = 0의 실근이 x = 0 하나뿐입니다." },
    ],
  },
  {
    id: "calc1-can", grade: C1, unit: 3, lesson: "Ⅲ-4 실생활", title: "음료 캔 설계 — 같은 부피에서 겉넓이가 가장 작은 모양", type: "조작", time: "12분",
    tags: ["최솟값", "미분의 활용", "원기둥"], links: ["calc1-closed-maxmin"],
    desc: "부피가 V로 정해진 원기둥 캔의 겉넓이 S = 2πr² + 2V/r은 반지름 r에 따라 달라집니다. 왼쪽에 캔의 모양을, 오른쪽에 S의 그래프를 보며 S′ = 0인 r에서 겉넓이가 가장 작고 그때 높이가 지름과 같다는 것을 확인합니다. (원기둥 겉넓이 식은 미분 활용을 위한 보충 예입니다.)",
    obs: ["h = V/(πr²)이므로 S는 r 하나의 함수입니다.", "S′ = 4πr − 2V/r² = 0에서 r³ = V/(2π)입니다.", "그때 h = 2r, 곧 높이와 지름이 같습니다."],
    q: "실제 음료 캔은 왜 이 모양보다 더 길쭉할까요?",
    formula: "S(r) = 2πr² + 2V/r, 최소일 때 h = 2r",
    en: { title: "Designing a Can", desc: "Minimize surface area for fixed volume." },
    view: { x: [-0.5, 15.5], y: [-0.8, 10.6] },
    params: [{ key: "V", label: "부피 V (cm³)", min: 200, max: 600, step: 10, value: 355 }, { key: "r", label: "반지름 r (cm)", min: 1.5, max: 8, step: 0.05, value: 3 }],
    anim: { key: "r", min: 1.5, max: 8, speed: 1.2, loop: "bounce", label: "반지름 바꾸기" },
    draw(s, g) {
      const h = s.V / (Math.PI * s.r * s.r), S = (r) => 2 * Math.PI * r * r + (2 * s.V) / r, ro = (s.V / (2 * Math.PI)) ** (1 / 3), k = 0.4;
      rect(g, 3 - s.r * k, 0.6, 2 * s.r * k, Math.min(h * k, 9.4), { fill: "b", fo: 0.3, color: "b", w: 2 });
      g.text([3, 0.6], `r = ${fmt(s.r, 2)}`, { dy: 16, size: 12, bold: true }).text([3 + s.r * k + 0.15, 0.6 + Math.min(h * k, 9.4) / 2], `h = ${fmt(h, 2)}`, { anchor: "start", size: 12, bold: true });
      const X = (r) => 7 + ((r - 1.5) / 6.5) * 8, Y = (v) => 0.6 + ((v - 200) / 500) * 9.6;
      g.seg([7, 0.6], [15.2, 0.6], { color: "axis", w: 1.2 }).seg([7, 0.6], [7, 10.4], { color: "axis", w: 1.2 });
      g.param((r) => [X(r), Y(clamp(S(r), 200, 700))], 1.5, 8, { color: "a", w: 2.6 });
      g.point([X(ro), Y(S(ro))], `최소 r ≈ ${fmt(ro, 2)}`, { color: "e", dy: 20 }).point([X(s.r), Y(clamp(S(s.r), 200, 700))], "", { color: "b" });
      g.text([11, 10.3], "겉넓이 S(r)", { bold: true, color: "a", size: 12 }).text([15.2, 0.6], "r", { dy: 16, size: 12, color: "muted" });
    },
    metrics(s) { const h = s.V / (Math.PI * s.r * s.r), S = 2 * Math.PI * s.r * s.r + (2 * s.V) / s.r, ro = (s.V / (2 * Math.PI)) ** (1 / 3); return [["겉넓이", `${fmt(S, 1)} cm²`], ["높이 ÷ 지름", fmt(h / (2 * s.r), 3)], ["가장 작을 때", `r = ${fmt(ro, 2)}, S = ${fmt(2 * Math.PI * ro * ro + (2 * s.V) / ro, 1)}`, "key"]]; },
    predict: [
      { q: "겉넓이가 가장 작을 때 (높이) ÷ (지름)은?", set: (s) => Object.assign(s, { V: 355, r: 6 }), reveal: (s) => (s.r = (355 / (2 * Math.PI)) ** (1 / 3)), answer: () => 1, why: "r³ = V/(2π)이면 h = V/(πr²) = 2r이라 높이와 지름이 같습니다." },
      { q: "부피 250π cm³일 때 겉넓이가 가장 작은 반지름은 몇 cm?", answer: () => 5, why: "r³ = 250π/(2π) = 125이므로 r = 5입니다." },
    ],
  },
  {
    id: "calc1-ineq-min", grade: C1, unit: 3, lesson: "Ⅲ-5", title: "부등식의 증명 — 최솟값이 0 이상이면", type: "조작", time: "10분",
    tags: ["부등식", "최솟값", "미분의 활용"], links: ["calc1-roots-k", "calc1-closed-maxmin"],
    desc: "x ≥ 0에서 x³ − 3x + k ≥ 0이 항상 성립하게 하려면 왼쪽 함수의 최솟값이 0 이상이면 됩니다. k를 바꾸며 그래프가 x축 아래로 내려가는지 보고, 극솟값 f(1) = k − 2 ≥ 0에서 k ≥ 2임을 확인합니다.",
    obs: ["'항상 f(x) ≥ 0'은 '(최솟값) ≥ 0'과 같습니다.", "x ≥ 0에서 f′(x) = 3x² − 3이므로 x = 1에서 최소입니다.", "f(1) = k − 2 ≥ 0이면 k ≥ 2입니다."],
    q: "x > 0에서 x + 1/x ≥ 2가 성립함을 미분으로 보여 봅시다.",
    formula: "x ≥ 0에서 f(x) ≥ 0 ⇔ min f ≥ 0",
    en: { title: "Proving Inequalities with Minima", desc: "Keep the minimum above zero." },
    view: { x: [-0.6, 3.2], y: [-2.6, 4.4] },
    params: [{ key: "k", label: "k", min: 0, max: 4, step: 0.1, value: 1.2 }],
    anim: { key: "k", min: 0, max: 4, speed: 1, loop: "bounce", label: "k 바꾸기" },
    draw(s, g) { const f = (x) => x ** 3 - 3 * x + s.k; g.grid(); shade(g, (x) => Math.min(0, f(x)), 0, 3); g.fx(f, { color: "b", w: 3, from: 0 }); g.point([1, f(1)], `최솟값 ${fmt(f(1), 2)}`, { color: f(1) >= 0 ? "c" : "e", dy: 20 }); g.text([g.xr[0] + 0.2, g.yr[1] - 0.4], `y = x³ − 3x + ${fmt(s.k)} (x ≥ 0)`, { anchor: "start", bold: true, color: "b" }); },
    metrics(s) { return [["최솟값 f(1) = k − 2", fmt(s.k - 2, 2)], ["x ≥ 0에서 항상 ≥ 0?", s.k >= 2 - 1e-9 ? "예" : "아니요 (분홍 부분)", "key"]]; },
    predict: [
      { q: "x ≥ 0에서 x³ − 3x + k ≥ 0이 항상 성립하는 k의 최솟값은?", set: (s) => (s.k = 0.5), reveal: (s) => (s.k = 2), answer: () => 2, why: "최솟값 f(1) = k − 2 ≥ 0이므로 k ≥ 2입니다." },
      { q: "k = 2일 때 f(x) = 0이 되는 양수 x는?", set: (s) => (s.k = 2), answer: () => 1, why: "x³ − 3x + 2 = (x − 1)²(x + 2)이므로 x = 1에서 x축에 접합니다." },
    ],
  },
  {
    id: "calc1-split", grade: C1, unit: 4, lesson: "Ⅳ-4", title: "정적분의 성질 — 구간을 쪼개고 이어 붙이기", type: "조작", time: "10분",
    tags: ["정적분의 성질", "구간", "넓이"], links: ["calc1-definite-sign", "calc1-ftc"],
    desc: "∫ₐᵇ f(x) dx = ∫ₐᶜ f(x) dx + ∫꜀ᵇ f(x) dx가 c의 위치와 관계없이 성립함을 확인합니다. c를 구간 밖으로 옮기면 한쪽 적분이 '거꾸로 간 적분'이 되어 빼지는 것도 색으로 봅니다.",
    obs: ["c가 a와 b 사이에 있으면 넓이를 둘로 나눈 것입니다.", "∫꜀ᵇ = −∫ᵇ꜀이므로 c가 밖에 있어도 등식이 성립합니다.", "∫ₐᵃ f(x) dx = 0입니다."],
    q: "∫₀³ f(x) dx = 5, ∫₂³ f(x) dx = 1이면 ∫₀² f(x) dx는?",
    formula: "∫ₐᵇ = ∫ₐᶜ + ∫꜀ᵇ, ∫ᵇₐ = −∫ₐᵇ",
    en: { title: "Splitting Definite Integrals", desc: "Additivity over intervals." },
    view: { x: [-1, 5], y: [-1.6, 4] },
    params: [{ key: "a", label: "a", min: 0, max: 1.5, step: 0.1, value: 0.5 }, { key: "b", label: "b", min: 2, max: 4, step: 0.1, value: 3.5 }, { key: "c", label: "c", min: -0.8, max: 4.8, step: 0.1, value: 2 }],
    F: (x) => 0.3 * x * x - 0.2 * x + 1,
    draw(s, g) { const f = this.F; g.grid(); const lo = Math.min(s.a, s.c), hi = Math.max(s.a, s.c); for (let i = 0; i < 120; i++) { const x0 = lo + ((hi - lo) * i) / 120, x1 = lo + ((hi - lo) * (i + 1)) / 120; g.poly([[x0, 0], [x1, 0], [x1, f(x0)], [x0, f(x0)]], { fill: s.c >= s.a ? "b" : "e", fo: 0.3, stroke: false }); } const l2 = Math.min(s.c, s.b), h2 = Math.max(s.c, s.b); for (let i = 0; i < 120; i++) { const x0 = l2 + ((h2 - l2) * i) / 120, x1 = l2 + ((h2 - l2) * (i + 1)) / 120; g.poly([[x0, 0], [x1, 0], [x1, -0.35], [x0, -0.35]], { fill: s.b >= s.c ? "c" : "e", fo: 0.6, stroke: false }); } g.fx(f, { color: "ink", w: 2.6 }); [["a", s.a], ["b", s.b], ["c", s.c]].forEach(([n, x]) => g.text([x, 0], n, { dy: 30, bold: true, color: n === "c" ? "a" : "ink" })); g.seg([s.c, -1.2], [s.c, 3.8], { color: "a", w: 1.6, dash: "5 4" }); g.text([-0.9, 3.8], "파랑: ∫ₐᶜ (분홍이면 거꾸로)   아래 띠: ∫꜀ᵇ", { anchor: "start", bold: true, size: 12 }); },
    metrics(s) { const f = this.F, I = (p, q) => simpson(f, p, q); return [["∫ₐᶜ", fmt(I(s.a, s.c), 4)], ["∫꜀ᵇ", fmt(I(s.c, s.b), 4)], ["합", fmt(I(s.a, s.c) + I(s.c, s.b), 4)], ["∫ₐᵇ", fmt(I(s.a, s.b), 4), "key"]]; },
    predict: [
      { q: "∫₀³ f(x) dx = 5, ∫₂³ f(x) dx = 1이면 ∫₀² f(x) dx는?", answer: () => 4, why: "∫₀³ = ∫₀² + ∫₂³이므로 5 − 1 = 4입니다." },
      { q: "∫₃¹ f(x) dx = −6이면 ∫₁³ f(x) dx는?", answer: () => 6, why: "적분 구간의 위끝과 아래끝을 바꾸면 부호가 바뀝니다." },
    ],
  },
  {
    id: "calc1-even-odd", grade: C1, unit: 4, lesson: "Ⅳ-4", title: "우함수·기함수의 정적분 — 대칭이면 반만 계산", type: "조작", time: "10분",
    tags: ["정적분", "대칭", "우함수"], links: ["calc1-split", "calc1-definite-sign"],
    desc: "y축에 대칭인 함수(우함수)는 ∫₋ₐᵃ f(x) dx = 2∫₀ᵃ f(x) dx이고, 원점에 대칭인 함수(기함수)는 왼쪽과 오른쪽 넓이가 서로 지워져 0입니다. a를 바꾸며 색칠된 넓이로 확인합니다.",
    obs: ["우함수: f(−x) = f(x), 예: x², x⁴, 상수.", "기함수: f(−x) = −f(x), 예: x, x³.", "다항식은 짝수 차항과 홀수 차항으로 나누어 계산하면 편합니다."],
    q: "∫₋₂² (x³ + 3x² − x + 1) dx를 빠르게 계산해 봅시다.",
    formula: "우함수 ∫₋ₐᵃ f = 2∫₀ᵃ f, 기함수 ∫₋ₐᵃ f = 0",
    en: { title: "Even and Odd Integrals", desc: "Symmetry halves the work." },
    view: { x: [-3.2, 3.2], y: [-3.2, 4] },
    params: [{ key: "f", label: "함수", type: "select", value: "odd", options: Object.entries(EO).map(([k, v]) => [k, v.n]) }, { key: "a", label: "a", min: 0.2, max: 2.4, step: 0.1, value: 2 }],
    draw(s, g) { const K = EO[s.f]; g.grid(); shade(g, K.f, -s.a, s.a); g.fx(K.f, { color: "ink", w: 2.6 }); [-s.a, s.a].forEach((x) => g.seg([x, -3], [x, 3.8], { color: "muted", w: 1.2, dash: "4 4" })); g.text([g.xr[0] + 0.2, g.yr[1] - 0.4], K.n, { anchor: "start", bold: true }); },
    metrics(s) { const K = EO[s.f], L = simpson(K.f, -s.a, 0), R = simpson(K.f, 0, s.a); return [["∫₋ₐ⁰", fmt(L, 4)], ["∫₀ᵃ", fmt(R, 4)], ["∫₋ₐᵃ", fmt(L + R, 4), "key"]]; },
    predict: [
      { q: "∫₋₂² (x³ − 2x) dx의 값은?", set: (s) => Object.assign(s, { f: "odd", a: 1 }), reveal: (s) => (s.a = 2), answer: () => 0, why: "기함수라 왼쪽과 오른쪽이 서로 지워집니다." },
      { q: "∫₋₂² (x³ + 3x² − x + 1) dx의 값은?", answer: () => 20, why: "홀수 차항은 0, 2∫₀²(3x² + 1) dx = 2(8 + 2) = 20입니다." },
    ],
  },
  {
    id: "calc1-trapezoid", grade: C1, unit: 4, lesson: "Ⅳ-3 탐구", title: "사다리꼴로 넓이 어림하기 — 직사각형보다 빠르게", type: "조작", time: "10분",
    tags: ["구분구적법", "근삿값", "사다리꼴"], links: ["calc-riemann", "calc2-riemann-limit"],
    desc: "곡선 아래 넓이를 n개의 사다리꼴로 어림하면 같은 n에서 직사각형(왼쪽 끝 높이)보다 훨씬 정확합니다. n을 늘리며 두 어림값과 정적분의 차이가 어떻게 줄어드는지 비교합니다.",
    obs: ["사다리꼴은 곡선의 양 끝 높이를 모두 써서 경사를 반영합니다.", "n을 2배로 하면 사다리꼴 어림의 오차는 대략 1/4로 줄어듭니다.", "직사각형 어림의 오차는 대략 1/2로 줄어듭니다."],
    q: "아래로 볼록한 곡선에서 사다리꼴 어림은 참값보다 클까요, 작을까요?",
    formula: "T = (Δx/2)(f₀ + 2f₁ + ⋯ + 2fₙ₋₁ + fₙ)",
    en: { title: "The Trapezoid Rule", desc: "Faster than rectangles." },
    view: { x: [-0.4, 3.4], y: [-0.4, 9.6] },
    params: [{ key: "n", label: "나눈 개수 n", min: 1, max: 20, step: 1, value: 4 }, { key: "rect", label: "직사각형도 보이기", type: "check", value: false }],
    anim: { key: "n", min: 1, max: 20, speed: 3, label: "n 늘리기" },
    f: (x) => x * x,
    sums(s) { const f = this.f, h = 3 / s.n; let T = 0, L = 0; for (let i = 0; i < s.n; i++) { T += ((f(i * h) + f((i + 1) * h)) * h) / 2; L += f(i * h) * h; } return { T, L, I: 9 }; },
    draw(s, g) { const f = this.f, h = 3 / s.n; for (let i = 0; i < s.n; i++) { const x0 = i * h, x1 = x0 + h; if (s.rect) g.poly([[x0, 0], [x1, 0], [x1, f(x0)], [x0, f(x0)]], { fill: "c", fo: 0.25, color: "c", w: 1 }); g.poly([[x0, 0], [x1, 0], [x1, f(x1)], [x0, f(x0)]], { fill: "a", fo: 0.25, color: "a", w: 1.4 }); } g.fx(f, { color: "ink", w: 2.6, from: 0, to: 3.1 }); g.grid({ labels: false, step: 1 }); },
    metrics(s) { const R = this.sums(s); return [["사다리꼴 어림", `${fmt(R.T, 4)} (오차 ${fmt(R.T - R.I, 4)})`, "key"], ["직사각형 어림", `${fmt(R.L, 4)} (오차 ${fmt(R.L - R.I, 4)})`], ["참값 ∫₀³ x² dx", "9"]]; },
    predict: [
      { q: "∫₀³ x² dx를 사다리꼴 3개로 어림하면?", set: (s) => Object.assign(s, { n: 1 }), reveal: (s) => (s.n = 3), answer: () => 9.5, tol: 1e-6, why: "(1/2)(0 + 2 + 8 + 9) = 9.5입니다." },
      { q: "y = x²처럼 아래로 볼록한 곡선에서 사다리꼴 어림은?", options: O("참값보다 크다", "참값보다 작다", "늘 같다"), answer: () => "a", why: "사다리꼴의 윗변(현)이 곡선보다 위에 있기 때문입니다." },
    ],
  },
  {
    id: "calc1-mean-integral", grade: C1, unit: 4, lesson: "Ⅳ-4 탐구", title: "정적분의 평균값 — 넓이가 같은 직사각형의 높이", type: "조작", time: "10분",
    tags: ["정적분", "평균", "넓이"], links: ["calc1-split", "calc-mean-value"],
    desc: "구간 [a, b]에서 곡선 아래 넓이와 넓이가 같은 직사각형의 높이를 함수의 평균값 (1/(b − a))∫ₐᵇ f(x) dx라 합니다. 직사각형을 위아래로 옮겨 넓이가 맞는 높이를 찾고, 그 높이가 되는 x가 구간 안에 꼭 있다는 것도 확인합니다.",
    obs: ["평균값 × (b − a) = ∫ₐᵇ f(x) dx입니다.", "직사각형 위로 튀어나온 넓이와 비어 있는 넓이가 같습니다.", "f가 연속이면 f(c) = (평균값)인 c가 [a, b]에 있습니다."],
    q: "하루 기온 그래프의 평균값은 무엇을 뜻할까요?",
    formula: "평균값 = (1/(b − a)) ∫ₐᵇ f(x) dx",
    en: { title: "Average Value of a Function", desc: "A rectangle of the same area." },
    view: { x: [-0.4, 4.4], y: [-0.4, 5] },
    params: [{ key: "b", label: "b (a = 0)", min: 1, max: 4, step: 0.1, value: 3 }, { key: "hgt", label: "직사각형 높이", min: 0, max: 4.5, step: 0.05, value: 1.5 }],
    f: (x) => 1 + 0.6 * x + 0.8 * Math.sin(1.6 * x),
    draw(s, g) { const f = this.f, m = simpson(f, 0, s.b) / s.b; g.region(f, () => 0, 0, s.b, { fill: "b", fo: 0.25 }); g.poly([[0, 0], [s.b, 0], [s.b, s.hgt], [0, s.hgt]], { fill: "a", fo: 0.15, color: "a", w: 2 }); g.fx(f, { color: "ink", w: 2.6, from: 0, to: 4.2 }); g.seg([0, m], [s.b, m], { color: "e", w: 1.6, dash: "5 4" }).text([s.b, m], "평균값", { dx: 6, anchor: "start", dy: 4, bold: true, color: "e", size: 12 }); g.grid({ labels: false }); },
    metrics(s) { const f = this.f, I = simpson(f, 0, s.b); return [["곡선 아래 넓이", fmt(I, 4)], ["직사각형 넓이", fmt(s.hgt * s.b, 4)], ["평균값", fmt(I / s.b, 4), "key"]]; },
    predict: [
      { q: "f(x) = 2x의 [0, 3]에서의 평균값은?", answer: () => 3, why: "∫₀³ 2x dx = 9를 3으로 나누면 3입니다." },
      { q: "직사각형 넓이가 곡선 아래 넓이와 같아지는 높이는?", options: O("함수의 평균값", "함수의 최댓값", "f(b)"), set: (s) => Object.assign(s, { b: 3, hgt: 0.5 }), answer: () => "a", why: "높이 × 밑변 = 넓이가 되는 높이가 평균값입니다." },
    ],
  },
  {
    id: "calc1-sixth", grade: C1, unit: 4, lesson: "Ⅳ-5", title: "포물선과 직선 사이의 넓이 — |a|(β − α)³/6", type: "조작", time: "12분",
    tags: ["넓이", "포물선", "공식"], links: ["calc-area-between"],
    desc: "포물선 y = ax² + bx + c와 직선이 x = α, β에서 만나면 둘 사이의 넓이는 |a|(β − α)³/6입니다. 두 교점과 a를 바꾸며 직접 적분한 값과 공식의 값이 늘 같음을 확인하고, 넓이가 두 교점 사이의 거리의 세제곱에 비례함을 봅니다.",
    obs: ["(포물선) − (직선) = a(x − α)(x − β)입니다.", "∫ₐᵝ a(x − α)(x − β) dx = −a(β − α)³/6입니다.", "그래서 넓이는 직선의 기울기와 상관없이 a와 β − α만으로 정해집니다."],
    q: "y = x²과 y = x + 2로 둘러싸인 넓이를 공식으로 구해 봅시다.",
    formula: "S = |a|(β − α)³/6",
    en: { title: "Area Between a Parabola and a Line", desc: "The |a|(β − α)³/6 formula." },
    view: { x: [-4, 4], y: [-2, 9] },
    params: [{ key: "a", label: "a", min: 0.25, max: 2, step: 0.25, value: 1 }, { key: "al", label: "α", min: -3, max: 1, step: 0.5, value: -1 }, { key: "be", label: "β", min: -1, max: 3, step: 0.5, value: 2 }, { key: "m", label: "직선의 기울기 (넓이와 무관)", min: -2, max: 2, step: 0.5, value: 1 }],
    onChange(s) { if (s.be <= s.al) s.be = s.al + 0.5; },
    draw(s, g) { const L = (x) => s.m * x + 2, P = (x) => s.a * (x - s.al) * (x - s.be) + L(x); g.grid(); g.region(L, P, s.al, s.be, { fill: "b", fo: 0.3 }); g.fx(P, { color: "b", w: 3 }); g.fx(L, { color: "a", w: 2.4 }); [s.al, s.be].forEach((x, i) => g.point([x, L(x)], i ? "β" : "α", { color: "ink" })); },
    metrics(s) { const L = (x) => s.m * x + 2, P = (x) => s.a * (x - s.al) * (x - s.be) + L(x), I = simpson((x) => L(x) - P(x), s.al, s.be); return [["직접 적분", fmt(I, 4)], ["|a|(β − α)³/6", fmt((s.a * (s.be - s.al) ** 3) / 6, 4), "key"]]; },
    predict: [
      { q: "y = x²과 y = x + 2로 둘러싸인 넓이는?", set: (s) => Object.assign(s, { a: 1, al: -1, be: 1, m: 1 }), reveal: (s) => (s.be = 2), answer: () => 4.5, tol: 1e-6, why: "x² = x + 2에서 α = −1, β = 2이므로 3³/6 = 4.5입니다." },
      { q: "두 교점 사이의 거리가 2배가 되면 넓이는 몇 배?", answer: () => 8, why: "(β − α)³에 비례하므로 2³ = 8배입니다." },
    ],
  },
];
