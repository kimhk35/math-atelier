// 23차 묶음 5 — 중학교 2학년 (유리수와 순환소수 · 식의 계산 · 부등식과 연립방정식 · 일차함수)
import { fmt, frac, poly, clamp } from "./hs-core.js";

const G2 = 2;
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a; };
const SUP = "⁰¹²³⁴⁵⁶⁷⁸⁹", supN = (n) => [...String(n)].map((d) => SUP[d]).join("");
const DOT = "̇";
const signed = (v) => (v < 0 ? `(${fmt(v)})` : fmt(v));
// p/q의 나눗셈: 몫 숫자들과 나머지, 순환 시작 위치
function longDiv(p, q) {
  const digits = [], rems = [], seen = new Map(); let r = p % q;
  while (r && !seen.has(r) && digits.length < 120) { seen.set(r, digits.length); rems.push(r); r *= 10; digits.push(Math.floor(r / q)); r %= q; }
  return { int: Math.floor(p / q), digits, rems, start: r ? seen.get(r) : -1 };
}
function decStr(D) {
  if (D.start < 0) return `${D.int}${D.digits.length ? "." + D.digits.join("") : ""}`;
  const pre = D.digits.slice(0, D.start).join(""), rep = D.digits.slice(D.start);
  // 순환마디가 길면(예: 1/97은 96자리) 가운데를 줄여 보여 준다
  const mid = rep.length > 16 ? rep.slice(1, 7).join("") + "…" + rep.slice(-6, -1).join("") : rep.slice(1, -1).join("");
  const r = rep.length === 1 ? rep[0] + DOT : rep[0] + DOT + mid + rep[rep.length - 1] + DOT;
  return `${D.int}.${pre}${r}`;
}
const REP = {
  a: { n: "0.3̇", v: [0, "", "3"] }, b: { n: "0.1̇2̇", v: [0, "", "12"] }, c: { n: "0.12̇", v: [0, "1", "2"] },
  d: { n: "1.2̇3̇", v: [1, "", "23"] }, e: { n: "0.9̇", v: [0, "", "9"] }, f: { n: "0.1̇42857̇", v: [0, "", "142857"] },
};
// 부등식 기호
const OPS = [[">", ">"], [">=", "≥"], ["<", "<"], ["<=", "≤"]], opS = (o) => ({ ">": ">", ">=": "≥", "<": "<", "<=": "≤" })[o], flip = (o) => ({ ">": "<", ">=": "<=", "<": ">", "<=": ">=" })[o];
const lineStr = (a, b, c) => `${poly([[a, "x"], [b, "y"]])} = ${fmt(c)}`;

export default [
  // ───────── 1단원 유리수와 순환소수 ─────────
  {
    id: "m2-repeating", grade: G2, unit: 1, lesson: "1.1", title: "나머지가 되풀이되면 순환소수 — 분모로 미리 알기", type: "조작", time: "12분",
    tags: ["순환소수", "유한소수", "나눗셈"], links: ["m2-rep-to-frac"],
    desc: "분수 p/q를 나눗셈으로 소수로 바꿀 때 나오는 나머지를 원 위에 차례로 찍습니다. 나머지는 1부터 q − 1까지뿐이라 언젠가 같은 나머지가 다시 나오고, 그때부터 몫이 되풀이됩니다. 기약분수의 분모가 2와 5만으로 이루어지면 나머지가 0이 되어 유한소수가 됨도 확인합니다.",
    obs: ["나머지가 0이 되면 유한소수, 같은 나머지가 다시 나오면 순환소수입니다.", "나머지의 종류가 q − 1가지뿐이므로 순환마디의 길이는 q − 1 이하입니다.", "기약분수의 분모의 소인수가 2나 5뿐이면 유한소수로 나타낼 수 있습니다."],
    q: "1/7의 순환마디가 6자리인 까닭을 나머지로 설명해 봅시다.",
    formula: "기약분수 a/b: b의 소인수가 2, 5뿐 ⇔ 유한소수",
    en: { title: "Repeating Decimals from Remainders", desc: "Remainders repeat, so digits repeat." },
    view: BOX,
    params: [
      { key: "q", label: "분모 q", min: 2, max: 100, step: 1, value: 7 },
      { key: "p", label: "분자 p", min: 1, max: (s) => s.q - 1, step: 1, value: 1 },
      { key: "k", label: "나눗셈 진행", min: 0, max: 30, step: 1, value: 30 },
    ],
    anim: { key: "k", min: 0, max: 30, speed: 2.5, label: "한 자리씩 나누기" },
    onChange(s) { s.p = clamp(s.p, 1, s.q - 1); },
    draw(s, g) {
      const D = longDiv(s.p, s.q), C = [4.2, 5.2], R = 3.4, n = s.q, k = Math.min(s.k, D.rems.length);
      g.circle(C, R, { color: "grid", w: 1.4 });
      const at = (r) => { const a = Math.PI / 2 - (2 * Math.PI * r) / n; return [C[0] + R * Math.cos(a), C[1] + R * Math.sin(a)]; };
      for (let r = 0; r < n; r++) { const used = D.rems.slice(0, k).includes(r); g.point(at(r), "", { color: r === 0 ? "e" : used ? "a" : "muted", r: used ? 5.5 : 3 }); g.text(at(r), String(r), { dy: 4, dx: (at(r)[0] - C[0]) * 6, size: 11, color: used ? "a" : "muted", anchor: "middle" }); }
      for (let i = 1; i < k; i++) g.vec(at(D.rems[i - 1]), at(D.rems[i]), { color: "a", w: 1.6, opacity: 0.7 });
      if (k === D.rems.length && D.start >= 0 && k) g.vec(at(D.rems[k - 1]), at(D.rems[D.start]), { color: "e", w: 2.4 });
      if (k === D.rems.length && D.start < 0 && k) g.vec(at(D.rems[k - 1]), at(0), { color: "e", w: 2.4 });
      g.text(C, "나머지", { dy: 5, size: 13, color: "muted" });
      const shown = D.digits.slice(0, k).join("");
      g.text([8.8, 9.6], `${s.p}/${s.q} = ${D.int}.${shown}${k < D.digits.length ? "…" : ""}`, { anchor: "start", bold: true, size: 18, mono: true });
      if (k >= D.digits.length) g.text([8.8, 8.4], D.start < 0 ? `나머지 0 → 유한소수 ${decStr(D)}` : `나머지 ${D.rems[D.start]}이 다시 나옴 → ${decStr(D)}`, { anchor: "start", bold: true, color: "e", size: 15 });
      D.rems.slice(0, Math.min(k, 10)).forEach((r, i) => g.text([8.8, 7.2 - i * 0.6], `${r} × 10 = ${r * 10} → 몫 ${D.digits[i]}, 나머지 ${(r * 10) % s.q}`, { anchor: "start", size: 12, color: "muted", mono: true }));
    },
    metrics(s) {
      const D = longDiv(s.p, s.q), g0 = gcd(s.p, s.q), qq = s.q / g0; let m = qq; while (m % 2 === 0) m /= 2; while (m % 5 === 0) m /= 5;
      return [["기약분수", `${s.p / g0}/${qq}`], ["분모의 소인수", m === 1 ? "2, 5뿐 → 유한소수" : "2, 5 말고도 있음 → 순환소수"], ["소수", decStr(D), "key"], ["순환마디의 길이", D.start < 0 ? "—" : `${D.digits.length - D.start}자리`]];
    },
    predict: [
      { q: "1/7의 순환마디는 몇 자리일까요?", set: (s) => Object.assign(s, { q: 7, p: 1, k: 2 }), reveal: (s) => (s.k = 30), answer: () => 6, why: "나머지가 1, 3, 2, 6, 4, 5를 돌고 다시 1이 나와 142857이 되풀이됩니다." },
      { q: "7/40은 유한소수일까요?", options: O("그렇다", "아니다"), set: (s) => Object.assign(s, { q: 40, p: 7, k: 1 }), reveal: (s) => (s.k = 30), answer: () => "a", why: "40 = 2³ × 5라서 유한소수 0.175입니다." },
    ],
  },
  {
    id: "m2-rep-to-frac", grade: G2, unit: 1, lesson: "1.2", title: "순환소수를 분수로 — 10ⁿx − x로 꼬리 자르기", type: "조작", time: "10분",
    tags: ["순환소수", "분수", "등식"], links: ["m2-repeating"],
    desc: "순환소수 x에 10이나 100을 곱해 소수점 아래를 한 마디만큼 옮긴 뒤 원래 수를 빼면, 끝없이 이어지는 꼬리가 똑같아 사라집니다. 이렇게 순환소수를 분수로 바꾸고, 0.9̇ = 1이 되는 까닭도 확인합니다.",
    obs: ["순환마디가 k자리이면 10ᵏ을 곱해 한 마디를 소수점 앞으로 옮깁니다.", "두 수의 소수 부분이 같아 빼면 정수(또는 유한소수)만 남습니다.", "0.9̇ = 9/9 = 1입니다. 두 수 사이에 다른 수가 없기 때문입니다."],
    q: "0.12̇처럼 순환하지 않는 자리가 있을 때는 어떤 두 수를 빼야 할까요?",
    formula: "x = 0.ȧḃ ⇒ 100x − x = ab ⇒ x = ab/99",
    en: { title: "Repeating Decimals to Fractions", desc: "Shift and subtract to cut off the tail." },
    view: BOX,
    params: [
      { key: "r", label: "순환소수", type: "select", value: "b", options: Object.entries(REP).map(([k, v]) => [k, v.n]) },
      { key: "st", label: "단계", min: 0, max: 3, step: 1, value: 3 },
    ],
    anim: { key: "st", min: 0, max: 3, speed: 0.8, label: "한 단계씩" },
    calc(s) {
      const [I, pre, rep] = REP[s.r].v, a = pre.length, k = rep.length;
      const big = (n) => (I + "." + (pre + rep.repeat(8)).slice(0)).slice(0, 2 + n);
      const num = Number(String(I) + pre + rep) - Number(String(I) + pre), den = Number("9".repeat(k) + "0".repeat(a)), g0 = gcd(num, den);
      return { I, pre, rep, a, k, num, den, g: g0 };
    },
    draw(s, g) {
      const C = this.calc(s), digits = (C.pre + C.rep.repeat(10)).slice(0, 14);
      const shift = (n) => { const all = String(C.I) + digits; return `${all.slice(0, String(C.I).length + n)}.${all.slice(String(C.I).length + n)}…`; };
      const P = 10 ** (C.a + C.k), Q = 10 ** C.a;
      const rows = [[`${P === 1 ? "" : P}x`, shift(C.a + C.k)], [`${Q === 1 ? "" : Q}x`, shift(C.a)]];
      g.text([1, 9.8], `x = ${REP[s.r].n} = ${shift(0)}`, { anchor: "start", bold: true, size: 18, mono: true });
      if (s.st >= 1) g.text([1, 8.2], `${rows[0][0]} = ${rows[0][1]}`, { anchor: "start", size: 17, mono: true, color: "b", bold: true });
      if (s.st >= 2) { g.text([1, 7.0], `${rows[1][0]} = ${rows[1][1]}`, { anchor: "start", size: 17, mono: true, color: "a", bold: true }); g.seg([1, 6.4], [14.5, 6.4], { color: "ink", w: 2 }); g.text([0.6, 7.0], "−", { size: 18, bold: true }); }
      if (s.st >= 3) {
        g.text([1, 5.6], `${P - Q}x = ${C.num}`, { anchor: "start", size: 18, mono: true, bold: true, color: "c" });
        g.text([1, 4.2], `x = ${C.num}/${P - Q}${C.g > 1 ? ` = ${C.num / C.g}/${(P - Q) / C.g}` : ""}`, { anchor: "start", size: 20, bold: true, color: "e" });
        g.text([1, 2.8], "소수점 아래 꼬리가 똑같아서 빼면 사라져요", { anchor: "start", size: 14, color: "muted" });
      }
    },
    metrics(s) { const C = this.calc(s); return [["분수", `${C.num / C.g}/${C.den / C.g}`, "key"], ["순환마디", `${C.rep} (${C.k}자리)`], ["곱한 수", `10${supN(C.a + C.k)}${C.a ? `, 10${supN(C.a)}` : ""}`]]; },
    predict: [
      { q: "0.1̇2̇를 기약분수로 나타내면? (분수로)", set: (s) => Object.assign(s, { r: "b", st: 1 }), reveal: (s) => (s.st = 3), answer: () => 12 / 99, tol: 1e-6, show: () => "4/33", why: "100x − x = 12이므로 x = 12/99 = 4/33입니다." },
      { q: "0.9̇와 1의 관계는?", options: O("같다", "0.9̇가 조금 작다"), set: (s) => Object.assign(s, { r: "e", st: 1 }), reveal: (s) => (s.st = 3), answer: () => "a", why: "10x − x = 9이므로 9x = 9, x = 1입니다." },
    ],
  },

  // ───────── 2단원 식의 계산 ─────────
  {
    id: "m2-exp-law", grade: G2, unit: 2, lesson: "2.1", title: "지수법칙 — 칸을 세어 보면", type: "조작", time: "10분",
    tags: ["지수법칙", "거듭제곱", "단항식"], links: ["m2-algebra-tiles"],
    desc: "2ᵐ칸짜리 줄을 2ⁿ줄 쌓으면 2ᵐ × 2ⁿ칸, 곧 2ᵐ⁺ⁿ칸이 됩니다. 칸의 수를 직접 세며 aᵐ × aⁿ = aᵐ⁺ⁿ, (aᵐ)ⁿ = aᵐⁿ, aᵐ ÷ aⁿ = aᵐ⁻ⁿ을 확인합니다.",
    obs: ["곱할 때는 지수끼리 더합니다: 2를 m번, n번 곱하면 모두 m + n번 곱한 것입니다.", "(aᵐ)ⁿ은 aᵐ을 n번 곱한 것이므로 지수가 m × n입니다.", "나눌 때는 지수끼리 뺍니다."],
    q: "2³ × 3³과 6³이 같은 까닭을 칸으로 설명해 봅시다.",
    formula: "aᵐ × aⁿ = aᵐ⁺ⁿ, (aᵐ)ⁿ = aᵐⁿ, aᵐ ÷ aⁿ = aᵐ⁻ⁿ (m > n)",
    en: { title: "Laws of Exponents", desc: "Count the cells." },
    view: BOX,
    params: [
      { key: "mode", label: "법칙", type: "seg", value: "mul", options: [["mul", "aᵐ × aⁿ"], ["pow", "(aᵐ)ⁿ"], ["div", "aᵐ ÷ aⁿ"]] },
      { key: "m", label: "m", min: 1, max: 5, step: 1, value: 3 },
      { key: "n", label: "n", min: 1, max: 4, step: 1, value: 2 },
    ],
    onChange(s) { if (s.mode === "div" && s.n >= s.m) s.n = s.m - 1 || 1; if (s.mode === "pow" && s.m * s.n > 10) s.n = Math.floor(10 / s.m); },
    draw(s, g) {
      const W = 2 ** s.m, Hh = s.mode === "mul" ? 2 ** s.n : s.mode === "pow" ? 2 ** (s.m * s.n - s.m) : 1, cells = s.mode === "div" ? 2 ** (s.m - s.n) : W * Hh;
      const cols = s.mode === "div" ? 2 ** s.m : W, rows = s.mode === "div" ? 1 : Hh, d = Math.min(14.4 / cols, 8.2 / rows, 0.9);
      for (let i = 0; i < cols; i++) for (let j = 0; j < rows; j++) {
        const keep = s.mode !== "div" || i < cells, grp = s.mode === "div" ? Math.floor(i / cells) : j;
        g.poly([[0.8 + i * d, 9.6 - j * d], [0.8 + (i + 1) * d, 9.6 - j * d], [0.8 + (i + 1) * d, 9.6 - (j + 1) * d], [0.8 + i * d, 9.6 - (j + 1) * d]], { fill: keep ? (grp % 2 ? "b" : "c") : "muted", fo: keep ? 0.5 : 0.12, color: "paper", w: Math.min(1.2, d * 3) });
      }
      const txt = s.mode === "mul" ? `2${supN(s.m)} × 2${supN(s.n)} = ${W} × ${2 ** s.n} = ${cells} = 2${supN(s.m + s.n)}` : s.mode === "pow" ? `(2${supN(s.m)})${supN(s.n)} = ${W}${s.n > 1 ? ` × ${W}`.repeat(s.n - 1) : ""} = ${cells} = 2${supN(s.m * s.n)}` : `2${supN(s.m)} ÷ 2${supN(s.n)} = ${W} ÷ ${2 ** s.n} = ${cells} = 2${supN(s.m - s.n)}`;
      g.text([0.8, 1.2], txt, { anchor: "start", bold: true, size: 17 });
      g.text([0.8, 10.4], s.mode === "mul" ? `한 줄 2${supN(s.m)}칸 × ${2 ** s.n}줄` : s.mode === "pow" ? `2${supN(s.m)}칸짜리 묶음을 ${s.n}번 곱하기` : `2${supN(s.m)}칸을 ${2 ** s.n}묶음으로 나누면 한 묶음은?`, { anchor: "start", size: 13, color: "muted" });
    },
    metrics(s) { const e = s.mode === "mul" ? s.m + s.n : s.mode === "pow" ? s.m * s.n : s.m - s.n; return [["결과", `2${supN(e)} = ${2 ** e}`, "key"], ["지수", s.mode === "mul" ? `${s.m} + ${s.n}` : s.mode === "pow" ? `${s.m} × ${s.n}` : `${s.m} − ${s.n}`]]; },
    predict: [
      { q: "2³ × 2²은 2의 몇 제곱일까요?", set: (s) => Object.assign(s, { mode: "mul", m: 3, n: 1 }), reveal: (s) => (s.n = 2), answer: () => 5, why: "8칸 × 4줄 = 32칸 = 2⁵입니다. 지수끼리 더합니다." },
      { q: "(2²)³은 2의 몇 제곱일까요?", set: (s) => Object.assign(s, { mode: "pow", m: 2, n: 1 }), reveal: (s) => (s.n = 3), answer: () => 6, why: "2²을 세 번 곱하므로 지수는 2 × 3 = 6입니다." },
    ],
  },
  {
    id: "m2-algebra-tiles", grade: G2, unit: 2, lesson: "2.2", title: "대수 타일로 하는 다항식의 덧셈과 뺄셈", type: "조작", time: "12분",
    tags: ["다항식", "동류항", "대수 타일"], links: ["m2-exp-law", "m3-tile-factor"],
    desc: "긴 막대는 x, 작은 정사각형은 1, 파랑은 양수, 주황은 음수인 타일로 두 일차식을 늘어놓고 더하거나 뺍니다. 같은 모양의 파랑·주황 한 쌍은 0이라 지울 수 있고, 뺄셈은 빼는 식의 타일 색을 모두 뒤집어 더하는 것임을 확인합니다.",
    obs: ["동류항끼리만 모아 계산할 수 있습니다(막대는 막대끼리, 정사각형은 정사각형끼리).", "파랑과 주황 한 쌍은 합이 0이므로 지웁니다.", "A − B는 B의 모든 부호를 바꾸어 A에 더한 것입니다."],
    q: "(2x + 3) − (x − 4)를 타일로 할 때 주황 정사각형 4개는 어떻게 바뀔까요?",
    formula: "(ax + b) ± (cx + d) = (a ± c)x + (b ± d)",
    en: { title: "Algebra Tiles", desc: "Add and subtract polynomials, cancel zero pairs." },
    view: BOX,
    params: [
      { key: "op", label: "계산", type: "seg", value: "-", options: [["+", "더하기"], ["-", "빼기"]] },
      { key: "a", label: "첫째 식 x의 계수", min: -4, max: 4, step: 1, value: 2 },
      { key: "b", label: "첫째 식 상수항", min: -5, max: 5, step: 1, value: 3 },
      { key: "c", label: "둘째 식 x의 계수", min: -4, max: 4, step: 1, value: 1 },
      { key: "d", label: "둘째 식 상수항", min: -5, max: 5, step: 1, value: -4 },
      { key: "zero", label: "영 쌍 지우기", type: "check", value: false },
    ],
    draw(s, g) {
      const c2 = s.op === "+" ? s.c : -s.c, d2 = s.op === "+" ? s.d : -s.d;
      const row = (y, xs, ones, label, faded = 0) => {
        let x = 3.2; g.text([0.6, y - 0.5], label, { anchor: "start", bold: true, size: 13 });
        const bar = (v) => { g.poly([[x, y], [x + 0.42, y], [x + 0.42, y - 1.7], [x, y - 1.7]], { fill: v > 0 ? "b" : "a", fo: 0.55, color: v > 0 ? "b" : "a", w: 1.2 }); g.text([x + 0.21, y - 0.85], "x", { dy: 4, size: 11, bold: true }); x += 0.55; };
        const one = (v) => { g.poly([[x, y], [x + 0.42, y], [x + 0.42, y - 0.42], [x, y - 0.42]], { fill: v > 0 ? "b" : "a", fo: 0.55, color: v > 0 ? "b" : "a", w: 1.2 }); x += 0.55; };
        for (let i = 0; i < Math.abs(xs); i++) bar(Math.sign(xs));
        x += 0.4; for (let i = 0; i < Math.abs(ones); i++) one(Math.sign(ones));
      };
      row(10.2, s.a, s.b, `(${poly([[s.a, "x"]], s.b)})`);
      row(7.9, s.c, s.d, `${s.op === "+" ? "+" : "−"} (${poly([[s.c, "x"]], s.d)})`);
      if (s.op === "-") row(5.6, c2, d2, `→ + (${poly([[c2, "x"]], d2)})`);
      const X = s.a + c2, Y = s.b + d2;
      if (s.zero) row(3.1, X, Y, "= 정리하면");
      else {
        // 지우기 전: 모두 늘어놓기
        let x = 3.2; const y = 3.1; g.text([0.6, y - 0.5], "= 모으면", { anchor: "start", bold: true, size: 13 });
        [[s.a, "x"], [c2, "x"]].forEach(([v]) => { for (let i = 0; i < Math.abs(v); i++) { g.poly([[x, y], [x + 0.42, y], [x + 0.42, y - 1.7], [x, y - 1.7]], { fill: v > 0 ? "b" : "a", fo: 0.55, color: v > 0 ? "b" : "a", w: 1.2 }); x += 0.55; } });
        x += 0.4; [s.b, d2].forEach((v) => { for (let i = 0; i < Math.abs(v); i++) { g.poly([[x, y], [x + 0.42, y], [x + 0.42, y - 0.42], [x, y - 0.42]], { fill: v > 0 ? "b" : "a", fo: 0.55, color: v > 0 ? "b" : "a", w: 1.2 }); x += 0.55; } });
      }
      g.text([0.6, 0.6], `결과: ${poly([[X, "x"]], Y)}`, { anchor: "start", bold: true, size: 16, color: "c" });
    },
    metrics(s) { const c2 = s.op === "+" ? s.c : -s.c, d2 = s.op === "+" ? s.d : -s.d; return [["x의 계수", `${signed(s.a)} + ${signed(c2)} = ${fmt(s.a + c2)}`], ["상수항", `${signed(s.b)} + ${signed(d2)} = ${fmt(s.b + d2)}`], ["결과", poly([[s.a + c2, "x"]], s.b + d2), "key"]]; },
    predict: [
      { q: "(2x + 3) − (x − 4)를 간단히 하면 상수항은?", set: (s) => Object.assign(s, { op: "-", a: 2, b: 3, c: 1, d: -4, zero: false }), reveal: (s) => (s.zero = true), answer: () => 7, why: "−(x − 4) = −x + 4이므로 3 + 4 = 7, 결과는 x + 7입니다." },
      { q: "(3x − 2) + (−x + 5)의 x의 계수는?", set: (s) => Object.assign(s, { op: "+", a: 3, b: -2, c: -1, d: 5, zero: false }), reveal: (s) => (s.zero = true), answer: () => 2, why: "파랑 막대 3개와 주황 막대 1개에서 한 쌍을 지우면 2개가 남습니다." },
    ],
  },

  // ───────── 3단원 부등식과 연립방정식 ─────────
  {
    id: "m2-ineq-flip", grade: G2, unit: 3, lesson: "3.1", title: "일차부등식 — 음수를 곱하면 부등호가 돌아선다", type: "조작", time: "10분",
    tags: ["부등식의 성질", "일차부등식", "수직선"], links: ["m2-two-lines", "cm1-ineq-system"],
    desc: "수직선 위의 두 수 p < q에 같은 수 k를 곱해 봅니다. k가 양수면 순서가 그대로지만 음수면 수직선이 뒤집혀 kp > kq가 됩니다. 이 성질로 일차부등식 ax + b ○ c를 풀고 해를 수직선에 나타냅니다.",
    obs: ["양변에 같은 수를 더하거나 빼도 부등호의 방향은 그대로입니다.", "양변에 같은 양수를 곱하거나 나누어도 방향은 그대로입니다.", "양변에 같은 음수를 곱하거나 나누면 방향이 바뀝니다."],
    q: "−2x > 6의 양변을 −2로 나눌 때 방향을 바꾸지 않으면 어떤 잘못된 답이 나올까요? 수를 넣어 확인해 봅시다.",
    formula: "a < b, k < 0 ⇒ ka > kb",
    en: { title: "Linear Inequalities", desc: "Multiplying by a negative flips the sign." },
    view: { x: [-10.5, 10.5], y: [-3.4, 3.6] },
    params: [
      { key: "mode", label: "보기", type: "seg", value: "flip", options: [["flip", "음수 곱하기"], ["solve", "부등식 풀기"]] },
      { key: "p", label: "p", min: -4, max: 4, step: 1, value: -1, when: (s) => s.mode === "flip" },
      { key: "q", label: "q", min: -4, max: 4, step: 1, value: 3, when: (s) => s.mode === "flip" },
      { key: "k", label: "곱하는 수 k", min: -3, max: 3, step: 0.5, value: -2, when: (s) => s.mode === "flip" },
      { key: "a", label: "a (ax + b ○ c)", min: -4, max: 4, step: 1, value: -2, when: (s) => s.mode === "solve" },
      { key: "b", label: "b", min: -6, max: 6, step: 1, value: 1, when: (s) => s.mode === "solve" },
      { key: "op", label: "○", type: "select", value: ">", options: OPS, when: (s) => s.mode === "solve" },
      { key: "c", label: "c", min: -10, max: 10, step: 1, value: 7, when: (s) => s.mode === "solve" },
    ],
    onChange(s) { if (!s.a) s.a = 1; },
    axis(g, y) { g.seg([-10.2, y], [10.2, y], { color: "axis", w: 1.6 }); for (let x = -10; x <= 10; x += 2) { g.seg([x, y - 0.12], [x, y + 0.12], { color: "axis", w: 1.1 }); g.text([x, y], String(x).replace("-", "−"), { dy: 18, size: 11, color: "muted" }); } },
    draw(s, g) {
      if (s.mode === "flip") {
        this.axis(g, 1.6); this.axis(g, -1.6);
        g.point([s.p, 1.6], "p", { color: "a", dy: -12, dx: -4 }).point([s.q, 1.6], "q", { color: "b", dy: -12, dx: -4 });
        const kp = s.k * s.p, kq = s.k * s.q; g.point([kp, -1.6], "kp", { color: "a", dy: -12, dx: -8 }).point([kq, -1.6], "kq", { color: "b", dy: -12, dx: -8 });
        g.seg([s.p, 1.45], [kp, -1.45], { color: "a", w: 1.2, dash: "4 4" }).seg([s.q, 1.45], [kq, -1.45], { color: "b", w: 1.2, dash: "4 4" });
        const r1 = s.p < s.q ? "<" : s.p > s.q ? ">" : "=", r2 = kp < kq ? "<" : kp > kq ? ">" : "=";
        g.text([-10, 3.1], `p ${r1} q   →   ×${fmt(s.k)}   →   kp ${r2} kq`, { anchor: "start", bold: true, size: 16, color: r1 !== r2 && r1 !== "=" && r2 !== "=" ? "e" : "c" });
      } else {
        this.axis(g, 0);
        const op2 = s.a < 0 ? flip(s.op) : s.op, v = (s.c - s.b) / s.a, closed = op2.length > 1, right = op2[0] === ">";
        g.seg([v, 0.6], [right ? 10 : -10, 0.6], { color: "c", w: 5 }).vec([right ? 9.4 : -9.4, 0.6], [right ? 10 : -10, 0.6], { color: "c", w: 5 });
        g.point([v, 0.6], "", { color: "c", hollow: !closed, r: 6.5 });
        g.text([-10, 3.0], `${poly([[s.a, "x"]], s.b)} ${opS(s.op)} ${fmt(s.c)}`, { anchor: "start", bold: true, size: 16 });
        g.text([-10, 2.2], `${fmt(s.a)}x ${opS(s.op)} ${fmt(s.c - s.b)}  →  ÷(${fmt(s.a)})${s.a < 0 ? " 방향 바뀜!" : ""}  →  x ${opS(op2)} ${frac(v)}`, { anchor: "start", size: 14, color: s.a < 0 ? "e" : "muted", bold: true });
      }
    },
    metrics(s) {
      if (s.mode === "flip") { const kp = s.k * s.p, kq = s.k * s.q; return [["p, q", `${fmt(s.p)}, ${fmt(s.q)}`], ["kp, kq", `${fmt(kp)}, ${fmt(kq)}`], ["순서", s.k < 0 ? "뒤집힘" : s.k > 0 ? "그대로" : "둘 다 0", "key"]]; }
      const op2 = s.a < 0 ? flip(s.op) : s.op; return [["해", `x ${opS(op2)} ${frac((s.c - s.b) / s.a)}`, "key"], ["나눈 수", `${fmt(s.a)} (${s.a < 0 ? "음수 → 방향 바꿈" : "양수 → 그대로"})`]];
    },
    predict: [
      { q: "−2x + 1 > 7의 해는?", options: O("x < −3", "x > −3", "x < 3"), set: (s) => Object.assign(s, { mode: "solve", a: -2, b: 1, op: ">", c: 7 }), answer: () => "a", why: "−2x > 6의 양변을 −2로 나누면 방향이 바뀌어 x < −3입니다." },
      { q: "−1 < 3의 양변에 −2를 곱하면 2와 −6 가운데 어느 쪽이 클까요?", options: O("2", "−6"), set: (s) => Object.assign(s, { mode: "flip", p: -1, q: 3, k: 1 }), reveal: (s) => (s.k = -2), answer: () => "a", why: "(−1) × (−2) = 2, 3 × (−2) = −6이므로 2 > −6, 방향이 바뀌었습니다." },
    ],
  },
  {
    id: "m2-two-lines", grade: G2, unit: 3, lesson: "3.2", title: "연립방정식과 두 직선의 교점 — 해가 없거나 무수히 많을 때", type: "조작", time: "12분",
    tags: ["연립방정식", "직선", "교점"], links: ["m2-elimination", "m2-slope-intercept"],
    desc: "두 일차방정식을 직선으로 그리면 연립방정식의 해는 교점의 좌표입니다. 계수를 바꾸어 한 점에서 만날 때, 평행해서 만나지 않을 때(해가 없음), 완전히 겹칠 때(해가 무수히 많음)를 비교합니다.",
    obs: ["두 직선이 한 점에서 만나면 해가 한 쌍입니다.", "기울기가 같고 y절편이 다르면 평행하여 해가 없습니다.", "두 식이 같은 직선을 나타내면 해가 무수히 많습니다."],
    q: "x + y = 3, 2x + 2y = k가 해를 무수히 많이 가지려면 k는 얼마여야 할까요?",
    formula: "a/a′ = b/b′ ≠ c/c′ ⇒ 해가 없음, a/a′ = b/b′ = c/c′ ⇒ 해가 무수히 많음",
    en: { title: "Systems of Equations as Two Lines", desc: "One, none, or infinitely many solutions." },
    view: { x: [-6, 6], y: [-4.6, 4.6] },
    params: [
      { key: "a1", label: "첫째 식 a", min: -3, max: 3, step: 1, value: 1 }, { key: "b1", label: "첫째 식 b", min: -3, max: 3, step: 1, value: 1 }, { key: "c1", label: "첫째 식 c", min: -6, max: 6, step: 1, value: 3 },
      { key: "a2", label: "둘째 식 a′", min: -3, max: 3, step: 1, value: 2 }, { key: "b2", label: "둘째 식 b′", min: -3, max: 3, step: 1, value: -1 }, { key: "c2", label: "둘째 식 c′", min: -6, max: 6, step: 1, value: 0 },
    ],
    onChange(s) { if (!s.a1 && !s.b1) s.b1 = 1; if (!s.a2 && !s.b2) s.b2 = 1; },
    sol(s) { const D = s.a1 * s.b2 - s.a2 * s.b1; if (Math.abs(D) > 1e-9) return { k: 1, p: [(s.c1 * s.b2 - s.c2 * s.b1) / D, (s.a1 * s.c2 - s.a2 * s.c1) / D] }; const same = Math.abs(s.a1 * s.c2 - s.a2 * s.c1) < 1e-9 && Math.abs(s.b1 * s.c2 - s.b2 * s.c1) < 1e-9; return { k: same ? Infinity : 0 }; },
    draw(s, g) {
      const R = this.sol(s);
      g.grid();
      g.lineABC(s.a2, s.b2, -s.c2, { color: "b", w: R.k === Infinity ? 8 : 3, opacity: R.k === Infinity ? 0.4 : 1 });
      g.lineABC(s.a1, s.b1, -s.c1, { color: "a", w: 3 });
      if (R.k === 1) g.point(R.p, `(${frac(R.p[0])}, ${frac(R.p[1])})`, { color: "ink" });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], `주황: ${lineStr(s.a1, s.b1, s.c1)}`, { anchor: "start", bold: true, color: "a" }).text([g.xr[0] + 0.3, g.yr[1] - 1.3], `파랑: ${lineStr(s.a2, s.b2, s.c2)}`, { anchor: "start", bold: true, color: "b" });
    },
    metrics(s) { const R = this.sol(s); return [["해", R.k === 1 ? `x = ${frac(R.p[0])}, y = ${frac(R.p[1])}` : R.k ? "해가 무수히 많다" : "해가 없다", "key"], ["두 직선", R.k === 1 ? "한 점에서 만남" : R.k ? "일치" : "평행"]]; },
    predict: [
      { q: "x + y = 3, 2x − y = 0의 해에서 x의 값은?", set: (s) => Object.assign(s, { a1: 1, b1: 1, c1: 3, a2: 2, b2: -1, c2: 0 }), answer: () => 1, why: "두 식을 더하면 3x = 3, x = 1이고 y = 2입니다. 두 직선의 교점이 (1, 2)입니다." },
      { q: "x + y = 3, 2x + 2y = 2의 해는?", options: O("해가 없다", "한 쌍이다", "무수히 많다"), set: (s) => Object.assign(s, { a1: 1, b1: 1, c1: 3, a2: 2, b2: 2, c2: 2 }), answer: () => "a", why: "둘째 식은 x + y = 1이라 첫째 식과 평행합니다." },
    ],
  },
  {
    id: "m2-elimination", grade: G2, unit: 3, lesson: "3.3", title: "가감법 — 두 식을 섞은 직선은 교점을 지난다", type: "조작", time: "12분",
    tags: ["가감법", "연립방정식", "소거"], links: ["m2-two-lines"],
    desc: "(첫째 식) + k × (둘째 식)이 나타내는 직선은 k가 무엇이든 두 직선의 교점을 지나며 그 점을 중심으로 돕니다. k를 알맞게 고르면 y가 사라져 세로 직선 x = p가, 또는 x가 사라져 가로 직선 y = q가 되는데, 이것이 가감법으로 한 문자를 없애는 과정입니다.",
    obs: ["교점의 좌표는 두 식을 모두 만족하므로 섞은 식도 만족합니다.", "y의 계수가 0이 되도록 k를 고르면 x = p, 곧 해의 x좌표만 남습니다.", "x의 계수를 0으로 만들면 해의 y좌표를 얻습니다."],
    q: "2x + 3y = 12, x − y = 1에서 y를 없애려면 둘째 식에 몇을 곱해 더해야 할까요?",
    formula: "(a₁x + b₁y − c₁) + k(a₂x + b₂y − c₂) = 0",
    en: { title: "Elimination", desc: "Combined equations pivot about the solution." },
    view: { x: [-6, 6], y: [-4.6, 4.6] },
    params: [{ key: "k", label: "둘째 식에 곱할 수 k", min: -4, max: 4, step: 0.5, value: 0.5 }],
    buttons: [["ky", "y 없애기 (k = 3)"], ["kx", "x 없애기 (k = −2)"]],
    onDo(a, s) { s.k = a === "ky" ? 3 : -2; },
    anim: { key: "k", min: -4, max: 4, speed: 1.5, loop: "bounce", label: "k 바꾸기" },
    E1: [2, 3, 12], E2: [1, -1, 1],
    draw(s, g) {
      const [a1, b1, c1] = this.E1, [a2, b2, c2] = this.E2, A = a1 + s.k * a2, B = b1 + s.k * b2, C = c1 + s.k * c2;
      g.grid();
      g.lineABC(a1, b1, -c1, { color: "a", w: 2.4 }).lineABC(a2, b2, -c2, { color: "b", w: 2.4 });
      if (Math.abs(A) > 1e-9 || Math.abs(B) > 1e-9) g.lineABC(A, B, -C, { color: "c", w: 3.4, dash: Math.abs(B) < 1e-9 || Math.abs(A) < 1e-9 ? false : "8 5" });
      g.point([3, 2], "(3, 2)", { color: "ink" });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], "주황: 2x + 3y = 12", { anchor: "start", bold: true, color: "a" }).text([g.xr[0] + 0.3, g.yr[1] - 1.3], "파랑: x − y = 1", { anchor: "start", bold: true, color: "b" }).text([g.xr[0] + 0.3, g.yr[1] - 2.1], `초록: ${lineStr(A, B, C)}`, { anchor: "start", bold: true, color: "c" });
    },
    metrics(s) { const [a1, b1, c1] = this.E1, [a2, b2, c2] = this.E2, A = a1 + s.k * a2, B = b1 + s.k * b2, C = c1 + s.k * c2; return [["섞은 식", lineStr(A, B, C)], ["사라진 문자", Math.abs(B) < 1e-9 ? `y → x = ${frac(C / A)}` : Math.abs(A) < 1e-9 ? `x → y = ${frac(C / B)}` : "없음", "key"]]; },
    predict: [
      { q: "y를 없애려면 둘째 식 x − y = 1에 몇을 곱해 첫째 식에 더해야 할까요?", set: (s) => (s.k = 0.5), reveal: (s) => (s.k = 3), answer: () => 3, why: "3y + k(−y) = 0이 되려면 k = 3입니다. 그러면 5x = 15, x = 3입니다." },
      { q: "k를 바꾸어도 초록 직선이 항상 지나는 점의 y좌표는?", set: (s) => (s.k = -1), reveal: (s) => (s.k = 2), answer: () => 2, why: "두 식을 모두 만족하는 해 (3, 2)는 섞은 식도 만족합니다." },
    ],
  },

  // ───────── 4단원 일차함수와 그래프 ─────────
  {
    id: "m2-slope-intercept", grade: G2, unit: 4, lesson: "4.1", title: "기울기와 y절편 — 계단으로 보는 증가량", type: "조작", time: "10분",
    tags: ["일차함수", "기울기", "y절편"], links: ["m2-linear-eq", "m2-two-lines"],
    desc: "y = ax + b의 그래프에 x가 1씩 늘 때 y가 a씩 느는 계단을 그려 기울기를 봅니다. a와 b를 바꾸며 기울기는 기울어진 정도를, y절편은 y축과 만나는 높이를 정한다는 것과 x절편 −b/a의 위치를 확인합니다.",
    obs: ["(y의 증가량) ÷ (x의 증가량) = a로 일정합니다.", "a > 0이면 오른쪽 위로, a < 0이면 오른쪽 아래로 향합니다.", "b만 바꾸면 그래프가 y축 방향으로 평행이동합니다."],
    q: "기울기가 같은 두 일차함수의 그래프는 어떤 관계일까요?",
    formula: "기울기 = (y의 증가량)/(x의 증가량) = a, y절편 = b, x절편 = −b/a",
    en: { title: "Slope and Intercept", desc: "Staircases show the rate of change." },
    view: { x: [-6, 6], y: [-4.6, 4.6] },
    params: [
      { key: "a", label: "기울기 a", min: -3, max: 3, step: 0.5, value: 1.5 },
      { key: "b", label: "y절편 b", min: -4, max: 4, step: 0.5, value: -1 },
      { key: "dx", label: "x의 증가량", min: 1, max: 3, step: 1, value: 2 },
    ],
    anim: { key: "b", min: -4, max: 4, speed: 1.5, loop: "bounce", label: "평행이동" },
    draw(s, g) {
      const f = (x) => s.a * x + s.b;
      g.grid();
      g.fx(f, { color: "b", w: 3 });
      for (let x = -4; x + s.dx <= 4.01; x += s.dx) { if (Math.abs(f(x)) > 4.4 || Math.abs(f(x + s.dx)) > 4.4) continue; g.seg([x, f(x)], [x + s.dx, f(x)], { color: "a", w: 2 }).seg([x + s.dx, f(x)], [x + s.dx, f(x + s.dx)], { color: "c", w: 2 }); }
      const x0 = 0; g.text([x0 + s.dx / 2, f(x0)], `+${s.dx}`, { dy: f(x0) < f(x0 + s.dx) ? 16 : -6, size: 12, bold: true, color: "a" }).text([x0 + s.dx, (f(x0) + f(x0 + s.dx)) / 2], `${s.a * s.dx >= 0 ? "+" : "−"}${fmt(Math.abs(s.a * s.dx))}`, { dx: 6, anchor: "start", size: 12, bold: true, color: "c" });
      g.point([0, s.b], "y절편", { color: "e" });
      if (s.a) g.point([-s.b / s.a, 0], "x절편", { color: "d", dy: 20 });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], `y = ${poly([[s.a, "x"]], s.b)}`, { anchor: "start", bold: true, color: "b", size: 16 });
    },
    metrics(s) { return [["기울기", `${fmt(s.a * s.dx)} ÷ ${s.dx} = ${fmt(s.a)}`, "key"], ["y절편", fmt(s.b)], ["x절편", s.a ? frac(-s.b / s.a) : "없음"]]; },
    predict: [
      { q: "y = 2x − 4의 x절편은?", set: (s) => Object.assign(s, { a: 1, b: -1 }), reveal: (s) => Object.assign(s, { a: 2, b: -4 }), answer: () => 2, why: "y = 0을 넣으면 2x = 4, x = 2입니다." },
      { q: "y = −1.5x + 1에서 x가 2만큼 늘면 y는 얼마만큼 변할까요?", set: (s) => Object.assign(s, { a: -1.5, b: 1, dx: 1 }), reveal: (s) => (s.dx = 2), answer: () => -3, why: "기울기 × x의 증가량 = −1.5 × 2 = −3, 3만큼 줄어듭니다." },
    ],
  },
  {
    id: "m2-linear-eq", grade: G2, unit: 4, lesson: "4.2", title: "일차함수와 일차방정식 — x = p, y = q 꼴의 직선", type: "조작", time: "10분",
    tags: ["일차방정식의 그래프", "일차함수", "좌표축에 평행한 직선"], links: ["m2-slope-intercept"],
    desc: "일차방정식 ax + by + c = 0의 해를 좌표평면에 모두 찍으면 직선이 됩니다. b ≠ 0이면 일차함수 y = −(a/b)x − c/b의 그래프이고, a = 0이면 x축에 평행한 직선 y = q, b = 0이면 y축에 평행한 직선 x = p가 됩니다. x = p는 함수가 아님도 확인합니다.",
    obs: ["b ≠ 0이면 y에 대하여 풀어 기울기 −a/b, y절편 −c/b인 일차함수가 됩니다.", "a = 0이면 y = −c/b로 일정한 가로 직선입니다.", "b = 0이면 x = −c/a인 세로 직선이고, 하나의 x에 y가 무수히 많아 함수가 아닙니다."],
    q: "x = 3과 y = −2의 그래프와 두 좌표축으로 둘러싸인 도형의 넓이를 구해 봅시다.",
    formula: "ax + by + c = 0 (b ≠ 0) ⇔ y = −(a/b)x − c/b",
    en: { title: "Linear Equations in Two Variables", desc: "Including lines x = p and y = q." },
    view: { x: [-6, 6], y: [-4.6, 4.6] },
    params: [
      { key: "a", label: "a", min: -3, max: 3, step: 1, value: 2 },
      { key: "b", label: "b", min: -3, max: 3, step: 1, value: -1 },
      { key: "c", label: "c", min: -6, max: 6, step: 1, value: 2 },
    ],
    onChange(s) { if (!s.a && !s.b) s.a = 1; },
    draw(s, g) {
      g.grid();
      g.lineABC(s.a, s.b, s.c, { color: "b", w: 3.2 });
      for (let x = -5; x <= 5; x++) for (let y = -4; y <= 4; y++) if (s.a * x + s.b * y + s.c === 0) g.point([x, y], "", { color: "a", r: 4.5 });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], `${poly([[s.a, "x"], [s.b, "y"]], s.c)} = 0`, { anchor: "start", bold: true, color: "b", size: 16 });
    },
    metrics(s) {
      const kind = !s.b ? `x = ${frac(-s.c / s.a)} (y축에 평행)` : !s.a ? `y = ${frac(-s.c / s.b)} (x축에 평행)` : `y = ${poly([[-s.a / s.b, "x"]], -s.c / s.b)}`;
      return [["직선", kind, "key"], ["함수인가?", s.b ? "예 — x마다 y가 하나" : "아니요 — 한 x에 y가 무수히 많음"]];
    },
    predict: [
      { q: "2x − 6 = 0의 그래프는 어떤 직선일까요?", options: O("y축에 평행한 직선 x = 3", "x축에 평행한 직선 y = 3", "원점을 지나는 직선"), set: (s) => Object.assign(s, { a: 2, b: -1, c: -6 }), reveal: (s) => (s.b = 0), answer: () => "a", why: "y가 없으므로 x = 3인 모든 점, 곧 세로 직선입니다." },
      { q: "2x − y + 2 = 0의 기울기는?", set: (s) => Object.assign(s, { a: 2, b: -1, c: 2 }), answer: () => 2, why: "y에 대하여 풀면 y = 2x + 2입니다." },
    ],
  },
  {
    id: "m2-plans", grade: G2, unit: 4, lesson: "4.3", title: "두 요금제 비교 — 그래프가 만나는 곳이 갈림길", type: "조작", time: "12분",
    tags: ["일차함수의 활용", "그래프", "교점"], links: ["m2-two-lines", "m2-slope-intercept"],
    desc: "기본요금과 1분당 요금이 다른 두 요금제를 일차함수로 나타내고 그래프로 비교합니다. 두 직선이 만나는 시간보다 적게 쓰면 기본요금이 싼 쪽이, 많이 쓰면 분당 요금이 싼 쪽이 유리함을 확인합니다.",
    obs: ["요금 = 기본요금 + 분당 요금 × 시간이므로 일차함수입니다.", "y절편은 기본요금, 기울기는 분당 요금입니다.", "두 그래프의 교점에서 두 요금이 같아집니다."],
    q: "분당 요금이 같은 두 요금제는 어느 쪽이 유리할까요? 그래프는 어떤 모양일까요?",
    formula: "요금 y = (기본요금) + (분당 요금) × x",
    en: { title: "Comparing Two Phone Plans", desc: "Where two lines cross." },
    view: { x: [-1.2, 10.8], y: [-0.9, 10.6] },
    params: [
      { key: "a0", label: "A 기본요금 (원)", min: 0, max: 30000, step: 1000, value: 10000 }, { key: "a1", label: "A 1분당 (원)", min: 0, max: 200, step: 10, value: 100 },
      { key: "b0", label: "B 기본요금 (원)", min: 0, max: 30000, step: 1000, value: 20000 }, { key: "b1", label: "B 1분당 (원)", min: 0, max: 200, step: 10, value: 50 },
      { key: "t", label: "한 달 통화 시간 (분)", min: 0, max: 400, step: 10, value: 120 },
    ],
    anim: { key: "t", min: 0, max: 400, speed: 60, loop: "bounce", label: "통화 시간 늘리기" },
    draw(s, g) {
      const A = (x) => s.a0 + s.a1 * x, B = (x) => s.b0 + s.b1 * x, P = (x, y) => [x / 40, y / 4000];
      for (let x = 0; x <= 400; x += 100) { g.seg(P(x, 0), P(x, 40000), { color: "grid", w: 1 }); g.text(P(x, 0), String(x), { dy: 16, size: 11, color: "muted" }); }
      for (let y = 0; y <= 40000; y += 10000) { g.seg(P(0, y), P(400, y), { color: "grid", w: 1 }); g.text(P(0, y), y ? `${y / 10000}만` : "0", { dx: -6, anchor: "end", dy: 4, size: 11, color: "muted" }); }
      g.seg(P(0, 0), P(410, 0), { color: "axis", w: 1.6 }).seg(P(0, 0), P(0, 41000), { color: "axis", w: 1.6 });
      g.text(P(400, 0), "분", { dy: 30, size: 12, color: "muted" });
      g.seg(P(0, A(0)), P(400, A(400)), { color: "a", w: 3 }).seg(P(0, B(0)), P(400, B(400)), { color: "b", w: 3 });
      if (s.a1 !== s.b1) { const x = (s.b0 - s.a0) / (s.a1 - s.b1); if (x > 0 && x < 400) g.point(P(x, A(x)), `${fmt(x, 1)}분`, { color: "ink" }); }
      g.seg(P(s.t, 0), P(s.t, Math.max(A(s.t), B(s.t))), { color: "muted", w: 1.2, dash: "4 4" });
      g.point(P(s.t, A(s.t)), "", { color: "a" }).point(P(s.t, B(s.t)), "", { color: "b" });
      g.text(P(10, 39000), `주황 A: y = ${s.a0} + ${s.a1}x`, { anchor: "start", bold: true, color: "a" }).text(P(10, 35500), `파랑 B: y = ${s.b0} + ${s.b1}x`, { anchor: "start", bold: true, color: "b" });
    },
    metrics(s) { const A = s.a0 + s.a1 * s.t, B = s.b0 + s.b1 * s.t, x = s.a1 !== s.b1 ? (s.b0 - s.a0) / (s.a1 - s.b1) : null; return [[`${s.t}분일 때 A, B`, `${A.toLocaleString()}원, ${B.toLocaleString()}원`], ["더 싼 요금제", A < B ? "A" : B < A ? "B" : "같음", "key"], ["요금이 같아지는 시간", x != null && x >= 0 ? `${fmt(x, 1)}분` : "없음"]]; },
    predict: [
      { q: "A(10000 + 100x), B(20000 + 50x)의 요금이 같아지는 통화 시간은 몇 분?", set: (s) => Object.assign(s, { a0: 10000, a1: 100, b0: 20000, b1: 50, t: 50 }), reveal: (s) => (s.t = 200), answer: () => 200, why: "10000 + 100x = 20000 + 50x에서 50x = 10000, x = 200입니다." },
      { q: "한 달에 300분 통화한다면 어느 요금제가 유리할까요?", options: O("B", "A", "같다"), set: (s) => Object.assign(s, { a0: 10000, a1: 100, b0: 20000, b1: 50, t: 100 }), reveal: (s) => (s.t = 300), answer: () => "a", why: "A는 40000원, B는 35000원입니다. 200분보다 많이 쓰면 분당 요금이 싼 B가 유리합니다." },
    ],
  },
];
