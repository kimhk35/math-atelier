// 2026-10 추가 실험 11개 — 실험이 없던 성취기준 채우기
// [9수01-09] 실수의 대소, [9수02-14] 함수의 개념, [9수04-04] 통계적 탐구, [12대수01-02] 지수의 확장, [12대수01-03] 지수법칙,
// [12직수02-03] 대응 관계 표, [12직수02-04] 증가·감소·주기 그래프, [12직수04-01] 직무 경우의 수, [12수문01-03] 문학, [12수문01-04] 영화, [12수문04-03] 사막화
import { fmt } from "./hs-core.js";

const EN = () => typeof document !== "undefined" && document.documentElement.lang === "en";
const T = (ko, en) => (EN() ? en : ko);
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
const RNG = (seed) => { let x = (Math.abs(seed | 0) * 7919 + 104729) % 2147483647 || 1; return () => (x = (x * 16807) % 2147483647) / 2147483647; };
// 가로·세로 단위가 크게 다른 그래프용 축: 자료값 (u, v) → 그림 좌표 (X(u), Y(v)), 눈금 글자는 자료값 그대로
function axes(g, o) {
  const { X, Y, xs, ys, xName, yName, x0 = xs[0], x1 = xs[xs.length - 1], y0 = ys[0], y1 = ys[ys.length - 1] } = o;
  for (const u of xs) { g.seg([X(u), Y(y0)], [X(u), Y(y1)], { color: "grid", w: 1, layer: "fill" }); g.text([X(u), Y(y0)], o.xl ? o.xl(u) : fmt(u), { size: 11, color: "muted", dy: 16 }); }
  for (const v of ys) { g.seg([X(x0), Y(v)], [X(x1), Y(v)], { color: "grid", w: 1, layer: "fill" }); g.text([X(x0), Y(v)], o.yl ? o.yl(v) : fmt(v), { size: 11, color: "muted", dx: -6, dy: 4, anchor: "end" }); }
  g.seg([X(x0), Y(y0)], [X(x1), Y(y0)], { color: "axis", w: 1.6 }); g.seg([X(x0), Y(y0)], [X(x0), Y(y1)], { color: "axis", w: 1.6 });
  if (xName) g.text([X(x1), Y(y0)], xName, { size: 12, color: "muted", dy: 30, anchor: "end" });
  if (yName) g.text([X(x0), Y(y1)], yName, { size: 12, color: "muted", dy: -10, anchor: "start" });
}
const range = (a, b, st) => { const out = []; for (let v = a; v <= b + 1e-9; v += st) out.push(+v.toFixed(6)); return out; };

// ── 실수의 대소: 두 수 ──
const PAIRS = { a: [["√2", Math.SQRT2], ["1.41", 1.41]], b: [["√2", Math.SQRT2], ["7/5", 1.4]], c: [["√3", Math.sqrt(3)], ["1.732", 1.732]], d: [["π", Math.PI], ["22/7", 22 / 7]], e: [["√5 − 1", Math.sqrt(5) - 1], ["1.24", 1.24]] };
const firstDiff = (x, y) => { const a = x.toFixed(12), b = y.toFixed(12); if (a.split(".")[0] !== b.split(".")[0]) return 0; const da = a.split(".")[1], db = b.split(".")[1]; for (let i = 0; i < 12; i++) if (da[i] !== db[i]) return i + 1; return 13; };

// ── 함수 상자: 규칙마다 x에 대응하는 y들 ──
const RULES = {
  a: (x) => [2 * x + 1], b: (x) => [x * x], c: (x) => [range(1, x, 1).filter((d) => x % d === 0).length],
  d: (x) => range(x, 6, x), e: (x) => range(1, x - 1, 1),
};

// ── 통계 탐구: 질문별 자료 ──
const QS = { a: { ko: "하루 수면 시간", en: "Hours of sleep a day", unit: ["시간", "h"], m: 7.2, sd: 1, lo: 4, hi: 10, w: 1 },
  b: { ko: "등교에 걸리는 시간", en: "Time to get to school", unit: ["분", "min"], m: 16, sd: 7, lo: 0, hi: 40, w: 5 },
  c: { ko: "하루 휴대폰 사용 시간", en: "Phone use a day", unit: ["분", "min"], m: 150, sd: 60, lo: 0, hi: 330, w: 30 } };
function survey(s) {
  const q = QS[s.q], r = RNG(s.seed * 31 + s.q.charCodeAt(0)), out = [];
  for (let i = 0; i < s.n; i++) { let z = 0; for (let k = 0; k < 6; k++) z += r(); z = (z - 3) / Math.sqrt(0.5); let v = q.m + q.sd * z; if (s.q === "c" && r() < 0.08) v += 120; out.push(Math.max(q.lo, Math.min(q.hi - 1e-6, q.w === 1 ? Math.round(v * 2) / 2 : Math.round(v)))); }
  return out;
}

// ── 사막화 모형: 해마다 식생 비율 v (0~1). 식생이 문턱(20%)보다 적으면 흙이 말라 자라는 힘이 음수가 된다(알리 효과) ──
function desert(s, plant = s.p) {
  const out = [s.v0]; let v = s.v0;
  for (let y = 0; y < 50; y++) { v = v + 2 * v * (1 - v) * (v - 0.2) - s.g * v + plant; v = Math.max(0, Math.min(1, v)); out.push(v); }
  return out;
}

// ── 주기 그래프 ──
const TIDE = (t) => 3 + 2.5 * Math.cos((2 * Math.PI * (t - 2)) / 12.42), TEMP = (t) => 15 + 7 * Math.sin((2 * Math.PI * (t - 9)) / 24);

export default [
  // ═════════ 중3 Ⅰ 실수와 그 계산 ═════════
  {
    id: "m3-real-zoom", grade: 3, unit: 1, lesson: "1.3", title: "수직선 돋보기 — √2와 1.41은 어디서 갈라질까", type: "조작", time: "10분",
    tags: ["실수의 대소", "무리수", "수직선"], links: ["m3-sqrt-line", "m3-dense-line"],
    desc: "가까이 붙어 있는 두 실수를 수직선에 찍고, 돋보기 배율을 10배씩 올려 봅니다. 소수점 아래 같은 자리까지는 겹쳐 보이다가, 처음으로 다른 숫자가 나오는 자리에서 두 점이 갈라집니다. 그 자리의 숫자를 비교하면 두 실수의 대소를 정할 수 있습니다.",
    obs: ["모든 실수는 수직선 위의 한 점에 대응하므로 크기를 비교할 수 있습니다.", "소수로 나타냈을 때 처음으로 다른 자리의 숫자가 큰 쪽이 더 큰 수입니다.", "무리수는 소수점 아래가 끝없이 이어지므로 필요한 자리까지 어림해 비교합니다."],
    q: "√2와 1.41 중 어느 쪽이 큰지 설명하고, 둘 사이에 있는 수를 하나 찾아봅시다.",
    formula: "a − b > 0 ⇔ a > b ⇔ 수직선에서 a가 b의 오른쪽",
    view: { x: [-6.2, 6.2], y: [-3.4, 4.6] },
    params: [
      { key: "pair", label: "비교할 두 수", type: "select", value: "a", options: [["a", "√2와 1.41"], ["b", "√2와 7/5"], ["c", "√3과 1.732"], ["d", "π와 22/7"], ["e", "√5 − 1과 1.24"]] },
      { key: "k", label: "돋보기 배율 (10의 거듭제곱)", min: 0, max: 5, step: 1, value: 0 },
    ],
    draw(s, g) {
      const [[na, a], [nb, b]] = PAIRS[s.pair], c = (a + b) / 2, w = 4 / 10 ** s.k, X = (v) => ((v - c) / w) * 10, st = w / 10;
      g.seg([-5.6, 0], [5.6, 0], { color: "axis", w: 1.8 });
      for (let i = Math.ceil((c - w / 2) / st); i * st <= c + w / 2 + 1e-12; i++) {
        const v = i * st, x = X(v); if (Math.abs(x) > 5.5) continue;
        g.seg([x, -0.18], [x, 0.18], { color: "axis", w: 1.1 });
        if (i % 2 === 0) g.text([x, 0], v.toFixed(s.k + 1), { dy: 20, size: 11, color: "muted" });
      }
      const xa = X(a), xb = X(b), near = Math.abs(xa - xb) < 0.25;
      g.point([xa, 0], "", { color: "a", r: 6.5 }).point([xb, 0], "", { color: "b", r: 6.5 });
      g.text([xa, 0], na, { dy: -18, bold: true, color: "a", size: 15 }); g.text([xb, 0], nb, { dy: near ? -40 : -18, bold: true, color: "b", size: 15 });
      g.text([0, 3.6], T(`배율 ×${10 ** s.k} — 한 칸 = ${st.toPrecision(1)}`, `Zoom ×${10 ** s.k} — one tick = ${st.toPrecision(1)}`), { bold: true, size: 15 });
      g.text([0, 2.6], near ? T("아직 겹쳐 보여요. 배율을 올려 보세요.", "They still overlap. Zoom in further.") : T(`갈라졌어요: ${a > b ? na : nb}이(가) 오른쪽`, `Separated: ${a > b ? na : nb} is on the right`), { size: 14, color: near ? "muted" : "e" });
      g.text([0, -2.4], `${na} = ${a.toFixed(7)}…   ${nb} = ${Number.isInteger(b * 1e5) ? String(b) : b.toFixed(7) + "…"}`, { size: 13, mono: true });
    },
    metrics(s) { const [[na, a], [nb, b]] = PAIRS[s.pair], d = firstDiff(a, b); return [[T("더 큰 수", "Larger"), a > b ? na : nb, "key"], [T("처음 달라지는 자리", "First different digit"), T(`소수 ${d}째 자리`, `decimal place ${d}`)], [T("차", "Difference"), Math.abs(a - b).toPrecision(3)]]; },
    predict: [
      { q: "√2와 1.41 중 큰 수는?", options: O("√2", "1.41"), set: (s) => Object.assign(s, { pair: "a", k: 0 }), reveal: (s) => (s.k = 3), answer: () => "a", why: "√2 = 1.41421…이므로 소수 셋째 자리에서 4 > 0, √2가 더 큽니다." },
      { q: "√3 = 1.7320508…과 1.732는 소수 몇째 자리에서 처음 달라질까요?", set: (s) => Object.assign(s, { pair: "c", k: 0 }), reveal: (s) => (s.k = 5), answer: () => 5, why: "1.73205…와 1.73200은 소수 넷째 자리까지 같고 다섯째 자리에서 5와 0으로 갈라집니다." },
    ],
  },
  // ═════════ 중2 Ⅳ 일차함수와 그래프 ═════════
  {
    id: "m2-function-box", grade: 2, unit: 4, lesson: "4.1", title: "함수 상자 — x 하나에 y 하나씩일 때만 함수", type: "조작", time: "10분",
    tags: ["함수", "함숫값", "대응"], links: ["m2-rate-constant", "c2-vertical-test"],
    desc: "여러 규칙의 상자에 x = 1, 2, …, 6을 넣고 나오는 y를 화살표로 이어 봅니다. x 하나에 y가 꼭 하나씩 정해질 때만 함수입니다. y가 둘 이상 나오거나 하나도 나오지 않는 x가 있으면 함수가 아님을 확인하고, 함수일 때 함숫값 f(x)를 읽습니다.",
    obs: ["x의 값이 하나 정해지면 y의 값이 오직 하나로 정해질 때, y는 x의 함수입니다.", "y가 두 개 이상 나오는 x가 하나라도 있으면 함수가 아닙니다.", "대응하는 y가 없는 x가 있어도 함수가 아닙니다."],
    q: "‘x의 배수 y’는 왜 함수가 아닐까요? 함수가 되도록 규칙을 바꿔 봅시다.",
    formula: "y = f(x): x 하나 → y 하나",
    view: { x: [0, 12], y: [-0.6, 7.65] },
    params: [
      { key: "rule", label: "상자의 규칙", type: "select", value: "a", options: [["a", "y = 2x + 1"], ["b", "y = x²"], ["c", "y = (x의 약수의 개수)"], ["d", "y는 x의 배수 (6 이하)"], ["e", "y는 x보다 작은 자연수"]] },
      { key: "x", label: "넣는 수 x", min: 1, max: 6, step: 1, value: 3 },
    ],
    draw(s, g) {
      const f = RULES[s.rule], Ys = [...new Set(range(1, 6, 1).flatMap(f))].sort((p, q) => p - q);
      const yX = (i) => [9.6, 6.8 - (i * 6.2) / Math.max(1, Ys.length - 1)], xX = (x) => [2.4, 7 - (x - 1) * 1.2];
      rect(g, 1.5, 0.3, 1.8, 7.3, { fill: "a", fo: 0.06, color: "a", w: 1.4 }); rect(g, 8.6, 0.0, 2.0, 7.6, { fill: "b", fo: 0.06, color: "b", w: 1.4 });
      g.text([2.4, 7.6], "X", { dy: -10, bold: true, color: "a" }); g.text([9.6, 7.6], "Y", { dy: -10, bold: true, color: "b" });
      Ys.forEach((y, i) => g.point(yX(i), "", { color: "b", r: 4.5 }).text(yX(i), String(y), { dx: 16, anchor: "start", size: 13, bold: true, color: "b" }));
      for (let x = 1; x <= 6; x++) {
        const on = x === s.x, ys = f(x);
        g.point(xX(x), "", { color: on ? "e" : "a", r: on ? 6.5 : 4.5 }); g.text(xX(x), String(x), { dx: -16, anchor: "end", size: 13, bold: true, color: on ? "e" : "a" });
        for (const y of ys) g.vec([xX(x)[0] + 0.25, xX(x)[1]], [yX(Ys.indexOf(y))[0] - 0.3, yX(Ys.indexOf(y))[1]], { color: on ? "e" : "muted", w: on ? 2.6 : 1.1, opacity: on ? 1 : 0.55 });
        if (!ys.length) g.text([xX(x)[0] + 1.6, xX(x)[1]], T("짝 없음", "no y"), { size: 12, color: on ? "e" : "muted", anchor: "start" });
      }
      const ys = f(s.x), isF = range(1, 6, 1).every((x) => f(x).length === 1);
      g.text([6, -0.2], ys.length === 1 ? `x = ${s.x} → y = ${ys[0]}` : ys.length ? T(`x = ${s.x} → y가 ${ys.length}개: ${ys.join(", ")}`, `x = ${s.x} → ${ys.length} values: ${ys.join(", ")}`) : T(`x = ${s.x} → 대응하는 y가 없음`, `x = ${s.x} → no y`), { bold: true, size: 15, color: ys.length === 1 ? "ink" : "e" });
      g.text([6, 7.3], isF ? T("함수입니다", "This is a function") : T("함수가 아닙니다", "Not a function"), { bold: true, size: 16, color: isF ? "c" : "e" });
    },
    metrics(s) { const f = RULES[s.rule], isF = range(1, 6, 1).every((x) => f(x).length === 1), ys = f(s.x); return [[T("함수인가", "Function?"), isF ? T("예 — x 하나에 y 하나", "Yes — one y for each x") : T("아니요", "No"), "key"], [`f(${s.x})`, ys.length === 1 ? String(ys[0]) : T("정해지지 않음", "undefined")]]; },
    predict: [
      { q: "‘y는 x의 배수(6 이하)’는 함수일까요?", options: O("그렇다", "아니다"), set: (s) => Object.assign(s, { rule: "d", x: 3 }), reveal: (s) => (s.x = 1), answer: () => "b", why: "x = 1이면 y가 1, 2, 3, 4, 5, 6으로 여러 개라 함수가 아닙니다." },
      { q: "y = 2x + 1에서 f(3)은?", set: (s) => Object.assign(s, { rule: "a", x: 1 }), reveal: (s) => (s.x = 3), answer: () => 7, why: "f(3) = 2 × 3 + 1 = 7입니다." },
    ],
  },
  // ═════════ 중1 Ⅷ 자료의 정리와 해석 ═════════
  {
    id: "m1-stat-inquiry", grade: 1, unit: 8, lesson: "8 탐구", title: "우리 반 통계 탐구 — 질문에서 결론까지 네 단계", type: "데이터", time: "15분",
    tags: ["통계적 탐구", "히스토그램", "대푯값"], links: ["m1-histogram-width", "m1-averages"],
    desc: "궁금한 질문을 정하고(①), 자료를 모으고(②), 그래프로 나타내고(③), 결론을 말하는(④) 통계적 탐구의 흐름을 따라갑니다. 조사 인원과 반을 바꾸면 자료가 달라지고, 히스토그램과 도수분포다각형으로 분포를 보며 평균·중앙값으로 결론을 씁니다.",
    obs: ["통계적 탐구는 질문 설정 → 자료 수집 → 분석(표·그래프) → 해석과 결론의 순서로 진행합니다.", "조사 인원이 많을수록 분포의 모양이 안정됩니다.", "결론에는 근거가 된 그래프와 대푯값을 함께 씁니다."],
    q: "우리 반에서 조사해 보고 싶은 질문을 하나 정하고, 어떤 그래프로 나타낼지 정해 봅시다.",
    formula: "질문 → 자료 수집 → 그래프·대푯값 → 결론",
    view: { x: [-1.6, 12.4], y: [-1.6, 8] },
    params: [
      { key: "q", label: "① 질문", type: "select", value: "a", options: [["a", "하루 수면 시간"], ["b", "등교에 걸리는 시간"], ["c", "하루 휴대폰 사용 시간"]] },
      { key: "n", label: "② 조사 인원", min: 10, max: 60, step: 5, value: 30 },
      { key: "seed", label: "② 조사한 반", min: 1, max: 9, step: 1, value: 1 },
      { key: "gr", label: "③ 그래프", type: "seg", value: "hist", options: [["hist", "히스토그램"], ["poly", "도수분포다각형"]] },
    ],
    draw(s, g) {
      const q = QS[s.q], d = survey(s), bins = range(q.lo, q.hi - q.w, q.w), cnt = bins.map((b) => d.filter((v) => v >= b && v < b + q.w).length), top = Math.max(4, Math.ceil(Math.max(...cnt) / 2) * 2);
      const X = (u) => ((u - q.lo) / (q.hi - q.lo)) * 11, Y = (v) => (v / top) * 6.4;
      axes(g, { X, Y, xs: range(q.lo, q.hi, q.w * (bins.length > 8 ? 2 : 1)), ys: range(0, top, top / 4), xName: T(q.unit[0], q.unit[1]), yName: T("도수(명)", "Count") });
      if (s.gr === "hist") bins.forEach((b, i) => cnt[i] && rect(g, X(b), 0, X(b + q.w) - X(b), Y(cnt[i]), { fill: "a", fo: 0.35, color: "a", w: 1.4 }));
      else g.path([[X(q.lo - q.w / 2), 0], ...bins.map((b, i) => [X(b + q.w / 2), Y(cnt[i])]), [X(q.hi + q.w / 2), 0]].map(([x, y]) => [Math.max(-0.4, Math.min(11.4, x)), y]), { color: "a", w: 2.6 });
      const mean = d.reduce((a, b) => a + b, 0) / d.length; g.seg([X(mean), 0], [X(mean), 6.8], { color: "e", w: 1.6, dash: "5 4" }); g.text([X(mean), 6.8], T(`평균 ${fmt(mean, 1)}`, `mean ${fmt(mean, 1)}`), { dy: -8, size: 12, bold: true, color: "e" });
      g.text([5.5, 7.6], T(`① ${q.ko}  ② ${s.n}명 조사  ③ ${s.gr === "hist" ? "히스토그램" : "도수분포다각형"}`, `① ${q.en}  ② ${s.n} students  ③ ${s.gr === "hist" ? "Histogram" : "Frequency polygon"}`), { size: 13, bold: true });
    },
    metrics(s) {
      const q = QS[s.q], d = survey(s).slice().sort((a, b) => a - b), n = d.length, mean = d.reduce((a, b) => a + b, 0) / n, med = n % 2 ? d[(n - 1) / 2] : (d[n / 2 - 1] + d[n / 2]) / 2;
      const bins = range(q.lo, q.hi - q.w, q.w), cnt = bins.map((b) => d.filter((v) => v >= b && v < b + q.w).length), mi = cnt.indexOf(Math.max(...cnt)), u = T(q.unit[0], q.unit[1]);
      return [[T("평균", "Mean"), `${fmt(mean, 1)}${u}`], [T("중앙값", "Median"), `${fmt(med, 1)}${u}`], [T("가장 많은 계급", "Modal class"), `${bins[mi]}~${bins[mi] + q.w}${u}`],
        [T("④ 결론", "④ Conclusion"), T(`절반의 학생이 ${fmt(med, 1)}${u} 이하예요${Math.abs(mean - med) > q.w * 0.6 ? ". 평균이 중앙값보다 커서 아주 큰 값이 있어요" : ""}`, `Half the students are at or below ${fmt(med, 1)}${u}${Math.abs(mean - med) > q.w * 0.6 ? "; the mean is above the median, so there are some very large values" : ""}`), "key"]];
    },
    predict: [
      { q: "조사 인원을 10명에서 60명으로 늘리면 그래프 모양은 어떻게 될까요?", options: O("더 매끄럽고 안정된다", "더 들쭉날쭉해진다", "변하지 않는다"), set: (s) => Object.assign(s, { n: 10 }), reveal: (s) => (s.n = 60), answer: () => "a", why: "자료가 많을수록 우연에 따른 흔들림이 줄어 분포의 모양이 안정됩니다." },
      { q: "휴대폰 사용 시간처럼 아주 큰 값이 몇 개 있으면, 평균과 중앙값 중 더 크게 흔들리는 것은?", options: O("평균", "중앙값"), set: (s) => Object.assign(s, { q: "c", n: 40 }), answer: () => "a", why: "평균은 모든 값을 더해 나누므로 아주 큰 값에 끌려가지만, 중앙값은 가운데 순서의 값이라 덜 흔들립니다." },
    ],
  },
  // ═════════ 대수 Ⅰ 지수와 로그 ═════════
  {
    id: "alg-exp-extend", grade: 5, unit: 1, lesson: "Ⅰ-2", title: "2ˣ의 빈칸 채우기 — 정수에서 유리수, 실수 지수로", type: "조작", time: "12분",
    tags: ["지수의 확장", "유리수 지수", "실수 지수"], links: ["alg-nth-root", "alg-exp-laws"],
    desc: "y = 2ˣ의 점을 정수 x에서만 찍다가, 간격을 1/2, 1/4, 1/8로 좁혀 빈칸을 채웁니다. 2^(1/2) = √2처럼 지수법칙이 그대로 성립하도록 정하면 점들이 하나의 매끄러운 곡선 위에 놓입니다. 마지막으로 √2 = 1.4142…에 다가가는 유리수 지수로 2^√2를 어림합니다.",
    obs: ["2^(1/2) × 2^(1/2) = 2이 되려면 2^(1/2) = √2여야 합니다.", "유리수 지수의 점들은 간격을 좁힐수록 하나의 곡선을 빈틈없이 채웁니다.", "무리수 지수 2^√2는 √2에 다가가는 유리수 지수의 값들이 다가가는 수로 정합니다."],
    q: "2^(1/3)은 어떤 수여야 지수법칙이 깨지지 않을까요?",
    formula: "a^(m/n) = ⁿ√(aᵐ),  2^√2 = lim 2^(1.4), 2^(1.41), 2^(1.414), …",
    view: { x: [-5.9, 8.1], y: [-1.1, 8.5] },
    params: [
      { key: "k", label: "점 간격 1/2ᵏ", min: 0, max: 4, step: 1, value: 0 },
      { key: "d", label: "√2를 소수 몇째 자리까지", min: 0, max: 5, step: 1, value: 0 },
    ],
    draw(s, g) {
      const X = (u) => u * 2.4, Y = (v) => v * 0.95, st = 1 / 2 ** s.k;
      axes(g, { X, Y, xs: range(-2, 3, 1), ys: range(0, 8, 2), xName: "x", yName: "y = 2ˣ" });
      if (s.k >= 3) g.param((u) => [X(u), Y(2 ** u)], -2, 3, { color: "muted", w: 1.2, dash: "4 4" });
      for (let u = -2; u <= 3 + 1e-9; u += st) g.point([X(u), Y(2 ** u)], "", { color: Number.isInteger(+u.toFixed(6)) ? "a" : "b", r: s.k >= 3 ? 3 : 4.5 });
      g.point([X(0.5), Y(Math.SQRT2)], s.k >= 1 ? "2^(1/2) = √2" : "", { color: "b", hollow: s.k < 1, r: 5 });
      if (s.d > 0) { const e = Math.floor(Math.SQRT2 * 10 ** s.d) / 10 ** s.d; g.seg([X(e), 0], [X(e), Y(2 ** e)], { color: "e", w: 1.4, dash: "4 4" }); g.point([X(e), Y(2 ** e)], `2^${e} = ${(2 ** e).toFixed(5)}`, { color: "e", anchor: "end", dx: -10 }); }
      g.text([X(-1.9), Y(7.6)], T(`점 간격 ${s.k ? "1/" + 2 ** s.k : "1"} — 점 ${Math.round(5 / st) + 1}개`, `Spacing ${s.k ? "1/" + 2 ** s.k : "1"} — ${Math.round(5 / st) + 1} points`), { anchor: "start", bold: true, size: 14 });
    },
    metrics(s) { const e = Math.floor(Math.SQRT2 * 10 ** s.d) / 10 ** s.d; return [["2^(1/2)", `√2 ≈ ${Math.SQRT2.toFixed(4)}`], [T("√2의 어림", "Approximation of √2"), String(e)], [`2^${e}`, (2 ** e).toFixed(5), "key"], ["2^√2", "≈ 2.66514"]]; },
    predict: [
      { q: "2^(1/2)의 값을 소수 둘째 자리까지 구하면?", set: (s) => Object.assign(s, { k: 0, d: 0 }), reveal: (s) => (s.k = 1), answer: () => 1.41, tol: 0.006, why: "2^(1/2) × 2^(1/2) = 2이므로 2^(1/2) = √2 ≈ 1.41입니다." },
      { q: "2^1.4와 2^1.5 중 2^√2에 더 가까운 것은?", options: O("2^1.4", "2^1.5"), set: (s) => Object.assign(s, { k: 2, d: 1 }), answer: () => "a", why: "√2 = 1.414…는 1.5보다 1.4에 훨씬 가깝고 2ˣ는 연속이므로 2^1.4가 더 가깝습니다." },
    ],
  },
  {
    id: "alg-exp-laws", grade: 5, unit: 1, lesson: "Ⅰ-3", title: "지수법칙 — 곱하면 지수끼리 더해진다", type: "조작", time: "10분",
    tags: ["지수법칙", "거듭제곱", "실수 지수"], links: ["alg-exp-extend", "alg-slide-rule"],
    desc: "위의 수직선에는 지수를, 아래 수직선에는 그 거듭제곱 aˣ을 같은 자리에 적습니다. aᵐ × aⁿ은 지수를 m에서 n만큼 더 가는 것, aᵐ ÷ aⁿ은 n만큼 되돌아오는 것, (aᵐ)ⁿ은 m씩 n번 가는 것임을 화살표로 보고, 지수가 분수·음수여도 같은 규칙이 성립하는지 확인합니다.",
    obs: ["aᵐ × aⁿ = a^(m+n): 곱셈이 지수의 덧셈이 됩니다.", "aᵐ ÷ aⁿ = a^(m−n): 나눗셈은 지수의 뺄셈입니다.", "(aᵐ)ⁿ = a^(mn): 거듭제곱의 거듭제곱은 지수의 곱입니다."],
    q: "a⁰ = 1, a^(−1) = 1/a로 정하는 까닭을 지수법칙으로 설명해 봅시다.",
    formula: "aᵐaⁿ = a^(m+n),  aᵐ ÷ aⁿ = a^(m−n),  (aᵐ)ⁿ = a^(mn)  (a > 0)",
    view: { x: [-6.4, 7.4], y: [-2.6, 6.9] },
    params: [
      { key: "law", label: "법칙", type: "seg", value: "mul", options: [["mul", "aᵐ × aⁿ"], ["div", "aᵐ ÷ aⁿ"], ["pow", "(aᵐ)ⁿ"]] },
      { key: "a", label: "밑 a", type: "select", value: "2", options: [["2", "2"], ["3", "3"], ["10", "10"]] },
      { key: "m", label: "m", min: -2, max: 3, step: 0.5, value: 2 },
      { key: "n", label: "n", min: -2, max: 3, step: 0.5, value: 1.5 },
    ],
    draw(s, g) {
      const a = +s.a, X = (e) => e * 1.05, r = s.law === "mul" ? s.m + s.n : s.law === "div" ? s.m - s.n : s.m * s.n;
      g.seg([-6, 4], [7, 4], { color: "axis", w: 1.6 }); g.seg([-6, 0], [7, 0], { color: "axis", w: 1.6 });
      g.text([-6, 4], T("지수", "exponent"), { dy: -14, anchor: "start", size: 12, color: "muted" }); g.text([-6, 0], `${T("값", "value")} ${a}ˣ`, { dy: -14, anchor: "start", size: 12, color: "muted" });
      for (let e = -5; e <= 6; e++) { g.seg([X(e), 3.85], [X(e), 4.15], { color: "axis", w: 1 }); g.text([X(e), 4], String(e).replace("-", "−"), { dy: 20, size: 11, color: "muted" }); g.seg([X(e), -0.15], [X(e), 0.15], { color: "axis", w: 1 }); }
      const vl = (e, c, lab) => { if (Math.abs(e) > 6) return; g.seg([X(e), 4], [X(e), 0], { color: c, w: 1.2, dash: "4 4" }); g.point([X(e), 0], "", { color: c }); g.text([X(e), 0], lab, { dy: 22, size: 12, bold: true, color: c }); };
      const v = (e) => { const x = a ** e; return x >= 1000 || x < 0.01 ? x.toExponential(1) : fmt(x, 3); };
      if (s.law === "pow") { const k = Math.max(1, Math.round(Math.abs(s.n) * 2)); for (let i = 0; i < k; i++) { const e0 = (s.m * s.n * i) / k, e1 = (s.m * s.n * (i + 1)) / k; g.vec([X(e0), 4.6 + (i % 2) * 0.5], [X(e1), 4.6 + (i % 2) * 0.5], { color: "a", w: 2.4 }); } vl(0, "muted", "1"); vl(s.m, "a", `${a}^${fmt(s.m)}`); }
      else { g.vec([X(0), 4.6], [X(s.m), 4.6], { color: "a", w: 2.6 }); g.vec([X(s.m), 5.3], [X(r), 5.3], { color: "b", w: 2.6 }); vl(s.m, "a", v(s.m)); g.text([X((s.m + r) / 2), 5.3], (s.law === "mul" ? "+" : "−") + fmt(Math.abs(s.n)), { dy: -10, color: "b", bold: true, size: 13 }); }
      vl(r, "e", v(r));
      const lhs = s.law === "mul" ? `${a}^${fmt(s.m)} × ${a}^${fmt(s.n)}` : s.law === "div" ? `${a}^${fmt(s.m)} ÷ ${a}^${fmt(s.n)}` : `(${a}^${fmt(s.m)})^${fmt(s.n)}`;
      g.text([0.5, 6.4], `${lhs} = ${a}^${fmt(r)}`, { bold: true, size: 16 });
      g.text([0.5, -2.1], T(`왼쪽을 계산: ${v(r)}   오른쪽: ${a}^${fmt(r)} = ${v(r)}`, `Left side: ${v(r)}   Right side: ${a}^${fmt(r)} = ${v(r)}`), { size: 13, color: "muted" });
    },
    metrics(s) { const a = +s.a, r = s.law === "mul" ? s.m + s.n : s.law === "div" ? s.m - s.n : s.m * s.n, L = s.law === "mul" ? a ** s.m * a ** s.n : s.law === "div" ? a ** s.m / a ** s.n : (a ** s.m) ** s.n; return [[T("결과 지수", "Resulting exponent"), fmt(r), "key"], [T("왼쪽 값", "Left side"), fmt(L, 4)], [T("오른쪽 값", "Right side"), fmt(a ** r, 4)]]; },
    predict: [
      { q: "2³ × 2²는 2의 몇 제곱일까요?", set: (s) => Object.assign(s, { law: "mul", a: "2", m: 3, n: 2 }), answer: () => 5, why: "곱셈은 지수의 덧셈: 3 + 2 = 5, 2⁵ = 32입니다." },
      { q: "(2^0.5)⁴의 값은?", set: (s) => Object.assign(s, { law: "pow", a: "2", m: 0.5, n: 3 }), reveal: (s) => (s.n = 2), answer: () => 4, why: "(2^0.5)⁴ = 2^(0.5×4) = 2² = 4입니다." },
    ],
  },
  // ═════════ 직무 수학 Ⅱ 변화와 관계 ═════════
  {
    id: "job-rate-table", grade: 12, unit: 2, lesson: "Ⅱ-3", title: "주차 요금표에서 규칙 찾기 — 기본 요금과 추가 요금", type: "조작", time: "10분",
    tags: ["대응 관계", "규칙 찾기", "요금표"], links: ["job-breakeven", "job-recipe-scale"],
    desc: "주차장 요금표에서 주차 시간과 요금의 대응 관계를 표로 정리하고 규칙을 찾습니다. 기본 시간까지는 기본 요금, 그 뒤로는 일정 시간마다 추가 요금이 붙는 계단 모양의 관계를 그래프로 보고, 규칙을 식으로 나타내 다른 시간의 요금을 구합니다.",
    obs: ["표에서 x가 일정하게 늘 때 y가 얼마씩 느는지 보면 규칙이 보입니다.", "기본 시간 뒤로는 추가 시간마다 같은 금액이 더해지는 계단 모양입니다.", "규칙을 식으로 쓰면 표에 없는 시간의 요금도 구할 수 있습니다."],
    q: "기본 30분 2000원, 그 뒤 10분마다 500원이면 75분 주차 요금은 얼마일까요?",
    formula: "요금 = 기본 요금 + 추가 요금 × ⌈(주차 시간 − 기본 시간) ÷ 추가 단위⌉",
    view: { x: [-1.8, 12.2], y: [-1.6, 8] },
    params: [
      { key: "b", label: "기본 시간 (분)", min: 10, max: 60, step: 10, value: 30 },
      { key: "f", label: "기본 요금 (원)", min: 0, max: 5000, step: 500, value: 2000 },
      { key: "t", label: "추가 단위 (분)", min: 5, max: 30, step: 5, value: 10 },
      { key: "u", label: "추가 요금 (원)", min: 100, max: 2000, step: 100, value: 500 },
      { key: "x", label: "주차 시간 (분)", min: 0, max: 180, step: 5, value: 75 },
    ],
    fee(s, x) { return x <= s.b ? s.f : s.f + s.u * Math.ceil((x - s.b) / s.t - 1e-9); },
    draw(s, g) {
      const top = Math.ceil(this.fee(s, 180) / 2000) * 2000 || 2000, X = (m) => (m / 180) * 7, Y = (w) => (w / top) * 6.4;
      axes(g, { X, Y, xs: range(0, 180, 30), ys: range(0, top, top / 4), xName: T("분", "min"), yName: T("요금(원)", "Fee (₩)"), yl: (v) => (v >= 1000 ? v / 1000 + T("천", "k") : String(v)) });
      for (let m = 0; m < 180; m += 1) { const y = this.fee(s, m + 0.5); g.seg([X(m), Y(y)], [X(m + 1), Y(y)], { color: "a", w: 2.6 }); }
      g.point([X(s.x), Y(this.fee(s, s.x))], "", { color: "e", r: 6 });
      const rows = range(0, 6, 1).map((i) => s.b + (i - 1) * s.t).filter((m) => m >= 0);
      rect(g, 7.6, 0.2, 4.4, 7.2, { fill: "muted", fo: 0.05, color: "grid", w: 1 });
      g.text([8.3, 7.0], T("시간(분)", "min"), { bold: true, size: 12 }); g.text([10.0, 7.0], T("요금(원)", "fee"), { bold: true, size: 12 });
      rows.forEach((m, i) => { const yy = 6.2 - i * 0.95; g.text([8.3, yy], String(m), { size: 13, mono: true }); g.text([10.0, yy], this.fee(s, m).toLocaleString("ko-KR"), { size: 13, mono: true, color: i ? "ink" : "muted" }); if (i > 1) g.text([11.9, yy + 0.47], `+${s.u}`, { size: 11, color: "b", anchor: "end" }); });
    },
    metrics(s) { return [[T(`${s.x}분 요금`, `Fee for ${s.x} min`), `${this.fee(s, s.x).toLocaleString("ko-KR")}${T("원", " won")}`, "key"], [T("규칙", "Rule"), T(`${s.b}분까지 ${s.f}원, 그 뒤 ${s.t}분마다 +${s.u}원`, `₩${s.f} up to ${s.b} min, then +₩${s.u} every ${s.t} min`)]]; },
    predict: [
      { q: "기본 30분 2000원, 그 뒤 10분마다 500원일 때 75분 요금은 몇 원?", set: (s) => Object.assign(s, { b: 30, f: 2000, t: 10, u: 500, x: 30 }), reveal: (s) => (s.x = 75), answer: () => 4500, why: "추가 45분은 10분 단위 5개(41~50분까지 올림)이므로 2000 + 500 × 5 = 4500원입니다." },
      { q: "같은 요금표에서 요금이 처음으로 3000원이 되는 것은 몇 분을 넘을 때일까요?", set: (s) => Object.assign(s, { b: 30, f: 2000, t: 10, u: 500, x: 30 }), answer: () => 40, why: "3000원 = 2000 + 500 × 2, 추가 단위 2개째가 시작되는 40분을 넘을 때입니다." },
    ],
  },
  {
    id: "job-cycle-graph", grade: 12, unit: 2, lesson: "Ⅱ-4", title: "밀물·썰물과 하루 기온 — 증가·감소가 되풀이되는 그래프", type: "조작", time: "10분",
    tags: ["주기적 변화", "증가와 감소", "그래프 해석"], links: ["job-chart-choice", "cul-moving-average"],
    desc: "항구의 바닷물 높이와 하루 기온을 48시간 동안 그래프로 봅니다. 시각을 옮기며 지금 값이 늘고 있는지 줄고 있는지, 가장 높은 때와 낮은 때가 언제인지 읽고, 같은 모양이 되풀이되는 간격(주기)을 찾습니다. 물때표로 배가 들어올 수 있는 시간을 정하는 직무 상황과 연결합니다.",
    obs: ["그래프가 오른쪽 위로 가면 증가, 오른쪽 아래로 가면 감소입니다.", "같은 모양이 일정한 간격으로 되풀이되는 변화를 주기적 변화라고 합니다.", "밀물·썰물은 약 12시간 25분, 기온은 약 24시간마다 되풀이됩니다."],
    q: "배가 들어오려면 수위가 4 m 이상이어야 한다면, 하루에 몇 번, 언제 들어올 수 있을까요?",
    formula: "주기 = 같은 모양이 다시 시작되기까지의 시간",
    view: { x: [-1.8, 12.2], y: [-1.6, 8] },
    params: [
      { key: "mode", label: "그래프", type: "seg", value: "tide", options: [["tide", "밀물·썰물 수위"], ["temp", "하루 기온"]] },
      { key: "t", label: "시각 (시)", min: 0, max: 48, step: 0.5, value: 10 },
    ],
    draw(s, g) {
      const f = s.mode === "tide" ? TIDE : TEMP, [lo, hi, st] = s.mode === "tide" ? [0, 6, 1] : [5, 25, 5], X = (h) => (h / 48) * 11.5, Y = (v) => ((v - lo) / (hi - lo)) * 6.4;
      axes(g, { X, Y, xs: range(0, 48, 6), ys: range(lo, hi, st), xName: T("시", "h"), yName: s.mode === "tide" ? T("수위(m)", "Height (m)") : T("기온(°C)", "Temp (°C)") });
      if (s.mode === "tide") g.seg([X(0), Y(4)], [X(48), Y(4)], { color: "c", w: 1.4, dash: "6 4" });
      for (let h = 0; h < 48; h += 0.25) { const up = f(h + 0.25) > f(h); g.seg([X(h), Y(f(h))], [X(h + 0.25), Y(f(h + 0.25))], { color: up ? "a" : "b", w: 3 }); }
      const up = f(s.t + 0.01) > f(s.t);
      g.seg([X(s.t), 0], [X(s.t), Y(f(s.t))], { color: "e", w: 1.2, dash: "4 4" }); g.point([X(s.t), Y(f(s.t))], `${fmt(f(s.t), 1)}${s.mode === "tide" ? " m" : "°C"} ${up ? "↗" : "↘"}`, { color: "e" });
      g.text([X(1), Y(hi) + 0.6], T("주황: 증가  파랑: 감소", "orange: increasing  blue: decreasing"), { anchor: "start", size: 12, color: "muted" });
    },
    metrics(s) {
      const f = s.mode === "tide" ? TIDE : TEMP, P = s.mode === "tide" ? 12.42 : 24, up = f(s.t + 0.01) > f(s.t);
      let nx = s.t; for (let h = s.t; h < s.t + P + 0.1; h += 0.05) if (f(h) > f(nx)) nx = h;
      const hm = (h) => { const x = ((h % 24) + 24) % 24, H = Math.floor(x), M = Math.round((x - H) * 60); return `${H}:${String(M % 60).padStart(2, "0")}`; };
      return [[T("지금", "Now"), up ? T("증가 중", "increasing") : T("감소 중", "decreasing"), "key"], [T("주기", "Period"), s.mode === "tide" ? T("약 12시간 25분", "about 12 h 25 min") : T("24시간", "24 h")], [T("다음 최고", "Next peak"), hm(nx)]];
    },
    predict: [
      { q: "밀물·썰물 수위는 약 몇 시간마다 되풀이될까요?", set: (s) => Object.assign(s, { mode: "tide", t: 2 }), answer: () => 12.42, tol: 0.6, why: "그래프의 최고점 사이 간격이 약 12.4시간(12시간 25분)입니다." },
      { q: "하루 기온이 가장 높은 때는 몇 시쯤일까요?", set: (s) => Object.assign(s, { mode: "temp", t: 6 }), answer: () => 15, tol: 1.5, why: "해가 가장 높은 정오보다 늦은 오후 3시쯤 기온이 가장 높습니다." },
    ],
  },
  // ═════════ 직무 수학 Ⅳ 자료와 가능성 ═════════
  {
    id: "job-count-cases", grade: 12, unit: 4, lesson: "Ⅳ-1", title: "근무표와 비밀번호 — 직무에서 세는 경우의 수", type: "조작", time: "10분",
    tags: ["경우의 수", "곱의 법칙", "순열"], links: ["cm1-sum-product", "pst-perm-comb"],
    desc: "매장 직원 n명 중에서 오전·오후·야간 근무자를 한 명씩 정하는 방법과, 숫자·문자로 만드는 비밀번호의 개수를 셉니다. 자리마다 고를 수 있는 가짓수를 곱하는 곱의 법칙으로, 같은 사람을 두 번 쓸 수 있는지에 따라 달라지는 경우의 수를 비교합니다.",
    obs: ["단계마다 고르는 가짓수를 모두 곱하면 전체 경우의 수가 됩니다(곱의 법칙).", "한 번 뽑은 사람을 다시 쓸 수 없으면 자리마다 가짓수가 하나씩 줄어듭니다.", "비밀번호는 자리 수가 하나 늘 때마다 경우의 수가 글자 종류 수만큼 곱해집니다."],
    q: "숫자 4자리 비밀번호와 숫자·영문 소문자 4자리 비밀번호의 개수는 몇 배 차이 날까요?",
    formula: "곱의 법칙: m × n × …,  ₙP₃ = n(n − 1)(n − 2)",
    view: { x: [-0.6, 13.4], y: [-1.4, 8.2] },
    params: [
      { key: "mode", label: "상황", type: "seg", value: "shift", options: [["shift", "근무표 짜기"], ["pin", "비밀번호"]] },
      { key: "n", label: "직원 수", min: 3, max: 8, step: 1, value: 5, when: (s) => s.mode === "shift" },
      { key: "rep", label: "한 사람이 두 번 근무해도 됨", type: "check", value: false, when: (s) => s.mode === "shift" },
      { key: "L", label: "비밀번호 자리 수", min: 4, max: 8, step: 1, value: 4, when: (s) => s.mode === "pin" },
      { key: "kind", label: "쓸 수 있는 글자", type: "select", value: "d", options: [["d", "숫자 (10가지)"], ["l", "영문 소문자 (26가지)"], ["dl", "숫자 + 소문자 (36가지)"]], when: (s) => s.mode === "pin" },
    ],
    slots(s) { if (s.mode === "shift") return [T("오전", "AM"), T("오후", "PM"), T("야간", "Night")].map((nm, i) => [nm, s.rep ? s.n : s.n - i]); const k = { d: 10, l: 26, dl: 36 }[s.kind]; return Array.from({ length: s.L }, (_, i) => [T(`${i + 1}자리`, `#${i + 1}`), k]); },
    draw(s, g) {
      const sl = this.slots(s), w = Math.min(1.7, 12.4 / sl.length - 0.2), tot = sl.reduce((p, [, k]) => p * k, 1);
      sl.forEach(([nm, k], i) => { const x = 0.2 + i * (w + 0.2); rect(g, x, 3.4, w, 2.2, { fill: "a", fo: 0.12, color: "a", w: 2 }); g.text([x + w / 2, 6.0], nm, { size: 13, bold: true }); g.text([x + w / 2, 4.5], String(k), { size: 22, bold: true, color: "a" }); if (i) g.text([x - 0.1, 4.5], "×", { size: 18, color: "muted" }); });
      g.text([6.4, 2.2], `${sl.map(([, k]) => k).join(" × ")} = ${tot.toLocaleString("ko-KR")}`, { bold: true, size: 17, color: "e" });
      if (s.mode === "pin") g.text([6.4, 1.0], T(`1초에 1000번 시도하면 모두 해 보는 데 ${tot / 1000 < 3600 ? fmt(tot / 1000, 0) + "초" : tot / 1000 < 86400 * 2 ? fmt(tot / 3.6e6, 1) + "시간" : fmt(tot / 8.64e7, 0) + "일"}`, `At 1000 tries a second, trying all takes ${tot / 1000 < 3600 ? fmt(tot / 1000, 0) + " s" : tot / 1000 < 86400 * 2 ? fmt(tot / 3.6e6, 1) + " h" : fmt(tot / 8.64e7, 0) + " days"}`), { size: 14 });
      else g.text([6.4, 1.0], s.rep ? T("같은 사람을 다시 쓸 수 있어 자리마다 n가지", "People may repeat, so n choices each time") : T("한 번 정한 사람은 빼고 고르므로 하나씩 줄어요", "Each person is used once, so choices drop by one"), { size: 14, color: "muted" });
      g.text([6.4, 7.4], s.mode === "shift" ? T(`직원 ${s.n}명 → 오전·오후·야간 1명씩`, `${s.n} staff → one each for AM, PM, night`) : T(`${s.L}자리, 자리마다 ${sl[0][1]}가지`, `${s.L} characters, ${sl[0][1]} choices each`), { size: 15, bold: true });
    },
    metrics(s) { const sl = this.slots(s), tot = sl.reduce((p, [, k]) => p * k, 1); return [[T("경우의 수", "Number of ways"), tot.toLocaleString("ko-KR"), "key"], [T("계산", "Calculation"), sl.map(([, k]) => k).join(" × ")]]; },
    predict: [
      { q: "직원 5명 중 오전·오후·야간 근무자를 겹치지 않게 1명씩 정하는 방법의 수는?", set: (s) => Object.assign(s, { mode: "shift", n: 5, rep: false }), answer: () => 60, why: "5 × 4 × 3 = 60가지입니다." },
      { q: "숫자 4자리 비밀번호는 모두 몇 가지일까요?", set: (s) => Object.assign(s, { mode: "pin", L: 4, kind: "d" }), answer: () => 10000, why: "자리마다 10가지이므로 10 × 10 × 10 × 10 = 10000가지입니다." },
    ],
  },
  // ═════════ 수학과 문화 Ⅰ 예술과 수학 ═════════
  {
    id: "cul-queneau", grade: 11, unit: 1, lesson: "Ⅰ-3", title: "백조 편의 시 — 열네 줄로 만드는 10¹⁴편의 시", type: "조작", time: "10분",
    tags: ["문학과 수학", "곱의 법칙", "거듭제곱"], links: ["cul-braille", "job-count-cases"],
    desc: "프랑스 작가 레몽 크노는 1961년 14줄짜리 시 10편을 줄마다 잘라, 독자가 각 줄을 10편 중 아무 것에서나 골라 이어 읽게 했습니다. 줄마다 10가지씩 고르면 시는 10¹⁴편이 됩니다. 줄 수와 고를 수 있는 시의 수를 바꾸며 그 수가 얼마나 빨리 커지는지, 다 읽으려면 얼마나 걸리는지 계산합니다.",
    obs: ["줄마다 고를 수 있는 가짓수를 곱하면 만들 수 있는 시의 수가 됩니다.", "줄이 하나 늘 때마다 시의 수는 고를 수 있는 가짓수만큼 곱해집니다.", "10¹⁴편은 1분에 한 편씩 읽어도 약 1억 9천만 년이 걸립니다."],
    q: "우리 반이 4줄짜리 시를 5편 쓰고 같은 방법으로 섞으면 몇 편의 시가 생길까요?",
    formula: "만들 수 있는 시 = (고를 수 있는 시의 수)^(줄 수)",
    view: { x: [-0.6, 13.4], y: [-1.4, 8.2] },
    params: [
      { key: "L", label: "시의 줄 수", min: 2, max: 14, step: 1, value: 14 },
      { key: "c", label: "줄마다 고를 수 있는 시", min: 2, max: 10, step: 1, value: 10 },
      { key: "seed", label: "한 편 뽑기", min: 1, max: 30, step: 1, value: 1 },
    ],
    draw(s, g) {
      const r = RNG(s.seed * 97 + s.L * 7 + s.c), h = Math.min(0.5, 7 / s.L), w = Math.min(0.75, 8 / s.c);
      for (let i = 0; i < s.L; i++) { const pick = Math.floor(r() * s.c), y = 7.4 - (i + 1) * h; for (let j = 0; j < s.c; j++) rect(g, 0.4 + j * w, y, w * 0.86, h * 0.8, { fill: j === pick ? "e" : "muted", fo: j === pick ? 0.75 : 0.08, color: j === pick ? "e" : "grid", w: 1 }); if (s.L <= 14 && h >= 0.45) g.text([0.4 + s.c * w + 0.15, y + h * 0.4], T(`${i + 1}행 ← ${pick + 1}번 시`, `line ${i + 1} ← poem ${pick + 1}`), { anchor: "start", size: 11, color: "muted", dy: 4 }); }
      const tot = s.c ** s.L, yrs = tot / (60 * 24 * 365), big = (n) => Math.round(n).toLocaleString(EN() ? "en-US" : "ko-KR");
      g.text([6.4, -0.3], `${s.c}^${s.L} = ${tot >= 1e15 ? tot.toExponential(2) : big(tot)}${T("편", " poems")}   ·   ${T(`1분에 한 편이면 ${yrs >= 1 ? big(yrs) + "년" : fmt(tot / 60, 1) + "시간"}`, `${yrs >= 1 ? big(yrs) + " years" : fmt(tot / 60, 1) + " hours"} at one poem a minute`)}`, { bold: true, size: 15, color: "e" });
    },
    metrics(s) { const tot = s.c ** s.L; return [[T("만들 수 있는 시", "Possible poems"), tot >= 1e9 ? tot.toExponential(2) : tot.toLocaleString("ko-KR"), "key"], [T("계산", "Calculation"), `${s.c}^${s.L}`]]; },
    predict: [
      { q: "14줄짜리 시 10편을 줄마다 섞으면 시는 몇 편이 될까요?", options: O("140편", "10¹⁴편", "14¹⁰편"), set: (s) => Object.assign(s, { L: 14, c: 10 }), answer: () => "b", why: "줄마다 10가지씩 14번 고르므로 10 × 10 × ⋯ × 10 = 10¹⁴편입니다." },
      { q: "줄마다 10편 중에서 고를 때 줄이 하나 늘면 시의 수는 몇 배가 될까요?", set: (s) => Object.assign(s, { L: 3, c: 10 }), reveal: (s) => (s.L = 4), answer: () => 10, why: "줄 하나에 10가지가 더 곱해지므로 10배입니다." },
    ],
  },
  {
    id: "cul-wagon-wheel", grade: 11, unit: 1, lesson: "Ⅰ-4", title: "영화 속 거꾸로 도는 바퀴 — 1초에 24장의 비밀", type: "조작", time: "10분",
    tags: ["영화와 수학", "주기", "나머지"], links: ["job-cycle-graph", "cul-polyrhythm"],
    desc: "영화는 1초에 24장의 사진(프레임)을 이어 보여 줍니다. 바퀴살이 k개인 바퀴는 360°/k만큼 돌면 똑같아 보이므로, 한 프레임 사이에 돈 각을 360°/k로 나눈 나머지만 눈에 보입니다. 회전 속도를 바꾸며 바퀴가 멈춘 듯, 천천히, 또는 거꾸로 도는 것처럼 보이는 까닭을 계산합니다.",
    obs: ["한 프레임 사이에 도는 각은 360° × (초당 회전 수) ÷ (초당 프레임 수)입니다.", "바퀴살이 k개이면 360°/k마다 같은 모양이므로 그 나머지만 보입니다.", "나머지가 바퀴살 간격의 절반보다 크면 거꾸로 도는 것처럼 보입니다."],
    q: "초당 24프레임 영화에서 바퀴살 6개인 바퀴가 멈춰 보이는 회전 속도를 모두 찾아봅시다.",
    formula: "보이는 회전 = (360°·r/f를 360°/k로 나눈 나머지, −180°/k ~ 180°/k 사이로)",
    view: { x: [-7, 7], y: [-4.4, 5.2] },
    params: [
      { key: "f", label: "초당 프레임 수", type: "select", value: "24", options: [["24", "24 (영화)"], ["30", "30 (방송)"], ["60", "60 (게임)"]] },
      { key: "k", label: "바퀴살 수", min: 3, max: 8, step: 1, value: 6 },
      { key: "r", label: "실제 회전 (회/초)", min: 0, max: 12, step: 0.25, value: 3.5 },
    ],
    calc(s) { const f = +s.f, th = (360 * s.r) / f, sp = 360 / s.k, ap = ((((th + sp / 2) % sp) + sp) % sp) - sp / 2; return { th, sp, ap }; },
    draw(s, g) {
      const { th, sp, ap } = this.calc(s), R = 2.6, C = [-3.2, 0.2];
      g.circle(C, R, { color: "ink", w: 3 });
      for (let fr = 0; fr < 4; fr++) { const base = (-th * fr * Math.PI) / 180; for (let i = 0; i < s.k; i++) { const a = base + (i * 2 * Math.PI) / s.k; g.seg(C, [C[0] + R * Math.cos(a), C[1] + R * Math.sin(a)], { color: fr ? "muted" : "a", w: fr ? 1.2 : 2.8, opacity: 1 - fr * 0.25 }); } }
      g.text([C[0], C[1] + R + 0.6], T("실제 바퀴 (프레임 4장 겹침)", "Actual wheel (4 frames overlaid)"), { size: 12, color: "muted" });
      const D = [3.4, 0.2]; g.circle(D, R, { color: "ink", w: 3 });
      for (let i = 0; i < s.k; i++) { const a = (-ap * Math.PI) / 180 + (i * 2 * Math.PI) / s.k; g.seg(D, [D[0] + R * Math.cos(a), D[1] + R * Math.sin(a)], { color: "e", w: 2.8 }); g.seg(D, [D[0] + R * Math.cos(a + (ap * Math.PI) / 180), D[1] + R * Math.sin(a + (ap * Math.PI) / 180)], { color: "muted", w: 1.2, dash: "4 3" }); }
      const dir = Math.abs(ap) < 0.5 ? T("멈춘 듯", "standing still") : ap > 0 ? T("앞으로 (천천히)", "forwards (slowly)") : T("거꾸로!", "backwards!");
      g.text([D[0], D[1] + R + 0.6], T(`화면에 보이는 바퀴: ${dir}`, `What you see: ${dir}`), { size: 13, bold: true, color: ap < -0.5 ? "e" : "ink" });
      g.text([0, -3.9], T(`한 프레임에 ${fmt(th, 1)}° 회전 → 바퀴살 간격 ${fmt(sp, 1)}°로 나눈 나머지 ${fmt(ap, 1)}°`, `${fmt(th, 1)}° per frame → remainder ${fmt(ap, 1)}° modulo the ${fmt(sp, 1)}° spoke gap`), { size: 13 });
    },
    metrics(s) { const { th, sp, ap } = this.calc(s); return [[T("프레임당 실제 회전", "Actual turn per frame"), `${fmt(th, 1)}°`], [T("바퀴살 간격", "Spoke gap"), `${fmt(sp, 1)}°`], [T("보이는 회전", "Apparent turn"), `${fmt(ap, 1)}° ${Math.abs(ap) < 0.5 ? T("(멈춤)", "(still)") : ap < 0 ? T("(거꾸로)", "(backwards)") : ""}`, "key"]]; },
    predict: [
      { q: "24프레임, 바퀴살 6개, 초당 4회전이면 바퀴는 어떻게 보일까요?", options: O("멈춘 듯", "앞으로", "거꾸로"), set: (s) => Object.assign(s, { f: "24", k: 6, r: 3 }), reveal: (s) => (s.r = 4), answer: () => "a", why: "한 프레임에 60°를 돌아 바퀴살 간격 60°와 같아지므로 매 장면이 똑같아 멈춘 것처럼 보입니다." },
      { q: "같은 바퀴가 초당 3.5회전이면?", options: O("멈춘 듯", "앞으로", "거꾸로"), set: (s) => Object.assign(s, { f: "24", k: 6, r: 3 }), reveal: (s) => (s.r = 3.5), answer: () => "c", why: "한 프레임에 52.5°는 60°보다 7.5° 모자라 바퀴살이 조금씩 뒤로 간 것처럼 보입니다." },
    ],
  },
  // ═════════ 수학과 문화 Ⅳ 환경과 수학 ═════════
  {
    id: "cul-desert", grade: 11, unit: 4, lesson: "Ⅳ-3", title: "사막화 모형 — 숲이 어느 선 아래로 줄면 돌아오지 못한다", type: "조작", time: "12분",
    tags: ["사막화", "수학적 모형", "되먹임"], links: ["cul-carbon-budget", "cul-population"],
    desc: "해마다 식생(풀과 나무로 덮인 땅의 비율)이 자라는 양과 방목·가뭄으로 줄어드는 양을 계산하는 간단한 모형으로 50년을 내다봅니다. 식생이 적으면 흙이 마르고 날려 더 자라기 어려워지는 되먹임 때문에, 어느 선 아래로 떨어지면 압력을 조금 줄여도 회복이 어렵습니다. 나무 심기를 더해 사막화를 막는 방법을 비교합니다.",
    obs: ["식생이 많을 때는 줄어들어도 다시 자라 균형을 찾습니다.", "식생이 적으면 자라는 힘도 약해져, 어느 선 아래에서는 사막으로 굳어 버립니다.", "해마다 조금씩 나무를 심으면 사막으로 떨어지는 것을 막을 수 있습니다."],
    q: "지금 식생이 30%이고 압력이 0.24일 때, 해마다 몇 %씩 나무를 심어야 사막화를 막을 수 있을까요?",
    formula: "다음 해 식생 = 올해 식생 + 자라는 양 − 방목·가뭄으로 줄어드는 양 + 심은 양",
    view: { x: [-1.8, 12.2], y: [-1.6, 8] },
    params: [
      { key: "v0", label: "지금 식생 (비율)", min: 0.1, max: 0.9, step: 0.05, value: 0.5 },
      { key: "g", label: "방목·가뭄 압력", min: 0, max: 0.4, step: 0.02, value: 0.24 },
      { key: "p", label: "해마다 나무 심기 (비율)", min: 0, max: 0.05, step: 0.005, value: 0 },
    ],
    draw(s, g) {
      const X = (y) => (y / 50) * 11.5, Y = (v) => v * 6.4, d = desert(s), base = desert(s, 0);
      axes(g, { X, Y, xs: range(0, 50, 10), ys: range(0, 1, 0.25), xName: T("년", "years"), yName: T("식생", "Vegetation"), yl: (v) => Math.round(v * 100) + "%" });
      if (s.p > 0) g.path(base.map((v, i) => [X(i), Y(v)]), { color: "muted", w: 1.6, dash: "5 4" });
      g.path(d.map((v, i) => [X(i), Y(v)]), { color: d[50] < 0.15 ? "e" : "c", w: 3 });
      g.point([X(50), Y(d[50])], `${Math.round(d[50] * 100)}%`, { color: d[50] < 0.15 ? "e" : "c", anchor: "end", dx: -10 });
      g.text([X(25), Y(1) + 0.7], d[50] < 0.15 ? T("사막으로 굳어졌어요", "It has turned to desert") : d[50] < s.v0 - 0.05 ? T("줄었지만 남아 있어요", "Reduced but still there") : T("유지되거나 회복했어요", "Stable or recovering"), { bold: true, size: 15, color: d[50] < 0.15 ? "e" : "c" });
      if (s.p > 0) g.text([X(49), Y(0.05)], T("점선: 나무를 심지 않을 때", "dashed: no planting"), { anchor: "end", size: 12, color: "muted" });
    },
    metrics(s) { const d = desert(s); return [[T("50년 뒤 식생", "Vegetation after 50 years"), `${Math.round(d[50] * 100)}%`, "key"], [T("나무를 심지 않으면", "Without planting"), `${Math.round(desert(s, 0)[50] * 100)}%`]]; },
    predict: [
      { q: "압력 0.24에서 지금 식생이 35%이고 나무를 심지 않으면, 50년 뒤 식생이 절반 이상 남을까요?", options: O("남는다", "남지 않는다"), set: (s) => Object.assign(s, { v0: 0.35, g: 0.24, p: 0 }), answer: (s) => (desert(s)[50] >= 0.5 ? "a" : "b"), why: "식생이 적은 상태에서는 자라는 양보다 줄어드는 양이 커서 점점 줄고, 문턱 아래로 떨어지면 사막으로 굳습니다. 같은 압력에서 50%로 시작하면 회복합니다." },
      { q: "같은 조건에서 해마다 4%씩 나무를 심으면 50년 뒤 식생은 절반 이상일까요?", options: O("그렇다", "아니다"), set: (s) => Object.assign(s, { v0: 0.35, g: 0.24, p: 0 }), reveal: (s) => (s.p = 0.04), answer: () => (desert({ v0: 0.35, g: 0.24, p: 0.04 })[50] >= 0.5 ? "a" : "b"), why: "심은 나무가 식생을 문턱 위로 끌어올리면 그다음부터는 스스로 자라 회복합니다." },
    ],
  },
];
