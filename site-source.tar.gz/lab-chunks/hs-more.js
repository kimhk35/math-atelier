// 교과서 탐구 활동에서 더 뽑은 실험 — 기존 과정(중1·공통수학2·대수·기하·미적분·확률과 통계·수학실험실)에 추가
import { fmt, frac, surd, dist, sub, add, mul, norm, dot, len, cross, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const V = { x: [-7, 7], y: [-5, 5] };
const ang = (v, p, q) => rad2deg(Math.acos(clamp(dot(sub(p, v), sub(q, v)) / (len(sub(p, v)) * len(sub(q, v)) || 1), -1, 1)));
const area3 = (a, b, c) => Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])) / 2;
const rot = (p, a) => [p[0] * Math.cos(a) - p[1] * Math.sin(a), p[0] * Math.sin(a) + p[1] * Math.cos(a)];
const pt = (p) => `(${p.map((v) => frac(v)).join(", ")})`;
const randn = () => { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };

export default [
  // ── 공통수학2 ──
  {
    id: "c2-apollonius", grade: 4, unit: 2, lesson: "Ⅱ-1 공학 도구", title: "아폴로니우스의 원 — 거리의 비가 일정한 점", type: "조작", time: "10분",
    tags: ["자취", "거리의 비", "원의 방정식"], links: ["c2-circle-eq", "c2-division"],
    desc: "두 점 A, B까지의 거리의 비가 k : 1로 일정한 점 P의 자취가 원(k = 1이면 수직이등분선)이 되는 것을 확인하고, 그 원의 지름이 내분점과 외분점을 잇는 선분임을 봅니다.",
    obs: ["k ≠ 1이면 자취는 원이고, k = 1이면 선분 AB의 수직이등분선입니다.", "원의 지름의 양 끝은 AB를 k : 1로 내분하는 점과 외분하는 점입니다.", "k가 1에 가까울수록 원이 커집니다."],
    q: "두 점 A(−1, 2), B(2, −4)에서의 거리의 비가 1 : 2인 점의 자취의 방정식을 구해 보세요.",
    formula: "PA : PB = k : 1 (k ≠ 1) ⇒ 중심 (A − k²B)/(1 − k²), 반지름 k·AB/|1 − k²|",
    en: { title: "Circle of Apollonius", desc: "Points with a fixed distance ratio to A and B trace a circle." },
    view: V, snap: 0.5, points: { A: [-2, 0], B: [2, 0] },
    params: [{ key: "k", label: "비 k (PA : PB = k : 1)", min: 0.3, max: 3, step: 0.05, value: 2 }, { key: "t", label: "점 P의 위치", min: 0, max: 360, step: 1, value: 60, unit: "°" }],
    anim: { key: "t", min: 0, max: 360, speed: 40, loop: "wrap", label: "P 움직이기" },
    circ(s) { const { A, B, k } = s; if (Math.abs(k - 1) < 1e-9) return null; const C = mul(sub(A, mul(B, k * k)), 1 / (1 - k * k)); return { C, r: (k * dist(A, B)) / Math.abs(1 - k * k) }; },
    draw(s, g) {
      g.grid();
      const { A, B, k } = s, c = this.circ(s);
      let P;
      if (c) { g.circle(c.C, c.r, { color: "a", w: 3, fill: "a", fo: 0.06 }); P = add(c.C, [c.r * Math.cos(deg(s.t)), c.r * Math.sin(deg(s.t))]); const I = lerp(A, B, k / (k + 1)), E = add(A, mul(sub(B, A), k / (k - 1))); g.seg(I, E, { color: "e", w: 1.6, dash: "5 4" }); g.point(I, "내분점", { color: "e", r: 4, dy: -12, dx: -30 }); if (len(E) < 12) g.point(E, "외분점", { color: "e", r: 4, dy: 20 }); g.point(c.C, "", { color: "a", r: 3.5 }); }
      else { const M = lerp(A, B, 0.5), d = sub(B, A); g.line(M, add(M, [-d[1], d[0]]), { color: "a", w: 3 }); P = add(M, mul(norm([-d[1], d[0]]), (s.t - 180) / 40)); }
      g.seg(P, A, { color: "b", w: 2.4 }).seg(P, B, { color: "c", w: 2.4 });
      g.text(lerp(P, A, 0.5), fmt(dist(P, A)), { dy: -8, color: "b", bold: true, size: 13 }).text(lerp(P, B, 0.5), fmt(dist(P, B)), { dy: -8, color: "c", bold: true, size: 13 });
      g.point(A, "A", { color: "ink", dy: 20 }).point(B, "B", { color: "ink", dy: 20 }).point(P, "P", { color: "a", r: 6.5 });
      g.handle(A, "A", { color: "b" }).handle(B, "B", { color: "c" });
    },
    metrics(s) { const c = this.circ(s); return [["PA : PB", `${fmt(s.k)} : 1`], ["자취", c ? `중심 (${fmt(c.C[0])}, ${fmt(c.C[1])}), 반지름 ${fmt(c.r)}인 원` : "선분 AB의 수직이등분선", "key"]]; },
  },
  // ── 대수 ──
  {
    id: "alg-bisector-theorem", grade: 5, unit: 4, lesson: "Ⅳ 탐구 & 융합", title: "넓이로 증명하는 내각의 이등분선 정리", type: "조작", time: "10분",
    tags: ["각의 이등분선", "넓이의 비", "증명"], links: ["alg-triangle-area", "g2-incenter"],
    desc: "∠A의 이등분선이 BC와 만나는 점 D에 대해 BD : DC = AB : AC임을, 두 삼각형 ABD와 ADC의 넓이를 두 가지 방법으로 비교해 증명합니다.",
    obs: ["△ABD와 △ADC는 A에서 BC에 내린 높이가 같으므로 넓이의 비 = BD : DC입니다.", "D에서 AB, AC까지의 거리가 같으므로 넓이의 비 = AB : AC이기도 합니다.", "½·AB·AD·sin(A/2) : ½·AC·AD·sin(A/2)로도 같은 결론이 나옵니다."],
    q: "외각의 이등분선에 대해서도 비슷한 정리가 성립할까요?",
    formula: "BD : DC = AB : AC",
    en: { title: "Angle Bisector Theorem by Areas", desc: "Compare the areas of ABD and ADC in two ways to prove BD : DC = AB : AC." },
    view: V, points: { A: [-1, 3.6], B: [-5, -2.8], C: [5, -2.8] },
    D(s) { const { A, B, C } = s, c = dist(A, B), b = dist(A, C); return lerp(B, C, c / (b + c)); },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const { A, B, C } = s, D = this.D(s), foot = (P, Q, X) => { const u = norm(sub(Q, P)); return add(P, mul(u, dot(sub(X, P), u))); };
      g.poly([A, B, D], { fill: "a", fo: 0.2, color: "a", w: 1.6 }).poly([A, D, C], { fill: "b", fo: 0.2, color: "b", w: 1.6 });
      g.poly([A, B, C], { color: "ink", w: 2.6 });
      g.seg(A, D, { color: "e", w: 2.6 });
      const E = foot(A, B, D), F = foot(A, C, D);
      g.seg(D, E, { color: "c", w: 2, dash: "5 4" }).seg(D, F, { color: "c", w: 2, dash: "5 4" }).right(E, D, A, { size: 9 }).right(F, D, A, { size: 9 });
      g.arc(A, B, D, { r: 34, color: "e", ccw: false }).arc(A, D, C, { r: 40, color: "e", ccw: false });
      g.point(A, "A").point(B, "B", { dy: 20 }).point(C, "C", { dy: 20 }).point(D, "D", { dy: 20, color: "e" });
      g.handle(A, "A").handle(B, "B").handle(C, "C");
    },
    metrics(s) { const { A, B, C } = s, D = this.D(s); return [["BD : DC", `${fmt(dist(B, D), 3)} : ${fmt(dist(D, C), 3)}`], ["AB : AC", `${fmt(dist(A, B), 3)} : ${fmt(dist(A, C), 3)}`], ["△ABD : △ADC", `${fmt(area3(A, B, D), 3)} : ${fmt(area3(A, D, C), 3)}`, "key"]]; },
  },
  // ── 기하 ──
  {
    id: "geo-hyperboloid", grade: 6, unit: 1, lesson: "Ⅰ 탐구 & 융합", title: "건축물 속 이차곡선 — 직선으로 만드는 쌍곡면", type: "3D", time: "10분",
    tags: ["쌍곡면", "냉각탑", "직선으로 곡면"], links: ["geo-hyperbola", "geo-conic-section"],
    desc: "위아래 두 원을 곧은 막대로 이은 뒤 위쪽 원을 비틀면, 곧은 막대들만으로 허리가 잘록한 곡면(쌍곡면)이 생기고 그 단면이 쌍곡선임을 봅니다.",
    obs: ["막대는 모두 곧은 직선인데 전체 모양은 곡면이 됩니다.", "비튼 각이 클수록 허리가 가늘어집니다.", "축을 포함하는 평면으로 자른 단면의 윤곽은 쌍곡선입니다."],
    q: "발전소 냉각탑과 광저우 타워가 이 모양으로 지어진 이유를 생각해 보세요.",
    formula: "x²/a² + y²/a² − z²/c² = 1 · 허리 반지름 a = R cos(θ/2)",
    en: { title: "Hyperboloid from Straight Lines", desc: "Twist two circles joined by straight rods to form a hyperboloid." },
    space: true, cam: { yaw: 20, pitch: 12, scale: 58 },
    params: [{ key: "tw", label: "비튼 각 θ", min: 0, max: 170, step: 1, value: 110, unit: "°" }, { key: "n", label: "막대 수", min: 8, max: 48, step: 2, value: 28 }],
    anim: { key: "tw", min: 0, max: 170, speed: 30, label: "비틀기" },
    draw(s, g) {
      const R = 2.2, H = 2.4, tw = deg(s.tw), E = [1, 0, 0], F = [0, 1, 0];
      g.circle([0, 0, -H], E, F, R, { color: "b", w: 2 }).circle([0, 0, H], E, F, R, { color: "b", w: 2 });
      for (let i = 0; i < s.n; i++) { const a = (2 * Math.PI * i) / s.n; g.seg([R * Math.cos(a), R * Math.sin(a), -H], [R * Math.cos(a + tw), R * Math.sin(a + tw), H], { color: i % 2 ? "a" : "f", w: 1.6, opacity: 0.85 }); }
      const w = R * Math.cos(tw / 2), c = w > 0.05 ? (H * w) / Math.sqrt(Math.max(1e-6, R * R - w * w)) : 1;
      if (w > 0.05 && s.tw > 2) g.circle([0, 0, 0], E, F, w, { color: "d", w: 2.6, bias: 2 });
      if (s.tw > 2 && w > 0.05) [1, -1].forEach((sg) => g.path(Array.from({ length: 41 }, (_, i) => { const z = -H + (2 * H * i) / 40; return [sg * w * Math.sqrt(1 + (z * z) / (c * c)), 0, z]; }), { color: "e", w: 2.4, bias: 3 }));
    },
    metrics(s) { const R = 2.2, w = R * Math.cos(deg(s.tw) / 2); return [["위아래 반지름", fmt(R)], ["허리 반지름 R cos(θ/2)", fmt(w, 3), "key"], ["막대", `${s.n}개의 곧은 선분`]]; },
  },
  {
    id: "geo-bisector-plane", grade: 6, unit: 2, lesson: "Ⅱ-4 공학 도구", title: "두 도시에서 같은 거리 — 충전소 자리 찾기", type: "3D", time: "10분",
    tags: ["수직이등분면", "공간좌표", "거리"], links: ["geo-space-coord", "geo-plane-eq"],
    desc: "좌표공간의 두 점 A, B에서 같은 거리에 있는 점들이 선분 AB의 중점을 지나고 AB에 수직인 평면을 이룸을 확인하고, 그 평면 위에서 충전소 위치를 옮겨 봅니다.",
    obs: ["PA = PB인 점 P의 자취는 평면(수직이등분면)입니다.", "이 평면의 법선벡터는 AB 방향입니다.", "평면 위의 어느 점을 골라도 PA = PB입니다."],
    q: "세 도시에서 같은 거리에 있는 점들은 어떤 도형을 이룰까요?",
    formula: "|p − a| = |p − b| ⇔ (b − a) · (p − (a + b)/2) = 0",
    en: { title: "Equidistant Charging Station", desc: "Points equidistant from A and B form the perpendicular bisector plane." },
    space: true, cam: { yaw: 40, pitch: 22, scale: 42 },
    params: [
      { key: "bx", label: "B의 x", min: -1, max: 4, step: 1, value: 3 }, { key: "by", label: "B의 y", min: -1, max: 4, step: 1, value: 3 }, { key: "bz", label: "B의 z", min: 0, max: 4, step: 1, value: 2 },
      { key: "u", label: "충전소 이동 ①", min: -2, max: 2, step: 0.05, value: 0.8 }, { key: "v", label: "충전소 이동 ②", min: -2, max: 2, step: 0.05, value: -0.6 },
    ],
    draw(s, g) {
      g.floor(4); g.axes(4.6);
      const A = [0, 0, 0], B = [s.bx, s.by, s.bz], n = sub(B, A);
      if (len(n) < 1e-9) { g.point(A, "A = B"); return; }
      const M = lerp(A, B, 0.5), e1 = norm(Math.abs(n[2]) < 0.9 * len(n) ? cross(n, [0, 0, 1]) : cross(n, [1, 0, 0])), e2 = norm(cross(n, e1));
      g.plane(M, e1, e2, 2.6, 2.6, { fill: "c", color: "c", fo: 0.16, grid: 0.65 });
      const P = add(M, add(mul(e1, s.u), mul(e2, s.v)));
      g.seg(A, B, { color: "ink", w: 2, dash: "5 4" }).seg(P, A, { color: "a", w: 2.6 }).seg(P, B, { color: "b", w: 2.6 });
      g.point(A, "A (도시)", { color: "ink", dy: 20 }).point(B, "B (도시)", { color: "ink", dy: -12 }).point(M, "M", { color: "muted", r: 3.5, dx: -22, dy: 16 }).point(P, "충전소 P", { color: "d", r: 6.5 });
    },
    metrics(s) { const A = [0, 0, 0], B = [s.bx, s.by, s.bz], n = sub(B, A); if (len(n) < 1e-9) return ["두 점을 다르게 놓아 주세요."]; const M = lerp(A, B, 0.5), e1 = norm(Math.abs(n[2]) < 0.9 * len(n) ? cross(n, [0, 0, 1]) : cross(n, [1, 0, 0])), e2 = norm(cross(n, e1)), P = add(M, add(mul(e1, s.u), mul(e2, s.v))); const d = dot(n, M); return [["PA", fmt(dist(P, A), 3)], ["PB", fmt(dist(P, B), 3)], ["수직이등분면", `${n[0]}x + ${n[1]}y + ${n[2]}z = ${fmt(d)}`.replace(/\+ -/g, "− "), "key"]]; },
  },
  {
    id: "geo-tug-of-war", grade: 6, unit: 3, lesson: "Ⅲ 탐구 & 융합", title: "줄다리기와 벡터의 합", type: "조작", time: "10분",
    tags: ["힘의 합성", "벡터의 덧셈", "합력"], links: ["geo-vector-add", "geo-vector-component"],
    desc: "가운데 고리를 네 사람이 여러 방향으로 당길 때 각 힘을 벡터로 보고 더한 합력의 방향으로 고리가 움직이는 것을 확인합니다.",
    obs: ["합력은 모든 힘 벡터를 차례로 이어 붙인 끝점입니다.", "합력이 영벡터이면 고리는 움직이지 않습니다.", "힘이 세도 방향이 비스듬하면 앞으로 당기는 성분은 작아집니다."],
    q: "두 사람이 60°를 이루며 같은 크기로 당길 때 합력의 크기는 한 사람 힘의 몇 배일까요?",
    formula: "F = F₁ + F₂ + F₃ + F₄",
    en: { title: "Tug of War with Vectors", desc: "Add pulling forces as vectors and see where the ring moves." },
    view: V, snap: 0.25, points: { F1: [-4, 1.2], F2: [-3.8, -1.6], F3: [4.2, 0.8], F4: [3.4, -2] },
    params: [{ key: "chain", label: "벡터를 이어 붙여 합력 보기", type: "check", value: true }],
    draw(s, g) {
      g.grid();
      const F = [s.F1, s.F2, s.F3, s.F4], cols = ["a", "a", "b", "b"], sum = F.reduce((a, b) => add(a, b), [0, 0]);
      F.forEach((f, i) => g.vec([0, 0], f, { color: cols[i], w: 3, label: `F${i + 1}` }));
      if (s.chain) { let cur = [0, 0]; F.forEach((f, i) => { g.vec(cur, add(cur, f), { color: cols[i], w: 1.6, opacity: 0.45 }); cur = add(cur, f); }); }
      if (len(sum) > 0.05) g.vec([0, 0], sum, { color: "d", w: 4.2, label: "합력" });
      g.circle([0, 0], 0.35, { color: "ink", w: 2.4, fill: "f", fo: 0.6 });
      F.forEach((f, i) => g.handle(f, `F${i + 1}`, { color: cols[i] }));
    },
    metrics(s) { const sum = [s.F1, s.F2, s.F3, s.F4].reduce((a, b) => add(a, b), [0, 0]); return [["합력 (성분)", `(${fmt(sum[0])}, ${fmt(sum[1])})`], ["합력의 크기", fmt(len(sum), 3), "key"], ["결과", Math.abs(sum[0]) < 0.05 ? "좌우 균형" : sum[0] > 0 ? "오른쪽 팀 우세" : "왼쪽 팀 우세"]]; },
  },
  // ── 미적분 ──
  {
    id: "calc-vertical-throw", grade: 7, unit: 4, lesson: "Ⅳ 공학 도구", title: "옥상에서 던진 공 — 위치·속도의 그래프", type: "조작", time: "10분",
    tags: ["연직 운동", "속도", "최고점"], links: ["calc-motion", "calc-secant-tangent"],
    desc: "높이 h₀인 옥상에서 공을 위로 던질 때 높이 h(t)의 그래프와 접선의 기울기(속도)를 함께 보며, 최고점과 땅에 닿는 순간을 찾습니다.",
    obs: ["속도 v(t) = h′(t)가 0인 순간 공은 가장 높습니다.", "속도가 음수이면 공이 떨어지는 중입니다.", "h(t) = 0이 되는 순간 땅에 닿습니다."],
    q: "처음 속도를 두 배로 하면 최고 높이까지 걸리는 시간은 어떻게 변할까요?",
    formula: "h(t) = h₀ + v₀t − 4.9t² · v(t) = v₀ − 9.8t",
    en: { title: "Ball Thrown from a Rooftop", desc: "Read height and velocity from h(t) and its tangent slopes." },
    view: { x: [-1.2, 9], y: [-0.8, 9.6] },
    params: [{ key: "h0", label: "옥상 높이 h₀ (m)", min: 0, max: 60, step: 5, value: 40 }, { key: "v0", label: "처음 속도 v₀ (m/s)", min: 0, max: 40, step: 1, value: 30 }, { key: "t", label: "시각 t (초)", min: 0, max: 8, step: 0.02, value: 2 }],
    anim: { key: "t", min: 0, max: 8, speed: 1.2, label: "던지기" },
    H(s, t) { return s.h0 + s.v0 * t - 4.9 * t * t; },
    T(s) { return (s.v0 + Math.sqrt(s.v0 * s.v0 + 19.6 * s.h0)) / 9.8; },
    drags: { T: { at: (s) => { const tE = (s.v0 + Math.sqrt(s.v0 * s.v0 + 19.6 * s.h0)) / 9.8, t = Math.min(s.t, tE); return [t, (s.h0 + s.v0 * t - 4.9 * t * t) * 0.09]; }, move: (s, p) => (s.t = p[0]) } },
    draw(s, g) {
      const k = 9 / 100, X = (t) => t, Y = (h) => h * k, tEnd = this.T(s), t = Math.min(s.t, tEnd);
      g.seg([-1.2, 0], [9, 0], { color: "ink", w: 1.6 }).seg([0, 0], [0, 9.4], { color: "axis", w: 1.3 });
      for (let h = 20; h <= 100; h += 20) { g.seg([0, Y(h)], [9, Y(h)], { color: "grid", w: 1 }); g.text([0, Y(h)], `${h} m`, { dx: -6, dy: 4, anchor: "end", size: 11.5, color: "muted" }); }
      for (let x = 1; x <= 8; x++) g.text([x, 0], `${x}초`, { dy: 17, size: 11.5, color: "muted" });
      g.param((u) => [X(u), Y(this.H(s, u))], 0, tEnd, { color: "muted", w: 1.4, dash: "4 5" });
      g.param((u) => [X(u), Y(this.H(s, u))], 0, t, { color: "a", w: 3.2 });
      const P = [X(t), Y(this.H(s, t))], v = s.v0 - 9.8 * t;
      g.seg(add(P, [-0.9, -0.9 * v * k]), add(P, [0.9, 0.9 * v * k]), { color: "c", w: 2.4 });
      const tm = s.v0 / 9.8; if (tm <= tEnd) g.point([X(tm), Y(this.H(s, tm))], "최고점", { color: "e", r: 4, dy: -12, anchor: "middle", dx: 0 });
      g.point(P, "", { color: "a", r: 6 });
    },
    metrics(s) { const tEnd = this.T(s), t = Math.min(s.t, tEnd), tm = s.v0 / 9.8; return [["높이 h(t)", `${fmt(this.H(s, t), 2)} m`], ["속도 v(t)", `${fmt(s.v0 - 9.8 * t, 2)} m/s`, "key"], ["최고 높이", `${fmt(this.H(s, tm), 2)} m (t = ${fmt(tm, 2)}초)`], ["땅에 닿는 시각", `${fmt(tEnd, 2)}초`]]; },
  },
  // ── 확률과 통계 ──
  {
    id: "pst-geometric-prob", grade: 8, unit: 2, lesson: "Ⅱ 탐구 & 융합", title: "그림으로 구하는 확률 — 두 사람이 만날 확률", type: "데이터", time: "10분",
    tags: ["기하적 확률", "넓이의 비", "약속"], links: ["pst-continuous", "lab-monte-pi"],
    desc: "두 사람이 한 시간 안에 무작위로 도착해 w분까지만 기다린다면 만날 확률은 정사각형에서 띠 모양 부분의 넓이 비율입니다. 무작위 점으로도 확인합니다.",
    obs: ["두 도착 시각을 (x, y)로 나타내면 전체 경우는 정사각형입니다.", "만나는 경우는 |x − y| ≤ w인 띠 부분입니다.", "확률은 넓이의 비 1 − (1 − w/60)²입니다."],
    q: "만날 확률을 50% 이상으로 하려면 몇 분을 기다려야 할까요?",
    formula: "P = 1 − (1 − w/T)²",
    en: { title: "Geometric Probability: Will They Meet?", desc: "Meeting probability is the area of a band in the square." },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [{ key: "w", label: "기다리는 시간 w (분)", min: 0, max: 60, step: 1, value: 15 }],
    init: () => ({ pts: [], hit: 0 }),
    prefill(s) { this.onDo("p500", s); },
    onChange(s) { s.pts = []; s.hit = 0; this.onDo("p500", s); },
    buttons: [["p500", "무작위 도착 500번"], ["reset", "지우기"]],
    onDo(k, s) { if (k === "reset") { s.pts = []; s.hit = 0; return; } for (let i = 0; i < 500; i++) { const x = Math.random() * 60, y = Math.random() * 60, h = Math.abs(x - y) <= s.w; if (h) s.hit++; s.pts.push([x, y, h]); } },
    draw(s, g) {
      const O = [3, 0.8], S = 9.6, M = (x, y) => [O[0] + (x / 60) * S, O[1] + (y / 60) * S];
      g.poly([M(0, 0), M(60, 0), M(60, 60), M(0, 60)], { color: "ink", w: 2 });
      g.poly([M(0, 0), M(s.w, 0), M(60, 60 - s.w), M(60, 60), M(60 - s.w, 60), M(0, s.w)], { fill: "c", fo: 0.3, stroke: false });
      [0, 15, 30, 45, 60].forEach((v) => { g.text(M(v, 0), String(v), { dy: 16, size: 11.5, color: "muted" }); g.text(M(0, v), String(v), { dx: -6, dy: 4, anchor: "end", size: 11.5, color: "muted" }); });
      let dIn = "", dOut = ""; s.pts.slice(-3000).forEach(([x, y, h]) => { const q = g.X(M(x, y)); const seg = `M${q[0].toFixed(1)} ${q[1].toFixed(1)}h0`; if (h) dIn += seg; else dOut += seg; });
      g.L.point.push(`<path d="${dIn}" stroke="var(--pl-d)" stroke-width="3" stroke-linecap="round"/><path d="${dOut}" stroke="var(--pl-b)" stroke-width="3" stroke-linecap="round" opacity=".6"/>`);
      g.text(M(30, 0), "A의 도착 시각(분)", { dy: 34, color: "muted", size: 12 });
      g.note(470, 40, "초록 띠: 만남", { color: "c", bold: true });
    },
    metrics(s) { const P = 1 - (1 - s.w / 60) ** 2, N = s.pts.length; return [["넓이로 구한 확률", `${fmt(P * 100, 2)}%`, "key"], ["실험", N ? `${s.hit}/${N} = ${fmt((100 * s.hit) / N, 1)}%` : "—"]]; },
  },
  {
    id: "pst-close-race", grade: 8, unit: 4, lesson: "Ⅳ 탐구 & 융합", title: "오차 범위 내 접전 — 두 후보 지지율 비교", type: "데이터", time: "10분",
    tags: ["모비율", "신뢰구간", "여론조사 해석"], links: ["pst-proportion", "pst-confidence"],
    desc: "두 후보의 실제 지지율과 조사 인원을 정하고 여론조사를 해 보며, 두 표본비율의 신뢰구간이 겹치면 '오차 범위 내 접전'이라고 말하는 이유를 봅니다.",
    obs: ["조사 결과는 매번 조금씩 다릅니다.", "신뢰구간이 겹치면 실제 순위를 확신하기 어렵습니다.", "조사 인원을 늘리면 구간이 좁아져 판단이 쉬워집니다."],
    q: "1000명 조사에서 42% 대 39%이면 ‘앞선다’고 보도해도 될까요?",
    formula: "p̂ ± 1.96√(p̂(1 − p̂)/n)",
    en: { title: "Too Close to Call", desc: "Overlapping confidence intervals of two candidates mean a statistical tie." },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [{ key: "p1", label: "A 후보 실제 지지율", min: 0.2, max: 0.6, step: 0.01, value: 0.42, show: (v) => `${Math.round(v * 100)}%` }, { key: "p2", label: "B 후보 실제 지지율", min: 0.2, max: 0.6, step: 0.01, value: 0.39, show: (v) => `${Math.round(v * 100)}%` }, { key: "n", label: "조사 인원 n", min: 200, max: 4000, step: 100, value: 1000 }],
    init: () => ({ polls: [] }),
    prefill(s) { for (let i = 0; i < 6; i++) s.polls.push(this.one(s)); },
    onChange(s) { s.polls = []; for (let i = 0; i < 6; i++) s.polls.push(this.one(s)); },
    buttons: [["poll", "여론조사 1번"], ["p10", "10번"], ["reset", "초기화"]],
    one(s) { const q = (p) => clamp(p + Math.sqrt((p * (1 - p)) / s.n) * randn(), 0, 1); return [q(s.p1), q(s.p2)]; },
    onDo(k, s) { if (k === "reset") s.polls = []; else for (let i = 0; i < (k === "p10" ? 10 : 1); i++) { s.polls.push(this.one(s)); if (s.polls.length > 12) s.polls.shift(); } },
    draw(s, g) {
      const M = (p) => 1.5 + ((p - 0.2) / 0.45) * 13.5;
      [0.2, 0.3, 0.4, 0.5, 0.6].forEach((p) => { g.seg([M(p), 0.6], [M(p), 10.6], { color: "grid", w: 1 }); g.text([M(p), 0.6], `${p * 100}%`, { dy: 16, size: 11.5, color: "muted" }); });
      g.seg([M(s.p1), 0.6], [M(s.p1), 10.6], { color: "a", w: 1.4, dash: "4 4" }).seg([M(s.p2), 0.6], [M(s.p2), 10.6], { color: "b", w: 1.4, dash: "4 4" });
      s.polls.forEach(([a, b], i) => {
        const y = 10 - i * 0.78, ea = 1.96 * Math.sqrt((a * (1 - a)) / s.n), eb = 1.96 * Math.sqrt((b * (1 - b)) / s.n), tie = Math.abs(a - b) < ea + eb;
        g.seg([M(a - ea), y + 0.12], [M(a + ea), y + 0.12], { color: "a", w: 4 }).seg([M(b - eb), y - 0.12], [M(b + eb), y - 0.12], { color: "b", w: 4 });
        g.text([15.3, y], tie ? "접전" : a > b ? "A 우세" : "B 우세", { dy: 4, anchor: "start", size: 11.5, color: tie ? "muted" : "d", bold: !tie });
      });
      if (!s.polls.length) g.note(200, 200, "‘여론조사’ 버튼을 눌러 보세요", { color: "muted", bold: true });
    },
    metrics(s) { const e = (p) => 1.96 * Math.sqrt((p * (1 - p)) / s.n), last = s.polls[s.polls.length - 1]; return [["오차 한계 (약)", `±${fmt(e(0.4) * 100, 1)}%p`], ["마지막 조사", last ? `A ${fmt(last[0] * 100, 1)}% · B ${fmt(last[1] * 100, 1)}%` : "—"], ["판정", last ? (Math.abs(last[0] - last[1]) < e(last[0]) + e(last[1]) ? "오차 범위 내 접전" : "차이가 오차 범위를 넘음") : "—", "key"]]; },
  },
  // ── 중1 ──
  {
    id: "m1-circle-terms", grade: 1, unit: 6, lesson: "6.5", title: "원의 용어 — 호·현·할선·부채꼴·활꼴", type: "2D", time: "8분",
    tags: ["호", "현", "활꼴"], color: "#2e79bd", links: ["sector", "g3-circle-chord"],
    desc: "원 위의 두 점을 움직이며 호, 현, 할선, 부채꼴, 활꼴, 중심각을 하나씩 색칠해 보고 서로 어떻게 다른지 확인합니다.",
    obs: ["현은 원 위의 두 점을 이은 선분이고, 할선은 그 두 점을 지나는 직선입니다.", "부채꼴은 두 반지름과 호로, 활꼴은 현과 호로 둘러싸인 도형입니다.", "지름은 가장 긴 현이며, 반원은 부채꼴이면서 활꼴입니다."],
    q: "활꼴과 부채꼴이 같아지는 경우는 언제일까요?",
    formula: "호 AB · 현 AB · 할선 AB · 부채꼴 AOB · 활꼴 · 중심각 ∠AOB",
    en: { title: "Parts of a Circle", desc: "Highlight arc, chord, secant, sector, segment and central angle." },
    view: V,
    params: [{ key: "term", label: "용어", type: "seg", value: "seg", options: [["arc", "호"], ["chord", "현"], ["sec", "할선"], ["sector", "부채꼴"], ["seg", "활꼴"], ["cang", "중심각"]] }, { key: "a", label: "점 A의 위치", min: 0, max: 360, step: 1, value: 200, unit: "°" }, { key: "b", label: "점 B의 위치", min: 0, max: 360, step: 1, value: 320, unit: "°" }],
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const R = 3.8, P = (d) => [R * Math.cos(deg(d)), R * Math.sin(deg(d))], A = P(s.a), B = P(s.b), span = ((s.b - s.a) % 360 + 360) % 360;
      const arcPts = Array.from({ length: 61 }, (_, i) => P(s.a + (span * i) / 60));
      g.circle([0, 0], R, { color: "muted", w: 1.8 });
      if (s.term === "arc") g.path(arcPts, { color: "a", w: 6 });
      if (s.term === "chord") g.seg(A, B, { color: "a", w: 5 });
      if (s.term === "sec") g.line(A, B, { color: "a", w: 3.4 });
      if (s.term === "sector") g.poly([[0, 0], ...arcPts], { fill: "a", fo: 0.35, color: "a", w: 2.4 });
      if (s.term === "seg") g.poly(arcPts, { fill: "a", fo: 0.35, color: "a", w: 2.4 });
      if (s.term === "cang") { g.seg([0, 0], A, { color: "ink", w: 2 }).seg([0, 0], B, { color: "ink", w: 2 }); g.arc([0, 0], A, B, { r: 40, color: "a", label: `${span}°` }); }
      g.point([0, 0], "O", { color: "ink", r: 4 }).point(A, "A").point(B, "B");
    },
    metrics(s) { const span = ((s.b - s.a) % 360 + 360) % 360; const d = { arc: "원 위의 두 점 A, B 사이의 원의 일부", chord: "원 위의 두 점을 이은 선분", sec: "원 위의 두 점을 지나는 직선", sector: "두 반지름 OA, OB와 호 AB로 둘러싸인 도형", seg: "현 AB와 호 AB로 둘러싸인 도형", cang: "두 반지름 OA, OB가 이루는 각" }[s.term]; return [["뜻", d, "key"], ["중심각", `${span}°`]]; },
  },
  {
    id: "m1-pattern", grade: 1, unit: 6, lesson: "6.8 프로젝트", title: "나만의 무늬 — 회전과 대칭으로 만드는 만다라", type: "조작", time: "10분",
    tags: ["회전대칭", "선대칭", "무늬"], color: "#2e79bd", links: ["lab-tessellation", "job-moves"],
    desc: "한 조각의 모양을 점으로 만들고 n번 돌려 붙이거나 거울처럼 뒤집어 붙여, 회전대칭과 선대칭을 가진 무늬를 설계합니다.",
    obs: ["360°를 n으로 나눈 각만큼 돌리면 같은 모양이 n번 반복됩니다.", "거울 대칭을 켜면 대칭축이 n개인 무늬가 됩니다.", "눈 결정은 6회전 대칭과 선대칭을 함께 가집니다."],
    q: "태극기의 태극 문양은 몇 회전 대칭일까요?",
    formula: "회전각 = 360° ÷ n",
    en: { title: "Design Your Own Pattern", desc: "Rotate and reflect a motif to build rosette patterns." },
    view: V, points: { P: [1.2, 3.2], Q: [0.2, 1.6], R: [1.6, 0.8] },
    params: [{ key: "n", label: "회전 횟수 n", min: 2, max: 12, step: 1, value: 6 }, { key: "mir", label: "거울 대칭도 함께", type: "check", value: true }],
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const base = [[0, 0], s.Q, s.P, s.R], cols = ["a", "b", "c", "e", "f", "d"];
      for (let k = 0; k < s.n; k++) { const a = (2 * Math.PI * k) / s.n; g.poly(base.map((p) => rot(p, a)), { fill: cols[k % 6], fo: 0.35, color: cols[k % 6], w: 1.6 }); if (s.mir) g.poly(base.map((p) => rot([-p[0], p[1]], a)), { fill: cols[(k + 3) % 6], fo: 0.25, color: cols[(k + 3) % 6], w: 1.2 }); }
      if (s.mir) for (let k = 0; k < s.n; k++) { const a = Math.PI / 2 + (Math.PI * k) / s.n; g.line([0, 0], [Math.cos(a), Math.sin(a)], { color: "muted", w: 1, dash: "3 6" }); }
      g.handle(s.P, "P").handle(s.Q, "Q").handle(s.R, "R");
    },
    metrics(s) { return [["회전각", `${fmt(360 / s.n, 1)}°`, "key"], ["회전대칭", `${s.n}회`], ["대칭축", s.mir ? `${s.n}개` : "없음"]]; },
  },
  // ── 수학실험실 ──
  {
    id: "lab-theodorus", grade: 9, unit: 1, lesson: "주제 1", title: "테오도로스의 나선 — √n을 그리다", type: "2D", time: "8분",
    tags: ["무리수", "피타고라스", "나선"], links: ["g2-pythagoras", "m2-pythag-proof"],
    desc: "빗변에 길이 1인 변을 직각으로 계속 붙여 √2, √3, √4, …의 길이를 차례로 만들며 무리수를 길이로 그립니다.",
    obs: ["k번째 빗변의 길이는 √(k + 1)입니다.", "√4 = 2, √9 = 3처럼 제곱수에서만 자연수 길이가 나옵니다.", "17번째 삼각형 근처에서 나선이 처음으로 겹치기 시작합니다."],
    q: "이 방법으로 수직선 위에 √5를 정확히 나타내려면 어떻게 할까요?",
    formula: "(√k)² + 1² = (√(k + 1))²",
    en: { title: "Spiral of Theodorus", desc: "Attach unit legs at right angles to build √2, √3, √4, …" },
    view: { x: [-6.4, 6.4], y: [-4.8, 4.8] },
    params: [{ key: "n", label: "삼각형 수", min: 1, max: 30, step: 1, value: 16 }],
    anim: { key: "n", min: 1, max: 30, speed: 3, label: "하나씩 붙이기" },
    draw(s, g) {
      const k = 0.9; let P = [k, 0], th = 0; const cols = ["a", "b", "c", "e", "f", "d"];
      for (let i = 1; i <= Math.round(s.n); i++) {
        const r = Math.sqrt(i), dir = [-Math.sin(th), Math.cos(th)], Q = add(P, mul(dir, k));
        g.poly([[0, 0], P, Q], { fill: cols[i % 6], fo: 0.28, color: "ink", w: 1 });
        const sq = Math.round(Math.sqrt(i + 1)), perfect = sq * sq === i + 1, nn = Math.round(s.n); g.text(mul(Q, 1 + 0.55 / Math.max(1, len(Q))), perfect ? `√${i + 1}=${sq}` : `√${i + 1}`, { size: nn > 20 ? 10 : 11.5, color: perfect ? "d" : cols[i % 6], bold: true });
        th = Math.atan2(Q[1], Q[0]); P = Q;
      }
    },
    metrics(s) { const n = Math.round(s.n); return [["마지막 빗변", `√${n + 1} ≈ ${fmt(Math.sqrt(n + 1), 4)}`, "key"], ["삼각형 수", String(n)]]; },
  },
  {
    id: "lab-figurate", grade: 9, unit: 2, lesson: "주제 2", title: "다각수 — 점으로 만드는 수열", type: "조작", time: "8분",
    tags: ["삼각수", "사각수", "등차수열"], links: ["pst-pascal"],
    desc: "점을 삼각형·사각형·오각형·육각형 모양으로 늘어놓아 만든 다각수를 그리고, 이웃한 항의 차가 등차수열을 이루는 것을 봅니다.",
    obs: ["삼각수의 차는 2, 3, 4, …처럼 1씩 커집니다.", "k각수의 차는 공차가 k − 2인 등차수열입니다.", "이웃한 두 삼각수의 합은 사각수입니다."],
    q: "10번째 오각수는 몇 개의 점으로 이루어질까요?",
    formula: "k각수 Pₙ = ((k − 2)n² − (k − 4)n) / 2",
    en: { title: "Figurate Numbers", desc: "Arrange dots in polygons and find arithmetic sequences in the differences." },
    view: V,
    params: [{ key: "k", label: "모양", type: "seg", value: 5, options: [[3, "삼각수"], [4, "사각수"], [5, "오각수"], [6, "육각수"]] }, { key: "n", label: "단계 n", min: 1, max: 8, step: 1, value: 5 }],
    anim: { key: "n", min: 1, max: 8, speed: 1.5, label: "단계 늘리기" },
    P(k, n) { return ((k - 2) * n * n - (k - 4) * n) / 2; },
    draw(s, g) {
      const k = s.k, n = Math.round(s.n), sp = 5.6 / Math.max(n, 3), O = [-3.6, -4.2], seen = new Set(), cols = ["a", "b", "c", "e", "f", "d", "a", "b"];
      for (let m = n; m >= 1; m--) {
        const side = (m - 1) * sp, V = Array.from({ length: k }, (_, i) => add(O, mul(rot([1, 0], (2 * Math.PI * i) / k + Math.PI * (k === 4 ? 0 : 0)), side)));
        const verts = [O]; let cur = O, a = 0;
        for (let i = 0; i < k; i++) { const nxt = add(cur, mul([Math.cos(a), Math.sin(a)], side)); verts.push(nxt); cur = nxt; a += (2 * Math.PI) / k; }
        if (m > 1) g.poly(verts.slice(0, k), { color: cols[m % 8], w: 1, opacity: 0.4 });
        for (let e = 0; e < k; e++) for (let j = 0; j < m; j++) { const p = lerp(verts[e], verts[e + 1], m > 1 ? j / (m - 1) : 0), key = p.map((v) => Math.round(v * 100)).join(","); if (!seen.has(key)) { seen.add(key); g.circle(p, Math.min(0.2, sp * 0.28), { color: cols[m % 8], fill: cols[m % 8], fo: 0.85, w: 0.8, layer: "point" }); } }
      }
      const seq = Array.from({ length: 8 }, (_, i) => this.P(k, i + 1));
      g.note(420, 40, `수열: ${seq.slice(0, n).join(", ")}`, { color: "ink", bold: true, size: 13 });
      g.note(420, 64, `차: ${seq.slice(1, n).map((v, i) => v - seq[i]).join(", ")}`, { color: "e", bold: true, size: 13 });
    },
    metrics(s) { const n = Math.round(s.n); return [[`${n}번째 ${["", "", "", "삼", "사", "오", "육"][s.k]}각수`, String(this.P(s.k, n)), "key"], ["차의 공차", String(s.k - 2)]]; },
  },
];
