// 수학실험실 — 교과 밖의 기하·통계 탐구 실험
import { fmt, frac, dist, sub, add, mul, norm, dot, len, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const G = 9;
const PHI = (1 + Math.sqrt(5)) / 2;
const V = { x: [-7, 7], y: [-5, 5] };
const ang = (v, p, q) => rad2deg(Math.acos(clamp(dot(sub(p, v), sub(q, v)) / (len(sub(p, v)) * len(sub(q, v)) || 1), -1, 1)));
const rot = (p, a) => [p[0] * Math.cos(a) - p[1] * Math.sin(a), p[0] * Math.sin(a) + p[1] * Math.cos(a)];
const gcd = (a, b) => (b ? gcd(b, a % b) : Math.abs(a));
const lineX = (p, u, q, v) => { const d = u[0] * v[1] - u[1] * v[0]; if (Math.abs(d) < 1e-12) return null; const t = ((q[0] - p[0]) * v[1] - (q[1] - p[1]) * v[0]) / d; return add(p, mul(u, t)); };
const binomP = (n, p, k) => { let c = 1; for (let i = 1; i <= k; i++) c = (c * (n - k + i)) / i; return c * p ** k * (1 - p) ** (n - k); };
// 많은 점을 가볍게 그리기
const dots = (g, pts, color, r = 1.6, layer = "fill") => { if (!pts.length) return; let d = ""; for (const p of pts) { const q = g.X(p); d += `M${q[0].toFixed(1)} ${q[1].toFixed(1)}h0`; } g.L[layer].push(`<path d="${d}" stroke="var(--pl-${color})" stroke-width="${r * 2}" stroke-linecap="round" fill="none" opacity="0.8"/>`); };
function circum(A, B, C) { const d = 2 * (A[0] * (B[1] - C[1]) + B[0] * (C[1] - A[1]) + C[0] * (A[1] - B[1])); return [((A[0] ** 2 + A[1] ** 2) * (B[1] - C[1]) + (B[0] ** 2 + B[1] ** 2) * (C[1] - A[1]) + (C[0] ** 2 + C[1] ** 2) * (A[1] - B[1])) / d, ((A[0] ** 2 + A[1] ** 2) * (C[0] - B[0]) + (B[0] ** 2 + B[1] ** 2) * (A[0] - C[0]) + (C[0] ** 2 + C[1] ** 2) * (B[0] - A[0])) / d]; }
const ccw = (A, B, C) => ((B[0] - A[0]) * (C[1] - A[1]) - (B[1] - A[1]) * (C[0] - A[0]) > 0 ? [A, B, C] : [A, C, B]);
const eqApex = (P, Q) => { const m = lerp(P, Q, 0.5), d = sub(Q, P); return add(m, mul([d[1], -d[0]], Math.sqrt(3) / 2)); }; // PQ의 오른쪽(바깥, 반시계 삼각형 기준)에 정삼각형

export default [
  // ───────── 1 곡선과 무늬 ─────────
  {
    id: "lab-golden-spiral", grade: G, unit: 1, lesson: "주제 1", title: "피보나치 사각형과 황금 나선", type: "2D", time: "8분",
    tags: ["피보나치", "황금비", "나선"], links: ["lab-sunflower"],
    desc: "피보나치 수를 한 변으로 하는 정사각형을 돌려 붙이고 사분원을 이어 황금 나선을 그리며, 이웃한 두 수의 비가 황금비로 다가가는 것을 봅니다.",
    obs: ["새 정사각형의 한 변은 앞의 두 정사각형의 변의 합입니다.", "Fₙ₊₁/Fₙ은 1.618…(황금비 φ)에 가까워집니다.", "전체 직사각형은 점점 황금 직사각형에 가까워집니다."],
    q: "황금비 φ는 φ² = φ + 1을 만족합니다. 피보나치 수의 규칙과 어떤 관계일까요?",
    formula: "Fₙ₊₂ = Fₙ₊₁ + Fₙ · lim Fₙ₊₁/Fₙ = φ = (1 + √5)/2",
    en: { title: "Fibonacci Squares and the Golden Spiral", desc: "Attach Fibonacci squares and join quarter arcs into a golden spiral." },
    view: V,
    params: [{ key: "n", label: "정사각형 수", min: 1, max: 14, step: 1, value: 9 }],
    anim: { key: "n", min: 1, max: 14, speed: 2, label: "하나씩 붙이기" },
    build(n) {
      const F = [1, 1]; while (F.length < n) F.push(F[F.length - 1] + F[F.length - 2]);
      const sq = [[0, 0, 1, 3]]; let b = { x0: 0, y0: 0, x1: 1, y1: 1 };
      for (let i = 1; i < n; i++) { const s = F[i], d = (i - 1) % 4; let q; if (d === 0) { q = [b.x1, b.y0, s, 0]; b.x1 += s; } else if (d === 1) { q = [b.x0, b.y1, s, 1]; b.y1 += s; } else if (d === 2) { q = [b.x0 - s, b.y0, s, 2]; b.x0 -= s; } else { q = [b.x0, b.y0 - s, s, 3]; b.y0 -= s; } sq.push(q); }
      return { sq, b, F };
    },
    draw(s, g) {
      const n = Math.round(s.n), { sq, b, F } = this.build(n), W = b.x1 - b.x0, H = b.y1 - b.y0, k = Math.min(13 / W, 9.4 / H), cx = (b.x0 + b.x1) / 2, cy = (b.y0 + b.y1) / 2, T = (p) => [(p[0] - cx) * k, (p[1] - cy) * k];
      const cols = ["a", "b", "c", "e", "f", "d"];
      sq.forEach(([x, y, s2, d], i) => {
        g.poly([T([x, y]), T([x + s2, y]), T([x + s2, y + s2]), T([x, y + s2])], { fill: cols[i % 6], fo: 0.14, color: "ink", w: 1.2 });
        const C = d === 0 ? [x, y + s2] : d === 1 ? [x, y] : d === 2 ? [x + s2, y] : [x + s2, y + s2], a0 = [-90, 0, 90, 180][d];
        g.param((u) => T([C[0] + s2 * Math.cos(deg(a0 + 90 * u)), C[1] + s2 * Math.sin(deg(a0 + 90 * u))]), 0, 1, { color: "a", w: 3, n: 40 });
        if (s2 * k > 0.7) g.text(T([x + s2 / 2, y + s2 / 2]), String(F[i]), { dy: 5, color: "muted", size: Math.min(20, 8 + s2 * k * 2) });
      });
    },
    metrics(s) { const n = Math.round(s.n), { F } = this.build(n + 1); return [["마지막 두 수", `${F[n - 1]}, ${F[n]}`], ["비 Fₙ₊₁/Fₙ", fmt(F[n] / F[n - 1], 6), "key"], ["황금비 φ", fmt(PHI, 6)]]; },
  },
  {
    id: "lab-sunflower", grade: G, unit: 1, lesson: "주제 1", title: "해바라기 씨앗의 배열과 황금각", type: "조작", time: "8분",
    tags: ["황금각", "137.5°", "자연 속 수학"], links: ["lab-golden-spiral"],
    desc: "씨앗을 한 개 놓을 때마다 일정한 각만큼 돌려 배치해, 황금각 137.5°에서만 빈틈없이 고르게 채워지는 해바라기 무늬를 확인합니다.",
    obs: ["회전각이 간단한 분수의 360° 배이면 씨앗이 몇 줄로 늘어서 틈이 생깁니다.", "황금각(360°/φ²)에서 가장 고르게 퍼집니다.", "나선의 개수는 피보나치 수가 됩니다."],
    q: "회전각을 120°로 하면 씨앗은 어떻게 놓일까요?",
    formula: "k번째 씨앗: 각 k·θ, 거리 c√k · 황금각 θ = 360°(1 − 1/φ) ≈ 137.508°",
    en: { title: "Sunflower Seeds and the Golden Angle", desc: "Place seeds at a fixed turning angle and see why 137.5° packs best." },
    view: V,
    params: [{ key: "a", label: "회전각 θ", min: 130, max: 145, step: 0.01, value: 137.51, unit: "°" }, { key: "n", label: "씨앗 수", min: 50, max: 1200, step: 10, value: 700 }],
    anim: { key: "a", min: 135, max: 140, speed: 0.4, label: "각 천천히 바꾸기" },
    draw(s, g) {
      const c = 4.6 / Math.sqrt(s.n), pts = [], pts2 = [];
      for (let k = 1; k <= s.n; k++) { const t = deg(s.a * k), r = c * Math.sqrt(k), p = [r * Math.cos(t), r * Math.sin(t)]; (k % 2 ? pts : pts2).push(p); }
      dots(g, pts, "f", Math.max(1.4, 5 - s.n / 250)); dots(g, pts2, "a", Math.max(1.4, 5 - s.n / 250));
    },
    metrics(s) { const golden = 360 * (1 - 1 / PHI); return [["회전각", `${fmt(s.a, 2)}°`], ["황금각", `${fmt(golden, 3)}°`], ["차이", `${fmt(s.a - golden, 3)}°`, "key"]]; },
  },
  {
    id: "lab-tessellation", grade: G, unit: 1, lesson: "주제 1", title: "테셀레이션 — 평면을 빈틈없이 덮기", type: "2D", time: "10분",
    tags: ["테셀레이션", "정다각형", "360°"], links: ["m1-why-five", "interior-sum"],
    desc: "정삼각형·정사각형·정육각형, 그리고 두 종류 정다각형을 섞은 준정규 무늬로 평면을 덮으며 한 꼭짓점에 모인 각의 합이 360°임을 확인합니다.",
    obs: ["한 종류의 정다각형만으로는 정삼각형·정사각형·정육각형만 평면을 덮습니다.", "정팔각형 2개와 정사각형 1개(135° + 135° + 90°)도 360°를 이룹니다.", "정육각형과 정삼각형을 번갈아 놓은 무늬도 있습니다(120° + 60° + 120° + 60°)."],
    q: "정오각형만으로는 왜 평면을 덮을 수 없을까요?",
    formula: "한 꼭짓점에 모인 내각의 합 = 360°",
    en: { title: "Tessellations", desc: "Cover the plane with regular polygons and check the 360° vertex rule." },
    view: V,
    params: [{ key: "t", label: "무늬", type: "select", value: "488", options: [["3", "정삼각형 (3.3.3.3.3.3)"], ["4", "정사각형 (4.4.4.4)"], ["6", "정육각형 (6.6.6)"], ["488", "정사각형 + 정팔각형 (4.8.8)"], ["3636", "정삼각형 + 정육각형 (3.6.3.6)"]] }, { key: "a", label: "한 변의 길이", min: 0.6, max: 1.6, step: 0.05, value: 1 }],
    draw(s, g) {
      const a = s.a, T = String(s.t), reg = (c, n, R, off, o) => g.poly(Array.from({ length: n }, (_, i) => add(c, [R * Math.cos(off + (2 * Math.PI * i) / n), R * Math.sin(off + (2 * Math.PI * i) / n)])), o);
      if (T === "4") for (let i = -8; i <= 8; i++) for (let j = -6; j <= 6; j++) reg([i * a, j * a], 4, a / Math.SQRT2, Math.PI / 4, { fill: (i + j) % 2 ? "b" : "c", fo: 0.3, color: "ink", w: 1.2 });
      if (T === "3") for (let i = -10; i <= 10; i++) for (let j = -7; j <= 7; j++) { const x = i * a + (j % 2 ? a / 2 : 0), y = (j * a * Math.sqrt(3)) / 2, h = (a * Math.sqrt(3)) / 2; g.poly([[x, y], [x + a, y], [x + a / 2, y + h]], { fill: "a", fo: 0.3, color: "ink", w: 1.2 }); g.poly([[x + a, y], [x + a / 2, y + h], [x + 1.5 * a, y + h]], { fill: "f", fo: 0.3, color: "ink", w: 1.2 }); }
      if (T === "6") for (let i = -6; i <= 6; i++) for (let j = -6; j <= 6; j++) reg([i * 1.5 * a, (j + (i % 2 ? 0.5 : 0)) * Math.sqrt(3) * a], 6, a, 0, { fill: ["a", "b", "c"][((i % 3) + 3) % 3], fo: 0.3, color: "ink", w: 1.2 });
      if (T === "488") { g.poly([[-8, -6], [8, -6], [8, 6], [-8, 6]], { fill: "e", fo: 0.35, stroke: false }); const sp = a * (1 + Math.SQRT2); for (let i = -6; i <= 6; i++) for (let j = -5; j <= 5; j++) reg([i * sp, j * sp], 8, a / (2 * Math.sin(Math.PI / 8)), Math.PI / 8, { fill: "paper", fo: 1, color: "ink", w: 1.2 }); for (let i = -6; i <= 6; i++) for (let j = -5; j <= 5; j++) reg([i * sp, j * sp], 8, a / (2 * Math.sin(Math.PI / 8)), Math.PI / 8, { fill: "b", fo: 0.3, color: "ink", w: 1.2 }); }
      if (T === "3636") { g.poly([[-8, -6], [8, -6], [8, 6], [-8, 6]], { fill: "f", fo: 0.35, stroke: false }); for (let i = -6; i <= 6; i++) for (let j = -6; j <= 6; j++) { const c = [i * 2 * a + j * a, j * Math.sqrt(3) * a]; reg(c, 6, a, Math.PI / 6, { fill: "paper", fo: 1, color: "ink", w: 1.2 }); reg(c, 6, a, Math.PI / 6, { fill: "c", fo: 0.3, color: "ink", w: 1.2 }); } }
    },
    metrics(s) { const m = { 3: "60° × 6", 4: "90° × 4", 6: "120° × 3", 488: "90° + 135° + 135°", 3636: "60° + 120° + 60° + 120°" }[s.t]; return [["한 꼭짓점의 각", m], ["합", "360°", "key"]]; },
  },
  {
    id: "lab-cycloid", grade: G, unit: 1, lesson: "주제 1", title: "굴러가는 원이 그리는 곡선", type: "조작", time: "10분",
    tags: ["사이클로이드", "에피사이클로이드", "하이포사이클로이드"], links: ["calc-param-motion", "lab-spirograph"],
    desc: "원이 직선 위, 다른 원의 바깥, 안쪽을 미끄러지지 않고 구를 때 원 위(또는 안팎)의 한 점이 그리는 자취를 그립니다.",
    obs: ["직선 위를 구르면 사이클로이드, 원 바깥을 구르면 에피사이클로이드(카디오이드 등)가 생깁니다.", "큰 원 안을 반지름 1/4인 원이 구르면 별 모양 아스트로이드가 생깁니다.", "점이 원 밖에 있으면 고리가 생깁니다(트로코이드)."],
    q: "사이클로이드 한 아치의 길이는 굴러가는 원 지름의 몇 배일까요?",
    formula: "x = r(t − d·sin t), y = r(1 − d·cos t)",
    en: { title: "Curves from Rolling Circles", desc: "Trace a point on a circle rolling along a line, outside or inside another circle." },
    view: V,
    params: [
      { key: "mode", label: "구르는 곳", type: "seg", value: "epi", options: [["line", "직선 위"], ["epi", "원의 바깥"], ["hypo", "원의 안쪽"]] },
      { key: "k", label: "큰 원 : 작은 원 반지름 비", min: 1, max: 6, step: 1, value: 1, when: (s) => s.mode !== "line" },
      { key: "d", label: "점의 위치 (원 위 = 1)", min: 0, max: 1.6, step: 0.05, value: 1 },
      { key: "t", label: "굴러간 정도", min: 0, max: 1, step: 0.002, value: 0.6, show: (v) => `${Math.round(v * 100)}%` },
    ],
    anim: { key: "t", min: 0, max: 1, speed: 0.12, loop: "wrap", label: "굴리기" },
    curve(s) {
      if (s.mode === "line") { const r = 1.1; return { r, T: 2 * 2 * Math.PI, P: (t) => [-6.5 + r * (t - s.d * Math.sin(t)), -3 + r * (1 - s.d * Math.cos(t))], C: (t) => [-6.5 + r * t, -3 + r] }; }
      const k = s.k, R = s.mode === "epi" ? 4.2 * (k / (k + 2)) : 4.4, r = R / k, T = 2 * Math.PI;
      if (s.mode === "epi") return { R, r, T, P: (t) => [(R + r) * Math.cos(t) - s.d * r * Math.cos(((R + r) / r) * t), (R + r) * Math.sin(t) - s.d * r * Math.sin(((R + r) / r) * t)], C: (t) => [(R + r) * Math.cos(t), (R + r) * Math.sin(t)] };
      return { R, r, T, P: (t) => [(R - r) * Math.cos(t) + s.d * r * Math.cos(((R - r) / r) * t), (R - r) * Math.sin(t) - s.d * r * Math.sin(((R - r) / r) * t)], C: (t) => [(R - r) * Math.cos(t), (R - r) * Math.sin(t)] };
    },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const c = this.curve(s), t = s.t * c.T;
      if (s.mode === "line") g.seg([-7, -3], [7, -3], { color: "ink", w: 2 }); else g.circle([0, 0], c.R, { color: "ink", w: 2, fill: "b", fo: 0.06 });
      g.param(c.P, 0, c.T, { color: "muted", w: 1.2, dash: "3 5", n: 800 });
      g.param(c.P, 0, t, { color: "a", w: 3.2, n: 800 });
      const Cc = c.C(t), P = c.P(t);
      g.circle(Cc, c.r, { color: "b", w: 2 }); g.seg(Cc, P, { color: "b", w: 1.6 }); g.point(P, "", { color: "a", r: 6 });
    },
    metrics(s) { const name = s.mode === "line" ? (s.d === 1 ? "사이클로이드" : "트로코이드") : s.mode === "epi" ? (s.k === 1 && s.d === 1 ? "카디오이드" : s.k === 2 && s.d === 1 ? "네프로이드" : "에피사이클로이드") : s.k === 4 && s.d === 1 ? "아스트로이드" : s.k === 2 && s.d === 1 ? "지름 (선분)" : s.k === 3 && s.d === 1 ? "델토이드" : "하이포사이클로이드"; return [["곡선 이름", name, "key"], ["뾰족점 수", s.mode === "line" || s.d !== 1 ? "—" : String(s.k)]]; },
  },
  {
    id: "lab-spirograph", grade: G, unit: 1, lesson: "주제 1", title: "스피로그래프", type: "조작", time: "8분",
    tags: ["하이포트로코이드", "최소공배수", "무늬"], links: ["lab-cycloid"],
    desc: "큰 고리 안에서 톱니바퀴를 굴리는 스피로그래프 장난감처럼, 두 반지름의 비와 펜 구멍의 위치로 다양한 꽃무늬를 만듭니다.",
    obs: ["반지름의 비가 간단한 분수일수록 빨리 닫힌 무늬가 됩니다.", "꽃잎의 수는 두 반지름을 기약분수로 나타낸 값과 관계있습니다."],
    q: "큰 원 96톱니, 작은 원 36톱니면 무늬는 몇 바퀴 만에 닫힐까요?",
    formula: "x = (R − r)cos t + d cos((R − r)t/r), y = (R − r)sin t − d sin((R − r)t/r)",
    en: { title: "Spirograph", desc: "Roll a gear inside a ring and draw flower patterns with a pen hole." },
    view: V,
    params: [{ key: "R", label: "큰 고리 톱니 수", min: 60, max: 120, step: 1, value: 96 }, { key: "r", label: "작은 바퀴 톱니 수", min: 20, max: 84, step: 1, value: 36 }, { key: "d", label: "펜 위치 (바퀴 반지름 비)", min: 0.2, max: 1, step: 0.02, value: 0.75 }, { key: "t", label: "그린 양", min: 0, max: 1, step: 0.002, value: 1, show: (v) => `${Math.round(v * 100)}%` }],
    anim: { key: "t", min: 0, max: 1, speed: 0.12, loop: "wrap", label: "그리기" },
    draw(s, g) {
      const k = 4.6 / s.R, R = s.R * k, r = s.r * k, d = s.d * r, turns = s.r / gcd(s.R, s.r), T = 2 * Math.PI * turns;
      const P = (t) => [(R - r) * Math.cos(t) + d * Math.cos(((R - r) / r) * t), (R - r) * Math.sin(t) - d * Math.sin(((R - r) / r) * t)];
      g.circle([0, 0], R, { color: "muted", w: 1.4 });
      g.param(P, 0, T * s.t, { color: "e", w: 1.6, n: Math.min(6000, 300 * turns) });
      const t = T * s.t, C = [(R - r) * Math.cos(t), (R - r) * Math.sin(t)];
      g.circle(C, r, { color: "b", w: 1.6, fill: "b", fo: 0.08 }); g.point(P(t), "", { color: "a", r: 5 });
    },
    metrics(s) { const gg = gcd(s.R, s.r); return [["기약분수 r/R", `${s.r / gg}/${s.R / gg}`], ["닫히기까지 바퀴 수", `${s.r / gg}바퀴`, "key"], ["꽃잎 수", String(s.R / gg)]]; },
  },
  {
    id: "lab-lissajous", grade: G, unit: 1, lesson: "주제 1", title: "리사주 곡선 — 두 진동의 합성", type: "조작", time: "8분",
    tags: ["리사주", "주파수 비", "위상"], links: ["alg-transform", "calc-param-motion"],
    desc: "가로와 세로로 서로 다른 빠르기의 진동을 합성해 만들어지는 리사주 곡선의 모양을 진동수의 비와 위상차로 바꿔 봅니다.",
    obs: ["가로·세로 진동수의 비가 a : b이면 곡선은 가로로 b번, 세로로 a번 봉우리를 가집니다.", "위상차 δ를 바꾸면 곡선이 입체처럼 도는 듯 보입니다."],
    q: "a = b이고 δ = 90°이면 어떤 곡선이 될까요?",
    formula: "x = A sin(at + δ), y = B sin(bt)",
    en: { title: "Lissajous Curves", desc: "Combine two perpendicular oscillations with different frequencies and phase." },
    view: V,
    params: [{ key: "a", label: "가로 진동수 a", min: 1, max: 7, step: 1, value: 3 }, { key: "b", label: "세로 진동수 b", min: 1, max: 7, step: 1, value: 4 }, { key: "d", label: "위상차 δ", min: 0, max: 180, step: 1, value: 45, unit: "°" }],
    anim: { key: "d", min: 0, max: 180, speed: 20, loop: "wrap", label: "위상 돌리기" },
    draw(s, g) { g.grid({ labels: false }); g.param((t) => [6 * Math.sin(s.a * t + deg(s.d)), 4.4 * Math.sin(s.b * t)], 0, 2 * Math.PI, { color: "a", w: 2.6, n: 1400 }); },
    metrics(s) { const gg = gcd(s.a, s.b); return [["진동수의 비", `${s.a / gg} : ${s.b / gg}`, "key"], ["위상차", `${s.d}°`]]; },
  },
  {
    id: "lab-cardioid", grade: G, unit: 1, lesson: "주제 1", title: "곱셈표 원에 숨은 카디오이드", type: "조작", time: "8분",
    tags: ["곱셈표", "나머지", "포락선"], links: ["calc-string-art", "lab-cycloid"],
    desc: "원 위에 n개의 점을 찍고 i번 점과 (k × i)번 점을 잇기만 하면 k = 2에서 카디오이드, k = 3에서 네프로이드가 나타납니다.",
    obs: ["곱하는 수 k가 2이면 뾰족점 1개인 카디오이드가 보입니다.", "k가 커질수록 뾰족점이 k − 1개인 곡선이 나타납니다.", "k가 정수가 아닐 때는 모양이 서서히 변합니다."],
    q: "k = 101로 하면 어떤 모양이 보일까요? n과의 관계를 생각해 보세요.",
    formula: "i번 점 → (k·i mod n)번 점",
    en: { title: "Cardioids in a Times Table Circle", desc: "Join point i to point k·i mod n and watch a cardioid appear." },
    view: V,
    params: [{ key: "n", label: "점의 수 n", min: 10, max: 400, step: 1, value: 200 }, { key: "k", label: "곱하는 수 k", min: 2, max: 30, step: 1, value: 2 }],
    anim: { key: "k", min: 2, max: 30, speed: 1.2, label: "k 바꾸기" },
    draw(s, g) {
      const R = 4.5, P = (i) => [R * Math.cos(Math.PI + (2 * Math.PI * i) / s.n), R * Math.sin(Math.PI + (2 * Math.PI * i) / s.n)];
      g.circle([0, 0], R, { color: "muted", w: 1.2 });
      let d = "";
      for (let i = 0; i < s.n; i++) { const a = g.X(P(i)), b = g.X(P((s.k * i) % s.n)); d += `M${a[0].toFixed(1)} ${a[1].toFixed(1)}L${b[0].toFixed(1)} ${b[1].toFixed(1)}`; }
      g.L.line.push(`<path d="${d}" stroke="var(--pl-d)" stroke-width="0.9" opacity="0.75" fill="none"/>`);
    },
    metrics(s) { const k = Math.round(s.k); return [["k", String(k)], ["보이는 곡선", k === 2 ? "카디오이드" : k === 3 ? "네프로이드" : `뾰족점 ${k - 1}개의 에피사이클로이드`, "key"]]; },
  },
  {
    id: "lab-mobius", grade: G, unit: 1, lesson: "주제 1", title: "뫼비우스의 띠", type: "3D", time: "10분",
    tags: ["뫼비우스 띠", "한 면", "위상수학"], links: ["net-fold"],
    desc: "띠를 반 바퀴씩 비틀어 붙이며 개미가 띠를 따라 걸을 때 한 바퀴 만에 반대쪽 면에 도착하는 뫼비우스의 띠를 관찰합니다.",
    obs: ["반 바퀴 비틀면 앞면과 뒷면의 구분이 없어집니다.", "개미는 두 바퀴를 돌아야 처음 자리로 돌아옵니다.", "한 바퀴(두 번 반 바퀴) 비틀면 다시 면이 두 개가 됩니다."],
    q: "뫼비우스의 띠를 가운데로 자르면 어떻게 될까요?",
    formula: "x = (R + v cos(nu/2))cos u, y = (R + v cos(nu/2))sin u, z = v sin(nu/2)",
    en: { title: "The Möbius Strip", desc: "Twist a strip by half turns and follow an ant that reaches the other side." },
    space: true, cam: { yaw: 30, pitch: 34, scale: 72 },
    params: [{ key: "tw", label: "반 바퀴 비튼 횟수", min: 0, max: 3, step: 1, value: 1 }, { key: "u", label: "개미의 위치", min: 0, max: 12.566, step: 0.02, value: 3, show: (v) => `${fmt(v / (2 * Math.PI), 2)}바퀴` }],
    anim: { key: "u", min: 0, max: 12.566, speed: 1.2, loop: "wrap", label: "개미 걷기" },
    P(s, u, v) { const R = 2.2, h = (s.tw * u) / 2; return [(R + v * Math.cos(h)) * Math.cos(u), (R + v * Math.cos(h)) * Math.sin(u), v * Math.sin(h)]; },
    draw(s, g) {
      const N = 90, w = 0.8;
      for (let i = 0; i < N; i++) { const u0 = (2 * Math.PI * i) / N, u1 = (2 * Math.PI * (i + 1)) / N; g.face([this.P(s, u0, -w), this.P(s, u1, -w), this.P(s, u1, w), this.P(s, u0, w)], { fill: i % 2 ? "b" : "c", color: "b", fo: 0.35, w: 0.4 }); }
      const path = []; for (let i = 0; i <= 200; i++) { const u = (s.u * i) / 200; path.push(this.P(s, u, w * 0.55)); }
      g.path(path, { color: "a", w: 2.6, bias: 0.5 });
      g.point(this.P(s, s.u, w * 0.55), "", { color: "a", r: 6, bias: 1 });
    },
    metrics(s) { return [["면의 수", s.tw % 2 ? "1개 (한 면)" : "2개", "key"], ["개미가 제자리로 오는 데", s.tw % 2 ? "두 바퀴" : "한 바퀴"]]; },
  },
  {
    id: "lab-ellipse-billiards", grade: G, unit: 1, lesson: "주제 1", title: "타원 당구대", type: "조작", time: "10분",
    tags: ["타원", "반사", "초점"], links: ["geo-ellipse", "geo-tangent-reflect"],
    desc: "타원 모양 당구대에서 한 초점을 지나도록 공을 치면 벽에 튕긴 뒤 반드시 다른 초점을 지나는 것을 여러 번 튕겨 확인합니다.",
    obs: ["한 초점을 지난 공은 반사 후 다른 초점을 지납니다.", "여러 번 튕기면 공의 길은 장축 쪽으로 모여듭니다.", "초점을 지나지 않게 치면 작은 타원이나 쌍곡선에 접하는 길이 만들어집니다."],
    q: "‘속삭이는 방’에서는 왜 한 초점의 속삭임이 다른 초점에서 잘 들릴까요?",
    formula: "PF + PF′ = 2a · 접선은 ∠FPF′의 외각을 이등분",
    en: { title: "Elliptical Billiards", desc: "Shoot a ball through one focus and it always passes the other after bouncing." },
    view: V,
    params: [{ key: "start", label: "출발점", type: "seg", value: "focus", options: [["focus", "초점 F′"], ["free", "다른 곳 (0, 1)"]] }, { key: "phi", label: "치는 방향", min: 0, max: 360, step: 1, value: 70, unit: "°" }, { key: "n", label: "튕기는 횟수", min: 1, max: 40, step: 1, value: 6 }],
    anim: { key: "n", min: 1, max: 40, speed: 3, label: "계속 튕기기" },
    path(s) {
      const a = 6, b = 3.8, c = Math.sqrt(a * a - b * b); let P = s.start === "focus" ? [-c, 0] : [0, 1], d = [Math.cos(deg(s.phi)), Math.sin(deg(s.phi))];
      const pts = [P];
      for (let k = 0; k < Math.round(s.n); k++) {
        const A = d[0] ** 2 / a ** 2 + d[1] ** 2 / b ** 2, B = 2 * (P[0] * d[0] / a ** 2 + P[1] * d[1] / b ** 2), Cq = P[0] ** 2 / a ** 2 + P[1] ** 2 / b ** 2 - 1;
        const t = (-B + Math.sqrt(Math.max(0, B * B - 4 * A * Cq))) / (2 * A); P = add(P, mul(d, t)); pts.push(P);
        const nrm = norm([P[0] / a ** 2, P[1] / b ** 2]); d = sub(d, mul(nrm, 2 * dot(d, nrm))); P = add(P, mul(d, 1e-7));
      }
      return { pts, c };
    },
    draw(s, g) {
      const { pts, c } = this.path(s);
      g.param((u) => [6 * Math.cos(u), 3.8 * Math.sin(u)], 0, 6.3, { color: "c", w: 5 });
      g.poly(Array.from({ length: 80 }, (_, i) => [6 * Math.cos((i / 80) * 2 * Math.PI), 3.8 * Math.sin((i / 80) * 2 * Math.PI)]), { fill: "c", fo: 0.08, stroke: false });
      g.path(pts, { color: "a", w: 1.8 });
      g.point([c, 0], "F", { color: "ink", dy: 20 }).point([-c, 0], "F′", { color: "ink", dy: 20 });
      g.circle(pts[pts.length - 1], 0.22, { color: "a", fill: "a", fo: 1 });
    },
    metrics(s) { return [["튕긴 횟수", String(Math.round(s.n))], ["출발", s.start === "focus" ? "초점에서 출발 → 모든 경로가 두 초점을 번갈아 지남" : "초점이 아닌 곳에서 출발", "key"]]; },
  },
  {
    id: "lab-reuleaux", grade: G, unit: 1, lesson: "주제 1", title: "뢸로 삼각형 — 원이 아닌데 폭이 일정한 도형", type: "조작", time: "8분",
    tags: ["정폭 도형", "뢸로 삼각형", "맨홀"], links: ["g2-circumcenter", "lab-euler-line"],
    desc: "정삼각형의 각 꼭짓점을 중심으로 원호를 그린 뢸로 삼각형을 두 평행선 사이에서 돌려, 어느 방향으로도 폭이 같음을 확인합니다.",
    obs: ["돌려도 위아래 두 평행선에 항상 닿아 있습니다.", "그러나 중심은 한 점에 머물지 않고 움직입니다.", "둘레는 원과 같이 π × 폭입니다(바르비에 정리)."],
    q: "맨홀 뚜껑을 뢸로 삼각형으로 만들어도 구멍에 빠지지 않을까요?",
    formula: "폭 w로 일정 · 둘레 = πw · 넓이 = (π − √3)w²/2",
    en: { title: "Reuleaux Triangle", desc: "Rotate a curve of constant width between two parallel lines." },
    view: V,
    params: [{ key: "th", label: "회전각", min: 0, max: 360, step: 1, value: 20, unit: "°" }],
    anim: { key: "th", min: 0, max: 360, speed: 40, loop: "wrap", label: "돌리기" },
    shape(s) {
      const w = 4, V3 = [0, 1, 2].map((i) => [(w / Math.sqrt(3)) * Math.cos(Math.PI / 2 + (2 * Math.PI * i) / 3), (w / Math.sqrt(3)) * Math.sin(Math.PI / 2 + (2 * Math.PI * i) / 3)]), pts = [];
      for (let i = 0; i < 3; i++) { const C = V3[i], P1 = V3[(i + 1) % 3], a1 = Math.atan2(P1[1] - C[1], P1[0] - C[0]); for (let k = 0; k <= 30; k++) pts.push(add(C, [w * Math.cos(a1 + (Math.PI / 3) * (k / 30)), w * Math.sin(a1 + (Math.PI / 3) * (k / 30))])); }
      const R = pts.map((p) => rot(p, deg(s.th))), ymin = Math.min(...R.map((p) => p[1])), sh = (p) => [p[0] - 1, p[1] - ymin - 2];
      return { pts: R.map(sh), V: V3.map((v) => sh(rot(v, deg(s.th)))), cen: sh([0, 0]), w };
    },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const S = this.shape(s);
      g.seg([-7, -2], [7, -2], { color: "ink", w: 2.4 }).seg([-7, 2], [7, 2], { color: "ink", w: 2.4 });
      g.poly(S.pts, { fill: "f", fo: 0.3, color: "f", w: 2.6 });
      g.poly(S.V, { color: "muted", w: 1, dash: "4 4" });
      g.point(S.cen, "중심", { color: "d", r: 4 });
      g.circle([4.5, 0], 2, { color: "b", w: 1.6, dash: "5 5" }); g.text([4.5, 0], "같은 폭의 원", { dy: 4, color: "b", size: 12 });
    },
    metrics(s) { const S = this.shape(s), ys = S.pts.map((p) => p[1]); return [["폭 (위 − 아래)", fmt(Math.max(...ys) - Math.min(...ys), 3), "key"], ["둘레 πw", fmt(Math.PI * 4, 3)]]; },
  },

  // ───────── 2 프랙털과 무한 ─────────
  {
    id: "lab-koch", grade: G, unit: 2, lesson: "주제 2", title: "코흐 눈송이 — 둘레는 무한, 넓이는 유한", type: "2D", time: "10분",
    tags: ["프랙털", "무한등비급수", "자기닮음"], links: ["lab-sierpinski", "calc-riemann"],
    desc: "정삼각형의 각 변을 3등분해 가운데에 작은 정삼각형을 붙이는 과정을 되풀이하며 둘레는 끝없이 커지지만 넓이는 일정한 값에 수렴함을 봅니다.",
    obs: ["한 단계마다 변의 수는 4배, 한 변의 길이는 1/3배가 되어 둘레는 4/3배가 됩니다.", "넓이는 처음 넓이의 8/5배에 수렴합니다.", "어느 부분을 확대해도 전체와 닮은 모양이 나타납니다."],
    q: "해안선의 길이를 재는 자의 눈금에 따라 값이 달라지는 이유를 코흐 곡선으로 설명해 보세요.",
    formula: "둘레 Lₙ = L₀(4/3)ⁿ → ∞ · 넓이 → (8/5)S₀",
    en: { title: "Koch Snowflake", desc: "Infinite perimeter, finite area." },
    view: V,
    params: [{ key: "n", label: "단계", min: 0, max: 6, step: 1, value: 3 }],
    pts(n) {
      let P = [0, 1, 2].map((i) => [4.6 * Math.cos(Math.PI / 2 + (2 * Math.PI * i) / 3), 4.6 * Math.sin(Math.PI / 2 + (2 * Math.PI * i) / 3) - 0.6]);
      for (let k = 0; k < n; k++) { const Q = []; for (let i = 0; i < P.length; i++) { const a = P[i], b = P[(i + 1) % P.length], p1 = lerp(a, b, 1 / 3), p2 = lerp(a, b, 2 / 3), d = sub(p2, p1), tip = add(p1, rot(d, -Math.PI / 3)); Q.push(a, p1, tip, p2); } P = Q; }
      return P;
    },
    draw(s, g) { g.poly(this.pts(s.n), { fill: "b", fo: 0.2, color: "b", w: s.n > 4 ? 0.8 : 1.6 }); },
    metrics(s) { let area = 1, add1 = 1 / 3; for (let k = 1; k <= s.n; k++) { area += (3 * 4 ** (k - 1)) / 9 ** k; } return [["변의 수", String(3 * 4 ** s.n)], ["둘레 (처음 = 1)", fmt((4 / 3) ** s.n, 4)], ["넓이 (처음 = 1)", fmt(area, 5), "key"], ["넓이의 극한", "8/5 = 1.6"]]; },
  },
  {
    id: "lab-sierpinski", grade: G, unit: 2, lesson: "주제 2", title: "시에르핀스키 삼각형", type: "2D", time: "8분",
    tags: ["프랙털", "넓이 → 0", "파스칼"], links: ["pst-pascal", "lab-chaos-game"],
    desc: "정삼각형에서 가운데 삼각형을 계속 빼내며 남은 삼각형의 개수와 넓이가 어떻게 변하는지 봅니다.",
    obs: ["한 단계마다 삼각형 수는 3배, 넓이는 3/4배가 됩니다.", "무한히 반복하면 넓이는 0에 가까워집니다.", "파스칼 삼각형의 홀수를 칠해도 같은 무늬가 나옵니다."],
    q: "10단계 뒤에 남은 넓이는 처음의 몇 % 정도일까요?",
    formula: "삼각형 3ⁿ개 · 넓이 (3/4)ⁿ",
    en: { title: "Sierpinski Triangle", desc: "Remove middle triangles repeatedly and track count and area." },
    view: V,
    params: [{ key: "n", label: "단계", min: 0, max: 7, step: 1, value: 5 }],
    draw(s, g) {
      const go = (a, b, c, k) => { if (!k) { g.poly([a, b, c], { fill: "e", fo: 0.6, color: "e", w: 0.4 }); return; } const ab = lerp(a, b, 0.5), bc = lerp(b, c, 0.5), ca = lerp(c, a, 0.5); go(a, ab, ca, k - 1); go(ab, b, bc, k - 1); go(ca, bc, c, k - 1); };
      go([-5.4, -4.4], [5.4, -4.4], [0, 4.95], s.n);
    },
    metrics(s) { return [["삼각형 수 3ⁿ", String(3 ** s.n)], ["남은 넓이 (3/4)ⁿ", `${fmt(0.75 ** s.n * 100, 2)}%`, "key"]]; },
  },
  {
    id: "lab-chaos-game", grade: G, unit: 2, lesson: "주제 2", title: "카오스 게임 — 무작위로 그리는 질서", type: "데이터", time: "8분",
    tags: ["카오스 게임", "무작위", "프랙털"], links: ["lab-sierpinski"],
    desc: "꼭짓점 하나를 무작위로 골라 그쪽으로 일정 비율만큼 다가가는 점을 수천 번 찍으면, 무작위인데도 시에르핀스키 삼각형 같은 규칙적인 무늬가 나타납니다.",
    obs: ["삼각형에서 절반씩 다가가면 시에르핀스키 삼각형이 됩니다.", "꼭짓점 수와 비율을 바꾸면 다른 프랙털이 나옵니다.", "처음 몇 개의 점을 빼면 출발점과 상관없이 같은 무늬가 생깁니다."],
    q: "정사각형에서 절반씩 다가가면 왜 무늬 없이 꽉 차게 될까요?",
    formula: "Pₙ₊₁ = Pₙ + r(Vₖ − Pₙ), Vₖ는 무작위로 고른 꼭짓점",
    en: { title: "The Chaos Game", desc: "Random jumps toward vertices reveal an orderly fractal." },
    view: V,
    params: [{ key: "k", label: "꼭짓점 수", min: 3, max: 6, step: 1, value: 3 }, { key: "r", label: "다가가는 비율 r", min: 0.3, max: 0.7, step: 0.01, value: 0.5 }],
    init: () => ({ pts: [], cur: [0.1, 0.2] }),
    prefill(s) { this.jump(s, 4000); },
    onChange(s, k) { if (k === "k" || k === "r") { s.pts = []; s.cur = [0.1, 0.2]; this.jump(s, 4000); } },
    V(s) { return Array.from({ length: s.k }, (_, i) => [5 * Math.cos(Math.PI / 2 + (2 * Math.PI * i) / s.k), 4.8 * Math.sin(Math.PI / 2 + (2 * Math.PI * i) / s.k) - (s.k === 3 ? 0.4 : 0)]); },
    buttons: [["b2000", "점 2000개 찍기"], ["reset", "지우기"]],
    jump(s, m) { const V3 = this.V(s); for (let i = 0; i < m && s.pts.length < 30000; i++) { const v = V3[Math.floor(Math.random() * s.k)]; s.cur = lerp(s.cur, v, s.r); if (i > 5 || s.pts.length) s.pts.push(s.cur); } },
    onDo(k, s) { if (k === "reset") { s.pts = []; s.cur = [0.1, 0.2]; } else this.jump(s, 2000); },
    anim: { label: "계속 찍기", step(s, dt, sp) { sp.jump(s, Math.max(20, Math.round(1500 * dt))); } },
    draw(s, g) { const V3 = this.V(s); V3.forEach((v) => g.point(v, "", { color: "ink", r: 5 })); dots(g, s.pts, "e", 0.9); if (!s.pts.length) g.note(200, 30, "‘점 찍기’를 눌러 시작하세요", { color: "muted", bold: true }); },
    metrics(s) { return [["찍은 점", String(s.pts.length)], ["규칙", `꼭짓점 ${s.k}개 · 비율 ${fmt(s.r, 2)}`, "key"]]; },
  },
  {
    id: "lab-pythagoras-tree", grade: G, unit: 2, lesson: "주제 2", title: "피타고라스 나무", type: "2D", time: "8분",
    tags: ["프랙털", "피타고라스", "재귀"], links: ["g2-pythagoras", "m2-pythag-proof"],
    desc: "정사각형 위에 직각삼각형을 올리고 두 빗변 위에 다시 정사각형을 붙이는 과정을 되풀이해 나무 모양 프랙털을 만듭니다.",
    obs: ["각 단계의 두 작은 정사각형 넓이의 합은 큰 정사각형의 넓이와 같습니다.", "그래서 단계마다 새로 더해지는 넓이의 합은 처음 정사각형의 넓이와 같습니다.", "각을 바꾸면 한쪽으로 기운 나무가 됩니다."],
    q: "n단계까지 그린 정사각형들의 넓이의 합은 처음 정사각형의 몇 배일까요?",
    formula: "a² + b² = c² (각 가지마다)",
    en: { title: "Pythagoras Tree", desc: "Grow a fractal tree by stacking squares on right triangles." },
    view: { x: [-7, 7], y: [-4.4, 5.6] },
    params: [{ key: "n", label: "단계", min: 0, max: 11, step: 1, value: 8 }, { key: "a", label: "왼쪽 가지 각", min: 20, max: 70, step: 1, value: 45, unit: "°" }],
    anim: { key: "a", min: 20, max: 70, speed: 8, label: "바람 불기" },
    draw(s, g) {
      const cols = ["f", "c", "b", "e", "a", "d"], A = deg(s.a);
      const go = (p, q, k) => { const d = sub(q, p), nrm = [-d[1], d[0]], r = add(q, nrm), l = add(p, nrm); g.poly([p, q, r, l], { fill: cols[k % 6], fo: 0.45, color: cols[k % 6], w: 0.6 }); if (k >= s.n) return; const L = len(d), top = add(l, mul(rot(d, A), Math.cos(A))); go(l, top, k + 1); go(top, r, k + 1); };
      go([-0.9, -4.2], [0.9, -4.2], 0);
    },
    metrics(s) { return [["정사각형 수", String(2 ** (s.n + 1) - 1)], ["넓이의 합 (처음 = 1)", String(s.n + 1), "key"]]; },
  },
  {
    id: "lab-zeno", grade: G, unit: 2, lesson: "주제 2", title: "정사각형으로 보는 무한등비급수", type: "조작", time: "8분",
    tags: ["무한등비급수", "제논의 역설", "극한"], links: ["lab-koch"],
    desc: "넓이 1인 정사각형을 절반씩(또는 1/4씩) 계속 잘라 칠하며 1/2 + 1/4 + 1/8 + … = 1, 1/4 + 1/16 + … = 1/3이 되는 까닭을 봅니다.",
    obs: ["항을 아무리 많이 더해도 정사각형을 넘지 않습니다.", "남은 부분이 0에 가까워지므로 합은 1입니다.", "1/4씩 자르면 세 색이 똑같이 나눠 가져 각각 1/3이 됩니다."],
    q: "아킬레스는 왜 거북을 따라잡을 수 있을까요?",
    formula: "a/(1 − r) (|r| < 1)",
    en: { title: "Geometric Series in a Square", desc: "Keep halving (or quartering) a unit square to see an infinite sum converge." },
    view: { x: [-6.4, 6.4], y: [-4.8, 4.8] },
    params: [{ key: "mode", label: "나누기", type: "seg", value: "half", options: [["half", "1/2씩"], ["quarter", "1/4씩 (세 색)"]] }, { key: "n", label: "항의 수", min: 1, max: 14, step: 1, value: 6 }],
    anim: { key: "n", min: 1, max: 14, speed: 2.5, label: "하나씩 더하기" },
    draw(s, g) {
      const n = Math.round(s.n), S = 9, O = [-4.5, -4.5];
      g.poly([O, add(O, [S, 0]), add(O, [S, S]), add(O, [0, S])], { color: "ink", w: 2 });
      let x = O[0], y = O[1], w = S, h = S; const cols = ["a", "b", "c", "e", "f", "d"];
      if (s.mode === "half") for (let k = 0; k < n; k++) { if (k % 2 === 0) { g.poly([[x, y], [x + w / 2, y], [x + w / 2, y + h], [x, y + h]], { fill: cols[k % 6], fo: 0.45, color: "ink", w: 1 }); if (w > 0.8) g.text([x + w / 4, y + h / 2], `1/${2 ** (k + 1)}`, { dy: 5, size: 13, bold: true }); x += w / 2; w /= 2; } else { g.poly([[x, y], [x + w, y], [x + w, y + h / 2], [x, y + h / 2]], { fill: cols[k % 6], fo: 0.45, color: "ink", w: 1 }); if (h > 0.8) g.text([x + w / 2, y + h / 4], `1/${2 ** (k + 1)}`, { dy: 5, size: 13, bold: true }); y += h / 2; h /= 2; } }
      else for (let k = 0; k < n; k++) { const q = w / 2; [[x, y], [x + q, y], [x, y + q]].forEach((p, i) => g.poly([p, add(p, [q, 0]), add(p, [q, q]), add(p, [0, q])], { fill: ["a", "b", "c"][i], fo: 0.45, color: "ink", w: 0.8 })); x += q; y += q; w = q; }
    },
    metrics(s) { const n = Math.round(s.n); if (s.mode === "half") { const S = 1 - 0.5 ** n; return [["부분합", fmt(S, 6)], ["남은 넓이", fmt(1 - S, 6)], ["극한", "1", "key"]]; } const S = (1 - 0.25 ** n) / 3; return [["한 색의 부분합", fmt(S, 6)], ["극한", "1/3", "key"]]; },
  },

  // ───────── 3 삼각형의 신비 ─────────
  {
    id: "lab-euler-line", grade: G, unit: 3, lesson: "주제 3", title: "오일러 직선과 구점원", type: "조작", time: "12분",
    tags: ["외심", "무게중심", "수심"], links: ["m2-triangle-centers", "c2-centroid"],
    desc: "삼각형의 외심 O, 무게중심 G, 수심 H가 항상 한 직선 위에 있고 OG : GH = 1 : 2임을, 그리고 아홉 개의 특별한 점을 지나는 구점원을 확인합니다.",
    obs: ["O, G, H는 정삼각형이 아니면 한 직선 위에 있습니다.", "G는 선분 OH를 1 : 2로 내분합니다.", "세 변의 중점, 세 수선의 발, 꼭짓점과 H의 중점 세 개가 한 원 위에 있습니다."],
    q: "정삼각형에서는 오일러 직선이 어떻게 될까요?",
    formula: "OG : GH = 1 : 2 · 구점원의 반지름 = R/2",
    en: { title: "Euler Line and Nine-Point Circle", desc: "Circumcenter, centroid and orthocenter are collinear with OG : GH = 1 : 2." },
    view: V, points: { A: [-1, 3.8], B: [-5, -3], C: [5.2, -2.4] },
    params: [{ key: "nine", label: "구점원 보기", type: "check", value: true }],
    K(s) { const { A, B, C } = s, O = circum(A, B, C), Gc = mul(add(add(A, B), C), 1 / 3), H = sub(add(add(A, B), C), mul(O, 2)); return { O, G: Gc, H, R: dist(O, A), N: lerp(O, H, 0.5) }; },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const { A, B, C } = s, K = this.K(s);
      g.poly([A, B, C], { fill: "b", fo: 0.06, color: "ink", w: 2.4 });
      g.circle(K.O, K.R, { color: "muted", w: 1.2, dash: "4 5" });
      if (dist(K.O, K.H) > 0.05) g.line(K.O, K.H, { color: "d", w: 2.4 });
      if (s.nine) { g.circle(K.N, K.R / 2, { color: "c", w: 2 }); [lerp(A, B, 0.5), lerp(B, C, 0.5), lerp(C, A, 0.5), lerp(A, K.H, 0.5), lerp(B, K.H, 0.5), lerp(C, K.H, 0.5)].forEach((p) => g.point(p, "", { color: "c", r: 3.5 })); [[A, B, C], [B, C, A], [C, A, B]].forEach(([p, q, r]) => { const u = norm(sub(r, q)), F = add(q, mul(u, dot(sub(p, q), u))); g.seg(p, F, { color: "muted", w: 1, dash: "3 4" }); g.point(F, "", { color: "c", r: 3.5 }); }); }
      g.point(K.O, "O", { color: "a" }).point(K.G, "G", { color: "e" }).point(K.H, "H", { color: "d" });
      g.point(A, "A").point(B, "B", { dy: 20 }).point(C, "C", { dy: 20 }).handle(A, "A").handle(B, "B").handle(C, "C");
    },
    metrics(s) { const K = this.K(s); return [["OG", fmt(dist(K.O, K.G), 3)], ["GH", fmt(dist(K.G, K.H), 3)], ["OG : GH", dist(K.O, K.G) > 1e-6 ? `1 : ${fmt(dist(K.G, K.H) / dist(K.O, K.G), 3)}` : "한 점 (정삼각형)", "key"]]; },
  },
  {
    id: "lab-napoleon", grade: G, unit: 3, lesson: "주제 3", title: "나폴레옹의 정리", type: "조작", time: "8분",
    tags: ["정삼각형", "무게중심", "불변"], links: ["lab-fermat"],
    desc: "어떤 삼각형이든 세 변 위에 바깥쪽으로 정삼각형을 붙이고 그 중심들을 이으면 언제나 정삼각형이 되는 것을 확인합니다.",
    obs: ["처음 삼각형의 모양과 상관없이 가운데 삼각형은 정삼각형입니다.", "그 중심은 처음 삼각형의 무게중심과 같습니다."],
    q: "정삼각형을 안쪽으로 붙여도 같은 결과가 나올까요?",
    formula: "세 정삼각형의 중심을 이은 삼각형은 정삼각형",
    en: { title: "Napoleon's Theorem", desc: "Centers of outward equilateral triangles always form an equilateral triangle." },
    view: V, points: { A: [-0.6, 2.0], B: [-2.2, -0.8], C: [2.0, -0.5] },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const [A, B, C] = ccw(s.A, s.B, s.C), sides = [[A, B], [B, C], [C, A]], cen = [];
      sides.forEach(([p, q], i) => { const T = eqApex(p, q); g.poly([p, q, T], { fill: ["a", "b", "c"][i], fo: 0.18, color: ["a", "b", "c"][i], w: 1.6 }); const c = mul(add(add(p, q), T), 1 / 3); cen.push(c); g.point(c, "", { color: ["a", "b", "c"][i], r: 4.5 }); });
      g.poly([s.A, s.B, s.C], { fill: "paper", fo: 0.5, color: "ink", w: 2.4 });
      g.poly(cen, { fill: "d", fo: 0.12, color: "d", w: 3 });
      g.point(s.A, "A").point(s.B, "B").point(s.C, "C").handle(s.A, "A").handle(s.B, "B").handle(s.C, "C");
    },
    metrics(s) { const [A, B, C] = ccw(s.A, s.B, s.C), cen = [[A, B], [B, C], [C, A]].map(([p, q]) => mul(add(add(p, q), eqApex(p, q)), 1 / 3)); return [["세 변의 길이", cen.map((c, i) => fmt(dist(c, cen[(i + 1) % 3]), 3)).join(" · "), "key"]]; },
  },
  {
    id: "lab-fermat", grade: G, unit: 3, lesson: "주제 3", title: "페르마 점 — 세 마을을 잇는 가장 짧은 길", type: "조작", time: "10분",
    tags: ["최솟값", "120°", "페르마 점"], links: ["lab-napoleon", "c2-shortest"],
    desc: "세 마을 A, B, C까지의 거리의 합이 가장 작은 점 P를 직접 찾아보고, 그 점에서 세 선분이 120°씩 벌어져 있음을 확인합니다.",
    obs: ["P를 움직이면 PA + PB + PC가 변합니다.", "모든 각이 120°보다 작으면, 최소가 되는 점에서 세 선분은 서로 120°를 이룹니다.", "각 변에 붙인 정삼각형의 꼭짓점과 마주 보는 꼭짓점을 이은 세 선이 그 점에서 만납니다."],
    q: "한 각이 120° 이상이면 최단 지점은 어디일까요?",
    formula: "∠APB = ∠BPC = ∠CPA = 120°",
    en: { title: "Fermat Point", desc: "Find the point minimizing the total distance to three towns." },
    view: V, points: { A: [-0.8, 3.6], B: [-5, -2.6], C: [4.6, -2.6], P: [0.8, 0.8] },
    params: [{ key: "cons", label: "작도로 찾은 페르마 점 보기", type: "check", value: false }],
    F(s) { const [A, B, C] = ccw(s.A, s.B, s.C), TA = eqApex(B, C), TB = eqApex(C, A); return lineX(A, sub(TA, A), B, sub(TB, B)); },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const { A, B, C, P } = s;
      g.poly([A, B, C], { fill: "c", fo: 0.06, color: "muted", w: 1.4 });
      [A, B, C].forEach((X) => g.seg(P, X, { color: "a", w: 2.8 }));
      if (s.cons) { const F = this.F(s); if (F) { g.point(F, "F", { color: "d", r: 6 }); const [A2, B2, C2] = ccw(A, B, C); [[B2, C2, A2], [C2, A2, B2], [A2, B2, C2]].forEach(([p, q, r]) => { const T = eqApex(p, q); g.poly([p, q, T], { fill: "e", fo: 0.08, color: "e", w: 1 }); g.seg(r, T, { color: "e", w: 1, dash: "4 4" }); }); } }
      g.point(A, "A").point(B, "B", { dy: 20 }).point(C, "C", { dy: 20 }).point(P, "P", { color: "a", r: 6.5 });
      g.handle(P, "P").handle(A, "A", { color: "b" }).handle(B, "B", { color: "b" }).handle(C, "C", { color: "b" });
    },
    metrics(s) { const { A, B, C, P } = s, sum = dist(P, A) + dist(P, B) + dist(P, C), F = this.F(s), mn = F ? dist(F, A) + dist(F, B) + dist(F, C) : NaN; return [["PA + PB + PC", fmt(sum, 3)], ["최솟값", Number.isFinite(mn) ? fmt(mn, 3) : "—", "key"], ["∠APB · ∠BPC · ∠CPA", `${fmt(ang(P, A, B), 0)}° · ${fmt(ang(P, B, C), 0)}° · ${fmt(ang(P, C, A), 0)}°`]]; },
  },
  {
    id: "lab-morley", grade: G, unit: 3, lesson: "주제 3", title: "몰리의 삼등분선 정리", type: "조작", time: "10분",
    tags: ["각의 삼등분", "정삼각형", "놀라운 정리"], links: ["lab-napoleon"],
    desc: "삼각형 세 각을 각각 삼등분한 선들 가운데 한 변에 가까운 두 선의 교점 세 개를 이으면, 어떤 삼각형이든 정삼각형이 됩니다.",
    obs: ["처음 삼각형의 모양과 상관없이 몰리 삼각형은 정삼각형입니다.", "이 사실은 1899년에야 발견되었습니다."],
    q: "왜 이렇게 늦게 발견되었을지 생각해 보세요. (힌트: 각의 삼등분은 자와 컴퍼스로 작도할 수 없습니다.)",
    formula: "몰리 삼각형의 한 변 = 8R sin(A/3) sin(B/3) sin(C/3)",
    en: { title: "Morley's Trisector Theorem", desc: "Adjacent angle trisectors meet at the vertices of an equilateral triangle." },
    view: V, points: { A: [-0.5, 3.8], B: [-5.2, -3], C: [5, -2.2] },
    M(s) {
      const [A, B, C] = ccw(s.A, s.B, s.C), tri = [A, B, C], an = tri.map((v, i) => deg(ang(v, tri[(i + 1) % 3], tri[(i + 2) % 3])));
      const pt = (i, j) => { const P = tri[i], Q = tri[j], u = rot(sub(Q, P), (i + 1) % 3 === j ? an[i] / 3 : -an[i] / 3), v = rot(sub(P, Q), (i + 1) % 3 === j ? -an[j] / 3 : an[j] / 3); return lineX(P, u, Q, v); };
      return { tri, an, pts: [pt(0, 1), pt(1, 2), pt(2, 0)] };
    },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const { tri, pts } = this.M(s);
      g.poly(tri, { fill: "b", fo: 0.06, color: "ink", w: 2.4 });
      [[0, 1], [1, 2], [2, 0]].forEach(([i, j], k) => { const X = pts[k]; if (X) { g.seg(tri[i], X, { color: "muted", w: 1.2 }); g.seg(tri[j], X, { color: "muted", w: 1.2 }); } });
      if (pts.every(Boolean)) g.poly(pts, { fill: "d", fo: 0.25, color: "d", w: 2.8 });
      g.point(s.A, "A").point(s.B, "B", { dy: 20 }).point(s.C, "C", { dy: 20 }).handle(s.A, "A").handle(s.B, "B").handle(s.C, "C");
    },
    metrics(s) { const { pts } = this.M(s); if (!pts.every(Boolean)) return ["삼각형을 다시 만들어 주세요."]; return [["몰리 삼각형의 세 변", pts.map((p, i) => fmt(dist(p, pts[(i + 1) % 3]), 3)).join(" · "), "key"]]; },
  },
  {
    id: "lab-pick", grade: G, unit: 3, lesson: "주제 3", title: "픽의 정리 — 격자점으로 넓이 구하기", type: "조작", time: "10분",
    tags: ["격자점", "넓이", "픽의 정리"], links: ["c2-distance"],
    desc: "꼭짓점이 격자점인 다각형의 넓이를 안쪽 격자점 수 I와 변 위의 격자점 수 B만으로 A = I + B/2 − 1로 구합니다.",
    obs: ["꼭짓점을 격자점에 두면 넓이는 항상 0.5의 배수입니다.", "안쪽 점 하나는 1, 변 위의 점 하나는 1/2만큼 넓이에 기여합니다.", "변이 서로 교차하지 않는 다각형에서만 성립합니다."],
    q: "안쪽 격자점이 없는 삼각형 가운데 넓이가 가장 작은 것은 얼마일까요?",
    formula: "A = I + B/2 − 1",
    en: { title: "Pick's Theorem", desc: "Find the area of a lattice polygon from interior and boundary points." },
    view: { x: [-7, 7], y: [-5, 5] }, snap: 1,
    points: { P1: [-4, -3], P2: [3, -3], P3: [5, 1], P4: [0, 4], P5: [-5, 1] },
    params: [{ key: "k", label: "꼭짓점 수", type: "seg", value: 5, options: [[3, "3"], [4, "4"], [5, "5"]] }],
    poly(s) { return ["P1", "P2", "P3", "P4", "P5"].slice(0, s.k).map((k) => s[k]); },
    count(s) {
      const P = this.poly(s), n = P.length; let A2 = 0, B = 0;
      for (let i = 0; i < n; i++) { const a = P[i], b = P[(i + 1) % n]; A2 += a[0] * b[1] - b[0] * a[1]; B += gcd(Math.round(Math.abs(b[0] - a[0])), Math.round(Math.abs(b[1] - a[1]))); }
      const onB = (x, y) => P.some((a, i) => { const b = P[(i + 1) % n], cr = (b[0] - a[0]) * (y - a[1]) - (b[1] - a[1]) * (x - a[0]); return Math.abs(cr) < 1e-9 && x >= Math.min(a[0], b[0]) - 1e-9 && x <= Math.max(a[0], b[0]) + 1e-9 && y >= Math.min(a[1], b[1]) - 1e-9 && y <= Math.max(a[1], b[1]) + 1e-9; });
      const inside = (x, y) => { let c = false; for (let i = 0, j = n - 1; i < n; j = i++) { const a = P[i], b = P[j]; if (a[1] > y !== b[1] > y && x < ((b[0] - a[0]) * (y - a[1])) / (b[1] - a[1]) + a[0]) c = !c; } return c; };
      const I = [], Bp = [];
      for (let x = -7; x <= 7; x++) for (let y = -5; y <= 5; y++) { if (onB(x, y)) Bp.push([x, y]); else if (inside(x, y)) I.push([x, y]); }
      return { A: Math.abs(A2) / 2, B, I, Bp };
    },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const P = this.poly(s), c = this.count(s);
      for (let x = -7; x <= 7; x++) for (let y = -5; y <= 5; y++) g.circle([x, y], 0.05, { color: "muted", fill: "muted", fo: 1, w: 0.5 });
      g.poly(P, { fill: "b", fo: 0.15, color: "b", w: 2.6 });
      c.I.forEach((p) => g.circle(p, 0.14, { color: "c", fill: "c", fo: 1, w: 1 }));
      c.Bp.forEach((p) => g.circle(p, 0.14, { color: "a", fill: "a", fo: 1, w: 1 }));
      P.forEach((p, i) => g.handle(p, `P${i + 1}`));
      g.note(18, 28, "● 안쪽 I   ● 변 위 B", { color: "ink", bold: true });
    },
    metrics(s) { const c = this.count(s); return [["I (안쪽, 초록)", String(c.I.length)], ["B (변 위, 주황)", String(c.Bp.length)], ["I + B/2 − 1", fmt(c.I.length + c.Bp.length / 2 - 1)], ["실제 넓이 (신발끈 공식)", fmt(c.A), "key"]]; },
  },

  // ───────── 4 우연과 통계 실험 ─────────
  {
    id: "lab-galton", grade: G, unit: 4, lesson: "주제 4", title: "갈톤 보드 — 떨어지는 공이 만드는 종 모양", type: "데이터", time: "10분",
    tags: ["갈톤 보드", "이항분포", "정규분포"], links: ["pst-binomial", "pst-trials"],
    desc: "공이 못에 부딪힐 때마다 왼쪽·오른쪽으로 갈라지며 떨어지면, 칸에 쌓인 공의 모양이 이항분포를 거쳐 종 모양으로 다가가는 것을 봅니다.",
    obs: ["공 하나는 못을 n번 지나며 오른쪽으로 간 횟수만큼 옮겨집니다.", "그래서 k번째 칸에 들어갈 확률은 ₙCₖ pᵏ(1 − p)ⁿ⁻ᵏ입니다.", "공이 많아질수록 이론 곡선에 가까워집니다."],
    q: "못의 줄 수를 늘리면 가운데 칸에 들어갈 확률은 어떻게 변할까요?",
    formula: "P(k번째 칸) = ₙCₖ pᵏ qⁿ⁻ᵏ",
    en: { title: "Galton Board", desc: "Balls bouncing left or right pile up into a binomial, then bell-shaped, distribution." },
    view: VIEWL(),
    params: [{ key: "n", label: "못의 줄 수 n", min: 4, max: 14, step: 1, value: 10 }, { key: "p", label: "오른쪽으로 갈 확률 p", min: 0.2, max: 0.8, step: 0.05, value: 0.5 }],
    init: () => ({ bins: [], total: 0, recent: [] }),
    prefill(s) { this.drop(s, 250); },
    onChange(s, k) { if (k === "n" || k === "p") { s.bins = []; s.total = 0; s.recent = []; this.drop(s, 250); } },
    drop(s, m) { if (s.bins.length !== s.n + 1) s.bins = Array(s.n + 1).fill(0); for (let i = 0; i < m; i++) { let k = 0; const path = [0]; for (let r = 0; r < s.n; r++) { if (Math.random() < s.p) k++; path.push(k); } s.bins[k]++; s.total++; if (i >= m - 3) { s.recent.push(path); if (s.recent.length > 6) s.recent.shift(); } } },
    buttons: [["d1", "1개"], ["d100", "100개"], ["reset", "비우기"]],
    onDo(k, s) { if (k === "reset") { s.bins = []; s.total = 0; s.recent = []; } else this.drop(s, k === "d1" ? 1 : 100); },
    anim: { label: "계속 떨어뜨리기", step(s, dt, sp) { sp.drop(s, Math.max(1, Math.round(90 * dt))); } },
    draw(s, g) {
      const n = s.n, top = 9.8, rowH = 4.6 / n, bw = 13 / (n + 1), X = (r, k) => 8 + (k - r / 2) * bw;
      for (let r = 0; r < n; r++) for (let k = 0; k <= r; k++) g.circle([X(r, k), top - r * rowH], 0.08, { color: "ink", fill: "ink", fo: 1, w: 0.5 });
      s.recent.forEach((path, j) => g.path(path.map((k, r) => [X(r, k), top - r * rowH + 0.2]), { color: "a", w: 1.6, opacity: 0.25 + 0.12 * j }));
      const base = 0.6, H = 4, mx = Math.max(1, ...(s.bins.length ? s.bins : [1])), th = Array.from({ length: n + 1 }, (_, k) => binomP(n, s.p, k)), tmax = Math.max(...th);
      const scale = s.total ? Math.max(mx, tmax * s.total) : 1;
      for (let k = 0; k <= n; k++) { const x = X(n, k), h = s.total ? ((s.bins[k] || 0) / scale) * H : 0; g.poly([[x - bw * 0.45, base], [x + bw * 0.45, base], [x + bw * 0.45, base + h], [x - bw * 0.45, base + h]], { fill: "b", fo: 0.45, color: "b", w: 1 }); g.seg([x - bw * 0.5, base], [x - bw * 0.5, base + H], { color: "grid", w: 1 }); }
      if (s.total) g.path(th.map((v, k) => [X(n, k), base + ((v * s.total) / scale) * H]), { color: "d", w: 2.4 });
      g.seg([0.5, base], [15.5, base], { color: "ink", w: 1.6 });
    },
    metrics(s) { const mean = s.total ? s.bins.reduce((a, c, k) => a + c * k, 0) / s.total : NaN; return [["떨어뜨린 공", String(s.total)], ["평균 칸 번호", s.total ? fmt(mean, 3) : "—"], ["이론 평균 np", fmt(s.n * s.p, 3), "key"]]; },
  },
  {
    id: "lab-buffon", grade: G, unit: 4, lesson: "주제 4", title: "뷔퐁의 바늘로 π 구하기", type: "데이터", time: "10분",
    tags: ["기하학적 확률", "π", "시뮬레이션"], links: ["pi-estimation", "lab-monte-pi"],
    desc: "간격이 d인 평행선 위에 길이 l(≤ d)인 바늘을 무작위로 던져 선과 만나는 비율이 2l/(πd)임을 이용해 π를 추정합니다.",
    obs: ["바늘이 선과 만날 확률은 2l/(πd)입니다.", "던진 수가 많아질수록 π의 추정값이 안정됩니다.", "1777년 뷔퐁이 처음 제안한 기하학적 확률 문제입니다."],
    q: "l = d일 때 바늘이 선에 닿을 확률은 약 몇 %일까요?",
    formula: "P = 2l / (πd) ⇒ π ≈ 2l·N / (d·(만난 수))",
    en: { title: "Buffon's Needle", desc: "Drop needles on parallel lines and estimate π from the crossing rate." },
    view: V,
    params: [{ key: "l", label: "바늘 길이 l / 간격 d", min: 0.3, max: 1, step: 0.05, value: 0.8 }],
    init: () => ({ nd: [], N: 0, hit: 0 }),
    prefill(s) { this.toss(s, 300); },
    onChange(s, k) { if (k === "l") { s.nd = []; s.N = 0; s.hit = 0; this.toss(s, 300); } },
    toss(s, m) { const d = 1.6, L = s.l * d; for (let i = 0; i < m; i++) { const c = [-6.6 + Math.random() * 13.2, -4.8 + Math.random() * 9.6], a = Math.random() * Math.PI, u = [Math.cos(a) * L / 2, Math.sin(a) * L / 2], p = sub(c, u), q = add(c, u), h = Math.floor(p[1] / d) !== Math.floor(q[1] / d); s.N++; if (h) s.hit++; s.nd.push([p, q, h]); if (s.nd.length > 500) s.nd.shift(); } },
    buttons: [["t10", "10개"], ["t500", "500개"], ["reset", "치우기"]],
    onDo(k, s) { if (k === "reset") { s.nd = []; s.N = 0; s.hit = 0; } else this.toss(s, k === "t10" ? 10 : 500); },
    anim: { label: "계속 던지기", step(s, dt, sp) { sp.toss(s, Math.max(1, Math.round(80 * dt))); } },
    draw(s, g) {
      for (let y = -4.8; y <= 5; y += 1.6) g.seg([-7, y], [7, y], { color: "ink", w: 1.4 });
      s.nd.forEach(([p, q, h]) => g.seg(p, q, { color: h ? "d" : "b", w: 1.6, opacity: 0.8 }));
    },
    metrics(s) { return [["던진 바늘", String(s.N)], ["선과 만난 바늘", String(s.hit)], ["π의 추정값", s.hit ? fmt((2 * s.l * s.N) / s.hit, 5) : "—", "key"], ["실제 π", "3.14159"]]; },
  },
  {
    id: "lab-monte-pi", grade: G, unit: 4, lesson: "주제 4", title: "몬테카를로 방법으로 π 구하기", type: "데이터", time: "8분",
    tags: ["몬테카를로", "넓이의 비", "무작위 점"], links: ["pi-estimation", "lab-buffon"],
    desc: "정사각형 안에 무작위로 점을 찍어 사분원 안에 들어간 비율로 π를 추정하고, 점이 많아질수록 참값에 가까워지는지 봅니다.",
    obs: ["사분원 넓이 : 정사각형 넓이 = π/4 : 1입니다.", "점의 비율 × 4가 π의 추정값입니다.", "정확도를 한 자리 높이려면 점이 약 100배 필요합니다."],
    q: "같은 방법으로 원이 아닌 복잡한 도형의 넓이도 구할 수 있을까요?",
    formula: "π ≈ 4 × (원 안의 점 수) / (전체 점 수)",
    en: { title: "Monte Carlo Estimate of π", desc: "Scatter random points and use the fraction inside a quarter circle to estimate π." },
    view: { x: [-0.6, 10.6], y: [-0.4, 7.6] },
    init: () => ({ inP: [], outP: [], N: 0, In: 0 }),
    prefill(s) { this.add1(s, 1500); },
    add1(s, m) { for (let i = 0; i < m; i++) { const x = Math.random(), y = Math.random(), inside = x * x + y * y <= 1; s.N++; if (inside) s.In++; const p = [x * 7, y * 7]; if (s.inP.length + s.outP.length < 12000) (inside ? s.inP : s.outP).push(p); } },
    buttons: [["a100", "100개"], ["a5000", "5000개"], ["reset", "지우기"]],
    onDo(k, s) { if (k === "reset") { s.inP = []; s.outP = []; s.N = 0; s.In = 0; } else this.add1(s, k === "a100" ? 100 : 5000); },
    anim: { label: "계속 찍기", step(s, dt, sp) { sp.add1(s, Math.max(1, Math.round(600 * dt))); } },
    draw(s, g) {
      g.poly([[0, 0], [7, 0], [7, 7], [0, 7]], { color: "ink", w: 2 });
      g.param((u) => [7 * Math.cos(u), 7 * Math.sin(u)], 0, Math.PI / 2, { color: "ink", w: 2 });
      dots(g, s.inP, "d", 1.3); dots(g, s.outP, "b", 1.3);
      g.text([8.8, 6.4], "π ≈", { size: 22, bold: true, color: "ink" });
      g.text([8.8, 5.2], s.N ? (4 * s.In / s.N).toFixed(4) : "—", { size: 26, bold: true, color: "d", mono: true });
    },
    metrics(s) { return [["전체 점", String(s.N)], ["원 안의 점", String(s.In)], ["π의 추정값", s.N ? fmt((4 * s.In) / s.N, 5) : "—", "key"], ["오차", s.N ? fmt((4 * s.In) / s.N - Math.PI, 5) : "—"]]; },
  },
  {
    id: "lab-monty-hall", grade: G, unit: 4, lesson: "주제 4", title: "몬티 홀 문제 — 바꿀까, 말까?", type: "데이터", time: "10분",
    tags: ["조건부확률", "직관과 확률", "시뮬레이션"], links: ["pst-bayes"],
    desc: "문 뒤에 자동차 한 대가 있는 게임에서 진행자가 염소 문을 열어 준 뒤 선택을 바꾸는 전략과 유지하는 전략을 수천 번 시뮬레이션해 비교합니다.",
    obs: ["문이 3개일 때 바꾸면 이길 확률이 2/3, 유지하면 1/3입니다.", "처음 고른 문이 맞을 확률은 진행자가 문을 열어도 변하지 않습니다.", "문이 많을수록 바꾸는 쪽이 더 유리해집니다."],
    q: "문이 100개이고 진행자가 98개의 염소 문을 열어 준다면, 여러분은 바꾸겠습니까?",
    formula: "P(바꿔서 승리) = (n − 1)/n · P(유지해서 승리) = 1/n",
    en: { title: "The Monty Hall Problem", desc: "Simulate thousands of games to compare switching and staying." },
    view: VIEW0(),
    params: [{ key: "n", label: "문의 수", min: 3, max: 10, step: 1, value: 3 }],
    init: () => ({ games: 0, stayW: 0, swW: 0, last: null }),
    prefill(s) { this.play(s, 300); },
    onChange(s, k) { if (k === "n") { s.games = 0; s.stayW = 0; s.swW = 0; s.last = null; this.play(s, 300); } },
    play(s, m) { for (let i = 0; i < m; i++) { const car = Math.floor(Math.random() * s.n), pick = Math.floor(Math.random() * s.n); let other; if (pick === car) { other = (car + 1 + Math.floor(Math.random() * (s.n - 1))) % s.n; } else other = car; s.games++; if (pick === car) s.stayW++; if (other === car) s.swW++; s.last = { car, pick, other }; } },
    buttons: [["g1", "한 판"], ["g1000", "1000판"], ["reset", "초기화"]],
    onDo(k, s) { if (k === "reset") { s.games = 0; s.stayW = 0; s.swW = 0; s.last = null; } else this.play(s, k === "g1" ? 1 : 1000); },
    anim: { label: "계속하기", step(s, dt, sp) { sp.play(s, Math.max(1, Math.round(200 * dt))); } },
    draw(s, g) {
      const n = s.n, w = Math.min(1.5, 13 / n), L = s.last;
      for (let i = 0; i < n; i++) {
        const x = 8 + (i - (n - 1) / 2) * w * 1.1, open = L && i !== L.pick && i !== L.other;
        g.poly([[x - w / 2, 6.2], [x + w / 2, 6.2], [x + w / 2, 9.8], [x - w / 2, 9.8]], { fill: open ? "paper" : L && i === L.pick ? "b" : "f", fo: open ? 1 : 0.35, color: L && i === L.pick ? "b" : "ink", w: L && i === L.pick ? 3 : 1.4 });
        if (L && (open || i === L.car)) g.text([x, 7.8], i === L.car ? "🚗" : "🐐", { size: Math.min(26, w * 18) });
        if (L && i === L.other && i !== L.pick) g.text([x, 9.8], "남은 문", { dy: -6, size: 11, color: "c", bold: true });
      }
      const M = (x, y) => [3 + x * 10, 0.8 + y * 4.4];
      [["유지", s.games ? s.stayW / s.games : 0, 1 / n, "b"], ["바꾸기", s.games ? s.swW / s.games : 0, (n - 1) / n, "d"]].forEach(([nm, v, th], i) => {
        const y = 0.8 + i * 2.2; g.poly([[3, y], [3 + v * 10, y], [3 + v * 10, y + 1.3], [3, y + 1.3]], { fill: i ? "d" : "b", fo: 0.5, stroke: false }); g.seg([3 + th * 10, y - 0.2], [3 + th * 10, y + 1.5], { color: "ink", w: 2 }); g.text([2.8, y + 0.65], nm, { dy: 5, anchor: "end", bold: true }); g.text([3 + v * 10, y + 0.65], s.games ? `${fmt(v * 100, 1)}%` : "", { dx: 8, dy: 5, anchor: "start", bold: true, size: 13 });
      });
    },
    metrics(s) { return [["게임 수", String(s.games)], ["유지해서 승리", s.games ? `${fmt((100 * s.stayW) / s.games, 1)}% (이론 ${fmt(100 / s.n, 1)}%)` : "—"], ["바꿔서 승리", s.games ? `${fmt((100 * s.swW) / s.games, 1)}% (이론 ${fmt((100 * (s.n - 1)) / s.n, 1)}%)` : "—", "key"]]; },
  },
  {
    id: "lab-birthday", grade: G, unit: 4, lesson: "주제 4", title: "생일 문제 — 23명이면 절반이 넘는다", type: "데이터", time: "8분",
    tags: ["여사건", "곱셈정리", "직관의 함정"], links: ["pst-venn"],
    desc: "n명 가운데 생일이 같은 사람이 적어도 한 쌍 있을 확률을 여사건으로 계산한 곡선과, 가상의 교실을 여러 번 만들어 본 결과를 비교합니다.",
    obs: ["모두 생일이 다를 확률을 1에서 빼면 됩니다.", "23명이면 확률이 50%를 넘고, 50명이면 97%가 넘습니다.", "사람 수보다 '짝의 수' n(n − 1)/2가 빠르게 늘어나기 때문입니다."],
    q: "우리 반(약 25명)에 생일이 같은 친구가 있을 확률은 얼마일까요?",
    formula: "P = 1 − (365 × 364 × … × (366 − n)) / 365ⁿ",
    en: { title: "The Birthday Problem", desc: "Compare the exact curve with simulated classrooms." },
    view: VIEW0(),
    params: [{ key: "n", label: "사람 수 n", min: 2, max: 80, step: 1, value: 23 }],
    init: () => ({ rooms: 0, hits: 0 }),
    prefill(s) { this.onDo("r100", s); },
    onChange(s, k) { if (k === "n") { s.rooms = 0; s.hits = 0; this.onDo("r100", s); } },
    P(n) { let q = 1; for (let k = 0; k < n; k++) q *= (365 - k) / 365; return 1 - q; },
    buttons: [["r100", "교실 100개 만들기"], ["reset", "초기화"]],
    onDo(k, s) { if (k === "reset") { s.rooms = 0; s.hits = 0; return; } for (let r = 0; r < 100; r++) { const seen = new Set(); let hit = false; for (let i = 0; i < s.n; i++) { const b = Math.floor(Math.random() * 365); if (seen.has(b)) { hit = true; break; } seen.add(b); } s.rooms++; if (hit) s.hits++; } },
    draw(s, g) {
      const M = (x, y) => [1.8 + (x / 80) * 13.4, 1.4 + y * 8.8];
      g.seg(M(0, 0), M(80, 0), { color: "axis", w: 1.4 }).seg(M(0, 0), M(0, 1), { color: "axis", w: 1.4 });
      [0, 0.25, 0.5, 0.75, 1].forEach((v) => { g.seg(M(0, v), M(80, v), { color: "grid", w: 1 }); g.text(M(0, v), `${v * 100}%`, { dx: -6, dy: 4, anchor: "end", size: 11.5, color: "muted" }); });
      [0, 20, 40, 60, 80].forEach((x) => g.text(M(x, 0), String(x), { dy: 17, size: 11.5, color: "muted" }));
      g.param((x) => M(x, this.P(Math.round(x))), 1, 80, { color: "a", w: 3, n: 160 });
      g.seg(M(s.n, 0), M(s.n, this.P(s.n)), { color: "d", w: 1.6, dash: "4 4" }).point(M(s.n, this.P(s.n)), "", { color: "d", r: 6 });
      if (s.rooms) g.point(M(s.n, s.hits / s.rooms), "실험", { color: "b", r: 6, dx: 10 });
      g.text(M(80, 0), "사람 수", { dy: 34, anchor: "end", color: "muted", size: 12 });
    },
    metrics(s) { return [["이론 확률", `${fmt(this.P(s.n) * 100, 2)}%`, "key"], ["실험 (같은 생일이 있던 교실)", s.rooms ? `${s.hits} / ${s.rooms} = ${fmt((100 * s.hits) / s.rooms, 1)}%` : "—"], ["짝의 수", String((s.n * (s.n - 1)) / 2)]]; },
  },
  {
    id: "lab-random-walk", grade: G, unit: 4, lesson: "주제 4", title: "무작위 걸음 — 술 취한 사람은 얼마나 멀리 갈까?", type: "데이터", time: "10분",
    tags: ["무작위 걸음", "√n", "브라운 운동"], links: ["pst-lln"],
    desc: "동전을 던져 한 칸씩 무작위로 움직이는 사람들을 여럿 걷게 하고, 출발점에서 떨어진 평균 거리가 걸음 수의 제곱근 √n 정도로 늘어남을 확인합니다.",
    obs: ["평균 위치는 출발점 근처에 머뭅니다.", "그러나 출발점에서의 거리는 √n에 비례해 커집니다.", "꽃가루의 브라운 운동도 같은 원리로 설명됩니다."],
    q: "100걸음 걸으면 출발점에서 대략 몇 걸음 떨어져 있을까요?",
    formula: "√(평균 거리²) = √n",
    en: { title: "Random Walks", desc: "Many random walkers drift away from the start at a rate of about √n." },
    view: V,
    params: [{ key: "w", label: "걷는 사람 수", min: 1, max: 60, step: 1, value: 24 }, { key: "dim", label: "차원", type: "seg", value: 2, options: [[1, "1차원 (수직선)"], [2, "2차원 (격자)"]] }],
    init: () => ({ walks: [], steps: 0 }),
    prefill(s) { for (let i = 0; i < 150; i++) this.step1(s); },
    onChange(s, k) { s.walks = []; s.steps = 0; for (let i = 0; i < 150; i++) this.step1(s); },
    step1(s) { if (s.walks.length !== s.w) s.walks = Array.from({ length: s.w }, () => [[0, 0]]); if (s.steps >= 600) return; s.steps++; s.walks.forEach((wk) => { const p = wk[wk.length - 1], r = Math.random(); const q = s.dim === 1 ? [p[0] + (r < 0.5 ? 1 : -1), s.steps] : r < 0.25 ? [p[0] + 1, p[1]] : r < 0.5 ? [p[0] - 1, p[1]] : r < 0.75 ? [p[0], p[1] + 1] : [p[0], p[1] - 1]; wk.push(q); }); },
    buttons: [["s50", "50걸음"], ["reset", "처음부터"]],
    onDo(k, s) { if (k === "reset") { s.walks = []; s.steps = 0; } else for (let i = 0; i < 50; i++) this.step1(s); },
    anim: { label: "계속 걷기", step(s, dt, sp) { for (let i = 0; i < Math.max(1, Math.round(40 * dt)); i++) sp.step1(s); } },
    draw(s, g) {
      g.grid({ labels: false });
      const k = s.dim === 1 ? 0.18 : 0.22, T = (p) => (s.dim === 1 ? [-6.5 + p[1] * (13 / 600), p[0] * k] : [p[0] * k, p[1] * k]);
      const cols = ["a", "b", "c", "d", "e", "f"];
      s.walks.forEach((wk, i) => { g.path(wk.map(T), { color: cols[i % 6], w: 1.2, opacity: 0.6 }); g.point(T(wk[wk.length - 1]), "", { color: cols[i % 6], r: 3.5 }); });
      if (s.dim === 2) g.circle([0, 0], Math.sqrt(s.steps) * k, { color: "ink", w: 2, dash: "6 5" });
      else { g.param((x) => [x, Math.sqrt(((x + 6.5) / 13) * 600) * k], -6.5, 6.5, { color: "ink", w: 1.6, dash: "6 5" }); g.param((x) => [x, -Math.sqrt(((x + 6.5) / 13) * 600) * k], -6.5, 6.5, { color: "ink", w: 1.6, dash: "6 5" }); }
      if (!s.steps) g.note(190, 30, "‘계속 걷기’나 ‘50걸음’을 눌러 보세요", { color: "muted", bold: true });
    },
    metrics(s) { if (!s.walks.length) return [["걸음 수", "0"]]; const d2 = s.walks.reduce((a, wk) => { const p = wk[wk.length - 1]; return a + (s.dim === 1 ? p[0] ** 2 : p[0] ** 2 + p[1] ** 2); }, 0) / s.walks.length; return [["걸음 수 n", String(s.steps)], ["√(평균 거리²)", fmt(Math.sqrt(d2), 2)], ["√n", fmt(Math.sqrt(s.steps), 2), "key"]]; },
  },
];
function VIEWL() { return { x: [0, 16], y: [0, 11], pad: 6 }; }
function VIEW0() { return { x: [0, 16], y: [0, 11], pad: 6 }; }
