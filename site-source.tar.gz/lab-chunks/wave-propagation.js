import {fmt} from './wave-scenes.js';
const T=2*Math.PI,I='#263d5b',P='#6255c7',O='#c55337',G='#087d75';
const txt=(x,y,t,c=I,z=17,a='start')=>`<text x="${x}" y="${y}" fill="${c}" font-size="${z}" text-anchor="${a}" font-family="system-ui, sans-serif">${t}</text>`;
const line=(p,c=I,w=2,d='',op=1)=>`<polyline points="${p.map(v=>v.join(',')).join(' ')}" fill="none" stroke="${c}" stroke-width="${w}" stroke-linejoin="round" stroke-dasharray="${d}" opacity="${op}"/>`;
const dot=(x,y,c=G,r=6,fill=c)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${fill}" stroke="${c}" stroke-width="2"/>`;
const curve=f=>Array.from({length:601},(_,i)=>f(T*i/600));
export function propagationValues(s,x=(s.probe??.25)*T,t=s.angle*Math.PI/180){const k=s.waveK??1,a=s.a??1,dir=s.direction??1,right=a*Math.sin(k*x-t),left=a*Math.sin(k*x+t);return {x,right,left,y:s.view==='standing'?right+left:a*Math.sin(k*x-dir*t),envelope:s.view==='standing'?2*a*Math.abs(Math.sin(k*x)):a,wavelength:T/k,nodeCount:2*k+1,antinodeCount:2*k};}
export function propagationScene(s){
 const standing=s.view==='standing',k=s.waveK??1,dir=s.direction??1,a=s.a??1,v=propagationValues(s),t=s.angle*Math.PI/180,ys=standing?38:72,Q=(x,y)=>[60+840*x/T,320-ys*y];
 let out=`<rect width="960" height="640" rx="18" fill="#faf7ef"/><rect width="960" height="96" rx="18" fill="${I}"/>${txt(30,33,'MATH ATELIER / WAVES IN SPACE','#cfdaeb',13)}${txt(30,72,standing?'반대 방향의 두 파동이 만드는 정상파':'파형은 이동하고 한 점은 위아래로 진동합니다','#fffaf2',24)}`;
 out+=txt(35,131,standing?`y = 2 × ${fmt(a)} sin(${k}x) cos θ`:`y = ${fmt(a)} sin(${k}x ${dir===1?'−':'+'} θ)`,G,23)+txt(35,160,standing?'보라: 오른쪽 진행파   /   주황: 왼쪽 진행파   /   초록: 합성파':dir===1?'파형의 진행 방향 →':'← 파형의 진행 방향',standing?I:P,16);
 for(const y of (standing?[-4,-2,0,2,4]:[-2,-1,0,1,2]))out+=line([Q(0,y),Q(T,y)],I,y===0?1.5:1,'',.15)+txt(46,Q(0,y)[1]+5,String(y),I,13,'end');
 for(let j=0;j<=4;j++)out+=line([Q(j*T/4,standing?-4:-2),Q(j*T/4,standing?4:2)],I,1,'',.1)+txt(Q(j*T/4,0)[0],489,['0','π/2','π','3π/2','2π'][j],I,14,'middle');
 out+=txt(922,325,'x',I,18);
 const plot=(f,c,w=2,d='',op=1)=>line(curve(x=>Q(x,f(x))),c,w,d,op);
 if(standing){
  if(s.components!==false)out+=plot(x=>propagationValues(s,x).right,P,2,'5 5',.65)+plot(x=>propagationValues(s,x).left,O,2,'5 5',.65);
  if(s.nodes!==false){out+=plot(x=>2*a*Math.sin(k*x),I,1.4,'3 5',.2)+plot(x=>-2*a*Math.sin(k*x),I,1.4,'3 5',.2);for(let j=0;j<=2*k;j++){const p=Q(j*Math.PI/k,0);out+=dot(...p,P,5);}for(let j=0;j<2*k;j++){const p=Q((j+.5)*Math.PI/k,0);out+=dot(...p,O,5,'#faf7ef');}}
 }
 out+=plot(x=>propagationValues(s,x).y,G,3.5);
 if(!standing){for(let j=0;j<=24;j++){const z=propagationValues(s,j*T/24);out+=dot(...Q(j*T/24,z.y),P,2.5);}}
 if(s.guides)out+=line([Q(v.x,-v.envelope),Q(v.x,v.envelope)],O,2,'5 5',.8);
 const point=Q(v.x,v.y);out+=dot(...point,G,8,'#fffaf2')+dot(...point,G,3);
 out+=txt(35,529,`관찰 위치 x = ${fmt(v.x/Math.PI)}π    현재 높이 ${fmt(v.y)}`,G,18);
 out+=txt(35,560,standing?`마디 ${v.nodeCount}개   /   배 ${v.antinodeCount}개`:`파장 = ${fmt(2/k)}π   /   한 점의 진폭 ${fmt(a)}`,I,18);
 out+=txt(35,590,standing?'마디는 항상 0입니다. 배는 가장 크게 진동합니다.':'관찰점의 가로 위치는 고정됩니다. 파형만 이동합니다.',I,15);
 out+=txt(35,618,standing?'마디 수는 양 끝점을 포함합니다. 빈 주황 원은 배의 위치입니다.':'x와 θ는 무차원 변수입니다. 실제 길이와 시간 단위를 가정하지 않습니다.',I,14);
 const R=(phase,y)=>[610+290*phase/T,565-13*y];
 out+=txt(610,501,'선택한 한 점의 진동',G,16)+line([R(0,0),R(T,0)],I,1,'',.3)+line(curve(ph=>R(ph,propagationValues(s,v.x,ph).y)),G,2.5)+dot(...R(t,v.y),O,4);
 for(let j=0;j<=2;j++)out+=txt(R(j*Math.PI,0)[0],626,['0','π','2π'][j],I,12,'middle');out+=txt(922,568,'θ',I,15);
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 640" role="img" aria-label="${standing?'정상파의 마디와 배':'진행파와 고정된 관찰점'}">${out}</svg>`;
}
