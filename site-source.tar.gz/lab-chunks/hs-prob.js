// 확률과 통계 (공통수학1의 경우의 수 포함) — Ⅰ 경우의 수 · Ⅱ 확률 · Ⅲ 확률분포 · Ⅳ 통계적 추정
import { fmt, frac, lerp, clamp } from "./hs-core.js";

const G = 8;
const VIEW = { x: [0, 16], y: [0, 11], pad: 6 };
export const fact = (n) => { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; };
export const C = (n, k) => { if (k < 0 || k > n) return 0; let r = 1; for (let i = 1; i <= k; i++) r = (r * (n - k + i)) / i; return Math.round(r); };
const binom = (n, p, k) => C(n, k) * p ** k * (1 - p) ** (n - k);
const npdf = (x, m, s) => Math.exp(-((x - m) ** 2) / (2 * s * s)) / (s * Math.sqrt(2 * Math.PI));
function erf(x) { const t = 1 / (1 + 0.3275911 * Math.abs(x)), y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return x >= 0 ? y : -y; }
const ncdf = (x, m = 0, s = 1) => 0.5 * (1 + erf((x - m) / (s * Math.SQRT2)));
const randn = () => { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
const pct = (p) => `${fmt(p * 100, 1)}%`;
const INK = ["a", "b", "c", "d", "e", "f"];

// 자료 그래프 틀: 세계 좌표의 상자 [x0, y0, x1, y1]에 자료 범위 xr, yr을 대응
function chart(g, box, xr, yr, o = {}) {
  const [X0, Y0, X1, Y1] = box;
  const M = (p) => [X0 + ((p[0] - xr[0]) / (xr[1] - xr[0])) * (X1 - X0), Y0 + ((p[1] - yr[0]) / (yr[1] - yr[0])) * (Y1 - Y0)];
  g.seg([X0, Y0], [X1, Y0], { color: "axis", w: 1.4 });
  if (o.yaxis !== false) g.seg([X0, Y0], [X0, Y1], { color: "axis", w: 1.4 });
  (o.yt || []).forEach((v) => { const q = M([xr[0], v]); g.seg([X0, q[1]], [X1, q[1]], { color: "grid", w: 1 }); g.text(q, o.yf ? o.yf(v) : fmt(v), { dx: -6, dy: 4, anchor: "end", color: "muted", size: 11.5, mono: true }); });
  (o.xt || []).forEach((v) => { const q = M([v, yr[0]]); g.seg(q, [q[0], Y0 - 0.12], { color: "axis", w: 1.2 }); g.text(q, o.xf ? o.xf(v) : fmt(v), { dy: 17, color: "muted", size: 11.5, mono: true }); });
  if (o.xName) g.text([X1, Y0], o.xName, { dy: 34, anchor: "end", color: "muted", size: 12 });
  if (o.yName) g.text([X0, Y1], o.yName, { dy: -8, anchor: "start", color: "muted", size: 12 });
  return M;
}
const bar = (g, M, x, w, h, o) => g.poly([M([x - w / 2, 0]), M([x + w / 2, 0]), M([x + w / 2, h]), M([x - w / 2, h])], { fo: 0.4, w: 1.2, ...o });
const ticks = (a, b, n) => { const st = (b - a) / n; return Array.from({ length: n + 1 }, (_, i) => a + i * st); };
const niceMax = (v) => { const e = 10 ** Math.floor(Math.log10(v)), m = v / e; return (m <= 1 ? 1 : m <= 2 ? 2 : m <= 2.5 ? 2.5 : m <= 5 ? 5 : 10) * e; };

// 두 주사위 사건
const EVENTS = {
  sum7: ["눈의 합이 7", (a, b) => a + b === 7], even1: ["첫째 눈이 짝수", (a) => a % 2 === 0], ge5: ["둘째 눈이 5 이상", (a, b) => b >= 5],
  same: ["두 눈이 같음", (a, b) => a === b], sum_ge9: ["눈의 합이 9 이상", (a, b) => a + b >= 9], prod_even: ["눈의 곱이 짝수", (a, b) => (a * b) % 2 === 0], has6: ["6이 하나 이상", (a, b) => a === 6 || b === 6],
};
const evOpts = Object.entries(EVENTS).map(([k, v]) => [k, v[0]]);

export default [
  // ───────── Ⅰ 경우의 수 ─────────
  {
    id: "pst-perm-comb", grade: 14, unit: 5, lesson: "Ⅴ-2", title: "순열과 조합 — 줄 세우기와 뽑기", type: "조작", time: "12분",
    tags: ["순열", "조합", "r!"], links: ["g2-counting", "pst-pascal"],
    desc: "n개 가운데 r개를 뽑아 줄 세운 모든 경우(순열)를 펼치고, 같은 구성끼리 묶으면 한 묶음에 r!개씩 있어 조합이 됨을 봅니다.",
    obs: ["순열은 순서가 다르면 다른 경우로 셉니다.", "같은 r개로 만든 순열은 r!가지이므로 조합 = 순열 ÷ r!입니다.", "nCr = nC(n−r)입니다."],
    q: "5명 중 회장·부회장을 뽑는 경우와 대표 2명을 뽑는 경우는 몇 배 차이일까요?",
    formula: "ₙPᵣ = n!/(n − r)! · ₙCᵣ = ₙPᵣ / r!",
    en: { title: "Permutations and Combinations", desc: "List every arrangement, then group equal selections to see nCr = nPr / r!." },
    view: VIEW,
    params: [
      { key: "mode", label: "보기", type: "seg", value: "comb", options: [["perm", "순열 전체"], ["comb", "조합으로 묶기"]] },
      { key: "n", label: "n (사람 수)", min: 2, max: 6, step: 1, value: 4 },
      { key: "r", label: "r (뽑는 수)", min: 1, max: 4, step: 1, value: 2 },
    ],
    derive(s) { if (s.r > s.n) s.r = s.n; },
    list(s) {
      const out = [], cur = [], used = Array(s.n).fill(false);
      const go = () => { if (cur.length === s.r) { out.push([...cur]); return; } for (let i = 0; i < s.n; i++) if (!used[i]) { used[i] = true; cur.push(i); go(); cur.pop(); used[i] = false; } };
      go(); return out;
    },
    draw(s, g) {
      const P = this.list(s), L = "ABCDEF";
      let rows;
      if (s.mode === "comb") { const map = new Map(); P.forEach((p) => { const k = [...p].sort().join(""); if (!map.has(k)) map.set(k, []); map.get(k).push(p); }); rows = [...map.values()]; }
      // 공 크기를 화면에 맞게 고른다
      let d = 0.66, per = 1, R = [], rh = 1;
      for (; d >= 0.2; d -= 0.02) {
        const tw = s.r * d + 0.34; per = Math.max(1, Math.floor(15.2 / tw));
        R = s.mode === "comb" ? rows : Array.from({ length: Math.ceil(P.length / per) }, (_, i) => P.slice(i * per, i * per + per));
        rh = d * 1.55; if (R.length * rh <= 10.2 && (s.mode !== "comb" || rows[0].length <= per)) break;
      }
      const maxRows = Math.floor(10.2 / rh); rows = R; R = R.slice(0, maxRows);
      const cw = s.r * d + 0.34;
      R.forEach((row, i) => {
        const y = 10.6 - (i + 0.5) * rh;
        row.slice(0, per).forEach((p, j) => {
          const x0 = 0.4 + j * cw;
          if (s.mode === "comb" && j === 0) g.poly([[x0 - 0.08, y - rh * 0.4], [x0 + cw - 0.2, y - rh * 0.4], [x0 + cw - 0.2, y + rh * 0.4], [x0 - 0.08, y + rh * 0.4]], { fill: "f", fo: 0.22, stroke: false });
          p.forEach((k, m) => { const c = [x0 + m * d + d / 2, y]; g.circle(c, d * 0.44, { color: INK[k], fill: INK[k], fo: 0.85, w: 1 }); if (d >= 0.32) g.text(c, L[k], { dy: 4, size: Math.max(8, Math.min(14, d * 22)), color: "paper", bold: true }); });
        });
      });
      if (rows.length > maxRows) g.note(18, 430, `…외 ${rows.length - maxRows}줄 더`, { color: "muted" });
    },
    metrics(s) { const P = fact(s.n) / fact(s.n - s.r); return [[`${s.n}P${s.r}`, fmt(P)], [`${s.r}!`, fmt(fact(s.r))], [`${s.n}C${s.r} = ${s.n}P${s.r} / ${s.r}!`, fmt(C(s.n, s.r)), "key"], s.mode === "comb" ? "한 줄이 같은 사람들로 만든 순열 묶음입니다. 줄의 수가 조합의 수입니다." : "색 공 한 묶음이 한 가지 줄 세우기입니다."]; },
  },
  {
    id: "pst-rep-perm", grade: G, unit: 1, lesson: "Ⅰ-1", title: "중복순열 — 수형도로 세기", type: "조작", time: "8분",
    tags: ["중복순열", "수형도", "nʳ"], links: ["pst-perm-comb"],
    desc: "같은 것을 여러 번 뽑을 수 있을 때 수형도의 가지가 매번 n개씩 뻗어 nʳ개가 되는 것을, 중복을 허용하지 않는 순열과 비교합니다.",
    obs: ["중복을 허용하면 각 단계의 선택 수가 모두 n입니다.", "중복을 허용하지 않으면 한 단계마다 선택이 하나씩 줄어듭니다."],
    q: "숫자 1, 2, 3으로 만들 수 있는 네 자리 비밀번호는 몇 개일까요?",
    formula: "ₙΠᵣ = nʳ",
    en: { title: "Permutations with Repetition", desc: "Count branches of a tree diagram: nʳ with repetition vs nPr without." },
    view: VIEW,
    params: [{ key: "n", label: "n (고를 수 있는 것)", min: 2, max: 4, step: 1, value: 3 }, { key: "r", label: "r (자리 수)", min: 1, max: 3, step: 1, value: 3 }, { key: "rep", label: "중복 허용", type: "check", value: true }],
    draw(s, g) {
      const n = s.n, r = s.r, L = "1234";
      const leaves = n ** r, x = (i, lvl) => 0.6 + ((i + 0.5) / n ** lvl) * 14.8;
      g.point([8, 10.4], "시작", { color: "ink", r: 4, dy: -8, anchor: "middle", dx: 0 });
      const walk = (lvl, idx, path) => {
        if (lvl === r) return;
        for (let k = 0; k < n; k++) {
          const ni = idx * n + k, P0 = lvl === 0 ? [8, 10.4] : [x(idx, lvl), 10.4 - (lvl * 9.4) / r], P1 = [x(ni, lvl + 1), 10.4 - ((lvl + 1) * 9.4) / r];
          const ok = s.rep || !path.includes(k);
          g.seg(P0, P1, { color: ok ? INK[k] : "grid", w: ok ? 1.6 : 1 });
          if (n ** (lvl + 1) <= 27) g.text(P1, L[k], { dy: -6, size: 11, color: ok ? INK[k] : "muted", bold: ok });
          else g.point(P1, "", { r: 2, color: ok ? INK[k] : "grid" });
          if (ok || lvl + 1 < r) walk(lvl + 1, ni, [...path, k]);
        }
      };
      walk(0, 0, []);
    },
    metrics(s) { const P = s.r <= s.n ? fact(s.n) / fact(s.n - s.r) : 0; return [["중복순열 nʳ", fmt(s.n ** s.r), s.rep ? "key" : ""], ["순열 nPr", s.r <= s.n ? fmt(P) : "0", s.rep ? "" : "key"]]; },
  },
  {
    id: "pst-grid-path", grade: G, unit: 1, lesson: "Ⅰ-2", title: "같은 것이 있는 순열과 최단 경로", type: "조작", time: "10분",
    tags: ["최단 경로", "같은 것이 있는 순열", "격자"], links: ["pst-pascal"],
    desc: "격자 도로에서 오른쪽 m번, 위쪽 n번 가는 최단 경로의 수를 교차로마다 더해 가며 세고, 같은 것이 있는 순열 (m + n)!/(m!n!)과 비교합니다. 탁자(장애물)를 피해 가는 서빙 로봇의 경로도 셉니다.",
    obs: ["각 교차로의 경우의 수는 왼쪽 수 + 아래쪽 수입니다.", "경로 하나는 →와 ↑를 늘어놓은 순서 하나와 같습니다.", "막힌 교차로를 두면 그 점을 지나는 경로만큼 빠집니다."],
    q: "→→→↑↑를 늘어놓는 방법의 수와 격자 경로의 수가 같은 이유를 설명해 보세요.",
    formula: "(m + n)! / (m! n!) = ₘ₊ₙCₘ",
    en: { title: "Shortest Grid Paths", desc: "Count shortest paths on a grid by adding at each intersection and compare with (m + n)!/(m!n!)." },
    view: VIEW,
    params: [
      { key: "m", label: "오른쪽 칸 수 m", min: 1, max: 8, step: 1, value: 5 },
      { key: "n", label: "위쪽 칸 수 n", min: 1, max: 6, step: 1, value: 3 },
      { key: "block", label: "장애물", type: "select", value: "none", options: [["none", "없음"], ["one", "가운데 교차로 1곳"], ["table", "탁자 (교차로 2곳)"], ["two", "탁자 2개"]] },
      { key: "k", label: "경로 번호", min: 1, max: (s) => C(s.m + s.n, s.m), step: 1, value: 20 },
    ],
    B(s) { return [Math.floor(s.m / 2), Math.floor(s.n / 2)]; },
    blocked(s, a, b) { const [x, y] = this.B(s); if (s.block === "one") return a === x && b === y; if (s.block === "table") return b === y && (a === x || a === x + 1) && a < s.m; if (s.block === "two") return (b === y && a === x) || (b === Math.min(s.n - 1, y + 1) && a === Math.max(1, x - 2) && s.n > 1); return false; },
    dp(s) { const B = this.B(s), T = []; for (let i = 0; i <= s.m; i++) { T[i] = []; for (let j = 0; j <= s.n; j++) T[i][j] = this.blocked(s, i, j) && !(i === 0 && j === 0) && !(i === s.m && j === s.n) ? 0 : i === 0 && j === 0 ? 1 : (i ? T[i - 1][j] : 0) + (j ? T[i][j - 1] : 0); } return T; },
    draw(s, g) {
      const T = this.dp(s), cs = Math.min(14 / s.m, 9 / s.n), O = [8 - (s.m * cs) / 2, 1];
      const P = (i, j) => [O[0] + i * cs, O[1] + j * cs];
      for (let i = 0; i <= s.m; i++) g.seg(P(i, 0), P(i, s.n), { color: "muted", w: 1.4 });
      for (let j = 0; j <= s.n; j++) g.seg(P(0, j), P(s.m, j), { color: "muted", w: 1.4 });
      // 경로 하나: 끝에서부터 비율에 따라 거꾸로 고르기
      let i = s.m, j = s.n, r = Math.min(s.k, Math.max(1, T[s.m][s.n])) - 1, path = [[i, j]];
      while (i > 0 || j > 0) { const L = i ? T[i - 1][j] : 0; if (i && (r < L || !j)) i--; else { r -= L; j--; } path.push([i, j]); }
      if (T[s.m][s.n] > 0) g.path(path.map(([a, b]) => P(a, b)), { color: "a", w: 5, opacity: 0.8 });
      for (let a = 0; a <= s.m; a++) for (let b = 0; b <= s.n; b++) { const blk = this.blocked(s, a, b) && !(a === 0 && b === 0) && !(a === s.m && b === s.n); g.circle(P(a, b), 0.34, { color: blk ? "d" : "b", fill: blk ? "d" : "paper", fo: 1, w: 1.4, layer: "point" }); g.text(P(a, b), blk ? "✕" : String(T[a][b]), { dy: 4, size: T[a][b] > 99 ? 9.5 : 11.5, color: blk ? "paper" : "ink", bold: true }); }
      g.text(P(0, 0), "A", { dx: -18, dy: 18, bold: true }).text(P(s.m, s.n), "B", { dx: 18, dy: -10, bold: true });
    },
    metrics(s) { const T = this.dp(s); return [["(m + n)!/(m!n!)", fmt(fact(s.m + s.n) / (fact(s.m) * fact(s.n)))], ["A → B 최단 경로", fmt(T[s.m][s.n]), "key"], s.block !== "none" ? `장애물을 지나는 ${fmt(fact(s.m + s.n) / (fact(s.m) * fact(s.n)) - T[s.m][s.n])}가지가 빠졌습니다.` : `지금 보는 경로: ${Math.min(s.k, T[s.m][s.n])}번째 / ${T[s.m][s.n]}가지`]; },
  },
  {
    id: "pst-rep-comb", grade: G, unit: 1, lesson: "Ⅰ-3", title: "중복조합 — 공과 칸막이", type: "조작", time: "10분",
    tags: ["중복조합", "칸막이", "방정식의 해"], links: ["pst-perm-comb"],
    desc: "r개의 같은 공을 n개의 상자에 나누어 담는 방법을 공(○)과 칸막이(|)의 배열로 바꾸어 세어 봅니다.",
    obs: ["칸막이 n − 1개와 공 r개를 한 줄로 늘어놓는 방법과 같습니다.", "x + y + z = r의 음이 아닌 정수해의 개수도 같은 방법으로 셉니다."],
    q: "사탕 5개를 3명에게 나누어 주는 방법은 몇 가지일까요? (못 받는 사람이 있어도 됨)",
    formula: "ₙHᵣ = ₙ₊ᵣ₋₁Cᵣ",
    en: { title: "Combinations with Repetition", desc: "Turn distributions of identical balls into strings of stars and bars." },
    view: VIEW,
    params: [{ key: "n", label: "상자 수 n", min: 2, max: 5, step: 1, value: 3 }, { key: "r", label: "공의 수 r", min: 1, max: 8, step: 1, value: 5 }, { key: "k", label: "배치 번호", min: 1, max: (s) => C(s.n + s.r - 1, s.r), step: 1, value: 4 }],
    all(s) { const out = [], cur = []; const go = (i, left) => { if (i === s.n - 1) { out.push([...cur, left]); return; } for (let v = left; v >= 0; v--) { cur.push(v); go(i + 1, left - v); cur.pop(); } }; go(0, s.r); return out; },
    draw(s, g) {
      const A = this.all(s), d = A[Math.min(A.length, Math.max(1, s.k)) - 1], w = 14 / s.n;
      d.forEach((c, i) => {
        const x0 = 1 + i * w; g.poly([[x0 + 0.2, 4.6], [x0 + w - 0.2, 4.6], [x0 + w - 0.2, 9.4], [x0 + 0.2, 9.4]], { color: INK[i], fill: INK[i], fo: 0.08, w: 2 });
        g.text([x0 + w / 2, 9.4], `상자 ${i + 1}`, { dy: -8, color: INK[i], bold: true, size: 12 });
        for (let b = 0; b < c; b++) g.circle([x0 + w / 2 + ((b % 2) - 0.5) * 0.7, 5.2 + Math.floor(b / 2) * 0.72], 0.3, { color: INK[i], fill: INK[i], fo: 0.8, w: 1 });
      });
      const str = d.map((c) => "○".repeat(c)).join(" | ");
      g.text([8, 2.6], str || "|", { size: 24, color: "ink", bold: true });
      g.text([8, 1.2], `(${d.join(", ")})`, { size: 14, color: "muted", mono: true });
    },
    metrics(s) { return [["배치", `${Math.min(s.k, C(s.n + s.r - 1, s.r))}번째 / ${C(s.n + s.r - 1, s.r)}가지`], ["공 + 칸막이", `${s.r} + ${s.n - 1} = ${s.r + s.n - 1}자리`], [`${s.n}H${s.r} = ${s.n + s.r - 1}C${s.r}`, fmt(C(s.n + s.r - 1, s.r)), "key"]]; },
  },
  {
    id: "pst-pascal", grade: G, unit: 1, lesson: "Ⅰ-4", title: "이항정리와 파스칼의 삼각형", type: "2D", time: "10분",
    tags: ["이항계수", "파스칼", "시에르핀스키"], links: ["pst-grid-path", "lab-sierpinski"],
    desc: "파스칼의 삼각형에서 (a + b)ⁿ의 계수를 읽고, 이웃한 두 수의 합 규칙과 하키스틱 규칙, 짝수·홀수 색칠에서 나타나는 무늬를 봅니다.",
    obs: ["각 수는 바로 위 두 수의 합입니다(ₙCᵣ = ₙ₋₁Cᵣ₋₁ + ₙ₋₁Cᵣ).", "n번째 줄의 합은 2ⁿ입니다.", "홀수만 색칠하면 시에르핀스키 삼각형이 나타납니다."],
    q: "(a + b)⁶을 전개했을 때 a²b⁴의 계수는 무엇일까요?",
    formula: "(a + b)ⁿ = Σ ₙCᵣ aⁿ⁻ʳ bʳ",
    en: { title: "Binomial Theorem and Pascal's Triangle", desc: "Read binomial coefficients, the addition rule, the hockey stick, and the odd-even pattern." },
    view: VIEW,
    params: [
      { key: "mode", label: "보기", type: "seg", value: "coef", options: [["coef", "계수"], ["odd", "홀수 색칠"], ["hockey", "하키스틱"]] },
      { key: "N", label: "줄 수", min: 4, max: 32, step: 1, value: 10 },
      { key: "n", label: "강조할 n", min: 0, max: 31, step: 1, value: 6 },
      { key: "r", label: "강조할 r", min: 0, max: 31, step: 1, value: 2 },
    ],
    derive(s) { if (s.n > s.N - 1) s.n = s.N - 1; if (s.r > s.n) s.r = s.n; },
    draw(s, g) {
      const N = s.N, h = 10.4 / N, w = Math.min(15.6 / N, h * 1.25);
      const P = (n, r) => [8 + (r - n / 2) * w, 10.6 - (n + 0.5) * h];
      const hk = new Set(); if (s.mode === "hockey") for (let i = s.r; i < s.n; i++) hk.add(`${i},${s.r}`);
      for (let n = 0; n < N; n++) for (let r = 0; r <= n; r++) {
        const v = C(n, r), p = P(n, r), odd = v % 2 === 1;
        let fill = "paper", fo = 1, col = "grid";
        if (s.mode === "odd") { fill = odd ? "e" : "paper"; fo = odd ? 0.85 : 1; col = odd ? "e" : "grid"; }
        if (s.mode === "coef" && n === s.n) { fill = "a"; fo = 0.25; col = "a"; }
        if (s.mode === "coef" && n === s.n && r === s.r) { fill = "a"; fo = 0.8; }
        if (s.mode === "coef" && s.n > 0 && n === s.n - 1 && (r === s.r - 1 || r === s.r)) { fill = "b"; fo = 0.35; col = "b"; }
        if (s.mode === "hockey" && hk.has(`${n},${r}`)) { fill = "c"; fo = 0.5; col = "c"; }
        if (s.mode === "hockey" && n === s.n && r === s.r + 1) { fill = "d"; fo = 0.6; col = "d"; }
        g.circle(p, Math.min(w, h) * 0.46, { color: col, fill, fo, w: 1 });
        if (N <= 14) g.text(p, String(v), { dy: 4, size: Math.max(8.5, Math.min(13, 110 / N)), color: "ink" });
      }
    },
    metrics(s) {
      const out = [[`${s.n}C${s.r}`, fmt(C(s.n, s.r)), "key"], [`${s.n}번째 줄의 합`, `2^${s.n} = ${fmt(2 ** s.n)}`]];
      if (s.n <= 7) out.push(["전개", Array.from({ length: s.n + 1 }, (_, r) => `${C(s.n, r) === 1 ? "" : C(s.n, r)}${s.n - r ? "a" + (s.n - r > 1 ? "^" + (s.n - r) : "") : ""}${r ? "b" + (r > 1 ? "^" + r : "") : ""}`).join(" + ")]);
      if (s.mode === "hockey") { let sum = 0; for (let i = s.r; i < s.n; i++) sum += C(i, s.r); out.push(["하키스틱", `초록 수의 합 ${fmt(sum)} = ${s.n}C${s.r + 1}`]); }
      return out;
    },
  },

  // ───────── Ⅱ 확률 ─────────
  {
    id: "pst-dice-sum", grade: G, unit: 2, lesson: "Ⅱ-1", title: "수학적 확률과 통계적 확률 — 두 주사위의 합", type: "데이터", time: "10분",
    tags: ["시뮬레이션", "상대도수", "두 주사위"], links: ["g2-probability", "pst-lln"],
    desc: "두 주사위를 여러 번 던진 결과의 상대도수 막대가 경우의 수로 계산한 수학적 확률(선)에 다가가는 모습을 봅니다.",
    obs: ["합이 7인 경우가 6가지로 가장 많습니다.", "던진 횟수가 적으면 상대도수가 들쭉날쭉합니다.", "횟수가 많아질수록 상대도수는 수학적 확률에 가까워집니다."],
    q: "합이 2가 나올 확률과 합이 12가 나올 확률은 왜 같을까요?",
    formula: "수학적 확률 = (사건의 경우의 수) / 36 · 통계적 확률 = lim 상대도수",
    en: { title: "Two Dice: Theoretical vs Experimental", desc: "Roll two dice many times and compare relative frequencies with theoretical probabilities." },
    view: VIEW,
    params: [{ key: "speed", label: "재생 속도 (초당 던지기)", min: 10, max: 2000, step: 10, value: 300 }],
    init: () => ({ cnt: Array(13).fill(0), tot: 0 }),
    prefill(s) { this.roll(s, 400); },
    buttons: [["r1", "1번 던지기"], ["r100", "100번"], ["r1000", "1000번"], ["reset", "초기화"]],
    roll(s, k) { for (let i = 0; i < k; i++) { s.cnt[1 + Math.ceil(Math.random() * 6) + Math.floor(Math.random() * 6)]++; s.tot++; } },
    onDo(k, s) { if (k === "reset") { s.cnt = Array(13).fill(0); s.tot = 0; } else this.roll(s, { r1: 1, r100: 100, r1000: 1000 }[k]); },
    anim: { label: "계속 던지기", step(s, dt) { const sp = s.speed || 300; for (let i = 0; i < Math.max(1, Math.round(sp * dt)); i++) { s.cnt[1 + Math.ceil(Math.random() * 6) + Math.floor(Math.random() * 6)]++; s.tot++; } } },
    draw(s, g) {
      const M = chart(g, [1.6, 1.3, 15.4, 10.3], [1.3, 12.7], [0, 0.25], { xt: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], yt: [0, 0.05, 0.1, 0.15, 0.2, 0.25], yf: (v) => fmt(v, 2), xName: "두 눈의 합", yName: "상대도수" });
      for (let k = 2; k <= 12; k++) { const th = (6 - Math.abs(k - 7)) / 36, rf = s.tot ? s.cnt[k] / s.tot : 0; bar(g, M, k, 0.7, Math.min(rf, 0.25), { fill: "b", color: "b" }); g.seg(M([k - 0.45, th]), M([k + 0.45, th]), { color: "a", w: 3 }); }
      g.note(460, 30, "— 수학적 확률", { color: "a", bold: true }); g.note(460, 52, "■ 상대도수", { color: "b", bold: true });
    },
    metrics(s) { const rf = s.tot ? s.cnt[7] / s.tot : 0; return [["던진 횟수", fmt(s.tot)], ["합 7의 상대도수", s.tot ? fmt(rf, 4) : "—"], ["합 7의 수학적 확률", "6/36 ≈ 0.1667", "key"]]; },
  },
  {
    id: "pst-venn", grade: G, unit: 2, lesson: "Ⅱ-2", title: "확률의 덧셈정리와 여사건 — 36칸 표본공간", type: "조작", time: "10분",
    tags: ["합사건", "곱사건", "여사건"], links: ["g2-complement", "pst-bayes"],
    desc: "두 주사위의 36가지 결과를 격자로 놓고 사건 A, B를 색칠해 P(A ∪ B) = P(A) + P(B) − P(A ∩ B)와 여사건의 확률을 셉니다.",
    obs: ["A와 B에 모두 속한 칸은 두 번 세어지므로 한 번 빼 줍니다.", "A ∩ B가 비어 있으면(배반사건) 확률을 그냥 더합니다.", "'적어도 하나'는 여사건으로 세는 것이 편합니다."],
    q: "6의 눈이 적어도 한 번 나올 확률을 여사건으로 구해 보세요.",
    formula: "P(A ∪ B) = P(A) + P(B) − P(A ∩ B) · P(Aᶜ) = 1 − P(A)",
    en: { title: "Addition Rule and Complements", desc: "Color events on the 36-outcome grid of two dice and count unions, intersections and complements." },
    view: VIEW,
    params: [
      { key: "A", label: "사건 A", type: "select", value: "sum7", options: evOpts },
      { key: "B", label: "사건 B", type: "select", value: "even1", options: evOpts },
      { key: "comp", label: "A의 여사건 보기", type: "check", value: false },
    ],
    cnt(s) { let a = 0, b = 0, ab = 0; for (let i = 1; i <= 6; i++) for (let j = 1; j <= 6; j++) { const x = EVENTS[s.A][1](i, j), y = EVENTS[s.B][1](i, j); a += x; b += y; ab += x && y; } return { a, b, ab }; },
    draw(s, g) {
      const cs = 1.45, O = [3.4, 0.9];
      for (let i = 1; i <= 6; i++) for (let j = 1; j <= 6; j++) {
        const p = [O[0] + (i - 0.5) * cs, O[1] + (j - 0.5) * cs], a = EVENTS[s.A][1](i, j), b = EVENTS[s.B][1](i, j);
        const inA = s.comp ? !a : a;
        g.poly([[p[0] - cs / 2 + 0.05, p[1] - cs / 2 + 0.05], [p[0] + cs / 2 - 0.05, p[1] - cs / 2 + 0.05], [p[0] + cs / 2 - 0.05, p[1] + cs / 2 - 0.05], [p[0] - cs / 2 + 0.05, p[1] + cs / 2 - 0.05]], { fill: inA && b ? "e" : inA ? "a" : b ? "b" : "paper", fo: inA && b ? 0.55 : inA || b ? 0.35 : 1, color: "grid", w: 1 });
        g.text(p, `${i},${j}`, { dy: 4, size: 11, color: "ink", mono: true });
      }
      for (let i = 1; i <= 6; i++) { g.text([O[0] + (i - 0.5) * cs, O[1]], String(i), { dy: 16, color: "muted", bold: true }); g.text([O[0], O[1] + (i - 0.5) * cs], String(i), { dx: -10, dy: 4, anchor: "end", color: "muted", bold: true }); }
      g.text([O[0] + 3 * cs, O[1]], "첫째 눈", { dy: 34, color: "muted", size: 12 });
      g.note(18, 30, s.comp ? `■ Aᶜ: ${EVENTS[s.A][0]}이 아님` : `■ A: ${EVENTS[s.A][0]}`, { color: "a", bold: true });
      g.note(18, 54, `■ B: ${EVENTS[s.B][0]}`, { color: "b", bold: true });
      g.note(18, 78, "■ 둘 다", { color: "e", bold: true });
    },
    metrics(s) {
      const { a, b, ab } = this.cnt(s);
      if (s.comp) return [["P(A)", `${a}/36`], ["P(Aᶜ) = 1 − P(A)", `${36 - a}/36 = ${frac((36 - a) / 36, 36)}`, "key"]];
      return [["P(A) + P(B)", `${a}/36 + ${b}/36`], ["P(A ∩ B)", `${ab}/36`], ["P(A ∪ B)", `${a + b - ab}/36 = ${frac((a + b - ab) / 36, 36)}`, "key"], ab === 0 ? "A와 B는 서로 배반사건입니다." : ""].filter(Boolean);
    },
  },
  {
    id: "pst-bayes", grade: G, unit: 2, lesson: "Ⅱ-4", title: "조건부확률 — 검사 양성이면 정말 병일까?", type: "데이터", time: "12분",
    tags: ["조건부확률", "곱셈정리", "자연 빈도"], links: ["pst-venn", "pst-independence"],
    desc: "1000명 중 병이 있는 사람, 검사 결과가 양성인 사람을 점으로 나누어 P(병 | 양성)이 직관보다 훨씬 작을 수 있음을 봅니다.",
    obs: ["P(B | A)는 A가 일어났다는 조건 아래에서 B의 비율입니다.", "양성 반응자 중 실제 환자의 비율은 유병률에 크게 좌우됩니다.", "P(A ∩ B) = P(A)P(B | A)입니다(곱셈정리)."],
    q: "민감도와 특이도가 모두 99%인 검사에서 양성이어도 실제 병일 확률이 50%보다 낮을 수 있는 까닭은 무엇일까요?",
    formula: "P(A | B) = P(A ∩ B) / P(B)",
    en: { title: "Conditional Probability: Is a Positive Test Reliable?", desc: "Split 1000 people into sick/healthy and positive/negative to see P(sick | positive)." },
    view: VIEW,
    params: [
      { key: "prev", label: "유병률", min: 0.005, max: 0.3, step: 0.005, value: 0.02, show: pct },
      { key: "sens", label: "민감도 (병이 있을 때 양성)", min: 0.5, max: 1, step: 0.01, value: 0.95, show: pct },
      { key: "spec", label: "특이도 (병이 없을 때 음성)", min: 0.5, max: 1, step: 0.01, value: 0.95, show: pct },
    ],
    draw(s, g) {
      const sick = Math.round(1000 * s.prev), tp = Math.round(sick * s.sens), fp = Math.round((1000 - sick) * (1 - s.spec));
      let idx = 0;
      for (let i = 0; i < 1000; i++) {
        const c = i % 50, r = Math.floor(i / 50), p = [0.5 + c * 0.3, 10.4 - r * 0.47];
        let fill = "grid", fo = 1;
        if (i < tp) { fill = "d"; fo = 0.95; } else if (i < sick) { fill = "d"; fo = 0.3; } else if (i < sick + fp) { fill = "b"; fo = 0.9; }
        g.circle(p, 0.12, { color: fill, fill, fo, w: 0.6, stroke: false });
        idx++;
      }
      g.note(18, 424, `● 환자·양성 ${tp}명   ◌ 환자·음성 ${sick - tp}명   ● 건강·양성 ${fp}명`, { color: "ink", bold: true });
    },
    metrics(s) { const sick = 1000 * s.prev, tp = sick * s.sens, fp = (1000 - sick) * (1 - s.spec); return [["양성 기대 인원", `${fmt(tp + fp, 2)}명`], ["그중 실제 환자 기대 인원", `${fmt(tp, 2)}명`], ["P(병 | 양성)", pct(tp / (tp + fp)), "key"], ["P(양성 | 병)", pct(s.sens)], "점 그림의 인원은 반올림한 예시입니다. 확률은 반올림 전 기대 인원으로 계산합니다."]; },
  },
  {
    id: "pst-independence", grade: G, unit: 2, lesson: "Ⅱ-6", title: "사건의 독립과 종속 — 넓이 모형", type: "조작", time: "10분",
    tags: ["독립", "종속", "넓이 모형"], links: ["pst-bayes", "pst-trials"],
    desc: "정사각형을 A와 Aᶜ로 나누고 각 부분에서 B의 비율을 정해, 두 비율이 같을 때 A와 B가 독립이 됨을 넓이로 확인합니다.",
    obs: ["P(B | A) = P(B | Aᶜ)이면 B의 경계선이 한 직선으로 이어집니다.", "그때 P(A ∩ B) = P(A)P(B)가 성립합니다.", "경계선이 어긋나면 A가 B에 영향을 주는 종속입니다."],
    q: "배반사건(A ∩ B = ∅)인 두 사건은 독립일 수 있을까요?",
    formula: "A, B 독립 ⇔ P(B | A) = P(B) ⇔ P(A ∩ B) = P(A)P(B)",
    en: { title: "Independence by Area", desc: "Split a square into A and Aᶜ and see independence when B's boundary lines up." },
    view: VIEW,
    params: [
      { key: "pa", label: "P(A)", min: 0.05, max: 0.95, step: 0.01, value: 0.4 },
      { key: "ba", label: "P(B | A)", min: 0, max: 1, step: 0.01, value: 0.7 },
      { key: "bc", label: "P(B | Aᶜ)", min: 0, max: 1, step: 0.01, value: 0.3 },
    ],
    buttons: [["ind", "독립이 되도록 맞추기"]],
    onDo(k, s) { if (k === "ind") s.bc = s.ba; },
    draw(s, g) {
      const X0 = 3, Y0 = 0.8, S = 9.6, xa = X0 + S * s.pa;
      g.poly([[X0, Y0], [xa, Y0], [xa, Y0 + S * s.ba], [X0, Y0 + S * s.ba]], { fill: "e", fo: 0.55, stroke: false });
      g.poly([[xa, Y0], [X0 + S, Y0], [X0 + S, Y0 + S * s.bc], [xa, Y0 + S * s.bc]], { fill: "b", fo: 0.45, stroke: false });
      g.poly([[X0, Y0], [X0 + S, Y0], [X0 + S, Y0 + S], [X0, Y0 + S]], { color: "ink", w: 2 });
      g.seg([xa, Y0], [xa, Y0 + S], { color: "ink", w: 2 });
      g.seg([X0, Y0 + S * s.ba], [xa, Y0 + S * s.ba], { color: "d", w: 3 }).seg([xa, Y0 + S * s.bc], [X0 + S, Y0 + S * s.bc], { color: "d", w: 3 });
      g.text([(X0 + xa) / 2, Y0 + S], "A", { dy: -8, bold: true }).text([(xa + X0 + S) / 2, Y0 + S], "Aᶜ", { dy: -8, bold: true });
      g.text([(X0 + xa) / 2, Y0 + (S * s.ba) / 2], "A ∩ B", { dy: 4, bold: true, color: "ink" });
    },
    metrics(s) { const pb = s.pa * s.ba + (1 - s.pa) * s.bc, ind = Math.abs(s.ba - s.bc) < 1e-9; return [["P(B)", fmt(pb, 3)], ["P(A ∩ B)", fmt(s.pa * s.ba, 3)], ["P(A)P(B)", fmt(s.pa * pb, 3)], ["판정", ind ? "독립" : "종속", "key"]]; },
  },
  {
    id: "pst-trials", grade: G, unit: 2, lesson: "Ⅱ-6", title: "독립시행의 확률 — 확률 나무", type: "조작", time: "10분",
    tags: ["독립시행", "확률 나무", "ₙCᵣpʳqⁿ⁻ʳ"], links: ["pst-independence", "pst-binomial"],
    desc: "성공 확률이 p인 시행을 n번 할 때 성공이 정확히 k번인 가지를 모두 칠하고, 가지 수 ₙCₖ와 한 가지의 확률 pᵏqⁿ⁻ᵏ의 곱을 확인합니다.",
    obs: ["각 가지의 확률은 그 경로의 확률을 곱한 것입니다.", "성공 k번인 가지는 ₙCₖ개이고 모두 확률이 같습니다."],
    q: "동전을 5번 던져 앞면이 3번 나올 확률은 얼마일까요?",
    formula: "P(성공 k번) = ₙCₖ pᵏ (1 − p)ⁿ⁻ᵏ",
    en: { title: "Independent Trials Tree", desc: "Highlight all branches with exactly k successes and multiply nCk by pᵏqⁿ⁻ᵏ." },
    view: VIEW,
    params: [{ key: "n", label: "시행 횟수 n", min: 1, max: 5, step: 1, value: 4 }, { key: "k", label: "성공 횟수 k", min: 0, max: 5, step: 1, value: 2 }, { key: "p", label: "성공 확률 p", min: 0.05, max: 0.95, step: 0.05, value: 0.5 }],
    derive(s) { if (s.k > s.n) s.k = s.n; },
    draw(s, g) {
      const n = s.n, x = (i, l) => 0.6 + ((i + 0.5) / 2 ** l) * 14.8, yv = (l) => 10.4 - (l * 9.2) / n;
      const walk = (l, i, succ) => {
        if (l === n) { const hit = succ === s.k; g.text([x(i, l), yv(l)], hit ? "★" : "·", { dy: 16, color: hit ? "d" : "muted", size: 13, bold: true }); return; }
        [[1, "성공"], [0, "실패"]].forEach(([ok], t) => {
          const ni = i * 2 + t, sNext = succ + ok, P0 = [l === 0 ? 8 : x(i, l), yv(l)], P1 = [x(ni, l + 1), yv(l + 1)];
          const canHit = sNext <= s.k && sNext + (n - l - 1) >= s.k;
          g.seg(P0, P1, { color: canHit ? (ok ? "c" : "b") : "grid", w: canHit ? 2.2 : 1 });
          walk(l + 1, ni, sNext);
        });
      };
      walk(0, 0, 0);
      g.note(18, 30, "초록: 성공 · 파랑: 실패 · ★ 성공이 정확히 k번", { color: "muted" });
    },
    metrics(s) { return [["★ 가지 수", `${s.n}C${s.k} = ${C(s.n, s.k)}`], ["한 가지의 확률", fmt(s.p ** s.k * (1 - s.p) ** (s.n - s.k), 5)], ["P(성공 k번)", fmt(binom(s.n, s.p, s.k), 5), "key"]]; },
  },

  // ───────── Ⅲ 확률분포 ─────────
  {
    id: "pst-expectation", grade: G, unit: 3, lesson: "Ⅲ-1", title: "이산확률변수의 기댓값 — 무게중심", type: "데이터", time: "10분",
    tags: ["기댓값", "분산", "확률분포"], links: ["averages", "pst-binomial"],
    desc: "확률분포의 막대 높이를 바꾸며 기댓값 E(X)가 막대들이 균형을 이루는 받침점 위치이고, 분산은 퍼진 정도임을 봅니다.",
    obs: ["확률의 합은 항상 1이 되도록 자동으로 맞춰집니다.", "막대를 한쪽으로 몰면 받침점도 그쪽으로 옮겨갑니다.", "V(X) = E(X²) − {E(X)}²입니다."],
    q: "당첨금이 다른 복권의 기댓값으로 공정한 가격을 어떻게 정할 수 있을까요?",
    formula: "E(X) = Σ xᵢpᵢ · V(X) = Σ (xᵢ − m)²pᵢ = E(X²) − m²",
    en: { title: "Expected Value as a Balance Point", desc: "Change the bar heights of a distribution and see E(X) as the balance point." },
    view: VIEW,
    params: [0, 1, 2, 3, 4].map((x) => ({ key: `w${x}`, label: `X = ${x}의 가중치`, min: 0, max: 10, step: 0.5, value: [1, 3, 4, 2, 1][x] })),
    ps(s) { const w = [0, 1, 2, 3, 4].map((x) => s[`w${x}`]), t = w.reduce((a, b) => a + b, 0) || 1; return w.map((v) => v / t); },
    draw(s, g) {
      const p = this.ps(s), m = p.reduce((a, v, x) => a + v * x, 0), V = p.reduce((a, v, x) => a + v * (x - m) ** 2, 0);
      const M = chart(g, [2, 2.4, 15, 10.3], [-0.6, 4.6], [0, niceMax(Math.max(...p, 0.01) * 1.1)], { xt: [0, 1, 2, 3, 4], yt: ticks(0, niceMax(Math.max(...p, 0.01) * 1.1), 4), yf: (v) => fmt(v, 2), xName: "X", yName: "P(X = x)" });
      p.forEach((v, x) => { bar(g, M, x, 0.6, v, { fill: "b", color: "b" }); g.text(M([x, v]), fmt(v, 3), { dy: -6, size: 11, color: "b", mono: true }); });
      const b = M([m, 0]);
      g.poly([b, [b[0] - 0.35, b[1] - 0.8], [b[0] + 0.35, b[1] - 0.8]], { fill: "a", fo: 0.9, color: "a" });
      g.text([b[0], b[1] - 0.8], `E(X) = ${fmt(m, 3)}`, { dy: 18, color: "a", bold: true });
      const sd = Math.sqrt(V); g.seg(M([m - sd, 0]), M([m + sd, 0]), { color: "e", w: 5, opacity: 0.6 });
    },
    metrics(s) { const p = this.ps(s), m = p.reduce((a, v, x) => a + v * x, 0), E2 = p.reduce((a, v, x) => a + v * x * x, 0); return [["E(X)", fmt(m, 4), "key"], ["E(X²)", fmt(E2, 4)], ["V(X)", fmt(E2 - m * m, 4)], ["σ(X)", fmt(Math.sqrt(E2 - m * m), 4)]]; },
  },
  {
    id: "pst-binomial", grade: G, unit: 3, lesson: "Ⅲ-3", title: "이항분포 B(n, p)와 정규분포 근사", type: "데이터", time: "12분",
    tags: ["이항분포", "평균 np", "정규 근사"], links: ["pst-trials", "pst-normal", "lab-galton"],
    desc: "n과 p를 바꾸며 이항분포의 막대 모양이 평균 np를 중심으로 모이고, n이 커지면 종 모양의 정규분포에 가까워지는 것을 봅니다.",
    obs: ["평균 np, 분산 np(1 − p)입니다.", "p = 0.5이면 좌우대칭입니다.", "n이 충분히 크면 N(np, npq)로 근사할 수 있습니다."],
    q: "n = 100, p = 0.5일 때 성공 횟수가 40 이상 60 이하일 확률은 대략 얼마일까요?",
    formula: "P(X = x) = ₙCₓ pˣ qⁿ⁻ˣ · E(X) = np · V(X) = npq",
    en: { title: "Binomial Distribution and Normal Approximation", desc: "Watch the binomial bars gather around np and approach a bell curve as n grows." },
    view: VIEW,
    params: [{ key: "n", label: "n", min: 1, max: 80, step: 1, value: 20 }, { key: "p", label: "p", min: 0.05, max: 0.95, step: 0.01, value: 0.3 }, { key: "norm", label: "정규분포 곡선 겹치기", type: "check", value: true }],
    anim: { key: "n", min: 1, max: 80, speed: 10, label: "n 늘리기" },
    derive(s) { s.n = Math.round(s.n); },
    draw(s, g) {
      const n = s.n, P = Array.from({ length: n + 1 }, (_, k) => binom(n, s.p, k)), ym = niceMax(Math.max(...P) * 1.1);
      const M = chart(g, [1.8, 1.4, 15.4, 10.3], [-0.6, n + 0.6], [0, ym], { xt: Array.from({ length: Math.floor(n / Math.max(1, Math.ceil(n / 10))) + 1 }, (_, i) => i * Math.max(1, Math.ceil(n / 10))), yt: ticks(0, ym, 4), yf: (v) => fmt(v, 3), xName: "성공 횟수", yName: "확률" });
      P.forEach((v, k) => bar(g, M, k, 0.8, v, { fill: "b", color: "b", w: n > 40 ? 0.5 : 1 }));
      const m = n * s.p, sd = Math.sqrt(n * s.p * (1 - s.p));
      if (s.norm && sd > 0) g.param((x) => M([x, npdf(x, m, sd)]), -0.5, n + 0.5, { color: "a", w: 3 });
      g.seg(M([m, 0]), M([m, ym * 0.98]), { color: "d", w: 1.6, dash: "5 4" }).text(M([m, ym]), `np = ${fmt(m, 2)}`, { dy: 4, color: "d", bold: true, size: 12 });
    },
    metrics(s) { const m = s.n * s.p, v = m * (1 - s.p); return [["E(X) = np", fmt(m, 3), "key"], ["V(X) = npq", fmt(v, 3)], ["σ(X)", fmt(Math.sqrt(v), 3)]]; },
  },
  {
    id: "pst-lln", grade: G, unit: 3, lesson: "Ⅲ-3", title: "큰 수의 법칙", type: "데이터", time: "8분",
    tags: ["큰 수의 법칙", "상대도수", "시뮬레이션"], links: ["pst-dice-sum", "pst-binomial"],
    desc: "성공 확률이 p인 시행을 계속하며 상대도수 X/n의 그래프가 p 둘레의 좁은 띠 안으로 들어가는 모습을 봅니다.",
    obs: ["초반에는 상대도수가 크게 흔들립니다.", "n이 커질수록 |(X/n) − p| < h일 확률이 1에 가까워집니다.", "그러나 한 번 한 번의 결과는 여전히 우연입니다."],
    q: "동전을 10번 던져 앞면이 7번 나오면 동전이 불공정하다고 말할 수 있을까요?",
    formula: "lim(n→∞) P(|(X/n) − p| < h) = 1",
    en: { title: "Law of Large Numbers", desc: "Keep running trials and watch X/n settle into a band around p." },
    view: VIEW,
    params: [{ key: "p", label: "성공 확률 p", min: 0.1, max: 0.9, step: 0.05, value: 0.5 }, { key: "h", label: "띠의 폭 h", min: 0.01, max: 0.2, step: 0.01, value: 0.05 }],
    init: () => ({ path: [], succ: 0, n: 0 }),
    buttons: [["reset", "처음부터"]],
    onDo(k, s) { if (k === "reset") { s.path = []; s.succ = 0; s.n = 0; } },
    prefill(s) { for (let i = 0; i < 25; i++) this.anim.step(s, 0.05, this); },
    onChange(s, k) { if (k === "p") { s.path = []; s.succ = 0; s.n = 0; for (let i = 0; i < 25; i++) this.anim.step(s, 0.05, this); } },
    anim: { label: "시행 계속하기", autoplay: false, step(s, dt) { for (let i = 0; i < Math.max(2, Math.round(160 * dt)) && s.n < 3000; i++) { s.succ += Math.random() < s.p ? 1 : 0; s.n++; if (s.n <= 50 || s.n % 5 === 0) s.path.push([s.n, s.succ / s.n]); } } },
    draw(s, g) {
      const M = chart(g, [1.8, 1.4, 15.4, 10.3], [0, 3000], [0, 1], { xt: [0, 500, 1000, 1500, 2000, 2500, 3000], yt: [0, 0.25, 0.5, 0.75, 1], yf: (v) => fmt(v, 2), xName: "시행 횟수 n", yName: "상대도수 X/n" });
      g.poly([M([0, s.p - s.h]), M([3000, s.p - s.h]), M([3000, s.p + s.h]), M([0, s.p + s.h])], { fill: "c", fo: 0.18, stroke: false });
      g.seg(M([0, s.p]), M([3000, s.p]), { color: "c", w: 1.6, dash: "5 4" });
      if (s.path.length > 1) g.path(s.path.map(M), { color: "a", w: 2 });
      if (!s.n) g.note(200, 200, "‘시행 계속하기’를 눌러 시작하세요", { color: "muted", bold: true });
    },
    metrics(s) { return [["시행 횟수", fmt(s.n)], ["상대도수", s.n ? fmt(s.succ / s.n, 4) : "—", "key"], ["|(X/n) − p|", s.n ? fmt(Math.abs(s.succ / s.n - s.p), 4) : "—"]]; },
  },
  {
    id: "pst-continuous", grade: G, unit: 3, lesson: "Ⅲ-4", title: "연속확률변수 — 넓이가 곧 확률", type: "2D", time: "8분",
    tags: ["확률밀도함수", "넓이", "연속"], links: ["pst-normal", "calc-riemann"],
    desc: "확률밀도함수의 그래프 아래 전체 넓이가 1이고, a ≤ X ≤ b일 확률이 그 구간의 넓이임을 균등·삼각형 분포로 확인합니다.",
    obs: ["연속확률변수에서 한 점의 확률 P(X = a)는 0입니다.", "그래서 P(a ≤ X ≤ b) = P(a < X < b)입니다.", "그래프 아래 넓이의 합은 언제나 1입니다."],
    q: "버스가 10분 간격으로 올 때 5분 이상 기다릴 확률은 얼마일까요?",
    formula: "P(a ≤ X ≤ b) = ∫ₐᵇ f(x)dx · ∫ f(x)dx = 1",
    en: { title: "Continuous Random Variables", desc: "Probability equals the area under the density curve." },
    view: VIEW,
    params: [
      { key: "shape", label: "분포", type: "seg", value: "tri", options: [["uni", "균등 (0~10)"], ["tri", "삼각형 (0~10)"]] },
      { key: "a", label: "a", min: 0, max: 10, step: 0.1, value: 3 },
      { key: "b", label: "b", min: 0, max: 10, step: 0.1, value: 6.5 },
    ],
    derive(s) { if (s.b < s.a) s.b = s.a; },
    f(s, x) { if (x < 0 || x > 10) return 0; return s.shape === "uni" ? 0.1 : x <= 5 ? x / 25 : (10 - x) / 25; },
    F(s, x) { x = clamp(x, 0, 10); if (s.shape === "uni") return x / 10; return x <= 5 ? (x * x) / 50 : 1 - ((10 - x) ** 2) / 50; },
    drags: { A: { at: (s) => [1.8 + ((s.a + 0.5) / 11) * 13.6, 1.4], move: (s, p) => (s.a = Math.min(s.b, ((p[0] - 1.8) / 13.6) * 11 - 0.5)) }, B: { at: (s) => [1.8 + ((s.b + 0.5) / 11) * 13.6, 1.4], move: (s, p) => (s.b = Math.max(s.a, ((p[0] - 1.8) / 13.6) * 11 - 0.5)) } },
    draw(s, g) {
      const M = chart(g, [1.8, 1.4, 15.4, 10.3], [-0.5, 10.5], [0, 0.25], { xt: [0, 2, 4, 6, 8, 10], yt: [0, 0.05, 0.1, 0.15, 0.2, 0.25], yf: (v) => fmt(v, 2), xName: "x", yName: "f(x)" });
      const pts = []; for (let i = 0; i <= 200; i++) { const x = s.a + ((s.b - s.a) * i) / 200; pts.push(M([x, this.f(s, x)])); }
      g.poly([M([s.a, 0]), ...pts, M([s.b, 0])], { fill: "a", fo: 0.35, stroke: false });
      g.param((x) => M([x, this.f(s, x)]), -0.5, 10.5, { color: "b", w: 3, n: 400 });
    },
    metrics(s) { return [["P(a ≤ X ≤ b)", fmt(this.F(s, s.b) - this.F(s, s.a), 4), "key"], ["전체 넓이", "1"]]; },
  },
  {
    id: "pst-normal", grade: G, unit: 3, lesson: "Ⅲ-5", title: "정규분포와 표준화", type: "2D", time: "12분",
    tags: ["정규분포", "표준화", "68-95-99.7"], links: ["pst-binomial", "pst-sample-mean"],
    desc: "평균 m과 표준편차 σ를 바꾸며 정규분포 곡선의 위치와 퍼짐을 보고, Z = (X − m)/σ로 표준정규분포의 넓이를 구합니다.",
    obs: ["m을 바꾸면 곡선이 좌우로 옮겨지고, σ가 커지면 낮고 넓게 퍼집니다.", "m ± σ, m ± 2σ, m ± 3σ 안에 약 68%, 95%, 99.7%가 들어갑니다.", "표준화하면 모든 정규분포를 하나의 표로 계산할 수 있습니다."],
    q: "평균 170cm, 표준편차 6cm인 키에서 182cm 이상은 몇 %쯤일까요?",
    formula: "Z = (X − m)/σ ~ N(0, 1) · P(a ≤ X ≤ b) = P((a − m)/σ ≤ Z ≤ (b − m)/σ)",
    en: { title: "Normal Distribution and Standardization", desc: "Shift and spread the bell curve and compute areas with Z = (X − m)/σ." },
    view: VIEW,
    params: [
      { key: "m", label: "평균 m", min: 150, max: 190, step: 1, value: 170 },
      { key: "sd", label: "표준편차 σ", min: 3, max: 12, step: 0.5, value: 6 },
      { key: "a", label: "a", min: 130, max: 210, step: 1, value: 164 },
      { key: "b", label: "b", min: 130, max: 210, step: 1, value: 182 },
      { key: "rule", label: "m ± σ, 2σ, 3σ 띠 보기", type: "check", value: false },
    ],
    derive(s) { if (s.b < s.a) s.b = s.a; },
    drags: { A: { at: (s) => [1.8 + ((s.a - 130) / 80) * 13.6, 1.4], move: (s, p) => (s.a = Math.min(s.b, Math.round(130 + ((p[0] - 1.8) / 13.6) * 80))), color: "a" }, B: { at: (s) => [1.8 + ((s.b - 130) / 80) * 13.6, 1.4], move: (s, p) => (s.b = Math.max(s.a, Math.round(130 + ((p[0] - 1.8) / 13.6) * 80))), color: "a" } },
    draw(s, g) {
      const M = chart(g, [1.8, 1.4, 15.4, 10.3], [130, 210], [0, 0.14], { xt: [130, 140, 150, 160, 170, 180, 190, 200, 210], yt: [0, 0.04, 0.08, 0.12], yf: (v) => fmt(v, 2), xName: "X", yName: "밀도" });
      const f = (x) => npdf(x, s.m, s.sd);
      if (s.rule) [3, 2, 1].forEach((k, i) => { const pts = []; for (let j = 0; j <= 120; j++) { const x = s.m - k * s.sd + (2 * k * s.sd * j) / 120; pts.push(M([x, Math.min(0.14, f(x))])); } g.poly([M([s.m - k * s.sd, 0]), ...pts, M([s.m + k * s.sd, 0])], { fill: ["e", "c", "b"][i], fo: 0.18, stroke: false }); });
      const pts = []; for (let j = 0; j <= 200; j++) { const x = s.a + ((s.b - s.a) * j) / 200; pts.push(M([x, Math.min(0.14, f(x))])); }
      g.poly([M([s.a, 0]), ...pts, M([s.b, 0])], { fill: "a", fo: 0.4, stroke: false });
      g.param((x) => M([x, Math.min(0.14, f(x))]), 130, 210, { color: "b", w: 3, n: 400 });
      g.seg(M([s.m, 0]), M([s.m, Math.min(0.14, f(s.m))]), { color: "d", w: 1.4, dash: "4 4" });
    },
    metrics(s) { const za = (s.a - s.m) / s.sd, zb = (s.b - s.m) / s.sd; return [["표준화", `${fmt(za, 2)} ≤ Z ≤ ${fmt(zb, 2)}`], ["P(a ≤ X ≤ b)", fmt(ncdf(zb) - ncdf(za), 4), "key"], ["P(X ≥ b)", fmt(1 - ncdf(zb), 4)]]; },
  },

  // ───────── Ⅳ 통계적 추정 ─────────
  {
    id: "pst-sample-mean", grade: G, unit: 4, lesson: "Ⅳ-2", title: "표본평균의 분포 — 모양이 달라도 종 모양으로", type: "데이터", time: "12분",
    tags: ["표본평균", "σ/√n", "중심극한"], links: ["pst-normal", "pst-confidence"],
    desc: "모집단의 모양(균등·치우침·쌍봉)을 고르고 크기 n인 표본을 계속 뽑아 표본평균의 히스토그램이 평균 m, 표준편차 σ/√n인 정규분포에 가까워지는 모습을 봅니다.",
    obs: ["표본평균의 평균은 모평균 m과 같습니다.", "표본평균의 표준편차는 σ/√n으로 n이 커질수록 줄어듭니다.", "n이 크면 모집단이 치우쳐 있어도 표본평균의 분포는 정규분포에 가깝습니다."],
    q: "표본의 크기를 4배로 늘리면 표본평균의 표준편차는 몇 배가 될까요?",
    formula: "E(X̄) = m · σ(X̄) = σ/√n · n이 크면 X̄ ~ N(m, σ²/n)",
    en: { title: "Distribution of the Sample Mean", desc: "Draw many samples and watch the sample means form a normal curve with spread σ/√n." },
    view: VIEW,
    params: [
      { key: "pop", label: "모집단", type: "seg", value: "skew", options: [["uni", "균등"], ["skew", "치우침"], ["bi", "쌍봉"]] },
      { key: "n", label: "표본의 크기 n", min: 1, max: 30, step: 1, value: 5 },
    ],
    W: { uni: [1, 1, 1, 1, 1, 1], skew: [6, 4, 2.5, 1.5, 1, 0.5], bi: [4, 1.5, 0.5, 0.5, 1.5, 4] },
    pop(s) { const w = this.W[s.pop], t = w.reduce((a, b) => a + b, 0), p = w.map((v) => v / t), m = p.reduce((a, v, i) => a + v * (i + 1), 0), v = p.reduce((a, q, i) => a + q * (i + 1 - m) ** 2, 0); return { p, m, sd: Math.sqrt(v) }; },
    init: () => ({ means: [] }),
    prefill(s) { for (let i = 0; i < 500; i++) s.means.push(this.draw1(s)); },
    onChange(s, k) { if (k === "pop" || k === "n") { s.means = []; for (let i = 0; i < 500; i++) s.means.push(this.draw1(s)); } },
    buttons: [["b100", "표본 100개 뽑기"], ["reset", "초기화"]],
    draw1(s) { const { p } = this.pop(s); let sum = 0; for (let i = 0; i < s.n; i++) { let r = Math.random(), k = 0; while (r > p[k] && k < 5) { r -= p[k]; k++; } sum += k + 1; } return sum / s.n; },
    onDo(k, s) { if (k === "reset") s.means = []; if (k === "b100") for (let i = 0; i < 100; i++) s.means.push(this.draw1(s)); },
    anim: { label: "계속 뽑기", step(s, dt, sp) { for (let i = 0; i < Math.max(1, Math.round(120 * dt)) && s.means.length < 20000; i++) s.means.push(sp.draw1(s)); } },
    draw(s, g) {
      const { p, m, sd } = this.pop(s);
      const M1 = chart(g, [1.2, 7.4, 5.4, 10.4], [0.4, 6.6], [0, Math.max(...p) * 1.15], { xt: [1, 2, 3, 4, 5, 6], yaxis: false });
      p.forEach((v, i) => bar(g, M1, i + 1, 0.7, v, { fill: "e", color: "e" }));
      g.text([3.3, 10.4], "모집단", { dy: -4, color: "e", bold: true, size: 12 });
      const bins = 50, H = Array(bins).fill(0); s.means.forEach((x) => { const b = Math.min(bins - 1, Math.floor(((x - 1) / 5) * bins)); H[b]++; });
      const N = s.means.length || 1, bw = 5 / bins, dens = H.map((c) => c / N / bw), ym = Math.max(npdf(m, m, sd / Math.sqrt(s.n)) * 1.15, ...dens, 0.5);
      const M = chart(g, [6.4, 1.4, 15.4, 10.3], [1, 6], [0, ym], { xt: [1, 2, 3, 4, 5, 6], xName: "표본평균 X̄" });
      dens.forEach((d, i) => { if (d > 0) bar(g, M, 1 + (i + 0.5) * bw, bw * 0.92, Math.min(d, ym), { fill: "b", color: "b", w: 0.5 }); });
      g.param((x) => M([x, Math.min(ym, npdf(x, m, sd / Math.sqrt(s.n)))]), 1, 6, { color: "a", w: 2.6, n: 300 });
      g.seg(M([m, 0]), M([m, ym * 0.97]), { color: "d", w: 1.4, dash: "4 4" });
    },
    metrics(s) {
      const { m, sd } = this.pop(s), N = s.means.length, mm = N ? s.means.reduce((a, b) => a + b, 0) / N : NaN, ss = N > 1 ? Math.sqrt(s.means.reduce((a, b) => a + (b - mm) ** 2, 0) / N) : NaN;
      return [["모평균 m · 모표준편차 σ", `${fmt(m, 3)} · ${fmt(sd, 3)}`], ["뽑은 표본 수", fmt(N)], ["X̄들의 평균", N ? fmt(mm, 3) : "—"], ["X̄들의 표준편차 (이론 σ/√n)", `${N > 1 ? fmt(ss, 3) : "—"} (${fmt(sd / Math.sqrt(s.n), 3)})`, "key"]];
    },
  },
  {
    id: "pst-confidence", grade: G, unit: 4, lesson: "Ⅳ-3", title: "모평균의 신뢰구간 — 50번 추정해 보기", type: "데이터", time: "12분",
    tags: ["신뢰구간", "신뢰도 95%", "모평균"], links: ["pst-sample-mean", "pst-proportion"],
    desc: "모평균이 50인 모집단에서 표본을 뽑아 신뢰구간을 50번 만들고, 그중 모평균을 포함하는 구간이 약 95%(99%)임을 확인합니다.",
    obs: ["신뢰구간은 표본마다 달라집니다.", "95% 신뢰도는 이런 구간을 여러 번 만들 때 약 95%가 모평균을 포함한다는 뜻입니다.", "n이 커지면 구간의 길이 2·k·σ/√n이 짧아집니다."],
    q: "신뢰도를 99%로 높이면 구간은 길어질까요, 짧아질까요?",
    formula: "x̄ − k·σ/√n ≤ m ≤ x̄ + k·σ/√n (k = 1.96 또는 2.58)",
    en: { title: "Confidence Intervals for the Mean", desc: "Build 50 intervals and count how many contain the true mean." },
    view: VIEW,
    params: [{ key: "n", label: "표본의 크기 n", min: 4, max: 100, step: 1, value: 25 }, { key: "lvl", label: "신뢰도", type: "seg", value: 95, options: [[95, "95%"], [99, "99%"]] }],
    init: () => ({ xs: [] }),
    buttons: [["go", "표본 50개로 추정하기"]],
    onDo(k, s) { if (k === "go") s.xs = Array.from({ length: 50 }, () => 50 + (10 / Math.sqrt(s.n)) * randn()); },
    prefill(s) { this.onDo("go", s); },
    onChange(s, k) { if (k === "n") this.onDo("go", s); },
    draw(s, g) {
      const kk = s.lvl === 99 ? 2.58 : 1.96, e = (kk * 10) / Math.sqrt(s.n);
      const M = chart(g, [1.6, 0.8, 15.4, 10.6], [35, 65], [0, 51], { xt: [35, 40, 45, 50, 55, 60, 65], yaxis: false, xName: "모평균 m = 50" });
      g.seg(M([50, 0]), M([50, 51]), { color: "ink", w: 1.6, dash: "5 4" });
      s.xs.forEach((x, i) => { const hit = Math.abs(x - 50) <= e; g.seg(M([Math.max(35, x - e), i + 1]), M([Math.min(65, x + e), i + 1]), { color: hit ? "b" : "d", w: hit ? 2 : 3 }); g.circle(M([x, i + 1]), 0.06, { color: hit ? "b" : "d", fill: hit ? "b" : "d", fo: 1, w: 1 }); });
      if (!s.xs.length) g.note(180, 200, "‘표본 50개로 추정하기’를 눌러 보세요", { color: "muted", bold: true });
    },
    metrics(s) { const kk = s.lvl === 99 ? 2.58 : 1.96, e = (kk * 10) / Math.sqrt(s.n), hit = s.xs.filter((x) => Math.abs(x - 50) <= e).length; return [["구간의 길이", fmt(2 * e, 3)], ["모평균을 포함한 구간", s.xs.length ? `${hit} / 50 (${fmt((hit / 50) * 100, 0)}%)` : "—", "key"], ["모표준편차 σ", "10 (안다고 가정)"]]; },
  },
  {
    id: "pst-proportion", grade: G, unit: 4, lesson: "Ⅳ-4", title: "모비율의 추정 — 여론조사", type: "데이터", time: "10분",
    tags: ["표본비율", "모비율", "오차 한계"], links: ["pst-confidence", "pst-binomial"],
    desc: "지지율이 p인 모집단에서 n명을 조사한 표본비율 p̂를 반복해 얻고, p̂의 분포와 오차 한계 ±1.96√(p̂(1 − p̂)/n)을 봅니다.",
    obs: ["p̂의 평균은 p, 표준편차는 √(pq/n)입니다.", "조사 인원을 4배로 늘리면 오차 한계가 절반이 됩니다.", "여론조사의 '±3.1%p'는 이 오차 한계입니다."],
    q: "1000명 조사의 오차 한계가 약 ±3.1%p인 이유를 계산해 보세요.",
    formula: "p̂ − 1.96√(p̂q̂/n) ≤ p ≤ p̂ + 1.96√(p̂q̂/n)",
    en: { title: "Estimating a Proportion", desc: "Repeat a poll, see the distribution of p̂, and read the margin of error." },
    view: VIEW,
    params: [{ key: "p", label: "실제 지지율 p", min: 0.1, max: 0.9, step: 0.01, value: 0.42, show: pct }, { key: "n", label: "조사 인원 n", min: 50, max: 2000, step: 50, value: 1000 }],
    init: () => ({ hats: [] }),
    prefill(s) { this.onDo("many", s); },
    onChange(s, k) { if (k === "p" || k === "n") { s.hats = []; this.onDo("many", s); } },
    buttons: [["one", "조사 1번"], ["many", "조사 200번"], ["reset", "초기화"]],
    poll(s) { let c = 0; const sd = Math.sqrt(s.p * (1 - s.p) * s.n); c = Math.round(s.n * s.p + sd * randn()); return clamp(c / s.n, 0, 1); },
    onDo(k, s) { if (k === "reset") s.hats = []; if (k === "one") s.hats.push(this.poll(s)); if (k === "many") for (let i = 0; i < 200; i++) s.hats.push(this.poll(s)); },
    draw(s, g) {
      const sd = Math.sqrt((s.p * (1 - s.p)) / s.n), lo = Math.max(0, s.p - 5 * sd), hi = Math.min(1, s.p + 5 * sd);
      const bins = 40, H = Array(bins).fill(0); s.hats.forEach((x) => { const b = Math.floor(((x - lo) / (hi - lo)) * bins); if (b >= 0 && b < bins) H[b]++; });
      const N = s.hats.length || 1, bw = (hi - lo) / bins, dens = H.map((c) => c / N / bw), ym = Math.max(npdf(s.p, s.p, sd) * 1.15, ...dens);
      const M = chart(g, [1.8, 3, 15.4, 10.3], [lo, hi], [0, ym], { xt: ticks(lo, hi, 4), xf: (v) => pct(v), yaxis: false, xName: "표본비율 p̂" });
      dens.forEach((d, i) => { if (d > 0) bar(g, M, lo + (i + 0.5) * bw, bw * 0.9, d, { fill: "b", color: "b", w: 0.5 }); });
      g.param((x) => M([x, npdf(x, s.p, sd)]), lo, hi, { color: "a", w: 2.6 });
      g.seg(M([s.p, 0]), M([s.p, ym * 0.97]), { color: "d", w: 1.4, dash: "4 4" });
      const last = s.hats[s.hats.length - 1];
      if (last != null) { const e = 1.96 * Math.sqrt((last * (1 - last)) / s.n); const y = 1.6; const a = M([Math.max(lo, last - e), 0]), b = M([Math.min(hi, last + e), 0]); g.seg([a[0], y], [b[0], y], { color: "c", w: 4 }); g.circle([M([last, 0])[0], y], 0.12, { color: "c", fill: "c", fo: 1 }); g.text([M([last, 0])[0], y], "마지막 조사의 95% 신뢰구간", { dy: 22, color: "c", bold: true, size: 12 }); }
    },
    metrics(s) { const last = s.hats[s.hats.length - 1], e = last != null ? 1.96 * Math.sqrt((last * (1 - last)) / s.n) : 1.96 * Math.sqrt((s.p * (1 - s.p)) / s.n); return [["조사 횟수", fmt(s.hats.length)], ["마지막 p̂", last != null ? pct(last) : "—"], ["오차 한계 (95%)", `±${fmt(e * 100, 2)}%p`, "key"]]; },
  },
];
