// 미적분Ⅰ(극한·연속) · 미적분Ⅱ(수열의 극한·n계도함수·이계도함수) 보강
import { fmt, frac, piFmt, dist, add, sub, mul, lerp, clamp } from "./hs-core.js";

const I = 7, II = 13;
const FACT = (n) => { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; };
const SUPN = (n) => String(n).replace(/[0-9]/g, (d) => "⁰¹²³⁴⁵⁶⁷⁸⁹"[d]);
const dname = (n) => (n === 0 ? "f(x)" : n === 1 ? "f′(x)" : n === 2 ? "f″(x)" : n === 3 ? "f‴(x)" : `f⁽${SUPN(n)}⁾(x)`);

const LIMF = {
  hole: { name: "y = (x² − 1)/(x − 1)", f: (x) => (Math.abs(x - 1) < 1e-12 ? NaN : (x * x - 1) / (x - 1)), L: 2, R: 2, fa: "정의되지 않음" },
  jump: { name: "x < 1이면 x + 1, x ≥ 1이면 x − 2", f: (x) => (x < 1 ? x + 1 : x - 2), L: 2, R: -1, fa: "−1" },
  cont: { name: "y = x²/2 + 1", f: (x) => (x * x) / 2 + 1, L: 1.5, R: 1.5, fa: "3/2" },
  inf: { name: "y = 1/(x − 1)²", f: (x) => 1 / (x - 1) ** 2, L: Infinity, R: Infinity, fa: "정의되지 않음" },
};
const CF = {
  cub: { name: "y = (x³ − 6x)/4", f: (x) => (x ** 3 - 6 * x) / 4, d: (x) => (3 * x * x - 6) / 4, dd: (x) => (6 * x) / 4 },
  sin: { name: "y = 2 sin x", f: (x) => 2 * Math.sin(x), d: (x) => 2 * Math.cos(x), dd: (x) => -2 * Math.sin(x) },
  quar: { name: "y = (x⁴ − 6x²)/6 + 1", f: (x) => (x ** 4 - 6 * x * x) / 6 + 1, d: (x) => (4 * x ** 3 - 12 * x) / 6, dd: (x) => (12 * x * x - 12) / 6 },
  gauss: { name: "y = 3e^(−x²/2)", f: (x) => 3 * Math.exp(-(x * x) / 2), d: (x) => -3 * x * Math.exp(-(x * x) / 2), dd: (x) => 3 * (x * x - 1) * Math.exp(-(x * x) / 2) },
};
const NTH = {
  sin: { name: "y = sin x", f: (n) => (x) => Math.sin(x + (n * Math.PI) / 2), tex: (n) => (n % 4 === 0 ? "sin x" : n % 4 === 1 ? "cos x" : n % 4 === 2 ? "−sin x" : "−cos x"), gen: "sin(x + nπ/2)", view: { x: [-7, 7], y: [-3, 3] } },
  exp: { name: "y = eˣ", f: () => (x) => Math.exp(x), tex: () => "eˣ", gen: "eˣ (몇 번 미분해도 그대로)", view: { x: [-4, 3], y: [-1, 6] } },
  poly: { name: "y = x⁵/20", f: (n) => (x) => (n > 5 ? 0 : ((FACT(5) / FACT(5 - n)) * x ** (5 - n)) / 20), tex: (n) => (n > 5 ? "0" : n === 5 ? "6" : `${frac(FACT(5) / FACT(5 - n) / 20)}x${5 - n > 1 ? SUPN(5 - n) : ""}`), gen: "n > 5이면 0 (다항식은 언젠가 0)", view: { x: [-3, 3], y: [-5, 7] } },
  xex: { name: "y = xeˣ", f: (n) => (x) => (x + n) * Math.exp(x), tex: (n) => `(x + ${n})eˣ`, gen: "(x + n)eˣ", view: { x: [-7, 2], y: [-2, 6] } },
  ln: { name: "y = ln x", f: (n) => (x) => (x <= 0 ? NaN : n === 0 ? Math.log(x) : ((-1) ** (n - 1) * FACT(n - 1)) / x ** n), tex: (n) => (n === 0 ? "ln x" : `${n % 2 ? "" : "−"}${FACT(n - 1) === 1 ? "" : FACT(n - 1)}/x${n > 1 ? SUPN(n) : ""}`.replace(/^\//, "1/").replace(/^−\//, "−1/")), gen: "(−1)ⁿ⁻¹(n − 1)!/xⁿ", view: { x: [-0.5, 5], y: [-4, 4] } },
};

export default [
  // ───── 미적분Ⅰ Ⅰ 함수의 극한과 연속 ─────
  {
    id: "calc1-limit", grade: I, unit: 1, lesson: "Ⅰ-1", title: "함수의 극한 — 좌극한과 우극한", type: "조작", time: "10분",
    tags: ["좌극한", "우극한", "극한값"], links: ["calc1-continuity", "calc-secant-tangent"],
    desc: "x가 a의 왼쪽과 오른쪽에서 가까워질 때 함숫값이 다가가는 값을 각각 보고, 두 값이 같을 때만 극한이 존재함을 확인합니다. 구멍·끊김·무한대를 비교합니다.",
    obs: ["좌극한과 우극한이 같으면 극한값이 존재합니다.", "x = a에서 함숫값이 없어도 극한값은 있을 수 있습니다(구멍).", "끊긴 그래프는 좌극한과 우극한이 달라 극한이 없습니다."],
    q: "lim(x→1) (x² − 1)/(x − 1)의 값은 무엇이고, f(1)과는 어떻게 다를까요?",
    formula: "lim(x→a) f(x) = L ⇔ lim(x→a−) f(x) = lim(x→a+) f(x) = L",
    en: { title: "Limits: Left and Right", desc: "Approach a from both sides and compare left and right limits." },
    view: { x: [-2.5, 4.5], y: [-3.5, 5.5] },
    params: [{ key: "fn", label: "함수", type: "seg", value: "hole", options: [["hole", "구멍"], ["jump", "끊김"], ["cont", "연속"], ["inf", "무한대"]] }, { key: "h", label: "a까지의 거리 h", min: 0.01, max: 2, step: 0.01, value: 1.2 }],
    anim: { key: "h", min: 0.01, max: 2, speed: 0.5, label: "a로 다가가기" },
    drags: { R: { at: (s) => [1 + s.h, clamp(LIMF[s.fn].f(1 + s.h), -3.4, 5.4)], move: (s, p) => (s.h = clamp(p[0] - 1, 0.01, 2)), color: "b" }, L: { at: (s) => [1 - s.h, clamp(LIMF[s.fn].f(1 - s.h), -3.4, 5.4)], move: (s, p) => (s.h = clamp(1 - p[0], 0.01, 2)), color: "d" } },
    draw(s, g) {
      g.grid();
      const F = LIMF[s.fn];
      g.fx((x) => (Math.abs(x - 1) < 0.004 ? NaN : F.f(x)), { color: "a", w: 3, from: -2.5, to: 0.999 });
      g.fx((x) => (Math.abs(x - 1) < 0.004 ? NaN : F.f(x)), { color: "a", w: 3, from: 1.001, to: 4.5 });
      g.seg([1, -3.5], [1, 5.5], { color: "muted", w: 1.2, dash: "3 5" }).text([1, -3.5], "x = 1", { dy: -6, color: "muted", size: 12 });
      if (s.fn === "hole") g.point([1, 2], "", { color: "a", hollow: true, r: 6 });
      if (s.fn === "jump") { g.point([1, 2], "", { color: "a", hollow: true, r: 6 }); g.point([1, -1], "", { color: "a", r: 6 }); }
      if (s.fn === "cont") g.point([1, 1.5], "", { color: "a", r: 6 });
      const xl = 1 - s.h, xr = 1 + s.h, yl = F.f(xl), yr = F.f(xr);
      [[xl, yl, "d"], [xr, yr, "b"]].forEach(([x, y, c]) => { if (y < 5.5 && y > -3.5) { g.seg([x, 0], [x, y], { color: c, w: 1.4, dash: "4 4" }).seg([0, y], [x, y], { color: c, w: 1.4, dash: "4 4" }); } });
      if (Number.isFinite(F.L)) g.seg([-2.5, F.L], [-2.1, F.L], { color: "d", w: 4 });
      if (Number.isFinite(F.R)) g.seg([-2.5, F.R], [-2.1, F.R], { color: "b", w: 4 });
    },
    metrics(s) { const F = LIMF[s.fn], v = (x) => (Number.isFinite(x) ? fmt(x, 4) : "∞"); const ex = F.L === F.R; return [["f(1 − h)", v(F.f(1 - s.h))], ["f(1 + h)", v(F.f(1 + s.h))], ["좌극한 · 우극한", `${v(F.L)} · ${v(F.R)}`], ["극한 lim(x→1) f(x)", ex ? (Number.isFinite(F.L) ? v(F.L) : "∞로 발산") : "존재하지 않음", "key"], ["f(1)", F.fa]]; },
  },
  {
    id: "calc1-continuity", grade: I, unit: 1, lesson: "Ⅰ-3", title: "연속과 사잇값 정리", type: "조작", time: "10분",
    tags: ["연속", "사잇값 정리", "방정식의 실근"], links: ["calc1-limit", "calc-mean-value"],
    desc: "닫힌구간에서 연속인 함수는 f(a)와 f(b) 사이의 모든 값 k를 적어도 한 번 지난다는 사잇값 정리를, 구간 끝과 k를 움직이며 확인하고 불연속이면 깨지는 것을 봅니다.",
    obs: ["f가 [a, b]에서 연속이면 f(a)와 f(b) 사이의 k에 대해 f(c) = k인 c가 있습니다.", "f(a)f(b) < 0이면 방정식 f(x) = 0은 (a, b)에 실근을 가집니다.", "그래프가 끊기면 k를 건너뛸 수 있어 정리가 성립하지 않습니다."],
    q: "x³ + x − 1 = 0이 0과 1 사이에 실근을 가짐을 설명해 보세요.",
    formula: "f가 [a, b]에서 연속, f(a) ≠ f(b), k는 그 사이 ⇒ f(c) = k인 c가 (a, b)에 존재",
    en: { title: "Continuity and the Intermediate Value Theorem", desc: "A continuous function on [a, b] hits every value between f(a) and f(b)." },
    view: { x: [-4, 4], y: [-4, 4.5] },
    params: [{ key: "a", label: "a", min: -3.8, max: 3, step: 0.05, value: -2.5 }, { key: "b", label: "b", min: -3, max: 3.8, step: 0.05, value: 2.2 }, { key: "k", label: "k", min: -3.5, max: 4, step: 0.05, value: 0.4 }, { key: "gap", label: "불연속 함수로 바꾸기", type: "check", value: false }],
    f(s, x) { const y = (x ** 3 - 6 * x) / 4 + 0.3; return s.gap && x > 0.4 ? y + 2.2 : y; },
    derive(s) { if (s.b < s.a + 0.3) s.b = s.a + 0.3; },
    drags: { A: { at: (s) => [s.a, 0], move: (s, p) => (s.a = p[0]), color: "c" }, B: { at: (s) => [s.b, 0], move: (s, p) => (s.b = p[0]), color: "c" }, K: { at: (s) => [-3.7, s.k], move: (s, p) => (s.k = p[1]), color: "e" } },
    roots(s) { const out = []; const N = 1600; for (let i = 0; i < N; i++) { const x0 = s.a + ((s.b - s.a) * i) / N, x1 = x0 + (s.b - s.a) / N, u = this.f(s, x0) - s.k, v = this.f(s, x1) - s.k; if (u * v <= 0 && !(s.gap && x0 < 0.4 && x1 > 0.4)) out.push((x0 + x1) / 2); } return out.filter((x, i, a) => !i || x - a[i - 1] > 0.02); },
    draw(s, g) {
      g.grid();
      const fa = this.f(s, s.a), fb = this.f(s, s.b);
      g.poly([[s.a, Math.min(fa, fb)], [s.b, Math.min(fa, fb)], [s.b, Math.max(fa, fb)], [s.a, Math.max(fa, fb)]], { fill: "f", fo: 0.1, stroke: false });
      if (s.gap) { g.fx((x) => this.f(s, x), { color: "a", w: 3, from: -4, to: 0.399 }); g.fx((x) => this.f(s, x), { color: "a", w: 3, from: 0.401, to: 4 }); }
      else g.fx((x) => this.f(s, x), { color: "a", w: 3 });
      g.seg([-4, s.k], [4, s.k], { color: "e", w: 2.2 }).text([3.9, s.k], `y = ${fmt(s.k)}`, { dy: -8, anchor: "end", color: "e", bold: true, size: 13 });
      g.seg([s.a, 0], [s.a, fa], { color: "c", w: 1.6, dash: "4 4" }).seg([s.b, 0], [s.b, fb], { color: "c", w: 1.6, dash: "4 4" });
      g.point([s.a, fa], "", { color: "c" }).point([s.b, fb], "", { color: "c" });
      this.roots(s).forEach((c) => g.point([c, s.k], "c", { color: "d", r: 6 }));
    },
    metrics(s) { const fa = this.f(s, s.a), fb = this.f(s, s.b), inside = (s.k - fa) * (s.k - fb) < 0, R = this.roots(s); return [["f(a) · f(b)", `${fmt(fa, 2)} · ${fmt(fb, 2)}`], ["k가 사이에 있음", inside ? "예" : "아니요"], ["f(c) = k인 c", R.length ? R.map((x) => fmt(x, 2)).join(", ") : "없음", "key"], s.gap && inside && !R.length ? "불연속이라 k를 건너뛰었습니다. 사잇값 정리는 연속일 때만 성립합니다." : ""].filter(Boolean); },
  },
  // ───── 미적분Ⅱ Ⅰ 수열의 극한 ─────
  {
    id: "calc2-seq-limit", grade: II, unit: 1, lesson: "Ⅰ-1", title: "수열의 극한 — ε 띠 안으로", type: "조작", time: "10분",
    tags: ["수렴", "발산", "진동"], links: ["calc2-geo-series", "pst-lln"],
    desc: "수열의 항 (n, aₙ)을 점으로 찍고 극한값 둘레에 폭 ε인 띠를 그려, 어느 항부터 모든 항이 띠 안에 들어오는지로 수렴을 판단합니다.",
    obs: ["수렴하는 수열은 ε을 아무리 작게 해도 언젠가부터 모든 항이 띠 안에 들어옵니다.", "(−1)ⁿ은 두 값 사이를 오가 진동하므로 발산합니다.", "(1 + 1/n)ⁿ은 e = 2.718…에 수렴합니다."],
    q: "rⁿ이 수렴하기 위한 r의 범위는 무엇일까요?",
    formula: "lim(n→∞) aₙ = L ⇔ 충분히 큰 모든 n에서 |aₙ − L| < ε",
    en: { title: "Limits of Sequences", desc: "Plot terms and find where they all stay inside an ε-band." },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [{ key: "sq", label: "수열", type: "select", value: "e", options: [["inv", "aₙ = 1/n"], ["alt", "aₙ = (−1)ⁿ/n"], ["frac", "aₙ = n/(n + 1)"], ["osc", "aₙ = (−1)ⁿ"], ["geo", "aₙ = rⁿ"], ["e", "aₙ = (1 + 1/n)ⁿ"]] }, { key: "r", label: "공비 r", min: -1.2, max: 1.2, step: 0.05, value: 0.8, when: (s) => s.sq === "geo" }, { key: "eps", label: "띠의 폭 ε", min: 0.01, max: 0.5, step: 0.01, value: 0.1 }, { key: "N", label: "보는 항의 수", min: 5, max: 60, step: 1, value: 40 }],
    seq(s) { const f = { inv: (n) => 1 / n, alt: (n) => (-1) ** n / n, frac: (n) => n / (n + 1), osc: (n) => (-1) ** n, geo: (n) => s.r ** n, e: (n) => (1 + 1 / n) ** n }[s.sq]; const L = { inv: 0, alt: 0, frac: 1, osc: NaN, geo: Math.abs(s.r) < 1 ? 0 : s.r === 1 ? 1 : NaN, e: Math.E }[s.sq]; return { f, L }; },
    draw(s, g) {
      const { f, L } = this.seq(s), vals = Array.from({ length: s.N }, (_, i) => f(i + 1)), lo = Math.min(...vals, Number.isFinite(L) ? L - s.eps : 0, 0), hi = Math.max(...vals, Number.isFinite(L) ? L + s.eps : 1);
      const pad = (hi - lo) * 0.08 || 1, M = (n, y) => [1.4 + (n / s.N) * 14, 0.9 + ((y - lo + pad) / (hi - lo + 2 * pad)) * 9.8];
      g.seg(M(0, 0), M(s.N, 0), { color: "axis", w: 1.3 }).seg([1.4, 0.9], [1.4, 10.7], { color: "axis", w: 1.3 });
      [lo, (lo + hi) / 2, hi].forEach((v) => g.text([1.4, M(0, v)[1]], fmt(v, 2), { dx: -5, dy: 4, anchor: "end", size: 11, color: "muted" }));
      let first = null;
      if (Number.isFinite(L)) { g.poly([M(0, L - s.eps), M(s.N, L - s.eps), M(s.N, L + s.eps), M(0, L + s.eps)], { fill: "c", fo: 0.18, stroke: false }); g.seg(M(0, L), M(s.N, L), { color: "c", w: 1.6, dash: "5 4" }); for (let n = s.N; n >= 1; n--) if (Math.abs(f(n) - L) >= s.eps) { first = n + 1; break; } if (first === null) first = 1; }
      vals.forEach((v, i) => { const inb = Number.isFinite(L) && Math.abs(v - L) < s.eps && first && i + 1 >= first; g.circle(M(i + 1, v), 0.11, { color: inb ? "c" : "a", fill: inb ? "c" : "a", fo: 1, w: 1, layer: "point" }); });
      if (first && first <= s.N) g.seg(M(first, lo), M(first, hi), { color: "d", w: 1.4, dash: "3 4" });
    },
    metrics(s) { const { f, L } = this.seq(s); let first = null; if (Number.isFinite(L)) { for (let n = 2000; n >= 1; n--) if (Math.abs(f(n) - L) >= s.eps) { first = n + 1; break; } if (first === null) first = 1; } return [["극한값", Number.isFinite(L) ? (s.sq === "e" ? "e ≈ 2.71828" : fmt(L)) : "없음 (발산·진동)", "key"], ["띠 안에 머무는 항", first ? `n ≥ ${first}` : "—"], [`a${s.N > 0 ? "" : ""}₁₀`, fmt(f(10), 5)]]; },
  },
  {
    id: "calc2-geo-series", grade: II, unit: 1, lesson: "Ⅰ-5", title: "등비급수의 수렴 — 부분합 따라가기", type: "조작", time: "8분",
    tags: ["등비급수", "부분합", "수렴 조건"], links: ["lab-zeno", "calc2-seq-limit"],
    desc: "첫째항 a와 공비 r을 바꾸며 각 항을 막대로, 부분합 Sₙ을 점으로 그려 |r| < 1일 때 Sₙ이 a/(1 − r)에 다가가는 것을 봅니다.",
    obs: ["|r| < 1이면 부분합은 a/(1 − r)에 수렴합니다.", "r이 음수이면 부분합이 극한값 위아래를 오가며 다가갑니다.", "|r| ≥ 1이면 발산합니다."],
    q: "0.999… = 1인 이유를 등비급수로 설명해 보세요.",
    formula: "Sₙ = a(1 − rⁿ)/(1 − r) · |r| < 1 ⇒ Σ arⁿ⁻¹ = a/(1 − r)",
    en: { title: "Convergence of Geometric Series", desc: "Follow partial sums toward a/(1 − r) when |r| < 1." },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [{ key: "a", label: "첫째항 a", min: 0.5, max: 3, step: 0.1, value: 2 }, { key: "r", label: "공비 r", min: -1.1, max: 1.1, step: 0.05, value: 0.6 }, { key: "n", label: "항의 수 n", min: 1, max: 30, step: 1, value: 15 }],
    anim: { key: "n", min: 1, max: 30, speed: 4, label: "더해 가기" },
    draw(s, g) {
      const terms = Array.from({ length: s.n }, (_, i) => s.a * s.r ** i), S = []; terms.reduce((acc, t2) => (S.push(acc + t2), acc + t2), 0);
      const lim = Math.abs(s.r) < 1 ? s.a / (1 - s.r) : NaN, vals = [...S, ...terms, 0, Number.isFinite(lim) ? lim : 0], lo = Math.min(...vals), hi = Math.max(...vals), pad = (hi - lo) * 0.08 || 1;
      const M = (i, y) => [1.4 + (i / 30) * 14, 0.9 + ((y - lo + pad) / (hi - lo + 2 * pad)) * 9.8];
      g.seg(M(0, 0), M(30, 0), { color: "axis", w: 1.3 });
      [lo, 0, hi].forEach((v) => g.text([1.4, M(0, v)[1]], fmt(v, 2), { dx: -5, dy: 4, anchor: "end", size: 11, color: "muted" }));
      terms.forEach((t2, i) => { const x = M(i + 1, 0)[0]; g.poly([[x - 0.12, M(0, 0)[1]], [x + 0.12, M(0, 0)[1]], [x + 0.12, M(0, t2)[1]], [x - 0.12, M(0, t2)[1]]], { fill: "b", fo: 0.45, stroke: false }); });
      if (Number.isFinite(lim)) g.seg(M(0, lim), M(30, lim), { color: "c", w: 1.8, dash: "6 4" }).text(M(30, lim), `a/(1 − r) = ${fmt(lim, 3)}`, { dy: -8, anchor: "end", color: "c", bold: true, size: 12 });
      g.path(S.map((v, i) => M(i + 1, v)), { color: "a", w: 2 });
      S.forEach((v, i) => g.circle(M(i + 1, v), 0.1, { color: "a", fill: "a", fo: 1, w: 1, layer: "point" }));
    },
    metrics(s) { const S = (s.a * (1 - s.r ** s.n)) / (1 - s.r || 1e-12), lim = Math.abs(s.r) < 1 ? s.a / (1 - s.r) : NaN; return [[`S${String(s.n).replace(/[0-9]/g, (d) => "₀₁₂₃₄₅₆₇₈₉"[d])}`, Math.abs(s.r - 1) < 1e-9 ? fmt(s.a * s.n, 4) : fmt(S, 5)], ["합", Number.isFinite(lim) ? fmt(lim, 5) : "발산", "key"]]; },
  },
  // ───── 미적분Ⅱ Ⅱ 미분법 ─────
  {
    id: "calc2-e-slope", grade: II, unit: 2, lesson: "Ⅱ-2", title: "왜 e인가 — y = aˣ의 접선 기울기", type: "조작", time: "8분",
    tags: ["자연상수 e", "지수함수의 미분", "ln a"], links: ["calc-secant-tangent", "calc2-nth-deriv"],
    desc: "밑 a를 바꾸며 y = aˣ의 (0, 1)에서의 접선 기울기가 ln a임을 보고, 그 기울기가 정확히 1이 되는 밑이 e = 2.718…임을 찾습니다.",
    obs: ["(aˣ)′ = aˣ ln a입니다.", "a = e일 때 기울기가 1이 되어 (eˣ)′ = eˣ입니다.", "a가 1보다 작으면 기울기가 음수입니다."],
    q: "y = 2ˣ과 y = 3ˣ의 x = 0에서 기울기는 1보다 클까요, 작을까요?",
    formula: "(aˣ)′ = aˣ ln a · (eˣ)′ = eˣ · lim(h→0) (eʰ − 1)/h = 1",
    en: { title: "Why e? Tangent Slope of aˣ", desc: "The slope of aˣ at (0, 1) is ln a; it equals 1 exactly when a = e." },
    view: { x: [-3.5, 3.5], y: [-1, 7] },
    params: [{ key: "a", label: "밑 a", min: 0.3, max: 5, step: 0.001, value: 2 }],
    buttons: [["e", "a = e로 맞추기"]],
    onDo(k, s) { if (k === "e") s.a = Math.E; },
    drags: { A: { at: (s) => [1, s.a], move: (s, p) => (s.a = clamp(p[1], 0.3, 5)), color: "a", label: "(1, a)" } },
    draw(s, g) {
      g.grid();
      g.fx((x) => Math.E ** x, { color: "muted", w: 1.4, dash: "4 5" });
      g.fx((x) => s.a ** x, { color: "a", w: 3.2 });
      const m = Math.log(s.a); g.line([0, 1], [1, 1 + m], { color: "b", w: 2.4 });
      g.point([0, 1], "(0, 1)", { color: "ink" });
      g.text([2.6, Math.E ** 2.6 > 7 ? 6.6 : Math.E ** 2.6], "y = eˣ", { dx: -30, color: "muted", size: 12 });
    },
    metrics(s) { const m = Math.log(s.a); return [["밑 a", fmt(s.a, 3)], ["접선 기울기 ln a", fmt(m, 4), "key"], ["판정", Math.abs(m - 1) < 0.005 ? "기울기 1 → a = e" : m > 1 ? "a > e" : "a < e"]]; },
  },
  {
    id: "calc2-nth-deriv", grade: II, unit: 2, lesson: "Ⅱ-9", title: "n계도함수 — 거듭 미분하기", type: "조작", time: "10분",
    tags: ["n계도함수", "규칙 찾기", "주기"], links: ["calc2-concavity", "calc2-e-slope"],
    desc: "함수를 한 번, 두 번, …, n번 미분한 그래프를 차례로 겹쳐 그리고 식의 규칙을 찾습니다. sin x는 네 번마다 돌아오고, eˣ는 그대로이며, 다항식은 언젠가 0이 됩니다.",
    obs: ["sin x를 미분할 때마다 그래프가 왼쪽으로 π/2씩 옮겨집니다.", "eˣ는 몇 번을 미분해도 자기 자신입니다.", "5차 다항식은 여섯 번 미분하면 0이 됩니다."],
    q: "(sin x)의 100계도함수는 무엇일까요?",
    formula: "(sin x)⁽ⁿ⁾ = sin(x + nπ/2) · (eˣ)⁽ⁿ⁾ = eˣ · (xeˣ)⁽ⁿ⁾ = (x + n)eˣ",
    en: { title: "n-th Derivatives", desc: "Differentiate repeatedly and discover the pattern in the formulas." },
    view: (s) => NTH[s.fn].view,
    params: [{ key: "fn", label: "함수", type: "seg", value: "sin", options: [["sin", "sin x"], ["exp", "eˣ"], ["poly", "x⁵/20"], ["xex", "xeˣ"], ["ln", "ln x"]] }, { key: "n", label: "미분 횟수 n", min: 0, max: 8, step: 1, value: 3 }, { key: "all", label: "앞의 도함수도 함께 보기", type: "check", value: true }],
    anim: { key: "n", min: 0, max: 8, speed: 1.2, label: "하나씩 미분" },
    draw(s, g) {
      g.grid();
      const F = NTH[s.fn], cols = ["b", "c", "e", "f", "d", "a"];
      if (s.all) for (let k = 0; k < s.n; k++) g.fx(F.f(k), { color: cols[k % 6], w: 1.4, opacity: 0.45 });
      g.fx(F.f(s.n), { color: "a", w: 3.4 });
    },
    metrics(s) { const F = NTH[s.fn]; return [["n", String(s.n)], [dname(s.n), F.tex(s.n), "key"], ["일반항", F.gen]]; },
  },
  // ───── 미적분Ⅱ Ⅲ 도함수의 활용 ─────
  {
    id: "calc2-concavity", grade: II, unit: 3, lesson: "Ⅲ-4", title: "이계도함수 — 오목·볼록과 변곡점", type: "조작", time: "12분",
    tags: ["이계도함수", "변곡점", "오목·볼록"], links: ["calc-derivative-graph", "calc2-nth-deriv"],
    desc: "위에는 f, 아래에는 f′와 f″를 나란히 두고 점을 움직이며, f″ > 0이면 아래로 볼록, f″ < 0이면 위로 볼록이고 f″의 부호가 바뀌는 점이 변곡점임을 확인합니다.",
    obs: ["f″(x) > 0이면 접선의 기울기가 커지므로 그래프는 아래로 볼록입니다.", "f″의 부호가 바뀌는 점에서 곡선의 휘는 방향이 바뀝니다(변곡점).", "변곡점에서 접선은 곡선을 가로지릅니다."],
    q: "f″(a) = 0이면 x = a는 반드시 변곡점일까요? (예: f(x) = x⁴)",
    formula: "f″(x) > 0 ⇒ 아래로 볼록 · f″(x) < 0 ⇒ 위로 볼록 · f″의 부호 변화 ⇒ 변곡점",
    en: { title: "Second Derivative: Concavity and Inflection", desc: "Link the sign of f″ with concavity and find inflection points." },
    view: { x: [-4, 4], y: [-5.4, 5.4] },
    params: [{ key: "fn", label: "함수", type: "select", value: "cub", options: Object.entries(CF).map(([k, v]) => [k, v.name]) }, { key: "x", label: "x", min: -3.8, max: 3.8, step: 0.02, value: -1.2 }, { key: "show", label: "아래 그래프", type: "seg", value: "dd", options: [["d", "f′"], ["dd", "f″"]] }],
    anim: { key: "x", min: -3.8, max: 3.8, speed: 1.2, label: "점 움직이기" },
    drags: { X: { at: (s) => [s.x, clamp(2.6 + 0.6 * CF[s.fn].f(s.x), 0.2, 5.3)], move: (s, p) => (s.x = clamp(p[0], -3.8, 3.8)), color: "a" } },
    draw(s, g) {
      const F = CF[s.fn], up = 2.6, dn = -2.6, k = 0.6, fU = (x) => clamp(up + k * F.f(x), 0.2, 5.3), low = s.show === "dd" ? F.dd : F.d, fD = (x) => clamp(dn + k * low(x), -5.3, -0.2);
      g.grid({ labels: false, axes: false });
      g.seg([-4, up], [4, up], { color: "axis", w: 1.2 }).seg([-4, dn], [4, dn], { color: "axis", w: 1.2 });
      const inU = (x) => { const v = up + k * F.f(x); return v >= 0.2 && v <= 5.3; };
      for (let i = 0; i < 400; i++) { const x0 = -4 + (8 * i) / 400, x1 = x0 + 0.02, v = F.dd((x0 + x1) / 2); if (inU(x0) && inU(x1)) g.seg([x0, fU(x0)], [x1, fU(x1)], { color: v > 0 ? "b" : "a", w: 3.4 }); if (s.show === "dd") g.seg([x0, dn], [x1, dn], { color: v > 0 ? "b" : "a", w: 5, opacity: 0.3 }); }
      g.fx((x) => { const v = dn + k * low(x); return v >= -5.3 && v <= -0.2 ? v : NaN; }, { color: s.show === "dd" ? "e" : "c", w: 2.6 });
      g.text([-3.9, 5.1], "y = f(x)   파랑: 아래로 볼록 · 주황: 위로 볼록", { anchor: "start", size: 12, color: "muted", bold: true });
      g.text([-3.9, -0.5], s.show === "dd" ? "y = f″(x)" : "y = f′(x)", { anchor: "start", size: 12, color: s.show === "dd" ? "e" : "c", bold: true });
      for (let i = 0; i < 800; i++) { const x0 = -4 + (8 * i) / 800, x1 = x0 + 0.01; if (F.dd(x0) * F.dd(x1) < 0) { const xi = (x0 + x1) / 2; g.point([xi, fU(xi)], "변곡점", { color: "d", r: 5, dy: -12, anchor: "middle", dx: 0 }); } }
      const P = [s.x, fU(s.x)], m = k * F.d(s.x);
      g.seg(add(P, [-1.3, -1.3 * m]), add(P, [1.3, 1.3 * m]), { color: "ink", w: 1.8 });
      g.seg(P, [s.x, fD(s.x)], { color: "muted", w: 1, dash: "3 4" }).point([s.x, fD(s.x)], "", { color: s.show === "dd" ? "e" : "c", r: 5 });
    },
    metrics(s) { const F = CF[s.fn], dd = F.dd(s.x); return [["f′(x)", fmt(F.d(s.x), 3)], ["f″(x)", fmt(dd, 3), "key"], ["곡선의 모양", Math.abs(dd) < 0.02 ? "변곡점 근처" : dd > 0 ? "아래로 볼록" : "위로 볼록"]]; },
  },
];
