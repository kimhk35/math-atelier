// 23차 묶음 9 — 중학교 2학년 추가 실험 14개
import { fmt, frac, poly, clamp } from "./hs-core.js";

const G2 = 2;
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a; };
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
const lcg = (seed) => { let x = (seed * 6007) % 2147483647 || 7; return () => ((x = (x * 16807) % 2147483647) / 2147483647); };
const only25 = (q) => { while (q % 2 === 0) q /= 2; while (q % 5 === 0) q /= 5; return q === 1; };
const FORM = {
  trap: { n: "사다리꼴의 넓이 S = (a + b)h/2 → h", from: "S = (a + b)h / 2", steps: ["2S = (a + b)h", "h = 2S / (a + b)"], vars: [["S", 30], ["a", 4], ["b", 8]], out: (v) => (2 * v.S) / (v.a + v.b), on: "h" },
  speed: { n: "거리 d = vt → t", from: "d = vt", steps: ["양변을 v로 나누면", "t = d / v"], vars: [["d", 120], ["v", 40]], out: (v) => v.d / v.v, on: "t" },
  temp: { n: "화씨 F = 1.8C + 32 → C", from: "F = 1.8C + 32", steps: ["F − 32 = 1.8C", "C = (F − 32) / 1.8"], vars: [["F", 77]], out: (v) => (v.F - 32) / 1.8, on: "C" },
};
const DICE = [[4, "정사면체"], [6, "정육면체"], [8, "정팔면체"], [12, "정십이면체"], [20, "정이십면체"]];

export default [
  {
    id: "m2-fraction-table", grade: G2, unit: 1, lesson: "1.1", title: "분모만 보고 유한소수 가려내기 — 1/2부터 1/30까지", type: "조작", time: "10분",
    tags: ["유한소수", "순환소수", "소인수"], links: ["m2-repeating"],
    desc: "1/2부터 1/30까지의 단위분수를 표에 늘어놓고 유한소수와 순환소수를 색으로 구분합니다. 분모의 소인수가 2와 5뿐인 칸만 유한소수라는 규칙을 찾고, 분자가 있을 때는 먼저 약분해야 한다는 것도 확인합니다.",
    obs: ["유한소수는 분모를 10, 100, 1000, …으로 만들 수 있는 분수입니다.", "10ⁿ = 2ⁿ × 5ⁿ이므로 분모의 소인수가 2와 5뿐이어야 합니다.", "3/12처럼 약분하면 분모가 바뀔 수 있으니 기약분수로 고친 뒤 판단합니다."],
    q: "7/14는 분모 14에 7이 있는데도 유한소수입니다. 왜 그럴까요?",
    formula: "기약분수의 분모의 소인수가 2, 5뿐 ⇔ 유한소수",
    en: { title: "Spotting Terminating Decimals", desc: "Look only at the denominator." },
    view: BOX,
    params: [{ key: "p", label: "분자 p", min: 1, max: 9, step: 1, value: 1 }, { key: "q", label: "살펴볼 분모", min: 2, max: 30, step: 1, value: 12 }],
    draw(s, g) {
      for (let q = 2; q <= 30; q++) { const i = q - 2, c = i % 6, r = Math.floor(i / 6), x = 0.6 + c * 2.5, y = 10.2 - r * 1.9, G = gcd(s.p, q), ok = only25(q / G), on = q === s.q; rect(g, x, y - 1.6, 2.3, 1.6, { fill: ok ? "c" : "a", fo: on ? 0.6 : 0.22, color: on ? "ink" : ok ? "c" : "a", w: on ? 2.4 : 1 }); g.text([x + 1.15, y - 0.65], `${s.p}/${q}`, { dy: 4, bold: true, size: 13 }); g.text([x + 1.15, y - 1.25], String(+(s.p / q).toFixed(5)), { dy: 4, size: 10, color: "muted" }); }
      g.text([15.6, 1.2], "초록: 유한소수 · 주황: 순환소수", { anchor: "end", size: 12, bold: true });
    },
    metrics(s) { const G = gcd(s.p, s.q), q = s.q / G; const f = []; let m = q; for (let p = 2; p <= m; p++) while (m % p === 0) { f.push(p); m /= p; } return [["기약분수", `${s.p / G}/${q}`], ["분모의 소인수", f.length ? [...new Set(f)].join(", ") : "없음"], ["판정", only25(q) ? "유한소수" : "순환소수", "key"]]; },
    predict: [
      { q: "1/2부터 1/30까지 단위분수 가운데 유한소수는 몇 개일까요?", set: (s) => Object.assign(s, { p: 1, q: 3 }), answer: () => { let c = 0; for (let q = 2; q <= 30; q++) if (only25(q)) c++; return c; }, why: "분모가 2, 4, 5, 8, 10, 16, 20, 25인 8개뿐입니다." },
      { q: "3/12는 유한소수일까요?", options: O("그렇다", "아니다"), set: (s) => Object.assign(s, { p: 1, q: 12 }), reveal: (s) => (s.p = 3), answer: () => "a", why: "3/12 = 1/4로 약분되어 0.25입니다." },
    ],
  },
  {
    id: "m2-point-nine", grade: G2, unit: 1, lesson: "1.2", title: "0.9̇ = 1 — 끝없이 다가가면 같아진다", type: "조작", time: "8분",
    tags: ["순환소수", "극한", "등식"], links: ["m2-rep-to-frac"],
    desc: "0.9, 0.99, 0.999, …를 막대로 그리면 1과의 차이가 0.1, 0.01, 0.001로 끝없이 줄어듭니다. 9가 한없이 이어지는 0.9̇는 1과의 차이가 어떤 양수보다도 작으므로 1과 같습니다. 1/3 = 0.3̇의 양변에 3을 곱하는 방법과도 비교합니다.",
    obs: ["0.99…9(9가 n개)와 1의 차는 1/10ⁿ입니다.", "0.9̇와 1 사이에 들어갈 수 있는 수는 없습니다.", "1/3 = 0.3̇의 양변에 3을 곱하면 1 = 0.9̇입니다."],
    q: "0.4̇9̇… 아니, 0.49̇는 어떤 수와 같을까요?",
    formula: "0.9̇ = 9/9 = 1",
    en: { title: "0.999… = 1", desc: "Endless approach means equality." },
    view: { x: [-0.4, 12.4], y: [-1, 7.6] },
    params: [{ key: "n", label: "9의 개수 n", min: 1, max: 8, step: 1, value: 3 }],
    anim: { key: "n", min: 1, max: 8, speed: 1, label: "9 늘리기" },
    draw(s, g) {
      const L = 12;
      for (let k = 1; k <= s.n; k++) { const v = 1 - 10 ** -k, y = 7 - k * 0.8; rect(g, 0, y - 0.55, L * v, 0.55, { fill: "b", fo: 0.45, color: "b", w: 1 }); rect(g, L * v, y - 0.55, L - L * v, 0.55, { fill: "e", fo: 0.6, stroke: false }); g.text([0.2, y - 0.27], `0.${"9".repeat(k)}`, { anchor: "start", dy: 4, size: 12, bold: true, mono: true }); g.text([L + 0.1, y - 0.27], `차 ${k < 4 ? fmt(10 ** -k, k) : `1/10${"⁰¹²³⁴⁵⁶⁷⁸⁹"[k]}`}`, { anchor: "start", dy: 4, size: 11, color: "e" }); }
      g.seg([L, -0.6], [L, 7], { color: "ink", w: 2, dash: "4 4" }).text([L, -0.6], "1", { dy: 14, bold: true });
      g.text([0, 0], "1/3 = 0.333…  →  ×3  →  1 = 0.999…", { anchor: "start", bold: true, size: 14, color: "c" });
    },
    metrics(s) { return [[`0.${"9".repeat(s.n)}과 1의 차`, `${fmt(10 ** -s.n, 9)}`], ["9가 끝없이 이어지면", "차가 0 → 0.9̇ = 1", "key"]]; },
    predict: [
      { q: "0.999(9가 3개)와 1의 차는?", set: (s) => (s.n = 1), reveal: (s) => (s.n = 3), answer: () => 0.001, tol: 1e-9, why: "1 − 0.999 = 0.001 = 1/10³입니다." },
      { q: "0.9̇와 1의 관계는?", options: O("같다", "0.9̇가 아주 조금 작다"), set: (s) => (s.n = 2), reveal: (s) => (s.n = 8), answer: () => "a", why: "차이가 어떤 양수보다도 작으므로 0입니다. x = 0.9̇이면 10x − x = 9, x = 1입니다." },
    ],
  },
  {
    id: "m2-monomial", grade: G2, unit: 2, lesson: "2.1", title: "단항식의 곱셈과 나눗셈 — 넓이로 세는 3a × 2b", type: "조작", time: "10분",
    tags: ["단항식", "곱셈", "나눗셈"], links: ["m2-exp-law"],
    desc: "가로 ma, 세로 nb인 직사각형은 a × b 타일 mn개로 채워져 넓이가 mnab입니다. 계수끼리, 문자끼리 곱하는 단항식의 곱셈과, 넓이를 한 변으로 나누어 다른 변을 구하는 나눗셈을 함께 확인합니다.",
    obs: ["단항식의 곱셈은 계수는 계수끼리, 문자는 문자끼리 곱합니다.", "3a × 2b = (3 × 2) × (a × b) = 6ab입니다.", "넓이 6ab를 가로 3a로 나누면 세로 2b입니다."],
    q: "4a²b ÷ 2ab를 넓이 그림으로 설명해 봅시다.",
    formula: "(ma) × (nb) = mnab, mnab ÷ ma = nb",
    en: { title: "Multiplying Monomials", desc: "Count a × b tiles." },
    view: BOX,
    params: [{ key: "m", label: "가로의 계수 m (ma)", min: 1, max: 5, step: 1, value: 3 }, { key: "n", label: "세로의 계수 n (nb)", min: 1, max: 4, step: 1, value: 2 }, { key: "a", label: "a의 길이", min: 0.8, max: 2, step: 0.1, value: 1.6 }, { key: "b", label: "b의 길이", min: 0.6, max: 1.6, step: 0.1, value: 1.2 }],
    draw(s, g) {
      const x0 = 1.4, y0 = 1.2;
      for (let i = 0; i < s.m; i++) for (let j = 0; j < s.n; j++) { rect(g, x0 + i * s.a, y0 + j * s.b, s.a, s.b, { fill: (i + j) % 2 ? "b" : "c", fo: 0.35, color: "paper", w: 1.4 }); g.text([x0 + (i + 0.5) * s.a, y0 + (j + 0.5) * s.b], "ab", { dy: 4, size: 12, bold: true }); }
      rect(g, x0, y0, s.m * s.a, s.n * s.b, { color: "ink", w: 2.4 });
      g.text([x0 + (s.m * s.a) / 2, y0], `${s.m === 1 ? "" : s.m}a`, { dy: 18, bold: true, color: "a", size: 15 }).text([x0, y0 + (s.n * s.b) / 2], `${s.n === 1 ? "" : s.n}b`, { dx: -8, anchor: "end", bold: true, color: "a", size: 15 });
      g.text([x0 + s.m * s.a + 0.8, 9], `${s.m === 1 ? "" : s.m}a × ${s.n === 1 ? "" : s.n}b = ${s.m * s.n === 1 ? "" : s.m * s.n}ab`, { anchor: "start", bold: true, size: 18 }).text([x0 + s.m * s.a + 0.8, 7.8], `${s.m * s.n}ab ÷ ${s.m === 1 ? "" : s.m}a = ${s.n === 1 ? "" : s.n}b`, { anchor: "start", bold: true, size: 16, color: "c" });
    },
    metrics(s) { return [["ab 타일의 수", `${s.m} × ${s.n} = ${s.m * s.n}개`], ["넓이", `${s.m * s.n}ab = ${fmt(s.m * s.n * s.a * s.b, 3)}`, "key"]]; },
    predict: [
      { q: "3a × 2b를 간단히 하면 계수는?", set: (s) => Object.assign(s, { m: 1, n: 1 }), reveal: (s) => Object.assign(s, { m: 3, n: 2 }), answer: () => 6, why: "ab 타일이 3 × 2 = 6개라 6ab입니다." },
      { q: "12ab ÷ 4a의 계수는?", set: (s) => Object.assign(s, { m: 4, n: 3 }), answer: () => 3, why: "넓이 12ab, 가로 4a이면 세로는 3b입니다." },
    ],
  },
  {
    id: "m2-formula-solve", grade: G2, unit: 2, lesson: "2.2", title: "등식의 변형 — 공식을 다른 문자에 대하여 풀기", type: "조작", time: "10분",
    tags: ["등식의 변형", "공식", "문자"], links: ["m1-seesaw"],
    desc: "넓이·속력·온도 공식을 원하는 문자에 대하여 풀어 봅니다. 등식의 성질로 한 단계씩 변형하고, 값을 넣어 원래 공식과 바꾼 공식이 같은 답을 주는지 확인합니다.",
    obs: ["한 문자에 대하여 푼다는 것은 그 문자만 한쪽에 남기는 것입니다.", "등식의 성질을 쓰면 변형 전후의 관계가 같습니다.", "바꾼 공식은 다른 값을 구할 때 바로 쓸 수 있어 편리합니다."],
    q: "원기둥의 부피 V = πr²h를 h에 대하여 풀어 봅시다.",
    formula: "등식의 성질로 원하는 문자만 한쪽에 남기기",
    en: { title: "Rearranging Formulas", desc: "Solve a formula for another letter." },
    view: BOX,
    params: [
      { key: "f", label: "공식", type: "select", value: "trap", options: Object.entries(FORM).map(([k, v]) => [k, v.n]), rebuild: true },
      { key: "v1", label: "첫째 값", min: 1, max: 200, step: 1, value: 30 },
      { key: "v2", label: "둘째 값", min: 1, max: 60, step: 1, value: 4, when: (s) => FORM[s.f].vars.length > 1 },
      { key: "v3", label: "셋째 값", min: 1, max: 30, step: 1, value: 8, when: (s) => FORM[s.f].vars.length > 2 },
    ],
    onChange(s, k) { if (k === "f") { const V = FORM[s.f].vars; s.v1 = V[0][1]; s.v2 = V[1]?.[1] ?? 1; s.v3 = V[2]?.[1] ?? 1; } },
    vals(s) { const V = FORM[s.f].vars, o = {}; V.forEach(([n], i) => (o[n] = [s.v1, s.v2, s.v3][i])); return o; },
    draw(s, g) {
      const F = FORM[s.f], v = this.vals(s);
      g.text([1, 9.8], F.from, { anchor: "start", bold: true, size: 22 });
      F.steps.forEach((t, i) => g.text([1, 8.4 - i * 1.3], `→ ${t}`, { anchor: "start", size: 18, color: i === F.steps.length - 1 ? "c" : "ink", bold: i === F.steps.length - 1 }));
      g.text([1, 4.6], `${Object.entries(v).map(([k, x]) => `${k} = ${x}`).join(", ")}일 때`, { anchor: "start", size: 15, color: "muted" });
      g.text([1, 3.4], `${F.on} = ${fmt(F.out(v), 3)}`, { anchor: "start", bold: true, size: 22, color: "e" });
    },
    metrics(s) { const F = FORM[s.f], v = this.vals(s); return [["바꾼 공식", F.steps.at(-1)], [F.on, fmt(F.out(v), 3), "key"]]; },
    predict: [
      { q: "넓이 30, 윗변 4, 아랫변 8인 사다리꼴의 높이는?", set: (s) => Object.assign(s, { f: "trap", v1: 30, v2: 4, v3: 8 }), answer: () => 5, why: "h = 2S/(a + b) = 60/12 = 5입니다." },
      { q: "화씨 77도는 섭씨 몇 도일까요?", set: (s) => Object.assign(s, { f: "temp", v1: 77 }), answer: () => 25, why: "C = (77 − 32)/1.8 = 45/1.8 = 25입니다." },
    ],
  },
  {
    id: "m2-chicken-rabbit", grade: G2, unit: 3, lesson: "3.3", title: "닭과 토끼 — 머리와 다리로 세우는 연립방정식", type: "조작", time: "12분",
    tags: ["연립방정식의 활용", "표", "그래프"], links: ["m2-two-lines", "m2-elimination"],
    desc: "머리가 H개, 다리가 L개일 때 닭 x마리와 토끼 y마리를 구합니다. 닭의 수를 바꾸며 표로 다리 수를 맞춰 보는 방법과, x + y = H, 2x + 4y = L 두 직선의 교점으로 찾는 방법을 비교합니다.",
    obs: ["모두 닭이라고 생각하면 다리가 2H개, 실제보다 모자란 만큼이 토끼 때문입니다.", "닭 한 마리를 토끼로 바꿀 때마다 다리가 2개씩 늡니다.", "두 직선의 교점이 연립방정식의 해입니다."],
    q: "옛 중국 책 『손자산경』의 문제(머리 35, 다리 94)를 풀어 봅시다.",
    formula: "x + y = H, 2x + 4y = L",
    en: { title: "Chickens and Rabbits", desc: "Heads and legs give a system of equations." },
    view: { x: [-2, 40], y: [-3, 40], pad: 14 },
    params: [{ key: "H", label: "머리 수 H", min: 5, max: 35, step: 1, value: 35 }, { key: "L", label: "다리 수 L", min: 10, max: 140, step: 2, value: 94 }, { key: "x", label: "닭이라고 짐작한 수 x", min: 0, max: 35, step: 1, value: 20 }],
    onChange(s) { s.L = clamp(s.L, 2 * s.H, 4 * s.H); s.x = clamp(s.x, 0, s.H); },
    draw(s, g) {
      g.grid({ step: 5, labels: false });
      for (let v = 0; v <= 35; v += 5) { g.text([v, 0], String(v), { dy: 16, size: 11, color: "muted" }); if (v) g.text([0, v], String(v), { dx: -6, anchor: "end", dy: 4, size: 11, color: "muted" }); }
      g.text([39, 0], "닭 x", { dy: 30, size: 11, color: "muted" }).text([0, 39], "토끼 y", { dx: 6, anchor: "start", size: 11, color: "muted" });
      g.seg([0, s.H], [s.H, 0], { color: "a", w: 2.8 }).seg([0, s.L / 4], [s.L / 2, 0], { color: "b", w: 2.8 });
      const X = (4 * s.H - s.L) / 2, Y = s.H - X; g.point([X, Y], `(${fmt(X)}, ${fmt(Y)})`, { color: "ink" });
      g.point([s.x, s.H - s.x], "", { color: "e", r: 6 });
      g.text([12, 37], `주황: x + y = ${s.H}   파랑: 2x + 4y = ${s.L}`, { anchor: "start", bold: true, size: 13 });
    },
    metrics(s) { const legs = 2 * s.x + 4 * (s.H - s.x), X = (4 * s.H - s.L) / 2; return [[`닭 ${s.x}, 토끼 ${s.H - s.x}이면 다리`, `${legs}개 ${legs === s.L ? "✓" : legs < s.L ? "(모자람)" : "(넘침)"}`], ["해", `닭 ${fmt(X)}마리, 토끼 ${fmt(s.H - X)}마리`, "key"]]; },
    predict: [
      { q: "머리 35, 다리 94이면 토끼는 몇 마리일까요?", set: (s) => Object.assign(s, { H: 35, L: 94, x: 35 }), reveal: (s) => (s.x = 23), answer: () => 12, why: "모두 닭이면 다리 70개, 24개가 모자라므로 토끼는 24 ÷ 2 = 12마리입니다." },
      { q: "같은 문제에서 닭은 몇 마리일까요?", set: (s) => Object.assign(s, { H: 35, L: 94, x: 10 }), answer: () => 23, why: "35 − 12 = 23마리입니다." },
    ],
  },
  {
    id: "m2-ineq-budget", grade: G2, unit: 3, lesson: "3.1", title: "일차부등식의 활용 — 가진 돈으로 최대 몇 개?", type: "조작", time: "10분",
    tags: ["일차부등식의 활용", "자연수 해", "수직선"], links: ["m2-ineq-flip"],
    desc: "배송비 f원에 한 개 p원인 공책을 사려고 합니다. 가진 돈이 B원일 때 f + px ≤ B를 풀어 살 수 있는 최대 개수를 구합니다. 해는 범위로 나오지만 실제 답은 그 범위 안의 가장 큰 자연수임을 수직선으로 확인합니다.",
    obs: ["문제의 조건 '넘지 않는다'는 ≤로 나타냅니다.", "부등식의 해 x ≤ (B − f)/p는 범위입니다.", "개수는 자연수이므로 범위 안의 가장 큰 자연수가 답입니다."],
    q: "배송비가 무료인 대신 한 개에 200원씩 더 비싸다면 어느 쪽이 유리할까요?",
    formula: "f + px ≤ B ⇒ x ≤ (B − f)/p",
    en: { title: "Inequalities on a Budget", desc: "How many can you buy?" },
    view: { x: [-1, 21], y: [-2.6, 3.4] },
    params: [{ key: "B", label: "가진 돈 B (원)", min: 5000, max: 30000, step: 500, value: 15000 }, { key: "f", label: "배송비 f (원)", min: 0, max: 5000, step: 500, value: 3000 }, { key: "p", label: "한 개 가격 p (원)", min: 500, max: 3000, step: 100, value: 1500 }],
    draw(s, g) {
      const v = (s.B - s.f) / s.p, n = Math.floor(v + 1e-9);
      g.seg([-0.5, 0], [20.5, 0], { color: "axis", w: 1.6 });
      for (let k = 0; k <= 20; k++) { g.seg([k, -0.12], [k, 0.12], { color: "axis", w: 1 }); g.text([k, 0], String(k), { dy: 18, size: 11, color: "muted" }); }
      if (v > 0) { g.seg([Math.max(0, -1), 0.7], [Math.min(v, 20.4), 0.7], { color: "b", w: 5 }); g.point([Math.min(v, 20.4), 0.7], "", { color: "b", r: 6 }); }
      for (let k = 1; k <= Math.min(n, 20); k++) g.point([k, 0], "", { color: "a", r: 5.5 });
      g.text([0, 2.6], `${s.f} + ${s.p}x ≤ ${s.B}  →  x ≤ ${fmt(v, 2)}`, { anchor: "start", bold: true, size: 16 });
    },
    metrics(s) { const v = (s.B - s.f) / s.p, n = Math.max(0, Math.floor(v + 1e-9)); return [["부등식의 해", `x ≤ ${fmt(v, 3)}`], ["살 수 있는 최대 개수", `${n}개`, "key"], ["남는 돈", `${(s.B - s.f - n * s.p).toLocaleString()}원`]]; },
    predict: [
      { q: "15000원으로 배송비 3000원, 한 개 1500원인 공책을 최대 몇 개 살 수 있을까요?", set: (s) => Object.assign(s, { B: 15000, f: 3000, p: 1500 }), answer: () => 8, why: "3000 + 1500x ≤ 15000에서 x ≤ 8입니다." },
      { q: "가진 돈이 14000원이면 최대 몇 개?", set: (s) => Object.assign(s, { B: 15000, f: 3000, p: 1500 }), reveal: (s) => (s.B = 14000), answer: () => 7, why: "x ≤ 11000/1500 ≈ 7.33이므로 가장 큰 자연수는 7입니다." },
    ],
  },
  {
    id: "m2-catch-up", grade: G2, unit: 4, lesson: "4.3", title: "늦게 출발한 형이 따라잡는 때 — 두 직선의 교점", type: "조작", time: "12분",
    tags: ["일차함수의 활용", "그래프", "속력"], links: ["m2-plans", "m1-meet"],
    desc: "동생이 먼저 걸어서 출발하고 형이 늦게 자전거로 뒤따릅니다. 시간에 따른 두 사람의 거리를 일차함수 그래프로 그리면, 두 직선이 만나는 점의 x좌표가 형이 동생을 따라잡는 시각입니다.",
    obs: ["거리 = 속력 × (출발 뒤 흐른 시간)입니다.", "늦게 출발한 사람의 그래프는 x축에서 출발 시각만큼 오른쪽에서 시작합니다.", "기울기(속력)가 더 큰 그래프가 결국 따라잡습니다."],
    q: "형이 동생보다 느리다면 그래프는 어떻게 될까요?",
    formula: "동생 y = v₁x, 형 y = v₂(x − d)",
    en: { title: "Catching Up", desc: "Where two lines meet." },
    view: { x: [-1.4, 13], y: [-1.2, 11] },
    params: [{ key: "v1", label: "동생 (m/분)", min: 40, max: 100, step: 10, value: 60 }, { key: "v2", label: "형 (m/분)", min: 100, max: 300, step: 20, value: 200 }, { key: "d", label: "형이 늦게 출발한 시간 (분)", min: 1, max: 15, step: 1, value: 7 }, { key: "t", label: "시간 (분)", min: 0, max: 30, step: 0.5, value: 12 }],
    anim: { key: "t", min: 0, max: 30, speed: 3, label: "출발" },
    draw(s, g) {
      const X = (x) => (x / 30) * 11, Y = (y) => (y / 3000) * 9.6, A = (x) => s.v1 * x, B = (x) => Math.max(0, s.v2 * (x - s.d)), T = (s.v2 * s.d) / (s.v2 - s.v1);
      g.seg([0, 0], [11.4, 0], { color: "axis", w: 1.6 }).seg([0, 0], [0, 10], { color: "axis", w: 1.6 });
      for (let x = 0; x <= 30; x += 5) g.text([X(x), 0], String(x), { dy: 16, size: 11, color: "muted" });
      for (let y = 0; y <= 3000; y += 1000) g.text([0, Y(y)], String(y), { dx: -6, anchor: "end", dy: 4, size: 11, color: "muted" });
      g.text([11.4, 0], "분", { dy: 30, size: 11, color: "muted" }).text([0, 10.4], "m", { dx: 6, anchor: "start", size: 11, color: "muted" });
      g.param((x) => [X(x), Y(A(x))], 0, Math.min(30, 3000 / s.v1), { color: "a", w: 3 });
      g.param((x) => [X(x), Y(B(x))], 0, Math.min(30, s.d + 3000 / s.v2), { color: "b", w: 3 });
      if (T <= 30 && A(T) <= 3000) g.point([X(T), Y(A(T))], `${fmt(T, 1)}분`, { color: "ink" });
      g.point([X(s.t), Y(Math.min(3000, A(s.t)))], "", { color: "a" }).point([X(s.t), Y(Math.min(3000, B(s.t)))], "", { color: "b" });
      g.text([0.5, 10.4], "주황: 동생 · 파랑: 형", { anchor: "start", bold: true, size: 13 });
    },
    metrics(s) { const T = (s.v2 * s.d) / (s.v2 - s.v1); return [["식", `${s.v1}x = ${s.v2}(x − ${s.d})`], ["따라잡는 시각 (동생 출발 뒤)", `${fmt(T, 2)}분`, "key"], ["그때 거리", `${fmt(s.v1 * T, 1)} m`]]; },
    predict: [
      { q: "동생 분속 60 m, 형 분속 200 m, 형이 7분 늦게 출발하면 동생이 출발한 지 몇 분 뒤 따라잡을까요?", set: (s) => Object.assign(s, { v1: 60, v2: 200, d: 7, t: 0 }), reveal: (s) => (s.t = 10), answer: () => 10, why: "60x = 200(x − 7)에서 140x = 1400, x = 10분입니다." },
      { q: "그때까지 동생이 걸은 거리는 몇 m?", set: (s) => Object.assign(s, { v1: 60, v2: 200, d: 7, t: 10 }), answer: () => 600, why: "60 × 10 = 600 m입니다." },
    ],
  },
  {
    id: "m2-road-grade", grade: G2, unit: 4, lesson: "4.1", title: "도로 경사 10% — 기울기를 퍼센트로 읽기", type: "조작", time: "8분",
    tags: ["기울기", "경사", "실생활"], links: ["m2-slope-intercept"],
    desc: "도로 표지판의 '경사 10%'는 수평으로 100 m 갈 때 10 m 올라간다는 뜻, 곧 기울기 0.1입니다. 경사를 바꾸며 기울기, 올라간 높이, 실제 기울어진 각도를 함께 비교합니다.",
    obs: ["경사(%) = (올라간 높이 ÷ 수평 거리) × 100 = 기울기 × 100입니다.", "기울기가 1이면 경사 100%, 각도는 45°입니다.", "기울기가 2배가 되어도 각도는 2배가 되지 않습니다."],
    q: "경사 100%인 길이 있다면 얼마나 가파를까요?",
    formula: "기울기 = (높이의 증가량)/(수평 거리의 증가량)",
    en: { title: "Road Grade as Slope", desc: "A 10% grade means slope 0.1." },
    view: { x: [-0.6, 12.6], y: [-1, 8] },
    params: [{ key: "p", label: "경사 (%)", min: 0, max: 100, step: 1, value: 10 }, { key: "run", label: "수평 거리 (m)", min: 100, max: 1000, step: 50, value: 500 }],
    draw(s, g) {
      const m = s.p / 100, k = 10 / Math.max(s.run, s.run * m), W = s.run * k, H = s.run * m * k;
      g.poly([[1, 0.5], [1 + W, 0.5], [1 + W, 0.5 + H]], { fill: "c", fo: 0.25, color: "c", w: 2 });
      g.seg([1, 0.5], [1 + W, 0.5 + H], { color: "ink", w: 4 });
      g.text([1 + W / 2, 0.5], `수평 ${s.run} m`, { dy: 18, bold: true }).text([1 + W, 0.5 + H / 2], `${fmt(s.run * m)} m`, { dx: 8, anchor: "start", bold: true, color: "a" });
      if (m > 0) g.arc([1, 0.5], [2, 0.5], [1 + W, 0.5 + H], { color: "e", r: 44, label: `${fmt((Math.atan(m) * 180) / Math.PI, 1)}°` });
      g.text([1, 7.4], `경사 ${s.p}% = 기울기 ${fmt(m, 2)}`, { anchor: "start", bold: true, size: 18 });
    },
    metrics(s) { const m = s.p / 100; return [["기울기", fmt(m, 2), "key"], ["올라간 높이", `${fmt(s.run * m)} m`], ["각도", `${fmt((Math.atan(m) * 180) / Math.PI, 1)}°`]]; },
    predict: [
      { q: "경사 10%인 길을 수평으로 500 m 가면 몇 m 올라갈까요?", set: (s) => Object.assign(s, { p: 10, run: 100 }), reveal: (s) => (s.run = 500), answer: () => 50, why: "500 × 0.1 = 50 m입니다." },
      { q: "경사 100%인 길의 각도는?", set: (s) => (s.p = 50), reveal: (s) => (s.p = 100), answer: () => 45, why: "기울기 1이면 높이와 수평 거리가 같아 45°입니다." },
    ],
  },
  {
    id: "m2-intercept-tri", grade: G2, unit: 4, lesson: "4.2", title: "절편으로 그리는 직선과 삼각형의 넓이", type: "조작", time: "10분",
    tags: ["x절편", "y절편", "넓이"], links: ["m2-slope-intercept", "m2-linear-eq"],
    desc: "x절편 a와 y절편 b를 끌어 옮기면 두 점을 지나는 직선 x/a + y/b = 1이 그려지고, 직선과 두 좌표축이 만드는 삼각형의 넓이는 |ab|/2입니다. 기울기 −b/a도 함께 확인합니다.",
    obs: ["x절편은 y = 0일 때의 x, y절편은 x = 0일 때의 y입니다.", "두 절편을 알면 직선을 바로 그릴 수 있습니다.", "좌표축과 만드는 직각삼각형의 넓이는 |a| × |b| ÷ 2입니다."],
    q: "y = −2x + 6과 두 좌표축으로 둘러싸인 도형의 넓이를 구해 봅시다.",
    formula: "x/a + y/b = 1, 기울기 = −b/a, 넓이 = |ab|/2",
    en: { title: "Intercepts and Triangle Area", desc: "Drag the intercepts." },
    view: { x: [-6, 6], y: [-4.6, 4.6] },
    init: () => ({ a: 3, b: 4 }),
    drags: { A: { at: (s) => [s.a, 0], move: (s, p) => (s.a = clamp(Math.round(p[0] * 2) / 2, -5.5, 5.5) || 0.5), color: "a", label: "x절편" }, B: { at: (s) => [0, s.b], move: (s, p) => (s.b = clamp(Math.round(p[1] * 2) / 2, -4, 4) || 0.5), color: "b", label: "y절편" } },
    draw(s, g) { g.grid(); g.poly([[0, 0], [s.a, 0], [0, s.b]], { fill: "c", fo: 0.25, color: "c", w: 1.4 }); g.line([s.a, 0], [0, s.b], { color: "ink", w: 3 }); g.point([s.a, 0], `(${fmt(s.a)}, 0)`, { color: "a", dy: 20 }).point([0, s.b], `(0, ${fmt(s.b)})`, { color: "b" }); },
    metrics(s) { return [["직선", `y = ${poly([[-s.b / s.a, "x"]], s.b)}`], ["기울기", fmt(-s.b / s.a, 3)], ["삼각형의 넓이", fmt(Math.abs(s.a * s.b) / 2, 2), "key"]]; },
    predict: [
      { q: "y = −2x + 4와 두 좌표축으로 둘러싸인 삼각형의 넓이는?", set: (s) => Object.assign(s, { a: 1, b: 1 }), reveal: (s) => Object.assign(s, { a: 2, b: 4 }), answer: () => 4, why: "x절편 2, y절편 4이므로 2 × 4 ÷ 2 = 4입니다." },
      { q: "x절편 4, y절편 −2인 직선의 기울기는?", set: (s) => Object.assign(s, { a: 1, b: 1 }), reveal: (s) => Object.assign(s, { a: 4, b: -2 }), answer: () => 0.5, why: "−b/a = −(−2)/4 = 1/2입니다." },
    ],
  },
  {
    id: "m2-two-points", grade: G2, unit: 4, lesson: "4.2", title: "두 점을 지나는 직선 — 기울기부터 식까지", type: "조작", time: "10분",
    tags: ["일차함수의 식", "기울기", "두 점"], links: ["m2-slope-intercept", "m2-intercept-tri"],
    desc: "두 점 P, Q를 끌어 옮기면 기울기 (y₂ − y₁)/(x₂ − x₁)과 y절편이 정해져 직선의 식 y = ax + b가 하나로 결정됩니다. 두 점의 x좌표가 같으면 기울기를 정할 수 없는 세로 직선이 되는 것도 확인합니다.",
    obs: ["두 점이 정해지면 직선은 하나뿐입니다.", "기울기 a를 구한 뒤 한 점의 좌표를 대입하면 b를 구할 수 있습니다.", "x₁ = x₂이면 x = x₁인 세로 직선입니다."],
    q: "(1, 3)과 (3, 7)을 지나는 직선 위에 (10, ?)이 있으려면 ?는 얼마일까요?",
    formula: "a = (y₂ − y₁)/(x₂ − x₁), b = y₁ − ax₁",
    en: { title: "A Line Through Two Points", desc: "From slope to equation." },
    view: { x: [-6, 6], y: [-4.6, 4.6] },
    init: () => ({ P: [-2, -1], Q: [3, 2] }),
    drags: { P: { at: (s) => s.P, move: (s, p) => (s.P = [clamp(Math.round(p[0]), -5, 5), clamp(Math.round(p[1]), -4, 4)]), label: "P" }, Q: { at: (s) => s.Q, move: (s, p) => (s.Q = [clamp(Math.round(p[0]), -5, 5), clamp(Math.round(p[1]), -4, 4)]), label: "Q", color: "b" } },
    draw(s, g) { const [x1, y1] = s.P, [x2, y2] = s.Q; g.grid(); if (x1 !== x2 || y1 !== y2) g.line(s.P, s.Q, { color: "ink", w: 3 }); if (x1 !== x2) { g.seg(s.P, [x2, y1], { color: "a", w: 2 }).seg([x2, y1], s.Q, { color: "c", w: 2 }); g.text([(x1 + x2) / 2, y1], `Δx = ${x2 - x1}`, { dy: y2 > y1 ? 16 : -6, size: 12, bold: true, color: "a" }).text([x2, (y1 + y2) / 2], `Δy = ${y2 - y1}`, { dx: 6, anchor: "start", size: 12, bold: true, color: "c" }); } g.point(s.P, `P(${x1}, ${y1})`, { color: "a" }).point(s.Q, `Q(${x2}, ${y2})`, { color: "b" }); },
    metrics(s) { const [x1, y1] = s.P, [x2, y2] = s.Q; if (x1 === x2) return [["직선", x1 === x2 && y1 === y2 ? "두 점이 같아요" : `x = ${x1} (세로 직선)`, "key"]]; const a = (y2 - y1) / (x2 - x1), b = y1 - a * x1; return [["기울기", `${y2 - y1}/${x2 - x1} = ${frac(a)}`], ["y절편", frac(b)], ["식", `y = ${poly([[a, "x"]], b)}`, "key"]]; },
    predict: [
      { q: "(1, 3)과 (3, 7)을 지나는 직선의 기울기는?", set: (s) => Object.assign(s, { P: [1, 3], Q: [2, 3] }), reveal: (s) => (s.Q = [3, 4]), answer: () => 2, why: "(7 − 3)/(3 − 1) = 2입니다." },
      { q: "같은 직선의 y절편은?", set: (s) => Object.assign(s, { P: [1, 3], Q: [3, 4] }), answer: () => 1, why: "y = 2x + b에 (1, 3)을 넣으면 b = 1입니다." },
    ],
  },
  {
    id: "m2-lattice", grade: G2, unit: 4, lesson: "4.2", title: "직선 위의 격자점 — 동전으로 정확히 내기", type: "조작", time: "10분",
    tags: ["일차방정식", "자연수 해", "격자점"], links: ["m2-linear-eq"],
    desc: "300원짜리와 500원짜리 동전으로 c원을 정확히 내는 방법은 3x + 5y = c/100의 0 이상의 정수해, 곧 직선 위의 격자점입니다. c를 바꾸며 격자점이 몇 개인지, 정확히 낼 수 없는 금액은 언제인지 찾습니다.",
    obs: ["0 이상의 정수 x, y에 대하여 3x + 5y = k를 만족하는 점이 격자점입니다.", "격자점끼리는 x가 5씩, y가 3씩 차이 납니다.", "k = 7처럼 낼 수 없는 금액도 있습니다."],
    q: "300원·500원 동전으로 낼 수 없는 금액 가운데 가장 큰 것은 얼마일까요?",
    formula: "3x + 5y = k (x, y는 0 이상의 정수)",
    en: { title: "Lattice Points on a Line", desc: "Pay exactly with two coin types." },
    view: { x: [-1, 16], y: [-1, 10] },
    params: [{ key: "k", label: "낼 금액 (백 원)", min: 1, max: 45, step: 1, value: 30 }],
    anim: { key: "k", min: 1, max: 45, speed: 3, label: "금액 바꾸기" },
    pts(k) { const P = []; for (let y = 0; 5 * y <= k; y++) if ((k - 5 * y) % 3 === 0) P.push([(k - 5 * y) / 3, y]); return P; },
    draw(s, g) {
      g.grid({ labels: false }); for (let x = 0; x <= 15; x += 5) g.text([x, 0], String(x), { dy: 16, size: 11, color: "muted" }); for (let y = 5; y <= 9; y += 5) g.text([0, y], String(y), { dx: -6, anchor: "end", dy: 4, size: 11, color: "muted" });
      g.seg([0, s.k / 5], [s.k / 3, 0], { color: "b", w: 2.6 });
      this.pts(s.k).forEach((p) => g.point(p, `(${p[0]}, ${p[1]})`, { color: "a" }));
      g.text([15.5, 9.4], `300원 x개 + 500원 y개 = ${s.k * 100}원`, { anchor: "end", bold: true, size: 14 });
      g.text([15.5, 0], "300원 개수 x", { anchor: "end", dy: 30, size: 11, color: "muted" });
    },
    metrics(s) { const P = this.pts(s.k); return [["방정식", `3x + 5y = ${s.k}`], ["내는 방법 (격자점)", `${P.length}가지`, "key"], ["방법", P.map(([x, y]) => `300원 ${x}개 + 500원 ${y}개`).join(" / ") || "정확히 낼 수 없음"]]; },
    predict: [
      { q: "3000원을 300원·500원 동전으로 정확히 내는 방법은 몇 가지?", set: (s) => (s.k = 10), reveal: (s) => (s.k = 30), answer: () => 3, why: "(10, 0), (5, 3), (0, 6)의 3가지입니다." },
      { q: "700원은 정확히 낼 수 있을까요?", options: O("없다", "있다"), set: (s) => (s.k = 8), reveal: (s) => (s.k = 7), answer: () => "a", why: "3x + 5y = 7을 만족하는 0 이상의 정수 해가 없습니다." },
    ],
  },
  {
    id: "m2-ladder", grade: G2, unit: 7, lesson: "7.5", title: "미끄러지는 사다리 — 피타고라스 정리의 활용", type: "조작", time: "10분",
    tags: ["피타고라스 정리", "활용", "자취"], links: ["m2-pythag-proof"],
    desc: "길이 L인 사다리를 벽에 기대 놓고 아래쪽을 벽에서 x만큼 떨어뜨리면 위쪽 높이는 √(L² − x²)입니다. 사다리가 미끄러질 때 높이가 어떻게 줄어드는지, 그리고 사다리 가운데 점이 그리는 자취가 원이 되는 신기한 사실도 관찰합니다.",
    obs: ["벽, 바닥, 사다리가 직각삼각형을 이루므로 x² + h² = L²입니다.", "x가 일정하게 늘어도 h는 처음엔 천천히, 나중엔 빨리 줄어듭니다.", "사다리의 가운데 점은 벽 밑동에서 항상 L/2만큼 떨어져 원을 그립니다."],
    q: "사다리 가운데가 아닌 다른 점(예: 위에서 1/3 지점)은 어떤 곡선을 그릴까요?",
    formula: "x² + h² = L² ⇒ h = √(L² − x²)",
    en: { title: "The Sliding Ladder", desc: "Pythagoras in action." },
    view: { x: [-0.8, 8.4], y: [-0.8, 6.4] },
    params: [{ key: "L", label: "사다리 길이 L (m)", min: 3, max: 6, step: 0.5, value: 5 }, { key: "x", label: "벽에서 떨어진 거리 x (m)", min: 0, max: 6, step: 0.1, value: 3 }, { key: "trace", label: "가운데 점의 자취", type: "check", value: true }],
    anim: { key: "x", min: 0, max: 5, speed: 0.6, label: "미끄러뜨리기", loop: "bounce" },
    onChange(s) { s.x = clamp(s.x, 0, s.L); },
    draw(s, g) {
      const h = Math.sqrt(Math.max(0, s.L * s.L - s.x * s.x)), M = [s.x / 2, h / 2];
      g.seg([0, 0], [8, 0], { color: "ink", w: 3 }).seg([0, 0], [0, 6.2], { color: "ink", w: 3 });
      if (s.trace) g.param((t) => [(s.L / 2) * Math.cos(t), (s.L / 2) * Math.sin(t)], 0, Math.PI / 2, { color: "e", w: 1.8, dash: "5 4" });
      g.seg([s.x, 0], [0, h], { color: "a", w: 6 });
      g.right([0, 0], [1, 0], [0, 1], { color: "muted" });
      g.text([s.x / 2, 0], `x = ${fmt(s.x, 1)}`, { dy: 18, bold: true }).text([0, h / 2], `h = ${fmt(h, 2)}`, { dx: -8, anchor: "end", bold: true, color: "b" }).text(M, `L = ${fmt(s.L)}`, { dx: 12, anchor: "start", bold: true, color: "a" });
      g.point(M, "", { color: "e", r: 5 });
    },
    metrics(s) { const h = Math.sqrt(Math.max(0, s.L * s.L - s.x * s.x)); return [["x² + h²", `${fmt(s.x * s.x, 2)} + ${fmt(h * h, 2)} = ${fmt(s.L * s.L, 2)}`], ["높이 h", `${fmt(h, 3)} m`, "key"], ["가운데 점과 벽 밑동의 거리", `${fmt(s.L / 2, 2)} m (항상 같음)`]]; },
    predict: [
      { q: "5 m 사다리의 아래쪽이 벽에서 3 m 떨어져 있으면 높이는?", set: (s) => Object.assign(s, { L: 5, x: 1 }), reveal: (s) => (s.x = 3), answer: () => 4, why: "√(25 − 9) = 4 m입니다." },
      { q: "사다리가 미끄러질 때 가운데 점이 그리는 모양은?", options: O("원의 일부", "직선", "포물선"), set: (s) => Object.assign(s, { trace: false, x: 0.5 }), reveal: (s) => (s.trace = true), answer: () => "a", why: "직각삼각형의 빗변의 중점은 세 꼭짓점에서 같은 거리에 있어, 벽 밑동에서 늘 L/2 떨어져 있습니다." },
    ],
  },
  {
    id: "m2-rps", grade: G2, unit: 8, lesson: "8.1", title: "가위바위보 경우의 수 — 표로 세면 비기는 확률은?", type: "조작", time: "10분",
    tags: ["경우의 수", "확률", "표"], links: ["m2-dice-poly"],
    desc: "두 사람 또는 세 사람이 가위바위보를 할 때 나올 수 있는 모든 경우를 표로 늘어놓고, 승부가 나는 경우와 비기는 경우를 셉니다. 사람이 늘수록 비길 확률이 커지는 까닭을 확인합니다.",
    obs: ["두 사람이면 3 × 3 = 9가지, 세 사람이면 3 × 3 × 3 = 27가지입니다.", "두 사람이 비기는 경우는 같은 것을 낸 3가지입니다.", "세 사람은 모두 같거나 세 가지가 다 나오면 비깁니다."],
    q: "네 사람이 가위바위보를 하면 비길 확률은 얼마일까요?",
    formula: "두 사람: 비길 확률 3/9 = 1/3, 세 사람: 9/27 = 1/3",
    en: { title: "Rock–Paper–Scissors Outcomes", desc: "Count draws with a table." },
    view: BOX,
    params: [{ key: "n", label: "사람 수", type: "seg", value: 2, options: [[2, "2명"], [3, "3명"]] }],
    hands: ["✌", "✊", "✋"],
    res(h) { const k = new Set(h).size; if (k !== 2) return "비김"; const has = (x) => h.includes(x); const win = has(0) && has(1) ? 1 : has(1) && has(2) ? 2 : 0; return win; },
    draw(s, g) {
      const H = this.hands;
      if (s.n === 2) { const c = 2.2, x0 = 4, y0 = 9.6; H.forEach((h, i) => { g.text([x0 + (i + 0.5) * c, y0 + 0.5], h, { size: 22, keep: true }); g.text([x0 - 0.5, y0 - (i + 0.5) * c], h, { size: 22, dy: 8, keep: true }); }); for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) { const r = this.res([j, i]); rect(g, x0 + i * c, y0 - (j + 1) * c, c - 0.1, c - 0.1, { fill: r === "비김" ? "e" : "c", fo: 0.25, color: "grid", w: 1 }); g.text([x0 + (i + 0.5) * c, y0 - (j + 0.5) * c], r === "비김" ? "비김" : r === 0 ? "가위 이김" : r === 1 ? "바위 이김" : "보 이김", { dy: 5, size: 12, bold: true, color: r === "비김" ? "e" : "c" }); } g.text([x0 - 0.5, y0 + 0.5], "A \\ B", { size: 11, color: "muted" }); }
      else { let k = 0; for (let a = 0; a < 3; a++) for (let b = 0; b < 3; b++) for (let c = 0; c < 3; c++) { const r = this.res([a, b, c]), x = 0.6 + (k % 9) * 1.68, y = 9.8 - Math.floor(k / 9) * 2.6; rect(g, x, y - 2.2, 1.55, 2.2, { fill: r === "비김" ? "e" : "c", fo: 0.22, color: "grid", w: 1 }); g.text([x + 0.78, y - 0.75], H[a] + H[b] + H[c], { size: 14, keep: true }); g.text([x + 0.78, y - 1.65], r === "비김" ? "비김" : "승부", { size: 11, bold: true, color: r === "비김" ? "e" : "c" }); k++; } }
    },
    metrics(s) { const all = s.n === 2 ? 9 : 27; let d = 0; if (s.n === 2) { for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) if (this.res([i, j]) === "비김") d++; } else for (let a = 0; a < 3; a++) for (let b = 0; b < 3; b++) for (let c = 0; c < 3; c++) if (this.res([a, b, c]) === "비김") d++; return [["모든 경우", `${all}가지`], ["비기는 경우", `${d}가지`], ["비길 확률", `${d}/${all} = ${fmt(d / all, 3)}`, "key"]]; },
    predict: [
      { q: "세 사람이 가위바위보를 할 때 비기는 경우는 몇 가지?", set: (s) => (s.n = 2), reveal: (s) => (s.n = 3), answer: () => 9, why: "모두 같은 3가지 + 셋 다 다른 3! = 6가지 = 9가지입니다." },
      { q: "두 사람이 할 때 A가 이길 확률은?", options: O("1/3", "1/2", "2/9"), set: (s) => (s.n = 2), answer: () => "a", why: "9가지 가운데 A가 이기는 경우가 3가지입니다." },
    ],
  },
  {
    id: "m2-dice-poly", grade: G2, unit: 8, lesson: "8.2", title: "정다면체 주사위 — 많이 던지면 1/n에 가까워진다", type: "데이터", time: "10분",
    tags: ["확률", "상대도수", "정다면체"], links: ["m2-rps"],
    desc: "정사면체부터 정이십면체까지 다섯 가지 정다면체 주사위를 여러 번 던져 특정한 눈(1)이 나오는 상대도수를 기록합니다. 던진 횟수가 많아질수록 상대도수가 이론적인 확률 1/n에 가까워지는 모습을 그래프로 확인합니다.",
    obs: ["정다면체의 면은 모두 합동이라 각 눈이 나올 가능성이 같습니다.", "그래서 한 눈이 나올 확률은 1/(면의 수)입니다.", "던진 횟수가 적을 때는 상대도수가 크게 흔들리지만 많아질수록 안정됩니다."],
    q: "정다면체가 아닌 모양(예: 길쭉한 육각기둥)으로 주사위를 만들면 어떤 문제가 생길까요?",
    formula: "확률 = 1/n (n: 면의 수), 상대도수 → 확률 (횟수가 많을 때)",
    en: { title: "Polyhedral Dice", desc: "Relative frequency approaches 1/n." },
    view: { x: [-1.4, 11.4], y: [-0.9, 7.2] },
    params: [{ key: "d", label: "주사위", type: "seg", value: 6, options: DICE.map(([n, t]) => [n, `${t}(${n})`]) }, { key: "N", label: "던진 횟수", min: 10, max: 1000, step: 10, value: 300 }, { key: "seed", label: "다시 던지기", min: 1, max: 30, step: 1, value: 1 }],
    anim: { key: "N", min: 10, max: 1000, speed: 120, label: "계속 던지기" },
    draw(s, g) {
      const X = (n) => (n / 1000) * 10, Y = (p) => p * 12, r = lcg(s.seed * 31 + s.d), pts = []; let c = 0;
      for (let i = 1; i <= s.N; i++) { if (Math.floor(r() * s.d) === 0) c++; if (i % 5 === 0 || i === s.N) pts.push([X(i), Y(c / i)]); }
      g.seg([0, 0], [10.3, 0], { color: "axis", w: 1.4 }).seg([0, 0], [0, Y(0.55)], { color: "axis", w: 1.4 });
      [0.1, 0.2, 0.3, 0.4, 0.5].forEach((p) => g.text([0, Y(p)], fmt(p, 1), { dx: -6, anchor: "end", dy: 4, size: 11, color: "muted" }));
      [250, 500, 750, 1000].forEach((n) => g.text([X(n), 0], String(n), { dy: 16, size: 11, color: "muted" }));
      g.seg([0, Y(1 / s.d)], [10.3, Y(1 / s.d)], { color: "e", w: 1.8, dash: "6 4" }).text([10.3, Y(1 / s.d)], `1/${s.d}`, { dx: 4, anchor: "start", dy: 4, bold: true, color: "e" });
      g.path(pts, { color: "b", w: 2.2 });
    },
    metrics(s) { const r = lcg(s.seed * 31 + s.d); let c = 0; for (let i = 1; i <= s.N; i++) if (Math.floor(r() * s.d) === 0) c++; return [["1이 나온 횟수", `${c}번 / ${s.N}번`], ["상대도수", fmt(c / s.N, 4), "key"], ["확률 1/n", fmt(1 / s.d, 4)]]; },
    predict: [
      { q: "정십이면체 주사위에서 1이 나올 확률은? (분수로)", set: (s) => Object.assign(s, { d: 6, N: 100 }), reveal: (s) => Object.assign(s, { d: 12, N: 1000 }), answer: () => 1 / 12, tol: 1e-6, show: () => "1/12", why: "면이 12개이고 모두 합동이므로 1/12입니다." },
      { q: "던진 횟수를 늘리면 상대도수는?", options: O("확률에 가까워진다", "점점 0에 가까워진다", "항상 확률과 정확히 같다"), set: (s) => Object.assign(s, { d: 4, N: 20 }), reveal: (s) => (s.N = 1000), answer: () => "a", why: "큰 수의 법칙입니다. 정확히 같아지지는 않지만 흔들림이 줄어듭니다." },
    ],
  },
];
