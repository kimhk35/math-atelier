// 23차 묶음 10 — 중학교 3학년 추가 실험 12개
import { fmt, frac, poly, clamp, surd } from "./hs-core.js";

const G3 = 3;
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
const deg = (d) => (d * Math.PI) / 180;

export default [
  {
    id: "m3-sqrt-approx", grade: G3, unit: 1, lesson: "1.1", title: "넓이가 2인 정사각형의 한 변 — 한 자리씩 좁혀 가기", type: "조작", time: "10분",
    tags: ["제곱근", "근삿값", "무리수"], links: ["m3-sqrt-line"],
    desc: "한 변이 1이면 넓이가 1, 2이면 4이므로 √2는 1과 2 사이입니다. 1.4² = 1.96, 1.5² = 2.25처럼 소수 한 자리씩 늘려 가며 넓이 2를 사이에 두는 두 정사각형을 찾아 √2의 범위를 좁힙니다. 아무리 좁혀도 끝나지 않는 무리수임을 느껴 봅니다.",
    obs: ["a² < 2 < b²이면 a < √2 < b입니다.", "한 자리씩 늘릴 때마다 범위가 1/10로 좁아집니다.", "√2 = 1.41421356…은 끝나지도 되풀이되지도 않습니다."],
    q: "같은 방법으로 √10의 소수 첫째 자리까지의 값을 구해 봅시다.",
    formula: "a² < n < b² ⇒ a < √n < b",
    en: { title: "Approximating √2", desc: "Narrow the interval digit by digit." },
    view: BOX,
    params: [{ key: "n", label: "넓이 n", min: 2, max: 15, step: 1, value: 2 }, { key: "k", label: "소수 자릿수", min: 0, max: 6, step: 1, value: 2 }],
    anim: { key: "k", min: 0, max: 6, speed: 1, label: "한 자리씩" },
    bounds(s) { const r = Math.sqrt(s.n), u = 10 ** -s.k, lo = Math.floor(r / u) * u; return [lo, lo + u]; },
    draw(s, g) {
      const [lo, hi] = this.bounds(s), k = 8.6 / Math.ceil(Math.sqrt(s.n) + 0.01), x0 = 1, y0 = 1;
      rect(g, x0, y0, hi * k, hi * k, { fill: "a", fo: 0.15, color: "a", w: 1.6 });
      rect(g, x0, y0, Math.sqrt(s.n) * k, Math.sqrt(s.n) * k, { fill: "c", fo: 0.3, color: "c", w: 2.4 });
      rect(g, x0, y0, lo * k, lo * k, { fill: "b", fo: 0.25, color: "b", w: 1.6 });
      const tx = x0 + Math.ceil(Math.sqrt(s.n) + 0.01) * k + 0.6;
      g.text([tx, 9.6], `${fmt(lo, s.k)}² = ${fmt(lo * lo, 2 * s.k)}`, { anchor: "start", bold: true, color: "b", size: 15, mono: true }).text([tx, 8.6], `${fmt(hi, s.k)}² = ${fmt(hi * hi, 2 * s.k)}`, { anchor: "start", bold: true, color: "a", size: 15, mono: true });
      g.text([tx, 7.2], `${fmt(lo, s.k)} < √${s.n} < ${fmt(hi, s.k)}`, { anchor: "start", bold: true, size: 18, color: "c" });
    },
    metrics(s) { const [lo, hi] = this.bounds(s); return [["범위", `${fmt(lo, s.k)} < √${s.n} < ${fmt(hi, s.k)}`, "key"], ["범위의 폭", fmt(hi - lo, s.k + 1)], ["계산기 값", fmt(Math.sqrt(s.n), 8)]]; },
    predict: [
      { q: "√2를 소수 첫째 자리까지 구하면? (버림)", set: (s) => Object.assign(s, { n: 2, k: 0 }), reveal: (s) => (s.k = 1), answer: () => 1.4, tol: 1e-9, why: "1.4² = 1.96 < 2 < 2.25 = 1.5²입니다." },
      { q: "√10은 어느 두 자연수 사이에 있을까요? 작은 쪽을 쓰세요.", set: (s) => Object.assign(s, { n: 10, k: 1 }), reveal: (s) => (s.k = 0), answer: () => 3, why: "3² = 9 < 10 < 16 = 4²입니다." },
    ],
  },
  {
    id: "m3-sqrt-graph", grade: G3, unit: 1, lesson: "1.2", title: "제곱근의 대소 — y = √x 그래프로 비교하기", type: "조작", time: "8분",
    tags: ["제곱근의 대소", "그래프", "근호"], links: ["m3-sqrt-approx"],
    desc: "y = √x의 그래프는 오른쪽으로 갈수록 올라가므로, a < b이면 √a < √b입니다. 두 수 a, b를 정해 그래프 위의 높이로 √a와 √b를 비교하고, 3과 √10처럼 근호가 없는 수는 제곱해서 비교하는 방법도 확인합니다.",
    obs: ["a, b ≥ 0일 때 a < b ⇔ √a < √b입니다.", "근호가 있는 수와 없는 수는 둘 다 제곱해서 비교할 수 있습니다: 3 = √9 < √10.", "그래프가 점점 완만해져 √x는 x보다 천천히 커집니다."],
    q: "√5, 2.3, √(5.5)를 작은 것부터 늘어놓아 봅시다.",
    formula: "0 ≤ a < b ⇔ √a < √b",
    en: { title: "Comparing Square Roots", desc: "Use the graph of y = √x." },
    view: { x: [-1, 17], y: [-0.8, 4.8] },
    params: [{ key: "a", label: "a", min: 0, max: 16, step: 0.5, value: 9 }, { key: "b", label: "b", min: 0, max: 16, step: 0.5, value: 10 }],
    draw(s, g) {
      g.grid({ every: 2 });
      g.fx(Math.sqrt, { color: "b", w: 3, from: 0, to: 16.5 });
      [[s.a, "a"], [s.b, "c"]].forEach(([v, c]) => { const y = Math.sqrt(v); g.seg([v, 0], [v, y], { color: c, w: 1.4, dash: "3 4" }).seg([0, y], [v, y], { color: c, w: 1.4, dash: "3 4" }); g.point([v, y], `√${fmt(v)} ≈ ${fmt(y, 3)}`, { color: c, dy: c === "a" ? -10 : 18 }); });
    },
    metrics(s) { const A = Math.sqrt(s.a), B = Math.sqrt(s.b); return [["√a, √b", `${fmt(A, 4)}, ${fmt(B, 4)}`], ["비교", A < B ? `√${fmt(s.a)} < √${fmt(s.b)}` : A > B ? `√${fmt(s.a)} > √${fmt(s.b)}` : "같다", "key"]]; },
    predict: [
      { q: "3과 √10 가운데 큰 수는?", options: O("√10", "3"), set: (s) => Object.assign(s, { a: 4, b: 5 }), reveal: (s) => Object.assign(s, { a: 9, b: 10 }), answer: () => "a", why: "3 = √9이고 9 < 10이므로 √10이 큽니다." },
      { q: "√x가 3보다 작은 자연수 x는 모두 몇 개?", set: (s) => Object.assign(s, { a: 1, b: 9 }), answer: () => 8, why: "√x < 3 ⇔ x < 9이므로 1부터 8까지 8개입니다." },
    ],
  },
  {
    id: "m3-dense-line", grade: G3, unit: 1, lesson: "1.1", title: "수직선의 빈틈 — 유리수로는 √2에 닿지 못한다", type: "조작", time: "10분",
    tags: ["유리수", "무리수", "실수"], links: ["m3-sqrt-line", "m3-sqrt-approx"],
    desc: "분모가 q 이하인 유리수를 수직선에 모두 찍고 √2 근처를 확대해 봅니다. 유리수는 점점 빽빽해지지만 √2와 정확히 같은 점은 하나도 없고, 그 빈 곳을 채우는 것이 무리수입니다. 가장 가까운 분수와 √2의 차이를 확인합니다.",
    obs: ["두 유리수 사이에는 항상 또 다른 유리수가 있을 만큼 빽빽합니다.", "그래도 √2처럼 유리수가 아닌 점이 남습니다.", "유리수와 무리수를 합친 실수가 수직선을 빈틈없이 채웁니다."],
    q: "√2에 가장 가까운 분모 12 이하의 분수는 무엇일까요?",
    formula: "실수 = 유리수 ∪ 무리수",
    en: { title: "Gaps in the Rationals", desc: "No fraction lands exactly on √2." },
    view: (s) => { const w = 0.5 / 10 ** s.z; return { x: [Math.SQRT2 - w, Math.SQRT2 + w], y: [-w * 0.32, w * 0.32] }; },
    params: [{ key: "q", label: "분모의 최댓값 q", min: 2, max: 60, step: 1, value: 12 }, { key: "z", label: "확대", min: 0, max: 3, step: 0.1, value: 0, show: (v) => `${fmt(10 ** v, 0)}배` }],
    anim: { key: "q", min: 2, max: 60, speed: 8, label: "분모 늘리기" },
    best(s) { let b = null; for (let q = 1; q <= s.q; q++) { const p = Math.round(Math.SQRT2 * q), d = Math.abs(p / q - Math.SQRT2); if (!b || d < b.d - 1e-15) b = { p, q, d }; } return b; },
    draw(s, g) {
      const [x0, x1] = g.xr, h = (g.yr[1] - g.yr[0]) * 0.08;
      g.seg([x0, 0], [x1, 0], { color: "axis", w: 1.6 });
      const st = 10 ** Math.floor(Math.log10((x1 - x0) / 2)); for (let v = Math.ceil(x0 / st) * st; v <= x1; v += st) g.text([v, 0], fmt(v, 5), { dy: (g.yr[1] - g.yr[0]) * 0 + 40, size: 11, color: "muted" });
      for (let q = 1; q <= s.q; q++) for (let p = Math.ceil(x0 * q); p <= Math.floor(x1 * q); p++) g.seg([p / q, -h * (1 + 4 / q)], [p / q, h * (1 + 4 / q)], { color: "b", w: 1.2, opacity: 0.4 + 0.6 / q });
      g.seg([Math.SQRT2, -h * 6], [Math.SQRT2, h * 6], { color: "e", w: 2.6 }).text([Math.SQRT2, h * 6], "√2", { dy: -4, bold: true, color: "e" });
      const B = this.best(s); g.point([B.p / B.q, 0], `${B.p}/${B.q}`, { color: "a", dy: 22 });
    },
    metrics(s) { const B = this.best(s); return [["가장 가까운 분수", `${B.p}/${B.q} = ${fmt(B.p / B.q, 6)}`, "key"], ["√2와의 차", B.d < 1e-5 ? `약 ${fmt(B.d * 1e6, 2)}백만분의 1` : fmt(B.d, 6)], ["보이는 폭", fmt(g0(s), 6)]]; },
    predict: [
      { q: "분모 12 이하에서 √2에 가장 가까운 분수의 분모는?", set: (s) => Object.assign(s, { q: 3, z: 0 }), reveal: (s) => (s.q = 12), answer: () => 12, why: "17/12 = 1.41666…이 √2 ≈ 1.41421에 가장 가깝습니다." },
      { q: "분모를 아무리 크게 해도 √2와 정확히 같은 분수가 나올까요?", options: O("나오지 않는다", "언젠가 나온다"), set: (s) => Object.assign(s, { q: 20, z: 1 }), reveal: (s) => (s.z = 3), answer: () => "a", why: "√2는 무리수라 어떤 분수와도 같지 않습니다." },
    ],
  },
  {
    id: "m3-rationalize", grade: G3, unit: 1, lesson: "1.3", title: "분모의 유리화 — 1/√2 = √2/2를 길이로 확인", type: "조작", time: "8분",
    tags: ["분모의 유리화", "제곱근", "직각이등변삼각형"], links: ["m3-sqrt-sum"],
    desc: "빗변이 1인 직각이등변삼각형의 한 변은 1/√2입니다. 같은 길이를 한 변이 1인 정사각형의 대각선의 절반 √2/2로도 볼 수 있어, 분모와 분자에 √2를 곱한 1/√2 = √2/2가 같은 길이임을 그림으로 확인합니다. 다른 수 a/√b에도 적용해 봅니다.",
    obs: ["분모와 분자에 같은 수 √b를 곱해도 값은 같습니다.", "a/√b = a√b/b로 분모에서 근호를 없앨 수 있습니다.", "분모가 유리수이면 크기를 어림하기 쉬워집니다."],
    q: "3/√3을 유리화하면 어떤 간단한 수가 될까요?",
    formula: "a/√b = (a × √b)/(√b × √b) = a√b/b",
    en: { title: "Rationalizing Denominators", desc: "1/√2 = √2/2 as a length." },
    view: { x: [-0.6, 9.6], y: [-0.8, 5.6] },
    params: [{ key: "a", label: "분자 a", min: 1, max: 6, step: 1, value: 1 }, { key: "b", label: "근호 안 b", min: 2, max: 12, step: 1, value: 2 }],
    draw(s, g) {
      const k = 4.6, v = s.a / Math.sqrt(s.b), L = Math.min(8.4, v * k * 2);
      rect(g, 0.4, 0.4, k, k, { color: "muted", w: 1.4, dash: "5 4" });
      g.seg([0.4, 0.4], [0.4 + k, 0.4 + k], { color: "b", w: 2.2 }).text([0.4 + k / 2, 0.4 + k / 2], "√2", { dx: -14, bold: true, color: "b" });
      g.poly([[0.4, 0.4], [0.4 + k, 0.4], [0.4 + k / 2, 0.4 + k / 2]], { fill: "c", fo: 0.25, color: "c", w: 2 });
      g.text([0.4 + k / 2, 0.4], "1", { dy: 16, bold: true });
      g.seg([5.6, 1.4], [5.6 + v * 2, 1.4], { color: "a", w: 6 }).seg([5.6, 0.8], [5.6 + (s.a * Math.sqrt(s.b) / s.b) * 2, 0.8], { color: "e", w: 6, opacity: 0.7 });
      g.text([5.6, 2.4], `${s.a}/√${s.b} = ${s.a}√${s.b}/${s.b}`, { anchor: "start", bold: true, size: 16 });
      g.text([5.6, 1.4], `${fmt(v, 4)}`, { dx: v * 2 * g.s + 6, anchor: "start", dy: 4, size: 12, color: "a" });
    },
    metrics(s) { const v = s.a / Math.sqrt(s.b); return [["유리화", `${s.a}/√${s.b} = ${s.a === 1 ? "" : s.a}√${s.b}/${s.b}`, "key"], ["값", fmt(v, 5)]]; },
    predict: [
      { q: "3/√3을 간단히 하면?", options: O("√3", "3", "1"), set: (s) => Object.assign(s, { a: 1, b: 2 }), reveal: (s) => Object.assign(s, { a: 3, b: 3 }), answer: () => "a", why: "3√3/3 = √3입니다." },
      { q: "1/√2의 값을 소수 둘째 자리까지 구하면?", set: (s) => Object.assign(s, { a: 1, b: 2 }), answer: () => 0.71, tol: 0.005, why: "√2/2 ≈ 1.414/2 ≈ 0.707입니다." },
    ],
  },
  {
    id: "m3-common-factor", grade: G3, unit: 2, lesson: "2.2", title: "공통인수로 묶기 — 붙은 두 직사각형을 하나로", type: "조작", time: "8분",
    tags: ["인수분해", "공통인수", "분배법칙"], links: ["m3-tile-factor", "m3-mult-formula"],
    desc: "세로가 같은 두 직사각형 ma와 mb를 나란히 붙이면 세로 m, 가로 a + b인 하나의 직사각형 m(a + b)가 됩니다. 공통인수를 묶어 내는 인수분해가 분배법칙을 거꾸로 쓰는 것임을 넓이로 확인합니다.",
    obs: ["모든 항에 공통으로 들어 있는 인수를 공통인수라 합니다.", "ma + mb = m(a + b)는 분배법칙을 거꾸로 쓴 것입니다.", "공통인수를 모두 묶어야 완전한 인수분해입니다."],
    q: "6x² + 9x를 인수분해할 때 공통인수는 무엇일까요?",
    formula: "ma + mb = m(a + b)",
    en: { title: "Factoring Out a Common Factor", desc: "Merge two rectangles into one." },
    view: BOX,
    params: [{ key: "m", label: "공통인수 m (세로)", min: 1, max: 5, step: 0.5, value: 3 }, { key: "a", label: "a", min: 1, max: 6, step: 0.5, value: 4 }, { key: "b", label: "b", min: 1, max: 6, step: 0.5, value: 2.5 }, { key: "merge", label: "하나로 붙이기", type: "check", value: false }],
    draw(s, g) {
      const k = Math.min(1.5, 13 / (s.a + s.b + 1), 7 / s.m), gap = s.merge ? 0 : 1, x0 = 1, y0 = 2;
      rect(g, x0, y0, s.a * k, s.m * k, { fill: "b", fo: 0.35, color: "b", w: 2 }); rect(g, x0 + s.a * k + gap, y0, s.b * k, s.m * k, { fill: "a", fo: 0.35, color: "a", w: 2 });
      g.text([x0 + (s.a * k) / 2, y0 + (s.m * k) / 2], "ma", { bold: true, size: 16, color: "b" }).text([x0 + s.a * k + gap + (s.b * k) / 2, y0 + (s.m * k) / 2], "mb", { bold: true, size: 16, color: "a" });
      g.text([x0, y0 + (s.m * k) / 2], "m", { dx: -8, anchor: "end", bold: true });
      if (s.merge) { rect(g, x0, y0, (s.a + s.b) * k, s.m * k, { color: "ink", w: 3 }); g.text([x0 + ((s.a + s.b) * k) / 2, y0], "a + b", { dy: 20, bold: true, color: "c", size: 15 }); }
      g.text([1, 10.2], s.merge ? `ma + mb = m(a + b)` : "ma + mb", { anchor: "start", bold: true, size: 20, color: s.merge ? "c" : "ink" });
    },
    metrics(s) { return [["ma + mb", fmt(s.m * s.a + s.m * s.b, 3)], ["m(a + b)", fmt(s.m * (s.a + s.b), 3)], ["같은가?", "같다 ✓", "key"]]; },
    predict: [
      { q: "6x² + 9x = 3x(□x + 3)에서 □는?", answer: () => 2, why: "공통인수 3x로 묶으면 6x² = 3x × 2x, 9x = 3x × 3입니다." },
      { q: "두 직사각형을 붙여도 넓이의 합은?", options: O("그대로이다", "커진다"), set: (s) => (s.merge = false), reveal: (s) => (s.merge = true), answer: () => "a", why: "모양만 하나로 붙였을 뿐 넓이는 같습니다." },
    ],
  },
  {
    id: "m3-garden", grade: G3, unit: 3, lesson: "3.4", title: "화단 사이의 길 — 이차방정식의 활용", type: "조작", time: "12분",
    tags: ["이차방정식의 활용", "넓이", "근의 선택"], links: ["m3-quad-formula"],
    desc: "가로 W m, 세로 H m인 땅에 폭이 x m인 길을 가로·세로로 하나씩 내고 남은 화단의 넓이를 A m²로 만들려고 합니다. 길을 한쪽으로 모아도 넓이가 같다는 생각으로 (W − x)(H − x) = A를 세우고, 두 근 가운데 문제에 맞는 근을 고릅니다.",
    obs: ["길을 땅의 가장자리로 밀어 모아도 화단의 넓이는 그대로입니다.", "그래서 화단은 가로 W − x, 세로 H − x인 직사각형과 같습니다.", "이차방정식의 두 근 가운데 0 < x < (짧은 변)을 만족하는 것만 답이 됩니다."],
    q: "길이 두 개씩(가로 2개, 세로 2개)이면 방정식이 어떻게 바뀔까요?",
    formula: "(W − x)(H − x) = A",
    en: { title: "Garden Paths", desc: "Applying quadratic equations." },
    view: BOX,
    params: [{ key: "W", label: "가로 W (m)", min: 10, max: 30, step: 1, value: 20 }, { key: "H", label: "세로 H (m)", min: 8, max: 20, step: 1, value: 15 }, { key: "A", label: "남길 화단 넓이 A (m²)", min: 50, max: 400, step: 2, value: 234 }, { key: "x", label: "길의 폭 x (m)", min: 0, max: 7, step: 0.5, value: 1 }],
    onChange(s) { s.A = clamp(s.A, 10, s.W * s.H - 2); },
    draw(s, g) {
      const k = Math.min(14 / s.W, 9.6 / s.H), x0 = 1, y0 = 0.8, px = x0 + s.W * k * 0.4, py = y0 + s.H * k * 0.55;
      rect(g, x0, y0, s.W * k, s.H * k, { fill: "c", fo: 0.35, color: "ink", w: 2 });
      rect(g, px, y0, s.x * k, s.H * k, { fill: "paper", fo: 1, color: "muted", w: 1 }); rect(g, x0, py, s.W * k, s.x * k, { fill: "paper", fo: 1, color: "muted", w: 1 });
      g.text([x0 + (s.W * k) / 2, y0], `${s.W} m`, { dy: 16, bold: true }).text([x0, y0 + (s.H * k) / 2], `${s.H} m`, { dx: -6, anchor: "end", bold: true });
      g.text([px + (s.x * k) / 2, y0 + s.H * k], `길 ${fmt(s.x)} m`, { dy: -6, size: 12, color: "muted", bold: true });
    },
    metrics(s) {
      const area = (s.W - s.x) * (s.H - s.x), b = -(s.W + s.H), c = s.W * s.H - s.A, D = b * b - 4 * c, r = D >= 0 ? [(-b - Math.sqrt(D)) / 2, (-b + Math.sqrt(D)) / 2] : [];
      return [["지금 화단 넓이", `${fmt(area, 2)} m²`], ["방정식", `x² − ${s.W + s.H}x + ${c} = 0`], ["두 근", r.map((v) => fmt(v, 3)).join(", ") || "없음"], ["알맞은 길의 폭", r.filter((v) => v > 0 && v < Math.min(s.W, s.H)).map((v) => `${fmt(v, 3)} m`).join(", ") || "없음", "key"]];
    },
    predict: [
      { q: "20 m × 15 m 땅에 길을 내어 화단 넓이를 234 m²로 하려면 길의 폭은 몇 m?", set: (s) => Object.assign(s, { W: 20, H: 15, A: 234, x: 0 }), reveal: (s) => (s.x = 2), answer: () => 2, why: "(20 − x)(15 − x) = 234에서 x² − 35x + 66 = 0, x = 2 또는 33이고 33은 땅보다 넓어 버립니다." },
      { q: "버려야 하는 다른 근은?", set: (s) => Object.assign(s, { W: 20, H: 15, A: 234, x: 2 }), answer: () => 33, why: "(x − 2)(x − 33) = 0의 x = 33은 세로 15 m보다 커서 길이 될 수 없습니다." },
    ],
  },
  {
    id: "m3-throw", grade: G3, unit: 4, lesson: "4.4", title: "위로 던진 공 — 이차함수로 보는 최고 높이", type: "조작", time: "12분",
    tags: ["이차함수의 활용", "최댓값", "꼭짓점"], links: ["m3-vertex", "m3-fence"],
    desc: "초속 v m로 위로 던진 공의 t초 뒤 높이는 대략 h = vt − 5t²입니다. 시간을 움직이며 공의 높이와 그래프의 점을 함께 보고, 꼭짓점에서 최고 높이 v²/20이 되며 땅에 떨어지는 시각이 v/5초임을 확인합니다.",
    obs: ["h = −5(t − v/10)² + v²/20이므로 꼭짓점은 (v/10, v²/20)입니다.", "올라가는 시간과 내려오는 시간이 같습니다(대칭축).", "던지는 빠르기가 2배면 최고 높이는 4배입니다."],
    q: "옥상(높이 20 m)에서 던지면 식과 그래프는 어떻게 바뀔까요?",
    formula: "h = vt − 5t² = −5(t − v/10)² + v²/20",
    en: { title: "A Ball Thrown Upward", desc: "Maximum height at the vertex." },
    view: { x: [-1, 13], y: [-1, 10] },
    params: [{ key: "v", label: "던지는 빠르기 v (m/s)", min: 5, max: 30, step: 1, value: 20 }, { key: "t", label: "시간 t (초)", min: 0, max: 6, step: 0.05, value: 1.2 }],
    anim: { key: "t", min: 0, max: 6, speed: 1, label: "던지기", loop: "wrap" },
    draw(s, g) {
      const T = s.v / 5, H = (s.v * s.v) / 20, t = Math.min(s.t, T), h = s.v * t - 5 * t * t, X = (x) => 1.8 + (x / 6) * 10.6, Y = (y) => (y / 45) * 9.2;
      g.seg([0.6, 0], [0.6, Y(h)], { color: "muted", w: 1, dash: "3 3" }); g.circle([0.6, Y(h)], 0.22, { fill: "a", fo: 1, color: "ink", w: 1.4 });
      g.seg([X(0), 0], [X(6.2), 0], { color: "axis", w: 1.6 }).seg([X(0), 0], [X(0), 9.6], { color: "axis", w: 1.6 });
      for (let x = 1; x <= 6; x++) g.text([X(x), 0], `${x}초`, { dy: 16, size: 11, color: "muted" }); for (let y = 10; y <= 40; y += 10) g.text([X(0), Y(y)], `${y} m`, { dx: -6, anchor: "end", dy: 4, size: 11, color: "muted" });
      g.param((u) => [X(u), Y(s.v * u - 5 * u * u)], 0, T, { color: "b", w: 3 });
      g.point([X(T / 2), Y(H)], `최고 ${fmt(H, 1)} m`, { color: "e" }).point([X(t), Y(h)], "", { color: "a" });
      g.seg([X(T / 2), 0], [X(T / 2), Y(H)], { color: "e", w: 1.2, dash: "4 4" });
    },
    metrics(s) { const T = s.v / 5, t = Math.min(s.t, T); return [["지금 높이", `${fmt(s.v * t - 5 * t * t, 2)} m`], ["최고 높이 (꼭짓점)", `${fmt((s.v * s.v) / 20, 2)} m (${fmt(s.v / 10, 2)}초)`, "key"], ["땅에 떨어지는 시각", `${fmt(T, 2)}초`]]; },
    predict: [
      { q: "초속 20 m로 던진 공의 최고 높이는 몇 m?", set: (s) => Object.assign(s, { v: 20, t: 0.5 }), reveal: (s) => (s.t = 2), answer: () => 20, why: "h = −5(t − 2)² + 20이므로 2초에 최고 20 m입니다." },
      { q: "던지는 빠르기를 2배로 하면 최고 높이는 몇 배?", set: (s) => Object.assign(s, { v: 10, t: 1 }), reveal: (s) => Object.assign(s, { v: 20, t: 2 }), answer: () => 4, why: "최고 높이 v²/20은 v의 제곱에 비례하므로 4배입니다." },
    ],
  },
  {
    id: "m3-fence", grade: G3, unit: 4, lesson: "4.4", title: "울타리 문제 — 벽을 이용한 가장 넓은 우리", type: "조작", time: "10분",
    tags: ["이차함수의 최댓값", "활용", "넓이"], links: ["m3-throw", "m3-vertex"],
    desc: "길이 P m의 울타리로 벽 한 면을 이용해 직사각형 우리를 만듭니다. 벽에 수직인 변을 x m라 하면 넓이는 x(P − 2x)이고, 이 이차함수의 꼭짓점에서 넓이가 가장 커짐을 그림과 그래프로 함께 확인합니다.",
    obs: ["벽과 평행한 변의 길이는 P − 2x입니다.", "넓이 S = x(P − 2x) = −2(x − P/4)² + P²/8입니다.", "x = P/4일 때, 곧 벽과 평행한 변이 수직인 변의 2배일 때 가장 넓습니다."],
    q: "벽 없이 울타리만으로 네 변을 만들면 가장 넓은 모양은 무엇일까요?",
    formula: "S = x(P − 2x), 최대 x = P/4, S = P²/8",
    en: { title: "The Fence Problem", desc: "Largest pen against a wall." },
    view: { x: [-0.5, 16.5], y: [-1, 10.4] },
    params: [{ key: "P", label: "울타리 길이 P (m)", min: 8, max: 40, step: 2, value: 24 }, { key: "x", label: "벽에 수직인 변 x (m)", min: 0.5, max: 19.5, step: 0.5, value: 4 }],
    anim: { key: "x", min: 0.5, max: 11.5, speed: 3, label: "x 바꾸기", loop: "bounce" },
    onChange(s) { s.x = clamp(s.x, 0.5, s.P / 2 - 0.5); },
    draw(s, g) {
      const w = s.P - 2 * s.x, k = 6.4 / Math.max(s.P / 2, 12), x0 = 0.5;
      g.seg([x0, 9.6], [x0 + 7.2, 9.6], { color: "ink", w: 6 }).text([x0 + 3.6, 9.6], "벽", { dy: -8, bold: true });
      rect(g, x0 + 0.2, 9.6 - s.x * k, w * k, s.x * k, { fill: "c", fo: 0.3, color: "a", w: 3 });
      g.text([x0 + 0.2 + (w * k) / 2, 9.6 - s.x * k], `${fmt(w)} m`, { dy: 18, bold: true, color: "a" }).text([x0 + 0.2, 9.6 - (s.x * k) / 2], `${fmt(s.x)}`, { dx: -6, anchor: "end", bold: true, color: "a" });
      const X = (x) => 8.6 + (x / (s.P / 2)) * 7.4, Y = (y) => (y / ((s.P * s.P) / 8)) * 8.4 + 0.4;
      g.seg([X(0), Y(0)], [X(s.P / 2), Y(0)], { color: "axis", w: 1.4 }).seg([X(0), Y(0)], [X(0), Y((s.P * s.P) / 8) + 0.6], { color: "axis", w: 1.4 });
      g.param((x) => [X(x), Y(x * (s.P - 2 * x))], 0, s.P / 2, { color: "b", w: 2.8 });
      g.point([X(s.P / 4), Y((s.P * s.P) / 8)], `최대 ${fmt((s.P * s.P) / 8, 1)} m²`, { color: "e", dy: -8 }).point([X(s.x), Y(s.x * w)], "", { color: "a" });
      g.text([X(s.P / 2), Y(0)], "x", { dy: 16, size: 12, color: "muted" });
    },
    metrics(s) { return [["넓이", `${fmt(s.x)} × ${fmt(s.P - 2 * s.x)} = ${fmt(s.x * (s.P - 2 * s.x), 2)} m²`], ["가장 넓을 때", `x = ${fmt(s.P / 4, 2)} m, ${fmt((s.P * s.P) / 8, 2)} m²`, "key"]]; },
    predict: [
      { q: "울타리 24 m로 벽을 이용해 만들 수 있는 가장 넓은 우리의 넓이는?", set: (s) => Object.assign(s, { P: 24, x: 2 }), reveal: (s) => (s.x = 6), answer: () => 72, why: "S = x(24 − 2x) = −2(x − 6)² + 72이므로 72 m²입니다." },
      { q: "그때 벽과 평행한 변의 길이는?", set: (s) => Object.assign(s, { P: 24, x: 6 }), answer: () => 12, why: "24 − 2 × 6 = 12 m로, 수직인 변의 2배입니다." },
    ],
  },
  {
    id: "m3-sym-points", grade: G3, unit: 4, lesson: "4.3", title: "같은 높이의 두 점 — 한가운데가 대칭축", type: "조작", time: "8분",
    tags: ["이차함수", "대칭축", "그래프"], links: ["m3-vertex", "m3-shift"],
    desc: "포물선 위에서 y좌표가 같은 두 점 (α, k), (β, k)를 찾으면 그 한가운데 x = (α + β)/2가 대칭축입니다. 가로선의 높이를 바꾸어도 두 점의 한가운데가 늘 같은 자리에 있음을 확인합니다.",
    obs: ["포물선은 축에 대하여 선대칭입니다.", "y좌표가 같은 두 점은 축에서 같은 거리만큼 떨어져 있습니다.", "그래서 축 x = (α + β)/2, 꼭짓점의 x좌표도 같습니다."],
    q: "(−1, 5)와 (5, 5)를 지나는 이차함수의 꼭짓점의 x좌표는?",
    formula: "f(α) = f(β) ⇒ 축은 x = (α + β)/2",
    en: { title: "Equal Heights, Axis Between", desc: "The axis lies midway." },
    view: { x: [-6, 6], y: [-5, 6] },
    params: [{ key: "p", label: "꼭짓점 x좌표 p", min: -3, max: 3, step: 0.5, value: 1 }, { key: "k", label: "가로선 y = k", min: -3, max: 5.5, step: 0.25, value: 3 }],
    anim: { key: "k", min: -2.5, max: 5.5, speed: 1.5, label: "가로선 움직이기", loop: "bounce" },
    draw(s, g) {
      const q = -3, f = (x) => 0.5 * (x - s.p) ** 2 + q;
      g.grid(); g.fx(f, { color: "b", w: 3 });
      g.seg([g.xr[0], s.k], [g.xr[1], s.k], { color: "a", w: 1.6, dash: "6 4" });
      g.seg([s.p, g.yr[0]], [s.p, g.yr[1]], { color: "e", w: 1.4, dash: "4 4" });
      if (s.k >= q) { const d = Math.sqrt(2 * (s.k - q)); [s.p - d, s.p + d].forEach((x, i) => g.point([x, s.k], `(${fmt(x, 2)}, ${fmt(s.k)})`, { color: "a", anchor: i ? "start" : "end", dx: i ? 12 : -12 })); }
    },
    metrics(s) { const q = -3; if (s.k < q) return [["가로선과 만나는 점", "없음"]]; const d = Math.sqrt(2 * (s.k - q)); return [["두 점의 x좌표", `${fmt(s.p - d, 3)}, ${fmt(s.p + d, 3)}`], ["한가운데", fmt(s.p, 3), "key"]]; },
    predict: [
      { q: "(−1, 5)와 (5, 5)를 지나는 포물선의 축은 x = ?", answer: () => 2, why: "(−1 + 5)/2 = 2입니다." },
      { q: "가로선을 올리면 두 점의 한가운데는?", options: O("그대로이다", "오른쪽으로 간다", "위로 간다"), set: (s) => (s.k = 0), reveal: (s) => (s.k = 5), answer: () => "a", why: "포물선이 축에 대하여 대칭이라 한가운데는 늘 축 위에 있습니다." },
    ],
  },
  {
    id: "m3-ramp", grade: G3, unit: 5, lesson: "5.4", title: "휠체어 경사로 — 1/12 기울기는 몇 도일까", type: "조작", time: "8분",
    tags: ["삼각비", "탄젠트", "실생활"], links: ["m2-road-grade"],
    desc: "휠체어 경사로는 높이 1을 오르는 데 수평 거리 12 이상이 되도록 권장됩니다. 높이와 수평 거리를 바꾸며 tan A = (높이)/(수평 거리), sin A = (높이)/(경사로 길이)로 각도와 경사로 길이를 구하고, 권장 기준을 만족하는지 확인합니다.",
    obs: ["tan A = 1/12이면 A는 약 4.8°입니다.", "같은 높이를 오르려면 각이 작을수록 경사로가 길어집니다.", "경사로 길이 = 높이 ÷ sin A입니다."],
    q: "높이 60 cm인 현관에 권장 기준을 지키는 경사로를 놓으려면 수평 거리가 최소 몇 m여야 할까요?",
    formula: "tan A = 높이/수평 거리, sin A = 높이/빗변",
    en: { title: "Wheelchair Ramps", desc: "What angle is a 1:12 slope?" },
    view: { x: [-0.6, 12.6], y: [-1.4, 5.2] },
    params: [{ key: "h", label: "높이 (cm)", min: 10, max: 100, step: 5, value: 60 }, { key: "d", label: "수평 거리 (cm)", min: 100, max: 1500, step: 20, value: 720 }],
    draw(s, g) {
      const k = 11 / Math.max(s.d, s.h * 2.2), W = s.d * k, H = s.h * k * 2.5, A = Math.atan(s.h / s.d), ok = s.h / s.d <= 1 / 12 + 1e-9;
      g.poly([[0.5, 0], [0.5 + W, 0], [0.5 + W, H]], { fill: ok ? "c" : "e", fo: 0.3, color: ok ? "c" : "e", w: 2.4 });
      g.text([0.5 + W / 2, 0], `${s.d} cm`, { dy: 18, bold: true }).text([0.5 + W, H / 2], `${s.h} cm`, { dx: 8, anchor: "start", bold: true });
      g.text([4, 4.4], ok ? "권장 기준 1/12 이하 ✓" : "너무 가파름 (1/12 초과)", { bold: true, color: ok ? "c" : "e", size: 15 });
      g.text([4, 3.6], "(높이는 2.5배 과장해서 그림)", { size: 11, color: "muted" });
      g.arc([0.5, 0], [1.5, 0], [0.5 + W, H], { color: "a", r: 40 });
    },
    metrics(s) { const A = Math.atan(s.h / s.d); return [["tan A", `${s.h}/${s.d} = ${fmt(s.h / s.d, 4)}`], ["각 A", `${fmt((A * 180) / Math.PI, 2)}°`, "key"], ["경사로 길이 (높이 ÷ sin A)", `${fmt(s.h / Math.sin(A), 1)} cm`]]; },
    predict: [
      { q: "높이 60 cm일 때 기울기 1/12을 지키려면 수평 거리는 최소 몇 cm?", set: (s) => Object.assign(s, { h: 60, d: 400 }), reveal: (s) => (s.d = 720), answer: () => 720, why: "60 × 12 = 720 cm, 곧 7.2 m입니다." },
      { q: "기울기 1/12인 경사로의 각도는 약 몇 도? (소수 첫째 자리까지)", set: (s) => Object.assign(s, { h: 50, d: 600 }), answer: () => (Math.atan(1 / 12) * 180) / Math.PI, tol: 0.1, why: "tan A = 1/12 ≈ 0.0833이므로 A ≈ 4.8°입니다." },
    ],
  },
  {
    id: "m3-shoot-angle", grade: G3, unit: 6, lesson: "6.3", title: "골대가 가장 넓게 보이는 곳 — 원주각의 활용", type: "조작", time: "12분",
    tags: ["원주각", "최대", "접원"], links: ["m3-arc-angle"],
    desc: "골대 양 끝 A, B를 바라보는 각 ∠APB가 클수록 슛하기 좋습니다. 선수가 터치라인과 평행한 직선을 따라 달릴 때 각이 가장 큰 점은 A, B를 지나면서 그 직선에 접하는 원의 접점입니다. 같은 원 위의 점에서는 원주각이 모두 같다는 성질로 설명합니다.",
    obs: ["같은 호에 대한 원주각은 크기가 같습니다.", "원 안의 점에서 보면 각이 더 크고, 원 밖에서 보면 더 작습니다.", "달리는 직선에 접하는 원의 접점에서 ∠APB가 가장 큽니다."],
    q: "골대에서 가장 먼 곳과 가장 가까운 곳 사이에서 각이 커졌다 작아지는 까닭을 설명해 봅시다.",
    formula: "같은 호 AB에 대한 원주각은 모두 같다",
    en: { title: "Best Shooting Angle", desc: "Inscribed angles and a tangent circle." },
    view: { x: [-6, 6], y: [-0.6, 9] },
    params: [{ key: "c", label: "달리는 직선의 위치 (골대 중심에서)", min: 1.5, max: 5, step: 0.1, value: 3 }, { key: "y", label: "선수의 위치 (골라인에서)", min: 0.2, max: 8.5, step: 0.05, value: 4 }, { key: "circ", label: "접하는 원 보이기", type: "check", value: true }],
    anim: { key: "y", min: 0.2, max: 8.5, speed: 1.5, label: "달리기", loop: "bounce" },
    ang(s, y) { const A = [-1.2, 0], B = [1.2, 0], P = [s.c, y], u = [A[0] - P[0], A[1] - P[1]], v = [B[0] - P[0], B[1] - P[1]]; return Math.acos((u[0] * v[0] + u[1] * v[1]) / (Math.hypot(...u) * Math.hypot(...v))); },
    draw(s, g) {
      const A = [-1.2, 0], B = [1.2, 0], P = [s.c, s.y], yb = Math.sqrt(s.c * s.c - 1.44);
      g.seg([-6, 0], [6, 0], { color: "ink", w: 2 }).seg(A, B, { color: "e", w: 6 });
      g.seg([s.c, -0.3], [s.c, 8.8], { color: "muted", w: 1.4, dash: "6 5" });
      if (s.circ) { const r = s.c; g.circle([0, yb], r, { color: "c", w: 1.6, dash: "5 4" }); g.point([s.c, yb], "최대", { color: "c", r: 4 }); }
      g.poly([A, B, P], { fill: "a", fo: 0.15, color: "a", w: 1.6 });
      g.arc(P, A, B, { color: "a", r: 26, ccw: false });
      g.point(P, "P", { color: "a" }).point(A, "A", { color: "e", dy: 18 }).point(B, "B", { color: "e", dy: 18 });
    },
    metrics(s) { const yb = Math.sqrt(s.c * s.c - 1.44); return [["∠APB", `${fmt((this.ang(s, s.y) * 180) / Math.PI, 1)}°`, "key"], ["가장 큰 각", `${fmt((this.ang(s, yb) * 180) / Math.PI, 1)}° (골라인에서 ${fmt(yb, 2)})`]]; },
    predict: [
      { q: "선수가 달리는 동안 ∠APB는 어떻게 변할까요?", options: O("커졌다가 작아진다", "계속 커진다", "계속 작아진다"), set: (s) => Object.assign(s, { y: 0.3, circ: false }), reveal: (s) => Object.assign(s, { y: 8.5, circ: true }), answer: () => "a", why: "골라인 근처에서는 A, B가 한쪽으로 몰려 작고, 멀리서는 골대가 작게 보여 작습니다. 그 사이 접점에서 가장 큽니다." },
      { q: "골대 폭 2.4, 달리는 직선이 중심에서 3만큼 떨어져 있을 때 각이 가장 큰 곳은 골라인에서 얼마나 떨어진 곳일까요? (소수 둘째 자리까지)", set: (s) => Object.assign(s, { c: 3, y: 1, circ: false }), reveal: (s) => (s.circ = true), answer: () => Math.sqrt(9 - 1.44), tol: 0.01, why: "접원의 반지름이 3이고 중심이 (0, y₀)이므로 y₀ = √(3² − 1.2²) ≈ 2.36입니다." },
    ],
  },
];
function g0(s) { return 1 / 10 ** s.z; }
