// 23차 묶음 2 — 공통수학2 (원의 방정식·집합·명제·함수) + 대수 (지수와 로그·삼각함수·수열)
import { fmt, frac, poly, clamp, piFmt } from "./hs-core.js";

const C2 = 4, AL = 5;
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const lcg = (seed) => { let x = (seed * 7919) % 2147483647 || 7; return () => ((x = (x * 16807) % 2147483647) / 2147483647); };
const sgnTerm = (k, v) => (Math.abs(k) < 1e-9 ? "" : ` ${k < 0 ? "−" : "+"} ${Math.abs(Math.abs(k) - 1) < 1e-9 && v ? "" : fmt(Math.abs(k), 2)}${v}`);
// 구간 [a, b]에서 f = 0의 근 (부호 변화 + 이분법)
function zeros(f, a, b, n = 1200) {
  const out = []; let x0 = a, y0 = f(a);
  for (let i = 1; i <= n; i++) {
    const x1 = a + ((b - a) * i) / n, y1 = f(x1);
    if (!Number.isFinite(y0) || !Number.isFinite(y1)) { x0 = x1; y0 = y1; continue; }
    if (y0 === 0) out.push(x0);
    else if (y0 * y1 < 0) { let lo = x0, hi = x1; for (let k = 0; k < 50; k++) { const m = (lo + hi) / 2; if (f(lo) * f(m) <= 0) hi = m; else lo = m; } out.push((lo + hi) / 2); }
    x0 = x1; y0 = y1;
  }
  return out.filter((x, i) => !i || Math.abs(x - out[i - 1]) > 1e-6);
}

// ───────── 함수 (일대일) ─────────
const ONE = {
  lin: { n: "y = 2x + 1", f: (x) => 2 * x + 1, ok: true },
  sq: { n: "y = x²", f: (x) => x * x, ok: false },
  sqp: { n: "y = x² (x ≥ 0)", f: (x) => x * x, from: 0, ok: true },
  cube: { n: "y = x³", f: (x) => x ** 3, ok: true },
  cub3: { n: "y = x³ − 3x", f: (x) => x ** 3 - 3 * x, ok: false },
  abs: { n: "y = |x − 1|", f: (x) => Math.abs(x - 1), ok: false },
};
// ───────── 지수·로그 방정식 ─────────
const EQ = {
  a: { n: "2ˣ = −x + 3", L: (x) => 2 ** x, R: (x) => -x + 3, Ls: "y = 2ˣ", Rs: "y = −x + 3" },
  b: { n: "log₂x = −x + 3", L: (x) => (x > 0 ? Math.log2(x) : NaN), R: (x) => -x + 3, Ls: "y = log₂x", Rs: "y = −x + 3", from: 0.001 },
  c: { n: "2ˣ = x + 2", L: (x) => 2 ** x, R: (x) => x + 2, Ls: "y = 2ˣ", Rs: "y = x + 2" },
  d: { n: "(1/2)ˣ = log₂x", L: (x) => 0.5 ** x, R: (x) => (x > 0 ? Math.log2(x) : NaN), Ls: "y = (1/2)ˣ", Rs: "y = log₂x", from: 0.001 },
};
// ───────── 귀납적 정의 ─────────
const REC = {
  a: { n: "aₙ₊₁ = ½aₙ + 2", f: (a) => a / 2 + 2, fix: "4" },
  b: { n: "aₙ₊₁ = −½aₙ + 3", f: (a) => -a / 2 + 3, fix: "2" },
  c: { n: "aₙ₊₁ = √(aₙ + 2)", f: (a) => Math.sqrt(a + 2), fix: "2" },
  d: { n: "aₙ₊₁ = 2aₙ − 1", f: (a) => 2 * a - 1, fix: "없음 (a₁ = 1일 때만 1로 일정)" },
};

export default [
  // ───────── 공통수학2 Ⅱ 원의 방정식 ─────────
  {
    id: "c2-circle-family", grade: C2, unit: 2, lesson: "Ⅱ-2", title: "두 원의 교점을 지나는 원과 직선 — k 하나로", type: "조작", time: "12분",
    tags: ["원의 방정식", "두 원의 교점", "공통현"], links: ["c2-circle-eq", "c2-circle-line"],
    desc: "두 원의 방정식을 (첫째 식) + k(둘째 식) = 0으로 묶으면, k가 무엇이든 두 원의 교점을 지나는 도형이 됩니다. k를 바꾸며 원이 교점에 꼭 붙어 움직이는 모습을 보고, k = −1일 때 두 교점을 지나는 직선(공통현)이 됨을 확인합니다.",
    obs: ["두 교점은 두 식을 모두 0으로 만들므로, 어떤 k에 대해서도 묶은 식을 만족합니다.", "k = −1이면 x², y²항이 사라져 두 교점을 지나는 직선이 됩니다.", "두 원이 만나지 않으면 k = −1일 때의 직선은 두 원 밖을 지납니다."],
    q: "두 원이 한 점에서 접할 때 k = −1로 얻은 직선은 어떤 직선일까요?",
    formula: "(x² + y² + Ax + By + C) + k(x² + y² + A′x + B′y + C′) = 0",
    en: { title: "Circles Through Two Intersection Points", desc: "One parameter k sweeps a family of circles." },
    view: { x: [-6, 7], y: [-4.5, 4.5] },
    init: () => ({ P: [3, 1] }),
    params: [
      { key: "k", label: "k", min: -3, max: 3, step: 0.1, value: 0.5 },
      { key: "r2", label: "둘째 원의 반지름", min: 1, max: 4, step: 0.1, value: 2 },
    ],
    buttons: [["line", "k = −1 (직선)"]],
    onDo(a, s) { if (a === "line") s.k = -1; },
    anim: { key: "k", min: -3, max: 3, speed: 1, loop: "bounce", label: "k 바꾸기" },
    drags: { P: { at: (s) => s.P, move: (s, p) => (s.P = [clamp(Math.round(p[0] * 2) / 2, -4, 5), clamp(Math.round(p[1] * 2) / 2, -3.5, 3.5)]), color: "c", label: "둘째 원의 중심" } },
    coef(s) { const [a, b] = s.P; return [-2 * a, -2 * b, a * a + b * b - s.r2 * s.r2]; },
    meets(s) {
      const [a, b] = s.P, d = Math.hypot(a, b), r = s.r2;
      if (d < 1e-9 || d > 3 + r || d < Math.abs(3 - r)) return [];
      const t = (9 - r * r + d * d) / (2 * d), h = Math.sqrt(Math.max(0, 9 - t * t)), ux = a / d, uy = b / d, bx = ux * t, by = uy * t;
      return h < 1e-9 ? [[bx, by]] : [[bx - uy * h, by + ux * h], [bx + uy * h, by - ux * h]];
    },
    draw(s, g) {
      const [A, B, C] = this.coef(s), k = s.k, E = [1 + k, k * A, k * B, -9 + k * C];
      g.grid();
      g.circle([0, 0], 3, { color: "b", w: 2.4 });
      g.circle(s.P, s.r2, { color: "c", w: 2.4 });
      if (Math.abs(E[0]) < 1e-9) g.lineABC(E[1], E[2], E[3], { color: "a", w: 3.2 });
      else { const cx = -E[1] / (2 * E[0]), cy = -E[2] / (2 * E[0]), r2 = cx * cx + cy * cy - E[3] / E[0]; if (r2 > 1e-6) { g.circle([cx, cy], Math.sqrt(r2), { color: "a", w: 3.2 }); g.point([cx, cy], "", { color: "a", r: 3.5 }); } }
      this.meets(s).forEach((p) => g.point(p, "", { color: "ink", r: 6 }));
      g.point([0, 0], "", { color: "b", r: 3.5 });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], "파랑: x² + y² = 9", { anchor: "start", bold: true, color: "b" }).text([g.xr[0] + 0.3, g.yr[1] - 1.25], "초록: 둘째 원", { anchor: "start", bold: true, color: "c" }).text([g.xr[0] + 0.3, g.yr[1] - 2], `주황: k = ${fmt(k)}일 때의 도형`, { anchor: "start", bold: true, color: "a" });
    },
    metrics(s) {
      const [A, B, C] = this.coef(s), k = s.k, E = [1 + k, k * A, k * B, -9 + k * C], M = this.meets(s);
      const second = `x² + y²${sgnTerm(A, "x")}${sgnTerm(B, "y")}${sgnTerm(C, "")}`;
      const shape = Math.abs(E[0]) < 1e-9 ? `직선 ${poly([[E[1], "x"], [E[2], "y"]], E[3])} = 0` : "원";
      return [["둘째 원", `${second} = 0`], ["두 원의 교점", `${M.length}개`], [`k = ${fmt(k)}일 때`, shape, "key"]];
    },
    predict: [
      { q: "k = −1이면 묶은 식은 어떤 도형이 될까요?", options: O("두 교점을 지나는 직선", "두 교점을 지나는 원", "아무 도형도 아니다"), set: (s) => Object.assign(s, { P: [3, 1], r2: 2, k: 0.5 }), reveal: (s) => (s.k = -1), answer: () => "a", why: "x² + y²의 계수가 1 + k = 0이 되어 일차식만 남습니다. 두 교점을 모두 지나므로 공통현을 품은 직선입니다." },
      { q: "x² + y² = 9와 (x − 3)² + (y − 1)² = 4의 두 교점을 지나는 직선의 기울기는?", set: (s) => Object.assign(s, { P: [3, 1], r2: 2, k: 0.5 }), reveal: (s) => (s.k = -1), answer: () => -3, why: "두 식을 빼면 6x + 2y − 15 = 0, 곧 y = −3x + 15/2입니다." },
    ],
  },
  // ───────── 공통수학2 Ⅲ 집합 ─────────
  {
    id: "c2-incl-excl", grade: C2, unit: 3, lesson: "Ⅲ-2", title: "세 집합의 포함과 배제 — 몇 번 세었는지 칸마다 세기", type: "조작", time: "12분",
    tags: ["합집합의 원소의 개수", "벤 다이어그램", "포함과 배제"], links: ["cm2-venn"],
    desc: "수학·과학·코딩 동아리 학생 수를 세 원의 벤 다이어그램에 나누어 넣고, n(A) + n(B) + n(C)부터 시작해 두 집합의 교집합을 빼고 세 집합의 교집합을 더할 때 칸마다 몇 번 세어지는지 추적합니다. 마지막에 모든 칸이 정확히 한 번씩 세어짐을 확인합니다.",
    obs: ["세 집합을 그냥 더하면 두 집합에 겹친 칸은 2번, 세 집합에 겹친 칸은 3번 세어집니다.", "두 집합의 교집합 셋을 빼면 가운데 칸은 0번이 되어 버립니다.", "그래서 세 집합의 교집합을 한 번 더해 주어야 합니다."],
    q: "네 집합이라면 공식이 어떻게 이어질지 규칙을 짐작해 봅시다.",
    formula: "n(A ∪ B ∪ C) = n(A) + n(B) + n(C) − n(A ∩ B) − n(B ∩ C) − n(C ∩ A) + n(A ∩ B ∩ C)",
    en: { title: "Inclusion–Exclusion for Three Sets", desc: "Track how many times each region is counted." },
    view: { x: [-4.6, 4.6], y: [-3.6, 3.4] },
    params: [
      { key: "seed", label: "자료 바꾸기", min: 1, max: 20, step: 1, value: 3 },
      { key: "st", label: "공식 단계", type: "seg", value: 1, options: [[0, "칸 보기"], [1, "① 세 집합 더하기"], [2, "② 교집합 셋 빼기"], [3, "③ 가운데 더하기"]] },
    ],
    reg(s) { const r = lcg(s.seed), v = () => 1 + Math.floor(r() * 9); return { a: v(), b: v(), c: v(), ab: v(), bc: v(), ca: v(), abc: 1 + Math.floor(r() * 4) }; },
    draw(s, g) {
      const R = this.reg(s), CC = [[-1.15, 0.55, "a", "A 수학"], [1.15, 0.55, "b", "B 과학"], [0, -1.35, "c", "C 코딩"]];
      CC.forEach(([x, y, c, n], i) => { g.circle([x, y], 2, { fill: c, fo: 0.1, color: c, w: 2.4 }); g.text([x + [-1.6, 1.6, 0][i], y + [1.75, 1.75, -2.25][i]], n, { bold: true, color: c }); });
      const T = { 0: [0, 0, 0], 1: [1, 2, 3], 2: [1, 1, 0], 3: [1, 1, 1] }[s.st];
      const pos = [["a", -2.05, 1.05, 0], ["b", 2.05, 1.05, 0], ["c", 0, -2.45, 0], ["ab", 0, 1.55, 1], ["ca", -1.2, -0.65, 1], ["bc", 1.2, -0.65, 1], ["abc", 0, 0.05, 2]];
      pos.forEach(([k, x, y, t]) => {
        g.text([x, y], String(R[k]), { dy: 2, bold: true, size: 18 });
        if (s.st) { const n = T[t]; g.text([x, y], `×${n}`, { dy: 20, bold: true, size: 13, color: n === 1 ? "c" : n === 0 ? "e" : "a" }); }
      });
    },
    metrics(s) {
      const R = this.reg(s), nA = R.a + R.ab + R.ca + R.abc, nB = R.b + R.ab + R.bc + R.abc, nC = R.c + R.bc + R.ca + R.abc, nAB = R.ab + R.abc, nBC = R.bc + R.abc, nCA = R.ca + R.abc, U = Object.values(R).reduce((x, y) => x + y, 0);
      return [["n(A), n(B), n(C)", `${nA}, ${nB}, ${nC}`], ["n(A∩B), n(B∩C), n(C∩A)", `${nAB}, ${nBC}, ${nCA}`], ["n(A∩B∩C)", String(R.abc)], ["공식으로 구한 n(A∪B∪C)", `${nA + nB + nC} − ${nAB + nBC + nCA} + ${R.abc} = ${nA + nB + nC - nAB - nBC - nCA + R.abc}`, "key"], ["칸을 직접 더한 값", String(U)]];
    },
    predict: [
      { q: "세 동아리의 인원이 각각 20명, 15명, 12명이고, 두 동아리씩 겹친 인원이 7명, 5명, 4명, 세 동아리에 모두 든 인원이 2명입니다. 동아리에 든 학생은 모두 몇 명일까요?", answer: () => 33, why: "20 + 15 + 12 − (7 + 5 + 4) + 2 = 47 − 16 + 2 = 33입니다." },
      { q: "② 교집합 셋을 뺀 단계에서 가운데 칸(A ∩ B ∩ C)은 몇 번 세어진 상태일까요?", set: (s) => (s.st = 1), reveal: (s) => (s.st = 2), answer: () => 0, why: "처음에 3번 더해지고 교집합 셋에서 3번 빠져 0번이 됩니다. 그래서 마지막에 한 번 더해 줍니다." },
    ],
  },
  // ───────── 공통수학2 Ⅳ 명제 ─────────
  {
    id: "c2-am-gm", grade: C2, unit: 4, lesson: "Ⅳ-3", title: "산술평균 ≥ 기하평균 — 반원 안의 두 선분", type: "조작", time: "10분",
    tags: ["절대부등식", "산술평균", "기하평균"], links: ["cm2-truth-set"],
    desc: "지름이 a + b인 반원에서 반지름 (a + b)/2와, 지름을 a와 b로 나눈 점에서 세운 수선의 길이 √(ab)를 비교합니다. 수선은 반지름보다 길 수 없으므로 (a + b)/2 ≥ √(ab)이고, 등호는 수선이 반지름과 겹치는 a = b일 때만 성립합니다.",
    obs: ["직각삼각형의 닮음으로 수선의 길이는 √(ab)입니다.", "수선은 원 안의 선분이라 반지름 (a + b)/2보다 길 수 없습니다.", "a = b일 때만 수선이 반지름이 되어 등호가 성립합니다."],
    q: "넓이가 16인 직사각형 중 둘레가 가장 짧은 것은 무엇일까요? 이 부등식으로 설명해 봅시다.",
    formula: "a > 0, b > 0일 때 (a + b)/2 ≥ √(ab) (등호는 a = b)",
    en: { title: "AM–GM in a Semicircle", desc: "Compare a radius with a half-chord." },
    view: { x: [-0.5, 8.5], y: [-1.1, 4.8] },
    params: [
      { key: "a", label: "a", min: 0.2, max: 4, step: 0.1, value: 3 },
      { key: "b", label: "b", min: 0.2, max: 4, step: 0.1, value: 1.2 },
    ],
    anim: { key: "a", min: 0.2, max: 4, speed: 0.8, loop: "bounce", label: "a 바꾸기" },
    draw(s, g) {
      const R = (s.a + s.b) / 2, M = [R, 0], P = [s.a, 0], Q = [s.a, Math.sqrt(s.a * s.b)];
      g.param((t) => [R + R * Math.cos(t), R * Math.sin(t)], 0, Math.PI, { color: "ink", w: 2.6 });
      g.seg([0, 0], [s.a + s.b, 0], { color: "ink", w: 2.4 });
      g.seg([0, 0], Q, { color: "muted", w: 1.4, dash: "4 4" }).seg([s.a + s.b, 0], Q, { color: "muted", w: 1.4, dash: "4 4" });
      g.text([s.a / 2, 0], `a = ${fmt(s.a)}`, { dy: 20, bold: true, color: "b" }).text([s.a + s.b / 2, 0], `b = ${fmt(s.b)}`, { dy: 20, bold: true, color: "d" });
      g.seg(M, [R, R], { color: "a", w: 3.4 }).text([R, R * 0.55], "(a + b)/2", { dx: -10, anchor: "end", bold: true, color: "a" });
      g.seg(P, Q, { color: "c", w: 3.4 }).text([s.a, Q[1] * 0.45], "√(ab)", { dx: 10, anchor: "start", bold: true, color: "c" });
      g.right(P, Q, [s.a + s.b, 0], { color: "c" });
      g.point(M, "", { color: "a", r: 4 }).point(Q, "", { color: "c" });
      if (Math.abs(s.a - s.b) < 0.05) g.text([R, R], "a = b: 두 선분이 겹쳐요", { dy: -12, bold: true, color: "e" });
    },
    metrics(s) { const A = (s.a + s.b) / 2, G = Math.sqrt(s.a * s.b); return [["산술평균 (a + b)/2", fmt(A, 3)], ["기하평균 √(ab)", fmt(G, 3)], ["차", fmt(A - G, 4), "key"]]; },
    predict: [
      { q: "a + b = 6일 때 √(ab)의 최댓값은?", set: (s) => Object.assign(s, { a: 5, b: 1 }), reveal: (s) => Object.assign(s, { a: 3, b: 3 }), answer: () => 3, why: "√(ab) ≤ (a + b)/2 = 3이고, a = b = 3일 때 등호가 성립합니다." },
      { q: "(a + b)/2 = √(ab)가 되는 것은 언제일까요?", options: O("a = b일 때", "a = 2b일 때", "언제나"), set: (s) => Object.assign(s, { a: 3.4, b: 1 }), reveal: (s) => Object.assign(s, { a: 2.2, b: 2.2 }), answer: () => "a", why: "수선이 반지름과 겹치려면 수선의 발이 원의 중심이어야 하므로 a = b입니다." },
    ],
  },
  // ───────── 공통수학2 Ⅴ 함수 ─────────
  {
    id: "c2-one-to-one", grade: C2, unit: 5, lesson: "Ⅴ-1", title: "일대일함수 판정 — 가로선을 대 보기", type: "조작", time: "10분",
    tags: ["일대일함수", "그래프", "역함수"], links: ["cm2-inverse", "cm2-composition"],
    desc: "가로선 y = k를 위아래로 움직이며 그래프와 몇 번 만나는지 셉니다. 어떤 k에서도 두 번 이상 만나지 않으면 일대일함수이고, 그래야 역함수를 생각할 수 있습니다. 정의역을 제한하면 일대일함수가 되는 경우도 확인합니다.",
    obs: ["x₁ ≠ x₂이면 f(x₁) ≠ f(x₂)인 함수가 일대일함수입니다.", "가로선이 그래프와 두 번 만나면 서로 다른 x가 같은 y값을 가집니다.", "y = x²도 x ≥ 0으로 제한하면 일대일함수가 됩니다."],
    q: "세로선을 대 보는 판정과 가로선을 대 보는 판정은 각각 무엇을 알려 줄까요?",
    formula: "일대일함수: x₁ ≠ x₂ ⇒ f(x₁) ≠ f(x₂)",
    en: { title: "One-to-One Functions", desc: "The horizontal line test." },
    view: { x: [-4, 4], y: [-4, 5] },
    params: [
      { key: "fn", label: "함수", type: "select", value: "sq", options: Object.entries(ONE).map(([k, v]) => [k, v.n]) },
      { key: "k", label: "가로선 y = k", min: -3.5, max: 4.5, step: 0.1, value: 2 },
    ],
    anim: { key: "k", min: -3.5, max: 4.5, speed: 1.2, loop: "bounce", label: "가로선 움직이기" },
    hits(s) { const F = ONE[s.fn]; return zeros((x) => F.f(x) - s.k, F.from ?? -4.2, 4.2, 2000).concat(Math.abs(F.f(F.from ?? -99) - s.k) < 1e-9 ? [F.from] : []).filter((x, i, a) => a.findIndex((y) => Math.abs(y - x) < 1e-6) === i); },
    draw(s, g) {
      const F = ONE[s.fn], H = this.hits(s);
      g.grid();
      g.fx(F.f, { color: "b", w: 3, from: F.from ?? g.xr[0] });
      if (F.from != null) g.point([F.from, F.f(F.from)], "", { color: "b", r: 4.5 });
      g.seg([g.xr[0], s.k], [g.xr[1], s.k], { color: H.length > 1 ? "e" : "a", w: 2.4, dash: "8 5" });
      H.forEach((x) => g.point([x, s.k], "", { color: H.length > 1 ? "e" : "a" }));
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], F.n, { anchor: "start", bold: true, color: "b" });
    },
    metrics(s) { const F = ONE[s.fn], H = this.hits(s); return [[`y = ${fmt(s.k)}과 만나는 점`, `${H.length}개`], ["일대일함수인가?", F.ok ? "예 — 어떤 가로선도 한 번 이하로 만남" : "아니요 — 두 번 만나는 가로선이 있음", "key"]]; },
    predict: [
      { q: "y = x³ − 3x는 일대일함수일까요?", options: O("아니다", "그렇다"), set: (s) => Object.assign(s, { fn: "cub3", k: 3.5 }), reveal: (s) => (s.k = 0), answer: () => "a", why: "y = 0인 가로선이 x = −√3, 0, √3에서 세 번 만납니다." },
      { q: "y = x²의 정의역을 x ≥ 0으로 제한하면 일대일함수일까요?", options: O("그렇다", "아니다"), set: (s) => Object.assign(s, { fn: "sq", k: 2 }), reveal: (s) => (s.fn = "sqp"), answer: () => "a", why: "오른쪽 절반만 남아 어떤 가로선도 한 번 이하로 만납니다." },
    ],
  },

  // ───────── 대수 Ⅰ 지수와 로그 ─────────
  {
    id: "alg-nth-root", grade: AL, unit: 1, lesson: "Ⅰ-1", title: "거듭제곱근 — y = xⁿ과 y = a는 몇 번 만날까", type: "조작", time: "10분",
    tags: ["거듭제곱근", "n제곱근", "그래프"], links: ["alg-exp-graph"],
    desc: "a의 n제곱근 중 실수인 것은 방정식 xⁿ = a의 실근, 곧 y = xⁿ과 y = a의 교점의 x좌표입니다. n이 짝수일 때와 홀수일 때, a가 양수·0·음수일 때 교점의 개수가 어떻게 달라지는지 확인합니다.",
    obs: ["n이 짝수이면 a > 0일 때 실수인 n제곱근이 ±ⁿ√a로 2개, a < 0이면 없습니다.", "n이 홀수이면 a의 부호와 관계없이 실수인 n제곱근이 하나뿐입니다.", "ⁿ√a는 실수인 n제곱근 가운데 양수(홀수일 때는 그 하나)를 뜻합니다."],
    q: "−8의 세제곱근은 복소수 범위에서 모두 몇 개일까요? 그중 실수는 몇 개일까요?",
    formula: "xⁿ = a의 실근 = y = xⁿ과 y = a의 교점",
    en: { title: "Real nth Roots", desc: "Intersect y = xⁿ with y = a." },
    view: { x: [-3.2, 3.2], y: [-9.5, 9.5] },
    params: [
      { key: "n", label: "n", min: 2, max: 6, step: 1, value: 3 },
      { key: "a", label: "a", min: -8, max: 8, step: 0.5, value: -8 },
    ],
    anim: { key: "a", min: -8, max: 8, speed: 4, loop: "bounce", label: "a 바꾸기" },
    roots(s) { if (s.n % 2) return [Math.sign(s.a) * Math.abs(s.a) ** (1 / s.n)]; if (s.a > 0) { const r = s.a ** (1 / s.n); return [-r, r]; } return s.a === 0 ? [0] : []; },
    draw(s, g) {
      g.grid({ step: 1, every: 2 });
      g.fx((x) => x ** s.n, { color: "b", w: 3 });
      g.seg([g.xr[0], s.a], [g.xr[1], s.a], { color: "a", w: 2.4, dash: "8 5" });
      this.roots(s).forEach((x) => { g.point([x, s.a], `x = ${fmt(x, 3)}`, { color: "c", dy: s.a > 0 ? -12 : 22 }); g.seg([x, 0], [x, s.a], { color: "c", w: 1.2, dash: "3 4" }); });
      g.text([g.xr[0] + 0.2, g.yr[1] - 1], `파랑: y = x${"⁰¹²³⁴⁵⁶"[s.n]}   주황: y = ${fmt(s.a)}`, { anchor: "start", bold: true });
    },
    metrics(s) { const R = this.roots(s); return [[`${fmt(s.a)}의 ${s.n}제곱근 중 실수`, R.length ? R.map((x) => fmt(x, 3)).join(", ") : "없음", "key"], ["개수", `${R.length}개`], ["n의 종류", s.n % 2 ? "홀수" : "짝수"]]; },
    predict: [
      { q: "−8의 세제곱근 중 실수인 것은?", set: (s) => Object.assign(s, { n: 3, a: 8 }), reveal: (s) => (s.a = -8), answer: () => -2, why: "(−2)³ = −8이고, n이 홀수라 실수인 세제곱근은 하나뿐입니다." },
      { q: "16의 네제곱근 중 실수인 것은 몇 개?", set: (s) => Object.assign(s, { n: 4, a: -4 }), reveal: (s) => (s.a = 8), answer: () => 2, why: "x⁴ = 16의 실근은 ±2의 2개입니다." },
    ],
  },
  {
    id: "alg-slide-rule", grade: AL, unit: 1, lesson: "Ⅰ-2", title: "로그 계산자 — 곱셈이 길이의 덧셈이 되는 자", type: "조작", time: "12분",
    tags: ["로그", "로그의 성질", "계산자"], links: ["alg-digits", "alg-exp-log-inverse"],
    desc: "눈금을 log₁₀x의 길이에 새긴 두 자를 겹쳐 밀면, log a + log b = log ab이므로 길이를 더하는 것만으로 곱셈이 됩니다. 계산기가 없던 시절 공학자들이 쓰던 계산자를 직접 밀어 봅니다.",
    obs: ["눈금 1에서 x까지의 길이가 log x에 비례합니다.", "윗자의 1을 아랫자의 a에 맞추면, 윗자 b 아래에 ab가 있습니다.", "ab가 10을 넘으면 윗자의 10을 a에 맞추고 읽은 값에 10을 곱합니다."],
    q: "계산자로 나눗셈 a ÷ b는 어떻게 할 수 있을까요?",
    formula: "log ab = log a + log b",
    en: { title: "The Slide Rule", desc: "Multiplication becomes adding lengths." },
    view: BOX,
    params: [
      { key: "a", label: "a (아랫자에서 맞출 곳)", min: 1, max: 10, step: 0.1, value: 2 },
      { key: "b", label: "b (윗자에서 읽을 곳)", min: 1, max: 10, step: 0.1, value: 3 },
    ],
    anim: { key: "a", min: 1, max: 10, speed: 1.5, loop: "bounce", label: "윗자 밀기" },
    draw(s, g) {
      const L = 12, X0 = 2, pos = (v) => X0 + L * Math.log10(v), over = s.a * s.b > 10.0001, sh = L * (Math.log10(s.a) - (over ? 1 : 0)), Yb = 3.4, Yt = 5.3;
      const scale = (y, dx, up, col) => {
        g.poly([[X0 + dx - 0.3, y], [X0 + dx + L + 0.3, y], [X0 + dx + L + 0.3, y + (up ? 1.3 : -1.3)], [X0 + dx - 0.3, y + (up ? 1.3 : -1.3)]], { fill: col, fo: 0.12, color: col, w: 1.4 });
        for (let v = 1; v <= 10.001; v += 0.5) { const x = pos(v) + dx, big = Math.abs(v - Math.round(v)) < 1e-9; g.seg([x, y], [x, y + (up ? 1 : -1) * (big ? 0.55 : 0.3)], { color: "ink", w: big ? 1.6 : 1 }); if (big) g.text([x, y + (up ? 0.85 : -0.85)], String(Math.round(v)), { dy: 5, size: 13, bold: true }); }
      };
      scale(Yt, sh, true, "b"); scale(Yb, 0, false, "c");
      g.text([X0 - 0.5, Yt + 0.65], "윗자", { anchor: "end", dy: 5, size: 12, color: "b", bold: true }).text([X0 - 0.5, Yb - 0.65], "아랫자", { anchor: "end", dy: 5, size: 12, color: "c", bold: true });
      const xa = pos(s.a), xr = pos(s.b) + sh;
      g.seg([xa, 1.4], [xa, 7.2], { color: "a", w: 1.6, dash: "5 4" }).seg([xr, 1.4], [xr, 7.2], { color: "e", w: 2, dash: "5 4" });
      g.vec([X0, 8.2], [xa, 8.2], { color: "c", w: 2.4 }).text([(X0 + xa) / 2, 8.2], "log a", { dy: -8, bold: true, color: "c", size: 13 });
      g.vec([xa, 8.2], [xr, 8.2], { color: "b", w: 2.4 }).text([(xa + xr) / 2, 8.2], over ? "log b − 1" : "log b", { dy: -8, bold: true, color: "b", size: 13 });
      const read = over ? (s.a * s.b) / 10 : s.a * s.b;
      g.text([xr, 1.1], `읽은 값 ${fmt(read, 2)}${over ? " → ×10" : ""}`, { bold: true, color: "e" });
      g.text([1, 10.2], `${fmt(s.a)} × ${fmt(s.b)} = ${fmt(s.a * s.b, 2)}`, { anchor: "start", bold: true, size: 18 });
    },
    metrics(s) { const la = Math.log10(s.a), lb = Math.log10(s.b); return [["log a + log b", `${fmt(la, 4)} + ${fmt(lb, 4)} = ${fmt(la + lb, 4)}`], ["log ab", fmt(Math.log10(s.a * s.b), 4)], ["ab", fmt(s.a * s.b, 3), "key"]]; },
    predict: [
      { q: "윗자의 1을 아랫자의 2에 맞추었을 때, 윗자 4 아래에 있는 아랫자의 눈금은?", set: (s) => Object.assign(s, { a: 2, b: 1 }), reveal: (s) => (s.b = 4), answer: () => 8, why: "log 2 + log 4 = log 8이므로 8을 가리킵니다." },
      { q: "log₁₀2 + log₁₀5의 값은?", set: (s) => Object.assign(s, { a: 2, b: 1 }), reveal: (s) => (s.b = 5), answer: () => 1, why: "log 2 + log 5 = log 10 = 1입니다. 계산자에서 끝 눈금 10에 닿습니다." },
    ],
  },
  {
    id: "alg-digits", grade: AL, unit: 1, lesson: "Ⅰ-3", title: "상용로그로 자릿수 세기 — 2ⁿ은 몇 자리 수일까", type: "조작", time: "10분",
    tags: ["상용로그", "자릿수", "지표와 가수"], links: ["alg-slide-rule"],
    desc: "N = 2ⁿ의 상용로그 n·log 2가 수직선 위 어느 칸 [k, k + 1)에 놓이는지 보면, N이 k + 1자리 수임을 알 수 있습니다. 실제로 계산한 자릿수와 맞는지, 소수 부분으로 맨 앞자리 숫자까지 알 수 있는지 확인합니다.",
    obs: ["k ≤ log N < k + 1이면 10ᵏ ≤ N < 10ᵏ⁺¹이므로 N은 k + 1자리 수입니다.", "log N의 정수 부분이 자릿수를, 소수 부분이 숫자의 배열을 정합니다.", "log 2 ≈ 0.3010이므로 2¹⁰ ≈ 10³입니다."],
    q: "2¹⁰⁰의 맨 앞자리 숫자를 상용로그만으로 구해 봅시다.",
    formula: "k ≤ log N < k + 1 ⇔ N은 (k + 1)자리 수",
    en: { title: "Counting Digits with Common Logarithms", desc: "How many digits does 2ⁿ have?" },
    view: (s) => { const v = s.n * Math.log10(s.base), k = Math.floor(v); return { x: [k - 3.2, k + 4.2], y: [-2.6, 2.6] }; },
    params: [
      { key: "base", label: "밑", type: "seg", value: 2, options: [[2, "2ⁿ"], [3, "3ⁿ"], [7, "7ⁿ"]] },
      { key: "n", label: "지수 n", min: 1, max: 200, step: 1, value: 100 },
    ],
    anim: { key: "n", min: 1, max: 200, speed: 12, label: "n 늘리기" },
    draw(s, g) {
      const v = s.n * Math.log10(s.base), k = Math.floor(v);
      for (let j = k - 3; j <= k + 3; j++) {
        const on = j === k;
        g.poly([[j, -0.35], [j + 1, -0.35], [j + 1, 0.35], [j, 0.35]], { fill: on ? "a" : "b", fo: on ? 0.35 : 0.08, color: on ? "a" : "grid", w: on ? 2 : 1 });
        g.text([j, -0.35], String(j), { dy: 20, size: 13, color: "muted" });
        g.text([j + 0.5, 0.35], `${j + 1}자리`, { dy: -10, size: 12, bold: on, color: on ? "a" : "muted" });
      }
      g.point([v, 0], "", { color: "e", r: 7 });
      g.text([v, 0], `log N = ${fmt(v, 4)}`, { dy: -48, bold: true, color: "e" });
      g.seg([v, 0.4], [v, 1.1], { color: "e", w: 1.4 });
      g.text([k - 3, 2], `N = ${s.base}^${s.n}`, { anchor: "start", bold: true, size: 16 });
    },
    metrics(s) {
      const v = s.n * Math.log10(s.base), k = Math.floor(v), big = (BigInt(s.base) ** BigInt(s.n)).toString();
      return [[`log ${s.base}^${s.n} = ${s.n} × log ${s.base}`, fmt(v, 4)], ["정수 부분 → 자릿수", `${k} → ${k + 1}자리`, "key"], ["실제로 계산한 자릿수", `${big.length}자리 (${big.slice(0, 6)}${big.length > 6 ? "…" : ""})`], ["소수 부분 → 맨 앞자리", `10^${fmt(v - k, 4)} ≈ ${fmt(10 ** (v - k), 3)} → ${Math.floor(10 ** (v - k))}`]];
    },
    predict: [
      { q: "log 2 = 0.3010일 때 2¹⁰⁰은 몇 자리 수?", set: (s) => Object.assign(s, { base: 2, n: 10 }), reveal: (s) => (s.n = 100), answer: () => 31, why: "log 2¹⁰⁰ = 30.10이므로 정수 부분 30, 곧 31자리 수입니다." },
      { q: "log 3 = 0.4771일 때 3²⁰은 몇 자리 수?", set: (s) => Object.assign(s, { base: 3, n: 1 }), reveal: (s) => (s.n = 20), answer: () => 10, why: "20 × 0.4771 = 9.542이므로 10자리 수입니다." },
    ],
  },

  // ───────── 대수 Ⅱ 지수함수와 로그함수 ─────────
  {
    id: "alg-explog-eq", grade: AL, unit: 2, lesson: "Ⅱ-3", title: "지수·로그 방정식과 부등식 — 두 그래프의 교점으로", type: "조작", time: "12분",
    tags: ["지수방정식", "로그방정식", "그래프"], links: ["alg-exp-graph", "alg-exp-log-inverse"],
    desc: "식을 바꾸어 풀기 어려운 지수·로그 방정식도 양변을 각각 함수로 그리면 교점의 x좌표가 해입니다. 해의 개수를 그래프로 세고, 부등식은 한 그래프가 다른 그래프보다 위에 있는 x의 범위로 읽습니다.",
    obs: ["방정식 f(x) = g(x)의 해는 y = f(x)와 y = g(x)의 교점의 x좌표입니다.", "증가하는 그래프와 감소하는 그래프는 많아야 한 번 만납니다.", "부등식 f(x) > g(x)의 해는 y = f(x)가 위에 있는 구간입니다."],
    q: "2ˣ = x + 2의 두 해 가운데 정수가 아닌 해는 대략 얼마일까요?",
    formula: "f(x) = g(x)의 실근 = 두 그래프의 교점의 x좌표",
    en: { title: "Exponential and Logarithmic Equations", desc: "Solve by intersecting graphs." },
    view: { x: [-3.5, 5.5], y: [-2.5, 6] },
    params: [
      { key: "eq", label: "방정식", type: "select", value: "a", options: Object.entries(EQ).map(([k, v]) => [k, v.n]) },
      { key: "ineq", label: "왼쪽 > 오른쪽인 범위 칠하기", type: "check", value: false },
    ],
    sols(s) { const E = EQ[s.eq]; return zeros((x) => E.L(x) - E.R(x), E.from ?? -3.5, 5.5, 3000); },
    draw(s, g) {
      const E = EQ[s.eq], X = this.sols(s);
      g.grid();
      if (s.ineq) { const n = 300, a = E.from ?? g.xr[0]; for (let i = 0; i < n; i++) { const x0 = a + ((g.xr[1] - a) * i) / n, x1 = a + ((g.xr[1] - a) * (i + 1)) / n, xm = (x0 + x1) / 2; if (E.L(xm) > E.R(xm)) g.poly([[x0, -0.15], [x1, -0.15], [x1, 0.15], [x0, 0.15]], { fill: "e", fo: 0.6, stroke: false }); } }
      g.fx(E.L, { color: "b", w: 3, from: E.from ?? g.xr[0] });
      g.fx(E.R, { color: "a", w: 3, from: E.from ?? g.xr[0] });
      X.forEach((x) => { g.point([x, E.L(x)], `x ≈ ${fmt(x, 3)}`, { color: "c" }); g.seg([x, 0], [x, E.L(x)], { color: "c", w: 1.2, dash: "3 4" }); });
      g.text([g.xr[0] + 0.2, g.yr[1] - 0.5], `파랑: ${E.Ls}`, { anchor: "start", bold: true, color: "b" }).text([g.xr[0] + 0.2, g.yr[1] - 1.2], `주황: ${E.Rs}`, { anchor: "start", bold: true, color: "a" });
    },
    metrics(s) {
      const E = EQ[s.eq], X = this.sols(s), a = E.from ?? -3.5;
      let iv = [], st = null; for (let i = 0; i <= 900; i++) { const x = a + ((5.5 - a) * i) / 900, on = E.L(x) > E.R(x); if (on && st == null) st = x; if ((!on || i === 900) && st != null) { iv.push([st, on ? x : x]); st = null; } }
      const ivs = iv.map(([p, q]) => `${p <= a + 0.01 ? (E.from ? "0" : "") : fmt(p, 2)}${p <= a + 0.01 && !E.from ? "x" : " < x"}${q >= 5.49 ? "" : ` < ${fmt(q, 2)}`}`).join(" 또는 ");
      return [["방정식", E.n], ["실근", X.length ? X.map((x) => fmt(x, 3)).join(", ") : "없음", "key"], ["실근의 개수", `${X.length}개`], ["왼쪽 > 오른쪽 (보이는 범위)", ivs || "없음"]];
    },
    predict: [
      { q: "2ˣ = −x + 3의 해는?", set: (s) => Object.assign(s, { eq: "a", ineq: false }), answer: () => 1, why: "x = 1이면 2¹ = 2, −1 + 3 = 2로 같습니다. 증가·감소 그래프라 교점은 하나뿐입니다." },
      { q: "2ˣ = x + 2의 실근은 몇 개?", set: (s) => Object.assign(s, { eq: "c" }), answer: () => 2, why: "직선 y = x + 2가 y = 2ˣ과 x = 2와 x ≈ −1.69에서 두 번 만납니다." },
    ],
  },

  // ───────── 대수 Ⅲ 삼각함수 ─────────
  {
    id: "alg-tan-graph", grade: AL, unit: 3, lesson: "Ⅲ-3", title: "탄젠트 그래프 — 단위원의 접선이 풀려 나온다", type: "조작", time: "12분",
    tags: ["탄젠트함수", "주기", "점근선"], links: ["alg-unit-circle", "alg-graph-wrap"],
    desc: "단위원의 x = 1에 접선을 긋고, 각 θ의 동경을 늘인 직선이 접선과 만나는 높이가 tan θ임을 봅니다. θ를 돌리며 그 높이를 오른쪽 그래프로 옮겨 y = tan θ의 모양, 주기 π, 점근선 θ = π/2 + nπ를 확인합니다.",
    obs: ["동경이 접선 x = 1과 만나는 점의 y좌표가 tan θ입니다.", "θ가 π/2에 가까워지면 동경이 접선과 평행해져 tan θ가 한없이 커집니다.", "θ와 θ + π의 동경은 같은 직선 위에 있어 tan(θ + π) = tan θ, 주기는 π입니다."],
    q: "y = tan θ의 그래프가 원점에 대하여 대칭인 까닭을 단위원으로 설명해 봅시다.",
    formula: "tan θ = sin θ / cos θ, tan(θ + π) = tan θ",
    en: { title: "The Tangent Graph", desc: "Unroll the tangent line of the unit circle." },
    view: { x: [-3.4, 7], y: [-3.4, 3.4] },
    params: [{ key: "t", label: "각 θ (라디안)", min: 0, max: 6.28, step: 0.01, value: 0.9, show: (v) => `${fmt(v, 2)} (${fmt((v * 180) / Math.PI, 0)}°)` }],
    anim: { key: "t", min: 0, max: 6.28, speed: 0.6, loop: "wrap", label: "동경 돌리기" },
    draw(s, g) {
      const C = [-2.2, 0], th = s.t, c = Math.cos(th), sn = Math.sin(th), T = Math.tan(th), ok = Math.abs(c) > 0.03;
      g.seg([g.xr[0], 0], [g.xr[1], 0], { color: "axis", w: 1.4 }).seg([0, g.yr[0]], [0, g.yr[1]], { color: "axis", w: 1.4 });
      g.circle(C, 1, { color: "muted", w: 1.6 });
      g.seg([C[0] + 1, g.yr[0]], [C[0] + 1, g.yr[1]], { color: "b", w: 1.6, dash: "6 4" });
      g.vec(C, [C[0] + c, C[1] + sn], { color: "ink", w: 2.4 });
      if (ok) { g.line(C, [C[0] + c, sn], { color: "muted", w: 1.2, opacity: 0.6 }); g.point([C[0] + 1, T], "", { color: "a" }); }
      g.arc(C, [C[0] + 1, 0], [C[0] + c, sn], { color: "c", r: 18 });
      [[Math.PI / 2, "π/2"], [Math.PI, "π"], [(3 * Math.PI) / 2, "3π/2"], [2 * Math.PI, "2π"]].forEach(([x, l]) => g.text([x, 0], l, { dy: 18, size: 12, color: "muted" }));
      [Math.PI / 2, (3 * Math.PI) / 2].forEach((x) => g.seg([x, g.yr[0]], [x, g.yr[1]], { color: "e", w: 1.2, dash: "5 5" }));
      g.param((x) => [x, Math.tan(x)], 0, th, { color: "a", w: 3, n: 600 });
      if (ok && Math.abs(T) < 3.4) { g.seg([C[0] + 1, T], [th, T], { color: "a", w: 1.2, dash: "3 4" }); g.point([th, T], "", { color: "a" }); }
      g.text([C[0], -1.5], "단위원과 접선 x = 1", { size: 12, color: "muted" });
    },
    metrics(s) { const c = Math.cos(s.t); return [["θ", `${piFmt(s.t)} (${fmt((s.t * 180) / Math.PI, 1)}°)`], ["tan θ", Math.abs(c) < 1e-3 ? "정의되지 않음" : fmt(Math.tan(s.t), 3), "key"], ["주기", "π"]]; },
    predict: [
      { q: "tan(π/4)의 값은?", set: (s) => (s.t = 0.3), reveal: (s) => (s.t = Math.PI / 4), answer: () => 1, why: "동경이 y = x 방향이라 접선 x = 1과 높이 1에서 만납니다." },
      { q: "y = tan θ의 주기는?", options: O("π", "2π", "π/2"), set: (s) => (s.t = 0.6), reveal: (s) => (s.t = 0.6 + Math.PI), answer: () => "a", why: "θ와 θ + π의 동경은 같은 직선 위에 있어 접선과 같은 점에서 만납니다." },
      { q: "tan(3π/4)의 값은?", set: (s) => (s.t = 2), reveal: (s) => (s.t = (3 * Math.PI) / 4), answer: () => -1, why: "동경을 반대로 늘이면 접선과 높이 −1에서 만납니다." },
    ],
  },

  // ───────── 대수 Ⅶ 수학적 귀납법 ─────────
  {
    id: "alg-cobweb", grade: AL, unit: 7, lesson: "Ⅶ-1", title: "수열의 귀납적 정의 — 거미줄 그림으로 따라가기", type: "조작", time: "12분",
    tags: ["귀납적 정의", "점화식", "수렴"], links: ["alg-arith-sum", "alg-geo-seq"],
    desc: "aₙ₊₁ = f(aₙ)처럼 앞의 항으로 다음 항을 정하는 수열을, y = f(x)와 y = x 사이를 계단처럼 오가는 거미줄 그림으로 그려 봅니다. 항이 한 점으로 모이는 경우, 빙글빙글 돌며 모이는 경우, 멀어지는 경우를 비교합니다.",
    obs: ["점 (aₙ, aₙ₊₁)에서 수평으로 y = x까지 가면 다음 출발점 aₙ₊₁이 됩니다.", "y = f(x)와 y = x의 교점이 수열이 다가갈 수 있는 값(고정점)입니다.", "고정점 근처에서 f의 기울기 크기가 1보다 작으면 모이고, 크면 멀어집니다."],
    q: "aₙ₊₁ = −½aₙ + 3의 거미줄 그림이 소용돌이 모양이 되는 까닭은 무엇일까요?",
    formula: "a₁ = a, aₙ₊₁ = f(aₙ) (n = 1, 2, 3, …)",
    en: { title: "Recursive Sequences — Cobweb Diagrams", desc: "Bounce between y = f(x) and y = x." },
    view: { x: [-0.6, 7], y: [-0.6, 7] },
    params: [
      { key: "f", label: "점화식", type: "select", value: "a", options: Object.entries(REC).map(([k, v]) => [k, v.n]) },
      { key: "a1", label: "첫째항 a₁", min: 0, max: 6, step: 0.1, value: 0.5 },
      { key: "n", label: "따라간 항의 수", min: 1, max: 15, step: 1, value: 6 },
    ],
    anim: { key: "n", min: 1, max: 15, speed: 2, label: "한 항씩 따라가기" },
    seq(s) { const F = REC[s.f].f, a = [s.a1]; for (let i = 1; i <= s.n; i++) a.push(F(a[i - 1])); return a; },
    draw(s, g) {
      const F = REC[s.f].f, a = this.seq(s), lim = 6.9;
      g.grid();
      g.fx((x) => x, { color: "muted", w: 1.6, dash: "6 5" });
      g.fx(F, { color: "b", w: 3, from: s.f === "c" ? -2 : g.xr[0] });
      g.seg([a[0], 0], [a[0], clamp(a[1], -0.5, lim)], { color: "a", w: 2, opacity: 0.6 });
      for (let i = 0; i < a.length - 1; i++) {
        const x = a[i], y = a[i + 1]; if (Math.abs(x) > 9 || Math.abs(y) > 9) break;
        if (i) g.seg([x, x], [x, clamp(y, -0.5, lim)], { color: "a", w: 2.2 });
        g.seg([x, clamp(y, -0.5, lim)], [clamp(y, -0.5, lim), clamp(y, -0.5, lim)], { color: "a", w: 2.2 });
        if (i < 5) g.text([x, 0], `a${"₁₂₃₄₅₆"[i]}`, { dy: 18, size: 12, color: "a", bold: true });
      }
      g.point([a[0], 0], "", { color: "a" });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.4], REC[s.f].n, { anchor: "start", bold: true, color: "b" }).text([6.4, 6.9], "y = x", { size: 12, color: "muted" });
    },
    metrics(s) { const a = this.seq(s); return [["처음 몇 항", a.slice(0, 6).map((v) => fmt(v, 3)).join(", ") + (a.length > 6 ? ", …" : "")], [`a${s.n + 1}`, fmt(a[a.length - 1], 4), "key"], ["다가갈 수 있는 값 (고정점)", REC[s.f].fix]]; },
    predict: [
      { q: "aₙ₊₁ = ½aₙ + 2, a₁ = 0이면 aₙ은 어떤 값에 다가갈까요?", set: (s) => Object.assign(s, { f: "a", a1: 0, n: 1 }), reveal: (s) => (s.n = 15), answer: () => 4, why: "x = ½x + 2를 풀면 x = 4입니다. 그래프에서 y = x와 만나는 점입니다." },
      { q: "aₙ₊₁ = 2aₙ − 1, a₁ = 1.5이면 수열은?", options: O("한없이 커진다", "1에 다가간다", "1.5로 일정하다"), set: (s) => Object.assign(s, { f: "d", a1: 1.5, n: 1 }), reveal: (s) => (s.n = 6), answer: () => "a", why: "aₙ₊₁ − 1 = 2(aₙ − 1)이라 1과의 차가 2배씩 커집니다." },
    ],
  },
  {
    id: "alg-domino", grade: AL, unit: 7, lesson: "Ⅶ-2", title: "수학적 귀납법 — 도미노가 끝까지 넘어지려면", type: "조작", time: "10분",
    tags: ["수학적 귀납법", "도미노", "증명"], links: ["alg-cobweb", "alg-square-sum"],
    desc: "수학적 귀납법의 두 단계 ① n = 1일 때 성립 ② n = k일 때 성립하면 n = k + 1일 때도 성립을 도미노의 '첫 도미노 넘어뜨리기'와 '앞이 넘어지면 뒤도 넘어지는 간격'에 견주어 봅니다. 한 단계라도 빠지면 끝까지 넘어지지 않음을 확인하고, 1 + 3 + ⋯ + (2n − 1) = n²을 넘어진 도미노 수로 따라갑니다.",
    obs: ["①이 없으면 아무 도미노도 넘어지지 않습니다.", "②가 없으면 어딘가에서 넘어짐이 멈출 수 있습니다.", "두 단계가 모두 있으면 모든 자연수 n에 대하여 명제가 성립합니다."],
    q: "② 단계만 증명하고 ① 단계를 빠뜨린 '증명'의 예를 만들어 봅시다.",
    formula: "P(1) 참, P(k) ⇒ P(k + 1) ⇒ 모든 자연수 n에 대하여 P(n) 참",
    en: { title: "Mathematical Induction as Dominoes", desc: "Both steps are needed." },
    view: { x: [-0.6, 13.2], y: [-3.6, 5.4] },
    params: [
      { key: "p1", label: "① 첫째 도미노를 넘어뜨린다 (P(1) 참)", type: "check", value: true },
      { key: "p2", label: "② 앞이 넘어지면 뒤도 넘어진다 (P(k) ⇒ P(k + 1))", type: "check", value: true },
      { key: "t", label: "시간", min: 0, max: 13, step: 0.05, value: 13 },
    ],
    anim: { key: "t", min: 0, max: 13, speed: 3, label: "넘어뜨리기" },
    fallen(s, i) { if (!s.p1) return 0; if (!s.p2 && i > 3) return 0; return clamp(s.t - i, 0, 1); },
    draw(s, g) {
      const N = 12, w = 0.28, h = 2.4;
      g.seg([-0.4, 0], [13, 0], { color: "ink", w: 2 });
      for (let i = 0; i < N; i++) {
        const x = 0.4 + i * 1.05, a = (this.fallen(s, i) * 72 * Math.PI) / 180, P = [x + w, 0];
        const rot = ([px, py]) => { const dx = px - P[0], dy = py - P[1]; return [P[0] + dx * Math.cos(a) + dy * Math.sin(a), P[1] - dx * Math.sin(a) + dy * Math.cos(a)]; };
        const pts = [[x, 0], [x + w, 0], [x + w, h], [x, h]].map(rot), down = this.fallen(s, i) >= 1;
        g.poly(pts, { fill: down ? "a" : "b", fo: down ? 0.7 : 0.35, color: down ? "a" : "b", w: 1.4 });
        g.text([x + w / 2, 0], String(i + 1), { dy: 18, size: 12, color: "muted" });
      }
      if (!s.p2 && s.p1) g.text([0.4 + 4 * 1.05, h + 0.6], "간격이 멀어 여기서 멈춤", { bold: true, color: "e", size: 13 });
      const n = Array.from({ length: N }, (_, i) => this.fallen(s, i) >= 1).filter(Boolean).length;
      g.text([0, -1.4], "P(n): 1 + 3 + 5 + ⋯ + (2n − 1) = n²", { anchor: "start", bold: true, size: 15 });
      if (n) g.text([0, -2.5], `n = ${n}까지 확인: ${Array.from({ length: Math.min(n, 6) }, (_, k) => 2 * k + 1).join(" + ")}${n > 6 ? " + ⋯" : ""} = ${n * n} = ${n}²`, { anchor: "start", size: 14, color: "a", bold: true });
    },
    metrics(s) { const n = Array.from({ length: 12 }, (_, i) => this.fallen(s, i) >= 1).filter(Boolean).length; return [["넘어진 도미노", `12개 중 ${n}개`], ["①, ②", `${s.p1 ? "✓" : "✗"}, ${s.p2 ? "✓" : "✗"}`], ["결론", s.p1 && s.p2 ? "모든 자연수 n에 대하여 참" : "모든 n에서 참이라 할 수 없음", "key"]]; },
    predict: [
      { q: "① P(1)은 참인데 ② P(k) ⇒ P(k + 1)이 보장되지 않으면?", options: O("모든 n에서 참이라 할 수 없다", "그래도 모든 n에서 참이다"), set: (s) => Object.assign(s, { p1: true, p2: false, t: 0 }), reveal: (s) => (s.t = 13), answer: () => "a", why: "어딘가에서 넘어짐이 멈추면 그 뒤의 n에 대해서는 알 수 없습니다." },
      { q: "② 단계는 증명했지만 ① P(1)이 거짓이면?", options: O("모든 n에서 참이라 할 수 없다", "그래도 모든 n에서 참이다"), set: (s) => Object.assign(s, { p1: false, p2: true, t: 0 }), reveal: (s) => (s.t = 13), answer: () => "a", why: "첫 도미노가 넘어지지 않으면 연쇄가 시작되지 않습니다." },
    ],
  },
];
