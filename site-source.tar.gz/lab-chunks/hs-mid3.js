// 23차 묶음 6 — 중학교 3학년 (실수 · 곱셈 공식과 인수분해 · 이차방정식 · 이차함수 · 상자그림)
import { fmt, frac, poly, clamp, surd } from "./hs-core.js";

const G3 = 3;
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const lcg = (seed) => { let x = (seed * 4111) % 2147483647 || 7; return () => ((x = (x * 16807) % 2147483647) / 2147483647); };
const sq = (n) => surd(n);
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
const quad = (a, b, c) => poly([[a, "x²"], [b, "x"]], c);
// 중앙값(정렬된 배열)
const med = (A) => { const n = A.length, m = Math.floor(n / 2); return n % 2 ? A[m] : (A[m - 1] + A[m]) / 2; };

export default [
  // ───────── 1단원 실수와 그 계산 ─────────
  {
    id: "m3-sqrt-line", grade: G3, unit: 1, lesson: "1.1", title: "수직선 위의 무리수 — 대각선을 컴퍼스로 옮기기", type: "조작", time: "10분",
    tags: ["제곱근", "무리수", "수직선"], links: ["m3-sqrt-sum"],
    desc: "가로 a, 세로 b인 직각삼각형의 빗변 길이는 √(a² + b²)입니다. 원점을 중심으로 빗변을 컴퍼스로 돌려 수직선에 옮기면 √2, √5, √10 같은 무리수도 수직선 위의 한 점으로 정확히 나타낼 수 있음을 확인합니다.",
    obs: ["넓이가 2인 정사각형의 한 변이 √2이고, 이것은 한 변이 1인 정사각형의 대각선입니다.", "컴퍼스로 길이를 옮기면 수직선 위에 √(a² + b²)을 나타내는 점이 생깁니다.", "무리수도 수직선 위의 한 점에 대응하므로, 수직선은 실수로 빈틈없이 채워집니다."],
    q: "√13을 수직선 위에 나타내려면 어떤 직각삼각형을 그리면 될까요?",
    formula: "빗변 = √(a² + b²)",
    en: { title: "Irrational Numbers on the Number Line", desc: "Swing a diagonal down with a compass." },
    view: { x: [-4.6, 4.6], y: [-1.2, 4.2] },
    params: [
      { key: "a", label: "가로 a", min: 1, max: 3, step: 1, value: 1 },
      { key: "b", label: "세로 b", min: 1, max: 3, step: 1, value: 1 },
      { key: "t", label: "컴퍼스 돌리기", min: 0, max: 1, step: 0.01, value: 1 },
    ],
    anim: { key: "t", min: 0, max: 1, speed: 0.4, label: "컴퍼스 돌리기" },
    draw(s, g) {
      const r = Math.hypot(s.a, s.b), th0 = Math.atan2(s.b, s.a), th = th0 * (1 - s.t);
      g.grid({ labels: false, axes: false });
      g.seg([-4.4, 0], [4.4, 0], { color: "axis", w: 1.8 });
      for (let x = -4; x <= 4; x++) { g.seg([x, -0.1], [x, 0.1], { color: "axis", w: 1.2 }); g.text([x, 0], String(x).replace("-", "−"), { dy: 20, size: 12, color: "muted" }); }
      g.poly([[0, 0], [s.a, 0], [s.a, s.b]], { fill: "b", fo: 0.18, color: "b", w: 2 });
      g.right([s.a, 0], [0, 0], [s.a, s.b], { color: "b" });
      g.seg([0, 0], [s.a, s.b], { color: "a", w: 3 });
      const pts = []; for (let i = 0; i <= 40; i++) { const u = th0 + (th - th0) * (i / 40); pts.push([r * Math.cos(u), r * Math.sin(u)]); }
      g.path(pts, { color: "e", w: 2, dash: "5 4" });
      g.seg([0, 0], [r * Math.cos(th), r * Math.sin(th)], { color: "e", w: 1.4 });
      g.point([r * Math.cos(th), r * Math.sin(th)], "", { color: "e" });
      if (s.t > 0.99) g.text([r, 0], `√${s.a * s.a + s.b * s.b}`, { dy: -12, bold: true, color: "e", size: 15 });
      g.text([s.a / 2, 0], String(s.a), { dy: -6, size: 12, color: "b" }).text([s.a, s.b / 2], String(s.b), { dx: 8, anchor: "start", size: 12, color: "b" });
    },
    metrics(s) { const n = s.a * s.a + s.b * s.b; return [["빗변의 길이", `√${n}${sq(n).includes("√") && sq(n) !== `√${n}` ? ` = ${sq(n)}` : ""}`, "key"], ["근삿값", fmt(Math.sqrt(n), 4)], ["무리수인가?", Number.isInteger(Math.sqrt(n)) ? "아니요 (정수)" : "예"]]; },
    predict: [
      { q: "가로 1, 세로 2인 직각삼각형의 빗변을 옮긴 점은 √몇일까요?", set: (s) => Object.assign(s, { a: 1, b: 2, t: 0 }), reveal: (s) => (s.t = 1), answer: () => 5, why: "1² + 2² = 5이므로 √5입니다." },
      { q: "√2는 수직선 위에서 어느 두 정수 사이에 있을까요?", options: O("1과 2 사이", "2와 3 사이", "0과 1 사이"), set: (s) => Object.assign(s, { a: 1, b: 1, t: 0 }), reveal: (s) => (s.t = 1), answer: () => "a", why: "1² = 1 < 2 < 4 = 2²이므로 1 < √2 < 2입니다." },
    ],
  },
  {
    id: "m3-sqrt-sum", grade: G3, unit: 1, lesson: "1.3", title: "√a + √b ≠ √(a + b) — 직각삼각형으로 확인하기", type: "조작", time: "10분",
    tags: ["근호를 포함한 식", "제곱근의 덧셈", "오개념"], links: ["m3-sqrt-line"],
    desc: "두 변이 √a, √b인 직각삼각형의 빗변은 √(a + b)입니다. 두 변을 이어 붙인 길이 √a + √b는 빗변보다 항상 길어, √a + √b = √(a + b)가 성립하지 않음을 그림과 수로 확인합니다. 곱셈 √a × √b = √(ab)는 성립하는 것과도 비교합니다.",
    obs: ["삼각형의 두 변의 길이의 합은 나머지 한 변보다 깁니다.", "그래서 √a + √b > √(a + b)입니다(a, b > 0).", "√2 + √3은 더 간단히 할 수 없지만 2√3 + 5√3 = 7√3처럼 같은 근호끼리는 더할 수 있습니다."],
    q: "√8 + √2를 간단히 하면 얼마일까요? √10과 같을까요?",
    formula: "√a × √b = √(ab), √a + √b ≠ √(a + b)",
    en: { title: "Why √a + √b ≠ √(a + b)", desc: "Check with a right triangle." },
    view: { x: [-0.5, 9.5], y: [-1.5, 5.4] },
    params: [
      { key: "a", label: "a", min: 1, max: 16, step: 1, value: 9 },
      { key: "b", label: "b", min: 1, max: 16, step: 1, value: 16 },
    ],
    draw(s, g) {
      const A = Math.sqrt(s.a), B = Math.sqrt(s.b), k = Math.min(1, 4.2 / B, 8.4 / (A + B));
      g.poly([[0, 0], [A * k, 0], [A * k, B * k]], { fill: "b", fo: 0.15, color: "b", w: 2.4 });
      g.right([A * k, 0], [0, 0], [A * k, B * k], { color: "b" });
      g.seg([0, 0], [A * k, B * k], { color: "a", w: 3.4 });
      g.text([(A * k) / 2, 0], `√${s.a}`, { dy: 18, bold: true, color: "b" }).text([A * k, (B * k) / 2], `√${s.b}`, { dx: 8, anchor: "start", bold: true, color: "b" }).text([(A * k) / 2, (B * k) / 2], `√${s.a + s.b}`, { dx: -10, anchor: "end", bold: true, color: "a" });
      g.seg([0, -0.8], [(A + B) * k, -0.8], { color: "b", w: 5 }).seg([0, -1.25], [Math.sqrt(s.a + s.b) * k, -1.25], { color: "a", w: 5 });
      g.text([(A + B) * k, -0.8], `√${s.a} + √${s.b}`, { dx: 8, anchor: "start", dy: 4, size: 12, color: "b", bold: true }).text([Math.sqrt(s.a + s.b) * k, -1.25], `√${s.a + s.b}`, { dx: 8, anchor: "start", dy: 4, size: 12, color: "a", bold: true });
    },
    metrics(s) { const A = Math.sqrt(s.a), B = Math.sqrt(s.b); return [["√a + √b", fmt(A + B, 4)], ["√(a + b)", fmt(Math.sqrt(s.a + s.b), 4)], ["차", fmt(A + B - Math.sqrt(s.a + s.b), 4), "key"], ["√a × √b = √(ab)", `${fmt(A * B, 4)} = √${s.a * s.b}`]]; },
    predict: [
      { q: "√9 + √16의 값은?", set: (s) => Object.assign(s, { a: 2, b: 3 }), reveal: (s) => Object.assign(s, { a: 9, b: 16 }), answer: () => 7, why: "3 + 4 = 7입니다. √(9 + 16) = √25 = 5와 다릅니다." },
      { q: "√2 × √8의 값은?", answer: () => 4, why: "√2 × √8 = √16 = 4입니다. 곱셈은 근호 안끼리 곱해도 됩니다." },
    ],
  },

  // ───────── 2단원 다항식의 곱셈과 인수분해 ─────────
  {
    id: "m3-mult-formula", grade: G3, unit: 2, lesson: "2.1", title: "넓이로 보는 곱셈 공식", type: "조작", time: "10분",
    tags: ["곱셈 공식", "넓이 모형", "완전제곱식"], links: ["m3-tile-factor", "cm1-poly-area"],
    desc: "한 변이 a + b인 정사각형을 a², ab, ab, b²의 네 조각으로 나누면 (a + b)² = a² + 2ab + b²입니다. (a − b)²과 (a + b)(a − b)도 정사각형에서 조각을 떼어 내고 옮기는 그림으로 확인합니다.",
    obs: ["(a + b)²에는 ab 직사각형이 2개 들어 있어 2ab가 생깁니다.", "(a − b)²은 a²에서 ab 두 개를 떼고, 두 번 뗀 b²을 한 번 되돌려 놓은 것입니다.", "(a + b)(a − b)는 a²에서 b²을 뗀 ㄱ자 모양을 직사각형으로 옮긴 것입니다."],
    q: "(a + b)² = a² + b²이라고 쓰는 실수를 그림으로 바로잡아 봅시다.",
    formula: "(a + b)² = a² + 2ab + b², (a − b)² = a² − 2ab + b², (a + b)(a − b) = a² − b²",
    en: { title: "Multiplication Formulas as Areas", desc: "Squares and rectangles explain the identities." },
    view: BOX,
    params: [
      { key: "mode", label: "공식", type: "seg", value: "p", options: [["p", "(a + b)²"], ["m", "(a − b)²"], ["d", "(a + b)(a − b)"]] },
      { key: "a", label: "a", min: 2, max: 6, step: 0.5, value: 5 },
      { key: "b", label: "b", min: 0.5, max: 3, step: 0.5, value: 2 },
    ],
    onChange(s) { if (s.b >= s.a) s.b = s.a - 0.5; },
    draw(s, g) {
      const k = 8.6 / (s.mode === "p" ? s.a + s.b : s.a), a = s.a * k, b = s.b * k, x0 = 1, y0 = 1;
      if (s.mode === "p") {
        rect(g, x0, y0 + b, a, a, { fill: "b", fo: 0.3, color: "b", w: 1.6 }); rect(g, x0 + a, y0 + b, b, a, { fill: "a", fo: 0.3, color: "a", w: 1.6 }); rect(g, x0, y0, a, b, { fill: "a", fo: 0.3, color: "a", w: 1.6 }); rect(g, x0 + a, y0, b, b, { fill: "c", fo: 0.4, color: "c", w: 1.6 });
        g.text([x0 + a / 2, y0 + b + a / 2], "a²", { bold: true, size: 18, color: "b" }).text([x0 + a + b / 2, y0 + b + a / 2], "ab", { bold: true, color: "a" }).text([x0 + a / 2, y0 + b / 2], "ab", { dy: 5, bold: true, color: "a" }).text([x0 + a + b / 2, y0 + b / 2], "b²", { dy: 5, bold: true, color: "c" });
      } else if (s.mode === "m") {
        rect(g, x0, y0, a, a, { color: "ink", w: 2, dash: "5 4" });
        rect(g, x0, y0 + b, a - b, a - b, { fill: "b", fo: 0.35, color: "b", w: 1.6 });
        rect(g, x0 + a - b, y0, b, a, { fill: "a", fo: 0.22, color: "a", w: 1.4 }); rect(g, x0, y0, a, b, { fill: "a", fo: 0.22, color: "a", w: 1.4 });
        rect(g, x0 + a - b, y0, b, b, { fill: "c", fo: 0.5, color: "c", w: 1.6 });
        g.text([x0 + (a - b) / 2, y0 + b + (a - b) / 2], "(a − b)²", { bold: true, size: 16, color: "b" }).text([x0 + a - b / 2, y0 + a / 2 + b / 2], "ab", { bold: true, color: "a" }).text([x0 + (a - b) / 2, y0 + b / 2], "ab", { dy: 5, bold: true, color: "a" }).text([x0 + a - b / 2, y0 + b / 2], "b²", { dy: 5, bold: true, color: "c", size: 12 });
        g.text([x0 + a + 0.5, y0 + a - 0.4], "a² − ab − ab + b²", { anchor: "start", bold: true, size: 14 }).text([x0 + a + 0.5, y0 + a - 1.2], "(b²은 두 번 떼었으니 한 번 되돌림)", { anchor: "start", size: 12, color: "muted" });
      } else {
        rect(g, x0, y0 + b, a, a - b, { fill: "b", fo: 0.32, color: "b", w: 1.6 }); rect(g, x0, y0, a - b, b, { fill: "a", fo: 0.32, color: "a", w: 1.6 }); rect(g, x0 + a - b, y0, b, b, { color: "e", w: 1.6, dash: "4 4" });
        g.text([x0 + a - b / 2, y0 + b / 2], "b² 뗌", { dy: 5, size: 11, color: "e", bold: true });
        const X = x0 + a + 0.8; rect(g, X, y0 + b, a, a - b, { fill: "b", fo: 0.32, color: "b", w: 1.6 }); rect(g, X + a, y0 + b, b, a - b, { fill: "a", fo: 0.32, color: "a", w: 1.6 });
        g.text([X + (a + b) / 2, y0 + b], `(a + b) × (a − b)`, { dy: 18, bold: true, size: 13 }).text([X + a + b / 2, y0 + b + (a - b) / 2], "옮김", { dy: 4, size: 11, color: "a", bold: true });
      }
    },
    metrics(s) { const { a, b } = s, L = s.mode === "p" ? (a + b) ** 2 : s.mode === "m" ? (a - b) ** 2 : (a + b) * (a - b), R = s.mode === "p" ? a * a + 2 * a * b + b * b : s.mode === "m" ? a * a - 2 * a * b + b * b : a * a - b * b; return [["왼쪽 (넓이)", fmt(L, 3)], ["오른쪽 (전개식)", fmt(R, 3)], ["같은가?", Math.abs(L - R) < 1e-9 ? "같다 ✓" : "다르다", "key"]]; },
    predict: [
      { q: "(x + 3)²을 전개했을 때 x의 계수는?", set: (s) => Object.assign(s, { mode: "p", a: 5, b: 1.5 }), answer: () => 6, why: "ab 직사각형이 2개라 2 × 3 = 6, x² + 6x + 9입니다." },
      { q: "51 × 49를 곱셈 공식으로 계산하면?", set: (s) => Object.assign(s, { mode: "d", a: 5, b: 1 }), answer: () => 2499, why: "(50 + 1)(50 − 1) = 50² − 1² = 2500 − 1 = 2499입니다." },
    ],
  },
  {
    id: "m3-tile-factor", grade: G3, unit: 2, lesson: "2.2", title: "대수 타일로 인수분해 — 직사각형을 완성하기", type: "조작", time: "12분",
    tags: ["인수분해", "대수 타일", "이차식"], links: ["m3-mult-formula", "m2-algebra-tiles"],
    desc: "x² 타일 1개, x 타일 b개, 1 타일 c개를 빈틈없이 한 직사각형으로 모으면 가로와 세로가 x + p, x + q가 됩니다. x 타일을 오른쪽 p개, 아래쪽 q개로 나누어 보며 p + q = b, pq = c일 때만 직사각형이 완성됨을 확인합니다.",
    obs: ["x² + bx + c = (x + p)(x + q)이면 p + q = b, pq = c입니다.", "1 타일은 p × q 직사각형으로 모여야 합니다.", "곱이 c인 두 수 가운데 합이 b인 짝을 찾는 것이 인수분해입니다."],
    q: "x² + 5x + 6과 x² + 7x + 6은 각각 어떤 직사각형이 될까요?",
    formula: "x² + (p + q)x + pq = (x + p)(x + q)",
    en: { title: "Factoring with Algebra Tiles", desc: "Complete the rectangle." },
    view: BOX,
    params: [
      { key: "b", label: "x의 계수 b", min: 2, max: 9, step: 1, value: 5 },
      { key: "c", label: "상수항 c", min: 1, max: 20, step: 1, value: 6 },
      { key: "p", label: "오른쪽에 둘 x 타일 수 p", min: 1, max: (s) => s.b - 1, step: 1, value: 2 },
    ],
    onChange(s) { s.p = clamp(s.p, 1, s.b - 1); },
    draw(s, g) {
      const X = 2.6, u = Math.min(0.7, 10 / (X + s.b)), q = s.b - s.p, x0 = 1, y0 = 10.2, need = s.p * q;
      const R = (x, y, w, h, c, t) => { rect(g, x, y - h, w, h, { fill: c, fo: 0.45, color: c, w: 1.2 }); if (t && w > 0.35 && h > 0.35) g.text([x + w / 2, y - h / 2], t, { dy: 4, size: 11, bold: true }); };
      R(x0, y0, X, X, "b", "x²");
      for (let i = 0; i < s.p; i++) R(x0 + X + i * u, y0, u, X, "c", "x");
      for (let j = 0; j < q; j++) R(x0, y0 - X - j * u, X, u, "c", "x");
      let k = 0;
      for (let j = 0; j < q; j++) for (let i = 0; i < s.p; i++) { const ok = k < s.c; rect(g, x0 + X + i * u, y0 - X - (j + 1) * u, u, u, { fill: ok ? "a" : "paper", fo: ok ? 0.5 : 1, color: ok ? "a" : "e", w: 1.2, dash: ok ? false : "3 3" }); k++; }
      for (let e = need; e < s.c; e++) { const i = e - need; rect(g, x0 + X + s.p * u + 0.6 + (i % 6) * (u + 0.1), y0 - X - Math.floor(i / 6) * (u + 0.1) - u, u, u, { fill: "a", fo: 0.5, color: "e", w: 1.6 }); }
      const ok = need === s.c;
      g.text([x0, 1.4], ok ? `완성! x² + ${s.b}x + ${s.c} = (x + ${s.p})(x + ${q})` : need > s.c ? `1 타일이 ${need - s.c}개 모자라요 (빈칸)` : `1 타일이 ${s.c - need}개 남아요 (분홍 테두리)`, { anchor: "start", bold: true, size: 16, color: ok ? "c" : "e" });
    },
    metrics(s) { const q = s.b - s.p, pairs = []; for (let p = 1; p < s.b; p++) if (p * (s.b - p) === s.c && p <= s.b - p) pairs.push(`(x + ${p})(x + ${s.b - p})`); return [["p + q", `${s.p} + ${q} = ${s.b}`], ["pq", `${s.p * q} (필요한 1 타일 ${s.c}개)`], ["인수분해", pairs.length ? pairs.join(", ") : "자연수 범위에서는 안 됨", "key"]]; },
    predict: [
      { q: "x² + 5x + 6 = (x + 2)(x + q)에서 q는?", set: (s) => Object.assign(s, { b: 5, c: 6, p: 1 }), reveal: (s) => (s.p = 2), answer: () => 3, why: "2 + 3 = 5, 2 × 3 = 6입니다." },
      { q: "x² + 7x + 12를 인수분해하면 (x + 3)(x + □)에서 □는?", set: (s) => Object.assign(s, { b: 7, c: 12, p: 1 }), reveal: (s) => (s.p = 3), answer: () => 4, why: "합이 7, 곱이 12인 두 수는 3과 4입니다." },
    ],
  },

  // ───────── 3단원 이차방정식 ─────────
  {
    id: "m3-complete-square", grade: G3, unit: 3, lesson: "3.2", title: "정사각형 완성 — 모서리 한 조각을 채우면", type: "조작", time: "12분",
    tags: ["완전제곱식", "이차방정식", "넓이 모형"], links: ["m3-quad-formula", "m3-mult-formula"],
    desc: "x² + bx = k를 x² 정사각형과 b/2 × x 직사각형 두 개로 그리면 모서리 하나가 비어 있습니다. 넓이 (b/2)²인 조각을 양쪽에 더해 채우면 (x + b/2)² = k + (b/2)²이 되어 제곱근으로 풀 수 있음을 확인합니다. 이것이 근의 공식을 만드는 생각입니다.",
    obs: ["bx를 반으로 나누어 두 변에 붙이면 정사각형이 거의 완성됩니다.", "비어 있는 모서리의 넓이가 (b/2)²입니다.", "양변에 (b/2)²을 더하면 왼쪽이 완전제곱식이 됩니다."],
    q: "x² + 6x = 7을 이 그림으로 풀어 봅시다. 음수인 해는 그림에서 어떻게 볼 수 있을까요?",
    formula: "x² + bx = k ⇒ (x + b/2)² = k + (b/2)²",
    en: { title: "Completing the Square", desc: "Fill in the missing corner." },
    view: BOX,
    params: [
      { key: "b", label: "b (x² + bx = k)", min: 2, max: 10, step: 2, value: 6 },
      { key: "k", label: "k", min: 1, max: 40, step: 1, value: 7 },
      { key: "fill", label: "모서리 채우기", type: "check", value: true },
    ],
    draw(s, g) {
      const h = s.b / 2, x = -h + Math.sqrt(s.k + h * h), Ttl = x + h, sc = 8.4 / Ttl, X = x * sc, Hh = h * sc, x0 = 1, y0 = 1;
      rect(g, x0, y0 + Hh, X, X, { fill: "b", fo: 0.32, color: "b", w: 1.6 }); rect(g, x0 + X, y0 + Hh, Hh, X, { fill: "a", fo: 0.32, color: "a", w: 1.6 }); rect(g, x0, y0, X, Hh, { fill: "a", fo: 0.32, color: "a", w: 1.6 });
      rect(g, x0 + X, y0, Hh, Hh, s.fill ? { fill: "c", fo: 0.55, color: "c", w: 1.8 } : { color: "e", w: 1.6, dash: "5 4" });
      g.text([x0 + X / 2, y0 + Hh + X / 2], "x²", { bold: true, size: 18, color: "b" }).text([x0 + X + Hh / 2, y0 + Hh + X / 2], `${fmt(h)}x`, { bold: true, color: "a" }).text([x0 + X / 2, y0 + Hh / 2], `${fmt(h)}x`, { dy: 5, bold: true, color: "a" }).text([x0 + X + Hh / 2, y0 + Hh / 2], `${fmt(h * h)}`, { dy: 5, bold: true, color: s.fill ? "c" : "e" });
      const tx = x0 + X + Hh + 0.6;
      g.text([tx, 9.6], `x² + ${s.b}x = ${s.k}`, { anchor: "start", bold: true, size: 17 });
      if (s.fill) { g.text([tx, 8.5], `x² + ${s.b}x + ${fmt(h * h)} = ${s.k} + ${fmt(h * h)}`, { anchor: "start", size: 15, color: "c", bold: true }); g.text([tx, 7.4], `(x + ${fmt(h)})² = ${fmt(s.k + h * h)}`, { anchor: "start", size: 17, bold: true }); g.text([tx, 6.3], `x + ${fmt(h)} = ±${sq(s.k + h * h)}`, { anchor: "start", size: 15 }); g.text([tx, 5.2], `x = −${fmt(h)} ± ${sq(s.k + h * h)}`, { anchor: "start", size: 17, bold: true, color: "e" }); }
      else g.text([tx, 8.5], `모서리 ${fmt(h)} × ${fmt(h)}가 비어 있어요`, { anchor: "start", size: 14, color: "e", bold: true });
    },
    metrics(s) { const h = s.b / 2, r = Math.sqrt(s.k + h * h); return [["더할 조각 (b/2)²", fmt(h * h), "key"], ["두 해", `${fmt(-h + r, 3)}, ${fmt(-h - r, 3)}`], ["그림의 한 변", `x + ${fmt(h)} = ${fmt(r, 3)}`]]; },
    predict: [
      { q: "x² + 6x = 7에서 양변에 더해야 할 수는?", set: (s) => Object.assign(s, { b: 6, k: 7, fill: false }), reveal: (s) => (s.fill = true), answer: () => 9, why: "(6/2)² = 9를 더하면 (x + 3)² = 16입니다." },
      { q: "x² + 6x = 7의 양수인 해는?", set: (s) => Object.assign(s, { b: 6, k: 7, fill: true }), answer: () => 1, why: "x + 3 = ±4이므로 x = 1 또는 x = −7입니다." },
    ],
  },
  {
    id: "m3-quad-formula", grade: G3, unit: 3, lesson: "3.3", title: "근의 공식과 근의 개수 — b² − 4ac의 부호", type: "조작", time: "12분",
    tags: ["근의 공식", "이차방정식", "근의 개수"], links: ["m3-complete-square", "m3-vertex"],
    desc: "이차방정식 ax² + bx + c = 0의 해를 근의 공식으로 구하고, 그래프 y = ax² + bx + c가 x축과 만나는 점과 비교합니다. 근호 안의 b² − 4ac가 양수이면 서로 다른 두 근, 0이면 중근, 음수이면 근이 없음을 확인합니다.",
    obs: ["근의 공식은 정사각형 완성을 일반적인 a, b, c로 한 결과입니다.", "b² − 4ac > 0이면 그래프가 x축과 두 점에서 만납니다.", "b² − 4ac < 0이면 √ 안이 음수라 실수인 근이 없습니다."],
    q: "x² − 4x + k = 0이 중근을 가지려면 k는 얼마여야 할까요?",
    formula: "x = (−b ± √(b² − 4ac)) / 2a",
    en: { title: "The Quadratic Formula", desc: "The sign of b² − 4ac counts the roots." },
    view: { x: [-6, 6], y: [-5, 6] },
    params: [
      { key: "a", label: "a", min: -2, max: 2, step: 0.5, value: 1 },
      { key: "b", label: "b", min: -6, max: 6, step: 1, value: -2 },
      { key: "c", label: "c", min: -6, max: 6, step: 1, value: -3 },
    ],
    onChange(s) { if (!s.a) s.a = 0.5; },
    draw(s, g) {
      const f = (x) => s.a * x * x + s.b * x + s.c, D = s.b * s.b - 4 * s.a * s.c;
      g.grid();
      g.fx(f, { color: "b", w: 3 });
      if (D >= 0) { const r = Math.sqrt(D); [(-s.b - r) / (2 * s.a), (-s.b + r) / (2 * s.a)].forEach((x) => g.point([x, 0], `x = ${fmt(x, 2)}`, { color: "a", dy: f(x - 0.01) > 0 ? 22 : -12 })); }
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], `y = ${quad(s.a, s.b, s.c)}`, { anchor: "start", bold: true, color: "b", size: 15 });
    },
    metrics(s) {
      const D = s.b * s.b - 4 * s.a * s.c, den = 2 * s.a;
      const exact = D >= 0 ? (Number.isInteger(Math.sqrt(D)) ? `${frac((-s.b - Math.sqrt(D)) / den)}, ${frac((-s.b + Math.sqrt(D)) / den)}` : `(${fmt(-s.b)} ± √${fmt(D)}) / ${fmt(den)}`) : "실수인 근 없음";
      return [["b² − 4ac", `${fmt(s.b * s.b)} − ${fmt(4 * s.a * s.c)} = ${fmt(D)}`], ["근", D > 0 ? exact : D === 0 ? `${frac(-s.b / den)} (중근)` : exact, "key"], ["근의 개수", D > 0 ? "2개" : D === 0 ? "1개 (중근)" : "0개"]];
    },
    predict: [
      { q: "x² − 2x − 3 = 0의 큰 근은?", set: (s) => Object.assign(s, { a: 1, b: -2, c: -3 }), answer: () => 3, why: "x = (2 ± √16)/2 = 1 ± 2이므로 3과 −1입니다." },
      { q: "x² − 4x + k = 0이 중근을 가지는 k는?", set: (s) => Object.assign(s, { a: 1, b: -4, c: 0 }), reveal: (s) => (s.c = 4), answer: () => 4, why: "b² − 4ac = 16 − 4k = 0에서 k = 4입니다." },
    ],
  },

  // ───────── 4단원 이차함수와 그래프 ─────────
  {
    id: "m3-ax2", grade: G3, unit: 4, lesson: "4.1", title: "y = ax²의 그래프 — a가 정하는 폭과 방향", type: "조작", time: "10분",
    tags: ["이차함수", "포물선", "축과 꼭짓점"], links: ["m3-shift"],
    desc: "a를 바꾸며 y = ax²의 그래프를 y = x², y = −x²과 겹쳐 봅니다. a의 부호가 아래로 볼록·위로 볼록을, |a|의 크기가 그래프의 폭을 정하고, 그래프가 y축에 대하여 대칭임을 x = ±k의 점으로 확인합니다.",
    obs: ["a > 0이면 아래로 볼록, a < 0이면 위로 볼록입니다.", "|a|가 클수록 그래프의 폭이 좁아집니다.", "y = ax²과 y = −ax²의 그래프는 x축에 대하여 대칭입니다."],
    q: "y = 2x²과 y = ½x²에서 x = 2일 때의 y 값을 비교하고, 폭과의 관계를 설명해 봅시다.",
    formula: "y = ax² (a ≠ 0): 꼭짓점 (0, 0), 축 x = 0",
    en: { title: "Graphs of y = ax²", desc: "a sets the width and direction." },
    view: { x: [-5, 5], y: [-6, 6] },
    params: [
      { key: "a", label: "a", min: -3, max: 3, step: 0.25, value: 2 },
      { key: "k", label: "살펴볼 x = ±k", min: 0, max: 3, step: 0.5, value: 1.5 },
    ],
    anim: { key: "a", min: -3, max: 3, speed: 1, loop: "bounce", label: "a 바꾸기" },
    onChange(s) { if (!s.a) s.a = 0.25; },
    draw(s, g) {
      g.grid();
      g.fx((x) => x * x, { color: "muted", w: 1.4, dash: "5 5" }).fx((x) => -x * x, { color: "muted", w: 1.4, dash: "5 5" });
      g.fx((x) => s.a * x * x, { color: "b", w: 3.2 });
      const y = s.a * s.k * s.k;
      if (s.k && Math.abs(y) < 6) { g.point([s.k, y], `(${fmt(s.k)}, ${fmt(y)})`, { color: "a" }).point([-s.k, y], `(−${fmt(s.k)}, ${fmt(y)})`, { color: "a", anchor: "end", dx: -12 }); g.seg([-s.k, y], [s.k, y], { color: "a", w: 1.2, dash: "3 4" }); }
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], `y = ${fmt(s.a)}x²`, { anchor: "start", bold: true, color: "b", size: 16 }).text([g.xr[0] + 0.3, g.yr[1] - 1.3], "점선: y = x², y = −x²", { anchor: "start", size: 12, color: "muted" });
    },
    metrics(s) { return [["볼록한 방향", s.a > 0 ? "아래로 볼록" : "위로 볼록", "key"], ["폭", Math.abs(s.a) > 1 ? "y = x²보다 좁다" : Math.abs(s.a) < 1 ? "y = x²보다 넓다" : "y = x²과 같다"], [`x = ±${fmt(s.k)}일 때 y`, fmt(s.a * s.k * s.k, 3)]]; },
    predict: [
      { q: "y = 2x²과 y = ½x² 가운데 폭이 더 좁은 것은?", options: O("y = 2x²", "y = ½x²"), set: (s) => Object.assign(s, { a: 0.5, k: 2 }), reveal: (s) => (s.a = 2), answer: () => "a", why: "x = 2에서 y가 8과 2로, |a|가 클수록 빨리 커져 폭이 좁습니다." },
      { q: "y = −3x²의 그래프 위의 점 (2, □)에서 □는?", set: (s) => Object.assign(s, { a: -1, k: 1 }), reveal: (s) => Object.assign(s, { a: -3, k: 2 }), answer: () => -12, why: "−3 × 2² = −12입니다." },
    ],
  },
  {
    id: "m3-shift", grade: G3, unit: 4, lesson: "4.2", title: "평행이동 — y = a(x − p)² + q", type: "조작", time: "12분",
    tags: ["이차함수", "평행이동", "꼭짓점"], links: ["m3-ax2", "m3-vertex"],
    desc: "y = ax²의 그래프(점선)를 x축 방향으로 p만큼, y축 방향으로 q만큼 평행이동하면 y = a(x − p)² + q가 됩니다. 꼭짓점이 (0, 0)에서 (p, q)로, 축이 x = 0에서 x = p로 옮겨 가고 모양(폭)은 그대로임을 확인합니다.",
    obs: ["x 대신 x − p를 넣으면 그래프가 오른쪽으로 p만큼 이동합니다.", "꼭짓점은 (p, q), 축의 방정식은 x = p입니다.", "평행이동해도 a가 같으면 모양과 폭은 같습니다."],
    q: "y = 2(x + 1)² − 3의 그래프는 y = 2x²을 어느 방향으로 얼마나 옮긴 것일까요?",
    formula: "y = a(x − p)² + q: 꼭짓점 (p, q), 축 x = p",
    en: { title: "Translating Parabolas", desc: "y = a(x − p)² + q." },
    view: { x: [-6, 6], y: [-5, 6] },
    params: [
      { key: "a", label: "a", min: -2, max: 2, step: 0.5, value: 1 },
      { key: "p", label: "p (x축 방향)", min: -4, max: 4, step: 0.5, value: 2 },
      { key: "q", label: "q (y축 방향)", min: -4, max: 4, step: 0.5, value: -1 },
    ],
    onChange(s) { if (!s.a) s.a = 0.5; },
    drags: { V: { at: (s) => [s.p, s.q], move: (s, p) => { s.p = clamp(Math.round(p[0] * 2) / 2, -4, 4); s.q = clamp(Math.round(p[1] * 2) / 2, -4, 4); }, label: "꼭짓점" } },
    draw(s, g) {
      g.grid();
      g.fx((x) => s.a * x * x, { color: "muted", w: 1.6, dash: "6 5" });
      g.fx((x) => s.a * (x - s.p) ** 2 + s.q, { color: "b", w: 3.2 });
      g.seg([s.p, g.yr[0]], [s.p, g.yr[1]], { color: "e", w: 1.4, dash: "4 4" });
      if (s.p || s.q) g.vec([0, 0], [s.p, s.q], { color: "a", w: 2.4 });
      g.point([0, 0], "", { color: "muted", r: 4 });
      const ps = s.p ? `(x ${s.p > 0 ? "−" : "+"} ${fmt(Math.abs(s.p))})²` : "x²", qs = s.q ? ` ${s.q > 0 ? "+" : "−"} ${fmt(Math.abs(s.q))}` : "";
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], `y = ${s.a === 1 ? "" : s.a === -1 ? "−" : fmt(s.a)}${ps}${qs}`, { anchor: "start", bold: true, color: "b", size: 16 });
    },
    metrics(s) { return [["꼭짓점", `(${fmt(s.p)}, ${fmt(s.q)})`, "key"], ["축의 방정식", `x = ${fmt(s.p)}`], ["이동", `x축 방향 ${fmt(s.p)}, y축 방향 ${fmt(s.q)}`]]; },
    predict: [
      { q: "y = 2(x + 1)² − 3의 꼭짓점의 x좌표는?", set: (s) => Object.assign(s, { a: 2, p: 0, q: 0 }), reveal: (s) => Object.assign(s, { p: -1, q: -3 }), answer: () => -1, why: "(x + 1)² = (x − (−1))²이므로 p = −1, 꼭짓점은 (−1, −3)입니다." },
      { q: "y = −(x − 2)² + 4의 최댓값은?", set: (s) => Object.assign(s, { a: -1, p: 0, q: 0 }), reveal: (s) => Object.assign(s, { p: 2, q: 4 }), answer: () => 4, why: "위로 볼록이라 꼭짓점 (2, 4)에서 가장 높습니다." },
    ],
  },
  {
    id: "m3-vertex", grade: G3, unit: 4, lesson: "4.3", title: "y = ax² + bx + c의 꼭짓점 찾기", type: "조작", time: "12분",
    tags: ["이차함수", "꼭짓점", "완전제곱식"], links: ["m3-shift", "m3-complete-square"],
    desc: "y = ax² + bx + c를 완전제곱식을 이용해 y = a(x − p)² + q 꼴로 바꾸면 꼭짓점 (p, q)를 읽을 수 있습니다. 변형 과정을 따라가며 p = −b/(2a)임을 확인하고, y절편 (0, c)와 그와 대칭인 점도 그래프에 표시합니다.",
    obs: ["a로 묶은 뒤 x의 계수의 반의 제곱을 더하고 뺍니다.", "꼭짓점의 x좌표는 −b/(2a)입니다.", "y절편 (0, c)와 축에 대하여 대칭인 점은 (−b/a, c)입니다."],
    q: "y = x² − 6x + 5의 그래프가 x축과 만나는 두 점의 한가운데는 어디일까요?",
    formula: "y = ax² + bx + c = a(x + b/(2a))² − (b² − 4ac)/(4a)",
    en: { title: "Finding the Vertex", desc: "Rewrite ax² + bx + c in vertex form." },
    view: { x: [-6, 6], y: [-5, 7] },
    params: [
      { key: "a", label: "a", min: -2, max: 2, step: 1, value: 1 },
      { key: "b", label: "b", min: -6, max: 6, step: 1, value: -4 },
      { key: "c", label: "c", min: -5, max: 6, step: 1, value: 1 },
    ],
    onChange(s) { if (!s.a) s.a = 1; },
    draw(s, g) {
      const f = (x) => s.a * x * x + s.b * x + s.c, p = -s.b / (2 * s.a), q = f(p);
      g.grid();
      g.fx(f, { color: "b", w: 3.2 });
      g.seg([p, g.yr[0]], [p, g.yr[1]], { color: "e", w: 1.4, dash: "4 4" });
      g.point([p, q], `꼭짓점 (${frac(p)}, ${frac(q)})`, { color: "a" });
      g.point([0, s.c], "(0, c)", { color: "c", anchor: "end", dx: -10 });
      if (Math.abs(p) > 1e-9) g.point([2 * p, s.c], "", { color: "c", hollow: true });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], `y = ${quad(s.a, s.b, s.c)}`, { anchor: "start", bold: true, color: "b", size: 15 });
    },
    metrics(s) {
      const p = -s.b / (2 * s.a), q = s.a * p * p + s.b * p + s.c, ps = Math.abs(p) < 1e-9 ? "x²" : `(x ${p > 0 ? "−" : "+"} ${frac(Math.abs(p))})²`;
      return [["꼴 바꾸기", `y = ${s.a === 1 ? "" : s.a === -1 ? "−" : fmt(s.a)}${ps}${Math.abs(q) < 1e-9 ? "" : ` ${q > 0 ? "+" : "−"} ${frac(Math.abs(q))}`}`], ["꼭짓점", `(${frac(p)}, ${frac(q)})`, "key"], ["축의 방정식", `x = ${frac(p)}`]];
    },
    predict: [
      { q: "y = x² − 4x + 1의 꼭짓점의 y좌표는?", set: (s) => Object.assign(s, { a: 1, b: -4, c: 1 }), answer: () => -3, why: "y = (x − 2)² − 4 + 1 = (x − 2)² − 3이므로 꼭짓점은 (2, −3)입니다." },
      { q: "y = −x² + 6x − 5의 축의 방정식 x = ?", set: (s) => Object.assign(s, { a: -1, b: 6, c: -5 }), answer: () => 3, why: "−b/(2a) = −6/(−2) = 3입니다." },
    ],
  },

  // ───────── 7단원 통계 ─────────
  {
    id: "m3-boxplot", grade: G3, unit: 7, lesson: "7.2", title: "상자그림과 사분위수 — 이상치에 흔들리지 않는 그림", type: "데이터", time: "12분",
    tags: ["상자그림", "사분위수", "이상치"], links: [],
    desc: "15개의 자료를 크기 순으로 늘어놓고 중앙값, 제1사분위수, 제3사분위수를 찾아 상자그림을 그립니다. 가장 큰 값을 크게 바꾸어 이상치를 만들어도 상자(사분위수)는 거의 움직이지 않지만 평균과 범위는 크게 달라짐을 비교합니다.",
    obs: ["중앙값은 자료를 둘로 나누고, 제1·제3사분위수는 아래쪽·위쪽 절반의 중앙값입니다.", "상자의 길이 Q3 − Q1(사분위수 범위)에 가운데 50%의 자료가 들어갑니다.", "극단적인 값 하나는 평균과 범위를 크게 바꾸지만 사분위수는 거의 바꾸지 못합니다."],
    q: "두 반의 수학 점수를 상자그림으로 나란히 그리면 어떤 점을 비교할 수 있을까요?",
    formula: "사분위수 범위 = Q3 − Q1",
    en: { title: "Box Plots and Quartiles", desc: "A picture that resists outliers." },
    view: { x: [-2, 102], y: [-30, 42], pad: 14 },
    params: [
      { key: "seed", label: "자료 바꾸기", min: 1, max: 20, step: 1, value: 4 },
      { key: "out", label: "가장 큰 값", min: 60, max: 100, step: 1, value: 72 },
    ],
    data(s) { const r = lcg(s.seed), A = Array.from({ length: 14 }, () => Math.round(35 + r() * 30)).sort((a, b) => a - b); A.push(Math.max(A[13], s.out)); return A; },
    draw(s, g) {
      const A = this.data(s), Q2 = med(A), Q1 = med(A.slice(0, 7)), Q3 = med(A.slice(8)), m = A.reduce((t, v) => t + v, 0) / A.length;
      g.seg([0, 0], [100, 0], { color: "axis", w: 1.6 });
      for (let x = 0; x <= 100; x += 10) { g.seg([x, -1.5], [x, 1.5], { color: "axis", w: 1 }); g.text([x, 0], String(x), { dy: 18, size: 11, color: "muted" }); }
      const cnt = {}; A.forEach((v) => { cnt[v] = (cnt[v] || 0) + 1; g.point([v, 3 + cnt[v] * 3.6], "", { color: v === A[14] && v >= 75 ? "e" : "b", r: 4.5 }); });
      const Y = -16, H = 7;
      g.poly([[Q1, Y - H], [Q3, Y - H], [Q3, Y + H], [Q1, Y + H]], { fill: "c", fo: 0.25, color: "c", w: 2 });
      g.seg([Q2, Y - H], [Q2, Y + H], { color: "c", w: 3 }).seg([A[0], Y], [Q1, Y], { color: "c", w: 2 }).seg([Q3, Y], [A[14], Y], { color: "c", w: 2 });
      g.seg([A[0], Y - 3], [A[0], Y + 3], { color: "c", w: 2 }).seg([A[14], Y - 3], [A[14], Y + 3], { color: "c", w: 2 });
      [["Q1", Q1], ["Q2", Q2], ["Q3", Q3]].forEach(([t, v]) => g.text([v, Y + H], t, { dy: -6, size: 12, bold: true, color: "c" }));
      g.seg([m, -27], [m, 30], { color: "a", w: 1.6, dash: "5 4" }).text([m, 33], `평균 ${fmt(m, 1)}`, { bold: true, color: "a", size: 12 });
    },
    metrics(s) { const A = this.data(s), Q2 = med(A), Q1 = med(A.slice(0, 7)), Q3 = med(A.slice(8)), m = A.reduce((t, v) => t + v, 0) / A.length; return [["Q1 · 중앙값 · Q3", `${fmt(Q1)} · ${fmt(Q2)} · ${fmt(Q3)}`], ["사분위수 범위", fmt(Q3 - Q1), "key"], ["범위", fmt(A[14] - A[0])], ["평균", fmt(m, 2)]]; },
    predict: [
      { q: "가장 큰 값을 72에서 100으로 바꾸면 사분위수 범위는?", options: O("그대로이다", "커진다", "작아진다"), set: (s) => Object.assign(s, { seed: 4, out: 72 }), reveal: (s) => (s.out = 100), answer: () => "a", why: "가장 큰 값은 위쪽 절반의 중앙값(Q3)을 바꾸지 못해 상자가 그대로입니다." },
      { q: "자료 15개의 제1사분위수는 작은 쪽에서 몇 번째 값일까요?", set: (s) => (s.seed = 9), answer: () => 4, why: "중앙값(8번째)을 뺀 아래쪽 7개의 중앙값이므로 4번째 값입니다." },
    ],
  },
];
