// 23차 묶음 15 — 미적분Ⅱ 추가 실험 16개
import { fmt, frac, clamp, piFmt } from "./hs-core.js";

const II = 13;
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const simpson = (f, a, b, n = 400) => { const h = (b - a) / n; let s = f(a) + f(b); for (let i = 1; i < n; i++) s += f(a + i * h) * (i % 2 ? 4 : 2); return (s * h) / 3; };
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
const SEQ = {
  a: { n: "aₙ = (2n² + 3n)/(n² + 1)", f: (n) => (2 * n * n + 3 * n) / (n * n + 1), L: 2, Ls: "2" },
  b: { n: "aₙ = (3n + 1)/(n² + 2)", f: (n) => (3 * n + 1) / (n * n + 2), L: 0, Ls: "0" },
  c: { n: "aₙ = √(n² + n) − n", f: (n) => Math.sqrt(n * n + n) - n, L: 0.5, Ls: "1/2" },
};
const REPD = { a: { n: "0.3̇", first: 0.3, r: 0.1, val: 1 / 3, vs: "1/3" }, b: { n: "0.2̇7̇", first: 0.27, r: 0.01, val: 27 / 99, vs: "3/11" }, c: { n: "0.9̇", first: 0.9, r: 0.1, val: 1, vs: "1" } };
const EXT = {
  a: { n: "y = x·e⁻ˣ", f: (x) => x * Math.exp(-x), d: (x) => (1 - x) * Math.exp(-x), dd: (x) => (x - 2) * Math.exp(-x), lo: -0.8, hi: 6, yr: [-1, 1] },
  b: { n: "y = x²·e⁻ˣ", f: (x) => x * x * Math.exp(-x), d: (x) => (2 * x - x * x) * Math.exp(-x), dd: (x) => (x * x - 4 * x + 2) * Math.exp(-x), lo: -0.8, hi: 7, yr: [-0.4, 1] },
  c: { n: "y = x·e^(−x²/2)", f: (x) => x * Math.exp((-x * x) / 2), d: (x) => (1 - x * x) * Math.exp((-x * x) / 2), dd: (x) => (x ** 3 - 3 * x) * Math.exp((-x * x) / 2), lo: -4, hi: 4, yr: [-1, 1] },
};
const zeros = (f, a, b, n = 1600) => { const R = []; for (let i = 0; i < n; i++) { const x0 = a + ((b - a) * i) / n, x1 = x0 + (b - a) / n; if (f(x0) === 0) R.push(x0); else if (f(x0) * f(x1) < 0) { let lo = x0, hi = x1; for (let k = 0; k < 40; k++) { const m = (lo + hi) / 2; if (f(lo) * f(m) <= 0) hi = m; else lo = m; } R.push((lo + hi) / 2); } } return R.filter((x, i) => !i || x - R[i - 1] > 1e-4); };
const MOT = {
  circ: { n: "원 위를 도는 점 (반지름 2)", p: (t) => [2 * Math.cos(t), 2 * Math.sin(t)], v: (t) => [-2 * Math.sin(t), 2 * Math.cos(t)], T: 2 * Math.PI },
  osc: { n: "직선 위를 오가는 점 x = 2 sin t", p: (t) => [2 * Math.sin(t), 0], v: (t) => [2 * Math.cos(t), 0], T: 2 * Math.PI },
  spiral: { n: "x = t cos t, y = t sin t", p: (t) => [t * Math.cos(t), t * Math.sin(t)], v: (t) => [Math.cos(t) - t * Math.sin(t), Math.sin(t) + t * Math.cos(t)], T: 2 * Math.PI },
};
const TAY = {
  exp: { n: "eˣ", f: Math.exp, c: (k) => 1 / [1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880][k], pow: (k) => k },
  sin: { n: "sin x", f: Math.sin, c: (k) => (k % 2 ? 1 : -1) / [1, 6, 120, 5040, 362880, 39916800, 6227020800, 1307674368000, 355687428096000, 121645100408832000][k], pow: (k) => 2 * k + 1 },
};

export default [
  {
    id: "calc2-seq-frac", grade: II, unit: 1, lesson: "Ⅰ-2", title: "분수꼴 수열의 극한 — 최고차항끼리의 승부", type: "조작", time: "10분",
    tags: ["수열의 극한", "∞/∞ 꼴", "유리화"], links: ["calc2-seq-limit", "calc1-inf-limit"],
    desc: "n이 커질 때 분자·분모가 모두 커지는 수열은 최고차항이 승부를 냅니다. n을 10배씩 키우며 (2n² + 3n)/(n² + 1) → 2처럼 차수가 같으면 계수의 비로, 분모의 차수가 크면 0으로 가고, √(n² + n) − n은 유리화하면 1/2로 간다는 것을 확인합니다.",
    obs: ["분자·분모를 분모의 최고차항으로 나누면 극한값이 보입니다.", "차수가 같으면 최고차항 계수의 비, 분모의 차수가 크면 0입니다.", "∞ − ∞ 꼴은 유리화하여 분수꼴로 바꿉니다."],
    q: "lim(n→∞) (√(n² + 4n) − n)의 값을 구해 봅시다.",
    formula: "lim (2n² + 3n)/(n² + 1) = 2, lim (√(n² + n) − n) = 1/2",
    en: { title: "Limits of Rational Sequences", desc: "Leading terms decide." },
    view: { x: [-0.5, 7.4], y: [-0.6, 3.6] },
    params: [{ key: "s", label: "수열", type: "select", value: "a", options: Object.entries(SEQ).map(([k, v]) => [k, v.n]) }, { key: "e", label: "n의 크기 (10의 거듭제곱)", min: 0, max: 6, step: 0.1, value: 1, show: (v) => `n ≈ ${fmt(10 ** v, 0)}` }],
    anim: { key: "e", min: 0, max: 6, speed: 1, label: "n 키우기" },
    draw(s, g) {
      const K = SEQ[s.s], X = (e) => e;
      g.seg([0, 0], [7, 0], { color: "axis", w: 1.4 }).seg([0, -0.4], [0, 3.4], { color: "axis", w: 1.4 });
      for (let e = 0; e <= 6; e++) g.text([X(e), 0], `10${"⁰¹²³⁴⁵⁶"[e]}`, { dy: 16, size: 11, color: "muted" });
      g.seg([0, K.L], [7, K.L], { color: "e", w: 1.6, dash: "6 4" }).text([7, K.L], `극한 ${K.Ls}`, { anchor: "end", dy: -6, bold: true, color: "e" });
      const pts = []; for (let e = 0; e <= 6; e += 0.05) pts.push([X(e), K.f(10 ** e)]); g.path(pts, { color: "b", w: 2.6 });
      for (let n = 1; n <= 12; n++) g.point([X(Math.log10(n)), K.f(n)], "", { color: "b", r: 3 });
      g.point([X(s.e), K.f(10 ** s.e)], "", { color: "a", r: 6 });
      g.text([0.2, 3.3], `${K.n}  (가로: n을 10배씩)`, { anchor: "start", bold: true });
    },
    metrics(s) { const K = SEQ[s.s], n = 10 ** s.e; return [[`a(${fmt(n, 0)})`, fmt(K.f(n), 7)], ["극한값", K.Ls, "key"], ["차", fmt(Math.abs(K.f(n) - K.L), 7)]]; },
    predict: [
      { q: "lim(n→∞) (2n² + 3n)/(n² + 1)의 값은?", set: (s) => Object.assign(s, { s: "a", e: 0.3 }), reveal: (s) => (s.e = 6), answer: () => 2, why: "분자·분모를 n²으로 나누면 (2 + 3/n)/(1 + 1/n²) → 2입니다." },
      { q: "lim(n→∞) (√(n² + n) − n)의 값은? (분수나 소수로)", set: (s) => Object.assign(s, { s: "c", e: 0.3 }), reveal: (s) => (s.e = 6), answer: () => 0.5, tol: 1e-6, why: "n/(√(n² + n) + n) = 1/(√(1 + 1/n) + 1) → 1/2입니다." },
    ],
  },
  {
    id: "calc2-bounce", grade: II, unit: 1, lesson: "Ⅰ-5 활용", title: "튀어 오르는 공 — 끝없이 튀어도 거리는 유한", type: "조작", time: "10분",
    tags: ["등비급수", "활용", "수렴"], links: ["calc2-geo-series"],
    desc: "높이 h에서 떨어뜨린 공이 매번 떨어진 높이의 r배만큼 튀어 오릅니다. 튀는 횟수는 끝이 없지만, 오르내린 거리의 합은 등비급수 h + 2hr + 2hr² + ⋯ = h(1 + r)/(1 − r)로 일정한 값에 다가감을 그림과 부분합으로 확인합니다.",
    obs: ["처음 h만큼 떨어진 뒤에는 올라가고 내려오는 거리가 2hrⁿ씩 더해집니다.", "0 < r < 1이면 등비급수가 수렴합니다.", "튀는 높이가 줄어드는 빠르기 r이 작을수록 총 거리가 짧습니다."],
    q: "공이 멈출 때까지 걸리는 시간도 유한할까요? (높이 h에서 떨어지는 시간은 √h에 비례)",
    formula: "총 거리 = h + 2hr/(1 − r) = h(1 + r)/(1 − r)",
    en: { title: "A Bouncing Ball", desc: "Infinitely many bounces, finite distance." },
    view: { x: [-0.5, 16], y: [-0.8, 11] },
    params: [{ key: "h", label: "처음 높이 h (m)", min: 2, max: 10, step: 0.5, value: 10 }, { key: "r", label: "튀어 오르는 비율 r", min: 0.1, max: 0.9, step: 0.05, value: 0.6 }, { key: "n", label: "튄 횟수", min: 0, max: 20, step: 1, value: 6 }],
    anim: { key: "n", min: 0, max: 20, speed: 3, label: "튀기기" },
    draw(s, g) {
      g.seg([0, 0], [15.8, 0], { color: "ink", w: 2 });
      let x = 0.5; const dx = 15 / (s.n + 2); const pts = [[x, s.h]]; x += dx * 0.5; pts.push([x, 0]);
      for (let k = 1; k <= s.n; k++) { const hk = s.h * s.r ** k; pts.push([x + dx * 0.5, hk]); x += dx; pts.push([x, 0]); }
      g.path(pts, { color: "b", w: 2.4 });
      pts.forEach((p, i) => i % 2 === 0 && i && g.point(p, "", { color: "a", r: 3.5 }));
      g.circle([pts.at(-1)[0], 0.25], 0.25, { fill: "a", fo: 1, color: "ink", w: 1 });
      g.text([0.5, s.h], `${fmt(s.h)} m`, { dx: 6, anchor: "start", dy: -6, size: 12, bold: true });
    },
    metrics(s) { let S = s.h; for (let k = 1; k <= s.n; k++) S += 2 * s.h * s.r ** k; const T = (s.h * (1 + s.r)) / (1 - s.r); return [[`${s.n}번 튈 때까지의 거리`, `${fmt(S, 3)} m`], ["끝없이 튈 때의 총 거리", `${fmt(T, 3)} m`, "key"]]; },
    predict: [
      { q: "10 m에서 떨어뜨린 공이 매번 3/5만큼 튀어 오르면 총 거리는 몇 m?", set: (s) => Object.assign(s, { h: 10, r: 0.6, n: 2 }), reveal: (s) => (s.n = 20), answer: () => 40, tol: 1e-6, why: "10 × (1 + 0.6)/(1 − 0.6) = 40 m입니다." },
      { q: "r = 1/2이면 총 거리는 처음 높이의 몇 배?", set: (s) => Object.assign(s, { r: 0.5, n: 3 }), answer: () => 3, why: "(1 + 1/2)/(1 − 1/2) = 3배입니다." },
    ],
  },
  {
    id: "calc2-repeating-series", grade: II, unit: 1, lesson: "Ⅰ-5", title: "순환소수는 등비급수 — 0.3̇ = 3/10 + 3/100 + ⋯", type: "조작", time: "8분",
    tags: ["등비급수", "순환소수", "부분합"], links: ["calc2-geo-series", "m2-rep-to-frac"],
    desc: "순환소수 0.3̇은 3/10 + 3/100 + 3/1000 + ⋯, 곧 첫째항 3/10, 공비 1/10인 등비급수입니다. 항을 하나씩 더하며 부분합이 1/3에 다가가는 것을 막대로 보고, 등비급수의 합 공식으로 분수를 바로 구합니다.",
    obs: ["순환마디가 k자리면 공비는 1/10ᵏ입니다.", "등비급수 a/(1 − r)로 순환소수를 분수로 바꿀 수 있습니다.", "0.9̇도 9/10 ÷ (1 − 1/10) = 1입니다."],
    q: "0.1̇2̇3̇을 등비급수로 나타내고 분수로 바꾸어 봅시다.",
    formula: "0.ȧ = a/10 ÷ (1 − 1/10) = a/9",
    en: { title: "Repeating Decimals as Geometric Series", desc: "0.333… = 3/10 + 3/100 + …" },
    view: { x: [-0.5, 12.6], y: [-0.8, 8] },
    params: [{ key: "d", label: "순환소수", type: "seg", value: "a", options: Object.entries(REPD).map(([k, v]) => [k, v.n]) }, { key: "n", label: "더한 항의 수", min: 1, max: 8, step: 1, value: 3 }],
    anim: { key: "n", min: 1, max: 8, speed: 1, label: "항 더하기" },
    draw(s, g) {
      const K = REPD[s.d], L = 12; let S = 0;
      g.seg([0, 0.4], [L, 0.4], { color: "axis", w: 1.4 }).text([0, 0.4], "0", { dy: 16, size: 11 }).text([L, 0.4], "1", { dy: 16, size: 11 });
      for (let k = 0; k < s.n; k++) { const t = K.first * K.r ** k, y = 6.8 - k * 0.78; rect(g, S * L, y - 0.55, Math.max(0.02, t * L), 0.55, { fill: k % 2 ? "b" : "c", fo: 0.55, stroke: false }); g.text([S * L + t * L + 0.2, y - 0.27], fmt(t, 9), { anchor: "start", dy: 4, size: 11, mono: true, color: "muted" }); S += t; }
      g.seg([K.val * L, 0.2], [K.val * L, 7.4], { color: "e", w: 1.6, dash: "5 4" }).text([K.val * L, 7.4], K.vs, { dy: -4, bold: true, color: "e" });
      rect(g, 0, 0.6, S * L, 0.4, { fill: "a", fo: 0.6, stroke: false });
    },
    metrics(s) { const K = REPD[s.d]; let S = 0; for (let k = 0; k < s.n; k++) S += K.first * K.r ** k; return [["부분합", fmt(S, 9)], ["급수의 합 a/(1 − r)", `${fmt(K.first, 3)}/(1 − ${fmt(K.r, 2)}) = ${K.vs}`, "key"]]; },
    predict: [
      { q: "0.2̇7̇을 기약분수로 나타내면? (분수로)", set: (s) => Object.assign(s, { d: "b", n: 1 }), reveal: (s) => (s.n = 8), answer: () => 3 / 11, tol: 1e-6, show: () => "3/11", why: "0.27 ÷ (1 − 0.01) = 27/99 = 3/11입니다." },
      { q: "0.3̇의 첫째항과 공비의 곱은? (소수로)", set: (s) => Object.assign(s, { d: "a", n: 2 }), answer: () => 0.03, tol: 1e-9, why: "첫째항 0.3, 공비 0.1이므로 0.03입니다." },
    ],
  },
  {
    id: "calc2-xx", grade: II, unit: 2, lesson: "Ⅱ-6", title: "y = xˣ의 미분 — 로그를 취해 미분하기", type: "조작", time: "12분",
    tags: ["로그미분법", "지수함수", "극솟값"], links: ["calc2-e-slope", "calc2-chain"],
    desc: "밑과 지수가 모두 x인 y = xˣ은 거듭제곱의 미분도 지수함수의 미분도 바로 쓸 수 없습니다. 양변에 자연로그를 취해 ln y = x ln x로 바꾸어 미분하면 y′ = xˣ(ln x + 1)이고, x = 1/e에서 가장 작아짐을 접선으로 확인합니다.",
    obs: ["ln y = x ln x를 미분하면 y′/y = ln x + 1입니다.", "그래서 y′ = xˣ(ln x + 1)입니다.", "ln x + 1 = 0인 x = 1/e에서 극소(최소)입니다."],
    q: "y = x^(1/x)의 최댓값은 어디에서 생길까요?",
    formula: "(xˣ)′ = xˣ(ln x + 1)",
    en: { title: "Differentiating xˣ", desc: "Take logarithms first." },
    view: { x: [-0.2, 2.4], y: [-0.4, 3.4] },
    params: [{ key: "x", label: "x", min: 0.05, max: 2, step: 0.01, value: 1 }],
    anim: { key: "x", min: 0.05, max: 2, speed: 0.4, label: "점 움직이기", loop: "bounce" },
    draw(s, g) { const f = (x) => x ** x, d = (x) => x ** x * (Math.log(x) + 1); g.grid({ step: 0.5, labels: false }); g.fx(f, { color: "b", w: 3, from: 0.01 }); const P = [s.x, f(s.x)], m = d(s.x); g.seg([s.x - 0.5, P[1] - 0.5 * m], [s.x + 0.5, P[1] + 0.5 * m], { color: "a", w: 2.4 }); g.point(P, "", { color: "a" }); g.point([1 / Math.E, f(1 / Math.E)], "최소 (1/e)", { color: "e", r: 4, dy: 20 }); g.text([0, 3.2], "y = xˣ", { anchor: "start", bold: true, color: "b" }); },
    metrics(s) { const m = s.x ** s.x * (Math.log(s.x) + 1); return [["xˣ", fmt(s.x ** s.x, 4)], ["접선 기울기 xˣ(ln x + 1)", fmt(m, 4), "key"], ["최솟값", `(1/e)^(1/e) ≈ ${fmt((1 / Math.E) ** (1 / Math.E), 4)}`]]; },
    predict: [
      { q: "y = xˣ의 x = 1에서의 미분계수는?", set: (s) => (s.x = 0.5), reveal: (s) => (s.x = 1), answer: () => 1, why: "1¹ × (ln 1 + 1) = 1입니다." },
      { q: "y = xˣ이 가장 작아지는 x는? (소수 셋째 자리까지)", set: (s) => (s.x = 1.5), reveal: (s) => (s.x = 1 / Math.E), answer: () => 1 / Math.E, tol: 0.001, why: "ln x + 1 = 0에서 x = 1/e ≈ 0.368입니다." },
    ],
  },
  {
    id: "calc2-ln-tangent", grade: II, unit: 2, lesson: "Ⅱ-2", title: "y = ln x의 접선 기울기는 1/x", type: "조작", time: "10분",
    tags: ["로그함수의 미분", "접선", "도함수"], links: ["calc2-e-slope", "calc2-inverse-deriv"],
    desc: "y = ln x 위의 점을 움직이며 접선의 기울기를 아래 그래프에 높이로 찍으면 y = 1/x의 그래프가 그려집니다. y = ln x가 y = eˣ의 역함수라 기울기가 역수가 된다는 것과도 연결해 봅니다.",
    obs: ["x = a에서 y = ln x의 접선 기울기는 1/a입니다.", "x가 커질수록 기울기는 줄어 0에 가까워집니다.", "y = eˣ 위의 점 (b, a)에서의 기울기 a의 역수와 같습니다."],
    q: "y = ln(2x)의 도함수는 y = ln x의 도함수와 같을까요? 그 까닭은?",
    formula: "(ln x)′ = 1/x",
    en: { title: "The Slope of ln x Is 1/x", desc: "Trace slopes to draw 1/x." },
    view: { x: [-0.4, 6.4], y: [-2.6, 3.2] },
    params: [{ key: "x", label: "x", min: 0.2, max: 6, step: 0.01, value: 2 }],
    anim: { key: "x", min: 0.2, max: 6, speed: 1, label: "점 움직이기", loop: "bounce" },
    draw(s, g) { g.grid(); g.fx(Math.log, { color: "b", w: 3, from: 0.05 }); g.fx((x) => 1 / x, { color: "muted", w: 1.4, dash: "5 4", from: 0.33 }); g.param((x) => [x, 1 / x], 0.33, s.x, { color: "a", w: 3 }); const P = [s.x, Math.log(s.x)], m = 1 / s.x; g.seg([s.x - 1, P[1] - m], [s.x + 1, P[1] + m], { color: "c", w: 2.4 }); g.point(P, "", { color: "b" }).point([s.x, m], "", { color: "a" }); g.seg([s.x, P[1]], [s.x, m], { color: "muted", w: 1, dash: "3 4" }); g.text([0, 3], "파랑: y = ln x · 주황: 찍은 기울기 (y = 1/x)", { anchor: "start", bold: true, size: 13 }); },
    metrics(s) { const h = 1e-5; return [["접선 기울기 (수치)", fmt((Math.log(s.x + h) - Math.log(s.x - h)) / (2 * h), 5)], ["1/x", fmt(1 / s.x, 5), "key"]]; },
    predict: [
      { q: "y = ln x의 x = 4에서의 접선 기울기는?", set: (s) => (s.x = 1), reveal: (s) => (s.x = 4), answer: () => 0.25, tol: 1e-6, why: "1/4입니다." },
      { q: "y = ln(2x)의 x = 4에서의 미분계수는?", answer: () => 0.25, tol: 1e-6, why: "ln(2x) = ln 2 + ln x라 도함수가 1/x로 같습니다." },
    ],
  },
  {
    id: "calc2-second-test", grade: II, unit: 3, lesson: "Ⅲ-3", title: "이계도함수로 극값 판정 — f″의 부호만 보면", type: "조작", time: "12분",
    tags: ["이계도함수", "극대·극소", "판정법"], links: ["calc2-concavity", "calc2-ext-infl"],
    desc: "f′(a) = 0인 점에서 f″(a) < 0이면 위로 볼록이라 극대, f″(a) > 0이면 아래로 볼록이라 극소입니다. 함수를 바꾸며 f′의 부호 변화로 판정한 결과와 f″의 부호로 판정한 결과가 같음을 확인합니다.",
    obs: ["f′(a) = 0이고 f″(a) < 0이면 극대입니다.", "f′(a) = 0이고 f″(a) > 0이면 극소입니다.", "f″(a) = 0이면 이 방법으로는 판정할 수 없습니다."],
    q: "f(x) = x⁴은 x = 0에서 f″(0) = 0입니다. 극값일까요?",
    formula: "f′(a) = 0, f″(a) < 0 ⇒ 극대, f″(a) > 0 ⇒ 극소",
    en: { title: "The Second Derivative Test", desc: "The sign of f″ decides." },
    view: (s) => ({ x: [EXT[s.f].lo, EXT[s.f].hi], y: EXT[s.f].yr }),
    params: [{ key: "f", label: "함수", type: "select", value: "a", options: Object.entries(EXT).map(([k, v]) => [k, v.n]) }],
    draw(s, g) { const K = EXT[s.f]; g.grid({ step: 1, labels: false }); g.fx(K.f, { color: "b", w: 3 }); zeros(K.d, K.lo, K.hi).forEach((x) => { const dd = K.dd(x); g.point([x, K.f(x)], dd < 0 ? "극대 (f″ < 0)" : dd > 0 ? "극소 (f″ > 0)" : "판정 불가", { color: dd < 0 ? "a" : "c", dy: dd < 0 ? -10 : 20 }); }); g.text([g.xr[0] + 0.2, g.yr[1] - 0.08], K.n, { anchor: "start", bold: true, color: "b" }); },
    metrics(s) { const K = EXT[s.f], Z = zeros(K.d, K.lo, K.hi); return Z.map((x) => [`f′ = 0인 x = ${fmt(x, 3)}`, `f″ = ${fmt(K.dd(x), 3)} → ${K.dd(x) < 0 ? "극대" : "극소"}`]).concat([["극값의 개수", `${Z.length}개`, "key"]]); },
    predict: [
      { q: "y = x·e⁻ˣ은 x = 1에서 극대일까요, 극소일까요?", options: O("극대", "극소"), set: (s) => (s.f = "a"), answer: () => "a", why: "f″(1) = (1 − 2)e⁻¹ < 0이라 위로 볼록, 극대입니다." },
      { q: "y = x²·e⁻ˣ의 극값은 몇 개?", set: (s) => (s.f = "b"), answer: () => 2, why: "f′ = (2x − x²)e⁻ˣ = 0에서 x = 0(극소), x = 2(극대)입니다." },
    ],
  },
  {
    id: "calc2-ext-infl", grade: II, unit: 3, lesson: "Ⅲ-4", title: "극값과 변곡점을 함께 — f, f′, f″의 0을 한눈에", type: "조작", time: "12분",
    tags: ["변곡점", "극값", "그래프의 개형"], links: ["calc2-concavity", "calc2-second-test"],
    desc: "y = f(x) 위에 f′(x) = 0인 점(극값)과 f″(x) = 0이면서 부호가 바뀌는 점(변곡점)을 함께 표시합니다. 아래 띠에는 f′와 f″의 부호를 색으로 나타내어, 증가·감소와 위로·아래로 볼록이 그래프 모양과 어떻게 대응하는지 확인합니다.",
    obs: ["f′의 부호가 증가·감소를, f″의 부호가 볼록한 방향을 정합니다.", "변곡점에서 접선은 곡선을 가로지릅니다.", "극값과 변곡점은 번갈아 나타나는 경우가 많습니다."],
    q: "y = x·e^(−x²/2)의 변곡점이 3개인 까닭을 f″의 식으로 설명해 봅시다.",
    formula: "f″(a) = 0이고 부호가 바뀌면 (a, f(a))는 변곡점",
    en: { title: "Extrema and Inflection Points Together", desc: "Zeros of f, f′ and f″." },
    view: (s) => ({ x: [EXT[s.f].lo, EXT[s.f].hi], y: [EXT[s.f].yr[0] - 0.7, EXT[s.f].yr[1]] }),
    params: [{ key: "f", label: "함수", type: "select", value: "c", options: Object.entries(EXT).map(([k, v]) => [k, v.n]) }],
    draw(s, g) {
      const K = EXT[s.f], y0 = K.yr[0] - 0.25, y1 = K.yr[0] - 0.55, N = 160;
      g.grid({ step: 1, labels: false }); g.fx(K.f, { color: "b", w: 3 });
      for (let i = 0; i < N; i++) { const a = K.lo + ((K.hi - K.lo) * i) / N, b = a + (K.hi - K.lo) / N, m = (a + b) / 2; g.poly([[a, y0 - 0.1], [b, y0 - 0.1], [b, y0 + 0.1], [a, y0 + 0.1]], { fill: K.d(m) > 0 ? "c" : "e", fo: 0.55, stroke: false }); g.poly([[a, y1 - 0.1], [b, y1 - 0.1], [b, y1 + 0.1], [a, y1 + 0.1]], { fill: K.dd(m) > 0 ? "b" : "a", fo: 0.55, stroke: false }); }
      g.text([K.lo + 0.05, y0], "f′", { anchor: "start", dy: 4, size: 11, bold: true }).text([K.lo + 0.05, y1], "f″", { anchor: "start", dy: 4, size: 11, bold: true });
      zeros(K.d, K.lo, K.hi).forEach((x) => g.point([x, K.f(x)], "극값", { color: "a", r: 5, dy: K.dd(x) < 0 ? -10 : 20 }));
      zeros(K.dd, K.lo, K.hi).forEach((x) => g.point([x, K.f(x)], "변곡점", { color: "d", r: 5, hollow: true, dy: 20 }));
    },
    metrics(s) { const K = EXT[s.f]; return [["극값의 x", zeros(K.d, K.lo, K.hi).map((x) => fmt(x, 3)).join(", ")], ["변곡점의 x", zeros(K.dd, K.lo, K.hi).map((x) => fmt(x, 3)).join(", "), "key"], ["f′ 띠", "초록 = 증가 · 보라 = 감소"], ["f″ 띠", "파랑 = 아래로 볼록 · 주황 = 위로 볼록"]]; },
    predict: [
      { q: "y = x·e⁻ˣ의 변곡점의 x좌표는?", set: (s) => (s.f = "c"), reveal: (s) => (s.f = "a"), answer: () => 2, why: "f″ = (x − 2)e⁻ˣ = 0에서 x = 2, 부호가 바뀝니다." },
      { q: "y = x·e^(−x²/2)의 변곡점은 몇 개?", set: (s) => (s.f = "c"), answer: () => 3, why: "f″ = (x³ − 3x)e^(−x²/2) = 0에서 x = 0, ±√3입니다." },
    ],
  },
  {
    id: "calc2-ex-kx", grade: II, unit: 3, lesson: "Ⅲ-5", title: "eˣ = kx의 실근 — 접선 기울기 e가 갈림길", type: "조작", time: "12분",
    tags: ["방정식의 실근", "접선", "지수함수"], links: ["calc1-roots-k", "calc2-e-slope"],
    desc: "원점을 지나는 직선 y = kx와 y = eˣ이 만나는 횟수가 실근의 개수입니다. k를 바꾸며 직선이 곡선에 접하는 순간이 k = e(접점 (1, e))이고, k > e이면 두 근, k = e이면 중근, 0 ≤ k < e이면 근이 없고, k < 0이면 한 근임을 확인합니다.",
    obs: ["원점에서 y = eˣ에 그은 접선의 접점은 (1, e)입니다.", "그 접선의 기울기 e보다 크면 직선이 곡선을 두 번 지납니다.", "k < 0이면 음수 쪽에서 한 번 만납니다."],
    q: "ln x = kx의 실근이 두 개가 되는 k의 범위도 같은 방법으로 구해 봅시다.",
    formula: "eˣ = kx의 실근: k > e → 2개, k = e → 1개, 0 ≤ k < e → 0개, k < 0 → 1개",
    en: { title: "Roots of eˣ = kx", desc: "The tangent slope e is the boundary." },
    view: { x: [-3, 3.6], y: [-3, 9] },
    params: [{ key: "k", label: "직선의 기울기 k", min: -2, max: 6, step: 0.05, value: 2 }],
    anim: { key: "k", min: -2, max: 6, speed: 1, label: "k 바꾸기", loop: "bounce" },
    roots(s) { return zeros((x) => Math.exp(x) - s.k * x, -3, 3.6, 3000); },
    draw(s, g) { g.grid(); g.fx(Math.exp, { color: "b", w: 3 }); g.line([0, 0], [1, s.k], { color: "a", w: 2.6 }); g.line([0, 0], [1, Math.E], { color: "muted", w: 1.2, dash: "5 5" }); g.point([1, Math.E], "(1, e)", { color: "muted", r: 4 }); this.roots(s).forEach((x) => g.point([x, Math.exp(x)], "", { color: "e" })); g.text([g.xr[0] + 0.2, g.yr[1] - 0.5], `y = eˣ, y = ${fmt(s.k, 2)}x`, { anchor: "start", bold: true }); },
    metrics(s) { const n = Math.abs(s.k - Math.E) < 0.03 ? 1 : this.roots(s).length; return [["실근의 개수", `${n}개`, "key"], ["기준 기울기 e", fmt(Math.E, 4)]]; },
    predict: [
      { q: "원점에서 y = eˣ에 그은 접선의 기울기는? (소수 둘째 자리까지)", set: (s) => (s.k = 1), reveal: (s) => (s.k = Math.E), answer: () => Math.E, tol: 0.01, why: "접점 (t, eᵗ)에서 eᵗ = eᵗ·t이므로 t = 1, 기울기 e ≈ 2.72입니다." },
      { q: "eˣ = 4x의 실근은 몇 개?", set: (s) => (s.k = 2), reveal: (s) => (s.k = 4), answer: () => 2, why: "4 > e이므로 두 번 만납니다." },
    ],
  },
  {
    id: "calc2-ex-ineq", grade: II, unit: 3, lesson: "Ⅲ-5", title: "eˣ ≥ 1 + x — 접선은 늘 곡선 아래에", type: "조작", time: "10분",
    tags: ["부등식", "접선", "최솟값"], links: ["calc1-ineq-min", "calc2-ex-kx"],
    desc: "y = eˣ과 x = 0에서의 접선 y = 1 + x를 겹쳐 그리면 접선이 늘 곡선 아래에 있습니다. f(x) = eˣ − 1 − x의 최솟값이 f(0) = 0이라 eˣ ≥ 1 + x가 모든 실수에서 성립함을 그래프로 확인하고, ln x ≤ x − 1도 같은 방법으로 봅니다.",
    obs: ["아래로 볼록한 곡선은 접선보다 위에 있습니다.", "f′(x) = eˣ − 1 = 0인 x = 0에서 f가 최소입니다.", "ln x ≤ x − 1은 역함수 관계로 같은 부등식을 뒤집은 것입니다."],
    q: "eˣ ≥ ex(x = 1에서의 접선)도 성립할까요?",
    formula: "eˣ ≥ 1 + x (등호는 x = 0), ln x ≤ x − 1 (등호는 x = 1)",
    en: { title: "eˣ ≥ 1 + x", desc: "Tangent lines lie below convex curves." },
    view: { x: [-3, 3.4], y: [-2.4, 6] },
    params: [{ key: "m", label: "부등식", type: "seg", value: "e", options: [["e", "eˣ ≥ 1 + x"], ["l", "ln x ≤ x − 1"]] }, { key: "x", label: "x", min: -2.5, max: 3, step: 0.01, value: 1.2 }],
    draw(s, g) {
      g.grid();
      if (s.m === "e") { g.region(Math.exp, (x) => 1 + x, -3, 3, { fill: "c", fo: 0.15 }); g.fx(Math.exp, { color: "b", w: 3 }); g.fx((x) => 1 + x, { color: "a", w: 2.4 }); g.point([0, 1], "등호 (0, 1)", { color: "e" }); g.seg([s.x, 1 + s.x], [s.x, Math.exp(s.x)], { color: "e", w: 2.4 }); }
      else { const x = Math.max(0.05, s.x); g.region((t) => t - 1, (t) => Math.log(t), 0.05, 3.4, { fill: "c", fo: 0.15 }); g.fx(Math.log, { color: "b", w: 3, from: 0.03 }); g.fx((t) => t - 1, { color: "a", w: 2.4 }); g.point([1, 0], "등호 (1, 0)", { color: "e" }); g.seg([x, Math.log(x)], [x, x - 1], { color: "e", w: 2.4 }); }
    },
    metrics(s) { if (s.m === "e") return [["eˣ − (1 + x)", fmt(Math.exp(s.x) - 1 - s.x, 4), "key"], ["항상 0 이상?", "예"]]; const x = Math.max(0.05, s.x); return [["(x − 1) − ln x", fmt(x - 1 - Math.log(x), 4), "key"], ["항상 0 이상?", "예 (x > 0)"]]; },
    predict: [
      { q: "eˣ − 1 − x의 최솟값은?", set: (s) => Object.assign(s, { m: "e", x: 2 }), reveal: (s) => (s.x = 0), answer: () => 0, why: "x = 0에서 최소이고 값은 1 − 1 − 0 = 0입니다." },
      { q: "ln x ≤ x − 1에서 등호가 성립하는 x는?", set: (s) => Object.assign(s, { m: "l", x: 2.5 }), reveal: (s) => (s.x = 1), answer: () => 1, why: "x = 1에서 ln 1 = 0 = 1 − 1입니다." },
    ],
  },
  {
    id: "calc2-xlnx", grade: II, unit: 3, lesson: "Ⅲ-4", title: "y = x ln x의 개형 — 0 근처에서 어디로 갈까", type: "조작", time: "10분",
    tags: ["그래프의 개형", "극한", "로그함수"], links: ["calc2-xx", "calc2-ext-infl"],
    desc: "y = x ln x는 x → 0+일 때 x는 0으로, ln x는 −∞로 가지만 곱은 0에 다가갑니다. 그래프를 확대하며 이 극한을 확인하고, x = 1/e에서 최솟값 −1/e을 가지며 항상 아래로 볼록함을 f′, f″로 확인합니다.",
    obs: ["x → 0+일 때 x ln x → 0입니다(x가 더 빨리 0으로 갑니다).", "f′(x) = ln x + 1 = 0에서 x = 1/e, 최솟값 −1/e입니다.", "f″(x) = 1/x > 0이라 늘 아래로 볼록합니다."],
    q: "y = x² ln x의 x → 0+일 때의 극한은 무엇일까요?",
    formula: "f′(x) = ln x + 1, f″(x) = 1/x",
    en: { title: "The Shape of x ln x", desc: "What happens near zero?" },
    view: (s) => { const w = 2.6 / 10 ** s.z; return { x: [-0.15 * w, w], y: [-0.55 * w, 0.75 * w] }; },
    params: [{ key: "z", label: "원점 근처 확대", min: 0, max: 2, step: 0.05, value: 0, show: (v) => `${fmt(10 ** v, 0)}배` }],
    anim: { key: "z", min: 0, max: 2, speed: 0.5, label: "확대하기", loop: "bounce" },
    draw(s, g) { const f = (x) => x * Math.log(x); g.grid({ step: 10 ** Math.floor(Math.log10(g.xr[1] / 2)), labels: false }); g.fx(f, { color: "b", w: 3, from: 1e-6, n: 900 }); if (1 / Math.E < g.xr[1]) g.point([1 / Math.E, -1 / Math.E], "최소 (1/e, −1/e)", { color: "e", dy: 20 }); g.point([0, 0], "", { color: "a", hollow: true, r: 5 }); },
    metrics(s) { const x = 0.26 / 10 ** s.z; return [[`x = ${fmt(x, 5)}일 때 x ln x`, fmt(x * Math.log(x), 6)], ["x → 0+ 극한", "0", "key"], ["최솟값", `−1/e ≈ ${fmt(-1 / Math.E, 4)}`]]; },
    predict: [
      { q: "lim(x→0+) x ln x의 값은?", set: (s) => (s.z = 0), reveal: (s) => (s.z = 2), answer: () => 0, why: "x → 0의 속도가 ln x → −∞보다 빨라 곱은 0으로 갑니다." },
      { q: "y = x ln x의 최솟값은? (소수 셋째 자리까지)", answer: () => -1 / Math.E, tol: 0.001, why: "x = 1/e에서 (1/e)(−1) = −1/e ≈ −0.368입니다." },
    ],
  },
  {
    id: "calc2-path-distance", grade: II, unit: 4, lesson: "Ⅳ-7", title: "평면 위에서 움직인 거리 — 속력을 적분하면", type: "조작", time: "12분",
    tags: ["움직인 거리", "속력", "정적분"], links: ["calc-param-motion", "calc2-arc-length"],
    desc: "점 P(x(t), y(t))가 움직일 때 시각 0부터 t까지 움직인 거리는 속력 √(x′² + y′²)를 적분한 값입니다. 원 위를 도는 점, 직선 위를 오가는 점, 소용돌이를 그리는 점에서 움직인 거리와 처음 위치에서 떨어진 거리(변위의 크기)가 어떻게 다른지 비교합니다.",
    obs: ["움직인 거리 = ∫ |v(t)| dt = ∫ √(x′(t)² + y′(t)²) dt입니다.", "제자리로 돌아와도 움직인 거리는 0이 아닙니다.", "곡선의 길이 공식과 같은 꼴입니다."],
    q: "x = 2 sin t인 점이 0 ≤ t ≤ 2π 동안 움직인 거리는 얼마일까요?",
    formula: "s = ∫ₐᵇ √((dx/dt)² + (dy/dt)²) dt",
    en: { title: "Distance Traveled in the Plane", desc: "Integrate the speed." },
    view: { x: [-7.4, 7.4], y: [-5, 5] },
    params: [{ key: "m", label: "움직임", type: "select", value: "circ", options: Object.entries(MOT).map(([k, v]) => [k, v.n]) }, { key: "t", label: "시각 t", min: 0, max: 2 * Math.PI, step: Math.PI / 200, value: 3 }],
    anim: { key: "t", min: 0, max: 2 * Math.PI, speed: 0.8, label: "움직이기" },
    dist(s) { const K = MOT[s.m]; return simpson((u) => Math.hypot(...K.v(u)), 0, s.t, 600); },
    draw(s, g) { const K = MOT[s.m], P = K.p(s.t), V = K.v(s.t); g.grid(); g.param(K.p, 0, K.T, { color: "muted", w: 1.4, dash: "5 5" }); g.param(K.p, 0, s.t, { color: "b", w: 3, n: 600 }); g.seg(K.p(0), P, { color: "e", w: 1.6, dash: "3 4" }); g.vec(P, [P[0] + V[0] * 0.5, P[1] + V[1] * 0.5], { color: "a", label: "v" }); g.point(K.p(0), "출발", { color: "ink", r: 4 }).point(P, "P", { color: "a" }); },
    metrics(s) { const K = MOT[s.m], P = K.p(s.t), P0 = K.p(0); return [["움직인 거리", fmt(this.dist(s), 4), "key"], ["출발점에서 떨어진 거리", fmt(Math.hypot(P[0] - P0[0], P[1] - P0[1]), 4)], ["속력", fmt(Math.hypot(...K.v(s.t)), 3)]]; },
    predict: [
      { q: "반지름 2인 원을 한 바퀴 돈 거리는? (소수 둘째 자리까지)", set: (s) => Object.assign(s, { m: "circ", t: 1 }), reveal: (s) => (s.t = 2 * Math.PI), answer: () => 4 * Math.PI, tol: 0.01, why: "속력이 늘 2이므로 2 × 2π = 4π ≈ 12.57입니다." },
      { q: "x = 2 sin t가 0 ≤ t ≤ 2π 동안 움직인 거리는?", set: (s) => Object.assign(s, { m: "osc", t: 1 }), reveal: (s) => (s.t = 2 * Math.PI), answer: () => 8, tol: 0.01, why: "0 → 2 → −2 → 0으로 2 + 4 + 2 = 8입니다. 변위는 0입니다." },
    ],
  },
  {
    id: "calc2-sin2", grade: II, unit: 4, lesson: "Ⅳ-2", title: "∫sin²x dx — 사인과 코사인이 반씩 나눈 직사각형", type: "조작", time: "10분",
    tags: ["삼각함수의 적분", "반각 공식", "넓이"], links: ["calc2-sin-deriv", "calc2-substitution"],
    desc: "0부터 π까지 y = sin²x 아래 넓이(파랑)와 y = cos²x 아래 넓이(주황)를 위아래로 쌓으면 sin²x + cos²x = 1이라 높이 1, 가로 π인 직사각형이 됩니다. 두 넓이가 같으므로 각각 π/2임을 확인하고, 반각 공식 sin²x = (1 − cos 2x)/2로도 계산합니다.",
    obs: ["sin²x + cos²x = 1이므로 두 영역을 쌓으면 직사각형입니다.", "0부터 π까지 두 넓이는 대칭이라 같습니다.", "그래서 ∫₀^π sin²x dx = π/2입니다."],
    q: "∫₀^(π/2) sin²x dx는 얼마일까요?",
    formula: "\\sin^2x=\\frac{1-\\cos 2x}{2}\\quad\\int_0^\\pi\\sin^2x\\,dx=\\frac\\pi2",
    en: { title: "Integrating sin²x", desc: "sin² and cos² split a rectangle." },
    view: { x: [-0.4, 3.6], y: [-0.4, 1.5] },
    params: [{ key: "b", label: "위끝 b", min: 0.1, max: 3.1416, step: 0.01, value: 3.1416, show: (v) => piFmt(Math.round(v / (Math.PI / 12)) * (Math.PI / 12)) }],
    anim: { key: "b", min: 0.1, max: 3.1416, speed: 0.6, label: "구간 늘이기" },
    draw(s, g) { const S = (x) => Math.sin(x) ** 2; g.region(S, () => 0, 0, s.b, { fill: "b", fo: 0.45 }); g.region(() => 1, S, 0, s.b, { fill: "a", fo: 0.35 }); g.fx(S, { color: "b", w: 2.6, from: 0, to: Math.PI }); g.seg([0, 1], [Math.PI, 1], { color: "ink", w: 1.4, dash: "5 4" }); g.seg([0, 0], [3.4, 0], { color: "axis", w: 1.4 }); [[Math.PI / 2, "π/2"], [Math.PI, "π"]].forEach(([x, l]) => g.text([x, 0], l, { dy: 16, size: 12, color: "muted" })); g.text([0, 1.35], "파랑: sin²x 아래 · 주황: cos²x만큼", { anchor: "start", bold: true, size: 13 }); },
    metrics(s) { const A = s.b / 2 - Math.sin(2 * s.b) / 4; return [["∫₀ᵇ sin²x dx", fmt(A, 4), "key"], ["∫₀ᵇ cos²x dx", fmt(s.b - A, 4)], ["합 = b", fmt(s.b, 4)]]; },
    predict: [
      { q: "∫₀^π sin²x dx의 값은? (소수 둘째 자리까지)", set: (s) => (s.b = 1), reveal: (s) => (s.b = Math.PI), answer: () => Math.PI / 2, tol: 0.01, why: "직사각형 넓이 π의 절반이라 π/2 ≈ 1.57입니다." },
      { q: "∫₀^(π/2) sin²x dx의 값은? (소수 둘째 자리까지)", set: (s) => (s.b = 0.5), reveal: (s) => (s.b = Math.PI / 2), answer: () => Math.PI / 4, tol: 0.01, why: "반각 공식으로 π/4 ≈ 0.79입니다." },
    ],
  },
  {
    id: "calc2-circle-integral", grade: II, unit: 4, lesson: "Ⅳ-5", title: "적분으로 원의 넓이 πr² 다시 얻기", type: "조작", time: "12분",
    tags: ["정적분", "원의 넓이", "치환적분"], links: ["calc2-substitution", "m1-pizza-area"],
    desc: "원 x² + y² = r²를 세로 띠로 잘라 띠 넓이 2√(r² − x²)Δx를 더합니다. 띠를 얇게 할수록 합이 πr²에 다가가고, x = r sin θ로 치환하면 ∫₋ᵣʳ 2√(r² − x²) dx = πr²이 정확히 나옴을 확인합니다.",
    obs: ["원의 위쪽 반원은 y = √(r² − x²)입니다.", "띠 하나의 넓이는 2√(r² − xᵢ²)Δx입니다.", "x = r sin θ로 치환하면 ∫ r²cos²θ dθ가 되어 πr²/2 × 2 = πr²입니다."],
    q: "같은 방법으로 타원 x²/a² + y²/b² = 1의 넓이를 구해 봅시다.",
    formula: "∫₋ᵣʳ 2√(r² − x²) dx = πr²",
    en: { title: "Circle Area by Integration", desc: "Slices add to πr²." },
    view: { x: [-3.4, 3.4], y: [-2.6, 2.6] },
    params: [{ key: "r", label: "반지름 r", min: 1, max: 2.4, step: 0.1, value: 2 }, { key: "n", label: "띠의 개수", min: 2, max: 60, step: 1, value: 12 }],
    anim: { key: "n", min: 2, max: 60, speed: 8, label: "띠 늘리기" },
    sum(s) { const dx = (2 * s.r) / s.n; let A = 0; for (let i = 0; i < s.n; i++) { const x = -s.r + (i + 0.5) * dx; A += 2 * Math.sqrt(Math.max(0, s.r * s.r - x * x)) * dx; } return A; },
    draw(s, g) { const dx = (2 * s.r) / s.n; for (let i = 0; i < s.n; i++) { const x = -s.r + (i + 0.5) * dx, h = Math.sqrt(Math.max(0, s.r * s.r - x * x)); rect(g, x - dx / 2, -h, dx, 2 * h, { fill: i % 2 ? "b" : "c", fo: 0.35, color: "paper", w: 0.8 }); } g.circle([0, 0], s.r, { color: "ink", w: 2.6 }); g.seg([-3.3, 0], [3.3, 0], { color: "axis", w: 1 }).seg([0, -2.5], [0, 2.5], { color: "axis", w: 1 }); },
    metrics(s) { return [[`띠 ${s.n}개의 합`, fmt(this.sum(s), 5)], ["πr²", fmt(Math.PI * s.r * s.r, 5), "key"]]; },
    predict: [
      { q: "반지름 2인 원의 넓이를 적분으로 구하면? (소수 둘째 자리까지)", set: (s) => Object.assign(s, { r: 2, n: 4 }), reveal: (s) => (s.n = 60), answer: () => 4 * Math.PI, tol: 0.01, why: "∫₋₂² 2√(4 − x²) dx = 4π ≈ 12.57입니다." },
      { q: "치환 x = r sin θ를 쓰면 √(r² − x²)는 무엇이 될까요?", options: O("r cos θ", "r sin θ", "r tan θ"), answer: () => "a", why: "√(r² − r²sin²θ) = r cos θ (−π/2 ≤ θ ≤ π/2)입니다." },
    ],
  },
  {
    id: "calc2-cycloid-area", grade: II, unit: 4, lesson: "Ⅳ-5 탐구", title: "사이클로이드 아래 넓이 — 바퀴 넓이의 3배", type: "조작", time: "12분",
    tags: ["매개변수", "넓이", "사이클로이드"], links: ["calc2-cycloid", "lab-brachistochrone"],
    desc: "바퀴가 한 바퀴 구를 때 바퀴 위의 점이 그리는 사이클로이드 x = r(t − sin t), y = r(1 − cos t) 아래 넓이를 ∫y dx = ∫y(t)x′(t) dt로 구합니다. 띠를 늘리며 넓이가 바퀴 넓이 πr²의 정확히 3배인 3πr²로 다가가는 것을 확인합니다.",
    obs: ["매개변수로 나타낸 곡선 아래 넓이는 ∫ y(t)·x′(t) dt입니다.", "∫₀^(2π) r²(1 − cos t)² dt = 3πr²입니다.", "갈릴레이는 종이를 오려 무게를 재서 이 값을 어림했다고 합니다."],
    q: "사이클로이드 한 아치의 길이(8r)도 같은 방법으로 구해 봅시다.",
    formula: "S=\\int_0^{2\\pi}y(t)x'(t)\\,dt=3\\pi r^2",
    en: { title: "Area Under a Cycloid", desc: "Three times the wheel." },
    view: { x: [-0.6, 13.2], y: [-1.4, 4.6] },
    params: [{ key: "r", label: "바퀴 반지름 r", min: 1, max: 2, step: 0.1, value: 2 }, { key: "n", label: "띠의 개수", min: 4, max: 80, step: 1, value: 16 }],
    anim: { key: "n", min: 4, max: 80, speed: 10, label: "띠 늘리기" },
    P(s, t) { return [s.r * (t - Math.sin(t)), s.r * (1 - Math.cos(t))]; },
    sum(s) { const X = 2 * Math.PI * s.r, dx = X / s.n; let A = 0; for (let i = 0; i < s.n; i++) { const xm = (i + 0.5) * dx; let lo = 0, hi = 2 * Math.PI; for (let k = 0; k < 40; k++) { const m = (lo + hi) / 2; if (s.r * (m - Math.sin(m)) < xm) lo = m; else hi = m; } A += s.r * (1 - Math.cos(lo)) * dx; } return A; },
    draw(s, g) { const X = 2 * Math.PI * s.r, dx = X / s.n; for (let i = 0; i < s.n; i++) { const xm = (i + 0.5) * dx; let lo = 0, hi = 2 * Math.PI; for (let k = 0; k < 40; k++) { const m = (lo + hi) / 2; if (s.r * (m - Math.sin(m)) < xm) lo = m; else hi = m; } const h = s.r * (1 - Math.cos(lo)); rect(g, i * dx, 0, dx, h, { fill: i % 2 ? "b" : "c", fo: 0.35, color: "paper", w: 0.6 }); } g.param((t) => this.P(s, t), 0, 2 * Math.PI, { color: "ink", w: 2.6 }); g.circle([Math.PI * s.r, s.r], s.r, { color: "a", w: 1.6, dash: "5 4" }); g.seg([-0.4, 0], [13, 0], { color: "axis", w: 1.4 }); g.text([Math.PI * s.r, s.r], "바퀴", { dy: 5, size: 12, color: "a", bold: true }); },
    metrics(s) { return [[`띠 ${s.n}개의 합`, fmt(this.sum(s), 4)], ["3πr²", fmt(3 * Math.PI * s.r * s.r, 4), "key"], ["바퀴 넓이 πr²", fmt(Math.PI * s.r * s.r, 4)]]; },
    predict: [
      { q: "사이클로이드 한 아치 아래 넓이는 바퀴 넓이의 몇 배?", set: (s) => Object.assign(s, { r: 2, n: 4 }), reveal: (s) => (s.n = 80), answer: () => 3, why: "∫₀^(2π) r²(1 − cos t)² dt = 3πr²입니다." },
      { q: "r = 1일 때 넓이는? (소수 둘째 자리까지)", set: (s) => Object.assign(s, { r: 1, n: 80 }), answer: () => 3 * Math.PI, tol: 0.01, why: "3π ≈ 9.42입니다." },
    ],
  },
  {
    id: "calc2-taylor", grade: II, unit: 2, lesson: "Ⅱ 탐구", title: "다항식으로 eˣ와 sin x 흉내 내기 (보충)", type: "조작", time: "12분",
    tags: ["근삿값", "다항식", "도함수"], links: ["calc2-nth-deriv", "calc2-e-limit"],
    desc: "x = 0에서 함숫값과 1계, 2계, 3계, …도함수의 값이 모두 같은 다항식을 만들면 eˣ는 1 + x + x²/2! + x³/3! + ⋯, sin x는 x − x³/3! + x⁵/5! − ⋯이 됩니다. 항을 늘리며 다항식이 원래 곡선과 겹치는 구간이 넓어짐을 확인합니다. (교과서 밖 보충 탐구입니다.)",
    obs: ["항을 하나 늘릴 때마다 x = 0 근처에서 더 잘 맞습니다.", "eˣ의 근사식에 x = 1을 넣으면 e의 근삿값이 나옵니다.", "계산기도 이런 다항식으로 삼각함수 값을 구합니다."],
    q: "1 + 1 + 1/2 + 1/6 + 1/24을 계산해 e와 비교해 봅시다.",
    formula: "eˣ ≈ 1 + x + x²/2! + ⋯ + xⁿ/n!",
    en: { title: "Polynomial Approximations (Enrichment)", desc: "Taylor polynomials for eˣ and sin x." },
    view: { x: [-6.4, 6.4], y: [-4.4, 6] },
    params: [{ key: "f", label: "함수", type: "seg", value: "exp", options: [["exp", "eˣ"], ["sin", "sin x"]] }, { key: "n", label: "항의 수", min: 1, max: 9, step: 1, value: 3 }],
    anim: { key: "n", min: 1, max: 9, speed: 1, label: "항 늘리기" },
    T(s, x) { const K = TAY[s.f]; let t = 0; for (let k = 0; k < s.n; k++) t += K.c(k) * x ** K.pow(k); return t; },
    draw(s, g) { const K = TAY[s.f]; g.grid({ every: 2 }); g.fx(K.f, { color: "b", w: 5, opacity: 0.4 }); g.fx((x) => this.T(s, x), { color: "a", w: 2.6 }); g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], `파랑: ${K.n} · 주황: 항 ${s.n}개짜리 다항식`, { anchor: "start", bold: true }); },
    metrics(s) { const K = TAY[s.f]; return [["x = 1에서 다항식 값", fmt(this.T(s, 1), 6)], [`x = 1에서 ${K.n}`, fmt(K.f(1), 6), "key"], ["x = 3에서의 차", fmt(Math.abs(this.T(s, 3) - K.f(3)), 4)]]; },
    predict: [
      { q: "eˣ의 근사식 항 5개(1 + x + x²/2 + x³/6 + x⁴/24)에 x = 1을 넣은 값은? (소수 넷째 자리까지)", set: (s) => Object.assign(s, { f: "exp", n: 2 }), reveal: (s) => (s.n = 5), answer: () => 1 + 1 + 1 / 2 + 1 / 6 + 1 / 24, tol: 0.0005, why: "2.7083으로 e ≈ 2.7183에 가깝습니다." },
      { q: "sin x의 근사식 x − x³/6에서 x³의 계수는? (분수나 소수로)", set: (s) => Object.assign(s, { f: "sin", n: 1 }), reveal: (s) => (s.n = 2), answer: () => -1 / 6, tol: 1e-6, why: "sin‴(0) = −1이므로 −1/3! = −1/6입니다." },
    ],
  },
  {
    id: "calc2-euler", grade: II, unit: 2, lesson: "Ⅱ 탐구", title: "오일러 방법 — 기울기를 따라 걸어 eˣ 그리기 (보충)", type: "조작", time: "12분",
    tags: ["근삿값", "도함수", "e"], links: ["calc2-e-slope", "calc2-taylor"],
    desc: "'기울기가 자기 자신의 높이와 같은 곡선'(y′ = y, y(0) = 1)을 모른다고 생각하고, 지금 높이만큼의 기울기로 h만큼씩 걸어 갑니다. 걸음을 잘게 할수록 꺾은선이 y = eˣ에 다가가고, x = 1에서의 높이가 (1 + 1/n)ⁿ → e임을 확인합니다. (교과서 밖 보충 탐구입니다.)",
    obs: ["한 걸음 뒤의 높이 = 지금 높이 × (1 + h)입니다.", "n걸음으로 1까지 가면 (1 + 1/n)ⁿ, 곧 e의 정의와 같습니다.", "걸음이 클수록 실제 곡선보다 아래로 처집니다."],
    q: "y′ = −y, y(0) = 1이면 어떤 곡선이 될까요?",
    formula: "yₖ₊₁ = yₖ + h·yₖ = (1 + h)yₖ",
    en: { title: "Euler's Method (Enrichment)", desc: "Walk along slopes to draw eˣ." },
    view: { x: [-0.4, 6.6], y: [-0.4, 7.6] },
    params: [{ key: "n", label: "1까지 걸음 수 n", min: 1, max: 50, step: 1, value: 4 }],
    anim: { key: "n", min: 1, max: 50, speed: 6, label: "걸음 늘리기" },
    draw(s, g) { const h = 1 / s.n, pts = [[0, 1]]; let y = 1; for (let k = 1; k <= 2 * s.n; k++) { y *= 1 + h; pts.push([3 * k * h, y]); } g.seg([0, 0], [6.4, 0], { color: "axis", w: 1.2 }).seg([0, 0], [0, 7.5], { color: "axis", w: 1.2 }); [0.5, 1, 1.5, 2].forEach((x) => g.text([3 * x, 0], fmt(x, 1), { dy: 14, size: 11, color: "muted" })); g.param((t) => [3 * t, Math.exp(t)], 0, 2, { color: "b", w: 4, opacity: 0.4 }); g.path(pts, { color: "a", w: 2.4 }); if (s.n <= 12) pts.forEach((p) => g.point(p, "", { color: "a", r: 3 })); g.seg([3, 0], [3, 7.4], { color: "muted", w: 1, dash: "3 4" }); g.point([3, (1 + h) ** s.n], "", { color: "e" }); g.text([0, 7.3], "파랑: y = eˣ · 주황: 오일러 방법", { anchor: "start", bold: true }); },
    metrics(s) { return [["x = 1에서의 높이 (1 + 1/n)ⁿ", fmt((1 + 1 / s.n) ** s.n, 6), "key"], ["e", fmt(Math.E, 6)], ["차", fmt(Math.E - (1 + 1 / s.n) ** s.n, 6)]]; },
    predict: [
      { q: "걸음 2번(h = 1/2)으로 x = 1에 가면 높이는?", set: (s) => (s.n = 1), reveal: (s) => (s.n = 2), answer: () => 2.25, tol: 1e-9, why: "(1 + 1/2)² = 2.25입니다." },
      { q: "걸음을 한없이 잘게 하면 x = 1에서의 높이는?", options: O("e", "2", "3"), set: (s) => (s.n = 4), reveal: (s) => (s.n = 50), answer: () => "a", why: "(1 + 1/n)ⁿ → e입니다." },
    ],
  },
];
