// 2026-10 추가 실험 18개 — 얇은 단원 채우기 (중3 인수분해·이차방정식, 공통수학2 명제·유리함수, 공통수학1 경우의 수, 수학과 문화)
import { fmt, frac, clamp, lerp } from "./hs-core.js";

const EN = () => typeof document !== "undefined" && document.documentElement.lang === "en";
const T = (ko, en) => (EN() ? en : ko);
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
const won = (n) => (EN() ? "₩" + Math.round(n).toLocaleString("en-US") : Math.round(n).toLocaleString("ko-KR") + "원");
const isPrime = (n) => { if (!Number.isInteger(n) || n < 2) return false; for (let d = 2; d * d <= n; d++) if (n % d === 0) return false; return true; };
const factorize = (n) => { const out = []; let m = Math.abs(n); for (let d = 2; d * d <= m; d++) while (m % d === 0) { out.push(d); m /= d; } if (m > 1) out.push(m); return out; };
const sgn = (v) => (v < 0 ? "−" : "+");
const term = (k, first = false) => (first ? (k < 0 ? "−" : "") : ` ${sgn(k)} `) + fmt(Math.abs(k));
// 가로·세로 단위가 크게 다른 그래프용 축: 자료값 (u, v) → 그림 좌표 (X(u), Y(v)), 눈금 글자는 자료값 그대로
function axes(g, o) {
  const { X, Y, xs, ys, xName, yName, x0 = xs[0], x1 = xs[xs.length - 1], y0 = ys[0], y1 = ys[ys.length - 1] } = o;
  for (const u of xs) { g.seg([X(u), Y(y0)], [X(u), Y(y1)], { color: "grid", w: 1, layer: "fill" }); g.text([X(u), Y(y0)], o.xl ? o.xl(u) : fmt(u), { size: 11, color: "muted", dy: 16 }); }
  for (const v of ys) { g.seg([X(x0), Y(v)], [X(x1), Y(v)], { color: "grid", w: 1, layer: "fill" }); g.text([X(x0), Y(v)], o.yl ? o.yl(v) : fmt(v), { size: 11, color: "muted", dx: -6, dy: 4, anchor: "end" }); }
  g.seg([X(x0), Y(y0)], [X(x1), Y(y0)], { color: "axis", w: 1.6 }); g.seg([X(x0), Y(y0)], [X(x0), Y(y1)], { color: "axis", w: 1.6 });
  if (xName) g.text([X(x1), Y(y0)], xName, { size: 12, color: "muted", dy: 30, anchor: "end" });
  if (yName) g.text([X(x0), Y(y1)], yName, { size: 12, color: "muted", dy: -10, anchor: "start" });
}
const RNG = (seed) => { let x = (Math.abs(seed | 0) * 7919 + 104729) % 2147483647 || 1; return () => (x = (x * 16807) % 2147483647) / 2147483647; };

export default [
  // ═════════ 중3 Ⅱ 다항식의 곱셈과 인수분해 ═════════
  {
    id: "m3-diff-squares", grade: 3, unit: 2, lesson: "2.2", title: "합차 공식 — 잘라 붙이면 (a + b)(a − b)", type: "조작", time: "10분",
    tags: ["곱셈 공식", "인수분해", "넓이 모델"], links: ["m3-mult-formula", "m3-mental-math"],
    desc: "한 변이 a인 정사각형에서 한 변이 b인 정사각형을 떼어 낸 ㄱ자 모양을 두 직사각형으로 잘라 옮겨 붙이면 가로 a + b, 세로 a − b인 직사각형이 됩니다. 넓이가 그대로이므로 a² − b² = (a + b)(a − b)입니다.",
    obs: ["떼어 낸 뒤 남은 넓이는 a² − b²입니다.", "아래쪽 직사각형(가로 b, 세로 a − b)을 옆으로 옮겨 붙입니다.", "새 직사각형의 가로는 a + b, 세로는 a − b입니다."],
    q: "51² − 49²를 계산기 없이 구하려면 어떻게 할까요?",
    formula: "a² − b² = (a + b)(a − b)",
    view: { x: [-0.6, 13.2], y: [-1.4, 8.6] },
    params: [
      { key: "a", label: "큰 정사각형의 한 변 a", min: 3, max: 8, step: 1, value: 7 },
      { key: "b", label: "떼어 낼 정사각형의 한 변 b", min: 1, max: 6, step: 1, value: 3 },
      { key: "t", label: "옮겨 붙이기", min: 0, max: 1, step: 0.02, value: 0 },
    ],
    derive(s) { if (s.b >= s.a) s.b = s.a - 1; },
    anim: { key: "t", min: 0, max: 1, speed: 0.4, label: "옮겨 붙이기" },
    draw(s, g) {
      const { a, b, t } = s;
      // 위쪽 큰 조각: 가로 a, 세로 a − b (그대로)
      rect(g, 0, b, a, a - b, { fill: "b", fo: 0.35, color: "b", w: 2 });
      // 오른쪽 아래 조각: 가로 a − b, 세로 b → 회전해 위쪽 조각 오른쪽에 붙음 (가로 b, 세로 a − b)
      const from = [[b, 0], [a, 0], [a, b], [b, b]], to = [[a, b], [a + b, b], [a + b, a], [a, a]];
      const pts = from.map((p, i) => lerp(p, to[(i + 1) % 4], t));
      g.poly(pts, { fill: "c", fo: 0.45, color: "c", w: 2 });
      if (t < 0.02) rect(g, 0, 0, b, b, { fill: "muted", fo: 0.08, color: "muted", w: 1.4, dash: "5 5" });
      g.text([a / 2, a + 0.45], `a = ${a}`, { bold: true, size: 14 });
      if (t > 0.98) { g.text([(a + b) / 2, b - 0.45], `a + b = ${a + b}`, { bold: true, size: 14, color: "a" }); g.text([a + b + 0.6, (a + b) / 2], `a − b = ${a - b}`, { bold: true, size: 14, color: "a", anchor: "start" }); }
      else g.text([b / 2, b / 2], `b² = ${b * b}`, { size: 13, color: "muted" });
      g.text([6.3, -0.8], T(`넓이 ${a}² − ${b}² = ${a * a - b * b}`, `Area ${a}² − ${b}² = ${a * a - b * b}`), { bold: true, size: 15 });
    },
    metrics(s) { return [["a² − b²", `${s.a * s.a} − ${s.b * s.b} = ${s.a * s.a - s.b * s.b}`], ["(a + b)(a − b)", `${s.a + s.b} × ${s.a - s.b} = ${(s.a + s.b) * (s.a - s.b)}`, "key"]]; },
    predict: [
      { q: "51² − 49²의 값은?", answer: () => 200, why: "(51 + 49)(51 − 49) = 100 × 2 = 200입니다." },
      { q: "x² − 9를 인수분해하면 (x + 3)(x − □)입니다. □는?", answer: () => 3, why: "9 = 3²이므로 x² − 3² = (x + 3)(x − 3)입니다." },
    ],
  },
  {
    id: "m3-sum-product", grade: 3, unit: 2, lesson: "2.3", title: "곱이 c, 합이 b인 두 수 — x² + bx + c 인수분해", type: "조작", time: "10분",
    tags: ["인수분해", "약수", "대수 타일"], links: ["m3-tile-factor", "m3-diff-squares"],
    desc: "x² + bx + c = (x + p)(x + q)가 되려면 p + q = b, pq = c여야 합니다. c를 두 정수의 곱으로 나타내는 모든 짝을 늘어놓고, 합이 b인 짝을 찾아 직사각형 넓이 모델로 확인합니다.",
    obs: ["c가 양수이면 두 수의 부호가 같고, 음수이면 부호가 다릅니다.", "곱이 c인 짝은 유한하므로 차례로 확인하면 반드시 찾거나 없음을 알 수 있습니다.", "맞는 짝이 없으면 정수 계수로는 인수분해되지 않습니다."],
    q: "x² + x − 12를 인수분해하려면 곱이 −12, 합이 1인 두 수를 찾아야 합니다. 어떤 두 수일까요?",
    formula: "x² + bx + c = (x + p)(x + q) ⇔ p + q = b, pq = c",
    view: { x: [0, 12], y: [-0.8, 8.4] },
    params: [
      { key: "b", label: "b (x의 계수)", min: -10, max: 10, step: 1, value: 5 },
      { key: "c", label: "c (상수항)", min: -24, max: 24, step: 1, value: 6 },
    ],
    pairs(s) { const out = []; const c = s.c; if (c === 0) return [[0, s.b]]; for (let p = -Math.abs(c); p <= Math.abs(c); p++) if (p && c % p === 0) { const q = c / p; if (p <= q) out.push([p, q]); } return out; },
    hit(s) { return this.pairs(s).find(([p, q]) => p + q === s.b) || null; },
    draw(s, g) {
      const P = this.pairs(s), h = this.hit(s);
      g.text([6, 8], T(`곱이 ${s.c}인 정수 짝`, `Integer pairs with product ${s.c}`), { bold: true, size: 15 });
      const cols = Math.min(4, Math.max(1, P.length)), rows = Math.ceil(P.length / cols);
      P.forEach(([p, q], i) => { const cx = 1.5 + (i % cols) * 3, cy = 6.6 - Math.floor(i / cols) * 1.15, ok = h && p === h[0] && q === h[1]; rect(g, cx - 1.3, cy - 0.45, 2.6, 0.9, { fill: ok ? "a" : "b", fo: ok ? 0.45 : 0.08, color: ok ? "a" : "grid", w: ok ? 2.4 : 1 }); g.text([cx, cy - 0.15], `${fmt(p)}, ${fmt(q)}  (${T("합", "sum")} ${fmt(p + q)})`, { size: 13, bold: ok }); });
      const yb = 6.6 - rows * 1.15 - 0.6;
      g.text([6, Math.max(0.2, yb)], h ? `x² ${s.b ? term(s.b) + "x" : ""}${term(s.c)} = (x ${sgn(h[0])} ${fmt(Math.abs(h[0]))})(x ${sgn(h[1])} ${fmt(Math.abs(h[1]))})` : T("합이 b인 짝이 없어요 — 정수로 인수분해되지 않아요", "No pair adds to b — not factorable over the integers"), { bold: true, size: 16, color: h ? "a" : "d" });
    },
    metrics(s) { const h = this.hit(s); return [[T("곱이 c인 짝의 수", "Pairs with product c"), fmt(this.pairs(s).length)], [T("찾은 두 수", "The two numbers"), h ? `${fmt(h[0])}, ${fmt(h[1])}` : "—", "key"]]; },
    predict: [
      { q: "x² + 5x + 6 = (x + p)(x + q)에서 p와 q 중 큰 수는?", answer: () => 3, why: "곱 6, 합 5인 두 수는 2와 3입니다." },
      { q: "x² + x − 12를 인수분해했을 때 두 일차식의 상수항 중 작은 수는?", set: (s) => Object.assign(s, { b: 1, c: -12 }), answer: () => -3, why: "곱 −12, 합 1인 두 수는 −3과 4이므로 (x − 3)(x + 4)입니다." },
    ],
  },
  {
    id: "m3-mental-math", grade: 3, unit: 2, lesson: "2.1 활용", title: "98 × 102 암산의 비밀 — 곱셈 공식으로 빠르게", type: "조작", time: "8분",
    tags: ["곱셈 공식", "암산", "넓이 모델"], links: ["m3-diff-squares", "m3-mult-formula"],
    desc: "100 근처의 두 수를 곱할 때 (100 − d)(100 + d) = 10000 − d²나 (100 + d)² = 10000 + 200d + d²를 쓰면 암산이 쉬워집니다. 넓이 그림으로 각 항이 어디에서 오는지 확인합니다.",
    obs: ["(a − d)(a + d)는 a²에서 d²만 빼면 됩니다.", "(a + d)²는 a² 옆에 두 직사각형 2ad와 작은 정사각형 d²가 붙습니다.", "기준 a는 10, 50, 100처럼 계산하기 쉬운 수로 고릅니다."],
    q: "103²을 암산하는 가장 빠른 방법은 무엇일까요?",
    formula: "(a − d)(a + d) = a² − d²,  (a + d)² = a² + 2ad + d²",
    view: { x: [-0.5, 12.5], y: [-1.6, 8.6] },
    params: [
      { key: "kind", label: "계산", type: "seg", options: [["diff", "(a − d)(a + d)"], ["sq", "(a + d)²"]], value: "diff" },
      { key: "a", label: "기준 수 a", type: "select", options: [[10, "10"], [50, "50"], [100, "100"]], value: 100 },
      { key: "d", label: "차이 d", min: 1, max: 9, step: 1, value: 2 },
    ],
    draw(s, g) {
      const { a, d } = s, S = 6.4, k = S / (a + d), A = a * k, D = d * k;
      if (s.kind === "diff") {
        rect(g, 0, 0, A + D, A - D, { fill: "b", fo: 0.3, color: "b", w: 2 });
        rect(g, A - D, A - D, D * 2, D, { fill: "muted", fo: 0.1, color: "muted", w: 1, dash: "4 4" });
        g.text([(A + D) / 2, -0.5], `${a} + ${d} = ${a + d}`, { size: 13, bold: true }); g.text([A + D + 0.4, (A - D) / 2], `${a} − ${d} = ${a - d}`, { anchor: "start", size: 13, bold: true });
        g.text([6, 8], `${a - d} × ${a + d} = ${a}² − ${d}² = ${a * a} − ${d * d} = ${a * a - d * d}`, { bold: true, size: 15, color: "a" });
      } else {
        rect(g, 0, 0, A, A, { fill: "b", fo: 0.3, color: "b", w: 2 }); rect(g, A, 0, D, A, { fill: "c", fo: 0.4, color: "c", w: 1.6 }); rect(g, 0, A, A, D, { fill: "c", fo: 0.4, color: "c", w: 1.6 }); rect(g, A, A, D, D, { fill: "d", fo: 0.5, color: "d", w: 1.6 });
        g.text([A / 2, A / 2], `${a}² = ${a * a}`, { size: 14, bold: true }); g.text([A + D + 0.3, A / 2], `${a}×${d} = ${a * d}`, { anchor: "start", size: 13 });
        g.text([6, 8], `${a + d}² = ${a * a} + 2×${a * d} + ${d * d} = ${(a + d) ** 2}`, { bold: true, size: 15, color: "a" });
      }
    },
    metrics(s) { const { a, d } = s; return s.kind === "diff" ? [[T("곱", "Product"), `${a - d} × ${a + d}`], [T("공식으로", "By the identity"), `${a * a} − ${d * d}`], [T("값", "Value"), fmt(a * a - d * d), "key"]] : [[T("제곱", "Square"), `${a + d}²`], [T("공식으로", "By the identity"), `${a * a} + ${2 * a * d} + ${d * d}`], [T("값", "Value"), fmt((a + d) ** 2), "key"]]; },
    predict: [
      { q: "98 × 102의 값은?", answer: () => 9996, why: "(100 − 2)(100 + 2) = 10000 − 4 = 9996입니다." },
      { q: "103²의 값은?", set: (s) => Object.assign(s, { kind: "sq", a: 100, d: 3 }), answer: () => 10609, why: "10000 + 2×100×3 + 9 = 10609입니다." },
    ],
  },
  // ═════════ 중3 Ⅲ 이차방정식 ═════════
  {
    id: "m3-golden-quad", grade: 3, unit: 3, lesson: "3.3 활용", title: "황금비와 이차방정식 — 정사각형을 잘라도 같은 모양", type: "조작", time: "10분",
    tags: ["이차방정식", "황금비", "근의 공식", "닮음"], links: ["m3-quad-formula", "lab-golden-spiral"],
    desc: "가로 x, 세로 1인 직사각형에서 한 변이 1인 정사각형을 잘라 냈을 때 남은 직사각형이 처음과 닮으려면 x : 1 = 1 : (x − 1), 즉 x² − x − 1 = 0이어야 합니다. x를 바꾸어 닮음 비를 비교하고 근의 공식으로 황금비 (1 + √5)/2를 구합니다.",
    obs: ["남은 직사각형의 긴 변 : 짧은 변 = 1 : (x − 1)입니다.", "두 비가 같아지는 x에서 f(x) = x² − x − 1 = 0입니다.", "그 x ≈ 1.618에서는 정사각형을 몇 번 잘라 내도 같은 모양이 남습니다."],
    q: "x² − x − 1 = 0의 두 근 중 양수인 근은 무엇일까요?",
    formula: "x : 1 = 1 : (x − 1)  ⇒  x² − x − 1 = 0  ⇒  x = (1 + √5)/2",
    view: { x: [-0.4, 11.4], y: [-1.6, 7.4] },
    params: [
      { key: "x", label: "가로 x (세로는 1)", min: 1.2, max: 2.4, step: 0.002, value: 1.5 },
      { key: "n", label: "잘라 내는 횟수", min: 1, max: 5, step: 1, value: 1 },
    ],
    draw(s, g) {
      const K = 4.6, X = s.x * K; let x0 = 0, y0 = 0, w = X, h = K, horiz = true;
      rect(g, 0, 0, X, K, { color: "ink", w: 2.2 });
      for (let i = 0; i < s.n && w > 0.05 && h > 0.05; i++) {
        if (w >= h) { rect(g, x0, y0, h, h, { fill: ["b", "c", "e", "a", "d"][i % 5], fo: 0.35, color: "ink", w: 1.4 }); x0 += h; w -= h; } else { rect(g, x0, y0 + h - w, w, w, { fill: ["b", "c", "e", "a", "d"][i % 5], fo: 0.35, color: "ink", w: 1.4 }); h -= w; }
        horiz = !horiz;
      }
      const r1 = s.x, r2 = 1 / (s.x - 1);
      g.text([5.5, 6.4], T(`처음 비 ${fmt(r1, 3)} · 남은 직사각형의 비 ${fmt(Math.max(r2, 1 / r2), 3)}`, `Original ratio ${fmt(r1, 3)} · remaining ratio ${fmt(Math.max(r2, 1 / r2), 3)}`), { bold: true, size: 14, color: Math.abs(r1 - r2) < 0.01 ? "a" : "ink" });
      g.text([5.5, -0.9], `f(x) = x² − x − 1 = ${fmt(s.x * s.x - s.x - 1, 3)}`, { size: 15, bold: true, color: Math.abs(s.x * s.x - s.x - 1) < 0.01 ? "a" : "muted" });
    },
    metrics(s) { return [[T("처음 직사각형의 비", "Original ratio"), fmt(s.x, 3)], [T("남은 직사각형의 비", "Remaining ratio"), fmt(Math.max(1 / (s.x - 1), s.x - 1), 3)], ["x² − x − 1", fmt(s.x * s.x - s.x - 1, 4), "key"], [T("황금비", "Golden ratio"), "(1 + √5)/2 ≈ 1.618"]]; },
    predict: [{ q: "x² − x − 1 = 0의 양수인 근은? (소수 셋째 자리까지)", answer: () => (1 + Math.sqrt(5)) / 2, tol: 0.002, why: "근의 공식으로 x = (1 ± √5)/2이고 양수인 근은 (1 + √5)/2 ≈ 1.618입니다." }],
  },
  {
    id: "m3-zero-product", grade: 3, unit: 3, lesson: "3.1", title: "곱이 0이면 — 인수분해로 이차방정식 풀기", type: "조작", time: "8분",
    tags: ["이차방정식", "인수분해", "AB = 0"], links: ["m3-sum-product", "m3-quad-formula"],
    desc: "두 수의 곱이 0이면 둘 중 적어도 하나는 0입니다. (x − p)(x − q) = 0에서 x에 여러 값을 넣어 두 인수와 곱의 부호를 표로 보고, 곱이 0이 되는 x가 p와 q뿐임을 그래프와 함께 확인합니다.",
    obs: ["A × B = 0이면 A = 0 또는 B = 0입니다.", "x = p이면 첫째 인수가, x = q이면 둘째 인수가 0이 됩니다.", "그래프 y = (x − p)(x − q)는 x = p, q에서 x축과 만납니다."],
    q: "(x − 2)(x + 5) = 0의 해는 무엇일까요?",
    formula: "AB = 0 ⇔ A = 0 또는 B = 0",
    view: { x: [-7, 7], y: [-9, 9] },
    params: [
      { key: "p", label: "p", min: -5, max: 5, step: 1, value: 2 },
      { key: "q", label: "q", min: -5, max: 5, step: 1, value: -3 },
      { key: "x", label: "넣어 볼 x", min: -6, max: 6, step: 0.5, value: 0 },
    ],
    drags: { X: { at: (s) => [s.x, 0], move: (s, p) => (s.x = clamp(Math.round(p[0] * 2) / 2, -6, 6)), color: "d", label: "x" } },
    draw(s, g) {
      g.grid({ step: 1 }); const f = (x) => (x - s.p) * (x - s.q);
      g.fx(f, { color: "b", w: 3 });
      [s.p, s.q].forEach((r) => g.point([r, 0], `x = ${fmt(r)}`, { color: "a", r: 6.5, dy: 22, anchor: "middle", dx: 0 }));
      const v = f(s.x); g.seg([s.x, 0], [s.x, clamp(v, -9, 9)], { color: "d", w: 2, dash: "4 4" }); g.point([s.x, clamp(v, -9, 9)], "", { color: "d" });
      g.text([0, 8.2], `(${fmt(s.x)} ${sgn(-s.p)} ${fmt(Math.abs(s.p))}) × (${fmt(s.x)} ${sgn(-s.q)} ${fmt(Math.abs(s.q))}) = ${fmt(s.x - s.p)} × ${fmt(s.x - s.q)} = ${fmt(v)}`, { bold: true, size: 14, color: v === 0 ? "a" : "ink" });
    },
    metrics(s) { const A = s.x - s.p, B = s.x - s.q; return [["x − p", fmt(A)], ["x − q", fmt(B)], [T("곱", "Product"), fmt(A * B), "key"], [T("해", "Solutions"), s.p === s.q ? `x = ${fmt(s.p)} (${T("중근", "double root")})` : `x = ${fmt(Math.min(s.p, s.q))}, ${fmt(Math.max(s.p, s.q))}`]]; },
    predict: [{ q: "(x − 2)(x + 5) = 0의 두 해 중 작은 해는?", set: (s) => Object.assign(s, { p: 2, q: -5, x: 0 }), answer: () => -5, why: "x − 2 = 0 또는 x + 5 = 0이므로 x = 2 또는 x = −5입니다." }],
  },
  // ═════════ 공통수학2 Ⅳ 명제 ═════════
  {
    id: "cm2-counterexample", grade: 4, unit: 4, lesson: "Ⅳ-1", title: "반례 하나면 충분하다 — ‘모든’ 명제 깨뜨리기", type: "조작", time: "12분",
    tags: ["명제", "반례", "소수"], links: ["cm2-truth-set", "c2-converse"],
    desc: "‘모든 n에 대하여 ~이다’ 꼴의 명제는 아무리 많은 예가 맞아도 참이라고 할 수 없지만, 맞지 않는 예(반례)가 하나라도 있으면 거짓입니다. 처음 수십 개가 모두 맞다가 갑자기 깨지는 유명한 명제들을 n을 늘려 가며 시험합니다.",
    obs: ["n² + n + 41은 n = 0부터 39까지 모두 소수지만 n = 40에서 41²이 됩니다.", "2ⁿ − 1은 n이 소수 2, 3, 5, 7일 때 소수지만 n = 11이면 2047 = 23 × 89입니다.", "예를 아무리 많이 확인해도 증명이 되지는 않습니다."],
    q: "‘n이 자연수이면 n² − n + 11은 소수이다’는 참일까요?",
    formula: "‘모든 x에 대하여 p(x)’의 부정 = ‘p(x)가 아닌 x가 있다’",
    view: { x: [-0.5, 41.5], y: [-2.4, 11.2] },
    params: [
      { key: "st", label: "명제", type: "select", options: [["euler", "n² + n + 41은 소수 (n ≥ 0)"], ["mers", "n이 소수이면 2ⁿ − 1도 소수"], ["eleven", "n² − n + 11은 소수 (n ≥ 1)"], ["odd", "모든 소수는 홀수"]], value: "euler" },
      { key: "n", label: "시험할 n", min: 0, max: 40, step: 1, value: 10 },
    ],
    val(st, n) { if (st === "euler") return n * n + n + 41; if (st === "mers") return isPrime(n) ? 2 ** n - 1 : null; if (st === "eleven") return n >= 1 ? n * n - n + 11 : null; if (st === "odd") return isPrime(n) ? n : null; return null; },
    ok(st, n) { const v = this.val(st, n); if (v == null) return null; return st === "odd" ? v % 2 === 1 : isPrime(v); },
    first(st) { for (let n = 0; n <= 40; n++) if (this.ok(st, n) === false) return n; return null; },
    draw(s, g) {
      for (let n = 0; n <= 40; n++) { const o = this.ok(s.st, n); if (o == null) continue; const h = n <= s.n ? 9 : 2; rect(g, n + 0.1, 0, 0.8, h * 0.55 + 0.3, { fill: n > s.n ? "muted" : o ? "a" : "d", fo: n > s.n ? 0.12 : 0.75, stroke: false }); if (n % 5 === 0) g.text([n + 0.5, -0.6], String(n), { size: 11, color: "muted" }); }
      const v = this.val(s.st, s.n), o = this.ok(s.st, s.n);
      g.text([20.5, 10.4], v == null ? T(`n = ${s.n}은 이 명제의 대상이 아니에요`, `n = ${s.n} is outside this statement`) : `n = ${s.n}: ${v.toLocaleString()} ${o ? (s.st === "odd" ? T("(홀수)", "(odd)") : T("(소수)", "(prime)")) : s.st === "odd" ? T("— 짝수! 반례", "— even! counterexample") : `= ${factorize(v).join(" × ")} ${T("— 반례!", "— counterexample!")}`}`, { bold: true, size: 15, color: o === false ? "d" : "ink" });
      g.text([20.5, -1.8], T("초록 = 성립 · 빨강 = 반례 · 회색 = 아직 시험 안 함", "green = holds · red = counterexample · grey = not tested yet"), { size: 12, color: "muted" });
    },
    metrics(s) { const f = this.first(s.st); let cnt = 0; for (let n = 0; n <= s.n; n++) if (this.ok(s.st, n)) cnt++; return [[T("지금까지 성립한 예", "Cases that held so far"), fmt(cnt)], [T("첫 반례", "First counterexample"), f == null ? T("0~40에서는 없음", "none in 0–40") : `n = ${f}`, "key"], [T("명제의 참·거짓", "Truth value"), f == null ? T("이 범위만으로는 알 수 없음", "cannot tell from this range") : T("거짓", "false")]]; },
    predict: [
      { q: "n² + n + 41이 처음으로 소수가 아니게 되는 n은?", answer: () => 40, why: "40² + 40 + 41 = 40·41 + 41 = 41²입니다." },
      { q: "n이 소수인데 2ⁿ − 1이 소수가 아닌 가장 작은 n은?", set: (s) => Object.assign(s, { st: "mers", n: 11 }), answer: () => 11, why: "2¹¹ − 1 = 2047 = 23 × 89입니다." },
    ],
  },
  {
    id: "cm2-sqrt2-proof", grade: 4, unit: 4, lesson: "Ⅳ-3", title: "귀류법 — √2가 분수라면 더 작은 분수가 생긴다", type: "조작", time: "12분",
    tags: ["명제", "귀류법", "무리수", "증명"], links: ["his-babylon-sqrt2", "cm2-counterexample"],
    desc: "√2 = a/b(자연수)라고 가정하면 a² = 2b²입니다. 넓이가 b²인 정사각형 두 개를 넓이 a²인 정사각형 안에 겹쳐 넣으면 겹친 부분과 빈 부분이 다시 (2b − a)² = 2(a − b)²을 만족하는 더 작은 정사각형이 됩니다. 이것이 끝없이 이어질 수 없으므로 가정이 틀렸습니다.",
    obs: ["a/b를 √2에 가깝게 고를수록 a² − 2b²은 ±1처럼 작아지지만 0이 되지는 않습니다.", "a² = 2b²이라면 (2b − a, a − b)도 같은 식을 만족하는 더 작은 자연수 쌍입니다.", "자연수는 끝없이 작아질 수 없으므로 처음 가정이 모순입니다."],
    q: "7/5는 √2에 가깝습니다. 7² − 2×5²은 얼마일까요?",
    formula: "a² = 2b²  ⇒  (2b − a)² = 2(a − b)²,  0 < a − b < b",
    view: { x: [-0.4, 12.4], y: [-1.6, 9] },
    params: [{ key: "b", label: "분모 b", min: 1, max: 70, step: 1, value: 5 }],
    a(s) { return Math.round(s.b * Math.SQRT2); },
    draw(s, g) {
      const a = this.a(s), b = s.b, K = 7.6 / a, A = a * K, B = b * K;
      rect(g, 0, 0, A, A, { color: "ink", w: 2.2 });
      rect(g, 0, 0, B, B, { fill: "b", fo: 0.25, color: "b", w: 1.8 }); rect(g, A - B, A - B, B, B, { fill: "c", fo: 0.25, color: "c", w: 1.8 });
      const o = Math.max(0, 2 * B - A); if (o > 0) rect(g, A - B, A - B, o, o, { fill: "d", fo: 0.55, color: "d", w: 1.6 });
      g.text([A / 2, A + 0.45], `a = ${a}`, { bold: true, size: 14 }); g.text([B / 2, -0.5], `b = ${b}`, { bold: true, size: 13, color: "b" });
      g.text([A + 0.5, A * 0.75], `a² = ${a * a}`, { anchor: "start", size: 14, bold: true }); g.text([A + 0.5, A * 0.6], `2b² = ${2 * b * b}`, { anchor: "start", size: 14, bold: true });
      g.text([A + 0.5, A * 0.4], `a² − 2b² = ${a * a - 2 * b * b}`, { anchor: "start", size: 15, bold: true, color: "d" });
      g.text([A + 0.5, A * 0.22], `a/b = ${fmt(a / b, 6)}`, { anchor: "start", size: 13 }); g.text([A + 0.5, A * 0.08], `√2 = ${fmt(Math.SQRT2, 6)}`, { anchor: "start", size: 13, color: "muted" });
    },
    metrics(s) { const a = this.a(s), b = s.b; return [["a / b", `${a}/${b}`], ["a² − 2b²", fmt(a * a - 2 * b * b), "key"], [T("겹친 정사각형의 한 변", "Overlap square side"), fmt(2 * b - a)], [T("빈 정사각형의 한 변", "Empty square side"), fmt(a - b)]]; },
    predict: [
      { q: "a = 7, b = 5일 때 a² − 2b²의 값은?", answer: () => -1, why: "49 − 50 = −1입니다. 아무리 가까워도 0은 되지 않습니다." },
      { q: "a² = 2b²을 만족하는 자연수 쌍이 있다면 (2b − a, a − b)도 그 식을 만족합니다. a − b와 b 중 어느 쪽이 더 작을까요?", options: [["a", "a − b가 더 작다"], ["b", "b가 더 작다"], ["c", "같다"]], answer: () => "a", why: "1 < √2 < 2이므로 b < a < 2b, 따라서 0 < a − b < b입니다. 더 작은 쌍이 끝없이 생기는 모순입니다." },
    ],
  },
  // ═════════ 공통수학2 Ⅵ 유리함수와 무리함수 ═════════
  {
    id: "cm2-avg-speed", grade: 4, unit: 6, lesson: "Ⅵ-1 활용", title: "왕복 평균 속력 — 60과 40의 평균은 50이 아니다", type: "조작", time: "10분",
    tags: ["유리함수", "조화평균", "점근선"], links: ["cm2-rational", "his-greek-means"],
    desc: "갈 때 a km/h, 올 때 b km/h로 같은 거리를 왕복하면 평균 속력은 2ab/(a + b)(조화평균)입니다. 갈 때 속력을 고정하고 올 때 속력을 바꾸면 평균 속력은 b에 대한 유리함수가 되고, 아무리 빨리 와도 2a를 넘지 못합니다.",
    obs: ["평균 속력 = 전체 거리 ÷ 전체 시간입니다.", "느린 쪽에서 시간을 더 오래 쓰므로 평균은 두 속력의 산술평균보다 작습니다.", "b → ∞이면 평균 속력은 2a에 가까워집니다(점근선 y = 2a)."],
    q: "갈 때 60 km/h, 올 때 40 km/h이면 평균 속력은 몇 km/h일까요?",
    formula: "v̄ = 2d / (d/a + d/b) = 2ab / (a + b)",
    view: (s) => ({ x: [-10, 210], y: [-12, Math.max(140, 2.2 * s.a + 10)] }),
    params: [
      { key: "a", label: "갈 때 속력 a (km/h)", min: 10, max: 100, step: 5, value: 60 },
      { key: "b", label: "올 때 속력 b (km/h)", min: 5, max: 200, step: 5, value: 40 },
    ],
    drags: { P: { at: (s) => [s.b, (2 * s.a * s.b) / (s.a + s.b)], move: (s, p) => (s.b = clamp(Math.round(p[0] / 5) * 5, 5, 200)), color: "d", label: "b" } },
    draw(s, g) {
      g.grid({ step: 20, xName: "b", yName: "v̄" }); const f = (b) => (2 * s.a * b) / (s.a + b);
      g.seg([-10, 2 * s.a], [210, 2 * s.a], { color: "muted", w: 1.4, dash: "6 6" }); g.text([180, 2 * s.a + 5], `y = 2a = ${2 * s.a}`, { size: 12, color: "muted" });
      g.fx(f, { from: 0, to: 210, color: "b", w: 3 }); g.fx((b) => (s.a + b) / 2, { from: 0, to: 210, color: "c", w: 2, dash: "4 6" });
      g.text([150, (s.a + 150) / 2 + 8], T("산술평균 (a + b)/2", "Arithmetic mean"), { size: 12, color: "c" });
      g.point([s.b, f(s.b)], `${fmt(f(s.b), 2)} km/h`, { color: "d" });
    },
    metrics(s) { const v = (2 * s.a * s.b) / (s.a + s.b); return [[T("평균 속력 (조화평균)", "Average speed (harmonic mean)"), fmt(v, 2) + " km/h", "key"], [T("산술평균", "Arithmetic mean"), fmt((s.a + s.b) / 2, 2) + " km/h"], [T("넘을 수 없는 값 2a", "Upper limit 2a"), fmt(2 * s.a) + " km/h"]]; },
    predict: [{ q: "갈 때 60 km/h, 올 때 40 km/h로 왕복하면 평균 속력은 몇 km/h일까요?", answer: () => 48, why: "2×60×40 ÷ (60 + 40) = 4800 ÷ 100 = 48 km/h입니다." }],
  },
  {
    id: "cm2-speed-time", grade: 4, unit: 6, lesson: "Ⅵ-1", title: "같은 거리를 가는 속력과 시간 — y = k/x의 넓이", type: "조작", time: "8분",
    tags: ["유리함수", "반비례", "직사각형 넓이"], links: ["cm2-rational", "cm2-avg-speed"],
    desc: "거리 k를 가는 데 걸리는 시간 t는 속력 v에 반비례하여 t = k/v입니다. 그래프 위의 점에서 두 축에 내린 직사각형의 넓이 v × t는 언제나 k로 같습니다.",
    obs: ["속력이 2배가 되면 시간은 절반이 됩니다.", "그래프 위 어느 점에서 만든 직사각형이든 넓이는 거리 k입니다.", "속력이 0에 가까워지면 시간은 한없이 커집니다(점근선 x = 0)."],
    q: "120 km를 40 km/h로 가면 몇 시간이 걸릴까요?",
    formula: "t = k / v,  v × t = k",
    view: { x: [-1.6, 13.4], y: [-1.8, 13.2] },
    params: [
      { key: "k", label: "거리 k (km)", min: 40, max: 240, step: 10, value: 120 },
      { key: "v", label: "속력 v (km/h)", min: 20, max: 120, step: 5, value: 40 },
    ],
    drags: { P: { at: (s) => [s.v / 10, s.k / s.v], move: (s, p) => (s.v = clamp(Math.round((p[0] * 10) / 5) * 5, 20, 120)), color: "d", label: "v" } },
    draw(s, g) {
      const X = (v) => v / 10, Y = (t) => t;
      axes(g, { X, Y, xs: [0, 20, 40, 60, 80, 100, 120], ys: [0, 2, 4, 6, 8, 10, 12], xName: "v (km/h)", yName: T("t (시간)", "t (h)") });
      rect(g, 0, 0, X(s.v), s.k / s.v, { fill: "c", fo: 0.25, color: "c", w: 1.6 });
      g.param((v) => [X(v), s.k / v], Math.max(s.k / 12.6, 1), 125, { color: "b", w: 3 });
      g.point([X(s.v), s.k / s.v], `(${s.v}, ${fmt(s.k / s.v, 2)})`, { color: "d" });
      g.text([X(s.v) / 2, s.k / s.v / 2], T(`넓이 ${s.v} × ${fmt(s.k / s.v, 2)} = ${s.k}`, `Area ${s.v} × ${fmt(s.k / s.v, 2)} = ${s.k}`), { bold: true, size: 13, color: "c" });
    },
    metrics(s) { return [[T("걸리는 시간", "Time"), fmt(s.k / s.v, 3) + T(" 시간", " h"), "key"], [T("속력 × 시간", "Speed × time"), fmt(s.k)]]; },
    predict: [{ q: "120 km를 40 km/h로 가면 몇 시간이 걸릴까요?", answer: () => 3, why: "t = 120 ÷ 40 = 3시간입니다." }],
  },
  // ═════════ 공통수학1 Ⅴ 경우의 수 ═════════
  {
    id: "cm1-complement", grade: 14, unit: 5, lesson: "Ⅴ-1 활용", title: "여사건으로 세기 — ‘적어도 하나’는 전체에서 빼기", type: "조작", time: "10분",
    tags: ["경우의 수", "여사건", "순열"], links: ["cm1-sum-product", "pst-perm-comb"],
    desc: "숫자 0~9로 만드는 n자리 비밀번호 중 ‘같은 숫자가 적어도 두 번 나오는’ 것을 직접 세기는 어렵습니다. 전체 10ⁿ가지에서 ‘모두 다른’ 10 × 9 × ⋯ (n개)를 빼면 바로 구할 수 있습니다.",
    obs: ["‘적어도 하나’의 반대는 ‘하나도 없음’입니다.", "모두 다른 경우는 순열 ₁₀Pₙ입니다.", "n이 커질수록 같은 숫자가 겹칠 비율이 빠르게 커지고, n = 11이면 반드시 겹칩니다(비둘기집 원리)."],
    q: "4자리 비밀번호 중 같은 숫자가 적어도 두 번 나오는 것은 몇 가지일까요?",
    formula: "(적어도 하나 겹침) = 10ⁿ − ₁₀Pₙ",
    view: { x: [0, 12], y: [-1, 8.6] },
    params: [{ key: "n", label: "비밀번호 자릿수 n", min: 1, max: 11, step: 1, value: 4 }],
    calc(s) { const all = 10 ** s.n; let d = 1; for (let i = 0; i < s.n; i++) d *= Math.max(0, 10 - i); return { all, diff: d, same: all - d }; },
    draw(s, g) {
      const { all, diff, same } = this.calc(s), W = 11, w1 = (diff / all) * W;
      rect(g, 0.5, 4, W, 1.6, { fill: "muted", fo: 0.08, color: "ink", w: 1.4 });
      rect(g, 0.5, 4, w1, 1.6, { fill: "b", fo: 0.55, stroke: false }); rect(g, 0.5 + w1, 4, W - w1, 1.6, { fill: "d", fo: 0.55, stroke: false });
      g.text([6, 7.6], T(`전체 10^${s.n} = ${all.toLocaleString()}`, `All 10^${s.n} = ${all.toLocaleString()}`), { bold: true, size: 15 });
      g.text([6, 3.2], T(`모두 다름 ₁₀P${s.n} = ${diff.toLocaleString()} · 적어도 하나 겹침 = ${same.toLocaleString()}`, `All different 10P${s.n} = ${diff.toLocaleString()} · some repeat = ${same.toLocaleString()}`), { size: 14 });
      g.text([6, 1.8], T(`겹칠 확률 ${fmt((same / all) * 100, 2)}%`, `Chance of a repeat ${fmt((same / all) * 100, 2)}%`), { bold: true, size: 17, color: "d" });
    },
    metrics(s) { const { all, diff, same } = this.calc(s); return [[T("전체", "All"), all.toLocaleString()], [T("모두 다름", "All different"), diff.toLocaleString()], [T("적어도 하나 겹침", "At least one repeat"), same.toLocaleString(), "key"]]; },
    predict: [{ q: "4자리 비밀번호 중 같은 숫자가 적어도 두 번 나오는 것은 몇 가지일까요?", answer: () => 4960, why: "10000 − 10×9×8×7 = 10000 − 5040 = 4960가지입니다." }],
  },
  {
    id: "cm1-tree-perm", grade: 14, unit: 5, lesson: "Ⅴ-2", title: "수형도로 세는 순열 — 회장·부회장·서기 뽑기", type: "조작", time: "10분",
    tags: ["경우의 수", "수형도", "순열"], links: ["pst-perm-comb", "cm1-complement"],
    desc: "n명 중에서 서로 다른 r개의 역할을 맡을 사람을 차례로 뽑으면 첫째 자리 n가지, 둘째 자리 n − 1가지, …로 가지가 줄어듭니다. 수형도의 끝 가지 수가 곱의 법칙으로 구한 ₙPᵣ와 같음을 확인합니다.",
    obs: ["한 사람이 두 역할을 맡을 수 없으므로 단계마다 고를 수 있는 사람이 1명씩 줄어듭니다.", "수형도의 끝 가지 하나가 한 가지 경우입니다.", "ₙPᵣ = n(n − 1)⋯(n − r + 1)입니다."],
    q: "4명 중 회장과 부회장을 한 명씩 뽑는 방법은 몇 가지일까요?",
    formula: "ₙPᵣ = n × (n − 1) × ⋯ × (n − r + 1)",
    view: { x: [-0.5, 12.5], y: [-0.6, 9.4] },
    params: [
      { key: "n", label: "사람 수 n", min: 2, max: 5, step: 1, value: 4 },
      { key: "r", label: "뽑을 역할 수 r", min: 1, max: 3, step: 1, value: 2 },
    ],
    derive(s) { if (s.r > s.n) s.r = s.n; },
    leaves(s) { let p = 1; for (let i = 0; i < s.r; i++) p *= s.n - i; return p; },
    draw(s, g) {
      const names = ["A", "B", "C", "D", "E"].slice(0, s.n), L = this.leaves(s), roles = [T("회장", "Pres."), T("부회장", "VP"), T("서기", "Sec.")];
      const levelY = (d) => 8.6 - d * (7.6 / s.r);
      let leafIdx = 0;
      const walk = (used, d, x0, x1, px, py) => {
        if (d === s.r) { leafIdx++; return; }
        const opts = names.filter((n) => !used.includes(n)), w = (x1 - x0) / opts.length;
        opts.forEach((nm, i) => { const cx = x0 + w * (i + 0.5), cy = levelY(d + 1); g.seg([px, py], [cx, cy], { color: "grid", w: 1.2 }); if (L <= 60 || d < s.r - 1) g.text([cx, cy - 0.05], nm, { size: L > 30 && d === s.r - 1 ? 9 : 12, bold: d === 0, dy: 4 }); walk([...used, nm], d + 1, x0 + w * i, x0 + w * (i + 1), cx, cy); });
      };
      walk([], 0, 0, 12, 6, 9.2);
      for (let d = 0; d < s.r; d++) g.text([-0.3, levelY(d + 1)], roles[d], { anchor: "start", size: 11, color: "muted", dy: -10 });
      g.text([6, 0], T(`끝 가지 ${L}개 = ${Array.from({ length: s.r }, (_, i) => s.n - i).join(" × ")}`, `${L} leaves = ${Array.from({ length: s.r }, (_, i) => s.n - i).join(" × ")}`), { bold: true, size: 15, color: "a" });
    },
    metrics(s) { return [[T("단계별 고를 수", "Choices per stage"), Array.from({ length: s.r }, (_, i) => s.n - i).join(" × ")], ["ₙPᵣ", fmt(this.leaves(s)), "key"]]; },
    predict: [{ q: "4명 중 회장과 부회장을 한 명씩 뽑는 방법은 몇 가지일까요?", answer: () => 12, why: "회장 4가지 × 부회장 3가지 = 12가지입니다." }, { q: "5명 중 회장·부회장·서기를 뽑는 방법은?", set: (s) => Object.assign(s, { n: 5, r: 3 }), answer: () => 60, why: "5 × 4 × 3 = 60가지입니다." }],
  },
  // ═════════ 수학과 문화 Ⅱ 생활과 수학 ═════════
  {
    id: "cul-barcode", grade: 11, unit: 2, lesson: "Ⅱ-1 탐구", title: "바코드의 마지막 숫자 — 잘못 찍으면 알아채는 검증 숫자", type: "조작", time: "10분",
    tags: ["바코드", "나머지", "오류 검출"], links: ["cul-braille", "puz-binary-cards"],
    desc: "상품 바코드(EAN-13)의 13번째 숫자는 앞 12자리에 1, 3, 1, 3, …을 번갈아 곱해 더한 값이 10의 배수가 되도록 정합니다. 숫자 하나를 잘못 읽거나 이웃한 두 숫자를 바꿔 찍으면 대부분 이 규칙이 깨져 계산대가 오류를 알아챕니다.",
    obs: ["검증 숫자 = (10 − 가중합을 10으로 나눈 나머지)를 10으로 나눈 나머지입니다.", "숫자 하나만 틀리면 언제나 알아챕니다.", "이웃한 두 숫자를 바꾸면 두 숫자의 차가 5일 때만 놓칩니다."],
    q: "880으로 시작하는 바코드는 어느 나라에서 등록된 상품일까요?",
    formula: "1·d₁ + 3·d₂ + 1·d₃ + ⋯ + 3·d₁₂ + d₁₃ ≡ 0 (mod 10)",
    view: { x: [0, 13.6], y: [-1, 8.6] },
    params: [
      { key: "code", label: "예시 바코드 (가상)", type: "select", options: [["880123456789", "880 1234 5678 9?"], ["880987654321", "880 9876 5432 1?"], ["880555000111", "880 5550 0011 1?"]], value: "880123456789" },
      { key: "err", label: "실수 넣기", type: "seg", options: [["none", "없음"], ["one", "숫자 하나 틀림"], ["swap", "이웃 두 숫자 바꿈"]], value: "none" },
      { key: "pos", label: "실수 위치 (몇 번째 자리)", min: 1, max: 11, step: 1, value: 5, when: (s) => s.err !== "none" },
    ],
    check(d12) { const w = d12.split("").reduce((t, ch, i) => t + +ch * (i % 2 ? 3 : 1), 0); return (10 - (w % 10)) % 10; },
    read(s) {
      const good = s.code + this.check(s.code); let r = good.split("");
      if (s.err === "one") r[s.pos - 1] = String((+r[s.pos - 1] + 4) % 10);
      if (s.err === "swap") [r[s.pos - 1], r[s.pos]] = [r[s.pos], r[s.pos - 1]];
      return { good, read: r.join("") };
    },
    draw(s, g) {
      const { good, read } = this.read(s), sum = read.split("").reduce((t, ch, i) => t + +ch * (i === 12 ? 1 : i % 2 ? 3 : 1), 0), ok = sum % 10 === 0;
      for (let i = 0; i < 13; i++) { const x = 0.5 + i, changed = read[i] !== good[i]; rect(g, x, 5.2, 0.9, 1.4, { fill: changed ? "d" : i === 12 ? "a" : "b", fo: changed ? 0.5 : 0.15, color: "ink", w: 1 }); g.text([x + 0.45, 5.75], read[i], { bold: true, size: 18 }); g.text([x + 0.45, 4.6], i === 12 ? "×1" : i % 2 ? "×3" : "×1", { size: 11, color: "muted" }); }
      for (let i = 0; i < 40; i++) { const bit = (good.charCodeAt(i % 13) * (i + 3)) % 3; if (bit) rect(g, 0.5 + i * 0.32, 7, 0.16 * bit, 1.2, { fill: "ink", fo: 0.9, stroke: false }); }
      g.text([6.8, 3.4], T(`가중합 = ${sum}`, `Weighted sum = ${sum}`), { bold: true, size: 16 });
      g.text([6.8, 2.2], ok ? T("10의 배수 → 정상으로 읽음", "Multiple of 10 → accepted") : T("10의 배수가 아님 → 오류! 다시 찍으세요", "Not a multiple of 10 → error! Scan again"), { bold: true, size: 16, color: ok ? "a" : "d" });
      if (ok && read !== good) g.text([6.8, 1.1], T("실수가 있는데도 알아채지 못했어요 (두 숫자의 차가 5)", "An error slipped through (digits differ by 5)"), { size: 13, color: "d" });
    },
    metrics(s) { const { good, read } = this.read(s); return [[T("검증 숫자", "Check digit"), good[12], "key"], [T("읽은 바코드", "Scanned"), read], [T("판정", "Verdict"), read.split("").reduce((t, ch, i) => t + +ch * (i === 12 ? 1 : i % 2 ? 3 : 1), 0) % 10 === 0 ? T("통과", "accepted") : T("오류 감지", "error detected")]]; },
    predict: [{ q: "앞 12자리가 880123456789인 바코드의 검증 숫자는?", answer: () => 3, why: "8 + 3·8 + 0 + 3·1 + 2 + 3·3 + 4 + 3·5 + 6 + 3·7 + 8 + 3·9 = 127이므로, 127 + 3 = 130이 10의 배수가 되게 하는 검증 숫자는 3입니다." }],
  },
  {
    id: "cul-parcel", grade: 11, unit: 2, lesson: "Ⅱ-2", title: "택배 요금의 부피 무게 — 가벼워도 크면 비싸다", type: "조작", time: "8분",
    tags: ["부피", "단위", "최댓값"], links: ["cul-barcode", "m1-prism-volume"],
    desc: "택배 회사는 실제 무게와 ‘부피 무게’(가로 × 세로 × 높이 ÷ 6000, kg) 가운데 큰 값으로 요금을 매깁니다. 상자의 크기와 무게를 바꾸며 어느 쪽이 요금을 정하는지, 상자를 줄이면 얼마나 아낄 수 있는지 봅니다.",
    obs: ["부피 무게는 부피(cm³)를 6000으로 나눈 값입니다(회사마다 나누는 수가 다를 수 있음).", "가볍고 큰 상자는 부피 무게가, 작고 무거운 상자는 실제 무게가 요금을 정합니다.", "한 변만 줄여도 부피 무게는 같은 비율로 줄어듭니다."],
    q: "60 × 40 × 30 cm 상자에 2 kg짜리 이불을 넣으면 요금을 정하는 무게는 몇 kg일까요?",
    formula: "요금 무게 = max(실제 무게, 가로 × 세로 × 높이 / 6000)",
    view: { x: [0, 12], y: [-1, 8.4] },
    params: [
      { key: "L", label: "가로 (cm)", min: 10, max: 80, step: 5, value: 60 },
      { key: "W", label: "세로 (cm)", min: 10, max: 60, step: 5, value: 40 },
      { key: "H", label: "높이 (cm)", min: 5, max: 60, step: 5, value: 30 },
      { key: "kg", label: "실제 무게 (kg)", min: 0.5, max: 20, step: 0.5, value: 2 },
    ],
    vw(s) { return (s.L * s.W * s.H) / 6000; },
    draw(s, g) {
      const v = this.vw(s), M = Math.max(20, v, s.kg), k = 9.5 / M;
      rect(g, 1, 5.4, s.kg * k, 0.9, { fill: "b", fo: s.kg >= v ? 0.75 : 0.3, stroke: false }); g.text([1, 6.8], T(`실제 무게 ${fmt(s.kg)} kg`, `Actual ${fmt(s.kg)} kg`), { anchor: "start", size: 14, bold: s.kg >= v });
      rect(g, 1, 2.8, v * k, 0.9, { fill: "c", fo: v > s.kg ? 0.75 : 0.3, stroke: false }); g.text([1, 4.2], T(`부피 무게 ${s.L}×${s.W}×${s.H}÷6000 = ${fmt(v, 2)} kg`, `Volumetric ${s.L}×${s.W}×${s.H}÷6000 = ${fmt(v, 2)} kg`), { anchor: "start", size: 14, bold: v > s.kg });
      g.text([6, 0.8], T(`요금은 ${fmt(Math.max(v, s.kg), 2)} kg 기준`, `Charged as ${fmt(Math.max(v, s.kg), 2)} kg`), { bold: true, size: 18, color: "a" });
    },
    metrics(s) { const v = this.vw(s); return [[T("부피", "Volume"), (s.L * s.W * s.H).toLocaleString() + " cm³"], [T("부피 무게", "Volumetric weight"), fmt(v, 2) + " kg"], [T("요금 무게", "Chargeable weight"), fmt(Math.max(v, s.kg), 2) + " kg", "key"], [T("요금을 정하는 쪽", "Deciding factor"), v > s.kg ? T("부피", "size") : T("실제 무게", "weight")]]; },
    predict: [{ q: "60 × 40 × 30 cm 상자에 2 kg 물건을 넣으면 요금 무게는 몇 kg일까요?", answer: () => 12, why: "72000 ÷ 6000 = 12 kg이 실제 무게 2 kg보다 크므로 12 kg으로 계산합니다." }],
  },
  // ═════════ 수학과 문화 Ⅲ 사회와 수학 ═════════
  {
    id: "cul-gini", grade: 11, unit: 3, lesson: "Ⅲ-3", title: "로렌츠 곡선과 지니계수 — 불평등을 하나의 수로", type: "조작", time: "12분",
    tags: ["로렌츠 곡선", "지니계수", "넓이", "적분 맛보기"], links: ["cul-weighted", "calc1-area-between"],
    desc: "소득이 낮은 사람부터 줄 세워 아래쪽 x%가 전체 소득의 몇 %를 갖는지 그린 곡선이 로렌츠 곡선입니다. 완전 평등선 y = x와 곡선 사이 넓이의 2배가 지니계수(0이면 완전 평등, 1에 가까울수록 불평등)입니다. 곡선 y = xᵖ로 모형을 만들어 비교합니다.",
    obs: ["모두 같은 소득이면 곡선은 대각선 y = x와 겹치고 지니계수는 0입니다.", "곡선이 아래로 처질수록 평등선과의 넓이가 커집니다.", "y = xᵖ 모형의 지니계수는 (p − 1)/(p + 1)입니다."],
    q: "하위 50%가 전체 소득의 25%를 갖는 사회는 지니계수가 대략 얼마일까요?",
    formula: "G = 2 × (평등선과 로렌츠 곡선 사이 넓이) = 1 − 2∫₀¹ L(x) dx",
    view: { x: [-0.12, 1.55], y: [-0.12, 1.08] },
    params: [
      { key: "p", label: "곡선의 처짐 p (y = xᵖ)", min: 1, max: 6, step: 0.05, value: 2 },
      { key: "x", label: "하위 몇 %", min: 0, max: 1, step: 0.01, value: 0.5 },
    ],
    draw(s, g) {
      const L = (x) => x ** s.p;
      g.poly([[0, 0], [1, 0], [1, 1]], { stroke: false, fill: "grid", fo: 0.25 });
      g.region((x) => x, L, 0, 1, { fill: "d", fo: 0.3 });
      g.seg([0, 0], [1, 1], { color: "muted", w: 1.6, dash: "5 5" }); g.seg([0, 0], [1, 0], { color: "axis", w: 1.4 }); g.seg([0, 0], [0, 1], { color: "axis", w: 1.4 }); g.seg([1, 0], [1, 1], { color: "axis", w: 1 });
      g.fx(L, { from: 0, to: 1, color: "b", w: 3 });
      g.point([s.x, L(s.x)], T(`하위 ${Math.round(s.x * 100)}% → 소득 ${fmt(L(s.x) * 100, 1)}%`, `Bottom ${Math.round(s.x * 100)}% → ${fmt(L(s.x) * 100, 1)}% of income`), { color: "d" });
      g.text([1.27, 0.75], T(`지니계수`, `Gini`), { size: 14, bold: true }); g.text([1.27, 0.62], fmt((s.p - 1) / (s.p + 1), 3), { size: 22, bold: true, color: "d" });
      g.text([0.5, -0.07], T("인구 누적 비율", "Cumulative share of people"), { size: 11, color: "muted" });
    },
    metrics(s) { const G = (s.p - 1) / (s.p + 1); return [[T("하위 비율이 가진 소득", "Income share of the bottom group"), fmt(s.x ** s.p * 100, 1) + "%"], [T("지니계수", "Gini coefficient"), fmt(G, 3), "key"], [T("평등선과의 넓이", "Area to the equality line"), fmt(G / 2, 3)]]; },
    predict: [{ q: "로렌츠 곡선이 y = x²이면 지니계수는? (분수나 소수)", answer: () => 1 / 3, tol: 0.01, why: "1 − 2∫₀¹ x² dx = 1 − 2/3 = 1/3 ≈ 0.333입니다. 이 사회에서는 하위 50%가 소득의 25%를 갖습니다." }],
  },
  {
    id: "cul-rule72", grade: 11, unit: 3, lesson: "Ⅲ-4", title: "72의 법칙 — 돈이 두 배가 되는 데 걸리는 해", type: "조작", time: "8분",
    tags: ["복리", "로그", "어림"], links: ["alg-geo-seq", "alg-log-scale"],
    desc: "연이율 r%의 복리로 돈이 두 배가 되는 데 걸리는 해는 log 2 / log(1 + r/100)입니다. 이 값을 72 ÷ r로 어림하는 ‘72의 법칙’이 얼마나 정확한지 이율을 바꾸며 비교합니다.",
    obs: ["이율이 2배가 되면 두 배가 되는 기간은 대략 절반이 됩니다.", "이율 6~10%에서 72의 법칙은 거의 정확합니다.", "72는 약수가 많아 2, 3, 4, 6, 8, 9, 12로 나누기 쉽습니다."],
    q: "연이율 6%로 저축하면 대략 몇 년 뒤에 두 배가 될까요?",
    formula: "n = log 2 / log(1 + r/100) ≈ 72 / r",
    view: { x: [-2.4, 21.6], y: [-1.8, 13.2] },
    params: [{ key: "r", label: "연이율 r (%)", min: 2, max: 20, step: 0.5, value: 6 }],
    exact: (r) => Math.log(2) / Math.log(1 + r / 100),
    drags: { R: { at: (s) => [s.r, (Math.log(2) / Math.log(1 + s.r / 100)) / 3], move: (s, p) => (s.r = clamp(Math.round(p[0] * 2) / 2, 2, 20)), color: "d", label: "r" } },
    draw(s, g) {
      const X = (r) => r, Y = (n) => n / 3;
      axes(g, { X, Y, xs: [0, 4, 8, 12, 16, 20], ys: [0, 6, 12, 18, 24, 30, 36], xName: T("연이율 r (%)", "rate r (%)"), yName: T("두 배가 되는 해", "years to double") });
      g.param((r) => [X(r), Y(this.exact(r))], 2, 20.5, { color: "b", w: 3 });
      g.param((r) => [X(r), Y(72 / r)], 2, 20.5, { color: "c", w: 2.2, dash: "6 5" });
      g.text([15.5, Y(9.5)], T("정확한 값", "Exact"), { color: "b", bold: true, size: 13 }); g.text([15.5, Y(3)], "72 ÷ r", { color: "c", bold: true, size: 13 });
      g.point([s.r, Y(72 / s.r)], "", { color: "c", r: 4 });
    },
    metrics(s) { const ex = Math.log(2) / Math.log(1 + s.r / 100), ap = 72 / s.r; return [[T("정확한 기간", "Exact"), fmt(ex, 2) + T("년", " yrs")], [T("72의 법칙", "Rule of 72"), fmt(ap, 2) + T("년", " yrs"), "key"], [T("오차", "Error"), fmt(ap - ex, 2) + T("년", " yrs")]]; },
    predict: [{ q: "연이율 6%로 복리 저축하면 72의 법칙으로 몇 년 뒤에 두 배가 될까요?", answer: () => 12, why: "72 ÷ 6 = 12년입니다. 정확한 값은 log 2 / log 1.06 ≈ 11.9년입니다." }],
  },
  {
    id: "cul-progressive-tax", grade: 11, unit: 3, lesson: "Ⅲ-4 탐구", title: "누진세 — 구간을 넘으면 넘은 만큼만 높은 세율", type: "조작", time: "10분",
    tags: ["세금", "구간별 함수", "평균"], links: ["cul-weighted", "job-breakeven"],
    desc: "누진세는 소득 전체에 높은 세율을 매기는 것이 아니라 각 구간에 해당하는 부분에만 그 구간의 세율을 매깁니다. 그래서 구간을 조금 넘어도 세금이 갑자기 뛰지 않고, 실제 부담률(세금 ÷ 소득)은 가장 높은 세율보다 낮습니다. (실제 소득세 구간을 단순화한 예시이며 공제는 생략했습니다.)",
    obs: ["세금 그래프는 꺾이지만 끊어지지 않는 구간별 일차함수입니다.", "한계세율(마지막 1원에 붙는 세율)과 실효세율(평균)은 다릅니다.", "구간을 넘었다고 손해 보는 일은 생기지 않습니다."],
    q: "과세 소득 6000만 원이면 세율 24% 구간에 들어갑니다. 내는 세금은 6000만 × 24%일까요?",
    formula: "세금 = Σ (구간에 해당하는 소득) × (그 구간의 세율)",
    view: { x: [-1.8, 13], y: [-1.8, 10.8] },
    params: [{ key: "inc", label: "과세 소득 (백만 원)", min: 0, max: 120, step: 1, value: 60 }],
    BR: [[0, 14, 0.06], [14, 50, 0.15], [50, 88, 0.24], [88, 150, 0.35]],
    tax(m) { return this.BR.reduce((t, [a, b, r]) => t + Math.max(0, Math.min(m, b) - a) * r, 0); },
    drags: { P: { at: (s) => [s.inc / 10, 0], move: (s, p) => (s.inc = clamp(Math.round(p[0] * 10), 0, 120)), color: "d", label: T("소득", "income") } },
    draw(s, g) {
      const X = (m) => m / 10, Y = (t) => t / 3;
      axes(g, { X, Y, xs: [0, 20, 40, 60, 80, 100, 120], ys: [0, 5, 10, 15, 20, 25], xName: T("과세 소득 (백만 원)", "taxable income (₩M)"), yName: T("세금 (백만 원)", "tax (₩M)") });
      this.BR.forEach(([a, b, r], i) => { const top = Math.min(b, 120); rect(g, X(a), 0, X(top) - X(a), 9.6, { fill: ["a", "b", "c", "d"][i], fo: 0.06, stroke: false }); g.text([(X(a) + X(top)) / 2, 9.9], `${Math.round(r * 100)}%`, { size: 12, color: "muted" }); });
      g.param((m) => [X(m), Y(this.tax(m))], 0, 120, { color: "b", w: 3 });
      g.point([X(s.inc), Y(this.tax(s.inc))], T(`세금 ${fmt(this.tax(s.inc), 2)}백만`, `tax ₩${fmt(this.tax(s.inc), 2)}M`), { color: "d" });
    },
    metrics(s) { const t = this.tax(s.inc), br = this.BR.find(([a, b]) => s.inc > a && s.inc <= b) || this.BR[0]; return [[T("세금", "Tax"), won(t * 1e6), "key"], [T("한계세율 (마지막 구간)", "Marginal rate"), Math.round(br[2] * 100) + "%"], [T("실효세율 (세금 ÷ 소득)", "Effective rate"), s.inc ? fmt((t / s.inc) * 100, 2) + "%" : "—"]]; },
    predict: [{ q: "과세 소득 6000만 원의 세금은 몇 만 원일까요? (이 실험의 단순화된 구간 기준)", answer: () => 864, why: "1400만×6% + 3600만×15% + 1000만×24% = 84 + 540 + 240 = 864만 원입니다. 6000만×24% = 1440만 원이 아닙니다." }],
  },
  // ═════════ 수학과 문화 Ⅳ 환경과 수학 ═════════
  {
    id: "cul-carbon-budget", grade: 11, unit: 4, lesson: "Ⅳ-2", title: "탄소 예산 — 해마다 같은 양 vs 같은 비율로 줄이기", type: "조작", time: "12분",
    tags: ["등차수열", "등비수열", "누적 합", "환경"], links: ["alg-geo-seq", "alg-arith-sum", "cul-population"],
    desc: "올해 배출량을 100이라 할 때, 해마다 같은 양 d씩 줄이는 계획(등차)과 같은 비율 r%씩 줄이는 계획(등비)을 비교합니다. 앞으로 내보낼 수 있는 총량(탄소 예산) 안에 들어오는지는 그래프 아래 넓이, 곧 배출량의 누적 합으로 판단합니다. (수치는 개념 학습용 가상 조건입니다.)",
    obs: ["같은 양씩 줄이면 언젠가 0에 닿고, 같은 비율로 줄이면 0에 다가가기만 합니다.", "총배출량은 해마다 배출량을 모두 더한 값(막대 넓이의 합)입니다.", "같은 비율로 줄이는 계획의 총량은 등비수열의 합 100·(1 − (1−r)ⁿ)/r로 구합니다."],
    q: "해마다 10%씩 줄이면 30년 동안의 총배출량은 올해 배출량의 몇 배일까요?",
    formula: "등차: Σ (100 − dk),  등비: Σ 100(1 − r)ᵏ = 100·(1 − (1 − r)ⁿ)/r",
    view: { x: [-1.6, 13.2], y: [-1.8, 12.8] },
    params: [
      { key: "d", label: "같은 양 d씩 감축 (해마다)", min: 1, max: 10, step: 0.5, value: 4 },
      { key: "r", label: "같은 비율 r%씩 감축", min: 1, max: 20, step: 0.5, value: 10 },
      { key: "B", label: "탄소 예산 (총량)", min: 300, max: 1500, step: 50, value: 900 },
    ],
    series(s) { const A = [], G = []; for (let k = 0; k < 30; k++) { A.push(Math.max(0, 100 - s.d * k)); G.push(100 * (1 - s.r / 100) ** k); } return { A, G, SA: A.reduce((a, b) => a + b, 0), SG: G.reduce((a, b) => a + b, 0) }; },
    draw(s, g) {
      const X = (k) => k / 2.5, Y = (e) => e / 10;
      axes(g, { X, Y, xs: [0, 5, 10, 15, 20, 25, 30], ys: [0, 20, 40, 60, 80, 100], xName: T("몇 년 뒤", "years from now"), yName: T("한 해 배출량", "annual emissions") });
      const { A, G, SA, SG } = this.series(s);
      A.forEach((v, k) => rect(g, X(k) + 0.02, 0, 0.17, Y(v), { fill: "c", fo: 0.6, stroke: false }));
      G.forEach((v, k) => rect(g, X(k) + 0.2, 0, 0.17, Y(v), { fill: "b", fo: 0.6, stroke: false }));
      g.text([8.6, 12.1], T(`같은 양: 총 ${fmt(SA, 1)} ${SA <= s.B ? "✓" : "✗"}`, `Same amount: ${fmt(SA, 1)} ${SA <= s.B ? "✓" : "✗"}`), { color: "c", bold: true, size: 14 });
      g.text([8.6, 11.1], T(`같은 비율: 총 ${fmt(SG, 1)} ${SG <= s.B ? "✓" : "✗"}`, `Same rate: ${fmt(SG, 1)} ${SG <= s.B ? "✓" : "✗"}`), { color: "b", bold: true, size: 14 });
      g.text([8.6, 10.1], T(`탄소 예산 ${s.B} 이내면 ✓`, `✓ if within the budget ${s.B}`), { color: "d", size: 13 });
    },
    metrics(s) { const { SA, SG, A } = this.series(s); const zero = A.findIndex((v) => v === 0); return [[T("같은 양 감축 총량", "Total (same amount)"), fmt(SA, 1)], [T("같은 비율 감축 총량", "Total (same rate)"), fmt(SG, 1), "key"], [T("같은 양 감축이 0에 닿는 해", "Year emissions hit 0"), zero < 0 ? T("30년 안에는 안 닿음", "not within 30 yrs") : String(zero)]]; },
    predict: [{ q: "올해 100에서 해마다 10%씩 줄이면 30년 동안의 총배출량은 대략 얼마일까요? (정수로)", set: (s) => Object.assign(s, { r: 10 }), answer: () => (100 * (1 - 0.9 ** 30)) / 0.1, tol: 1, why: "100 × (1 − 0.9³⁰) ÷ 0.1 ≈ 957.6입니다. 아무리 오래 가도 1000을 넘지 않습니다." }],
  },
  {
    id: "cul-moving-average", grade: 11, unit: 4, lesson: "Ⅳ-3", title: "이동평균으로 보는 기온 추세 — 흔들림 속의 방향", type: "데이터", time: "10분",
    tags: ["평균", "이동평균", "추세", "자료 해석"], links: ["cul-population", "m3-boxplot"],
    desc: "해마다 들쭉날쭉한 연평균 기온 자료에서 앞뒤 몇 해를 묶어 평균을 내면(이동평균) 짧은 흔들림이 줄고 긴 추세가 드러납니다. 묶는 기간을 바꾸며 무엇이 보이고 무엇이 사라지는지 비교합니다. (자료는 상승 추세와 무작위 흔들림을 합성한 가상 자료입니다.)",
    obs: ["묶는 기간이 길수록 선이 매끄러워집니다.", "너무 길게 묶으면 변화의 시작과 끝이 흐려집니다.", "이동평균은 양 끝에서는 계산할 자료가 부족해 짧아집니다."],
    q: "같은 자료에서 3년 이동평균과 11년 이동평균 중 어느 쪽이 해마다의 흔들림을 더 많이 지울까요?",
    formula: "Mₖ(t) = (x_{t−m} + ⋯ + x_t + ⋯ + x_{t+m}) / (2m + 1),  k = 2m + 1",
    view: { x: [-1.8, 13.4], y: [-1.8, 11] },
    params: [
      { key: "m", label: "앞뒤로 묶는 해 m (기간 2m + 1년)", min: 0, max: 10, step: 1, value: 2 },
      { key: "seed", label: "자료 바꾸기", min: 1, max: 30, step: 1, value: 7 },
    ],
    data(s) { const r = RNG(s.seed * 31 + 5), out = []; for (let y = 1960; y <= 2024; y++) { const trend = 11.8 + 0.028 * (y - 1960) + 0.00018 * (y - 1960) ** 2, noise = (r() + r() + r() - 1.5) * 0.55; out.push([y, trend + noise]); } return out; },
    ma(s) { const D = this.data(s), m = s.m, k = 2 * m + 1, out = []; for (let i = m; i < D.length - m; i++) out.push([D[i][0], D.slice(i - m, i + m + 1).reduce((t, p) => t + p[1], 0) / k]); return out; },
    draw(s, g) {
      const X = (y) => (y - 1960) / 5, Y = (t) => (t - 10.8) * 2.8, P = ([y, t]) => [X(y), Y(t)];
      axes(g, { X, Y, xs: [1960, 1970, 1980, 1990, 2000, 2010, 2020], ys: [11, 12, 13, 14], x0: 1960, x1: 2024, y0: 10.8, y1: 14.4, yl: (t) => `${t}°C`, xName: T("연도", "year"), yName: T("연평균 기온 (가상)", "annual mean temp. (synthetic)") });
      const D = this.data(s); g.path(D.map(P), { color: "muted", w: 1.4 }); D.forEach((p) => g.point(P(p), "", { r: 2.6, color: "muted" }));
      g.path(this.ma(s).map(P), { color: "d", w: 3.4 });
      g.text([6.4, 10.5], T(`${2 * s.m + 1}년 이동평균`, `${2 * s.m + 1}-year moving average`), { color: "d", bold: true, size: 14 });
    },
    metrics(s) { const M = this.ma(s), D = this.data(s); const sd = (a) => { const m = a.reduce((t, v) => t + v, 0) / a.length; return Math.sqrt(a.reduce((t, v) => t + (v - m) ** 2, 0) / a.length); }; const diff = (a) => a.slice(1).map((v, i) => v - a[i]); return [[T("해마다 변화의 흔들림 (원자료)", "Year-to-year wobble (raw)"), fmt(sd(diff(D.map((p) => p[1]))), 3) + "°C"], [T("해마다 변화의 흔들림 (이동평균)", "Year-to-year wobble (smoothed)"), M.length > 2 ? fmt(sd(diff(M.map((p) => p[1]))), 3) + "°C" : "—", "key"], [T("이동평균 첫해~끝해", "Smoothed span"), M.length ? `${M[0][0]}–${M[M.length - 1][0]}` : "—"]]; },
    predict: [{ q: "3년 이동평균과 11년 이동평균 중 해마다의 흔들림을 더 많이 지우는 것은?", set: (s) => Object.assign(s, { m: 5 }), options: [["a", "3년"], ["b", "11년"], ["c", "똑같다"]], answer: () => "b", why: "더 많은 해를 묶어 평균을 낼수록 우연한 흔들림이 서로 상쇄됩니다." }],
  },
];
