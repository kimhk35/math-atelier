// 23차 묶음 8 — 중학교 1학년 추가 실험 16개
import { fmt, frac, poly, clamp } from "./hs-core.js";

const G1 = 1;
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const sgn = (v) => (v < 0 ? `(${fmt(v)})` : fmt(v));
const isPrime = (n) => { if (n < 2) return false; for (let p = 2; p * p <= n; p++) if (n % p === 0) return false; return true; };
const SUP = "⁰¹²³⁴⁵⁶⁷⁸⁹", supN = (n) => [...String(n)].map((d) => SUP[d]).join("");
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
function numLine(g, y, a, b, step = 1, lab = 1) { g.seg([a - 0.3, y], [b + 0.3, y], { color: "axis", w: 1.6 }); for (let x = a; x <= b + 1e-9; x += step) { g.seg([x, y - 0.12], [x, y + 0.12], { color: "axis", w: 1.1 }); if (Math.abs(x / lab - Math.round(x / lab)) < 1e-9) g.text([x, y], fmt(x), { dy: 20, size: 11, color: "muted" }); } }
const THICK = [[0.0002, "머리카락 굵기"], [0.03, "책 한 권"], [1.6, "사람 키"], [123, "63빌딩 (약 250 m의 절반)"], [8849, "에베레스트산"], [384400000, "달까지의 거리"]];
const ULAM = (() => { const N = 21, G = {}; let x = 0, y = 0, dx = 1, dy = 0, len = 1, n = 1, k = 0; G[`${x},${y}`] = n; while (n < N * N) { for (let r = 0; r < 2; r++) { for (let i = 0; i < len && n < N * N; i++) { x += dx; y += dy; n++; G[`${x},${y}`] = n; } [dx, dy] = [-dy, dx]; } len++; k++; } return G; })();

export default [
  // ───────── 1단원 ─────────
  {
    id: "m1-paper-fold", grade: G1, unit: 1, lesson: "1.1", title: "종이 접기와 거듭제곱 — 42번 접으면 달까지?", type: "조작", time: "10분",
    tags: ["거듭제곱", "지수", "2ⁿ"], links: ["m1-sieve"],
    desc: "두께 0.1 mm인 종이를 반으로 접을 때마다 두께가 2배가 됩니다. n번 접으면 2ⁿ겹이고, 2를 거듭 곱하는 수가 얼마나 빨리 커지는지 책·사람 키·에베레스트·달까지의 거리와 비교하며 거듭제곱의 위력을 느껴 봅니다.",
    obs: ["n번 접으면 2 × 2 × ⋯ × 2 = 2ⁿ겹이 됩니다.", "10번만 접어도 2¹⁰ = 1024겹, 약 10 cm입니다.", "2를 곱하는 횟수(지수)가 1 늘 때마다 두께가 2배가 됩니다."],
    q: "실제 종이는 7~8번 넘게 접기 어렵습니다. 왜 그럴까요?",
    formula: "두께 = 0.1 mm × 2ⁿ",
    en: { title: "Paper Folding and Powers of 2", desc: "Fold 42 times to reach the Moon?" },
    view: BOX,
    params: [{ key: "n", label: "접은 횟수 n", min: 0, max: 42, step: 1, value: 10 }],
    anim: { key: "n", min: 0, max: 42, speed: 4, label: "접기" },
    draw(s, g) {
      const t = 0.0001 * 2 ** s.n, lg = (v) => Math.log10(v), y = (v) => 1 + ((lg(v) + 4.5) / 13.2) * 9;
      g.seg([2.2, 1], [2.2, 10.2], { color: "axis", w: 1.6 });
      for (let e = -4; e <= 8; e += 2) { g.seg([2.05, y(10 ** e)], [2.35, y(10 ** e)], { color: "axis", w: 1 }); g.text([1.9, y(10 ** e)], `10${e < 0 ? "⁻" : ""}${supN(Math.abs(e))} m`, { anchor: "end", dy: 4, size: 11, color: "muted" }); }
      THICK.forEach(([v, n]) => { g.seg([2.2, y(v)], [9, y(v)], { color: v <= t ? "c" : "grid", w: 1.2, dash: "4 4" }); g.text([9.2, y(v)], `${n}`, { anchor: "start", dy: 4, size: 12, color: v <= t ? "c" : "muted", bold: v <= t }); });
      rect(g, 3.4, 1, 3, Math.max(0.05, y(t) - 1), { fill: "a", fo: 0.45, color: "a", w: 1.6 });
      g.text([4.9, Math.min(y(t), 10) + 0.35], `${fmt(t < 1 ? t * 1000 : t, t < 1 ? 1 : 0)} ${t < 1 ? "mm" : "m"}`, { bold: true, color: "a" });
      g.note(14, 26, "세로 눈금은 10배마다 한 칸 (로그 눈금)", { size: 11 });
    },
    metrics(s) { const t = 0.0001 * 2 ** s.n; return [["겹 수", `2${supN(s.n)} = ${(2 ** s.n).toLocaleString()}겹`], ["두께", t < 1 ? `${fmt(t * 1000, 2)} mm` : t < 1000 ? `${fmt(t, 1)} m` : `${fmt(t / 1000, 1)} km`, "key"]]; },
    predict: [
      { q: "10번 접으면 몇 겹이 될까요?", set: (s) => (s.n = 3), reveal: (s) => (s.n = 10), answer: () => 1024, why: "2¹⁰ = 1024겹, 두께는 약 10 cm입니다." },
      { q: "몇 번 접으면 두께가 처음으로 에베레스트산(8849 m)을 넘을까요?", set: (s) => (s.n = 20), reveal: (s) => (s.n = 27), answer: () => 27, why: "0.1 mm × 2²⁷ ≈ 13421 m, 2²⁶번은 약 6711 m입니다." },
    ],
  },
  {
    id: "m1-ulam", grade: G1, unit: 1, lesson: "1.1", title: "울람의 소수 나선 — 소수에도 무늬가 있을까", type: "조작", time: "10분",
    tags: ["소수", "규칙", "탐구"], links: ["m1-sieve"],
    desc: "1을 가운데 두고 2, 3, 4, …를 소용돌이 모양으로 늘어놓은 뒤 소수만 칠해 봅니다. 수학자 울람이 회의 중 낙서로 발견한 그림으로, 소수가 대각선을 따라 줄지어 나타나는 신기한 경향을 관찰합니다.",
    obs: ["2를 뺀 소수는 모두 홀수라 체스판처럼 한 칸씩 건너 나타납니다.", "어떤 대각선에는 소수가 유난히 많이 모입니다.", "소수가 왜 이렇게 모이는지는 아직 완전히 풀리지 않은 질문입니다."],
    q: "4n² + 2n + 41 같은 식이 소수를 많이 만든다는 것과 이 그림은 어떤 관계가 있을까요?",
    formula: "소수: 1과 자기 자신만을 약수로 가지는 1보다 큰 수",
    en: { title: "Ulam's Prime Spiral", desc: "Do primes form patterns?" },
    view: { x: [-11, 11], y: [-11, 11], pad: 6 },
    params: [{ key: "N", label: "늘어놓은 수", min: 9, max: 441, step: 1, value: 441 }, { key: "num", label: "숫자도 보이기", type: "check", value: false }],
    anim: { key: "N", min: 9, max: 441, speed: 60, label: "소용돌이 늘리기" },
    draw(s, g) {
      Object.entries(ULAM).forEach(([k, n]) => { if (n > s.N) return; const [x, y] = k.split(",").map(Number), p = isPrime(n); rect(g, x - 0.48, y - 0.48, 0.96, 0.96, { fill: p ? "a" : n === 1 ? "e" : "grid", fo: p ? 0.85 : 0.35, stroke: false }); if (s.num && s.N <= 121) g.text([x, y], String(n), { dy: 4, size: 10, color: p ? "paper" : "muted" }); });
    },
    metrics(s) { let c = 0; for (let n = 2; n <= s.N; n++) if (isPrime(n)) c++; return [[`${s.N} 이하의 소수`, `${c}개`, "key"], ["비율", `${fmt((100 * c) / s.N, 1)}%`]]; },
    predict: [
      { q: "100 이하의 수 가운데 소수가 차지하는 비율은 몇 %일까요?", set: (s) => Object.assign(s, { N: 49, num: true }), reveal: (s) => (s.N = 100), answer: () => 25, why: "100 이하의 소수는 25개, 곧 25%입니다." },
      { q: "수가 커질수록 소수의 비율은?", options: O("점점 줄어든다", "점점 늘어난다", "일정하다"), set: (s) => (s.N = 100), reveal: (s) => (s.N = 441), answer: () => "a", why: "441 이하에서는 약 19%로 줄어듭니다. 큰 수일수록 약수가 될 수 있는 수가 많아지기 때문입니다." },
    ],
  },
  {
    id: "m1-divisor-grid", grade: G1, unit: 1, lesson: "1.2", title: "약수의 개수 — 표로 세는 (a + 1)(b + 1)", type: "조작", time: "10분",
    tags: ["약수의 개수", "소인수분해", "곱의 법칙"], links: ["m1-divisor-rect"],
    desc: "N = 2ᵃ × 3ᵇ의 약수를 2의 지수와 3의 지수로 가로·세로 표에 늘어놓으면 표의 칸 수가 곧 약수의 개수 (a + 1)(b + 1)입니다. 지수를 바꾸며 약수의 개수를 소인수분해로 바로 셀 수 있는 까닭을 확인합니다.",
    obs: ["약수는 2ⁱ × 3ʲ (0 ≤ i ≤ a, 0 ≤ j ≤ b) 꼴뿐입니다.", "i는 a + 1가지, j는 b + 1가지를 고를 수 있습니다.", "그래서 약수의 개수는 (a + 1)(b + 1)입니다."],
    q: "N = 2² × 3 × 5의 약수의 개수를 같은 방법으로 세어 봅시다.",
    formula: "N = 2ᵃ × 3ᵇ ⇒ 약수의 개수 = (a + 1)(b + 1)",
    en: { title: "Counting Divisors with a Table", desc: "(a + 1)(b + 1)." },
    view: BOX,
    params: [{ key: "a", label: "2의 지수 a", min: 0, max: 5, step: 1, value: 3 }, { key: "b", label: "3의 지수 b", min: 0, max: 3, step: 1, value: 2 }],
    draw(s, g) {
      const cw = 2, ch = 1.6, x0 = 2.6, y0 = 9.6;
      for (let i = 0; i <= s.a; i++) g.text([x0 + i * cw + cw / 2, y0 + 0.5], `2${supN(i)}`, { bold: true, color: "a" });
      for (let j = 0; j <= s.b; j++) g.text([x0 - 0.4, y0 - j * ch - ch / 2], `3${supN(j)}`, { anchor: "end", dy: 5, bold: true, color: "b" });
      for (let i = 0; i <= s.a; i++) for (let j = 0; j <= s.b; j++) { rect(g, x0 + i * cw + 0.05, y0 - (j + 1) * ch + 0.05, cw - 0.1, ch - 0.1, { fill: "c", fo: 0.2, color: "c", w: 1 }); g.text([x0 + i * cw + cw / 2, y0 - j * ch - ch / 2], String(2 ** i * 3 ** j), { dy: 5, bold: true, size: 15 }); }
      g.text([x0, 1.3], `N = 2${supN(s.a)} × 3${supN(s.b)} = ${2 ** s.a * 3 ** s.b}: 약수 ${(s.a + 1) * (s.b + 1)}개`, { anchor: "start", bold: true, size: 16 });
    },
    metrics(s) { return [["N", String(2 ** s.a * 3 ** s.b)], ["약수의 개수", `(${s.a} + 1) × (${s.b} + 1) = ${(s.a + 1) * (s.b + 1)}`, "key"]]; },
    predict: [
      { q: "72 = 2³ × 3²의 약수의 개수는?", set: (s) => Object.assign(s, { a: 1, b: 1 }), reveal: (s) => Object.assign(s, { a: 3, b: 2 }), answer: () => 12, why: "(3 + 1)(2 + 1) = 12개입니다." },
      { q: "약수가 4개인 2ᵃ × 3ᵇ 꼴의 수 중 가장 작은 것은?", set: (s) => Object.assign(s, { a: 0, b: 0 }), reveal: (s) => Object.assign(s, { a: 1, b: 1 }), answer: () => 6, why: "(a + 1)(b + 1) = 4가 되는 경우는 2³ = 8, 3³ = 27, 2 × 3 = 6이고 가장 작은 것은 6입니다." },
    ],
  },

  // ───────── 2단원 ─────────
  {
    id: "m1-abs-distance", grade: G1, unit: 2, lesson: "2.1", title: "절댓값은 원점까지의 거리", type: "조작", time: "8분",
    tags: ["절댓값", "수직선", "정수"], links: ["m1-numberline", "m1-thermometer"],
    desc: "수직선 위의 점 a를 끌어 원점까지의 거리 |a|를 화살표로 확인합니다. 절댓값이 같은 수는 원점을 사이에 두고 양쪽에 하나씩 있고, 음수끼리는 절댓값이 클수록 작은 수임을 비교합니다.",
    obs: ["|a|는 a가 원점에서 떨어진 거리이므로 항상 0 이상입니다.", "절댓값이 k (k > 0)인 수는 k와 −k의 두 개입니다.", "음수는 절댓값이 클수록 작습니다: −5 < −2."],
    q: "|a| = |b|이면 a = b라고 할 수 있을까요?",
    formula: "|a| = (a ≥ 0이면 a, a < 0이면 −a)",
    en: { title: "Absolute Value as Distance", desc: "Distance from zero on a number line." },
    view: { x: [-7.5, 7.5], y: [-2.6, 2.6] },
    init: () => ({ a: -4, b: 2.5 }),
    drags: {
      A: { at: (s) => [s.a, 0], move: (s, p) => (s.a = clamp(Math.round(p[0] * 2) / 2, -7, 7)), label: "a", color: "a" },
      B: { at: (s) => [s.b, 0], move: (s, p) => (s.b = clamp(Math.round(p[0] * 2) / 2, -7, 7)), label: "b", color: "b" },
    },
    params: [{ key: "mirror", label: "절댓값이 같은 수도 보이기", type: "check", value: true }],
    draw(s, g) {
      numLine(g, 0, -7, 7);
      if (s.a) g.vec([0, 1], [s.a, 1], { color: "a", w: 3 }).text([s.a / 2, 1], `|a| = ${fmt(Math.abs(s.a))}`, { dy: -8, bold: true, color: "a", size: 13 });
      if (s.b) g.vec([0, -1], [s.b, -1], { color: "b", w: 3 }).text([s.b / 2, -1], `|b| = ${fmt(Math.abs(s.b))}`, { dy: 18, bold: true, color: "b", size: 13 });
      if (s.mirror && s.a) g.point([-s.a, 0], "", { color: "a", hollow: true, r: 6 });
      if (s.mirror && s.b) g.point([-s.b, 0], "", { color: "b", hollow: true, r: 6 });
      g.point([s.a, 0], "a", { color: "a", dy: -12, dx: -4 }).point([s.b, 0], "b", { color: "b", dy: -12, dx: -4 });
    },
    metrics(s) { return [["a, b", `${fmt(s.a)}, ${fmt(s.b)}`], ["|a|, |b|", `${fmt(Math.abs(s.a))}, ${fmt(Math.abs(s.b))}`], ["더 큰 수", s.a > s.b ? "a" : s.b > s.a ? "b" : "같다", "key"]]; },
    predict: [
      { q: "절댓값이 3인 수는 모두 몇 개일까요?", set: (s) => Object.assign(s, { a: 3, b: 1, mirror: false }), reveal: (s) => (s.mirror = true), answer: () => 2, why: "3과 −3, 원점에서 거리가 3인 점은 양쪽에 하나씩입니다." },
      { q: "−5와 −2 가운데 더 큰 수는?", options: O("−2", "−5"), set: (s) => Object.assign(s, { a: -5, b: -2 }), answer: () => "a", why: "수직선에서 오른쪽에 있는 수가 큽니다. 음수는 절댓값이 작을수록 큽니다." },
    ],
  },
  {
    id: "m1-thermometer", grade: G1, unit: 2, lesson: "2.1", title: "온도계로 보는 수의 크기 — 영하의 비교", type: "조작", time: "8분",
    tags: ["정수와 유리수", "대소 관계", "수직선"], links: ["m1-abs-distance"],
    desc: "세운 수직선인 온도계에 두 도시의 기온을 표시하고 어느 쪽이 더 따뜻한지, 몇 도 차이인지 비교합니다. 위에 있을수록 큰 수이고, 두 수의 차는 눈금 사이의 거리임을 확인합니다.",
    obs: ["온도계에서 위쪽이 더 큰 수입니다.", "영하 3도(−3)는 영하 8도(−8)보다 따뜻합니다.", "두 기온의 차는 큰 수에서 작은 수를 뺀 값입니다."],
    q: "−4.5℃와 −4℃ 가운데 더 추운 쪽은 어디일까요?",
    formula: "a < b ⇔ 수직선에서 a가 b보다 아래(왼쪽)에 있음",
    en: { title: "Comparing Numbers on a Thermometer", desc: "Below zero, which is warmer?" },
    view: { x: [-6, 10], y: [-12.5, 12.5], pad: 10 },
    params: [{ key: "a", label: "서울 기온 (℃)", min: -10, max: 10, step: 0.5, value: -3 }, { key: "b", label: "평창 기온 (℃)", min: -10, max: 10, step: 0.5, value: -8 }],
    draw(s, g) {
      rect(g, -0.6, -10.5, 1.2, 21, { fill: "paper", fo: 1, color: "ink", w: 2 });
      for (let t = -10; t <= 10; t++) { g.seg([0.6, t], [t % 5 ? 1 : 1.4, t], { color: "ink", w: 1.2 }); if (!(t % 5)) g.text([1.6, t], `${t > 0 ? "+" : ""}${t}℃`.replace("-", "−"), { anchor: "start", dy: 4, size: 12, color: t < 0 ? "b" : t > 0 ? "a" : "ink", bold: !t }); }
      [[s.a, "서울", "a", -1], [s.b, "평창", "b", 1]].forEach(([v, n, c, d]) => { g.seg([-0.6, v], [-3.4, v], { color: c, w: 2.4 }); g.point([-3.6, v], "", { color: c }); g.text([-3.8, v], `${n} ${fmt(v)}℃`, { anchor: "end", dy: 4, bold: true, color: c, size: 13 }); });
      g.vec([5, Math.min(s.a, s.b)], [5, Math.max(s.a, s.b)], { color: "e", w: 2.4 }).text([5.3, (s.a + s.b) / 2], `차 ${fmt(Math.abs(s.a - s.b))}℃`, { anchor: "start", bold: true, color: "e" });
    },
    metrics(s) { return [["더 따뜻한 곳", s.a > s.b ? "서울" : s.b > s.a ? "평창" : "같음", "key"], ["기온 차", `${fmt(Math.max(s.a, s.b))} − ${sgn(Math.min(s.a, s.b))} = ${fmt(Math.abs(s.a - s.b))}℃`]]; },
    predict: [
      { q: "서울 −3℃, 평창 −8℃일 때 기온 차는 몇 ℃?", set: (s) => Object.assign(s, { a: -3, b: -8 }), answer: () => 5, why: "(−3) − (−8) = 5입니다. 온도계에서 5칸 차이입니다." },
      { q: "−4.5와 −4 가운데 더 작은 수는?", options: O("−4.5", "−4"), set: (s) => Object.assign(s, { a: -4, b: -4.5 }), answer: () => "a", why: "−4.5가 −4보다 아래에 있으므로 더 작습니다." },
    ],
  },
  {
    id: "m1-fraction-line", grade: G1, unit: 2, lesson: "2.1", title: "분수를 수직선에 — 등분해서 찾아가기", type: "조작", time: "8분",
    tags: ["유리수", "분수", "수직선"], links: ["m1-abs-distance"],
    desc: "정수 사이를 q등분하는 눈금을 그리고 p칸 가서 p/q를 수직선 위에 나타냅니다. 음수인 분수, 대분수, 소수로 고친 값을 함께 보며 유리수도 수직선 위의 한 점임을 확인합니다.",
    obs: ["p/q는 0에서 1/q 길이를 p번 간 점입니다.", "분모가 같으면 분자가 클수록 오른쪽에 있습니다.", "−p/q는 p/q와 원점에 대하여 반대쪽에 있습니다."],
    q: "2/3와 3/5 가운데 어느 것이 클까요? 수직선에서 어떻게 비교할 수 있을까요?",
    formula: "p/q = (1/q) × p",
    en: { title: "Fractions on the Number Line", desc: "Divide each unit into q parts." },
    view: { x: [-3.6, 3.6], y: [-1.6, 2] },
    params: [{ key: "q", label: "분모 q (등분)", min: 1, max: 10, step: 1, value: 4 }, { key: "p", label: "분자 p", min: -30, max: 30, step: 1, value: 7 }],
    onChange(s) { s.p = clamp(s.p, -3 * s.q, 3 * s.q); },
    draw(s, g) {
      g.seg([-3.4, 0], [3.4, 0], { color: "axis", w: 1.6 });
      for (let k = -3 * s.q; k <= 3 * s.q; k++) { const x = k / s.q, big = k % s.q === 0; g.seg([x, big ? -0.2 : -0.1], [x, big ? 0.2 : 0.1], { color: "axis", w: big ? 1.6 : 1 }); if (big) g.text([x, 0], fmt(x), { dy: 24, size: 12, bold: true }); }
      const v = s.p / s.q;
      for (let k = 0; k < Math.abs(s.p); k++) { const a = (Math.sign(s.p) * k) / s.q, b = (Math.sign(s.p) * (k + 1)) / s.q; const pts = []; for (let t = 0; t <= 10; t++) { const x = a + ((b - a) * t) / 10; pts.push([x, 0.15 + 0.25 * Math.sin((Math.PI * t) / 10)]); } g.path(pts, { color: "a", w: 1.6 }); }
      g.point([v, 0], `${s.p}/${s.q}`.replace("-", "−"), { color: "e", dy: -26, dx: -10 });
    },
    metrics(s) { const v = s.p / s.q, w = Math.trunc(v), r = Math.abs(s.p % s.q); return [["분수", `${s.p}/${s.q}`.replace("-", "−")], ["대분수", Math.abs(v) >= 1 && r ? `${v < 0 ? "−" : ""}${Math.abs(w)}과 ${r}/${s.q}` : "—"], ["소수", fmt(v, 4), "key"]]; },
    predict: [
      { q: "7/4는 어느 두 정수 사이에 있을까요?", options: O("1과 2 사이", "2와 3 사이", "0과 1 사이"), set: (s) => Object.assign(s, { q: 4, p: 1 }), reveal: (s) => (s.p = 7), answer: () => "a", why: "7/4 = 1과 3/4 = 1.75입니다." },
      { q: "−5/2를 소수로 나타내면?", set: (s) => Object.assign(s, { q: 2, p: 1 }), reveal: (s) => (s.p = -5), answer: () => -2.5, why: "1/2을 왼쪽으로 5번 가면 −2.5입니다." },
    ],
  },

  // ───────── 3단원 ─────────
  {
    id: "m1-distribute", grade: G1, unit: 3, lesson: "3.1", title: "일차식의 계산 — k(ax + b) 타일 묶음 복사하기", type: "조작", time: "10분",
    tags: ["일차식", "분배법칙", "대수 타일"], links: ["m1-matchstick", "m2-algebra-tiles"],
    desc: "ax + b를 나타내는 타일 묶음을 k번 복사해 늘어놓으면 x 타일 ka개와 1 타일 kb개가 됩니다. k가 음수이면 모든 타일의 색(부호)이 바뀌는 것을 보며 분배법칙 k(ax + b) = kax + kb를 확인합니다.",
    obs: ["k(ax + b)는 (ax + b)를 k번 더한 것입니다.", "괄호 안의 모든 항에 k를 곱해야 합니다.", "−(ax + b) = −ax − b: 부호가 모두 바뀝니다."],
    q: "2(3x − 1) − 3(x + 2)를 타일로 계산해 봅시다.",
    formula: "k(ax + b) = kax + kb",
    en: { title: "Distributing over a Linear Expression", desc: "Copy a tile group k times." },
    view: BOX,
    params: [{ key: "k", label: "곱하는 수 k", min: -3, max: 3, step: 1, value: 2 }, { key: "a", label: "x의 계수 a", min: 1, max: 3, step: 1, value: 2 }, { key: "b", label: "상수항 b", min: -3, max: 3, step: 1, value: -1 }],
    onChange(s) { if (!s.k) s.k = 1; },
    draw(s, g) {
      const n = Math.abs(s.k), sg = Math.sign(s.k);
      for (let r = 0; r < n; r++) { let x = 1.2; const y = 10 - r * 2.3; g.text([0.5, y - 0.9], `${r + 1}`, { size: 12, color: "muted" }); for (let i = 0; i < s.a; i++) { rect(g, x, y - 1.8, 0.45, 1.8, { fill: sg > 0 ? "b" : "a", fo: 0.55, color: sg > 0 ? "b" : "a", w: 1.2 }); g.text([x + 0.22, y - 0.9], "x", { dy: 4, size: 11, bold: true }); x += 0.6; } x += 0.5; for (let i = 0; i < Math.abs(s.b); i++) { const pos = Math.sign(s.b) * sg > 0; rect(g, x, y - 0.45, 0.45, 0.45, { fill: pos ? "b" : "a", fo: 0.55, color: pos ? "b" : "a", w: 1.2 }); x += 0.6; } }
      g.text([9, 9.6], `${s.k === -1 ? "−" : s.k === 1 ? "" : fmt(s.k)}(${poly([[s.a, "x"]], s.b)})`, { anchor: "start", bold: true, size: 18 });
      g.text([9, 8.4], `= ${poly([[s.k * s.a, "x"]], s.k * s.b)}`, { anchor: "start", bold: true, size: 18, color: "c" });
      g.text([9, 7.3], "파랑: 양수 · 주황: 음수", { anchor: "start", size: 12, color: "muted" });
    },
    metrics(s) { return [["x 타일", `${s.k} × ${s.a} = ${s.k * s.a}`], ["1 타일", `${s.k} × ${sgn(s.b)} = ${s.k * s.b}`], ["결과", poly([[s.k * s.a, "x"]], s.k * s.b), "key"]]; },
    predict: [
      { q: "−3(2x − 1)을 전개하면 상수항은?", set: (s) => Object.assign(s, { k: 3, a: 2, b: -1 }), reveal: (s) => (s.k = -3), answer: () => 3, why: "(−3) × (−1) = 3이므로 −6x + 3입니다." },
      { q: "2(3x − 1)의 x의 계수는?", set: (s) => Object.assign(s, { k: 1, a: 3, b: -1 }), reveal: (s) => (s.k = 2), answer: () => 6, why: "3x를 2번 더하면 6x입니다." },
    ],
  },
  {
    id: "m1-seesaw", grade: G1, unit: 3, lesson: "3.2", title: "등식의 성질 — 양쪽에 똑같이 하면 수평은 그대로", type: "조작", time: "12분",
    tags: ["등식의 성질", "일차방정식", "이항"], links: ["m1-balance"],
    desc: "방정식 ax + b = c에 '양변에 더하기·빼기·곱하기·나누기' 단추를 눌러 직접 변형해 봅니다. 양쪽에 똑같이 하면 해는 바뀌지 않고, 몇 번의 변형으로 x = (수) 꼴을 만들 수 있음을 기록과 함께 확인합니다.",
    obs: ["a = b이면 a + c = b + c, a − c = b − c입니다.", "a = b이면 ac = bc, a ÷ c = b ÷ c (c ≠ 0)입니다.", "항을 반대쪽으로 '옮기는' 이항은 양변에서 같은 수를 빼는 것과 같습니다."],
    q: "양변에 0을 곱하면 왜 안 될까요?",
    formula: "a = b ⇒ a ± c = b ± c, ac = bc, a/c = b/c (c ≠ 0)",
    en: { title: "Properties of Equality", desc: "Do the same to both sides." },
    view: BOX,
    init: () => ({ A: 3, B: 5, C: 20, log: [] }),
    params: [{ key: "c", label: "더하거나 곱할 수", min: 1, max: 6, step: 1, value: 5 }],
    buttons: [["add", "양변 + c"], ["sub", "양변 − c"], ["mul", "양변 × c"], ["div", "양변 ÷ c"], ["reset", "처음으로"]],
    onDo(a, s) {
      const c = s.c, E = (A, B, C) => `${A === 1 ? "" : fmt(A, 3)}x${Math.abs(B) < 1e-9 ? "" : ` ${B < 0 ? "−" : "+"} ${fmt(Math.abs(B), 3)}`} = ${fmt(C, 3)}`;
      if (a === "reset") { Object.assign(s, { A: 3, B: 5, C: 20, log: [] }); return; }
      if (a === "add") { s.B += c; s.C += c; } else if (a === "sub") { s.B -= c; s.C -= c; } else if (a === "mul") { s.A *= c; s.B *= c; s.C *= c; } else { s.A /= c; s.B /= c; s.C /= c; }
      s.log = [...s.log, `${{ add: "+", sub: "−", mul: "×", div: "÷" }[a]} ${c} → ${E(s.A, s.B, s.C)}`].slice(-6);
    },
    draw(s, g) {
      const E = `${s.A === 1 ? "" : fmt(s.A, 3)}x${Math.abs(s.B) < 1e-9 ? "" : ` ${s.B < 0 ? "−" : "+"} ${fmt(Math.abs(s.B), 3)}`} = ${fmt(s.C, 3)}`, done = Math.abs(s.A - 1) < 1e-9 && Math.abs(s.B) < 1e-9;
      g.text([8, 9.6], "3x + 5 = 20", { bold: true, size: 15, color: "muted" });
      g.text([8, 8.2], E, { bold: true, size: 26, color: done ? "c" : "ink" });
      g.seg([2, 6.4], [14, 6.4], { color: "ink", w: 4 }).poly([[7.3, 4.6], [8.7, 4.6], [8, 6.4]], { fill: "muted", fo: 0.3, color: "muted", w: 1.4 });
      g.text([4, 6.9], "왼쪽", { bold: true, color: "a" }).text([12, 6.9], "오른쪽", { bold: true, color: "b" });
      s.log.forEach((t, i) => g.text([2, 3.8 - i * 0.6], t, { anchor: "start", size: 13, mono: true, color: "muted" }));
      if (done) g.text([8, 7.1], "x만 남았어요! 해를 찾았어요", { bold: true, color: "c", size: 14 });
    },
    metrics(s) { return [["지금 식", `${fmt(s.A, 3)}x + ${fmt(s.B, 3)} = ${fmt(s.C, 3)}`], ["해 (어느 단계에서나 같음)", `x = ${fmt((s.C - s.B) / s.A, 3)}`, "key"], ["변형 횟수", `${s.log.length}번`]]; },
    predict: [
      { q: "3x + 5 = 20의 해는?", answer: () => 5, why: "양변에서 5를 빼면 3x = 15, 양변을 3으로 나누면 x = 5입니다." },
      { q: "양변에서 5를 뺀 뒤 식의 오른쪽 값은?", set: (s) => Object.assign(s, { A: 3, B: 5, C: 20, log: [], c: 5 }), reveal: (s) => { s.B -= 5; s.C -= 5; }, answer: () => 15, why: "20 − 5 = 15, 식은 3x = 15가 됩니다." },
    ],
  },
  {
    id: "m1-meet", grade: G1, unit: 3, lesson: "3.3", title: "거리·속력·시간 — 마주 보고 걸으면 언제 만날까", type: "조작", time: "12분",
    tags: ["일차방정식의 활용", "거리", "속력"], links: ["m1-seesaw"],
    desc: "거리 D만큼 떨어진 두 사람이 서로를 향해 걸을 때, 두 사람이 걸은 거리의 합이 D가 되는 순간에 만납니다. 시간을 x로 놓고 방정식 (속력₁ + 속력₂)x = D를 세워 푸는 것을 그림의 움직임과 비교합니다.",
    obs: ["거리 = 속력 × 시간입니다.", "마주 보고 걸으면 1분마다 두 사람 사이가 두 속력의 합만큼 줄어듭니다.", "그래서 만나는 시간은 D ÷ (속력₁ + 속력₂)입니다."],
    q: "두 사람이 같은 방향으로 걷는다면 뒤에 있는 사람이 언제 따라잡을까요?",
    formula: "(v₁ + v₂)x = D",
    en: { title: "Distance, Speed, Time", desc: "When do two walkers meet?" },
    view: { x: [-0.6, 12.6], y: [-2.6, 4] },
    params: [{ key: "D", label: "떨어진 거리 (m)", min: 600, max: 2400, step: 100, value: 1800 }, { key: "v1", label: "민지 (m/분)", min: 40, max: 120, step: 10, value: 80 }, { key: "v2", label: "준호 (m/분)", min: 40, max: 120, step: 10, value: 70 }, { key: "t", label: "시간 (분)", min: 0, max: 30, step: 0.5, value: 6 }],
    anim: { key: "t", min: 0, max: 30, speed: 4, label: "걷기" },
    draw(s, g) {
      const k = 12 / s.D, T = s.D / (s.v1 + s.v2), t = Math.min(s.t, T), a = s.v1 * t * k, b = 12 - s.v2 * t * k;
      g.seg([0, 0], [12, 0], { color: "ink", w: 2.4 });
      g.text([0, 0], "A", { dy: 20, bold: true }).text([12, 0], "B", { dy: 20, bold: true }).text([6, 0], `${s.D} m`, { dy: 36, size: 12, color: "muted" });
      g.seg([0, 0.6], [a, 0.6], { color: "a", w: 5 }).seg([b, 0.6], [12, 0.6], { color: "b", w: 5 });
      g.point([a, 0], "민지", { color: "a", dy: -20, dx: -10 }).point([b, 0], "준호", { color: "b", dy: -20, dx: -10 });
      g.text([0, 2.4], `${fmt(t)}분: 민지 ${fmt(s.v1 * t)} m + 준호 ${fmt(s.v2 * t)} m = ${fmt((s.v1 + s.v2) * t)} m`, { anchor: "start", bold: true, size: 14 });
      if (s.t >= T) g.text([a, -1.6], `${fmt(T, 2)}분 뒤 만남!`, { bold: true, color: "e", size: 15 });
    },
    metrics(s) { const T = s.D / (s.v1 + s.v2); return [["방정식", `(${s.v1} + ${s.v2})x = ${s.D}`], ["만나는 시간", `${fmt(T, 2)}분`, "key"], ["만나는 곳 (A에서)", `${fmt(s.v1 * T, 1)} m`]]; },
    predict: [
      { q: "1800 m 떨어져 분속 80 m, 70 m로 마주 보고 걸으면 몇 분 뒤에 만날까요?", set: (s) => Object.assign(s, { D: 1800, v1: 80, v2: 70, t: 0 }), reveal: (s) => (s.t = 12), answer: () => 12, why: "150x = 1800이므로 x = 12분입니다." },
      { q: "그때 민지는 A에서 몇 m 떨어진 곳에 있을까요?", set: (s) => Object.assign(s, { D: 1800, v1: 80, v2: 70, t: 12 }), answer: () => 960, why: "80 × 12 = 960 m입니다." },
    ],
  },
  {
    id: "m1-clock", grade: G1, unit: 3, lesson: "3.3", title: "시곗바늘 사이의 각 — 일차방정식으로 푸는 시계 문제", type: "조작", time: "12분",
    tags: ["일차방정식의 활용", "시계", "각"], links: ["m1-meet"],
    desc: "분침은 1분에 6°, 시침은 1분에 0.5°씩 돕니다. 시각을 바꾸며 두 바늘 사이의 각을 재고, '3시와 4시 사이에 두 바늘이 겹치는 때'를 방정식 6x = 90 + 0.5x로 구해 확인합니다.",
    obs: ["분침은 60분에 360°이므로 1분에 6°입니다.", "시침은 12시간(720분)에 360°이므로 1분에 0.5°입니다.", "두 바늘은 1분에 5.5°씩 벌어지거나 좁혀집니다."],
    q: "하루 동안 두 바늘이 정확히 겹치는 것은 몇 번일까요?",
    formula: "h시 m분: 시침 30h + 0.5m, 분침 6m",
    en: { title: "Angles Between Clock Hands", desc: "Solve clock problems with linear equations." },
    view: { x: [-4.6, 7.4], y: [-4, 4] },
    params: [{ key: "m", label: "시각 (0시부터 분)", min: 0, max: 719, step: 1, value: 196, show: (v) => `${Math.floor(v / 60) || 12}시 ${v % 60}분` }],
    anim: { key: "m", min: 0, max: 719, speed: 30, label: "시계 돌리기", loop: "wrap" },
    draw(s, g) {
      const R = 3.4, h = Math.floor(s.m / 60), mm = s.m % 60, H = (30 * h + 0.5 * mm) % 360, M = 6 * mm, P = (deg, r) => [r * Math.sin((deg * Math.PI) / 180), r * Math.cos((deg * Math.PI) / 180)];
      g.circle([0, 0], R, { fill: "paper", fo: 1, color: "ink", w: 3 });
      for (let i = 1; i <= 12; i++) g.text(P(i * 30, R - 0.55), String(i), { dy: 5, bold: true, size: 13 });
      for (let i = 0; i < 60; i++) g.seg(P(i * 6, R), P(i * 6, R - (i % 5 ? 0.15 : 0.3)), { color: "ink", w: i % 5 ? 1 : 2 });
      const a = Math.min(H, M), b = Math.max(H, M), d = b - a, small = d <= 180;
      g.arc([0, 0], P(small ? b : a, 1), P(small ? a : b, 1), { color: "e", r: 34, ccw: true });
      g.seg([0, 0], P(H, 1.9), { color: "ink", w: 6 }).seg([0, 0], P(M, 2.9), { color: "a", w: 3.4 });
      g.point([0, 0], "", { color: "ink", r: 5 });
      g.text([4.4, 2.6], `${h || 12}시 ${mm}분`, { anchor: "start", bold: true, size: 20 });
      g.text([4.4, 1.6], `시침 ${fmt(H, 1)}° · 분침 ${fmt(M)}°`, { anchor: "start", size: 13, color: "muted" });
      g.text([4.4, 0.6], `사이의 각 ${fmt(Math.min(d, 360 - d), 1)}°`, { anchor: "start", bold: true, size: 16, color: "e" });
    },
    metrics(s) { const h = Math.floor(s.m / 60), mm = s.m % 60, d = Math.abs((30 * h + 0.5 * mm) % 360 - 6 * mm); return [["시각", `${h || 12}시 ${mm}분`], ["두 바늘 사이의 각", `${fmt(Math.min(d, 360 - d), 1)}°`, "key"]]; },
    predict: [
      { q: "3시 정각에 두 바늘 사이의 각은 몇 도?", set: (s) => (s.m = 150), reveal: (s) => (s.m = 180), answer: () => 90, why: "시침은 3 × 30 = 90°, 분침은 0°에 있습니다." },
      { q: "3시와 4시 사이에 두 바늘이 겹치는 것은 3시 몇 분일까요? (소수 첫째 자리까지)", set: (s) => (s.m = 180), reveal: (s) => (s.m = 196), answer: () => 180 / 11, tol: 0.1, why: "6x = 90 + 0.5x에서 x = 180/11 ≈ 16.4분입니다." },
    ],
  },

  // ───────── 4단원 ─────────
  {
    id: "m1-treasure", grade: G1, unit: 4, lesson: "4.1", title: "좌표로 보물찾기 — 순서쌍 두 번 읽기", type: "조작", time: "10분",
    tags: ["순서쌍", "좌표", "놀이"], links: ["m1-quadrant"],
    desc: "섬 지도 위에 보물이 숨겨져 있습니다. 탐험가 점을 옮겨 놓을 때마다 '가로로 몇 칸, 세로로 몇 칸 더 가라'는 힌트가 나옵니다. 힌트를 좌표의 차로 읽어 보물의 순서쌍을 찾으며 (x, y)의 순서가 왜 중요한지 확인합니다.",
    obs: ["순서쌍 (a, b)에서 첫째 수는 가로(x), 둘째 수는 세로(y) 위치입니다.", "(2, 3)과 (3, 2)는 서로 다른 점입니다.", "두 점의 x좌표의 차가 가로 거리, y좌표의 차가 세로 거리입니다."],
    q: "보물이 (−3, 4)에 있을 때 친구에게 말로 길을 알려 주려면 어떻게 말해야 할까요?",
    formula: "점 P(a, b): x좌표 a, y좌표 b",
    en: { title: "Treasure Hunt with Coordinates", desc: "Read ordered pairs to find the treasure." },
    view: { x: [-6.5, 6.5], y: [-5, 5] },
    init: () => ({ P: [0, 0] }),
    params: [{ key: "seed", label: "보물 바꾸기", min: 1, max: 12, step: 1, value: 3 }, { key: "show", label: "보물 위치 보이기", type: "check", value: false }],
    drags: { P: { at: (s) => s.P, move: (s, p) => (s.P = [clamp(Math.round(p[0]), -6, 6), clamp(Math.round(p[1]), -4, 4)]), label: "탐험가" } },
    T(s) { const L = [[3, 2], [-4, 3], [5, -2], [-2, -3], [1, 4], [-5, -1], [4, 3], [-3, 4], [2, -4], [-6, 2], [6, 1], [-1, -2]]; return L[(s.seed - 1) % L.length]; },
    draw(s, g) {
      const T = this.T(s), dx = T[0] - s.P[0], dy = T[1] - s.P[1];
      g.grid();
      if (dx) g.vec(s.P, [T[0], s.P[1]], { color: "b", w: 2, dash: "5 4", opacity: 0.7 });
      if (dy) g.vec([T[0], s.P[1]], T, { color: "c", w: 2, dash: "5 4", opacity: 0.7 });
      if (s.show || (!dx && !dy)) g.text(T, "💎", { dy: 6, size: 22, keep: true });
      g.point(s.P, `(${fmt(s.P[0])}, ${fmt(s.P[1])})`, { color: "a" });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], !dx && !dy ? "보물을 찾았어요!" : `힌트: ${dx ? `${dx > 0 ? "오른쪽" : "왼쪽"}으로 ${Math.abs(dx)}칸` : ""}${dx && dy ? ", " : ""}${dy ? `${dy > 0 ? "위" : "아래"}로 ${Math.abs(dy)}칸` : ""}`, { anchor: "start", bold: true, color: !dx && !dy ? "c" : "ink", size: 15 });
    },
    metrics(s) { const T = this.T(s); return [["탐험가의 좌표", `(${fmt(s.P[0])}, ${fmt(s.P[1])})`], ["보물까지 (가로, 세로)", `(${T[0] - s.P[0]}, ${T[1] - s.P[1]})`, "key"]]; },
    predict: [
      { q: "탐험가가 (0, 0)에 있고 힌트가 '오른쪽으로 3칸, 위로 2칸'이면 보물의 x좌표는?", set: (s) => Object.assign(s, { seed: 1, P: [0, 0], show: false }), reveal: (s) => (s.P = [3, 2]), answer: () => 3, why: "보물은 (3, 2)에 있습니다. 첫째 수가 x좌표입니다." },
      { q: "(2, 3)과 (3, 2)는 같은 점일까요?", options: O("다른 점이다", "같은 점이다"), answer: () => "a", why: "순서쌍은 순서가 중요합니다. 가로 2·세로 3과 가로 3·세로 2는 다른 곳입니다." },
    ],
  },
  {
    id: "m1-fill-rate", grade: G1, unit: 4, lesson: "4.2", title: "정비례의 활용 — 물을 채우는 시간과 양", type: "조작", time: "10분",
    tags: ["정비례", "활용", "그래프"], links: ["m1-proportion", "m1-tank-graph"],
    desc: "1분에 a L씩 나오는 수도로 물통을 채울 때, 시간 x분과 물의 양 y L는 y = ax로 정비례합니다. 그래프에서 물통이 가득 차는 시간을 읽고, 물이 나오는 빠르기 a를 바꾸면 그래프가 어떻게 기울어지는지 봅니다.",
    obs: ["x가 2배, 3배가 되면 y도 2배, 3배가 됩니다.", "y/x = a로 일정합니다.", "a가 클수록 그래프가 가파르고 물통이 빨리 찹니다."],
    q: "물통이 가득 차는 데 걸리는 시간과 빠르기 a는 어떤 관계일까요?",
    formula: "y = ax (a: 1분에 나오는 물의 양)",
    en: { title: "Direct Proportion in Action", desc: "Filling a tank at a steady rate." },
    view: { x: [-1.4, 15], y: [-1.2, 11.5] },
    params: [{ key: "a", label: "1분에 나오는 물 a (L)", min: 2, max: 10, step: 1, value: 4 }, { key: "V", label: "물통의 들이 (L)", min: 20, max: 60, step: 4, value: 40 }, { key: "x", label: "시간 x (분)", min: 0, max: 30, step: 0.5, value: 5 }],
    anim: { key: "x", min: 0, max: 30, speed: 4, label: "물 틀기" },
    draw(s, g) {
      const X = (x) => (x / 30) * 10, Y = (y) => (y / 60) * 10, y = Math.min(s.a * s.x, s.V), full = s.V / s.a;
      g.seg([0, 0], [10.4, 0], { color: "axis", w: 1.6 }).seg([0, 0], [0, 10.4], { color: "axis", w: 1.6 });
      for (let t = 0; t <= 30; t += 5) g.text([X(t), 0], String(t), { dy: 16, size: 11, color: "muted" });
      for (let v = 0; v <= 60; v += 10) g.text([0, Y(v)], String(v), { dx: -6, anchor: "end", dy: 4, size: 11, color: "muted" });
      g.text([10.4, 0], "분", { dy: 30, size: 11, color: "muted" }).text([0, 10.6], "L", { dx: 6, anchor: "start", size: 11, color: "muted" });
      g.seg([0, Y(s.V)], [10.4, Y(s.V)], { color: "e", w: 1.4, dash: "5 4" }).text([10.4, Y(s.V)], "가득", { dx: 4, anchor: "start", dy: 4, size: 11, color: "e", bold: true });
      g.seg([0, 0], [X(Math.min(30, full)), Y(Math.min(s.V, 30 * s.a))], { color: "b", w: 3 });
      g.point([X(Math.min(s.x, full)), Y(y)], "", { color: "a" });
      rect(g, 11.6, 0, 2.6, Y(s.V), { color: "ink", w: 2 }); rect(g, 11.6, 0, 2.6, Y(y), { fill: "b", fo: 0.5, stroke: false });
      g.text([12.9, Y(y) + 0.4], `${fmt(y)} L`, { bold: true, color: "b", size: 13 });
    },
    metrics(s) { return [["식", `y = ${s.a}x`], [`${fmt(s.x)}분 뒤 물의 양`, `${fmt(Math.min(s.a * s.x, s.V))} L`], ["가득 차는 시간", `${fmt(s.V / s.a, 2)}분`, "key"]]; },
    predict: [
      { q: "1분에 4 L씩 나올 때 40 L 물통이 가득 차는 시간은 몇 분?", set: (s) => Object.assign(s, { a: 4, V: 40, x: 2 }), reveal: (s) => (s.x = 10), answer: () => 10, why: "4x = 40이므로 x = 10분입니다." },
      { q: "물이 나오는 빠르기를 2배로 하면 가득 차는 시간은?", options: O("절반이 된다", "2배가 된다", "그대로이다"), set: (s) => Object.assign(s, { a: 4, V: 40 }), reveal: (s) => (s.a = 8), answer: () => "a", why: "8x = 40, x = 5분으로 절반입니다." },
    ],
  },
  {
    id: "m1-gears", grade: G1, unit: 4, lesson: "4.2", title: "반비례 톱니바퀴 — 톱니 수 × 회전 수 = 일정", type: "조작", time: "10분",
    tags: ["반비례", "톱니바퀴", "활용"], links: ["m1-proportion"],
    desc: "톱니 24개인 바퀴가 1번 돌 때, 맞물린 바퀴의 톱니 수 x에 따라 회전 수 y가 달라집니다. 맞물린 톱니의 개수는 같으므로 xy = 24이고, 톱니가 적은 바퀴일수록 빨리 도는 반비례 관계를 움직임과 그래프로 확인합니다.",
    obs: ["두 바퀴가 맞물려 지나가는 톱니의 개수는 같습니다.", "그래서 (톱니 수) × (회전 수)가 두 바퀴에서 같습니다.", "x가 2배가 되면 y는 1/2배가 됩니다."],
    q: "자전거의 앞 기어와 뒤 기어 톱니 수는 바퀴 회전과 어떤 관계일까요?",
    formula: "xy = 24 ⇔ y = 24/x",
    en: { title: "Gears and Inverse Proportion", desc: "Teeth × turns stays constant." },
    view: { x: [-5, 11], y: [-5, 5.5] },
    params: [{ key: "x", label: "작은 바퀴의 톱니 수 x", min: 6, max: 24, step: 2, value: 12 }, { key: "t", label: "큰 바퀴 회전", min: 0, max: 2, step: 0.01, value: 0.3 }],
    anim: { key: "t", min: 0, max: 2, speed: 0.15, label: "돌리기", loop: "wrap" },
    gear(g, c, n, r, ang, col) { const pts = []; for (let i = 0; i < n * 4; i++) { const a = ang + (Math.PI * 2 * i) / (n * 4), rr = i % 4 < 2 ? r + 0.22 : r - 0.12; pts.push([c[0] + rr * Math.cos(a), c[1] + rr * Math.sin(a)]); } g.poly(pts, { fill: col, fo: 0.3, color: col, w: 1.4 }); g.seg(c, [c[0] + r * 0.8 * Math.cos(ang), c[1] + r * 0.8 * Math.sin(ang)], { color: col, w: 3 }); g.point(c, "", { color: col, r: 4 }); },
    draw(s, g) {
      const R1 = 2.4, r2 = (R1 * s.x) / 24, c1 = [-1.8, 0.4], c2 = [c1[0] + R1 + r2 + 0.1, 0.4], a1 = 2 * Math.PI * s.t, a2 = -a1 * (24 / s.x) + Math.PI / s.x;
      this.gear(g, c1, 24, R1, a1, "b"); this.gear(g, c2, s.x, r2, a2, "a");
      const X = (x) => 5.6 + (x / 24) * 5, Y = (y) => -4.4 + (y / 4) * 4.4;
      g.seg([X(0), Y(0)], [X(25), Y(0)], { color: "axis", w: 1.2 }).seg([X(0), Y(0)], [X(0), Y(4.2)], { color: "axis", w: 1.2 });
      g.param((x) => [X(x), Y(24 / x)], 6, 24, { color: "c", w: 2.4 });
      g.point([X(s.x), Y(24 / s.x)], `(${s.x}, ${fmt(24 / s.x, 2)})`, { color: "a" });
      g.text([X(12), Y(4.2)], "y = 24/x", { bold: true, color: "c", size: 13 });
    },
    metrics(s) { return [["작은 바퀴의 회전 수 y", `${fmt(24 / s.x, 2)}바퀴`, "key"], ["x × y", `${s.x} × ${fmt(24 / s.x, 2)} = 24`]]; },
    predict: [
      { q: "작은 바퀴의 톱니가 8개이면 큰 바퀴가 1번 돌 때 몇 번 돌까요?", set: (s) => Object.assign(s, { x: 24 }), reveal: (s) => (s.x = 8), answer: () => 3, why: "8y = 24이므로 y = 3바퀴입니다." },
      { q: "톱니 수가 2배가 되면 회전 수는?", options: O("1/2배가 된다", "2배가 된다", "변하지 않는다"), set: (s) => (s.x = 6), reveal: (s) => (s.x = 12), answer: () => "a", why: "곱이 24로 일정한 반비례입니다." },
    ],
  },

  // ───────── 5·6단원 도형 ─────────
  {
    id: "m1-triangle-ineq", grade: G1, unit: 5, lesson: "5.9", title: "세 변으로 삼각형이 될까 — 가장 긴 변 < 나머지 두 변의 합", type: "조작", time: "10분",
    tags: ["삼각형의 결정 조건", "작도", "삼각형의 세 변"], links: ["m1-copy-angle"],
    desc: "세 막대의 길이 a, b, c를 정하고 가장 긴 막대 양 끝에서 나머지 두 막대 길이로 원을 그려 만나는 점을 찾습니다. 두 원이 만나면 삼각형이 되고, 가장 긴 변이 나머지 두 변의 합보다 길거나 같으면 만나지 않아 삼각형이 될 수 없음을 확인합니다.",
    obs: ["두 원이 만나는 점이 삼각형의 세 번째 꼭짓점입니다.", "(가장 긴 변) < (나머지 두 변의 합)이어야 삼각형이 됩니다.", "합과 같으면 세 점이 한 직선 위에 놓여 납작해집니다."],
    q: "길이가 3, 5인 두 막대와 함께 삼각형을 만들 수 있는 셋째 막대의 길이의 범위는?",
    formula: "삼각형이 될 조건: a < b + c (a가 가장 긴 변)",
    en: { title: "When Do Three Sides Make a Triangle?", desc: "The triangle inequality by construction." },
    view: { x: [-1, 11], y: [-3.6, 5.2] },
    params: [{ key: "a", label: "밑변 a", min: 2, max: 9, step: 0.5, value: 8 }, { key: "b", label: "변 b", min: 1, max: 8, step: 0.5, value: 4 }, { key: "c", label: "변 c", min: 1, max: 8, step: 0.5, value: 5 }],
    draw(s, g) {
      const A = [0.5, 0], B = [0.5 + s.a, 0];
      g.seg(A, B, { color: "ink", w: 3.4 }).text([(A[0] + B[0]) / 2, 0], `a = ${fmt(s.a)}`, { dy: 20, bold: true });
      g.circle(A, s.c, { color: "a", w: 1.6, dash: "5 4" }).circle(B, s.b, { color: "b", w: 1.6, dash: "5 4" });
      const d = s.a, x = (d * d + s.c * s.c - s.b * s.b) / (2 * d), h2 = s.c * s.c - x * x;
      if (h2 > 1e-9) { const C = [A[0] + x, Math.sqrt(h2)]; g.poly([A, B, C], { fill: "c", fo: 0.2, color: "c", w: 2.6 }); g.point(C, "", { color: "c" }); g.text([(A[0] + C[0]) / 2, C[1] / 2], `c = ${fmt(s.c)}`, { dx: -8, anchor: "end", bold: true, color: "a" }).text([(B[0] + C[0]) / 2, C[1] / 2], `b = ${fmt(s.b)}`, { dx: 8, anchor: "start", bold: true, color: "b" }); }
      else { g.seg(A, [A[0] + s.c, 0], { color: "a", w: 6, opacity: 0.6 }).seg(B, [B[0] - s.b, 0], { color: "b", w: 6, opacity: 0.6 }); g.text([5, 4.6], Math.abs(h2) < 1e-9 ? "납작해져서 삼각형이 아니에요" : "두 원이 만나지 않아요", { bold: true, color: "e", size: 15 }); }
      g.point(A, "", { color: "ink" }).point(B, "", { color: "ink" });
    },
    metrics(s) { const L = [s.a, s.b, s.c].sort((p, q) => q - p); return [["가장 긴 변", fmt(L[0])], ["나머지 두 변의 합", fmt(L[1] + L[2])], ["삼각형이 되나?", L[0] < L[1] + L[2] ? "된다" : "안 된다", "key"]]; },
    predict: [
      { q: "길이가 2, 3, 6인 막대로 삼각형을 만들 수 있을까요?", options: O("없다", "있다"), set: (s) => Object.assign(s, { a: 6, b: 3, c: 4 }), reveal: (s) => (s.c = 2), answer: () => "a", why: "6 ≥ 2 + 3이라 두 원이 만나지 않습니다." },
      { q: "3과 5와 함께 삼각형을 만들 때 셋째 변의 길이가 될 수 있는 가장 큰 자연수는?", set: (s) => Object.assign(s, { a: 8, b: 5, c: 3 }), reveal: (s) => (s.a = 7), answer: () => 7, why: "셋째 변 x는 5 − 3 < x < 5 + 3, 곧 2 < x < 8이므로 가장 큰 자연수는 7입니다." },
    ],
  },
  {
    id: "m1-regular-angle", grade: G1, unit: 6, lesson: "6.4", title: "정다각형의 한 내각 — 평면을 덮을 수 있는 정다각형", type: "조작", time: "10분",
    tags: ["정다각형", "내각", "테셀레이션"], links: ["interior-sum", "lab-tessellation"],
    desc: "정n각형의 한 내각은 180°(n − 2)/n입니다. 한 꼭짓점에 같은 정다각형을 빙 둘러 붙여 보며 360°가 정확히 나누어떨어지는 정삼각형, 정사각형, 정육각형만 평면을 빈틈없이 덮을 수 있음을 확인합니다.",
    obs: ["정n각형의 내각의 합은 180°(n − 2)입니다.", "360 ÷ (한 내각)이 자연수여야 한 점에 빈틈없이 모입니다.", "그런 정다각형은 정삼각형(60°), 정사각형(90°), 정육각형(120°)뿐입니다."],
    q: "정오각형으로는 왜 바닥 타일을 만들 수 없을까요? 남는 각은 몇 도일까요?",
    formula: "정n각형의 한 내각 = 180°(n − 2)/n",
    en: { title: "Interior Angles of Regular Polygons", desc: "Which ones tile the plane?" },
    view: { x: [-5, 9], y: [-4.6, 4.6] },
    params: [{ key: "n", label: "n (정n각형)", min: 3, max: 12, step: 1, value: 5 }],
    anim: { key: "n", min: 3, max: 12, speed: 1, label: "n 바꾸기" },
    draw(s, g) {
      const A = (180 * (s.n - 2)) / s.n, side = 1.6, k = Math.floor(360 / A + 1e-9), cols = ["a", "b", "c", "d", "e", "f"];
      for (let j = 0; j < k; j++) { const rot = (j * A * Math.PI) / 180, pts = [[0, 0]]; let p = [0, 0], dir = rot; for (let i = 0; i < s.n - 1; i++) { p = [p[0] + side * Math.cos(dir), p[1] + side * Math.sin(dir)]; pts.push(p); dir += Math.PI - (A * Math.PI) / 180; } g.poly(pts, { fill: cols[j % 6], fo: 0.35, color: cols[j % 6], w: 1.6 }); }
      const gap = 360 - k * A;
      if (gap > 0.5) { const a0 = (k * A * Math.PI) / 180; g.arc([0, 0], [Math.cos(a0), Math.sin(a0)], [1, 0], { color: "e", r: 30, label: `빈틈 ${fmt(gap, 1)}°` }); }
      g.point([0, 0], "", { color: "ink", r: 4 });
      g.text([4.6, 3.6], `정${s.n}각형`, { anchor: "start", bold: true, size: 18 }).text([4.6, 2.6], `한 내각 ${fmt(A, 2)}°`, { anchor: "start", bold: true, size: 15, color: "b" }).text([4.6, 1.6], gap < 0.5 ? `${k}개로 360° 딱 맞음!` : `${k}개를 붙여도 ${fmt(gap, 1)}° 남음`, { anchor: "start", bold: true, size: 14, color: gap < 0.5 ? "c" : "e" });
    },
    metrics(s) { const A = (180 * (s.n - 2)) / s.n; return [["한 내각", `${fmt(A, 2)}°`, "key"], ["360 ÷ 한 내각", fmt(360 / A, 3)], ["평면을 덮을 수 있나?", Math.abs(360 / A - Math.round(360 / A)) < 1e-9 ? "예" : "아니요"]]; },
    predict: [
      { q: "정오각형의 한 내각은 몇 도?", set: (s) => (s.n = 4), reveal: (s) => (s.n = 5), answer: () => 108, why: "180 × 3 ÷ 5 = 108°입니다. 3개를 붙이면 324°로 36°가 남습니다." },
      { q: "평면을 빈틈없이 덮을 수 있는 정다각형은 모두 몇 가지?", set: (s) => (s.n = 3), reveal: (s) => (s.n = 6), answer: () => 3, why: "정삼각형, 정사각형, 정육각형의 3가지입니다." },
    ],
  },
  {
    id: "m1-pizza-area", grade: G1, unit: 6, lesson: "6.5", title: "피자 조각 재배열로 원의 넓이 구하기", type: "조작", time: "10분",
    tags: ["원의 넓이", "부채꼴", "원주율"], links: ["sector", "pi-estimation"],
    desc: "원을 2n개의 부채꼴로 잘라 위아래로 엇갈리게 늘어놓으면, n이 클수록 가로가 원주의 반(πr), 세로가 반지름 r인 직사각형에 가까워집니다. 그래서 원의 넓이가 πr × r = πr²임을 확인합니다.",
    obs: ["조각을 엇갈려 놓으면 위와 아래에 원주가 반씩 놓입니다.", "조각이 많아질수록 밑변이 곧아져 직사각형에 가까워집니다.", "가로 πr, 세로 r이므로 넓이는 πr²입니다."],
    q: "같은 방법으로 반지름이 2배인 원의 넓이는 몇 배가 될지 설명해 봅시다.",
    formula: "원의 넓이 = (원주의 반) × r = πr × r = πr²",
    en: { title: "Circle Area by Rearranging Slices", desc: "Pizza slices form a rectangle." },
    view: { x: [-3.4, 13], y: [-3.2, 3.4] },
    params: [{ key: "n", label: "조각 수의 반 n", min: 2, max: 24, step: 1, value: 6 }, { key: "r", label: "반지름 r", min: 1, max: 2.6, step: 0.1, value: 2.2 }],
    anim: { key: "n", min: 2, max: 24, speed: 3, label: "조각 늘리기" },
    draw(s, g) {
      const N = 2 * s.n, da = (2 * Math.PI) / N, cols = ["a", "b"];
      for (let i = 0; i < N; i++) { const pts = [[-0.8, 0]]; for (let t = 0; t <= 8; t++) { const a = i * da + (da * t) / 8; pts.push([-0.8 + s.r * Math.cos(a) * 0.9, s.r * Math.sin(a) * 0.9]); } g.poly(pts, { fill: cols[i % 2], fo: 0.45, color: "paper", w: 1 }); }
      const w = (Math.PI * s.r) / s.n, x0 = 2.6, yb = -s.r / 2;
      for (let i = 0; i < N; i++) {
        const up = i % 2 === 0, cx = x0 + (i * w) / 2 + (up ? 0 : 0), pts = [];
        if (up) { const apex = [x0 + (i / 2) * w + w / 2, yb + s.r]; pts.push(apex); for (let t = 0; t <= 8; t++) { const a = -Math.PI / 2 - da / 2 + (da * t) / 8; pts.push([apex[0] + s.r * Math.cos(a), apex[1] + s.r * Math.sin(a)]); } }
        else { const apex = [x0 + ((i + 1) / 2) * w, yb]; pts.push(apex); for (let t = 0; t <= 8; t++) { const a = Math.PI / 2 - da / 2 + (da * t) / 8; pts.push([apex[0] + s.r * Math.cos(a), apex[1] + s.r * Math.sin(a)]); } }
        g.poly(pts, { fill: cols[i % 2], fo: 0.45, color: "paper", w: 1 });
      }
      const L = s.n * w;
      g.seg([x0, yb - 0.35], [x0 + L, yb - 0.35], { color: "e", w: 1.6 }).text([x0 + L / 2, yb - 0.35], `πr = ${fmt(Math.PI * s.r, 2)}`, { dy: 16, bold: true, color: "e", size: 13 });
      g.seg([x0 + L + 0.35, yb], [x0 + L + 0.35, yb + s.r], { color: "c", w: 1.6 }).text([x0 + L + 0.35, yb + s.r / 2], `r = ${fmt(s.r)}`, { dx: 6, anchor: "start", bold: true, color: "c", size: 13 });
    },
    metrics(s) { return [["가로 × 세로", `${fmt(Math.PI * s.r, 3)} × ${fmt(s.r)}`], ["원의 넓이 πr²", fmt(Math.PI * s.r * s.r, 3), "key"], ["조각 수", `${2 * s.n}조각`]]; },
    predict: [
      { q: "반지름이 2인 원의 넓이는? (π = 3.14로 계산)", set: (s) => Object.assign(s, { r: 2, n: 3 }), reveal: (s) => (s.n = 24), answer: () => 12.56, tol: 0.01, why: "가로 πr = 2π, 세로 r = 2이므로 4π = 12.56입니다." },
      { q: "조각을 아주 많이 자르면 늘어놓은 모양은 어떤 도형에 가까워질까요?", options: O("직사각형", "삼각형", "원"), set: (s) => (s.n = 3), reveal: (s) => (s.n = 24), answer: () => "a", why: "밑변의 울퉁불퉁함이 사라지고 옆변이 곧게 서서 직사각형이 됩니다." },
    ],
  },
];
