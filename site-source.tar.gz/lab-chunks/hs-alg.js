// 대수 — Ⅲ 삼각함수 · Ⅳ 삼각함수의 활용
import { fmt, frac, surd, piFmt, dist, sub, add, mul, norm, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const G = 5;
const TAU = Math.PI * 2;
const EXACT = {
  sin: { 0: "0", 30: "1/2", 45: "√2/2", 60: "√3/2", 90: "1" },
  cos: { 0: "1", 30: "√3/2", 45: "√2/2", 60: "1/2", 90: "0" },
  tan: { 0: "0", 30: "√3/3", 45: "1", 60: "√3" },
};
// 특수각이면 정확한 값, 아니면 소수
export function trigStr(fn, d) {
  const a = ((Math.round(d) % 360) + 360) % 360;
  if (Math.abs(d - Math.round(d)) < 1e-9) {
    const ref = a <= 90 ? a : a <= 180 ? 180 - a : a <= 270 ? a - 180 : 360 - a;
    const q = a < 90 ? 1 : a < 180 ? 2 : a < 270 ? 3 : 4;
    if (fn === "tan" && (a === 90 || a === 270)) return "정의되지 않음";
    const table = EXACT[fn][ref];
    if (table != null) {
      let neg;
      if (fn === "sin") neg = a > 180;
      else if (fn === "cos") neg = a > 90 && a < 270;
      else neg = q === 2 || q === 4;
      if (table === "0") return "0";
      return (neg ? "−" : "") + table;
    }
  }
  const r = deg(d), v = fn === "sin" ? Math.sin(r) : fn === "cos" ? Math.cos(r) : Math.tan(r);
  return fmt(v, 4);
}
const F = { sin: Math.sin, cos: Math.cos, tan: Math.tan };
const piTicks = (g, y0 = 0, from = -TAU, to = TAU, step = Math.PI / 2) => {
  for (let x = Math.ceil(from / step) * step; x <= to + 1e-9; x += step) {
    if (Math.abs(x) < 1e-9) continue;
    g.seg([x, y0 - 0.08], [x, y0 + 0.08], { color: "axis", w: 1.4 });
    g.text([x, y0], piFmt(x), { dy: 20, color: "muted", size: 12.5 });
  }
};
const angleDegParam = (key, label, value, min = 0, max = 360) => ({ key, label, min, max, step: 1, value, unit: "°" });

export default [
  {
    id: "alg-radian", grade: G, unit: 3, lesson: "Ⅲ-1", title: "일반각과 호도법", type: "조작", time: "10분",
    tags: ["일반각", "라디안", "회전"], links: ["sector", "alg-unit-circle"],
    desc: "동경을 여러 바퀴 돌려 일반각을 만들고, 반지름과 같은 길이의 호가 만드는 1라디안으로 각을 다시 잽니다.",
    obs: ["시초선에서 시계 반대 방향 회전은 양의 각, 시계 방향은 음의 각입니다.", "동경의 위치가 같아도 회전한 바퀴 수에 따라 각은 360°×n만큼 다릅니다.", "반지름이 달라져도 호의 길이 ÷ 반지름은 같습니다."],
    q: "반지름이 2배가 되면 같은 중심각의 라디안 값은 어떻게 될까요?",
    formula: "360°×n + α · 180° = π rad · l = rθ · S = ½r²θ",
    en: { title: "General Angles and Radians", desc: "Rotate the terminal side through several turns and measure angles in radians." },
    view: { x: [-6, 6], y: [-4.1, 4.1] },
    params: [
      { key: "t", label: "회전한 각 θ", min: -720, max: 720, step: 5, value: 405, unit: "°" },
      { key: "r", label: "반지름 r", min: 1.5, max: 3.5, step: 0.5, value: 2.5 },
      { key: "one", label: "1라디안(호의 길이 = 반지름) 보기", type: "check", value: true },
    ],
    anim: { key: "t", min: -720, max: 720, speed: 120, label: "동경 돌리기" },
    drags: { P: { at: (s) => [s.r * Math.cos(deg(s.t)), s.r * Math.sin(deg(s.t))], move: (s, p) => { const a = rad2deg(Math.atan2(p[1], p[0])); s.t = Math.round((a + 360 * Math.round((s.t - a) / 360)) / 5) * 5; } } },
    draw(s, g) {
      g.grid({ labels: false });
      const r = s.r, th = deg(s.t);
      g.circle([0, 0], r, { color: "muted", w: 1.4, dash: "3 6" });
      if (s.one) { g.poly([[0, 0], ...Array.from({ length: 31 }, (_, i) => [r * Math.cos(i / 30), r * Math.sin(i / 30)])], { fill: "f", fo: 0.22, color: "f", w: 1.6 }); g.text([1.25 * r * Math.cos(0.5), 1.25 * r * Math.sin(0.5)], "1 rad", { color: "f", bold: true }); }
      const within = Math.max(-TAU, Math.min(TAU, th));
      g.param((u) => [r * Math.cos(u), r * Math.sin(u)], 0, within, { color: "a", w: 5, opacity: 0.55 });
      const turns = Math.abs(th) / TAU;
      g.param((u) => { const rr = 0.45 + (0.35 * Math.abs(u)) / TAU; return [rr * Math.cos(u), rr * Math.sin(u)]; }, 0, th, { color: "e", w: 2, n: Math.max(60, Math.round(turns * 160)) });
      const end = 0.45 + (0.35 * Math.abs(th)) / TAU;
      g.vec([end * Math.cos(th - Math.sign(th) * 0.18), end * Math.sin(th - Math.sign(th) * 0.18)], [end * Math.cos(th), end * Math.sin(th)], { color: "e", w: 2 });
      g.seg([0, 0], [r + 1.2, 0], { color: "ink", w: 2.4 }).text([r + 1.2, 0], "시초선 OX", { dy: 22, anchor: "end", color: "muted" });
      const P = [r * Math.cos(th), r * Math.sin(th)];
      g.seg([0, 0], mul(P, (r + 1.2) / r), { color: "a", w: 3.4 });
      g.point(P, "P", { color: "a" }).point([0, 0], "O", { color: "ink", r: 4, dx: -14, dy: 18 });
    },
    metrics(s) {
      const n = Math.floor(s.t / 360), a = s.t - 360 * n, th = deg(s.t);
      const q = a % 90 === 0 ? "좌표축 위" : `제${Math.floor(a / 90) + 1}사분면`;
      const out = [["일반각", `360° × (${n}) + ${fmt(a)}°`], ["호도법", `${piFmt(th)} rad`, "key"], ["동경의 위치", q]];
      if (s.t > 0 && s.t <= 360) out.push(["호의 길이 rθ", fmt(s.r * th)], ["부채꼴 넓이 ½r²θ", fmt(0.5 * s.r * s.r * th)]);
      else out.push("호의 길이·넓이는 0 < θ ≤ 2π일 때 봅니다.");
      return out;
    },
  },
  {
    id: "alg-unit-circle", grade: G, unit: 3, lesson: "Ⅲ-2", title: "삼각함수의 뜻", type: "2D", time: "10분",
    tags: ["단위원", "사분면", "부호"], links: ["g3-acute-trig", "alg-graph-wrap"],
    desc: "원 위의 점 P(x, y)를 돌리며 sin θ = y/r, cos θ = x/r, tan θ = y/x가 사분면마다 어떤 부호를 갖는지 확인합니다.",
    obs: ["삼각함수의 값은 반지름 r에 관계없이 각 θ로 정해집니다.", "제1사분면은 모두 양, 제2사분면은 sin만, 제3사분면은 tan만, 제4사분면은 cos만 양입니다.", "θ가 90°, 270°일 때 x = 0이므로 tan θ는 정의되지 않습니다."],
    q: "sin θ < 0이고 tan θ > 0이면 θ는 어느 사분면의 각일까요?",
    formula: "sin θ = y/r · cos θ = x/r · tan θ = y/x (x ≠ 0)",
    en: { title: "Defining Trigonometric Functions", desc: "Rotate P(x, y) on a circle and track sin, cos and tan with their signs in each quadrant." },
    view: { x: [-6, 6], y: [-4.2, 4.2] },
    params: [angleDegParam("t", "각 θ", 150), { key: "r", label: "반지름 r", min: 1.5, max: 3.8, step: 0.1, value: 3 }],
    anim: { key: "t", min: 0, max: 360, speed: 40, loop: "wrap", label: "점 P 돌리기" },
    points: { P: [0, 0] },
    derive(s) { s.P = [s.r * Math.cos(deg(s.t)), s.r * Math.sin(deg(s.t))]; },
    constrain(s, k, p) { let a = rad2deg(Math.atan2(p[1], p[0])); if (a < 0) a += 360; s.t = Math.round(a); return [s.r * Math.cos(deg(s.t)), s.r * Math.sin(deg(s.t))]; },
    draw(s, g) {
      g.grid({ labels: false });
      const r = s.r, th = deg(s.t), P = [r * Math.cos(th), r * Math.sin(th)], Q = Math.floor((((s.t % 360) + 360) % 360) / 90);
      const signs = [["모두 +"], ["sin +"], ["tan +"], ["cos +"]];
      [[1, 1], [-1, 1], [-1, -1], [1, -1]].forEach(([a, b], i) => g.text([a * 4.6, b * 3.5], `제${i + 1}사분면 · ${signs[i][0]}`, { color: i === Q && s.t % 90 ? "a" : "muted", bold: i === Q, size: 13 }));
      g.circle([0, 0], r, { color: "b", w: 2.4, fill: "b", fo: 0.04 });
      g.arc([0, 0], [1, 0], P, { r: 30, color: "e", label: "θ" });
      g.seg([0, 0], [P[0], 0], { color: "c", w: 4 }).seg([P[0], 0], P, { color: "a", w: 4 }).seg([0, 0], P, { color: "ink", w: 2.6 });
      if (Math.abs(P[1]) > 0.3 && Math.abs(P[0]) > 0.3) g.right([P[0], 0], [0, 0], P, { size: 10 });
      g.text([P[0] / 2, 0], `x = ${fmt(P[0])}`, { color: "c", dy: P[1] >= 0 ? 20 : -10, bold: true });
      g.text([P[0], P[1] / 2], `y = ${fmt(P[1])}`, { color: "a", dx: P[0] >= 0 ? 10 : -10, anchor: P[0] >= 0 ? "start" : "end", bold: true });
      g.point(P, "P(x, y)", { color: "a" }).handle(P, "P");
    },
    metrics(s) {
      return [["θ", `${fmt(s.t)}° = ${piFmt(deg(s.t))}`], ["sin θ = y/r", trigStr("sin", s.t), "key"], ["cos θ = x/r", trigStr("cos", s.t), "key"], ["tan θ = y/x", trigStr("tan", s.t), "key"]];
    },
  },
  {
    id: "alg-graph-wrap", grade: G, unit: 3, lesson: "Ⅲ-3", title: "원에서 풀려 나오는 삼각함수의 그래프", type: "조작", time: "12분",
    tags: ["주기", "대관람차", "그래프"], links: ["alg-unit-circle", "alg-transform"],
    desc: "단위원 위의 점이 돌 때 높이(sin)·가로 위치(cos)·접선 위 길이(tan)가 그래프로 풀려 나오는 모습을 봅니다.",
    obs: ["점이 한 바퀴(2π) 돌면 sin, cos의 그래프는 같은 모양을 되풀이합니다.", "tan의 그래프는 π마다 되풀이되고 θ = π/2 근처에서 끝없이 커집니다.", "cos의 그래프는 sin의 그래프를 왼쪽으로 π/2만큼 옮긴 것입니다."],
    q: "대관람차 곤돌라의 높이 그래프에서 주기와 최댓값은 무엇을 뜻할까요?",
    formula: "sin(θ + 2π) = sin θ · cos(θ + 2π) = cos θ · tan(θ + π) = tan θ",
    en: { title: "Graphs Unwinding from the Circle", desc: "Watch height, horizontal position and tangent length unwind into the sine, cosine and tangent graphs." },
    view: { x: [-7, 8.6], y: [-3.2, 3.2] },
    params: [
      { key: "fn", label: "함수", type: "seg", value: "sin", options: [["sin", "y = sin θ"], ["cos", "y = cos θ"], ["tan", "y = tan θ"]] },
      { key: "t", label: "θ", min: 0, max: 6.2832, step: 0.01, value: 2.2, show: (v) => `${fmt(rad2deg(v), 0)}°` },
      { key: "wheel", label: "대관람차로 보기 (sin)", type: "check", value: false },
    ],
    anim: { key: "t", min: 0, max: 6.2832, speed: 0.9, loop: "wrap", label: "점 돌리기" },
    drags: { P: { at: (s) => [-4.6 + 1.6 * Math.cos(s.t), 1.6 * Math.sin(s.t)], move: (s, p) => { let a = Math.atan2(p[1], p[0] + 4.6); if (a < 0) a += 2 * Math.PI; s.t = a; } }, G: { at: (s) => [-2.1 + s.t * 1.6, Math.max(-3.1, Math.min(3.1, 1.6 * F[s.fn](s.t)))], move: (s, p) => (s.t = (p[0] + 2.1) / 1.6), color: "b" } },
    draw(s, g) {
      const R = 1.6, C = [-4.6, 0], X0 = -2.1, kx = 1.6, f = F[s.fn], th = s.t;
      const gx = (u) => X0 + u * kx;
      g.seg([-7, 0], [8.6, 0], { color: "axis", w: 1.3 }).seg([X0, -3.1], [X0, 3.1], { color: "axis", w: 1.3 });
      [1, -1].forEach((v) => g.seg([X0, v * R], [gx(TAU), v * R], { color: "grid", w: 1.2 }));
      for (let k = 1; k <= 4; k++) { const x = gx((k * Math.PI) / 2); g.seg([x, -0.08], [x, 0.08], { color: "axis", w: 1.4 }); g.text([x, 0], piFmt((k * Math.PI) / 2), { dy: 20, color: "muted", size: 12.5 }); }
      g.text([X0, R], "1", { dx: -10, dy: 5, anchor: "end", color: "muted", size: 12.5 }).text([X0, -R], "−1", { dx: -10, dy: 5, anchor: "end", color: "muted", size: 12.5 });
      g.circle(C, R, { color: "b", w: 2.4 });
      if (s.wheel && s.fn === "sin") for (let k = 0; k < 8; k++) { const a = th + (k * TAU) / 8; g.seg(C, add(C, [R * Math.cos(a), R * Math.sin(a)]), { color: "muted", w: 1, opacity: 0.6 }); g.circle(add(C, [R * Math.cos(a), R * Math.sin(a)]), 0.12, { color: "muted", w: 1.2 }); }
      const P = add(C, [R * Math.cos(th), R * Math.sin(th)]);
      const yv = (u) => R * f(u);
      const ghost = (u) => [gx(u), yv(u)];
      g.param(ghost, 0, TAU, { color: "muted", w: 1.6, dash: "4 6", n: 400 });
      g.param(ghost, 0, th, { color: "a", w: 3.6, n: 400 });
      g.seg(C, P, { color: "ink", w: 2 }).arc(C, add(C, [1, 0]), P, { r: 18, color: "e" });
      if (s.fn === "sin") { g.seg([P[0], C[1]], P, { color: "a", w: 3.4 }); g.seg(P, [gx(th), P[1]], { color: "a", w: 1.4, dash: "4 5" }); }
      if (s.fn === "cos") {
        g.seg(C, [P[0], C[1]], { color: "c", w: 3.4 });
        const Y = yv(th); g.seg([gx(th), 0], [gx(th), Y], { color: "c", w: 3.4, opacity: 0.8 });
        g.path([[P[0], C[1]], [P[0], -2.6], [gx(th) - 0.001, -2.6]], { color: "c", w: 1.2, dash: "3 5", opacity: 0.7 });
        g.text([P[0], -2.6], "x좌표를 세로로 옮김", { dy: 18, color: "c", size: 12 });
      }
      if (s.fn === "tan" && Math.abs(Math.cos(th)) > 0.05) {
        const T = add(C, [R, R * Math.tan(th)]);
        g.seg(add(C, [R, -3.1]), add(C, [R, 3.1]), { color: "muted", w: 1.4, dash: "4 5" });
        if (Math.abs(T[1]) < 3.2) { g.seg(C, T, { color: "d", w: 1.6, dash: "5 4" }); g.seg(add(C, [R, 0]), T, { color: "d", w: 3.4 }); g.seg(T, [gx(th), T[1]], { color: "d", w: 1.2, dash: "4 5" }); }
      }
      const Y = yv(th);
      if (Math.abs(Y) < 3.2) g.point([gx(th), Y], "", { color: "a", r: 6 });
      g.point(P, "P", { color: "a" });
    },
    metrics(s) {
      const d = rad2deg(s.t), per = s.fn === "tan" ? "π" : "2π";
      return [["θ", `${fmt(d, 1)}° ≈ ${fmt(s.t, 3)} rad`], [`${s.fn} θ`, trigStr(s.fn, Math.round(d) === d ? d : d)], ["주기", per, "key"], ["치역", s.fn === "tan" ? "실수 전체" : "−1 ≤ y ≤ 1"]];
    },
  },
  {
    id: "alg-transform", grade: G, unit: 3, lesson: "Ⅲ-3", title: "주기·진폭 바꾸기 y = a sin(bx + c) + d", type: "2D", time: "12분",
    tags: ["주기", "최댓값", "평행이동"], links: ["alg-graph-wrap", "c2-translation"],
    desc: "a, b, c, d를 하나씩 바꾸며 그래프가 세로로 늘어나고, 가로로 줄어들고, 옮겨지는 방식을 기본 그래프와 비교합니다.",
    obs: ["|a|는 진폭, 즉 최댓값과 최솟값의 차의 절반을 정합니다.", "b가 커지면 주기 2π/|b|가 짧아집니다.", "bx + c = b(x + c/b)이므로 그래프는 x축 방향으로 −c/b만큼 평행이동합니다."],
    q: "y = sin(2x + π)와 y = sin 2x + π는 어떻게 다를까요?",
    formula: "주기 2π/|b| (tan은 π/|b|) · 최댓값 |a| + d · 최솟값 −|a| + d",
    en: { title: "Amplitude and Period", desc: "Change a, b, c and d one at a time and compare with the basic graph." },
    view: { x: [-7, 7], y: [-5, 5] },
    params: [
      { key: "fn", label: "함수", type: "seg", value: "sin", options: [["sin", "sin"], ["cos", "cos"], ["tan", "tan"]] },
      { key: "a", label: "a (세로 배율)", min: -3, max: 3, step: 0.5, value: 2 },
      { key: "b", label: "b (가로 압축)", min: 0.5, max: 4, step: 0.5, value: 2 },
      { key: "c", label: "c", min: -3.1416, max: 3.1416, step: Math.PI / 12, value: Math.PI / 3, show: piFmt },
      { key: "d", label: "d (위아래 이동)", min: -2, max: 2, step: 0.5, value: 0.5 },
    ],
    drags: { S: { at: (s) => [-s.c / s.b, s.fn === "cos" ? s.a + s.d : s.d], move: (s, p) => { s.c = Math.round((-p[0] * s.b) / (Math.PI / 12)) * (Math.PI / 12); s.d = Math.round((p[1] - (s.fn === "cos" ? s.a : 0)) * 2) / 2; }, color: "e", label: "시작점" }, A: { when: (s) => s.fn === "sin", at: (s) => [(Math.PI / 2 - s.c) / s.b, s.a + s.d], move: (s, p) => (s.a = Math.round((p[1] - s.d) * 2) / 2), color: "c", label: "진폭" } },
    draw(s, g) {
      g.grid({ labels: false });
      piTicks(g, 0, -7, 7);
      for (let y = -4; y <= 4; y++) if (y) g.text([0, y], String(y).replace("-", "−"), { dx: -8, dy: 5, anchor: "end", color: "muted", size: 12 });
      const f = F[s.fn], h = (x) => s.a * f(s.b * x + s.c) + s.d;
      g.fx(f, { color: "muted", w: 1.6, dash: "4 6" });
      if (s.fn !== "tan") {
        const A = Math.abs(s.a);
        g.seg([-7, A + s.d], [7, A + s.d], { color: "c", w: 1.2, dash: "6 5" }).seg([-7, -A + s.d], [7, -A + s.d], { color: "c", w: 1.2, dash: "6 5" });
        g.seg([-7, s.d], [7, s.d], { color: "e", w: 1.2, dash: "2 5" });
        const x0 = -s.c / s.b, P = (2 * Math.PI) / s.b, yb = -A + s.d - 0.45;
        if (P < 13) { g.seg([x0, yb], [x0 + P, yb], { color: "f", w: 3 }); g.text([x0 + P / 2, yb], `주기 ${piFmt(P)}`, { dy: 20, color: "f", bold: true }); }
      }
      g.fx(h, { color: "a", w: 3.4 });
    },
    metrics(s) {
      const A = Math.abs(s.a), P = (s.fn === "tan" ? Math.PI : 2 * Math.PI) / s.b;
      const eq = `y = ${s.a === 1 ? "" : s.a === -1 ? "−" : fmt(s.a)}${s.fn}(${fmt(s.b) === "1" ? "" : fmt(s.b)}x${Math.abs(s.c) > 1e-9 ? (s.c > 0 ? " + " : " − ") + piFmt(Math.abs(s.c)) : ""})${s.d ? (s.d > 0 ? " + " : " − ") + fmt(Math.abs(s.d)) : ""}`;
      if (s.a === 0) return [["식", `y = ${fmt(s.d)}`, "key"], "a = 0이면 상수함수가 됩니다."];
      const out = [["식", eq, "key"], ["주기", piFmt(P)], ["평행이동", `x축 방향 ${piFmt(-s.c / s.b)}`]];
      if (s.fn !== "tan") out.push(["최댓값", fmt(A + s.d)], ["최솟값", fmt(-A + s.d)]);
      else out.push(["최댓값·최솟값", "없음"]);
      return out;
    },
  },
  {
    id: "alg-identities", grade: G, unit: 3, lesson: "Ⅲ-4", title: "삼각함수의 성질 (대칭으로 보기)", type: "2D", time: "10분",
    tags: ["−θ", "π ± θ", "π/2 − θ"], links: ["c2-reflection", "alg-unit-circle"],
    desc: "단위원 위의 점 P(θ)를 x축·y축·원점·직선 y = x에 대칭이동하여 −θ, π ± θ, π/2 ± θ의 삼각함수 값을 θ로 나타냅니다.",
    obs: ["x축 대칭은 y좌표의 부호만 바꾸므로 sin(−θ) = −sin θ입니다.", "직선 y = x 대칭은 x, y를 바꾸므로 sin(π/2 − θ) = cos θ입니다.", "모든 일반각의 삼각함수 값은 0°~90°의 값으로 나타낼 수 있습니다."],
    q: "cos(π/2 + θ)를 sin θ로 나타내 보세요.",
    formula: "sin(−θ) = −sin θ · sin(π − θ) = sin θ · sin(π + θ) = −sin θ · sin(π/2 − θ) = cos θ",
    en: { title: "Trigonometric Identities by Symmetry", desc: "Reflect P(θ) on the unit circle to express −θ, π ± θ and π/2 ± θ in terms of θ." },
    view: { x: [-5.2, 5.2], y: [-3.6, 3.6] },
    params: [
      { key: "rel", label: "관계", type: "seg", value: "pi-", options: [["neg", "−θ"], ["pi-", "π − θ"], ["pi+", "π + θ"], ["h-", "π/2 − θ"], ["h+", "π/2 + θ"]] },
      angleDegParam("t", "θ", 35, 0, 360),
    ],
    Q(s) { const t = s.t; return { neg: -t, "pi-": 180 - t, "pi+": 180 + t, "h-": 90 - t, "h+": 90 + t }[s.rel]; },
    draw(s, g) {
      g.grid({ labels: false });
      const R = 3, P = [R * Math.cos(deg(s.t)), R * Math.sin(deg(s.t))], q = this.Q(s), Q = [R * Math.cos(deg(q)), R * Math.sin(deg(q))];
      g.circle([0, 0], R, { color: "b", w: 2.2 });
      const axis = { neg: [[-5, 0], [5, 0]], "pi-": [[0, -3.6], [0, 3.6]], "h-": [[-3.6, -3.6], [3.6, 3.6]] }[s.rel];
      if (axis) g.seg(axis[0], axis[1], { color: "e", w: 2.6, dash: "8 5" });
      if (s.rel === "pi+") g.point([0, 0], "대칭의 중심", { color: "e", dy: 20 });
      if (s.rel === "h+") g.arc([0, 0], P, Q, { r: 44, color: "e", label: "90° 회전" });
      g.seg([0, 0], P, { color: "b", w: 2.6 }).seg([0, 0], Q, { color: "a", w: 2.6 });
      g.seg(P, [P[0], 0], { color: "b", w: 1.6, dash: "4 4" }).seg(Q, [Q[0], 0], { color: "a", w: 1.6, dash: "4 4" });
      g.seg(P, Q, { color: "muted", w: 1.2, dash: "2 5" });
      g.point(P, "P(θ)", { color: "b" }).point(Q, `Q(${{ neg: "−θ", "pi-": "π − θ", "pi+": "π + θ", "h-": "π/2 − θ", "h+": "π/2 + θ" }[s.rel]})`, { color: "a" });
    },
    metrics(s) {
      const q = this.Q(s), name = { neg: "−θ", "pi-": "π − θ", "pi+": "π + θ", "h-": "π/2 − θ", "h+": "π/2 + θ" }[s.rel];
      const rule = { neg: ["−sin θ", "cos θ", "−tan θ"], "pi-": ["sin θ", "−cos θ", "−tan θ"], "pi+": ["−sin θ", "−cos θ", "tan θ"], "h-": ["cos θ", "sin θ", "1/tan θ"], "h+": ["cos θ", "−sin θ", "−1/tan θ"] }[s.rel];
      return [[`sin(${name})`, `= ${rule[0]} = ${trigStr("sin", q)}`, "key"], [`cos(${name})`, `= ${rule[1]} = ${trigStr("cos", q)}`, "key"], [`tan(${name})`, `= ${rule[2]} = ${trigStr("tan", q)}`], ["θ 값", `sin θ = ${trigStr("sin", s.t)}, cos θ = ${trigStr("cos", s.t)}`]];
    },
  },
  {
    id: "alg-trig-eq", grade: G, unit: 3, lesson: "Ⅲ-5", title: "삼각방정식과 부등식", type: "2D", time: "10분",
    tags: ["교점", "해의 범위", "그래프"], links: ["alg-graph-wrap"],
    desc: "0 ≤ x < 2π에서 y = sin x (cos x, tan x)의 그래프와 직선 y = k의 교점으로 방정식을 풀고, 위·아래 부분으로 부등식을 풉니다.",
    obs: ["교점의 x좌표가 방정식의 해입니다.", "|k| > 1이면 sin x = k의 해는 없습니다.", "부등식의 해는 그래프가 직선보다 위(또는 아래)에 있는 x의 범위입니다."],
    q: "sin x = 1/2과 sin x > 1/2의 해를 그래프로 비교해 보세요.",
    formula: "sin x = k ⇔ 그래프 y = sin x와 직선 y = k의 교점의 x좌표",
    en: { title: "Trigonometric Equations and Inequalities", desc: "Solve equations and inequalities on [0, 2π) from intersections with the line y = k." },
    view: { x: [-0.6, 7], y: [-2.2, 2.2] },
    params: [
      { key: "fn", label: "함수", type: "seg", value: "sin", options: [["sin", "sin x"], ["cos", "cos x"], ["tan", "tan x"]] },
      { key: "k", label: "k", min: -2, max: 2, step: 0.05, value: 0.5 },
      { key: "ineq", label: "비교", type: "seg", value: ">", options: [["=", "= k"], [">", "> k"], ["<", "< k"]] },
    ],
    roots(s) {
      const f = F[s.fn], out = [], N = 2000;
      for (let i = 0; i < N; i++) {
        let a = (TAU * i) / N, b = (TAU * (i + 1)) / N, fa = f(a) - s.k, fb = f(b) - s.k;
        if (Math.abs(fa) < 1e-12) { out.push(a); continue; }
        if (fa * fb < 0 && Math.abs(fa - fb) < 5) { for (let j = 0; j < 50; j++) { const m = (a + b) / 2, fm = f(m) - s.k; if (fa * fm <= 0) { b = m; fb = fm; } else { a = m; fa = fm; } } out.push((a + b) / 2); }
      }
      return out.filter((x, i, arr) => i === 0 || x - arr[i - 1] > 1e-6);
    },
    drags: { K: { at: (s) => [6.6, s.k], move: (s, p) => (s.k = p[1]), color: "b" } },
    draw(s, g) {
      g.grid({ labels: false });
      piTicks(g, 0, 0, TAU);
      [-1, 1].forEach((y) => g.text([0, y], String(y).replace("-", "−"), { dx: -8, dy: 5, anchor: "end", color: "muted", size: 12 }));
      const f = F[s.fn];
      if (s.ineq !== "=") {
        const ok = (x) => { const v = f(x); return s.fn === "tan" && Math.abs(Math.cos(x)) < 1e-3 ? false : s.ineq === ">" ? v > s.k : v < s.k; };
        let st = null;
        for (let i = 0; i <= 1200; i++) { const x = (TAU * i) / 1200, o = i < 1200 && ok(x); if (o && st == null) st = x; if (!o && st != null) { g.seg([st, 0], [x, 0], { color: "c", w: 7, opacity: 0.55 }); g.region((u) => Math.max(-2.2, Math.min(2.2, f(u))), () => s.k, st, x, { fill: "c", fo: 0.16 }); st = null; } }
      }
      g.seg([TAU, -2.2], [TAU, 2.2], { color: "muted", w: 1, dash: "3 5" });
      g.fx(f, { color: "a", w: 3.2, from: 0, to: TAU });
      g.seg([-0.6, s.k], [7, s.k], { color: "b", w: 2.4 }).text([6.9, s.k], `y = ${fmt(s.k)}`, { dy: -8, anchor: "end", color: "b", bold: true });
      this.roots(s).forEach((x) => { g.seg([x, 0], [x, s.k], { color: "d", w: 1.4, dash: "3 4" }); g.point([x, s.k], "", { color: "d" }); g.text([x, 0], piFmt(x), { dy: s.k >= 0 ? 34 : -22, color: "d", bold: true, size: 13 }); });
    },
    metrics(s) {
      const r = this.roots(s);
      const out = [["방정식의 해", r.length ? r.map(piFmt).join(", ") : "없음", "key"], ["해의 개수", `${r.length}개`]];
      if (s.ineq !== "=") out.push(["부등식", `${s.fn} x ${s.ineq} ${fmt(s.k)} → 초록색 구간`]);
      return out;
    },
  },
  {
    id: "alg-sine-law", grade: G, unit: 4, lesson: "Ⅳ-1", title: "사인법칙과 외접원", type: "2D", time: "12분",
    tags: ["외접원", "원주각", "2R"], links: ["g3-inscribed-angle", "g2-circumcenter", "alg-survey"],
    desc: "외접원 위에서 세 꼭짓점을 움직이며 a/sin A = b/sin B = c/sin C = 2R이 항상 성립함을 지름을 이용해 확인합니다.",
    obs: ["B에서 지름 BA′를 그으면 ∠A′ = ∠A (같은 호의 원주각)이고 ∠BCA′ = 90°입니다.", "따라서 a = 2R sin A입니다.", "꼭짓점이 원 위에서 움직여도 한 변과 대각의 비는 유지됩니다."],
    q: "∠A가 둔각일 때도 a = 2R sin A가 성립할까요?",
    formula: "a/sin A = b/sin B = c/sin C = 2R",
    en: { title: "Law of Sines and the Circumcircle", desc: "Move the vertices on the circumcircle and confirm a/sin A = 2R using a diameter." },
    view: { x: [-5.4, 5.4], y: [-3.8, 3.8] },
    params: [{ key: "R", label: "외접원의 반지름 R", min: 2, max: 3.5, step: 0.1, value: 3 }, { key: "dia", label: "지름 BA′로 증명 보기", type: "check", value: true }],
    points: { A: [0, 0], B: [0, 0], C: [0, 0] },
    init: () => ({ aA: 100, aB: 215, aC: 330 }),
    derive(s) { ["A", "B", "C"].forEach((k) => (s[k] = [s.R * Math.cos(deg(s["a" + k])), s.R * Math.sin(deg(s["a" + k]))])); },
    constrain(s, k, p) { s["a" + k] = rad2deg(Math.atan2(p[1], p[0])); return [s.R * Math.cos(deg(s["a" + k])), s.R * Math.sin(deg(s["a" + k]))]; },
    tri(s) { const { A, B, C } = s, a = dist(B, C), b = dist(C, A), c = dist(A, B); const ang = (x, y, z) => Math.acos(clamp((y * y + z * z - x * x) / (2 * y * z), -1, 1)); return { a, b, c, A: ang(a, b, c), B: ang(b, c, a), C: ang(c, a, b) }; },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const { A, B, C } = s, t = this.tri(s);
      g.circle([0, 0], s.R, { color: "b", w: 2.2, fill: "b", fo: 0.04 });
      if (s.dia) { const A2 = mul(B, -1); g.seg(B, A2, { color: "e", w: 2, dash: "7 5" }); g.seg(A2, C, { color: "e", w: 2 }); g.right(C, B, A2, { size: 11, color: "e" }); g.arc(A2, B, C, { r: 22, color: "e", ccw: false }); g.point(A2, "A′", { color: "e" }); g.point([0, 0], "O", { color: "ink", r: 3.5 }); }
      g.poly([A, B, C], { fill: "a", fo: 0.1, color: "ink", w: 2.6 });
      g.seg(B, C, { color: "a", w: 4 });
      g.arc(A, B, C, { r: 26, color: "a", ccw: false, label: `${fmt(rad2deg(t.A), 1)}°` });
      g.text(lerp(B, C, 0.5), "a", { dx: 0, dy: -8, color: "a", italic: true });
      g.point(A, "A", { color: "ink" }).point(B, "B", { color: "ink" }).point(C, "C", { color: "ink" });
      g.handle(A, "A").handle(B, "B").handle(C, "C");
    },
    metrics(s) {
      const t = this.tri(s);
      return [["a / sin A", fmt(t.a / Math.sin(t.A), 3)], ["b / sin B", fmt(t.b / Math.sin(t.B), 3)], ["c / sin C", fmt(t.c / Math.sin(t.C), 3)], ["2R", fmt(2 * s.R, 3), "key"], ["세 각", `${fmt(rad2deg(t.A), 1)}° · ${fmt(rad2deg(t.B), 1)}° · ${fmt(rad2deg(t.C), 1)}°`]];
    },
  },
  {
    id: "alg-cosine-law", grade: G, unit: 4, lesson: "Ⅳ-2", title: "코사인법칙 — 피타고라스 정리의 확장", type: "2D", time: "12분",
    tags: ["코사인법칙", "피타고라스", "정사영"], links: ["g2-pythagoras", "geo-dot-product"],
    desc: "끼인각 A를 바꾸며 a²과 b² + c²의 차이가 2bc cos A만큼임을 수선의 발과 정사각형 넓이로 확인합니다.",
    obs: ["A = 90°이면 cos A = 0이 되어 피타고라스 정리와 같습니다.", "A가 예각이면 a² < b² + c², 둔각이면 a² > b² + c²입니다.", "b cos A는 변 AC를 AB 위에 정사영한 길이입니다."],
    q: "세 변의 길이만 알 때 가장 큰 각이 예각인지 둔각인지 어떻게 판단할까요?",
    formula: "a² = b² + c² − 2bc cos A · cos A = (b² + c² − a²) / 2bc",
    en: { title: "Law of Cosines", desc: "Vary angle A and see that a² differs from b² + c² by 2bc cos A." },
    view: { x: [-5.5, 7.5], y: [-4.4, 5] },
    params: [
      { key: "b", label: "b = CA", min: 1.5, max: 4.5, step: 0.1, value: 3.2 },
      { key: "c", label: "c = AB", min: 1.5, max: 5, step: 0.1, value: 4 },
      { key: "A", label: "끼인각 A", min: 20, max: 160, step: 1, value: 60, unit: "°" },
      { key: "sq", label: "세 변 위의 정사각형 보기", type: "check", value: true },
    ],
    anim: { key: "A", min: 20, max: 160, speed: 25, label: "각 A 바꾸기" },
    drags: { C: { at: (s) => [-2 + s.b * Math.cos(deg(s.A)), -1.2 + s.b * Math.sin(deg(s.A))], move: (s, p) => { const v = [p[0] + 2, p[1] + 1.2]; s.b = Math.hypot(v[0], v[1]); s.A = Math.round(rad2deg(Math.atan2(v[1], v[0]))); } } },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const A = [-2, -1.2], B = [A[0] + s.c, A[1]], C = add(A, [s.b * Math.cos(deg(s.A)), s.b * Math.sin(deg(s.A))]), H = [C[0], A[1]];
      const square = (p, q, color) => { const d = sub(q, p), n = [d[1], -d[0]]; g.poly([p, q, add(q, n), add(p, n)], { fill: color, fo: 0.12, color, w: 1.4 }); };
      if (s.sq) { square(B, C, "a"); square(C, A, "b"); square(A, B, "c"); }
      g.seg(A, [Math.min(A[0], H[0]) - 0.3, A[1]], { color: "muted", w: 1.2, dash: "3 5" }).seg(B, [Math.max(B[0], H[0]) + 0.3, A[1]], { color: "muted", w: 1.2, dash: "3 5" });
      g.seg(C, H, { color: "e", w: 2, dash: "6 4" });
      if (Math.abs(C[1] - A[1]) > 0.3) g.right(H, C, B, { size: 10, color: "e" });
      g.seg(A, H, { color: "f", w: 5, opacity: 0.7 });
      g.text(lerp(A, H, 0.5), `b cos A = ${fmt(s.b * Math.cos(deg(s.A)))}`, { dy: 22, color: "f", bold: true, size: 13 });
      g.poly([A, B, C], { fill: "paper", fo: 0.6, color: "ink", w: 2.6 });
      g.seg(B, C, { color: "a", w: 3.6 });
      g.arc(A, B, C, { r: 24, color: "e", label: `${s.A}°` });
      g.point(A, "A", { color: "ink", dx: -12, anchor: "end", dy: 18 }).point(B, "B", { color: "ink", dy: 18 }).point(C, "C", { color: "ink" });
    },
    metrics(s) {
      const c = Math.cos(deg(s.A)), a2 = s.b * s.b + s.c * s.c - 2 * s.b * s.c * c;
      return [["b² + c²", fmt(s.b * s.b + s.c * s.c)], ["2bc cos A", fmt(2 * s.b * s.c * c)], ["a²", fmt(a2), "key"], ["a", fmt(Math.sqrt(a2), 3)], ["비교", Math.abs(c) < 1e-9 ? "a² = b² + c² (직각)" : c > 0 ? "a² < b² + c² (A는 예각)" : "a² > b² + c² (A는 둔각)"]];
    },
  },
  {
    id: "alg-triangle-area", grade: G, unit: 4, lesson: "Ⅳ-3", title: "삼각함수로 구하는 넓이", type: "2D", time: "10분",
    tags: ["½ab sin C", "평행사변형", "헤론"], links: ["g3-trig-area"],
    desc: "두 변과 끼인각, 평행사변형, 대각선이 주어진 사각형, 세 변(헤론의 공식)으로 넓이를 구하는 방법을 한 화면에서 바꿔 봅니다.",
    obs: ["높이는 b sin C로 바꿀 수 있습니다.", "평행사변형은 합동인 삼각형 두 개이므로 ab sin θ입니다.", "사각형의 넓이는 두 대각선과 그 끼인각으로 ½pq sin θ입니다."],
    q: "끼인각이 몇 도일 때 두 변의 길이가 고정된 삼각형의 넓이가 가장 클까요?",
    formula: "S = ½ab sin C · S = ab sin θ · S = ½pq sin θ · S = √(s(s−a)(s−b)(s−c))",
    en: { title: "Areas with Trigonometry", desc: "Compute areas from two sides and an angle, for parallelograms, quadrilaterals with diagonals, and by Heron's formula." },
    view: { x: [-5.5, 6.5], y: [-3.6, 4.6] },
    params: [
      { key: "mode", label: "도형", type: "seg", value: "tri", options: [["tri", "삼각형"], ["par", "평행사변형"], ["quad", "사각형(대각선)"], ["heron", "헤론"]] },
      { key: "a", label: "a", min: 2, max: 6, step: 0.1, value: 5, when: (s) => s.mode !== "heron" },
      { key: "b", label: "b", min: 1.5, max: 5, step: 0.1, value: 3.5, when: (s) => s.mode !== "heron" },
      { key: "t", label: "끼인각 θ", min: 10, max: 170, step: 1, value: 50, unit: "°", when: (s) => s.mode !== "heron" },
      { key: "ha", label: "a", min: 2, max: 7, step: 0.5, value: 6, when: (s) => s.mode === "heron" },
      { key: "hb", label: "b", min: 2, max: 7, step: 0.5, value: 5, when: (s) => s.mode === "heron" },
      { key: "hc", label: "c", min: 2, max: 7, step: 0.5, value: 4, when: (s) => s.mode === "heron" },
    ],
    anim: { key: "t", min: 10, max: 170, speed: 30, label: "끼인각 바꾸기" },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const th = deg(s.t), O = [-3.4, -2.2];
      if (s.mode === "tri" || s.mode === "par") {
        const B = add(O, [s.a, 0]), C = add(O, [s.b * Math.cos(th), s.b * Math.sin(th)]), H = [C[0], O[1]];
        if (s.mode === "par") g.poly([O, B, add(B, sub(C, O)), C], { fill: "b", fo: 0.12, color: "b", w: 2.6 });
        g.poly([O, B, C], { fill: "a", fo: 0.18, color: "ink", w: 2.6 });
        g.seg(C, H, { color: "e", w: 2, dash: "6 4" }).seg(O, [Math.min(O[0], H[0]), O[1]], { color: "muted", w: 1.2, dash: "3 4" });
        g.right(H, C, B, { size: 10, color: "e" });
        g.text(lerp(C, H, 0.5), `b sin θ = ${fmt(s.b * Math.sin(th))}`, { dx: 10, anchor: "start", color: "e", bold: true, size: 13 });
        g.arc(O, B, C, { r: 26, color: "a", label: `${s.t}°` });
        g.text(lerp(O, B, 0.5), `a = ${fmt(s.a)}`, { dy: 22, color: "ink", bold: true }).text(lerp(O, C, 0.5), `b = ${fmt(s.b)}`, { dx: -14, anchor: "end", color: "ink", bold: true });
      } else if (s.mode === "quad") {
        const X = [0.5, 0.4], u = [1, 0], v = [Math.cos(th), Math.sin(th)];
        const P1 = add(X, mul(u, -s.a * 0.45)), P3 = add(X, mul(u, s.a * 0.55)), P2 = add(X, mul(v, -s.b * 0.4)), P4 = add(X, mul(v, s.b * 0.6));
        g.poly([P1, P2, P3, P4], { fill: "c", fo: 0.14, color: "ink", w: 2.6 });
        g.seg(P1, P3, { color: "a", w: 3 }).seg(P2, P4, { color: "b", w: 3 });
        g.arc(X, P3, P4, { r: 24, color: "e", label: `${s.t}°` });
        g.text(P3, `p = ${fmt(s.a)}`, { dx: 12, anchor: "start", color: "a", bold: true }).text(P4, `q = ${fmt(s.b)}`, { dy: -12, color: "b", bold: true });
      } else {
        const { ha: a, hb: b, hc: c } = s;
        if (a + b <= c || b + c <= a || a + c <= b) { g.note(20, 30, "세 변으로 삼각형을 만들 수 없습니다 (두 변의 합 > 나머지 한 변).", { color: "d", bold: true }); return; }
        const x = (b * b + c * c - a * a) / (2 * c), y = Math.sqrt(b * b - x * x), sc = Math.min(1, 8 / c, 6.5 / y);
        const A = [-3.6, -2.4], B = add(A, [c * sc, 0]), C = add(A, [x * sc, y * sc]);
        g.poly([A, B, C], { fill: "d", fo: 0.14, color: "ink", w: 2.6 });
        g.text(lerp(A, B, 0.5), `c = ${fmt(c)}`, { dy: 22, bold: true }).text(lerp(B, C, 0.5), `a = ${fmt(a)}`, { dx: 12, anchor: "start", bold: true }).text(lerp(A, C, 0.5), `b = ${fmt(b)}`, { dx: -12, anchor: "end", bold: true });
      }
    },
    metrics(s) {
      const si = Math.sin(deg(s.t));
      if (s.mode === "tri") return [["sin θ", fmt(si, 4)], ["S = ½ab sin θ", fmt(0.5 * s.a * s.b * si, 3), "key"], s.t === 90 ? "θ = 90°에서 넓이가 가장 큽니다." : ""].filter(Boolean);
      if (s.mode === "par") return [["삼각형 두 개", `2 × ${fmt(0.5 * s.a * s.b * si, 3)}`], ["S = ab sin θ", fmt(s.a * s.b * si, 3), "key"]];
      if (s.mode === "quad") return [["S = ½pq sin θ", fmt(0.5 * s.a * s.b * si, 3), "key"], "대각선의 교점 위치를 바꾸어도 넓이는 같습니다."];
      const { ha: a, hb: b, hc: c } = s, p = (a + b + c) / 2, v = p * (p - a) * (p - b) * (p - c);
      return v <= 0 ? ["삼각형이 되지 않습니다."] : [["s = (a + b + c)/2", fmt(p)], ["s(s−a)(s−b)(s−c)", fmt(v)], ["S", `${surd(v)} ≈ ${fmt(Math.sqrt(v), 3)}`, "key"]];
    },
  },
  {
    id: "alg-survey", grade: G, unit: 4, lesson: "Ⅳ", title: "삼각측량 — 강 너비와 산 높이", type: "조작", time: "12분",
    tags: ["측량", "사인법칙", "실생활"], links: ["g3-trig-height", "alg-sine-law"],
    desc: "직접 갈 수 없는 강 건너편까지의 거리와 산의 높이를 기선의 길이와 두 각만으로 계산합니다.",
    obs: ["기선의 길이와 양 끝에서 잰 두 각을 알면 삼각형이 하나로 정해집니다(ASA).", "사인법칙으로 모르는 변을 구합니다.", "산 높이는 두 지점에서 올려본 각의 차이를 이용합니다."],
    q: "두 각의 합이 180°에 가까워지면 측량 결과는 어떻게 될까요?",
    formula: "AC = d·sin β / sin(α + β) · h = d·tan α·tan β / (tan β − tan α)",
    en: { title: "Triangulation", desc: "Find the width of a river and the height of a mountain from a baseline and two angles." },
    view: { x: [-6.5, 6.5], y: [-4, 4.8] },
    params: [
      { key: "mode", label: "상황", type: "seg", value: "river", options: [["river", "강 건너 거리"], ["hill", "산의 높이"]] },
      { key: "d", label: "기선 길이 d (m)", min: 40, max: 200, step: 5, value: 100 },
      { key: "al", label: "각 α", min: 15, max: 80, step: 1, value: 55, unit: "°" },
      { key: "be", label: "각 β", min: 15, max: 85, step: 1, value: 70, unit: "°" },
    ],
    derive(s) { if (s.mode === "hill" && s.be <= s.al + 1) s.be = Math.min(85, s.al + 5); },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const al = deg(s.al), be = deg(s.be), k = 6 / s.d;
      if (s.mode === "river") {
        const A = [-3, -2.6], B = [A[0] + s.d * k, A[1]];
        const AC = (s.d * Math.sin(be)) / Math.sin(al + be), C = add(A, [AC * k * Math.cos(al), AC * k * Math.sin(al)]);
        g.poly([[-6.5, -1.4], [6.5, -1.4], [6.5, Math.max(-0.6, C[1] - 0.8)], [-6.5, Math.max(-0.6, C[1] - 0.8)]], { fill: "b", fo: 0.16, stroke: false });
        g.text([5.5, -1.1], "강", { color: "b", bold: true });
        g.poly([A, B, C], { fill: "a", fo: 0.08, color: "ink", w: 2.4 });
        g.seg(A, B, { color: "f", w: 4 }).text(lerp(A, B, 0.5), `d = ${s.d} m`, { dy: 24, color: "f", bold: true });
        g.arc(A, B, C, { r: 28, color: "a", label: `α ${s.al}°` });
        g.arc(B, C, A, { r: 28, color: "c", label: `β ${s.be}°` });
        g.seg(A, C, { color: "a", w: 3.2 });
        g.point(A, "A", { dy: 20 }).point(B, "B", { dy: 20 }).point(C, "C (나무)", { color: "c" });
      } else {
        const A = [-5.6, -2.8], B = [A[0] + s.d * k * 0.55, A[1]];
        const h = (s.d * Math.tan(al) * Math.tan(be)) / (Math.tan(be) - Math.tan(al)), x = h / Math.tan(be);
        const sc = Math.min(0.55 * k, 6.6 / h, 9.5 / (s.d + x));
        const B2 = [A[0] + s.d * sc, A[1]], T = [B2[0] + x * sc, A[1] + h * sc], F2 = [T[0], A[1]];
        g.poly([[A[0] - 1, A[1]], [T[0] - (T[1] - A[1]) * 0.6, A[1]], T, [T[0] + (T[1] - A[1]) * 0.7, A[1]]], { fill: "c", fo: 0.14, color: "c", w: 1.6 });
        g.seg([A[0] - 1, A[1]], [6.5, A[1]], { color: "ink", w: 1.6 });
        g.seg(A, T, { color: "a", w: 2 }).seg(B2, T, { color: "e", w: 2 }).seg(T, F2, { color: "d", w: 3.2, dash: "7 4" });
        g.right(F2, T, A, { size: 11 });
        g.seg(A, B2, { color: "f", w: 4 }).text(lerp(A, B2, 0.5), `d = ${s.d} m`, { dy: 24, color: "f", bold: true });
        g.arc(A, F2, T, { r: 34, color: "a", label: `α ${s.al}°` });
        g.arc(B2, F2, T, { r: 26, color: "e", label: `β ${s.be}°` });
        g.text(lerp(T, F2, 0.5), `h ≈ ${fmt(h, 1)} m`, { dx: 12, anchor: "start", color: "d", bold: true });
        g.point(A, "A", { dy: 20 }).point(B2, "B", { dy: 20 }).point(T, "정상", { color: "d" });
      }
    },
    metrics(s) {
      const al = deg(s.al), be = deg(s.be);
      if (s.mode === "river") {
        const C = Math.PI - al - be, AC = (s.d * Math.sin(be)) / Math.sin(C);
        return [["∠C", `${fmt(180 - s.al - s.be)}°`], ["AC = d·sin β / sin C", `${fmt(AC, 1)} m`, "key"], ["강을 가로지른 거리 (AC sin α)", `${fmt(AC * Math.sin(al), 1)} m`]];
      }
      const h = (s.d * Math.tan(al) * Math.tan(be)) / (Math.tan(be) - Math.tan(al));
      return [["tan α", fmt(Math.tan(al), 3)], ["tan β", fmt(Math.tan(be), 3)], ["산의 높이 h", `${fmt(h, 1)} m`, "key"], "β는 α보다 커야 합니다(더 가까운 곳에서 잰 각)."];
    },
  },
];
