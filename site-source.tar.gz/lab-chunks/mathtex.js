// 수식 조판 — 사이트의 유니코드 수식을 LaTeX로 바꾸어 MathJax(SVG)로 그린다.
// MathJax가 아직 준비되지 않았으면 원래 글자를 보여 주고, 준비되면 다시 그린다.

const SUP = { "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4", "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9", "ⁿ": "n", "⁻": "-", "⁺": "+", "ᵏ": "k", "ʳ": "r", "ˣ": "x", "ᶜ": "c", "ᵀ": "T", "ᵃ": "a", "ᵇ": "b", "ᵐ": "m", "ⁱ": "i", "⁽": "(", "⁾": ")", "ʰ": "h", "ᵗ": "t" };
const TO_SUP = Object.fromEntries(Object.entries(SUP).map(([a, b]) => [b, a]));
const SUB = { "₀": "0", "₁": "1", "₂": "2", "₃": "3", "₄": "4", "₅": "5", "₆": "6", "₇": "7", "₈": "8", "₉": "9", "ₙ": "n", "ₖ": "k", "ᵣ": "r", "ₐ": "a", "ₑ": "e", "ₘ": "m", "ᵢ": "i", "ₓ": "x", "₊": "+", "₋": "-" };
const SYM = { "−": "-", "×": "\\times", "÷": "\\div", "⇒": "\\Rightarrow", "⇔": "\\Leftrightarrow", "→": "\\to", "←": "\\leftarrow", "↔": "\\leftrightarrow", "≤": "\\le", "≥": "\\ge", "≠": "\\ne", "≈": "\\approx", "±": "\\pm", "∞": "\\infty", "π": "\\pi", "θ": "\\theta", "α": "\\alpha", "β": "\\beta", "γ": "\\gamma", "δ": "\\delta", "φ": "\\varphi", "σ": "\\sigma", "η": "\\eta", "λ": "\\lambda", "μ": "\\mu", "ε": "\\varepsilon", "Δ": "\\Delta", "Σ": "\\sum", "∑": "\\sum", "∠": "\\angle", "⟂": "\\perp", "⊥": "\\perp", "∥": "\\parallel", "∦": "\\nparallel", "△": "\\triangle", "∽": "\\backsim", "∈": "\\in", "∪": "\\cup", "∩": "\\cap", "⊃": "\\supset", "∅": "\\varnothing", "…": "\\dots", "°": "^{\\circ}", "½": "\\tfrac12", "⅓": "\\tfrac13", "⅔": "\\tfrac23", "¼": "\\tfrac14", "∫": "\\int", "∝": "\\propto", "⋯": "\\cdots", "ℓ": "\\ell" };
const GREEK = new Set(["\\pi", "\\theta", "\\alpha", "\\beta", "\\gamma", "\\delta", "\\varphi", "\\sigma", "\\eta", "\\lambda", "\\mu", "\\varepsilon", "\\Delta", "\\infty", "\\ell"]);
const FUNC = new Set(["\\sin", "\\cos", "\\tan", "\\log", "\\ln", "\\max", "\\min", "\\sqrt", "\\tfrac12", "\\tfrac13", "\\tfrac23", "\\tfrac14"]);
const MULT = new Set(["\\cdot", "\\times"]);
const MATHY = /[=+<>^ᵗ≤≥≠≈±×÷√∫Σ∑²³ⁿ⁰¹⁴⁵⁶⁷⁸⁹₀₁₂₃₄₅₆₇₈₉ₙₖᵣπθαβφσλΔ⇒⇔∠⟂∥½⅓⅔¼′/]|\blim\b|(?:^|[^A-Za-z0-9.])\d+[CPH]\d|[A-Za-z]\s*[−-]\s*[A-Za-z0-9]/;
const HANGUL = /[가-힣]/;

// 1단계: 문자 변환 → 토큰 목록
function tokenize(src) {
  let s = String(src)
    .replace(/([^\s(=,:])(\s*)[−-](\s*)[−-](?=[\d.a-zA-Zπ(√])/g, "$1$2+$3") // y − −1 → y + 1
    .replace(/([^\s(=,:])(\s*)\+(\s*)[−-](?=[\d.a-zA-Zπ(√])/g, "$1$2−$3") // x + −2 → x − 2
    .replace(/(^|[^A-Za-z0-9.])(\d+)([CPH])(\d+)(?![\d.])/g, (m, a, n, c, r) => a + [...n].map((d) => "₀₁₂₃₄₅₆₇₈₉"[d]).join("") + c + [...r].map((d) => "₀₁₂₃₄₅₆₇₈₉"[d]).join("")) // 5C2 → ₅C₂
    .replace(/([·×])\s*([−-])(\d+(?:\.\d+)?|[a-zA-Zπ])/g, "$1($2$3)") // 1·−5 → 1·(−5)
    .replace(/\^(\d+|[a-zA-Z])/g, (m, e) => [...e].every((c) => TO_SUP[c]) ? [...e].map((c) => TO_SUP[c]).join("") : m) // 2^4 → 2⁴
    .replace(/[\\{}#&%$_^~]/g, (c) => ({ "\\": "\\backslash ", "{": "\\{", "}": "\\}", "#": "\\#", "&": "\\&", "%": "\\%", $: "\\$", _: "\\_", "^": "\\hat{}", "~": "\\sim " })[c])
    .replace(/([\dπ])\s+(m\/s|km\/h|cm|km|mm|kg|rad|dB|m)(²|³)?(?![A-Za-z])/g, (m, a, u, p) => `${a}${u}${p ? (p === "²" ? "^2" : "^3") : ""}`)
    .replace(/′/g, "'").replace(/″/g, "''");
  const T = [];
  const push = (t) => T.push(t);
  let i = 0;
  const cps = [...s];
  while (i < cps.length) {
    const c = cps[i];
    if (c === "") { let j = i + 1, u = ""; while (j < cps.length && cps[j] !== "") u += cps[j++]; const m2 = u.match(/^(.*?)(\^\d)?$/); push({ t: "raw", v: `\\,\\text{${m2[1]}}${m2[2] ? `^{${m2[2][1]}}` : ""}` }); i = j + 1; continue; }
    if (/[A-Za-z]/.test(c) && cps[i + 1] === "̄") { push({ t: "let", v: `\\bar{${c}}` }); i += 2; continue; }
    if (c === "\\") { let j = i + 1, name = "\\"; while (j < cps.length && /[A-Za-z]/.test(cps[j])) name += cps[j++]; if (name === "\\") name += cps[j++]; push({ t: "cmd", v: name }); i = j; continue; }
    if (SUP[c]) { let v = ""; while (i < cps.length && SUP[cps[i]]) v += SUP[cps[i++]]; push({ t: "sup", v }); continue; }
    if (SUB[c]) { let v = ""; while (i < cps.length && SUB[cps[i]]) v += SUB[cps[i++]]; push({ t: "sub", v }); continue; }
    if (c === "√") { push({ t: "sqrt" }); i++; continue; }
    if (SYM[c]) { const v = SYM[c]; if (v.startsWith("^")) push({ t: "sup", v: "\\circ", raw: true }); else if (v === "-") push({ t: "op", v: "-" }); else push({ t: "cmd", v }); i++; continue; }
    if (/[가-힣]/.test(c)) { let v = ""; while (i < cps.length && /[가-힣\s,.!?]/.test(cps[i]) && !(/\s/.test(cps[i]) && !/[가-힣]/.test(cps[i + 1] || ""))) v += cps[i++]; push({ t: "text", v: v.trimEnd() }); continue; }
    if (c === "·") { push({ t: "dot" }); i++; continue; }
    if (/\s/.test(c)) { if (T.length && T[T.length - 1].t !== "sp") push({ t: "sp" }); i++; continue; }
    if (/[0-9.]/.test(c)) { let v = ""; while (i < cps.length && /[0-9.,]/.test(cps[i]) && !(cps[i] === "," && !/[0-9]/.test(cps[i + 1] || "") ) && !(cps[i] === "," && cps[i + 1] === " ")) v += cps[i++]; if (v.endsWith(",")) { v = v.slice(0, -1); i--; } push({ t: "num", v: v.replace(/,/g, "{,}") }); continue; }
    if (/[A-Za-z]/.test(c)) { push({ t: "let", v: c }); i++; continue; }
    if ("()[]|".includes(c)) { push({ t: c }); i++; continue; }
    if (c === "!" || c === "'") { push({ t: "post", v: c }); i++; continue; }
    if (c === "/") { push({ t: "/" }); i++; continue; }
    if (c === "∕") { push({ t: "raw", v: "/" }); i++; continue; }
    if (c === " ") { push({ t: "raw", v: "\\," }); i++; continue; }
    push({ t: "op", v: c }); i++;
  }
  // 함수 이름(sin, cos, lim …)
  for (let k = 0; k < T.length; k++) {
    for (const fn of ["sin", "cos", "tan", "log", "ln", "lim", "max", "min"]) {
      const L = fn.length;
      if (k + L <= T.length && T.slice(k, k + L).every((x, j) => x.t === "let" && x.v === fn[j]) && !(T[k - 1] && T[k - 1].t === "let") && !(T[k + L] && T[k + L].t === "let")) { T.splice(k, L, { t: "cmd", v: "\\" + fn }); break; }
    }
  }
  return T;
}

// 2단계: 토큰 → LaTeX (분수 처리 포함)
function atomEnd(T, i) { // i에서 시작하는 원자 하나의 끝(포함) 인덱스
  const t = T[i]; if (!t) return i - 1;
  if (t.t === "(" || t.t === "[") { const close = t.t === "(" ? ")" : "]"; let d = 0; for (let j = i; j < T.length; j++) { if (T[j].t === t.t) d++; else if (T[j].t === close) { d--; if (!d) return j; } } return T.length - 1; }
  if (t.t === "|") { for (let j = i + 1; j < T.length; j++) if (T[j].t === "|") return j; return i; }
  if (t.t === "sqrt") { const n = T[i + 1]; return n ? atomEnd(T, i + 1) : i; }
  return i;
}
function isAtom(t) { return t && (t.t === "num" || t.t === "let" || t.t === "(" || t.t === "[" || t.t === "|" || t.t === "sqrt" || (t.t === "cmd" && (GREEK.has(t.v) || FUNC.has(t.v))) || (t.t === "cmd" && /^\\tfrac/.test(t.v))); }
function termRight(T, i) { // 오른쪽 피연산자 [i, end]
  let j = i; if (T[j]?.t === "sp") j++;
  const start = j; let end = j - 1;
  while (j < T.length) {
    const t = T[j];
    if (t.t === "cmd" && FUNC.has(t.v)) { j++; if (T[j]?.t === "sp") j++; continue; }
    if (!isAtom(t) && !(t.t === "cmd" && t.v === "\\{")) break;
    end = atomEnd(T, j); j = end + 1;
    while (T[j] && (T[j].t === "sup" || T[j].t === "sub" || T[j].t === "post")) { end = j; j++; }
    if (T[j] && (T[j].t === "let" || T[j].t === "num" || T[j].t === "sqrt" || (T[j].t === "cmd" && GREEK.has(T[j].v)))) continue;
    if (T[j] && T[j].t === "(" && T[j - 1] && (T[j - 1].t === "let" || T[j - 1].t === "post")) continue;
    break;
  }
  return [start, end];
}
function termLeft(T, i) { // 왼쪽 피연산자 [start, i]
  let j = i; if (T[j]?.t === "sp") j--;
  const end = j; let start = j + 1;
  while (j >= 0) {
    const t = T[j];
    if (t.t === "sup" || t.t === "sub" || t.t === "post") { j--; continue; }
    let s0 = j;
    if (t.t === ")" || t.t === "]") { const open = t.t === ")" ? "(" : "["; let d = 0; for (let k = j; k >= 0; k--) { if (T[k].t === t.t) d++; else if (T[k].t === open) { d--; if (!d) { s0 = k; break; } } } }
    else if (t.t === "|") { for (let k = j - 1; k >= 0; k--) if (T[k].t === "|") { s0 = k; break; } }
    else if (t.t === "(" || t.t === "[" || !isAtom(t)) break;
    start = s0; j = s0 - 1;
    if (T[j] && T[j].t === "sqrt") { start = j; j--; }
    if (T[j] && (T[j].t === "sp") && T[j - 1] && T[j - 1].t === "cmd" && FUNC.has(T[j - 1].v)) { j--; }
    if (T[j] && T[j].t === "cmd" && FUNC.has(T[j].v)) { start = j; j--; }
    if (T[j] && T[j].t === "dot") { start = j; j--; continue; }
    if (T[j] && T[j].t === "cmd" && MULT.has(T[j].v)) { start = j; j--; continue; }
    if (T[j] && (isAtom(T[j]) || T[j].t === ")" || T[j].t === "post" || T[j].t === "sup" || T[j].t === "sub")) continue;
    break;
  }
  if (T[start - 1] && T[start - 1].t === "sub" && (start - 2 < 0 || ["sp", "op", "("].includes(T[start - 2].t))) start--;
  return [start, end];
}
function emit(T, a = 0, b = T.length - 1, depth = 0) {
  let out = "";
  for (let i = a; i <= b; i++) {
    const t = T[i];
    // 분수 앞을 미리 봄: 이 위치에서 시작하는 왼쪽 항 뒤에 '/'가 오는가
    if (t.t === "/") { out += "/"; continue; }
    if (t.t === "sqrt") { const e = atomEnd(T, i + 1); let inner = e >= i + 1 ? T.slice(i + 1, e + 1) : []; if (inner[0]?.t === "(" && inner[inner.length - 1]?.t === ")") inner = inner.slice(1, -1); out += `\\sqrt{${emit(inner, 0, inner.length - 1, depth + 1)}}`; i = e; continue; }
    if (t.t === "(" || t.t === "[" ) { const e = Math.min(atomEnd(T, i), b), cl = T[e]?.t === (t.t === "(" ? ")" : "]"); out += (t.t === "(" ? "(" : "[") + emit(T, i + 1, cl ? e - 1 : e, depth + 1) + (cl ? (t.t === "(" ? ")" : "]") : ""); i = e; continue; }
    if (t.t === "|") { const e = atomEnd(T, i); if (e > i) { out += "\\left|" + emit(T, i + 1, e - 1, depth + 1) + "\\right|"; i = e; } else out += "|"; continue; }
    if (t.t === "sup") out += t.raw ? `^{${t.v}}` : `^{${t.v}}`;
    else if (t.t === "sub") out += (i === a || T[i - 1].t === "sp" || T[i - 1].t === "op" || T[i - 1].t === "(") ? `{}_{${t.v}}` : `_{${t.v}}`;
    else if (t.t === "dot") out += depth === 0 && T[i - 1]?.t === "sp" && T[i + 1]?.t === "sp" ? "\\qquad " : "\\cdot ";
    else if (t.t === "text") out += (i > a && T[i - 1].t === "sp" ? "\\ " : "") + `\\text{${t.v}}` + (i < b && T[i + 1].t === "sp" ? "\\ " : "");
    else if (t.t === "sp") out += " ";
    else if (t.t === "cmd") out += t.v === "\\lim" ? "\\lim" : t.v + " ";
    else if (t.t === "post") out += t.v;
    else out += t.v ?? t.t;
  }
  return out;
}
function fractions(T) {
  for (let guard = 0; guard < 40; guard++) {
    const k = T.findIndex((t) => t.t === "/"); if (k < 0) break;
    const [ls, le] = termLeft(T, k - 1), [rs, re] = termRight(T, k + 1);
    if (le < ls || re < rs) { T[k] = { t: "raw", v: "/" }; continue; }
    const strip = (A) => (A.length > 1 && A[0].t === "(" && atomEnd(A, 0) === A.length - 1 ? A.slice(1, -1) : A);
    const L = strip(T.slice(ls, le + 1)), R = strip(T.slice(rs, re + 1));
    // "60°/60°", "AB/CD", "A/C"처럼 두 값을 나란히 적은 것은 분수가 아니다
    const lt = emit(L, 0, L.length - 1, 1).replace(/\s/g, ""), rt = emit(R, 0, R.length - 1, 1).replace(/\s/g, "");
    if ((/\\circ/.test(lt) && /\\circ/.test(rt)) || (/^[A-Z]+$/.test(lt) && /^[A-Z]+$/.test(rt))) { T[k] = { t: "raw", v: "/" }; continue; }
    fractions(L); fractions(R);
    T.splice(ls, re - ls + 1, { t: "raw", v: `\\frac{${emit(L, 0, L.length - 1, 1)}}{${emit(R, 0, R.length - 1, 1)}}` });
  }
  return T;
}
// lim(h→0) 처리: lim 바로 뒤 괄호를 아래첨자로
function limits(T) { for (let k = 0; k < T.length; k++) if (T[k].t === "cmd" && T[k].v === "\\lim" && T[k + 1]?.t === "(") { const e = atomEnd(T, k + 1); const inner = T.slice(k + 2, e); T.splice(k, e - k + 1, { t: "raw", v: `\\lim_{${emit(inner, 0, inner.length - 1, 1)}}` }); } return T; }
function integrals(T) { for (let k = 0; k < T.length; k++) if (T[k].t === "cmd" && T[k].v === "\\int" && T[k + 1]?.t === "sub") { const sub = T[k + 1].v, sup = T[k + 2]?.t === "sup" ? T[k + 2].v : null; T.splice(k, sup ? 3 : 2, { t: "raw", v: `\\int_{${sub}}${sup ? `^{${sup}}` : ""}` }); } return T; }

// ' · '는 식과 식을 나누는 구분자이지만, 한쪽이 짧은 항(a · b)이면 곱셈으로 본다
export function splitSep(src) {
  const parts = String(src).split(/\s+·\s+/), out = [];
  const short = (x) => x.replace(/\s/g, "").length <= 3;
  for (const p of parts) { if (out.length && (short(p.split(/[=⇒⇔<>≤≥]/)[0]) && !/[=⇒⇔]/.test(p) ? true : short(out[out.length - 1]))) out[out.length - 1] += "·" + p; else out.push(p); }
  return out;
}
export const isNativeTex = src => /\\[A-Za-z]+/.test(String(src));
export function toTex(src) {
  if (isNativeTex(src)) return String(src);
  src = splitSep(src).join(" · ");
  const T = integrals(limits(tokenize(src)));
  fractions(T);
  return emit(T).replace(/\s+/g, " ").trim();
}

// ── 렌더링 ──
const cache = new Map();
let ready = false;
const waiters = new Set();
export function onMathReady(fn) { if (ready) fn(); else waiters.add(fn); }
if (typeof window !== "undefined") {
  const check = () => { if (window.MathJax && window.MathJax.tex2svg) { (window.MathJax.startup?.promise || Promise.resolve()).then(() => { ready = true; waiters.forEach((f) => { try { f(); } catch (e) { console.error(e); } }); waiters.clear(); }); return true; } return false; };
  if (!check()) { const iv = setInterval(() => { if (check()) clearInterval(iv); }, 150); setTimeout(() => clearInterval(iv), 30000); }
}
const esc = (x) => String(x).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
export function texSVG(tex, display = false) {
  const key = (display ? "D" : "I") + tex;
  if (cache.has(key)) return cache.get(key);
  let out = null;
  try { const node = window.MathJax.tex2svg(tex, { display }); if (!node.querySelector("[data-mjx-error], mjx-merror")) out = node.outerHTML; } catch (e) { out = null; }
  if (cache.size > 5000) cache.clear();
  cache.set(key, out);
  return out;
}
// 화면 낭독기는 그림 대신 원래 글자(예: x² + 1)를 읽는다
const mxWrap = (svg, text) => `<span class="mx" role="img" aria-label="${esc(text)}">${svg.replace("<svg", '<svg aria-hidden="true"')}</span>`;
// 문장 속 수식 구간만 골라 조판 (한글 문장은 그대로)
const SPLIT = /([가-힣][가-힣\s,.!?'"“”‘’~]*[가-힣.!?]|[가-힣])/;
// 영어 문장: 두 글자 이상 영어 낱말은 글자로, 그 사이만 수식으로 그린다 (sin, ln, lim 같은 수학 이름은 수식)
const MW = "sin|cos|tan|ln|log|lim|max|min|exp|sec|csc|cot|arcsin|arccos|arctan|mod|gcd|lcm|det|crd|sgn|dx|dy|dt|du";
const SMALL = "is|of|to|in|on|at|by|an|as|if|or|be|it|we|no|so|up|do|go|me|my|us|am|he|vs";
const EWS = `(?<![A-Za-z])(?!(?:${MW})(?![A-Za-z]))(?:[A-Za-z][a-z]{2,}(?:['’][a-z]+)?|(?:${SMALL}))(?![A-Za-z])`;
const ENW = new RegExp(EWS);
const SPLITX = new RegExp(`((?:[가-힣]|${EWS})(?:[\\s,.!?'"“”‘’~:;\\-–—]*(?:[가-힣]|${EWS}))*[.!?]?)`);
const TEXTY = (x) => HANGUL.test(x) || ENW.test(x);
export function mathHTML(str) {
  const raw = String(str ?? "");
  if (!ready) return esc(raw);
  if (isNativeTex(raw)) { const svg = texSVG(raw); return svg ? mxWrap(svg, raw) : esc(raw); }
  if (!MATHY.test(raw)) return esc(raw);
  if (TEXTY(raw)) {
    return raw.split(ENW.test(raw) ? SPLITX : SPLIT).map((seg) => {
      if (!seg) return "";
      if (TEXTY(seg)) return esc(seg);
      const lead = seg.match(/^[\s,.:;!?(]*/)[0], tail = seg.match(/[\s,.:;!?)]*$/)[0];
      let core = seg.slice(lead.length, Math.max(lead.length, seg.length - tail.length));
      if (!core || !MATHY.test(core) || core.replace(/\s/g, "").length < 2) return esc(seg);
      // 짝이 맞지 않는 괄호는 수식 밖으로
      let l2 = lead, t2 = tail;
      const bal = (x) => [...x].reduce((a, c) => a + (c === "(" ? 1 : c === ")" ? -1 : 0), 0);
      if (bal(core) !== 0) { if (lead.endsWith("(") && bal(core) < 0) { core = "(" + core; l2 = lead.slice(0, -1); } else if (tail.startsWith(")") && bal(core) > 0) { core = core + ")"; t2 = tail.slice(1); } }
      const svg = texSVG(toTex(core));
      return esc(l2) + (svg ? mxWrap(svg, core) : esc(core)) + esc(t2);
    }).join("");
  }
  const svg = texSVG(toTex(raw));
  return svg ? mxWrap(svg, raw) : esc(raw);
}
export function mathBlock(str) { const raw = String(str ?? ""); if (!ready) return esc(raw); if (isNativeTex(raw)) { const svg = texSVG(raw, false); return svg ? `<span class="mx mx-d">${svg}</span>` : esc(raw); } const parts = splitSep(raw); return parts.map((p) => { if (TEXTY(p)) return `<span class="mx-part">${mathHTML(p)}</span>`; const svg = texSVG(toTex(p), false); return svg ? `<span class="mx mx-d">${svg}</span>` : `<span>${esc(p)}</span>`; }).join(""); }
export function setMath(el, str) { const k = String(str); if (el.dataset.src === k && el.dataset.ready === String(ready)) return; el.dataset.src = k; el.dataset.ready = String(ready); el.innerHTML = mathHTML(k); }
export const isMathReady = () => ready;
