// 고등·특별관 실험 — 필요할 때만 불러오기
// 목록·검색에는 요약(hs-meta.js)만 쓰고, 실험을 열거나 카드 그림이 화면에 보일 때 그 실험의 설명서 파일을 받는다.
// (hs.js는 모든 설명서를 한꺼번에 불러오는 옛 방식으로, 요약을 만드는 도구와 시험에서만 쓴다)
import { mount as mountSpec, thumbSVG } from "./hs-core.js";
import { META, FILE_OF, LOAD } from "./hs-meta.js";
import { bankFor } from "./predict-ui.js";
export { bankFor, mountPredict } from "./predict-ui.js";

export const LABS = META;
const full = new Map(), pending = new Map();
function loadFile(f) {
  if (!pending.has(f)) pending.set(f, LOAD[f]().then((m) => {
    for (const sp of m.default) if (FILE_OF[sp.id] === f) { if (!sp.predict) { const b = bankFor(sp.id); if (b) sp.predict = b; } full.set(sp.id, sp); }
  }).catch((e) => { pending.delete(f); throw e; }));
  return pending.get(f);
}
// 설명서를 받아 둔다 (여러 실험을 한꺼번에)
export const ensure = (ids) => Promise.all([...new Set(ids.map((id) => FILE_OF[id]).filter(Boolean))].map(loadFile));
export const has = (id) => full.has(id);
export const specOf = (id) => full.get(id) || null;
export const isHS = (id) => id in FILE_OF;
// 오프라인 저장용: 모든 설명서 파일 이름
export const allFiles = () => Object.keys(LOAD);

// 영어판 — en-labs.js가 불러와지면 setEN으로 넘겨받아 실험을 바꿔 끼운다
let EN = null, TR = null;
export function setEN(map, tr) { EN = map; TR = tr || null; }
export function loc(spec) { const e = EN && spec && EN[spec.id]; return e ? localize(spec, e) : spec; }
function localize(sp, e) {
  const o = { ...sp };
  if (e.t) o.title = e.t; if (e.d) o.desc = e.d; if (e.o) o.obs = e.o; if (e.q) o.q = e.q; if (e.f) o.formula = e.f;
  if (e.p && sp.params) o.params = sp.params.map((p) => { const v = e.p[p.key]; if (v == null) return p; const [l, ops] = Array.isArray(v) ? v : [v]; return { ...p, label: l || p.label, options: p.options && ops ? p.options.map(([k, t], i) => [k, ops[i] ?? t]) : p.options }; });
  if (e.a && sp.anim) o.anim = { ...sp.anim, label: e.a };
  if (e.b && Array.isArray(sp.buttons)) o.buttons = sp.buttons.map(([k, t], i) => [k, e.b[i] ?? t]);
  if (e.pr && sp.predict) o.predict = sp.predict.map((it, i) => { const r = e.pr[i]; if (!r) return it; const [q, w, ops] = r; return { ...it, q: q || it.q, why: w || it.why, options: it.options && ops ? it.options.map(([k, t], j) => [k, ops[j] ?? t]) : it.options }; });
  if (TR && typeof sp.metrics === "function") o.metrics = function (st) { const r = sp.metrics.call(this, st); const t = (v) => (typeof v === "string" ? TR(v) : v); return Array.isArray(r) ? r.map((row) => (Array.isArray(row) ? row.map(t) : t(row))) : t(r); };
  return o;
}
export async function mount(id, ctx) { await ensure([id]); return mountSpec(loc(full.get(id)), ctx); }
// 카드 그림: 설명서가 있으면 바로 그리고, 없으면 자리표시를 두었다가 화면에 보일 때 채운다
export const thumb = (id) => (full.has(id) ? thumbSVG(full.get(id)) : "");
const io = typeof IntersectionObserver !== "undefined" ? new IntersectionObserver((ents) => {
  for (const en of ents) {
    if (!en.isIntersecting) continue;
    const el = en.target, id = el.dataset.hsThumb; io.unobserve(el);
    ensure([id]).then(() => { if (el.isConnected) { const svg = thumb(id); if (svg) el.outerHTML = svg; } }).catch(() => {});
  }
}, { rootMargin: "400px 0px" }) : null;
export const thumbHolder = (id) => `<span class="hs-thumb-wait" data-hs-thumb="${id}"></span>`;
export function watchThumbs(root = document) { root.querySelectorAll?.("[data-hs-thumb]:not([data-hs-seen])").forEach((el) => { el.dataset.hsSeen = "1"; if (io) io.observe(el); else ensure([el.dataset.hsThumb]).then(() => { const svg = thumb(el.dataset.hsThumb); if (svg) el.outerHTML = svg; }); }); }
if (typeof MutationObserver !== "undefined" && typeof document !== "undefined") {
  let t = 0; new MutationObserver(() => { if (!t) t = requestAnimationFrame(() => { t = 0; watchThumbs(); }); }).observe(document.documentElement, { childList: true, subtree: true });
}
