// 23차 묶음 13 — 기하 추가 실험 10개
import { fmt, clamp, add, sub, mul, dot, len, cross, norm, lerp } from "./hs-core.js";

const GE = 6;
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const deg = (d) => (d * Math.PI) / 180;
const SKEW = {
  diag: { n: "윗면 대각선", P: [0, 1, 1], d: [1, -1, 0] },
  side: { n: "옆면 대각선", P: [1, 0, 0], d: [0, 1, 1] },
  edge: { n: "꼬인 모서리", P: [0, 1, 0], d: [0, 0, 1] },
};
function cube(g, s = 1, o = {}) { const V = [[0, 0, 0], [s, 0, 0], [s, s, 0], [0, s, 0], [0, 0, s], [s, 0, s], [s, s, s], [0, s, s]]; [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]].forEach(([a, b]) => g.seg(V[a], V[b], { color: "muted", w: 1.2, opacity: 0.7, ...o })); return V; }

export default [
  {
    id: "geo-dandelin", grade: GE, unit: 1, lesson: "Ⅰ-2 탐구", title: "단델린 구 — 원뿔을 자른 곡선이 타원인 까닭", type: "조작", time: "12분",
    tags: ["타원", "원뿔의 단면", "초점"], links: ["geo-conic-section", "geo-ellipse"],
    desc: "원뿔을 비스듬한 평면으로 자르면 생기는 곡선이 왜 타원일까요? 원뿔과 평면에 동시에 접하는 두 구(단델린 구)를 넣으면 구가 평면에 닿는 두 점이 타원의 초점이 됩니다. 원뿔의 축을 지나는 단면도에서 곡선 위의 점 P까지의 두 거리의 합이 늘 같음을 확인합니다.",
    obs: ["한 점에서 구에 그은 접선의 길이는 모두 같습니다.", "그래서 PF₁ = (P에서 위 접원까지의 모선 길이), PF₂ = (아래 접원까지의 모선 길이)입니다.", "두 길이의 합은 두 접원 사이의 모선 길이로 일정하므로 타원입니다."],
    q: "자르는 평면을 원뿔의 모선과 평행하게 기울이면 아래 구는 어떻게 될까요?",
    formula: "PF₁ + PF₂ = (두 접원 사이의 모선의 길이) = 일정",
    en: { title: "Dandelin Spheres", desc: "Why a slanted cut of a cone is an ellipse." },
    view: { x: [-5, 13], y: [-0.4, 8.2] },
    params: [{ key: "tilt", label: "평면의 기울기 (°)", min: 5, max: 40, step: 1, value: 25 }, { key: "u", label: "타원 위의 점 P", min: 0, max: 6.28, step: 0.01, value: 1.2 }],
    anim: { key: "u", min: 0, max: 6.28, speed: 0.8, label: "P 돌리기", loop: "wrap" },
    ell(G) { const a = len(sub(G.B, G.A)) / 2, M = lerp(G.A, G.B, 0.5), c = len(sub(G.F1, M)), b = Math.sqrt(Math.max(0, a * a - c * c)); return { a, b, c, E0: [9.2, 3.8] }; },
    geo(s) {
      const al = deg(25), V = [0, 8], th = deg(s.tilt), C0 = [0, 3.6], dir = [Math.cos(th), Math.sin(th)];
      const lineL = (y) => [-(V[1] - y) * Math.tan(al), y], lineR = (y) => [(V[1] - y) * Math.tan(al), y];
      // 단면 직선과 두 모선의 교점
      const hit = (sg) => { const k = sg * Math.tan(al); const t = (k * (V[1] - C0[1]) - C0[0]) / (dir[0] + k * dir[1]); return add(C0, mul(dir, t)); };
      const A = hit(-1), B = hit(1);
      // 원뿔 양 모선과 단면 직선에 접하는 원 (축 위의 중심): 중심 (0, c), 반지름 r = (8 − c) sin α, 직선까지 거리 = r
      const ins = (side) => { let lo = side > 0 ? C0[1] - 6 : C0[1], hi = side > 0 ? C0[1] : 7.99; const f = (c) => { const r = (V[1] - c) * Math.sin(al), dl = Math.abs((0 - C0[0]) * dir[1] - (c - C0[1]) * dir[0]); return dl - r; }; for (let i = 0; i < 80; i++) { const m = (lo + hi) / 2; if ((f(lo) > 0) === (f(m) > 0)) lo = m; else hi = m; } const c = (lo + hi) / 2; return { c, r: (V[1] - c) * Math.sin(al) }; };
      const S1 = ins(1), S2 = ins(-1), foot = (c) => { const v = sub([0, c], C0), t = dot(v, dir); return add(C0, mul(dir, t)); };
      return { al, V, A, B, dir, S1, S2, F1: foot(S1.c), F2: foot(S2.c), lineL, lineR };
    },
    draw(s, g) {
      const G = this.geo(s), E = this.ell(G), P = [E.E0[0] + E.a * Math.cos(s.u), E.E0[1] + E.b * Math.sin(s.u)], F1 = [E.E0[0] - E.c, E.E0[1]], F2 = [E.E0[0] + E.c, E.E0[1]];
      g.seg(G.V, G.lineL(0), { color: "ink", w: 2 }).seg(G.V, G.lineR(0), { color: "ink", w: 2 });
      g.seg(sub(G.A, mul(G.dir, 0.6)), add(G.B, mul(G.dir, 0.6)), { color: "b", w: 3 });
      [G.S1, G.S2].forEach((S, i) => { g.circle([0, S.c], S.r, { color: i ? "c" : "a", w: 1.8, fill: i ? "c" : "a", fo: 0.08 }); const y = S.c + S.r * Math.sin(G.al); g.seg(G.lineL(y), G.lineR(y), { color: i ? "c" : "a", w: 1.2, dash: "4 4" }); });
      g.point(G.F1, "F₁", { color: "a", dy: 20 }).point(G.F2, "F₂", { color: "c" });
      g.param((t) => [E.E0[0] + E.a * Math.cos(t), E.E0[1] + E.b * Math.sin(t)], 0, 2 * Math.PI, { color: "b", w: 3 });
      g.point(F1, "F₁", { color: "a", dy: 20 }).point(F2, "F₂", { color: "c", dy: 20 });
      g.seg(P, F1, { color: "a", w: 2 }).seg(P, F2, { color: "c", w: 2 }).point(P, "P", { color: "e" });
      g.text([-4.8, 7.8], "축을 지나는 단면도", { anchor: "start", size: 12, color: "muted", bold: true }).text([E.E0[0], 7.8], "잘린 면을 정면에서 본 타원", { size: 12, color: "muted", bold: true });
    },
    metrics(s) { const G = this.geo(s), E = this.ell(G), P = [E.a * Math.cos(s.u), E.b * Math.sin(s.u)], d1 = Math.hypot(P[0] + E.c, P[1]), d2 = Math.hypot(P[0] - E.c, P[1]); return [["PF₁", fmt(d1, 3)], ["PF₂", fmt(d2, 3)], ["PF₁ + PF₂", fmt(d1 + d2, 3), "key"], ["장축의 길이 (양 끝 사이)", fmt(len(sub(G.B, G.A)), 3)]]; },
    predict: [
      { q: "P를 움직이면 PF₁ + PF₂는?", options: O("일정하다", "P가 가운데일 때 가장 크다", "P가 끝으로 갈수록 커진다"), set: (s) => Object.assign(s, { u: 0.4 }), reveal: (s) => (s.u = 2.6), answer: () => "a", why: "접선의 길이가 같다는 성질로 두 거리의 합이 두 접원 사이의 모선 길이와 같아 일정합니다." },
      { q: "PF₁ + PF₂는 무엇과 같을까요?", options: O("장축의 길이", "단축의 길이", "두 초점 사이의 거리"), answer: () => "a", why: "P를 장축의 끝에 두면 PF₁ + PF₂가 장축의 길이와 같아집니다." },
    ],
  },
  {
    id: "geo-rect-hyperbola", grade: GE, unit: 1, lesson: "Ⅰ-3", title: "xy = k도 쌍곡선 — 45° 돌려 보면", type: "조작", time: "10분",
    tags: ["쌍곡선", "회전", "점근선"], links: ["geo-hyperbola"],
    desc: "반비례 그래프 xy = k를 45° 돌리면 x² − y² = 2k라는 쌍곡선의 방정식과 정확히 겹칩니다. 회전 각도를 바꾸며 두 곡선이 포개지는 순간을 보고, 점근선이 좌표축에서 y = ±x로 바뀌는 것을 확인합니다. (회전 변환은 교과서 밖 보충 내용입니다.)",
    obs: ["xy = k의 점근선은 x축과 y축입니다.", "45° 돌리면 점근선이 y = x, y = −x가 됩니다.", "그래서 반비례 그래프도 두 점근선이 수직인 쌍곡선(직각쌍곡선)입니다."],
    q: "xy = 2의 초점의 좌표는 어디일까요?",
    formula: "xy = k를 45° 회전 → x² − y² = 2k",
    en: { title: "xy = k Is a Hyperbola", desc: "Rotate by 45°." },
    view: { x: [-5.5, 5.5], y: [-4.2, 4.2] },
    params: [{ key: "k", label: "k", min: 0.5, max: 4, step: 0.5, value: 2 }, { key: "rot", label: "회전 각도 (°)", min: 0, max: 45, step: 1, value: 20 }],
    anim: { key: "rot", min: 0, max: 45, speed: 12, label: "돌리기" },
    draw(s, g) {
      const a = deg(s.rot), R = ([x, y]) => [x * Math.cos(a) - y * Math.sin(a), x * Math.sin(a) + y * Math.cos(a)], A = Math.sqrt(2 * s.k);
      g.grid();
      g.param((t) => [A * Math.cosh(t), A * Math.sinh(t)], -2.2, 2.2, { color: "b", w: 5, opacity: 0.35 }).param((t) => [-A * Math.cosh(t), A * Math.sinh(t)], -2.2, 2.2, { color: "b", w: 5, opacity: 0.35 });
      [1, -1].forEach((sg) => g.param((t) => R([sg * Math.exp(t), (sg * s.k) / Math.exp(t)]), -3, 3, { color: "a", w: 2.6 }));
      g.line([0, 0], R([1, 0]), { color: "a", w: 1.2, dash: "5 5" }).line([0, 0], R([0, 1]), { color: "a", w: 1.2, dash: "5 5" });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], `주황: xy = ${fmt(s.k)}를 ${s.rot}° 돌린 곡선   파랑: x² − y² = ${fmt(2 * s.k)}`, { anchor: "start", bold: true, size: 13 });
    },
    metrics(s) { return [["회전 각도", `${s.rot}°`], ["두 곡선", s.rot === 45 ? "완전히 포개짐" : "아직 다름", "key"], ["x² − y² = 2k의 꼭짓점", `(±${fmt(Math.sqrt(2 * s.k), 3)}, 0)`]]; },
    predict: [
      { q: "xy = 2를 45° 돌리면 x² − y² = □이 됩니다. □는?", set: (s) => Object.assign(s, { k: 2, rot: 0 }), reveal: (s) => (s.rot = 45), answer: () => 4, why: "x² − y² = 2k = 4입니다." },
      { q: "xy = k의 두 점근선이 이루는 각은?", answer: () => 90, why: "x축과 y축이므로 90°, 그래서 직각쌍곡선이라 부릅니다." },
    ],
  },
  {
    id: "geo-parabola-tangent", grade: GE, unit: 1, lesson: "Ⅰ-5 탐구", title: "포물선의 접선 작도 — 초점과 준선의 이등분선", type: "조작", time: "10분",
    tags: ["포물선", "접선", "작도"], links: ["geo-parabola", "geo-tangent-reflect"],
    desc: "포물선 위의 점 P에서 준선에 내린 수선의 발을 H, 초점을 F라 하면 PF = PH이므로 ∠FPH의 이등분선이 P에서의 접선입니다. 자와 컴퍼스로 접선을 그리는 방법을 확인하고, 접선이 FH의 수직이등분선이라는 것도 봅니다.",
    obs: ["PF = PH이므로 삼각형 PFH는 이등변삼각형입니다.", "꼭지각 ∠FPH의 이등분선은 밑변 FH의 수직이등분선과 같습니다.", "그 직선이 포물선과 P에서만 만나는 접선입니다."],
    q: "이 성질로 포물선 모양 거울이 빛을 초점에 모으는 까닭을 설명해 봅시다.",
    formula: "P에서의 접선 = ∠FPH의 이등분선 = FH의 수직이등분선",
    en: { title: "Constructing a Parabola's Tangent", desc: "Bisect the angle between PF and PH." },
    view: { x: [-5.5, 5.5], y: [-2.2, 5.6] },
    params: [{ key: "p", label: "초점 거리 p", min: 0.5, max: 2, step: 0.1, value: 1 }, { key: "x", label: "점 P의 x좌표", min: -4.5, max: 4.5, step: 0.05, value: 2.6 }],
    anim: { key: "x", min: -4.5, max: 4.5, speed: 1.4, label: "P 움직이기", loop: "bounce" },
    draw(s, g) {
      const f = (x) => (x * x) / (4 * s.p), F = [0, s.p], P = [s.x, f(s.x)], H = [s.x, -s.p], M = lerp(F, H, 0.5);
      g.grid();
      g.fx(f, { color: "b", w: 3 });
      g.seg([g.xr[0], -s.p], [g.xr[1], -s.p], { color: "e", w: 1.8, dash: "6 4" }).text([g.xr[1] - 0.2, -s.p], "준선", { anchor: "end", dy: -6, size: 12, color: "e", bold: true });
      g.poly([F, P, H], { fill: "c", fo: 0.12, color: "c", w: 1.6 });
      g.line(P, M, { color: "a", w: 2.6 });
      g.seg(F, H, { color: "muted", w: 1.2, dash: "3 4" }).point(M, "", { color: "muted", r: 3.5 });
      g.point(F, "F", { color: "ink" }).point(P, "P", { color: "a" }).point(H, "H", { color: "e", dy: 18 });
    },
    metrics(s) { const P = [s.x, (s.x * s.x) / (4 * s.p)]; return [["PF", fmt(len(sub(P, [0, s.p])), 3)], ["PH", fmt(P[1] + s.p, 3)], ["접선의 기울기", fmt(s.x / (2 * s.p), 3), "key"]]; },
    predict: [
      { q: "PF와 PH의 관계는?", options: O("같다", "PF가 더 길다", "PH가 더 길다"), answer: () => "a", why: "포물선의 정의가 '초점과 준선까지의 거리가 같은 점'이기 때문입니다." },
      { q: "y = x²/4 (p = 1) 위의 점 (2, 1)에서의 접선의 기울기는?", set: (s) => Object.assign(s, { p: 1, x: -2 }), reveal: (s) => (s.x = 2), answer: () => 1, why: "FH의 수직이등분선의 기울기가 x/(2p) = 1입니다." },
    ],
  },
  {
    id: "geo-space-point", grade: GE, unit: 2, lesson: "Ⅱ-4", title: "좌표공간의 점 읽기 — 상자 하나로 (a, b, c)", type: "3D", time: "10분",
    tags: ["좌표공간", "정사영", "대칭"], links: ["geo-space-coord", "geo-sphere-eq"],
    desc: "점 P(a, b, c)를 꼭짓점으로 하는 상자를 그리면 세 좌표가 상자의 가로·세로·높이가 됩니다. P를 xy평면·yz평면·zx평면에 내린 발과 원점·좌표축에 대한 대칭점의 좌표가 어떻게 바뀌는지 돌려 보며 확인합니다.",
    obs: ["xy평면 위로의 정사영은 (a, b, 0)입니다.", "xy평면에 대한 대칭점은 (a, b, −c)로 z좌표의 부호만 바뀝니다.", "원점까지의 거리는 상자의 대각선 √(a² + b² + c²)입니다."],
    q: "점 (2, −3, 4)를 x축에 대하여 대칭이동한 점의 좌표는?",
    formula: "OP = √(a² + b² + c²)",
    en: { title: "Reading Points in Space", desc: "A box gives (a, b, c)." },
    space: true,
    cam: { yaw: 32, pitch: 22, scale: 36, center: [1, 1, 1] },
    params: [{ key: "a", label: "a", min: -3, max: 4, step: 0.5, value: 3 }, { key: "b", label: "b", min: -3, max: 4, step: 0.5, value: 2 }, { key: "c", label: "c", min: -3, max: 4, step: 0.5, value: 2.5 }, { key: "sym", label: "대칭점", type: "seg", value: "xy", options: [["none", "없음"], ["xy", "xy평면"], ["o", "원점"], ["x", "x축"]] }],
    draw(s, g) {
      const { a, b, c } = s, P = [a, b, c];
      g.axes(4.2, { ticks: true });
      const V = [[0, 0, 0], [a, 0, 0], [a, b, 0], [0, b, 0], [0, 0, c], [a, 0, c], [a, b, c], [0, b, c]];
      [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]].forEach(([i, j]) => g.seg(V[i], V[j], { color: "muted", w: 1, dash: "4 4" }));
      g.point([a, b, 0], "(a, b, 0)", { color: "b", r: 4 }).point([0, b, c], "", { color: "c", r: 3.5 }).point([a, 0, c], "", { color: "d", r: 3.5 });
      g.seg([0, 0, 0], P, { color: "a", w: 2.4 }).point(P, `P(${fmt(a)}, ${fmt(b)}, ${fmt(c)})`, { color: "a" });
      const Q = s.sym === "xy" ? [a, b, -c] : s.sym === "o" ? [-a, -b, -c] : s.sym === "x" ? [a, -b, -c] : null;
      if (Q) { g.seg(P, Q, { color: "e", w: 1.2, dash: "3 4" }); g.point(Q, `(${fmt(Q[0])}, ${fmt(Q[1])}, ${fmt(Q[2])})`, { color: "e" }); }
    },
    metrics(s) { const { a, b, c } = s, Q = s.sym === "xy" ? [a, b, -c] : s.sym === "o" ? [-a, -b, -c] : s.sym === "x" ? [a, -b, -c] : null; return [["xy평면 위로의 정사영", `(${fmt(a)}, ${fmt(b)}, 0)`], ["대칭점", Q ? `(${Q.map((v) => fmt(v)).join(", ")})` : "—", "key"], ["OP", fmt(Math.hypot(a, b, c), 3)]]; },
    predict: [
      { q: "점 (2, −3, 4)를 x축에 대하여 대칭이동한 점의 z좌표는?", set: (s) => Object.assign(s, { a: 2, b: -3, c: 4, sym: "none" }), reveal: (s) => (s.sym = "x"), answer: () => -4, why: "x축 대칭은 y, z의 부호를 바꾸므로 (2, 3, −4)입니다." },
      { q: "점 (2, 2, 1)과 원점 사이의 거리는?", answer: () => 3, why: "√(4 + 4 + 1) = 3입니다." },
    ],
  },
  {
    id: "geo-tetra-section", grade: GE, unit: 2, lesson: "Ⅱ 탐구", title: "정사면체를 자르면 정사각형이 나온다", type: "3D", time: "12분",
    tags: ["정사면체", "단면", "평행"], links: ["geo-cylinder-cut", "cross-section"],
    desc: "정사면체의 마주 보는 두 모서리에 평행한 평면으로 자르면 단면은 직사각형이 되고, 한가운데에서 자르면 정사각형이 됩니다. 자르는 위치를 바꾸며 단면의 가로·세로가 서로 반대로 바뀌어 둘레는 일정하고 넓이는 가운데에서 가장 큰 것을 확인합니다.",
    obs: ["단면의 각 변은 평행한 모서리와 평행합니다.", "자르는 위치 t에서 가로는 t, 세로는 1 − t에 비례합니다.", "그래서 둘레는 일정하고, 넓이는 t = 1/2일 때 가장 큽니다."],
    q: "정육면체를 한 평면으로 자를 때 정육각형 단면은 어떻게 만들 수 있을까요?",
    formula: "단면 = 가로 ta × 세로 (1 − t)a (a: 모서리 길이)",
    en: { title: "A Square Inside a Tetrahedron", desc: "Slice parallel to opposite edges." },
    space: true,
    cam: { yaw: 40, pitch: 18, scale: 110, center: [0.5, 0.5, 0.5] },
    params: [{ key: "t", label: "자르는 위치 t", min: 0.05, max: 0.95, step: 0.01, value: 0.5 }],
    anim: { key: "t", min: 0.05, max: 0.95, speed: 0.3, label: "평면 움직이기", loop: "bounce" },
    draw(s, g) {
      const A = [1, 1, 1], B = [1, 0, 0], C = [0, 1, 0], D = [0, 0, 1], E = [[A, B], [A, C], [A, D], [B, C], [B, D], [C, D]];
      E.forEach(([p, q]) => g.seg(p, q, { color: "ink", w: 1.8 }));
      // AB와 CD에 평행한 평면: A-C, A-D, B-C, B-D 모서리를 t로 나누는 점
      const P1 = lerp(A, C, s.t), P2 = lerp(A, D, s.t), P3 = lerp(B, D, s.t), P4 = lerp(B, C, s.t);
      g.face([P1, P2, P3, P4], { fill: "a", fo: 0.45, color: "a", w: 2.4, bias: 1 });
      g.seg(A, B, { color: "b", w: 3.4 }).seg(C, D, { color: "c", w: 3.4 });
      [["A", A], ["B", B], ["C", C], ["D", D]].forEach(([n, p]) => g.point(p, n, { color: "ink", r: 4 }));
    },
    metrics(s) { const a = Math.SQRT2, w = s.t * a, h = (1 - s.t) * a; return [["가로 · 세로 (모서리 √2 기준)", `${fmt(w, 3)} · ${fmt(h, 3)}`], ["둘레", fmt(2 * (w + h), 3)], ["넓이", fmt(w * h, 4), "key"], ["모양", Math.abs(s.t - 0.5) < 0.006 ? "정사각형" : "직사각형"]]; },
    predict: [
      { q: "t = 1/2일 때 단면은 어떤 모양일까요?", options: O("정사각형", "정삼각형", "마름모가 아닌 평행사변형"), set: (s) => (s.t = 0.2), reveal: (s) => (s.t = 0.5), answer: () => "a", why: "가로와 세로가 모두 모서리의 절반이고, 두 모서리 AB, CD가 수직이라 각도 90°입니다." },
      { q: "모서리가 2인 정사면체를 한가운데에서 잘랐을 때 단면의 넓이는?", answer: () => 1, why: "한 변이 1인 정사각형이므로 넓이는 1입니다." },
    ],
  },
  {
    id: "geo-skew-distance", grade: GE, unit: 4, lesson: "Ⅳ-1 탐구", title: "꼬인 위치의 두 직선 사이의 거리 — 공통수선 찾기", type: "3D", time: "12분",
    tags: ["꼬인 위치", "공통수선", "외적"], links: ["geo-space-lines", "geo-space-line"],
    desc: "정육면체의 한 모서리와 꼬인 위치에 있는 직선 위에서 점 P, Q를 움직여 PQ가 가장 짧아지는 곳을 찾습니다. 그때 PQ는 두 직선 모두와 수직(공통수선)이고, 길이가 두 직선 사이의 거리입니다.",
    obs: ["꼬인 두 직선 사이의 거리는 두 직선 위의 점 사이 거리의 최솟값입니다.", "가장 짧을 때 PQ는 두 직선과 모두 수직입니다.", "두 방향벡터에 모두 수직인 벡터 n을 쓰면 거리 = |(Q₀ − P₀)·n| / |n|입니다(외적은 교과 밖 보충)."],
    q: "정육면체에서 한 모서리와 꼬인 위치에 있는 모서리는 몇 개일까요?",
    formula: "거리 = |PQ|의 최솟값 (PQ ⊥ 두 직선)",
    en: { title: "Distance Between Skew Lines", desc: "Find the common perpendicular." },
    space: true,
    cam: { yaw: 35, pitch: 22, scale: 120, center: [0.5, 0.5, 0.5] },
    params: [{ key: "L", label: "둘째 직선", type: "seg", value: "diag", options: Object.entries(SKEW).map(([k, v]) => [k, v.n]) }, { key: "p", label: "첫째 직선 위의 P", min: -0.5, max: 1.5, step: 0.01, value: 0.2 }, { key: "q", label: "둘째 직선 위의 Q", min: -0.5, max: 1.5, step: 0.01, value: 0.8 }],
    best(s) { const K = SKEW[s.L], d1 = [1, 0, 0], d2 = K.d, w = sub([0, 0, 0], K.P), a = dot(d1, d1), b = dot(d1, d2), c = dot(d2, d2), d = dot(d1, w), e = dot(d2, w), D = a * c - b * b; return { p: (b * e - c * d) / D, q: (a * e - b * d) / D }; },
    draw(s, g) {
      const K = SKEW[s.L], L1 = (t) => [t, 0, 0], L2 = (t) => add(K.P, mul(K.d, t)), B = this.best(s);
      cube(g);
      g.seg(L1(-0.5), L1(1.5), { color: "b", w: 3 }).seg(L2(-0.5), L2(1.5), { color: "c", w: 3 });
      g.seg(L1(B.p), L2(B.q), { color: "e", w: 1.6, dash: "4 4" });
      g.seg(L1(s.p), L2(s.q), { color: "a", w: 2.6 }).point(L1(s.p), "P", { color: "b" }).point(L2(s.q), "Q", { color: "c" });
    },
    metrics(s) { const K = SKEW[s.L], L1 = (t) => [t, 0, 0], L2 = (t) => add(K.P, mul(K.d, t)), B = this.best(s); return [["지금 PQ", fmt(len(sub(L2(s.q), L1(s.p))), 4)], ["가장 짧은 거리", fmt(len(sub(L2(B.q), L1(B.p))), 4), "key"], ["그때 P, Q의 위치", `${fmt(B.p, 2)}, ${fmt(B.q, 2)}`]]; },
    predict: [
      { q: "한 모서리가 1인 정육면체에서 밑모서리와 윗면 대각선 사이의 거리는?", set: (s) => Object.assign(s, { L: "diag", p: 0.1, q: 0.1 }), reveal: (s) => Object.assign(s, { p: 0, q: 1 }), answer: () => 1, why: "두 직선에 모두 수직인 방향이 z축이고, 높이 차가 1입니다." },
      { q: "밑모서리 (t, 0, 0)과 모서리 (0, 1, t) 사이의 거리는?", set: (s) => Object.assign(s, { L: "edge", p: 0.5, q: 0.5 }), answer: () => 1, why: "공통수선이 y축 방향이고 길이가 1입니다." },
    ],
  },
  {
    id: "geo-point-plane", grade: GE, unit: 4, lesson: "Ⅳ-2", title: "점과 평면 사이의 거리 — 법선을 따라 내려가기", type: "3D", time: "12분",
    tags: ["점과 평면 사이의 거리", "법선벡터", "수선의 발"], links: ["geo-plane-eq", "c2-point-line"],
    desc: "점 P에서 평면 ax + by + cz + d = 0에 내린 수선은 법선벡터 n = (a, b, c) 방향입니다. 수선의 발 H를 찾아 PH의 길이가 |ax₀ + by₀ + cz₀ + d| / √(a² + b² + c²)임을 확인하고, 평면 위의 다른 점까지의 거리는 항상 더 길다는 것도 봅니다.",
    obs: ["수선의 발 H = P − t·n의 꼴로 찾습니다.", "거리 공식은 좌표평면에서 점과 직선 사이의 거리 공식과 같은 모양입니다.", "평면 위의 다른 점 Q에 대하여 PQ ≥ PH입니다."],
    q: "점 (1, 2, 3)과 평면 x + 2y + 2z = 1 사이의 거리를 구해 봅시다.",
    formula: "d = |ax₀ + by₀ + cz₀ + d| / √(a² + b² + c²)",
    en: { title: "Distance from a Point to a Plane", desc: "Go down along the normal." },
    space: true,
    cam: { yaw: 30, pitch: 18, scale: 40, center: [0, 0, 1] },
    params: [{ key: "x0", label: "P의 x", min: -2, max: 3, step: 0.5, value: 1 }, { key: "y0", label: "P의 y", min: -2, max: 3, step: 0.5, value: 2 }, { key: "z0", label: "P의 z", min: -1, max: 5, step: 0.5, value: 3 }, { key: "d", label: "평면 x + 2y + 2z = d의 d", min: -6, max: 8, step: 1, value: 1 }],
    draw(s, g) {
      const n = [1, 2, 2], P = [s.x0, s.y0, s.z0], t = (dot(n, P) - s.d) / 9, H = sub(P, mul(n, t)), c = mul(n, s.d / 9), u = norm(cross(n, [0, 0, 1])), v = norm(cross(n, u));
      g.axes(4);
      g.plane(c, u, v, 3, 3, { color: "b", grid: 1 });
      g.vec(H, add(H, mul(norm(n), 1.2)), { color: "c", label: "n" });
      g.seg(P, H, { color: "a", w: 3 }).point(P, "P", { color: "a" }).point(H, "H", { color: "e" });
    },
    metrics(s) { const n = [1, 2, 2], P = [s.x0, s.y0, s.z0], D = Math.abs(dot(n, P) - s.d) / 3, t = (dot(n, P) - s.d) / 9, H = sub(P, mul(n, t)); return [["거리 PH", fmt(D, 4), "key"], ["공식", `|${fmt(s.x0)} + 2·${fmt(s.y0)} + 2·${fmt(s.z0)} − ${fmt(s.d)}| / 3`], ["수선의 발 H", `(${H.map((x) => fmt(x, 2)).join(", ")})`]]; },
    predict: [
      { q: "점 (1, 2, 3)과 평면 x + 2y + 2z = 1 사이의 거리는?", set: (s) => Object.assign(s, { x0: 1, y0: 2, z0: 3, d: 1 }), answer: () => 10 / 3, tol: 0.001, show: () => "10/3", why: "|1 + 4 + 6 − 1| / √9 = 10/3입니다." },
      { q: "점 P가 평면 위에 있으면 거리는?", answer: () => 0, why: "ax₀ + by₀ + cz₀ + d = 0이라 분자가 0입니다." },
    ],
  },
  {
    id: "geo-incline-force", grade: GE, unit: 3, lesson: "Ⅲ 탐구 & 융합", title: "경사면 위의 상자 — 무게를 두 벡터로 나누기", type: "조작", time: "10분",
    tags: ["벡터의 분해", "삼각비", "물리"], links: ["geo-tug-of-war", "geo-vector-add"],
    desc: "경사면 위의 상자에 작용하는 무게 W를 경사면을 따라 미끄러뜨리는 성분과 경사면을 누르는 성분으로 나눕니다. 기울기 θ를 바꾸며 두 성분이 W sin θ, W cos θ이고 두 벡터의 합이 원래 W임을 평행사변형으로 확인합니다.",
    obs: ["무게는 아래쪽 한 방향이지만 경사면에 맞춘 두 방향으로 나눌 수 있습니다.", "미끄러지는 성분은 W sin θ, 누르는 성분은 W cos θ입니다.", "θ가 커질수록 미끄러지는 힘이 커집니다."],
    q: "θ = 90°이면 두 성분은 어떻게 될까요? 그 상황은 무엇일까요?",
    formula: "W = W sin θ (경사면 방향) + W cos θ (수직 방향)",
    en: { title: "Forces on an Incline", desc: "Split weight into two vectors." },
    view: { x: [-1, 11], y: [-1, 7.4] },
    params: [{ key: "th", label: "경사각 θ (°)", min: 5, max: 60, step: 1, value: 30 }, { key: "W", label: "무게 W (N)", min: 10, max: 50, step: 5, value: 30 }],
    draw(s, g) {
      const t = deg(s.th), L = 9.6, top = [0.2 + L * Math.cos(t), L * Math.sin(t)], base = [0.2 + L * Math.cos(t), 0];
      g.poly([[0.2, 0], base, top], { fill: "muted", fo: 0.15, color: "ink", w: 2 });
      const u = [Math.cos(t), Math.sin(t)], nrm = [-Math.sin(t), Math.cos(t)], C = add([0.2, 0], add(mul(u, L * 0.55), mul(nrm, 0.55))), k = 3 / 50;
      const box = [add(C, add(mul(u, -0.55), mul(nrm, -0.55))), add(C, add(mul(u, 0.55), mul(nrm, -0.55))), add(C, add(mul(u, 0.55), mul(nrm, 0.55))), add(C, add(mul(u, -0.55), mul(nrm, 0.55)))];
      g.poly(box, { fill: "b", fo: 0.3, color: "b", w: 2 });
      const Wv = [0, -s.W * k], along = mul(u, -s.W * Math.sin(t) * k), into = mul(nrm, -s.W * Math.cos(t) * k);
      g.vec(C, add(C, Wv), { color: "ink", w: 3, label: "W" });
      g.vec(C, add(C, along), { color: "a", w: 3, label: "W sin θ" }).vec(C, add(C, into), { color: "c", w: 3, label: "W cos θ" });
      g.seg(add(C, along), add(C, Wv), { color: "muted", w: 1, dash: "3 3" }).seg(add(C, into), add(C, Wv), { color: "muted", w: 1, dash: "3 3" });
      g.arc([0.2, 0], [1.2, 0], top, { color: "e", r: 40, label: `${s.th}°` });
    },
    metrics(s) { const t = deg(s.th); return [["미끄러지는 성분 W sin θ", `${fmt(s.W * Math.sin(t), 2)} N`, "key"], ["누르는 성분 W cos θ", `${fmt(s.W * Math.cos(t), 2)} N`], ["두 성분의 제곱의 합의 제곱근", `${fmt(Math.hypot(s.W * Math.sin(t), s.W * Math.cos(t)), 2)} N = W`]]; },
    predict: [
      { q: "무게 30 N인 상자가 30° 경사면에 있을 때 미끄러지는 성분은 몇 N?", set: (s) => Object.assign(s, { W: 30, th: 10 }), reveal: (s) => (s.th = 30), answer: () => 15, why: "30 × sin 30° = 15 N입니다." },
      { q: "경사가 커지면 경사면을 누르는 성분은?", options: O("작아진다", "커진다", "그대로이다"), set: (s) => Object.assign(s, { th: 10 }), reveal: (s) => (s.th = 60), answer: () => "a", why: "W cos θ는 θ가 커질수록 작아집니다." },
    ],
  },
  {
    id: "geo-work-dot", grade: GE, unit: 3, lesson: "Ⅲ-5 실생활", title: "힘이 한 일 = 내적 — 비스듬히 끄는 썰매", type: "조작", time: "10분",
    tags: ["내적", "일", "사잇각"], links: ["geo-dot-product", "geo-incline-force"],
    desc: "썰매를 줄로 비스듬히 끌면 힘 F 가운데 움직이는 방향의 성분만 일을 합니다. 힘의 크기와 줄의 각도를 바꾸며 일 W = F · s = |F||s|cos θ가 내적과 같음을 확인하고, 수직으로 끌면 일이 0이 되는 것도 봅니다.",
    obs: ["일은 (움직인 방향의 힘의 성분) × (움직인 거리)입니다.", "그 값이 두 벡터의 내적 F · s = |F||s|cos θ입니다.", "θ = 90°이면 내적이 0, 힘이 일을 하지 않습니다."],
    q: "θ가 90°보다 크면 내적이 음수가 됩니다. 이것은 어떤 상황일까요?",
    formula: "W = F · s = |F||s| cos θ",
    en: { title: "Work as a Dot Product", desc: "Pulling a sled at an angle." },
    view: { x: [-0.8, 12.6], y: [-1.6, 6.6] },
    params: [{ key: "F", label: "힘의 크기 |F| (N)", min: 10, max: 60, step: 5, value: 40 }, { key: "th", label: "줄의 각도 θ (°)", min: 0, max: 120, step: 1, value: 35 }, { key: "s", label: "움직인 거리 |s| (m)", min: 1, max: 10, step: 0.5, value: 8 }],
    draw(s, g) {
      const t = deg(s.th), k = 4.6 / 60, X0 = 1;
      g.seg([-0.6, 0], [12.4, 0], { color: "ink", w: 2 });
      g.poly([[X0, 0.1], [X0 + 1.6, 0.1], [X0 + 1.8, 0.7], [X0 - 0.1, 0.7]], { fill: "b", fo: 0.35, color: "b", w: 1.8 });
      const C = [X0 + 0.8, 0.6], Fv = [s.F * k * Math.cos(t), s.F * k * Math.sin(t)];
      g.vec(C, add(C, Fv), { color: "a", w: 3.4, label: "F" });
      g.vec(C, [C[0] + Fv[0], C[1]], { color: "c", w: 2.6, label: "|F| cos θ" }).seg(add(C, Fv), [C[0] + Fv[0], C[1]], { color: "muted", w: 1, dash: "3 3" });
      g.vec([X0, -0.8], [X0 + s.s, -0.8], { color: "d", w: 2.4, label: "s" });
      g.arc(C, [C[0] + 1, C[1]], add(C, Fv), { color: "e", r: 30, label: `${s.th}°` });
    },
    metrics(s) { const W = s.F * s.s * Math.cos(deg(s.th)); return [["움직이는 방향의 성분", `${fmt(s.F * Math.cos(deg(s.th)), 2)} N`], ["일 W = F · s", `${fmt(W, 1)} J`, "key"]]; },
    predict: [
      { q: "40 N의 힘으로 60° 방향으로 끌어 8 m 움직였을 때 한 일은 몇 J?", set: (s) => Object.assign(s, { F: 40, th: 20, s: 8 }), reveal: (s) => (s.th = 60), answer: () => 160, why: "40 × 8 × cos 60° = 160 J입니다." },
      { q: "줄을 움직이는 방향과 수직으로 당기면 일은?", set: (s) => (s.th = 40), reveal: (s) => (s.th = 90), answer: () => 0, why: "cos 90° = 0이라 내적이 0입니다." },
    ],
  },
  {
    id: "geo-para-area", grade: GE, unit: 3, lesson: "Ⅲ-5 탐구", title: "두 벡터가 만드는 평행사변형의 넓이", type: "조작", time: "10분",
    tags: ["내적", "넓이", "벡터"], links: ["geo-dot-product", "c2-shoelace"],
    desc: "두 벡터 a, b로 만든 평행사변형의 넓이는 |a||b| sin θ입니다. sin θ를 내적으로 바꾸면 √(|a|²|b|² − (a · b)²)이고, 성분으로 쓰면 |a₁b₂ − a₂b₁|이 됩니다. 두 벡터를 끌어 세 가지 계산이 늘 같은 값인지 확인합니다.",
    obs: ["넓이 = 밑변 |a| × 높이 |b| sin θ입니다.", "sin²θ = 1 − cos²θ이므로 내적만으로도 넓이를 구할 수 있습니다.", "성분으로는 |a₁b₂ − a₂b₁|로 아주 간단해집니다."],
    q: "a = (3, 1), b = (1, 2)일 때 두 벡터가 만드는 삼각형의 넓이는?",
    formula: "S = |a||b| sin θ = √(|a|²|b|² − (a · b)²) = |a₁b₂ − a₂b₁|",
    en: { title: "Parallelogram Area from Vectors", desc: "Three ways to the same area." },
    view: { x: [-5, 6], y: [-3.8, 4.4] },
    init: () => ({ a: [3, 1], b: [1, 2] }),
    drags: { a: { at: (s) => s.a, move: (s, p) => (s.a = [clamp(Math.round(p[0] * 2) / 2, -4.5, 5.5), clamp(Math.round(p[1] * 2) / 2, -3.5, 4)]), label: "a", color: "a" }, b: { at: (s) => s.b, move: (s, p) => (s.b = [clamp(Math.round(p[0] * 2) / 2, -4.5, 5.5), clamp(Math.round(p[1] * 2) / 2, -3.5, 4)]), label: "b", color: "b" } },
    draw(s, g) { const S = add(s.a, s.b); g.grid(); g.poly([[0, 0], s.a, S, s.b], { fill: "c", fo: 0.25, color: "c", w: 1.4 }); g.vec([0, 0], s.a, { color: "a", label: "a" }).vec([0, 0], s.b, { color: "b", label: "b" }); },
    metrics(s) { const [a1, a2] = s.a, [b1, b2] = s.b, A = Math.hypot(a1, a2), B = Math.hypot(b1, b2), D = a1 * b1 + a2 * b2, th = Math.acos(clamp(D / (A * B || 1), -1, 1)); return [["|a||b| sin θ", fmt(A * B * Math.sin(th), 4)], ["√(|a|²|b|² − (a·b)²)", fmt(Math.sqrt(Math.max(0, A * A * B * B - D * D)), 4)], ["|a₁b₂ − a₂b₁|", fmt(Math.abs(a1 * b2 - a2 * b1), 4), "key"]]; },
    predict: [
      { q: "a = (3, 1), b = (1, 2)가 만드는 평행사변형의 넓이는?", set: (s) => Object.assign(s, { a: [3, 1], b: [1, 2] }), answer: () => 5, why: "|3 × 2 − 1 × 1| = 5입니다." },
      { q: "두 벡터가 평행하면 넓이는?", set: (s) => Object.assign(s, { a: [2, 1], b: [1, 2] }), reveal: (s) => (s.b = [4, 2]), answer: () => 0, why: "sin θ = 0이라 평행사변형이 납작해집니다." },
    ],
  },
];
