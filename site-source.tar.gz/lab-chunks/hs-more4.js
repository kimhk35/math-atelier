// 교과서를 더 훑어 추가한 실험 — 수학과 문화 · 직무 수학 · 중1 작도 · 기하 · 미적분Ⅰ · 확률과 통계
import { fmt, frac, surd, dist, sub, add, mul, norm, dot, len, cross, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const V = { x: [-7, 7], y: [-5, 5] };
const COLS = ["a", "b", "c", "e", "f", "d"];
const lcg = (seed) => { let x = seed || 1; return () => ((x = (x * 16807) % 2147483647) / 2147483647); };

export default [
  {
    id: "cul-archery", grade: 11, unit: 2, lesson: "Ⅱ-1", title: "양궁 경기 — 합산제와 세트제", type: "데이터", time: "10분",
    tags: ["점수 방식", "합계", "의사 결정"], links: ["cul-voting", "averages"],
    desc: "두 선수가 4세트 동안 세 발씩 쏜 점수로, 모든 점수를 더하는 합산제와 세트마다 이기면 2점·비기면 1점을 주는 세트제로 승자를 정해 보고 결과가 달라질 수 있음을 확인합니다.",
    obs: ["합산제는 모든 화살의 점수를 똑같이 반영합니다.", "세트제는 한 세트에서 크게 이기든 조금 이기든 2점만 얻습니다.", "그래서 합계는 앞서도 세트제에서는 질 수 있습니다."],
    q: "올림픽 양궁이 세트제를 쓰는 이유는 무엇일까요?",
    formula: "합산제: 점수의 합 · 세트제: 세트 승 2점, 무 1점, 패 0점",
    en: { title: "Archery Scoring Systems", desc: "Compare cumulative scoring with the set system and see winners differ." },
    view: BOX,
    init: () => ({ game: 3 }),
    buttons: [["new", "새 경기"]],
    onDo(k, s) { if (k === "new") s.game = Math.floor(Math.random() * 1e6); },
    scores(s) { const r = lcg(s.game), shot = (sk) => Math.min(10, Math.max(5, Math.round(8 + sk + 1.6 * (r() + r() - 1)))); const A = [0, 1, 2, 3].map((i) => [0, 1, 2].map(() => shot(i === 1 ? 1.4 : -0.1))), B = [0, 1, 2, 3].map(() => [0, 1, 2].map(() => shot(0.2))); return { A, B }; },
    draw(s, g) {
      const { A, B } = this.scores(s), sum = (x) => x.reduce((a, b) => a + b, 0);
      ["세트", "A 선수", "B 선수", "세트 점수"].forEach((h, i) => g.text([1.6, 9.2 - i * 1.6], h, { anchor: "start", bold: true, size: 13 }));
      let sa = 0, sb = 0;
      A.forEach((set, i) => {
        const x = 4.6 + i * 2.8, ta = sum(set), tb = sum(B[i]), pa = ta > tb ? 2 : ta === tb ? 1 : 0, pb = 2 - pa; sa += pa; sb += pb;
        g.text([x, 9.2], `${i + 1}세트`, { bold: true, size: 13, color: "muted" });
        g.text([x, 7.6], `${set.join(" ")} = ${ta}`, { size: 12.5, mono: true, color: ta > tb ? "a" : "ink", bold: ta > tb });
        g.text([x, 6], `${B[i].join(" ")} = ${tb}`, { size: 12.5, mono: true, color: tb > ta ? "b" : "ink", bold: tb > ta });
        g.text([x, 4.4], `${pa} : ${pb}`, { size: 14, bold: true, color: pa > pb ? "a" : pb > pa ? "b" : "muted" });
      });
      const TA = sum(A.flat()), TB = sum(B.flat());
      [[TA, TB, "합산제", 2.4], [sa, sb, "세트제", 1]].forEach(([x1, x2, nm, y]) => { const mx = Math.max(x1, x2), w = 5.5; g.text([1.6, y + 0.3], nm, { anchor: "start", bold: true, size: 13 }); g.poly([[4, y], [4 + (w * x1) / mx, y], [4 + (w * x1) / mx, y + 0.5], [4, y + 0.5]], { fill: "a", fo: 0.55, stroke: false }); g.poly([[10, y], [10 + (w * x2) / mx, y], [10 + (w * x2) / mx, y + 0.5], [10, y + 0.5]], { fill: "b", fo: 0.55, stroke: false }); g.text([4, y + 0.25], `A ${x1}`, { dx: -6, dy: 4, anchor: "end", size: 12, bold: true, color: "a" }); g.text([10, y + 0.25], `B ${x2}`, { dx: -6, dy: 4, anchor: "end", size: 12, bold: true, color: "b" }); });
    },
    metrics(s) { const { A, B } = this.scores(s), sum = (x) => x.reduce((a, b) => a + b, 0); let sa = 0, sb = 0; A.forEach((set, i) => { const d = sum(set) - sum(B[i]); sa += d > 0 ? 2 : d === 0 ? 1 : 0; sb += d < 0 ? 2 : d === 0 ? 1 : 0; }); const TA = sum(A.flat()), TB = sum(B.flat()), w1 = TA > TB ? "A" : TA < TB ? "B" : "무승부", w2 = sa > sb ? "A" : sa < sb ? "B" : "무승부 (슛오프)"; return [["합산제 승자", `${w1} (${TA} : ${TB})`], ["세트제 승자", `${w2} (${sa} : ${sb})`, "key"], w1 !== w2.split(" ")[0] ? "두 방식의 승자가 다릅니다!" : "두 방식의 승자가 같습니다. ‘새 경기’를 눌러 다른 경기도 보세요."]; },
  },
  {
    id: "cul-population", grade: 11, unit: 4, lesson: "Ⅳ-4", title: "표본 구역으로 동물 개체 수 추정하기", type: "데이터", time: "10분",
    tags: ["표본조사", "비례식", "추정"], links: ["pst-proportion", "pst-sample-mean"],
    desc: "넓은 지역을 같은 크기의 칸으로 나누고 몇 칸만 골라 동물 수를 세어 전체 개체 수를 추정합니다. 고르는 칸의 수와 조사를 되풀이한 결과로 추정이 얼마나 흔들리는지 봅니다.",
    obs: ["추정값 = (표본 칸의 동물 수) × (전체 칸 수 ÷ 표본 칸 수)입니다.", "표본 칸을 많이 고를수록 추정값이 실제 값 근처에 모입니다.", "동물이 무리 지어 있으면 칸을 어디서 고르는지에 따라 추정이 크게 달라집니다."],
    q: "항공 조사에서 표본 구역을 무작위로 고르는 이유는 무엇일까요?",
    formula: "추정 개체 수 = (표본에서 센 수) × (전체 넓이) / (표본 넓이)",
    en: { title: "Estimating Animal Populations by Sampling", desc: "Count animals in sample plots and scale up to estimate the total." },
    view: BOX,
    params: [{ key: "k", label: "조사할 칸 수", min: 2, max: 40, step: 1, value: 10 }, { key: "clump", label: "무리 지어 사는 동물", type: "check", value: false }],
    init: () => ({ sample: 7, hist: [] }),
    animals(s) { const r = lcg(s.clump ? 99 : 41), A = []; for (let i = 0; i < 180; i++) { if (s.clump) { const c = [[2, 2], [7, 6], [4, 8]][i % 3]; A.push([clamp(c[0] + 1.2 * (r() + r() + r() - 1.5), 0.05, 9.95), clamp(c[1] + 1.2 * (r() + r() + r() - 1.5), 0.05, 9.95)]); } else A.push([r() * 10, r() * 10]); } return A; },
    cells(s) { const r = lcg(s.sample), ids = [...Array(100).keys()]; for (let i = 99; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [ids[i], ids[j]] = [ids[j], ids[i]]; } return new Set(ids.slice(0, s.k)); },
    est(s) { const A = this.animals(s), C = this.cells(s); const n = A.filter(([x, y]) => C.has(Math.floor(y) * 10 + Math.floor(x))).length; return { n, E: (n * 100) / s.k }; },
    buttons: [["again", "다른 칸 골라 조사"], ["many", "20번 조사"], ["clear", "기록 지우기"]],
    onDo(k, s) { if (k === "clear") { s.hist = []; return; } const times = k === "many" ? 20 : 1; for (let i = 0; i < times; i++) { s.sample = Math.floor(Math.random() * 1e6); s.hist.push(this.est(s).E); } if (s.hist.length > 200) s.hist = s.hist.slice(-200); },
    onChange(s, key) { if (key === "k" || key === "clump") s.hist = []; },
    draw(s, g) {
      const O = [0.6, 0.6], cs = 0.98, A = this.animals(s), C = this.cells(s);
      for (let i = 0; i < 10; i++) for (let j = 0; j < 10; j++) { const on = C.has(j * 10 + i); g.poly([[O[0] + i * cs, O[1] + j * cs], [O[0] + (i + 1) * cs, O[1] + j * cs], [O[0] + (i + 1) * cs, O[1] + (j + 1) * cs], [O[0] + i * cs, O[1] + (j + 1) * cs]], { fill: on ? "f" : "paper", fo: on ? 0.35 : 1, color: "grid", w: 0.8 }); }
      A.forEach(([x, y]) => { const on = C.has(Math.floor(y) * 10 + Math.floor(x)); g.circle([O[0] + x * cs, O[1] + y * cs], 0.07, { color: on ? "d" : "muted", fill: on ? "d" : "muted", fo: 1, w: 0.6, layer: "point" }); });
      const M = (v) => 11 + ((v - 0) / 400) * 4.4; g.seg([11, 1], [15.4, 1], { color: "axis", w: 1.2 }); [0, 180, 400].forEach((v) => g.text([M(v), 1], String(v), { dy: 15, size: 11, color: "muted" }));
      g.seg([M(180), 0.8], [M(180), 10], { color: "c", w: 1.6, dash: "5 4" }); g.text([M(180), 10], "실제 180", { dy: -4, size: 11.5, color: "c", bold: true });
      s.hist.forEach((v, i) => g.circle([M(Math.min(400, v)), 1.4 + (i % 40) * 0.2], 0.08, { color: "b", fill: "b", fo: 0.8, w: 0.6 }));
      g.text([13.2, 10.6], "추정값 기록", { size: 12, bold: true, color: "muted" });
    },
    metrics(s) { const { n, E } = this.est(s), h = s.hist, m = h.length ? h.reduce((a, b) => a + b, 0) / h.length : NaN; return [["표본 칸에서 센 수", `${n}마리`], ["추정 개체 수", `${n} × 100/${s.k} = ${fmt(E, 1)}마리`, "key"], ["추정값들의 평균", h.length ? `${fmt(m, 1)} (${h.length}번)` : "—"], ["실제 개체 수", "180마리"]]; },
  },
  {
    id: "cul-diet-plan", grade: 11, unit: 4, lesson: "Ⅳ-1", title: "균형 잡힌 식단 — 조건을 만족하는 영역", type: "조작", time: "12분",
    tags: ["부등식의 영역", "최적화", "식생활"], links: ["c2-line-eq", "job-perimeter-area"],
    desc: "두 식품 A, B를 몇 인분 먹을지 점으로 움직이며 단백질은 충분히, 지방은 넘치지 않게 하는 조건을 만족하는 영역을 찾고, 그 안에서 열량이 가장 적은 식단을 구합니다.",
    obs: ["각 조건은 직선의 한쪽 영역으로 나타납니다.", "모든 조건을 만족하는 식단은 여러 영역이 겹친 부분의 점입니다.", "열량이 가장 적은 식단은 겹친 영역의 꼭짓점에서 나타납니다."],
    q: "단백질 조건을 더 높이면 가장 가벼운 식단은 어떻게 바뀔까요?",
    formula: "단백질 3x + 2y ≥ P · 지방 x + 3y ≤ F · 열량 4x + 3y 최소",
    en: { title: "Planning a Balanced Diet", desc: "Find servings that meet protein and fat conditions and minimize calories." },
    view: { x: [-0.8, 9], y: [-0.8, 6.5] },
    params: [{ key: "P", label: "필요한 단백질 P (g) 이상", min: 6, max: 20, step: 1, value: 12 }, { key: "F", label: "지방 F (g) 이하", min: 6, max: 18, step: 1, value: 12 }],
    points: { X: [3, 2] },
    constrain(s, k, p) { return [clamp(Math.round(p[0] * 4) / 4, 0, 8.5), clamp(Math.round(p[1] * 4) / 4, 0, 6)]; },
    best(s) {
      const L = [[1, 0, 0], [0, 1, 0], [3, 2, s.P], [1, 3, s.F]], pts = [];
      for (let i = 0; i < 4; i++) for (let j = i + 1; j < 4; j++) { const [a1, b1, c1] = L[i], [a2, b2, c2] = L[j], d = a1 * b2 - a2 * b1; if (Math.abs(d) > 1e-9) pts.push([(c1 * b2 - c2 * b1) / d, (a1 * c2 - a2 * c1) / d]); }
      const ok = (p) => p[0] >= -1e-9 && p[1] >= -1e-9 && 3 * p[0] + 2 * p[1] >= s.P - 1e-9 && p[0] + 3 * p[1] <= s.F + 1e-9, f = pts.filter(ok);
      return f.length ? f.reduce((a, b) => (4 * b[0] + 3 * b[1] < 4 * a[0] + 3 * a[1] ? b : a)) : null;
    },
    draw(s, g) {
      g.grid({ xName: "A (인분)", yName: "B (인분)" });
      for (let x = 0; x <= 8.8; x += 0.2) for (let y = 0; y <= 6.3; y += 0.2) { const c = x + 0.1, d = y + 0.1; if (3 * c + 2 * d >= s.P && c + 3 * d <= s.F) g.poly([[x, y], [x + 0.2, y], [x + 0.2, y + 0.2], [x, y + 0.2]], { fill: "c", fo: 0.22, stroke: false }); }
      g.lineABC(3, 2, -s.P, { color: "b", w: 2.4 }).lineABC(1, 3, -s.F, { color: "d", w: 2.4 });
      g.text([s.P / 3, 0], "단백질 경계", { dy: -8, dx: 6, anchor: "start", size: 12, color: "b", bold: true }).text([0, s.F / 3], "지방 경계", { dx: 8, dy: -6, anchor: "start", size: 12, color: "d", bold: true });
      const B = this.best(s); if (B) { g.line(B, [B[0] + 3, B[1] - 4], { color: "e", w: 1.4, dash: "5 4" }); g.point(B, "열량 최소", { color: "e", r: 6 }); }
      const ok = 3 * s.X[0] + 2 * s.X[1] >= s.P && s.X[0] + 3 * s.X[1] <= s.F;
      g.point(s.X, `(${fmt(s.X[0])}, ${fmt(s.X[1])})`, { color: ok ? "c" : "a", r: 7 }).handle(s.X, "X");
    },
    metrics(s) { const [x, y] = s.X, pr = 3 * x + 2 * y, ft = x + 3 * y, B = this.best(s); return [["단백질", `${fmt(pr)} g ${pr >= s.P ? "≥" : "<"} ${s.P}`], ["지방", `${fmt(ft)} g ${ft <= s.F ? "≤" : ">"} ${s.F}`], ["열량 4x + 3y", `${fmt(4 * x + 3 * y)} (×100 kcal)`], ["가장 가벼운 식단", B ? `A ${fmt(B[0], 2)}, B ${fmt(B[1], 2)} → ${fmt(4 * B[0] + 3 * B[1], 2)}` : "조건을 모두 만족하는 식단이 없음", "key"]]; },
  },
  {
    id: "job-mirror", grade: 12, unit: 3, lesson: "Ⅲ-3 예제", title: "거울에 비친 글자 — 구급차 앞의 거꾸로 글씨", type: "조작", time: "8분",
    tags: ["선대칭", "뒤집기", "실생활"], links: ["job-moves", "c2-reflection"],
    desc: "구급차 앞에 좌우를 뒤집어 쓴 글자가 앞차의 거울에서는 바로 읽히는 까닭을 선대칭으로 확인하고, 뒤집어도 모양이 같은 글자를 찾아봅니다.",
    obs: ["거울은 좌우를 뒤집으므로, 미리 뒤집어 쓴 글자가 거울 속에서는 바로 보입니다.", "A, H, M, O, T, U, V, W, X, Y는 세로 대칭축을 가져 뒤집어도 같습니다.", "글자의 순서도 거꾸로 바뀝니다."],
    q: "‘WOW’를 거울에 비추면 어떻게 보일까요? 위아래로 뒤집으면요?",
    formula: "좌우 뒤집기: (x, y) → (−x, y) · 위아래 뒤집기: (x, y) → (x, −y)",
    en: { title: "Mirror Writing on Ambulances", desc: "Why reversed text reads correctly in a mirror, and which letters are symmetric." },
    view: BOX,
    params: [{ key: "word", label: "글자", type: "select", value: "AMBULANCE", options: [["AMBULANCE", "AMBULANCE"], ["119", "119"], ["WOW", "WOW"], ["MATH", "MATH"], ["TOYOTA", "TOYOTA"]] }, { key: "axis", label: "뒤집기", type: "seg", value: "lr", options: [["lr", "좌우 (거울)"], ["ud", "위아래 (물)"]] }],
    SYM: { lr: new Set("AHIMOTUVWXY08".split("")), ud: new Set("BCDEHIKOX0138".split("")) },
    draw(s, g) {
      const W = String(s.word), flip = s.axis === "lr";
      const mk = (y, txt, tf, col) => g.L.text.push(`<text x="0" y="0" transform="${tf}" text-anchor="middle" font-size="46" font-weight="800" fill="var(--pl-${col})" font-family="IBM Plex Sans KR, sans-serif" letter-spacing="3">${txt}</text>`);
      const cx = g.X([8, 0])[0], y1 = g.X([0, 8.2])[1], y2 = g.X([0, 5])[1], y3 = g.X([0, 1.6])[1];
      g.text([8, 9.6], "구급차 앞에 쓴 글자", { size: 13, bold: true, color: "muted" });
      mk(0, W, `translate(${cx},${y1}) ${flip ? "scale(-1,1)" : "scale(1,-1)"}`, "d");
      g.seg([1.5, 6.6], [14.5, 6.6], { color: "e", w: 2.4, dash: "8 5" }); g.text([14.5, 6.6], flip ? "거울" : "수면", { dy: -6, anchor: "end", size: 12, color: "e", bold: true });
      g.text([8, 6.2], "앞차 거울 속 모습", { size: 13, bold: true, color: "muted" });
      mk(0, W, `translate(${cx},${y2})`, "b");
      g.text([8, 3], "대칭축이 있는 글자", { size: 13, bold: true, color: "muted" });
      [...W].forEach((ch, i) => g.text([8 + (i - (W.length - 1) / 2) * 0.95, 1.6], ch, { size: 22, bold: true, color: this.SYM[s.axis].has(ch) ? "c" : "grid" }));
    },
    metrics(s) { const set = this.SYM[s.axis], same = [...String(s.word)].filter((c) => set.has(c)); return [["뒤집어도 같은 글자", same.length ? [...new Set(same)].join(", ") : "없음", "key"], ["뒤집는 규칙", s.axis === "lr" ? "좌우가 바뀌고 글자 순서도 거꾸로" : "위아래가 바뀜"]]; },
  },
  {
    id: "job-pool-fill", grade: 12, unit: 3, lesson: "Ⅲ-5 탐구 & 융합", title: "이동식 풀장 — 부피와 물 채우는 시간", type: "3D", time: "10분",
    tags: ["부피", "들이", "단위 환산"], links: ["m1-prism-volume", "calc-cup"],
    desc: "원기둥·직육면체 모양 풀장의 크기와 물을 붓는 빠르기를 정해 부피(들이)와 가득 채우는 데 걸리는 시간을 계산하고, 물이 차오르는 모습을 봅니다.",
    obs: ["1 m³ = 1000 L입니다.", "부피 = 밑넓이 × 물의 높이이므로 밑넓이가 일정하면 물의 높이는 시간에 정비례합니다.", "밑면의 지름을 2배로 하면 들이는 4배, 채우는 시간도 4배가 됩니다."],
    q: "지름 3 m, 깊이 0.8 m인 원기둥 풀장을 분당 50 L로 채우면 몇 시간이 걸릴까요?",
    formula: "원기둥 V = πr²h · 직육면체 V = abh · 시간 = V ÷ (분당 채우는 양)",
    en: { title: "Filling a Portable Pool", desc: "Compute pool volume and filling time, and watch the water rise." },
    space: true, cam: { yaw: 30, pitch: 26, scale: 70 },
    params: [{ key: "shape", label: "모양", type: "seg", value: "cyl", options: [["cyl", "원기둥"], ["box", "직육면체"]] }, { key: "d", label: "지름 또는 가로 (m)", min: 1, max: 4, step: 0.5, value: 3 }, { key: "w", label: "세로 (m)", min: 1, max: 4, step: 0.5, value: 2, when: (s) => s.shape === "box" }, { key: "h", label: "깊이 (m)", min: 0.4, max: 1.2, step: 0.1, value: 0.8 }, { key: "q", label: "분당 채우는 양 (L)", min: 20, max: 200, step: 10, value: 50 }, { key: "t", label: "채운 정도", min: 0, max: 1, step: 0.01, value: 0.6, show: (v) => `${Math.round(v * 100)}%` }],
    anim: { key: "t", min: 0, max: 1, speed: 0.15, label: "물 채우기" },
    vol(s) { return s.shape === "cyl" ? Math.PI * (s.d / 2) ** 2 * s.h : s.d * s.w * s.h; },
    draw(s, g) {
      const k = 2.6 / Math.max(s.d, s.shape === "box" ? s.w : 0, 1.5), H = s.h * k * 1.6, z0 = -0.9, lvl = z0 + H * s.t, E = [1, 0, 0], F = [0, 1, 0];
      if (s.shape === "cyl") { const r = (s.d / 2) * k; g.circle([0, 0, z0], E, F, r, { color: "b", w: 2, fill: "b", fo: 0.1 }); g.circle([0, 0, z0 + H], E, F, r, { color: "b", w: 2 }); for (let i = 0; i < 12; i++) { const a = (i * Math.PI) / 6; g.seg([r * Math.cos(a), r * Math.sin(a), z0], [r * Math.cos(a), r * Math.sin(a), z0 + H], { color: "b", w: 1, opacity: 0.5 }); } if (s.t > 0) g.circle([0, 0, lvl], E, F, r * 0.99, { color: "c", w: 2, fill: "c", fo: 0.4, bias: 2 }); }
      else { const a = (s.d / 2) * k, b = (s.w / 2) * k, box = (z) => [[-a, -b, z], [a, -b, z], [a, b, z], [-a, b, z]]; g.face(box(z0), { fill: "b", color: "b", fo: 0.1 }); g.path([...box(z0 + H), box(z0 + H)[0]], { color: "b", w: 2 }); box(z0).forEach((p, i) => g.seg(p, box(z0 + H)[i], { color: "b", w: 1.4 })); if (s.t > 0) { g.face(box(lvl), { fill: "c", color: "c", fo: 0.4, bias: 2 }); } }
    },
    metrics(s) { const V = this.vol(s), L = V * 1000, min = L / s.q; return [["들이", `${fmt(V, 3)} m³ = ${fmt(L, 0)} L`], ["가득 채우는 시간", `${fmt(min, 0)}분 ≈ ${fmt(min / 60, 1)}시간`, "key"], ["지금 들어간 물", `${fmt(L * s.t, 0)} L · ${fmt(min * s.t, 0)}분 경과`]]; },
  },
  {
    id: "m1-copy-angle", grade: 1, unit: 5, lesson: "5.8 작도", title: "크기가 같은 각의 작도로 평행선 긋기", type: "조작", time: "10분",
    tags: ["작도", "크기가 같은 각", "평행선"], links: ["compass", "parallel-angles"],
    desc: "직선 밖의 한 점 P를 지나고 직선 l에 평행한 직선을, 크기가 같은 각(동위각)을 작도하는 순서대로 한 단계씩 그립니다.",
    obs: ["컴퍼스로 같은 반지름의 원호를 그리면 같은 길이를 옮길 수 있습니다.", "세 변의 길이가 같은 두 삼각형은 합동이므로 옮긴 각의 크기가 같습니다.", "동위각의 크기가 같으면 두 직선은 평행합니다."],
    q: "엇각을 이용해서도 같은 평행선을 작도할 수 있을까요?",
    formula: "동위각이 같다 ⇒ l ∥ m",
    en: { title: "Copying an Angle to Draw a Parallel", desc: "Construct a parallel line through P by copying a corresponding angle step by step." },
    view: V, points: { P: [0.6, 2.6] },
    params: [{ key: "step", label: "작도 단계", min: 0, max: 5, step: 1, value: 5 }],
    anim: { key: "step", min: 0, max: 5, speed: 0.8, label: "한 단계씩" },
    constrain(s, k, p) { return [clamp(p[0], -3, 4), clamp(p[1], 1.2, 4.2)]; },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const P = s.P, Q = [-2.6, -2.2], L = (x) => [x, -2.2];
      g.seg([-7, -2.2], [7, -2.2], { color: "ink", w: 2.4 }).text([6.8, -2.2], "l", { dy: -8, italic: true });
      const dir = norm(sub(P, Q)); g.line(Q, P, { color: "ink", w: 1.8 });
      const r = 1.6, A = add(Q, [r, 0]), B = add(Q, mul(dir, r)), C = add(P, mul(dir, r)), ab = dist(A, B);
      const ang = Math.atan2(dir[1], dir[0]);
      if (s.step >= 1) { g.param((t) => add(Q, [r * Math.cos(t), r * Math.sin(t)]), -0.2, ang + 0.3, { color: "b", w: 1.6 }); g.point(A, "A", { color: "b", r: 4, dy: 18 }).point(B, "B", { color: "b", r: 4 }); }
      if (s.step >= 2) { g.param((t) => add(P, [r * Math.cos(t), r * Math.sin(t)]), -0.3, ang + 0.3, { color: "c", w: 1.6 }); g.point(C, "C", { color: "c", r: 4 }); }
      const D = (() => { const Dp = add(P, [r, 0]); return Dp; })();
      if (s.step >= 3) { g.seg(A, B, { color: "e", w: 2.4, dash: "5 4" }); g.text(lerp(A, B, 0.5), "AB 길이", { dx: 10, anchor: "start", size: 12, color: "e", bold: true }); }
      if (s.step >= 4) { const a0 = Math.atan2(D[1] - C[1], D[0] - C[0]); g.param((t) => add(C, [ab * Math.cos(t), ab * Math.sin(t)]), a0 - 0.3, a0 + 0.3, { color: "e", w: 1.6 }); g.point(D, "D", { color: "e", r: 4 }); }
      if (s.step >= 5) { g.line(P, D, { color: "a", w: 3 }); g.text(add(P, [5.5, 0]), "m ∥ l", { dy: -8, color: "a", bold: true, size: 14 }); g.arc(Q, A, B, { r: 22, color: "d" }).arc(P, D, C, { r: 22, color: "d" }); }
      g.point(Q, "Q", { color: "ink", dy: 18 }).point(P, "P", { color: "a" }).handle(P, "P");
    },
    metrics(s) { const txt = ["직선 l과 그 밖의 점 P, P와 l 위의 점 Q를 이은 직선을 준비합니다.", "① Q를 중심으로 원호를 그려 두 변과 만나는 점 A, B를 찍습니다.", "② 같은 반지름으로 P를 중심으로 원호를 그려 C를 찍습니다.", "③ 컴퍼스로 AB의 길이를 잽니다.", "④ C를 중심으로 반지름 AB인 원호를 그려 D를 찍습니다.", "⑤ 직선 PD를 그으면 동위각이 같으므로 l과 평행합니다."][s.step]; return [["단계", `${s.step}단계 (모두 5단계)`], txt]; },
  },
  {
    id: "geo-space-dot", grade: 6, unit: 3, lesson: "Ⅲ-5 공간벡터", title: "공간벡터의 내적과 사잇각", type: "3D", time: "10분",
    tags: ["공간벡터", "내적", "수직 판정"], links: ["geo-dot-product", "geo-plane-angle"],
    desc: "좌표공간의 두 벡터의 성분을 바꾸며 내적 a₁b₁ + a₂b₂ + a₃b₃와 사잇각, a 방향으로 내린 b의 정사영을 확인하고 두 벡터가 수직이 되는 조건을 찾습니다.",
    obs: ["공간벡터의 내적도 성분끼리 곱해 더합니다.", "내적이 0이면 두 벡터는 수직입니다.", "|b| cos θ는 b를 a 방향으로 정사영한 길이입니다."],
    q: "a = (1, 2, 2)와 수직인 벡터를 하나 찾아보세요.",
    formula: "a · b = a₁b₁ + a₂b₂ + a₃b₃ = |a||b| cos θ",
    en: { title: "Dot Product in Space", desc: "Change components of two 3D vectors and read their dot product and angle." },
    space: true, cam: { yaw: 36, pitch: 22, scale: 44 },
    params: [{ key: "head", label: "벡터 a", type: "head" }, { key: "a1", label: "a₁", min: -3, max: 3, step: 1, value: 2 }, { key: "a2", label: "a₂", min: -3, max: 3, step: 1, value: 1 }, { key: "a3", label: "a₃", min: -3, max: 3, step: 1, value: 2 }, { key: "head2", label: "벡터 b", type: "head" }, { key: "b1", label: "b₁", min: -3, max: 3, step: 1, value: 0 }, { key: "b2", label: "b₂", min: -3, max: 3, step: 1, value: 3 }, { key: "b3", label: "b₃", min: -3, max: 3, step: 1, value: 1 }],
    draw(s, g) {
      g.floor(4); g.axes(4);
      const a = [s.a1, s.a2, s.a3], b = [s.b1, s.b2, s.b3];
      if (len(a) > 0) { const u = norm(a), P = mul(u, dot(b, u)); g.seg(b, P, { color: "muted", w: 1.4, dash: "4 4" }); g.seg([0, 0, 0], P, { color: dot(a, b) >= 0 ? "c" : "d", w: 5, opacity: 0.6 }); }
      g.vec([0, 0, 0], a, { color: "a", w: 3.4, label: "a" }).vec([0, 0, 0], b, { color: "b", w: 3.4, label: "b" });
    },
    metrics(s) { const a = [s.a1, s.a2, s.a3], b = [s.b1, s.b2, s.b3], d = dot(a, b); if (!len(a) || !len(b)) return ["영벡터가 아닌 두 벡터를 만들어 주세요."]; return [["a · b", `${s.a1}·${s.b1} + ${s.a2}·${s.b2} + ${s.a3}·${s.b3} = ${d}`, "key"], ["|a| · |b|", `${surd(dot(a, a))} · ${surd(dot(b, b))}`], ["사잇각", `${fmt(rad2deg(Math.acos(clamp(d / (len(a) * len(b)), -1, 1))), 2)}°${d === 0 ? " (수직)" : ""}`]]; },
  },
  {
    id: "calc1-tangent-from-point", grade: 7, unit: 2, lesson: "Ⅱ-3 예제", title: "곡선 밖의 점에서 그은 접선", type: "조작", time: "10분",
    tags: ["접선의 방정식", "접점", "판별식"], links: ["calc-secant-tangent", "c2-tangent"],
    desc: "곡선 y = x² 밖의 점 P에서 곡선에 그은 접선을, 접점을 (t, t²)로 두고 접선이 P를 지나는 조건을 풀어 구합니다. P가 곡선 위쪽에 있으면 접선을 그을 수 없습니다.",
    obs: ["접점 (t, t²)에서의 접선은 y = 2t(x − t) + t²입니다.", "이 직선이 P(a, b)를 지나야 하므로 t² − 2at + b = 0을 풉니다.", "P가 곡선 아래쪽이면 접선이 2개, 곡선 위의 점이면 1개, 위쪽이면 0개입니다."],
    q: "점 (1, −3)에서 곡선 y = x²에 그은 두 접선의 기울기의 곱은 얼마일까요?",
    formula: "접선 y = 2t(x − t) + t² 가 P(a, b)를 지남 ⇔ t² − 2at + b = 0",
    en: { title: "Tangents from an External Point", desc: "Solve for the contact points of tangents from P to y = x²." },
    view: { x: [-5, 5], y: [-4.5, 7] }, points: { P: [1, -3] },
    ts(s) { const [a, b] = s.P, D = a * a - b; if (D < -1e-9) return []; if (Math.abs(D) < 1e-9) return [a]; return [a - Math.sqrt(D), a + Math.sqrt(D)]; },
    draw(s, g) {
      g.grid();
      g.fx((x) => x * x, { color: "a", w: 3.2 });
      this.ts(s).forEach((t, i) => { g.line([t, t * t], [t + 1, t * t + 2 * t], { color: COLS[i + 1], w: 2.4 }); g.point([t, t * t], `t = ${fmt(t, 2)}`, { color: COLS[i + 1], r: 5 }); });
      g.point(s.P, "P", { color: "ink", r: 6 }).handle(s.P, "P");
    },
    metrics(s) { const T = this.ts(s), [a, b] = s.P; return [["t² − 2at + b = 0", `t² − ${fmt(2 * a)}t + ${fmt(b)} = 0`.replace("+ −", "− ").replace("− −", "+ ")], ["접선의 수", `${T.length}개`, "key"], ["접선", T.length ? T.map((t) => `y = ${fmt(2 * t, 2)}x ${-t * t >= 0 ? "+" : "−"} ${fmt(Math.abs(t * t), 2)}`).join(" , ") : "없음 (P가 곡선 위쪽)"]]; },
  },
  {
    id: "pst-binomial-area", grade: 8, unit: 1, lesson: "Ⅰ-4 탐구", title: "이항정리의 넓이 모형 (a + b)²과 (a + b + c)²", type: "조작", time: "8분",
    tags: ["전개", "넓이 모형", "이항계수"], links: ["pst-pascal", "pst-binomial-cube"],
    desc: "한 변이 a + b인 정사각형을 a², ab, ab, b² 조각으로 나누어 (a + b)² = a² + 2ab + b²을 넓이로 확인하고, 세 조각으로 나누면 (a + b + c)²도 같은 방식으로 전개됩니다.",
    obs: ["같은 모양의 직사각형 ab가 2개 생기는 것이 계수 2의 이유입니다.", "계수 1, 2, 1은 파스칼 삼각형의 둘째 줄입니다.", "(a + b + c)²은 정사각형 3개와 직사각형 6개로 나뉩니다."],
    q: "(a − b)²의 공식도 넓이 그림으로 설명할 수 있을까요?",
    formula: "(a + b)² = a² + 2ab + b² · (a + b + c)² = a² + b² + c² + 2ab + 2bc + 2ca",
    en: { title: "Area Model of the Binomial Expansion", desc: "Split an (a + b) square into pieces to see the expansion." },
    view: { x: [-0.6, 12], y: [-0.6, 8.6] },
    params: [{ key: "three", label: "항의 수", type: "seg", value: 2, options: [[2, "(a + b)²"], [3, "(a + b + c)²"]] }, { key: "a", label: "a", min: 1, max: 5, step: 0.5, value: 4 }, { key: "b", label: "b", min: 1, max: 4, step: 0.5, value: 2.5 }, { key: "c", label: "c", min: 0.5, max: 3, step: 0.5, value: 1.5, when: (s) => s.three === 3 }],
    draw(s, g) {
      const parts = s.three === 3 ? [["a", s.a], ["b", s.b], ["c", s.c]] : [["a", s.a], ["b", s.b]], T = parts.reduce((x, p) => x + p[1], 0), k = 7.8 / T;
      let y = 0; parts.forEach(([ny, vy], i) => { let x = 0; parts.forEach(([nx, vx], j) => { const same = i === j, col = same ? COLS[i] : "f"; g.poly([[x * k, y * k], [(x + vx) * k, y * k], [(x + vx) * k, (y + vy) * k], [x * k, (y + vy) * k]], { fill: col, fo: same ? 0.45 : 0.25, color: "ink", w: 1.4 }); g.text([(x + vx / 2) * k, (y + vy / 2) * k], same ? `${nx}²` : `${nx < ny ? nx + ny : ny + nx}`, { dy: 5, size: 15, bold: true }); x += vx; }); y += vy; });
      parts.reduce((x, [n, v]) => { g.text([(x + v / 2) * k, T * k], n, { dy: -6, size: 14, italic: true, color: "muted" }); return x + v; }, 0);
    },
    metrics(s) { const a = s.a, b = s.b, c = s.three === 3 ? s.c : 0; const T = a + b + c; return s.three === 3 ? [["(a + b + c)²", fmt(T * T, 2)], ["a² + b² + c² + 2ab + 2bc + 2ca", fmt(a * a + b * b + c * c + 2 * a * b + 2 * b * c + 2 * c * a, 2), "key"]] : [["(a + b)²", fmt(T * T, 2)], ["a² + 2ab + b²", `${fmt(a * a, 2)} + ${fmt(2 * a * b, 2)} + ${fmt(b * b, 2)} = ${fmt(a * a + 2 * a * b + b * b, 2)}`, "key"]]; },
  },
  {
    id: "pst-binomial-cube", grade: 8, unit: 1, lesson: "Ⅰ-4 탐구", title: "이항정리의 부피 모형 (a + b)³", type: "3D", time: "10분",
    tags: ["전개", "부피 모형", "계수 1, 3, 3, 1"], links: ["pst-binomial-area", "pst-pascal"],
    desc: "한 모서리가 a + b인 정육면체를 a³, a²b 3개, ab² 3개, b³으로 나누어 (a + b)³ = a³ + 3a²b + 3ab² + b³을 부피로 확인합니다. 조각을 벌려 개수를 세어 봅니다.",
    obs: ["a²b 모양의 조각이 3개, ab² 모양의 조각이 3개 있습니다.", "계수 1, 3, 3, 1은 파스칼 삼각형의 셋째 줄입니다.", "조각을 벌려도 전체 부피는 그대로입니다."],
    q: "(a + b)⁴은 4차원 ‘초정육면체’의 조각으로 생각할 수 있습니다. 계수는 무엇일까요?",
    formula: "(a + b)³ = a³ + 3a²b + 3ab² + b³",
    en: { title: "Volume Model of (a + b)³", desc: "Split an (a + b) cube into eight blocks to see coefficients 1, 3, 3, 1." },
    space: true, cam: { yaw: 36, pitch: 24, scale: 50 },
    params: [{ key: "a", label: "a", min: 1, max: 3, step: 0.25, value: 2 }, { key: "b", label: "b", min: 0.5, max: 2, step: 0.25, value: 1 }, { key: "gap", label: "조각 벌리기", min: 0, max: 1, step: 0.05, value: 0.5 }],
    anim: { key: "gap", min: 0, max: 1, speed: 0.5, label: "벌렸다 모으기" },
    draw(s, g) {
      const L = [s.a, s.b], O = -(s.a + s.b) / 2;
      for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) for (let k = 0; k < 2; k++) {
        const nb = i + j + k, col = ["a", "c", "e", "b"][nb], x0 = O + (i ? s.a : 0) + i * s.gap, y0 = O + (j ? s.a : 0) + j * s.gap, z0 = O + (k ? s.a : 0) + k * s.gap, dx = L[i], dy = L[j], dz = L[k];
        const P = (u, v, w) => [x0 + u * dx, y0 + v * dy, z0 + w * dz];
        [[P(0, 0, 0), P(1, 0, 0), P(1, 1, 0), P(0, 1, 0)], [P(0, 0, 1), P(1, 0, 1), P(1, 1, 1), P(0, 1, 1)], [P(0, 0, 0), P(1, 0, 0), P(1, 0, 1), P(0, 0, 1)], [P(0, 1, 0), P(1, 1, 0), P(1, 1, 1), P(0, 1, 1)], [P(0, 0, 0), P(0, 1, 0), P(0, 1, 1), P(0, 0, 1)], [P(1, 0, 0), P(1, 1, 0), P(1, 1, 1), P(1, 0, 1)]].forEach((f) => g.face(f, { fill: col, color: "ink", fo: 0.5, w: 0.8 }));
      }
      g.note(20, 30, "빨강 a³ · 초록 a²b ×3 · 보라 ab² ×3 · 파랑 b³", { color: "ink", bold: true });
    },
    metrics(s) { const a = s.a, b = s.b; return [["(a + b)³", fmt((a + b) ** 3, 3)], ["a³ + 3a²b + 3ab² + b³", `${fmt(a ** 3, 2)} + ${fmt(3 * a * a * b, 2)} + ${fmt(3 * a * b * b, 2)} + ${fmt(b ** 3, 2)}`, "key"]]; },
  },
];
