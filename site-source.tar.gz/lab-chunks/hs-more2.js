// 교과서 '공학 도구·탐구' 활동을 다시 훑어 추가한 실험
import { fmt, frac, surd, dist, sub, add, mul, norm, dot, len, cross, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const V = { x: [-7, 7], y: [-5, 5] };
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const COLS = ["a", "b", "c", "e", "f", "d"];
let seed = 23;
const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-12)) * Math.cos(2 * Math.PI * rnd());
const BLOBS = [[-3.5, 2], [3, 2.5], [0.5, -2.8], [-4, -2.6], [4.2, -1.6]].flatMap((c, i) => Array.from({ length: 16 }, () => [c[0] + 0.95 * gauss(), c[1] + 0.8 * gauss()])).filter((p) => Math.abs(p[0]) < 6.8 && Math.abs(p[1]) < 4.8);
const IMG = ["000000000000", "000111111000", "001000000100", "010011001010", "010011001010", "010000000010", "010100001010", "010011110010", "001000000100", "000111111000", "000000000000", "000000000000"].map((r) => [...r].map(Number));
const FILTERS = {
  blur: { name: "흐리게 (평균)", k: [[1, 1, 1], [1, 1, 1], [1, 1, 1]], div: 9 },
  gauss: { name: "부드럽게 (가우시안)", k: [[1, 2, 1], [2, 4, 2], [1, 2, 1]], div: 16 },
  vert: { name: "세로 경계 찾기", k: [[-1, 0, 1], [-1, 0, 1], [-1, 0, 1]], div: 1 },
  horz: { name: "가로 경계 찾기", k: [[-1, -1, -1], [0, 0, 0], [1, 1, 1]], div: 1 },
  sharp: { name: "선명하게", k: [[0, -1, 0], [-1, 5, -1], [0, -1, 0]], div: 1 },
};
const conv = (fk, i, j) => { const F = FILTERS[fk]; let s = 0; for (let a = -1; a <= 1; a++) for (let b = -1; b <= 1; b++) { const v = IMG[i + a]?.[j + b] ?? 0; s += v * F.k[a + 1][b + 1]; } return s / F.div; };

export default [
  {
    id: "geo-conic-construct", grade: 6, unit: 1, lesson: "Ⅰ 공학 도구", title: "동심원으로 이차곡선 작도하기", type: "조작", time: "12분",
    tags: ["작도", "동심원", "자취"], links: ["geo-ellipse", "geo-hyperbola", "geo-parabola"],
    desc: "두 초점을 중심으로 하는 동심원들을 그리고 반지름의 합(또는 차)이 일정한 두 원의 교점을 하나씩 찍어 타원·쌍곡선을, 동심원과 평행선의 교점으로 포물선을 작도합니다.",
    obs: ["타원: 반지름이 r인 원과 2a − r인 원의 교점은 PF + PF′ = 2a를 만족합니다.", "쌍곡선: 반지름이 r인 원과 r + 2a인 원의 교점은 |PF − PF′| = 2a를 만족합니다.", "포물선: 초점을 중심으로 하는 반지름 r인 원과 준선에서 r만큼 떨어진 평행선의 교점을 잇습니다."],
    q: "교점을 더 촘촘히 찍으려면 동심원의 간격을 어떻게 해야 할까요?",
    formula: "PF + PF′ = 2a · |PF − PF′| = 2a · PF = PH",
    en: { title: "Constructing Conics with Concentric Circles", desc: "Intersect concentric circles to plot ellipses, hyperbolas and parabolas point by point." },
    view: V,
    params: [{ key: "kind", label: "곡선", type: "seg", value: "ell", options: [["ell", "타원"], ["hyp", "쌍곡선"], ["par", "포물선"]] }, { key: "a", label: "2a (거리의 합 또는 차)", min: 2, max: 10, step: 0.5, value: 8 }, { key: "k", label: "그린 원의 쌍", min: 0, max: 24, step: 1, value: 12 }],
    anim: { key: "k", min: 0, max: 24, speed: 4, label: "하나씩 작도" },
    derive(s) { if (s.kind === "ell" && s.a < 6.5) s.a = 6.5; if (s.kind === "hyp" && s.a > 5.5) s.a = 5.5; },
    pts(s) {
      const F1 = [-3, 0], F2 = [3, 0], out = [];
      if (s.kind === "par") { for (let i = 1; i <= 24; i++) { const r = 0.4 * i, y = -1.5 + r, dx2 = r * r - (y - 1.5) ** 2; if (dx2 >= 0) out.push({ r, pts: [[Math.sqrt(dx2), y], [-Math.sqrt(dx2), y]] }); else out.push({ r, pts: [] }); } return out; }
      for (let i = 1; i <= 24; i++) {
        const r1 = s.kind === "ell" ? (s.a / 2 - 3) + ((i - 0.5) / 24) * 6 : 0.3 + i * 0.4, r2 = s.kind === "ell" ? s.a - r1 : r1 + s.a;
        const x = (r1 * r1 - r2 * r2) / 12, h2 = r1 * r1 - (x + 3) ** 2;
        const P = h2 >= 0 ? [[x, Math.sqrt(h2)], [x, -Math.sqrt(h2)]] : [];
        if (s.kind === "hyp") P.push(...P.map((p) => [-p[0], p[1]]));
        out.push({ r: r1, r2, pts: P });
      }
      return out;
    },
    draw(s, g) {
      g.grid({ labels: false });
      const F1 = [-3, 0], F2 = [3, 0], L = this.pts(s);
      if (s.kind === "par") { g.seg([-7, -1.5], [7, -1.5], { color: "ink", w: 2.2 }).text([6.8, -1.5], "준선", { dy: 18, anchor: "end", size: 12 }); for (let i = 1; i <= 24; i++) { g.circle([0, 1.5], 0.4 * i, { color: "grid", w: 1 }); g.seg([-7, -1.5 + 0.4 * i], [7, -1.5 + 0.4 * i], { color: "grid", w: 1 }); } }
      else for (let i = 1; i <= 24; i++) { g.circle(F1, 0.4 * i, { color: "grid", w: 1 }); g.circle(F2, 0.4 * i, { color: "grid", w: 1 }); }
      L.slice(0, s.k).forEach((o, i) => { o.pts.forEach((p) => g.point(p, "", { color: "a", r: 4 })); if (i === s.k - 1) { if (s.kind === "par") { g.circle([0, 1.5], o.r, { color: "b", w: 2 }); g.seg([-7, -1.5 + o.r], [7, -1.5 + o.r], { color: "e", w: 2 }); } else { g.circle(F1, o.r, { color: "b", w: 2 }); g.circle(F2, o.r2, { color: "e", w: 2 }); } } });
      if (s.kind === "par") g.point([0, 1.5], "F", { color: "ink" }); else g.point(F1, "F′", { color: "ink", dy: 20 }).point(F2, "F", { color: "ink", dy: 20 });
    },
    metrics(s) { const L = this.pts(s), cur = L[Math.max(0, s.k - 1)]; const n = L.slice(0, s.k).reduce((a, o) => a + o.pts.length, 0); return s.kind === "par" ? [["찍은 점", `${n}개`], ["마지막 원의 반지름 = 평행선까지 거리", fmt(cur.r, 2), "key"]] : [["찍은 점", `${n}개`], [s.kind === "ell" ? "r₁ + r₂" : "|r₁ − r₂|", `${fmt(cur.r, 2)} ${s.kind === "ell" ? "+" : "와"} ${fmt(cur.r2, 2)} → ${fmt(s.a)}`, "key"]]; },
  },
  {
    id: "geo-conic-family", grade: 6, unit: 1, lesson: "Ⅰ-4 공학 도구", title: "계수 하나로 바뀌는 이차곡선 Ax² + y² + 4x = 0", type: "조작", time: "8분",
    tags: ["이차곡선의 분류", "계수", "완전제곱식"], links: ["geo-conic-shift", "geo-conic-section"],
    desc: "방정식 Ax² + y² + 4x = 0에서 x²의 계수 A만 바꾸며 곡선이 쌍곡선 → 포물선 → 타원 → 원으로 바뀌는 과정을 보고, 완전제곱식으로 표준형을 만들어 확인합니다.",
    obs: ["A < 0이면 x², y²의 계수 부호가 달라 쌍곡선입니다.", "A = 0이면 y² = −4x로 포물선입니다.", "A > 0이면 타원이고, A = 1이면 원입니다."],
    q: "A가 0에 아주 가까운 양수일 때 타원은 어떤 모양일까요?",
    formula: "A(x + 2/A)² + y² = 4/A (A ≠ 0) · A = 0 ⇒ y² = −4x",
    en: { title: "One Coefficient, Many Conics", desc: "Vary A in Ax² + y² + 4x = 0 to morph hyperbola, parabola, ellipse and circle." },
    view: { x: [-11.5, 3.5], y: [-5.5, 5.5] },
    params: [{ key: "A", label: "A", min: -2, max: 2, step: 0.05, value: 0.4 }],
    anim: { key: "A", min: -2, max: 2, speed: 0.6, label: "A 바꾸기" },
    draw(s, g) {
      g.grid();
      const A = s.A, f = (x) => Math.sqrt(-A * x * x - 4 * x);
      [1, -1].forEach((sg) => g.fx((x) => { const v = -A * x * x - 4 * x; return v < 0 ? NaN : sg * Math.sqrt(v); }, { color: "a", w: 3.2, n: 1600 }));
      if (A > 1e-9) g.point([-2 / A, 0], "중심", { color: "ink", r: 4 });
    },
    metrics(s) { const A = s.A; if (Math.abs(A) < 1e-9) return [["종류", "포물선", "key"], ["표준형", "y² = −4x"]]; const kind = A < 0 ? "쌍곡선" : Math.abs(A - 1) < 1e-9 ? "원" : "타원"; return [["종류", kind, "key"], ["표준형", `${fmt(A, 2)}(x + ${fmt(2 / A, 2)})² + y² = ${fmt(4 / A, 2)}`]]; },
  },
  {
    id: "geo-shortest-surface", grade: 6, unit: 2, lesson: "Ⅱ 충전소", title: "직육면체 겉면을 따라가는 최단 경로", type: "3D", time: "12분",
    tags: ["전개도", "최단 거리", "공간도형"], links: ["net-fold", "c2-shortest"],
    desc: "직육면체의 한 꼭짓점에서 맞은편 꼭짓점까지 겉면을 따라가는 세 가지 경로를 전개도로 펼쳐 길이를 비교하고, 가장 짧은 경로를 입체 위에 그립니다.",
    obs: ["겉면 위의 최단 경로는 두 면을 펼친 전개도에서 선분이 됩니다.", "펼치는 방법이 세 가지이므로 길이 후보도 세 개입니다.", "가장 긴 모서리를 두 면이 나누어 갖도록 펼친 경로가 가장 짧습니다."],
    q: "정육면체에서는 세 경로의 길이가 어떻게 될까요?",
    formula: "√((a + b)² + c²) · √((b + c)² + a²) · √((a + c)² + b²) 중 최솟값",
    en: { title: "Shortest Path on a Box Surface", desc: "Unfold two faces three ways and compare the path lengths." },
    space: true, cam: { yaw: -48, pitch: 26, scale: 58 },
    params: [{ key: "a", label: "가로 a", min: 1, max: 4, step: 0.5, value: 3 }, { key: "b", label: "세로 b", min: 1, max: 4, step: 0.5, value: 2 }, { key: "c", label: "높이 c", min: 1, max: 4, step: 0.5, value: 1.5 }, { key: "route", label: "강조할 경로", type: "seg", value: "best", options: [["best", "가장 짧은 것"], ["1", "경로 ①"], ["2", "경로 ②"], ["3", "경로 ③"]] }],
    routes(s) { const { a, b, c } = s; return [{ L: Math.hypot(a + b, c), P: [[0, 0, 0], [a, 0, (c * a) / (a + b)], [a, b, c]] }, { L: Math.hypot(b + c, a), P: [[0, 0, 0], [(a * c) / (b + c), 0, c], [a, b, c]] }, { L: Math.hypot(a + c, b), P: [[0, 0, 0], [a, (b * a) / (a + c), 0], [a, b, c]] }]; },
    draw(s, g) {
      const { a, b, c } = s, o = [-a / 2, -b / 2, -c / 2], T = (p) => add(p, o), Vx = [[0, 0, 0], [a, 0, 0], [a, b, 0], [0, b, 0], [0, 0, c], [a, 0, c], [a, b, c], [0, b, c]].map(T);
      [[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4], [1, 2, 6, 5], [2, 3, 7, 6], [3, 0, 4, 7]].forEach((f) => g.face(f.map((i) => Vx[i]), { fill: "f", color: "ink", fo: 0.12, w: 1.2 }));
      const R = this.routes(s), best = R.reduce((m, r, i) => (r.L < R[m].L ? i : m), 0), pick = s.route === "best" ? best : +s.route - 1;
      R.forEach((r, i) => g.path(r.P.map(T), { color: COLS[i], w: i === pick ? 4 : 1.6, opacity: i === pick ? 1 : 0.5, dash: i === pick ? null : "5 4", bias: 2 }));
      g.point(T([0, 0, 0]), "A", { color: "ink" }).point(T([a, b, c]), "G", { color: "ink" });
    },
    metrics(s) { const R = this.routes(s), best = R.reduce((m, r, i) => (r.L < R[m].L ? i : m), 0); return [["경로 ①", fmt(R[0].L, 3)], ["경로 ②", fmt(R[1].L, 3)], ["경로 ③", fmt(R[2].L, 3)], ["최단 경로", `경로 ${"①②③"[best]} · ${fmt(R[best].L, 3)}`, "key"]]; },
  },
  {
    id: "geo-lidar", grade: 6, unit: 4, lesson: "Ⅳ 프로젝트", title: "가상 라이다로 숨은 구 찾기", type: "3D", time: "12분",
    tags: ["라이다", "직선과 구", "방향벡터"], links: ["geo-sphere-eq", "geo-space-line"],
    desc: "원점에서 방향벡터를 따라 레이저(직선)를 쏘아 숨겨진 구와 만나는지 판정하고, 만나는 점까지의 거리를 계산해 자율주행차의 라이다 원리를 체험합니다.",
    obs: ["직선 p = tu를 구의 방정식에 넣으면 t에 대한 이차방정식이 됩니다.", "판별식이 0 이상이면 레이저가 구에 닿습니다.", "가장 작은 양의 t가 처음 닿는 점까지의 거리입니다(|u| = 1일 때)."],
    q: "레이저가 구에 닿지 않을 때 가장 가까이 지나간 거리는 어떻게 구할까요?",
    formula: "|tu − c|² = r² ⇒ t² − 2(u · c)t + |c|² − r² = 0",
    en: { title: "Virtual LiDAR", desc: "Shoot a laser line from the origin and test whether it hits a hidden sphere." },
    space: true, cam: { yaw: 30, pitch: 22, scale: 40 },
    params: [{ key: "az", label: "레이저 방향 (가로 각)", min: -180, max: 180, step: 1, value: 42, unit: "°" }, { key: "el", label: "레이저 방향 (세로 각)", min: -60, max: 80, step: 1, value: 18, unit: "°" }, { key: "show", label: "숨은 구 보이기", type: "check", value: true }, { key: "cx", label: "구의 중심 x", min: -4, max: 4, step: 1, value: 3 }, { key: "cy", label: "구의 중심 y", min: -4, max: 4, step: 1, value: 3 }, { key: "cz", label: "구의 중심 z", min: 0, max: 4, step: 1, value: 2 }, { key: "r", label: "구의 반지름", min: 0.5, max: 2.5, step: 0.5, value: 1.5 }],
    anim: { key: "az", min: -180, max: 180, speed: 30, loop: "wrap", label: "레이저 돌리기" },
    hit(s) { const u = [Math.cos(deg(s.el)) * Math.cos(deg(s.az)), Math.cos(deg(s.el)) * Math.sin(deg(s.az)), Math.sin(deg(s.el))], c = [s.cx, s.cy, s.cz], b = dot(u, c), D = b * b - (dot(c, c) - s.r * s.r); const t = D >= 0 ? b - Math.sqrt(D) : NaN; return { u, c, D, t: t > 0 ? t : NaN, near: Math.sqrt(Math.max(0, dot(c, c) - b * b)) }; },
    draw(s, g) {
      g.floor(5); g.axes(5);
      const H = this.hit(s);
      if (s.show) g.sphere(H.c, s.r, { color: "b" });
      const end = Number.isFinite(H.t) ? mul(H.u, H.t) : mul(H.u, 9);
      g.seg([0, 0, 0], end, { color: "d", w: 3, bias: 3 });
      if (Number.isFinite(H.t)) g.point(end, "반사점", { color: "d", r: 6, bias: 4, dy: -14 });
      g.point([0, 0, 0], "라이다", { color: "ink", dx: -50, dy: 22 });
    },
    metrics(s) { const H = this.hit(s); return [["판별식 D/4", fmt(H.D, 3)], ["결과", Number.isFinite(H.t) ? `닿음 · 거리 ${fmt(H.t, 3)}` : "닿지 않음", "key"], ["구 중심과 레이저 사이 거리", fmt(H.near, 3)]]; },
  },
  {
    id: "calc1-bisection", grade: 7, unit: 1, lesson: "Ⅰ-3 탐구", title: "이분법으로 방정식의 근 찾기", type: "조작", time: "10분",
    tags: ["사잇값 정리", "이분법", "근삿값"], links: ["calc1-continuity"],
    desc: "f(a)와 f(b)의 부호가 다른 구간을 반으로 나누어 부호가 바뀌는 쪽을 남기는 과정을 되풀이하며 방정식 x³ − 2x − 2 = 0의 근을 좁혀 갑니다.",
    obs: ["구간의 가운데 m에서 f(m)의 부호를 보고 근이 있는 쪽 절반만 남깁니다.", "한 번 나눌 때마다 구간의 길이가 절반이 됩니다.", "10번 나누면 구간의 길이는 처음의 1/1024이 됩니다."],
    q: "근을 소수 셋째 자리까지 정확히 구하려면 몇 번 나누어야 할까요?",
    formula: "구간의 길이 = (b − a)/2ⁿ",
    en: { title: "Bisection Method", desc: "Halve the interval where the sign changes to trap a root." },
    view: { x: [-0.4, 2.6], y: [-3.6, 3.2] },
    params: [{ key: "n", label: "나눈 횟수 n", min: 0, max: 14, step: 1, value: 4 }],
    anim: { key: "n", min: 0, max: 14, speed: 1.5, label: "한 번씩 나누기" },
    f: (x) => x ** 3 - 2 * x - 2,
    steps(s) { let a = 1, b = 2; const out = [[a, b]]; for (let i = 0; i < s.n; i++) { const m = (a + b) / 2; if (this.f(a) * this.f(m) <= 0) b = m; else a = m; out.push([a, b]); } return out; },
    draw(s, g) {
      g.grid({ every: 1 });
      g.fx(this.f, { color: "a", w: 3 });
      this.steps(s).forEach(([a, b], i, arr) => { const y = -3.3 + (i * 2.6) / Math.max(arr.length, 6); g.seg([a, y], [b, y], { color: COLS[i % 6], w: 3.4 }); });
      const [a, b] = this.steps(s).pop();
      g.seg([a, 0], [a, this.f(a)], { color: "c", w: 1.4, dash: "4 4" }).seg([b, 0], [b, this.f(b)], { color: "c", w: 1.4, dash: "4 4" });
      g.point([(a + b) / 2, 0], "", { color: "d", r: 5 });
    },
    metrics(s) { const [a, b] = this.steps(s).pop(); return [["지금 구간", `[${fmt(a, 6)}, ${fmt(b, 6)}]`], ["구간의 길이", `1/2^${s.n} = ${fmt(b - a, 6)}`], ["근의 근삿값", fmt((a + b) / 2, 6), "key"]]; },
  },
  {
    id: "ai-kmeans", grade: 10, unit: 1, lesson: "Ⅰ 탐구", title: "비슷한 데이터끼리 묶기 — k-평균 군집화", type: "조작", time: "12분",
    tags: ["군집화", "무게중심", "거리"], links: ["ai-knn", "c2-centroid"],
    desc: "점들을 가장 가까운 중심에 배정하고, 각 무리의 무게중심으로 중심을 옮기는 두 단계를 되풀이하며 비지도학습이 데이터를 k개의 무리로 나누는 과정을 봅니다.",
    obs: ["① 배정: 각 점을 가장 가까운 중심의 무리에 넣습니다.", "② 이동: 각 중심을 자기 무리의 평균(무게중심) 위치로 옮깁니다.", "중심이 더 움직이지 않으면 멈춥니다. 처음 중심에 따라 결과가 달라질 수 있습니다."],
    q: "k를 실제 무리의 수보다 크게 정하면 어떤 일이 생길까요?",
    formula: "새 중심 = (그 무리 점들의 좌표의 합) / (점의 개수)",
    en: { title: "k-Means Clustering", desc: "Assign points to the nearest center and move centers to cluster means, repeatedly." },
    view: V,
    params: [{ key: "k", label: "무리의 수 k", min: 2, max: 5, step: 1, value: 3 }],
    init: () => ({ cents: [], iter: 0 }),
    reset(s) { s.cents = Array.from({ length: s.k }, () => [-6 + Math.random() * 12, -4 + Math.random() * 8]); s.iter = 0; },
    prefill(s) { this.reset(s); },
    onChange(s, key) { if (key === "k") this.reset(s); },
    assign(s) { return BLOBS.map((p) => s.cents.reduce((m, c, i) => (dist(p, c) < dist(p, s.cents[m]) ? i : m), 0)); },
    step(s) { const A = this.assign(s); s.cents = s.cents.map((c, i) => { const P = BLOBS.filter((_, j) => A[j] === i); return P.length ? mul(P.reduce((u, p) => add(u, p), [0, 0]), 1 / P.length) : c; }); s.iter++; },
    buttons: [["one", "한 단계 진행"], ["new", "중심 새로 뽑기"]],
    onDo(k, s) { if (k === "one") this.step(s); if (k === "new") this.reset(s); },
    anim: { label: "끝까지 진행", step(s, dt, sp) { sp._acc = (sp._acc || 0) + dt; if (sp._acc > 0.5) { sp._acc = 0; sp.step(s); } } },
    draw(s, g) {
      g.grid({ labels: false });
      const A = this.assign(s);
      BLOBS.forEach((p, j) => { g.seg(p, s.cents[A[j]], { color: COLS[A[j]], w: 0.8, opacity: 0.35 }); g.circle(p, 0.12, { color: COLS[A[j]], fill: COLS[A[j]], fo: 0.85, w: 1, layer: "point" }); });
      s.cents.forEach((c, i) => { g.poly([add(c, [-0.3, -0.3]), add(c, [0.3, -0.3]), add(c, [0.3, 0.3]), add(c, [-0.3, 0.3])], { fill: COLS[i], fo: 1, color: "ink", w: 2, layer: "top" }); });
    },
    metrics(s) { const A = this.assign(s); const sse = BLOBS.reduce((t, p, j) => t + dist(p, s.cents[A[j]]) ** 2, 0); return [["진행한 단계", String(s.iter)], ["무리별 점 수", s.cents.map((_, i) => A.filter((x) => x === i).length).join(" · ")], ["거리 제곱의 합", fmt(sse, 2), "key"]]; },
  },
  {
    id: "ai-convolution", grade: 10, unit: 2, lesson: "Ⅲ-2 탐구", title: "이미지 필터 — 합성곱으로 흐리게·경계 찾기", type: "조작", time: "12분",
    tags: ["합성곱", "필터", "이미지 행렬"], links: ["ai-image-transform"],
    desc: "0과 1로 된 픽셀 행렬 위에 3×3 필터를 한 칸씩 옮기며 겹친 값끼리 곱해 더하는 합성곱을 계산하고, 필터에 따라 이미지가 흐려지거나 경계만 남는 모습을 봅니다.",
    obs: ["합성곱은 겹친 칸의 값끼리 곱한 뒤 모두 더합니다.", "평균 필터는 주변 값을 섞어 이미지를 흐리게 합니다.", "경계 필터는 값이 바뀌는 곳에서만 큰 값을 냅니다."],
    q: "가로 경계 필터를 세로 줄무늬 이미지에 쓰면 결과는 어떻게 될까요?",
    formula: "출력(i, j) = Σ 입력(i + a, j + b) × 필터(a, b)",
    en: { title: "Image Filters by Convolution", desc: "Slide a 3×3 filter across a pixel matrix to blur or detect edges." },
    view: BOX,
    params: [{ key: "f", label: "필터", type: "select", value: "vert", options: Object.entries(FILTERS).map(([k, v]) => [k, v.name]) }, { key: "pos", label: "필터 위치 (칸 번호)", min: 1, max: 144, step: 1, value: 40 }],
    anim: { key: "pos", min: 1, max: 144, speed: 18, loop: "wrap", label: "필터 밀기" },
    draw(s, g) {
      const cs = 0.56, L = [0.4, 1], R = [9.2, 1], i0 = Math.floor((s.pos - 1) / 12), j0 = (s.pos - 1) % 12;
      const cell = (O, i, j) => [O[0] + j * cs, O[1] + (11 - i) * cs];
      let mn = Infinity, mx = -Infinity; const out = IMG.map((r, i) => r.map((_, j) => { const v = conv(s.f, i, j); mn = Math.min(mn, v); mx = Math.max(mx, v); return v; }));
      for (let i = 0; i < 12; i++) for (let j = 0; j < 12; j++) {
        const p = cell(L, i, j); g.poly([p, add(p, [cs, 0]), add(p, [cs, cs]), add(p, [0, cs])], { fill: IMG[i][j] ? "ink" : "paper", fo: IMG[i][j] ? 0.85 : 1, color: "grid", w: 0.6 });
        const q = cell(R, i, j), v = (out[i][j] - mn) / (mx - mn || 1), done = i * 12 + j < s.pos;
        g.poly([q, add(q, [cs, 0]), add(q, [cs, cs]), add(q, [0, cs])], { fill: done ? "ink" : "paper", fo: done ? 0.1 + 0.85 * v : 1, color: "grid", w: 0.6 });
      }
      const w0 = cell(L, i0 + 1, j0 - 1); g.poly([w0, add(w0, [3 * cs, 0]), add(w0, [3 * cs, 3 * cs]), add(w0, [0, 3 * cs])], { color: "a", w: 3, fill: "a", fo: 0.15 });
      const c0 = cell(R, i0, j0); g.poly([c0, add(c0, [cs, 0]), add(c0, [cs, cs]), add(c0, [0, cs])], { color: "a", w: 3 });
      g.text([L[0] + 6 * cs, L[1] + 12 * cs], "입력 이미지 (0 · 1)", { dy: -10, bold: true, size: 13 }).text([R[0] + 6 * cs, R[1] + 12 * cs], "합성곱 결과", { dy: -10, bold: true, size: 13 });
      const F = FILTERS[s.f]; g.text([8.16, 6.9], "필터", { size: 12, bold: true, color: "a" }); g.poly([[7.3, 3.7], [9.02, 3.7], [9.02, 6.4], [7.3, 6.4]], { color: "a", w: 1.4, fill: "a", fo: 0.06 }); F.k.forEach((row, a) => row.forEach((v, b) => g.text([8.16 + (b - 1) * 0.55, 5.55 - a * 0.8], String(v).replace("-", "−"), { size: 13, mono: true, color: "a", bold: true }))); if (F.div > 1) g.text([8.16, 3.7], `÷ ${F.div}`, { dy: 18, size: 12, color: "a", bold: true });
    },
    metrics(s) { const i0 = Math.floor((s.pos - 1) / 12), j0 = (s.pos - 1) % 12, F = FILTERS[s.f]; return [["위치", `${i0 + 1}행 ${j0 + 1}열`], ["곱의 합", `${fmt(conv(s.f, i0, j0) * F.div, 2)}${F.div > 1 ? ` ÷ ${F.div}` : ""}`], ["출력값", fmt(conv(s.f, i0, j0), 3), "key"]]; },
  },
  {
    id: "m1-turtle-polygon", grade: 1, unit: 6, lesson: "6.8 블록 코딩", title: "거북이로 그리는 정다각형과 별", type: "조작", time: "10분",
    tags: ["블록 코딩", "외각", "별다각형"], links: ["exterior-walk", "m1-pattern"],
    desc: "‘앞으로 가기 → 각만큼 돌기’를 n번 반복하는 거북이 코딩으로 정다각형과 별 모양을 그리고, 거북이가 돈 각의 합이 360°의 배수가 되어야 처음 자리로 돌아온다는 것을 확인합니다.",
    obs: ["정n각형을 그리려면 한 번에 외각 360°/n만큼 돕니다.", "360° × k / n만큼 돌면 별다각형 {n/k}가 그려집니다.", "돈 각의 합이 360° × k일 때 거북이가 제자리로 돌아옵니다."],
    q: "144°씩 돌면서 5번 반복하면 어떤 모양이 될까요?",
    formula: "한 번 도는 각 = 360° × k ÷ n · 돈 각의 합 = 360° × k",
    en: { title: "Turtle Polygons and Stars", desc: "Repeat 'move, turn' to draw regular polygons and star polygons." },
    view: V,
    params: [{ key: "n", label: "반복 횟수 n", min: 3, max: 12, step: 1, value: 5 }, { key: "k", label: "감는 수 k (1이면 다각형)", min: 1, max: 5, step: 1, value: 2 }, { key: "m", label: "실행한 줄 수", min: 0, max: 12, step: 1, value: 5 }],
    anim: { key: "m", min: 0, max: 12, speed: 2, label: "코드 실행" },
    derive(s) { if (s.k >= s.n / 2) s.k = Math.max(1, Math.ceil(s.n / 2) - 1); if (s.m > s.n) s.m = s.n; },
    onChange(s, key) { if (key === "n" || key === "k") s.m = s.n; },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const turn = (360 * s.k) / s.n, L = s.k === 1 ? 7 / Math.max(3, s.n / 2) : 6.2, R = L / (2 * Math.sin((Math.PI * s.k) / s.n));
      let P = [-L / 2, -R * Math.cos((Math.PI * s.k) / s.n)], h = 0; const pts = [P];
      for (let i = 0; i < s.n; i++) { P = add(P, [L * Math.cos(deg(h)), L * Math.sin(deg(h))]); pts.push(P); h += turn; }
      g.path(pts, { color: "muted", w: 1.2, dash: "4 5" });
      g.path(pts.slice(0, s.m + 1), { color: "a", w: 3.4 });
      const cur = pts[Math.min(s.m, s.n)], hd = s.m * turn;
      g.poly([add(cur, [0.45 * Math.cos(deg(hd)), 0.45 * Math.sin(deg(hd))]), add(cur, [0.3 * Math.cos(deg(hd + 140)), 0.3 * Math.sin(deg(hd + 140))]), add(cur, [0.3 * Math.cos(deg(hd - 140)), 0.3 * Math.sin(deg(hd - 140))])], { fill: "c", fo: 1, color: "ink", w: 1.4, layer: "top" });
      g.note(24, 36, `반복 ${s.n}번 { 앞으로 ${fmt(L, 1)}  ·  왼쪽으로 ${fmt(turn, 1)}° 돌기 }`, { color: "ink", bold: true, mono: true });
    },
    metrics(s) { const turn = (360 * s.k) / s.n; return [["한 번 도는 각", `${fmt(turn, 2)}°`], ["돈 각의 합", `${fmt(turn * s.m, 1)}°`], ["모양", s.k === 1 ? `정${s.n}각형` : `별다각형 {${s.n}/${s.k}}`, "key"]]; },
  },
];
