// 기하 — Ⅰ 이차곡선 · Ⅱ 공간도형과 공간좌표 · Ⅲ 벡터 · Ⅳ 벡터의 활용
import { fmt, frac, surd, poly, shiftSq, dist, sub, add, mul, norm, dot, len, cross, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const G = 6;
const V = { x: [-7, 7], y: [-5, 5] };
const pt = (p) => `(${p.map((v) => frac(v)).join(", ")})`;
const pt2 = (p) => `(${p.map((v) => fmt(v)).join(", ")})`;
const cosh = Math.cosh, sinh = Math.sinh;
const vlen2 = (p) => fmt(len(p));

// 정육면체 (한 변 2, 중심이 원점)
const CUBE = { A: [-1, -1, -1], B: [1, -1, -1], C: [1, 1, -1], D: [-1, 1, -1], E: [-1, -1, 1], F: [1, -1, 1], G: [1, 1, 1], H: [-1, 1, 1] };
const EDGES = ["AB", "BC", "CD", "DA", "EF", "FG", "GH", "HE", "AE", "BF", "CG", "DH"];
const LINES = [...EDGES, "AC", "BD", "EG", "FH", "AF", "BE", "AH", "DE", "BG", "CF", "AG", "BH", "CE", "DF"];
const FACES = { ABCD: "아랫면 ABCD", EFGH: "윗면 EFGH", ABFE: "앞면 ABFE", DCGH: "뒷면 DCGH", BCGF: "오른쪽 면 BCGF", ADHE: "왼쪽 면 ADHE" };
function drawCube(g, hi = []) {
  EDGES.forEach((e) => g.seg(CUBE[e[0]], CUBE[e[1]], { color: "muted", w: 1.4, opacity: 0.8 }));
  Object.entries(CUBE).forEach(([k, v]) => g.text(v, k, { dx: v[0] > 0 ? 12 : -12, dy: v[2] > 0 ? -8 : 18, color: "muted", bold: true }));
}

export default [
  // ───────── Ⅰ 이차곡선 ─────────
  {
    id: "geo-parabola", grade: G, unit: 1, lesson: "Ⅰ-1", title: "포물선 — 초점과 준선", type: "2D", time: "10분",
    tags: ["초점", "준선", "자취"], links: ["geo-tangent-reflect", "geo-conic-section"],
    desc: "초점 F까지의 거리와 준선까지의 거리가 같은 점 P를 움직이며 포물선이 그려지는 원리를 확인합니다.",
    obs: ["포물선 위의 모든 점에서 PF = PH입니다.", "p가 커질수록 초점이 꼭짓점에서 멀어지고 포물선이 넓게 벌어집니다.", "꼭짓점은 초점과 준선의 한가운데에 있습니다."],
    q: "준선이 x = −2이고 초점이 (2, 0)인 포물선의 방정식은 무엇일까요?",
    formula: "y² = 4px (초점 (p, 0), 준선 x = −p) · x² = 4py",
    en: { title: "Parabola: Focus and Directrix", desc: "Move P with equal distances to the focus and the directrix to trace a parabola." },
    view: V,
    params: [
      { key: "ori", label: "방향", type: "seg", value: "x", options: [["x", "y² = 4px"], ["y", "x² = 4py"]] },
      { key: "p", label: "p", min: -3, max: 3, step: 0.25, value: 1.5 },
      { key: "t", label: "점 P의 위치", min: -4.5, max: 4.5, step: 0.05, value: 2.6 },
      { key: "trace", label: "자취를 따라 그리기", type: "check", value: true },
    ],
    anim: { key: "t", min: -4.5, max: 4.5, speed: 2.2, label: "P 움직이기" },
    derive(s) { if (Math.abs(s.p) < 0.2) s.p = 0.25; },
    drags: { P: { at: (s) => (s.ori === "x" ? [(s.t * s.t) / (4 * s.p), s.t] : [s.t, (s.t * s.t) / (4 * s.p)]), move: (s, p) => (s.t = s.ori === "x" ? p[1] : p[0]) } },
    draw(s, g) {
      g.grid();
      const p = s.p, sw = (q) => (s.ori === "x" ? q : [q[1], q[0]]);
      const P = sw([(s.t * s.t) / (4 * p), s.t]), F = sw([p, 0]), H = sw([-p, s.t]);
      g.param((u) => sw([(u * u) / (4 * p), u]), -6, 6, { color: "a", w: s.trace ? 1.6 : 3.2, dash: s.trace ? "5 6" : null });
      if (s.trace) g.param((u) => sw([(u * u) / (4 * p), u]), -4.5, s.t, { color: "a", w: 3.4 });
      if (s.ori === "x") g.seg([-p, -5], [-p, 5], { color: "b", w: 2.6 }); else g.seg([-7, -p], [7, -p], { color: "b", w: 2.6 });
      g.text(s.ori === "x" ? [-p, 4.6] : [6.6, -p], s.ori === "x" ? `준선 x = ${fmt(-p)}` : `준선 y = ${fmt(-p)}`, { dx: s.ori === "x" ? 8 : 0, dy: s.ori === "x" ? 0 : -8, anchor: s.ori === "x" ? "start" : "end", color: "b", bold: true });
      g.seg(P, F, { color: "d", w: 2.8 }).seg(P, H, { color: "c", w: 2.8 });
      g.right(H, P, s.ori === "x" ? [-p, s.t + 1] : [s.t + 1, -p], { size: 10 });
      g.text(lerp(P, F, 0.5), `PF = ${fmt(dist(P, F))}`, { dy: -10, color: "d", bold: true, size: 13 });
      g.text(lerp(P, H, 0.5), `PH = ${fmt(dist(P, H))}`, { dy: 20, color: "c", bold: true, size: 13 });
      g.point(F, "F", { color: "d" }).point(H, "H", { color: "c", r: 4.5 }).point(P, "P", { color: "a", r: 7 });
    },
    metrics(s) {
      const eq = s.ori === "x" ? `y² = ${fmt(4 * s.p)}x` : `x² = ${fmt(4 * s.p)}y`;
      return [["방정식", eq, "key"], ["초점", s.ori === "x" ? `(${fmt(s.p)}, 0)` : `(0, ${fmt(s.p)})`], ["준선", s.ori === "x" ? `x = ${fmt(-s.p)}` : `y = ${fmt(-s.p)}`], ["PF − PH", "0 (항상 같음)"]];
    },
  },
  {
    id: "geo-ellipse", grade: G, unit: 1, lesson: "Ⅰ-2", title: "타원 — 실로 그리기", type: "조작", time: "12분",
    tags: ["두 초점", "장축", "이심률"], links: ["geo-conic-section", "lab-ellipse-billiards"],
    desc: "두 초점에 실의 양 끝을 고정하고 팽팽하게 당겨 돌리듯, 두 초점까지 거리의 합이 일정한 점의 자취로 타원을 그립니다.",
    obs: ["PF + PF′는 언제나 장축의 길이 2a와 같습니다.", "두 초점이 가까워지면 원에, 멀어지면 납작한 타원에 가까워집니다.", "b² = a² − c²의 관계가 성립합니다."],
    q: "두 초점이 한 점에서 만나면 어떤 도형이 될까요?",
    formula: "x²/a² + y²/b² = 1 · b² = a² − c² · PF + PF′ = 2a",
    en: { title: "Ellipse: Drawing with a String", desc: "Keep the sum of distances to two foci constant and trace an ellipse." },
    view: V,
    params: [
      { key: "ori", label: "장축", type: "seg", value: "x", options: [["x", "x축 위"], ["y", "y축 위"]] },
      { key: "a", label: "a (장축의 반)", min: 2, max: s => s.ori === "y" ? 4.5 : 6.5, step: 0.25, value: 5 },
      { key: "c", label: "c (중심에서 초점까지)", min: 0, max: s => s.a - 0.25, step: 0.25, value: 3 },
      { key: "t", label: "점 P의 각", min: 0, max: 6.2832, step: 0.01, value: 1.1, show: (v) => `${fmt(rad2deg(v), 0)}°` },
    ],
    anim: { key: "t", min: 0, max: 6.2832, speed: 0.9, loop: "wrap", label: "실로 그리기" },
    derive(s) { if (s.ori === "y" && s.a > 4.5) s.a = 4.5; s.c = clamp(s.c, 0, s.a - 0.25); },
    drags: { P: { at: (s) => { const b = Math.sqrt(s.a * s.a - s.c * s.c), q = [s.a * Math.cos(s.t), b * Math.sin(s.t)]; return s.ori === "x" ? q : [q[1], q[0]]; }, move: (s, p) => { const b = Math.sqrt(s.a * s.a - s.c * s.c), q = s.ori === "x" ? p : [p[1], p[0]]; let t = Math.atan2(q[1] / b, q[0] / s.a); if (t < 0) t += 2 * Math.PI; s.t = t; } } },
    draw(s, g) {
      g.grid();
      const a = s.a, c = s.c, b = Math.sqrt(a * a - c * c), sw = (q) => (s.ori === "x" ? q : [q[1], q[0]]);
      const P = sw([a * Math.cos(s.t), b * Math.sin(s.t)]), F = sw([c, 0]), F2 = sw([-c, 0]);
      g.param((u) => sw([a * Math.cos(u), b * Math.sin(u)]), 0, 6.3, { color: "a", w: 1.6, dash: "5 6" });
      g.param((u) => sw([a * Math.cos(u), b * Math.sin(u)]), 0, s.t, { color: "a", w: 3.6 });
      g.seg(sw([-a, 0]), sw([a, 0]), { color: "muted", w: 1.4 }).seg(sw([0, -b]), sw([0, b]), { color: "muted", w: 1.4 });
      g.seg(F2, P, { color: "f", w: 2.6 }).seg(F, P, { color: "b", w: 2.6 });
      g.text(lerp(F2, P, 0.5), fmt(dist(F2, P)), { dy: -8, color: "f", bold: true, size: 13 }).text(lerp(F, P, 0.5), fmt(dist(F, P)), { dy: -8, color: "b", bold: true, size: 13 });
      g.point(F, "F", { color: "ink", dy: 20 }).point(F2, "F′", { color: "ink", dy: 20 }).point(P, "P", { color: "a", r: 7 });
      g.point(sw([a, 0]), "", { r: 3.5, color: "muted" }).point(sw([-a, 0]), "", { r: 3.5, color: "muted" });
    },
    metrics(s) {
      const b2 = s.a * s.a - s.c * s.c, eq = s.ori === "x" ? `x²/${fmt(s.a * s.a)} + y²/${fmt(b2)} = 1` : `x²/${fmt(b2)} + y²/${fmt(s.a * s.a)} = 1`;
      return [["PF′ + PF", `${fmt(2 * s.a)} = 2a`, "key"], ["방정식", eq], ["b = √(a² − c²)", `${surd(b2)} ≈ ${fmt(Math.sqrt(b2))}`], ["이심률 c/a", fmt(s.c / s.a, 3)]];
    },
  },
  {
    id: "geo-hyperbola", grade: G, unit: 1, lesson: "Ⅰ-3", title: "쌍곡선 — 거리의 차와 점근선", type: "2D", time: "12분",
    tags: ["거리의 차", "점근선", "항해"], links: ["geo-conic-section"],
    desc: "두 초점까지 거리의 차가 일정한 점을 움직이며 쌍곡선의 두 가지와 점근선이 만들어지는 모습을 봅니다.",
    obs: ["|PF − PF′|는 언제나 주축의 길이 2a입니다.", "점이 멀어질수록 곡선은 점근선 y = ±(b/a)x에 가까워집니다.", "c² = a² + b²입니다."],
    q: "두 기지국에서 오는 전파의 도착 시간 차가 일정한 위치는 어떤 곡선 위에 있을까요?",
    formula: "x²/a² − y²/b² = 1 · c² = a² + b² · |PF − PF′| = 2a",
    en: { title: "Hyperbola: Difference of Distances", desc: "Keep the difference of distances to two foci constant and see both branches and the asymptotes." },
    view: V,
    params: [
      { key: "a", label: "a", min: 1, max: 4, step: 0.25, value: 2 },
      { key: "c", label: "c", min: 1.5, max: 6, step: 0.25, value: 3 },
      { key: "t", label: "점 P의 위치", min: -2, max: 2, step: 0.02, value: 0.9 },
      { key: "side", label: "가지", type: "seg", value: "r", options: [["r", "오른쪽"], ["l", "왼쪽"]] },
      { key: "box", label: "점근선과 기본 직사각형 보기", type: "check", value: true },
    ],
    anim: { key: "t", min: -2, max: 2, speed: 0.9, label: "P 움직이기" },
    derive(s) { if (s.c < s.a + 0.25) s.c = s.a + 0.25; },
    drags: { P: { at: (s) => { const b = Math.sqrt(s.c * s.c - s.a * s.a); return [(s.side === "r" ? 1 : -1) * s.a * Math.cosh(s.t), b * Math.sinh(s.t)]; }, move: (s, p) => { const b = Math.sqrt(s.c * s.c - s.a * s.a); s.t = Math.asinh(p[1] / b); s.side = p[0] < 0 ? "l" : "r"; } } },
    draw(s, g) {
      g.grid();
      const a = s.a, c = s.c, b = Math.sqrt(c * c - a * a), k = s.side === "r" ? 1 : -1;
      if (s.box) { g.poly([[a, b], [-a, b], [-a, -b], [a, -b]], { color: "muted", w: 1.2, dash: "4 5" }); g.line([0, 0], [a, b], { color: "e", w: 1.6, dash: "7 5" }).line([0, 0], [a, -b], { color: "e", w: 1.6, dash: "7 5" }); }
      [1, -1].forEach((sg) => g.param((u) => [sg * a * cosh(u), b * sinh(u)], -3, 3, { color: "a", w: 3.2 }));
      const P = [k * a * cosh(s.t), b * sinh(s.t)], F = [c, 0], F2 = [-c, 0];
      g.seg(F2, P, { color: "f", w: 2.4 }).seg(F, P, { color: "b", w: 2.4 });
      g.text(lerp(F2, P, 0.5), fmt(dist(F2, P)), { dy: -8, color: "f", bold: true, size: 13 }).text(lerp(F, P, 0.5), fmt(dist(F, P)), { dy: 18, color: "b", bold: true, size: 13 });
      g.point(F, "F", { dy: 20 }).point(F2, "F′", { dy: 20 }).point(P, "P", { color: "a", r: 7 });
      g.point([a, 0], "", { r: 3.5, color: "muted" }).point([-a, 0], "", { r: 3.5, color: "muted" });
    },
    metrics(s) {
      const b2 = s.c * s.c - s.a * s.a, b = Math.sqrt(b2);
      return [["|PF − PF′|", `${fmt(2 * s.a)} = 2a`, "key"], ["방정식", `x²/${fmt(s.a * s.a)} − y²/${fmt(b2)} = 1`], ["점근선", `y = ±${fmt(b / s.a, 3)}x`], ["이심률 c/a", fmt(s.c / s.a, 3)]];
    },
  },
  {
    id: "geo-conic-section", grade: G, unit: 1, lesson: "Ⅰ", title: "원뿔을 자르면 — 이차곡선의 탄생", type: "3D", time: "12분",
    tags: ["원뿔 단면", "원·타원·포물선·쌍곡선", "3D"], links: ["cross-section", "geo-parabola", "geo-ellipse", "geo-hyperbola"],
    desc: "두 원뿔을 꼭짓점끼리 붙이고 평면의 기울기를 바꿔 자르면 원, 타원, 포물선, 쌍곡선이 차례로 나타납니다.",
    obs: ["평면이 축에 수직이면 원, 조금 기울이면 타원이 됩니다.", "평면이 모선과 평행해지는 순간 포물선이 됩니다.", "더 기울이면 두 원뿔을 모두 잘라 쌍곡선의 두 가지가 생깁니다."],
    q: "평면이 꼭짓점을 지나도록 자르면 어떤 모양이 생길까요?",
    formula: "기울기 φ와 모선의 각 (90° − α)의 비교: φ < 90° − α 타원 · = 포물선 · > 쌍곡선",
    en: { title: "Slicing a Cone: Birth of the Conics", desc: "Tilt a plane through a double cone to obtain circles, ellipses, parabolas and hyperbolas." },
    space: true, cam: { yaw: 28, pitch: 14, scale: 62, persp: 30 },
    params: [
      { key: "phi", label: "평면의 기울기 φ", min: 0, max: 90, step: 1, value: 35, unit: "°" },
      { key: "alpha", label: "원뿔의 반꼭지각 α", min: 20, max: 45, step: 1, value: 32, unit: "°" },
      { key: "z0", label: "평면의 높이", min: -1.6, max: 1.6, step: 0.05, value: 0.9 },
    ],
    anim: { key: "phi", min: 0, max: 90, speed: 12, label: "평면 기울이기" },
    kind(s) { const lim = 90 - s.alpha; if (Math.abs(s.z0) < 0.03) return "꼭짓점을 지남 (점 또는 직선)"; if (s.phi < 0.5) return "원"; if (Math.abs(s.phi - lim) < 0.6) return "포물선"; return s.phi < lim ? "타원" : "쌍곡선"; },
    draw(s, g) {
      const H = 2.3, ta = Math.tan(deg(s.alpha)), ph = deg(s.phi), n = [0, Math.sin(ph), Math.cos(ph)];
      for (let k = 0; k < 24; k++) { const a = (k * Math.PI) / 12, d = [ta * Math.cos(a), ta * Math.sin(a), 1]; g.seg(mul(d, -H), mul(d, H), { color: "b", w: 1, opacity: 0.45 }); }
      [H, -H].forEach((z) => g.circle([0, 0, z], [1, 0, 0], [0, 1, 0], z * ta * Math.sign(z), { color: "b", w: 1.6, fill: "b", fo: 0.06 }));
      g.seg([0, 0, -H - 0.4], [0, 0, H + 0.4], { color: "muted", w: 1, dash: "3 5" });
      const P0 = [0, 0, s.z0], u = [1, 0, 0], v = [0, Math.cos(ph), -Math.sin(ph)];
      g.plane(P0, u, v, 2.4, 2.4, { fill: "e", color: "e", fo: 0.16 });
      // 교선: 모선 방향마다 교점 z를 계산
      const segs = []; let cur = [];
      for (let i = 0; i <= 720; i++) {
        const th = (i / 720) * Math.PI * 2, den = ta * Math.sin(th) * n[1] + n[2];
        const z = Math.abs(den) < 1e-6 ? Infinity : (s.z0 * n[2]) / den;
        if (Math.abs(z) <= H) cur.push([z * ta * Math.cos(th), z * ta * Math.sin(th), z]);
        else { if (cur.length > 1) segs.push(cur); cur = []; }
      }
      if (cur.length > 1) segs.push(cur);
      if (segs.length > 1 && dist(segs[0][0], segs[segs.length - 1][segs[segs.length - 1].length - 1]) < 0.1) { segs[0] = [...segs.pop(), ...segs[0]]; }
      segs.forEach((sg) => g.path(sg, { color: "a", w: 3.6, bias: 3 }));
      g.note(20, 32, `단면: ${this.kind(s)}`, { color: "a", bold: true });
    },
    metrics(s) { return [["평면의 기울기 φ", `${s.phi}°`], ["모선의 기울기 90° − α", `${90 - s.alpha}°`], ["단면의 모양", this.kind(s), "key"]]; },
  },
  {
    id: "geo-conic-shift", grade: G, unit: 1, lesson: "Ⅰ-4", title: "이차곡선의 평행이동과 일반형", type: "2D", time: "10분",
    tags: ["평행이동", "완전제곱식", "일반형"], links: ["c2-translation", "c2-circle-eq"],
    desc: "포물선·타원·쌍곡선을 평행이동한 뒤 전개한 일반형과, 일반형을 다시 완전제곱식으로 바꾼 표준형을 나란히 봅니다.",
    obs: ["평행이동하면 중심·꼭짓점·초점이 모두 같은 만큼 옮겨집니다.", "일반형 Ax² + By² + Cx + Dy + E = 0에서 x², y²의 계수 부호로 곡선의 종류를 판단할 수 있습니다."],
    q: "4x² + 9y² − 16x + 18y − 11 = 0은 어떤 곡선일까요?",
    formula: "f(x, y) = 0 → f(x − m, y − n) = 0",
    en: { title: "Translating Conics", desc: "Translate conics and compare the expanded general form with the standard form." },
    view: V,
    params: [
      { key: "kind", label: "곡선", type: "seg", value: "ell", options: [["par", "포물선"], ["ell", "타원"], ["hyp", "쌍곡선"]] },
      { key: "m", label: "x축 방향 m", min: -4, max: 4, step: 0.5, value: 1.5 },
      { key: "n", label: "y축 방향 n", min: -3, max: 3, step: 0.5, value: 1 },
    ],
    base(s) {
      if (s.kind === "par") return { f: (u, m, n) => [u * u / 4 + m, u + n], r: [-5, 5], foci: [[1, 0]], eqS: (m, n) => `${shiftSq("y", n)} = 4${m ? `(x ${m > 0 ? "−" : "+"} ${fmt(Math.abs(m))})` : "x"}`, gen: (m, n) => `${poly([[1, "y²"], [-4, "x"], [-2 * n, "y"]], 4 * m + n * n)} = 0` };
      if (s.kind === "ell") return { f: (u, m, n) => [3 * Math.cos(u) + m, 2 * Math.sin(u) + n], r: [0, 6.3], foci: [[Math.sqrt(5), 0], [-Math.sqrt(5), 0]], eqS: (m, n) => `${shiftSq("x", m)}/9 + ${shiftSq("y", n)}/4 = 1`, gen: (m, n) => `${poly([[4, "x²"], [9, "y²"], [-8 * m, "x"], [-18 * n, "y"]], 4 * m * m + 9 * n * n - 36)} = 0` };
      return { f: (u, m, n) => [2 * cosh(u) + m, Math.sqrt(5) * sinh(u) + n], f2: (u, m, n) => [-2 * cosh(u) + m, Math.sqrt(5) * sinh(u) + n], r: [-2.2, 2.2], foci: [[3, 0], [-3, 0]], eqS: (m, n) => `${shiftSq("x", m)}/4 − ${shiftSq("y", n)}/5 = 1`, gen: (m, n) => `${poly([[5, "x²"], [-4, "y²"], [-10 * m, "x"], [8 * n, "y"]], 5 * m * m - 4 * n * n - 20)} = 0` };
    },
    draw(s, g) {
      g.grid();
      const B = this.base(s);
      [B.f, B.f2].filter(Boolean).forEach((f) => { g.param((u) => f(u, 0, 0), B.r[0], B.r[1], { color: "muted", w: 1.8, dash: "5 6" }); g.param((u) => f(u, s.m, s.n), B.r[0], B.r[1], { color: "a", w: 3.4 }); });
      g.vec([0, 0], [s.m, s.n], { color: "e", w: 2.4 });
      B.foci.forEach((F) => { g.point(F, "", { color: "muted", r: 4, hollow: true }); g.point(add(F, [s.m, s.n]), "F", { color: "d", r: 5 }); });
      g.point([s.m, s.n], s.kind === "par" ? "꼭짓점" : "중심", { color: "ink", r: 4 });
    },
    metrics(s) {
      const B = this.base(s);
      return [["표준형", B.eqS(s.m, s.n), "key"], ["일반형 (전개)", B.gen(s.m, s.n)], ["초점", B.foci.map((F) => pt2(add(F, [s.m, s.n]))).join(", ")]];
    },
  },
  {
    id: "geo-tangent-reflect", grade: G, unit: 1, lesson: "Ⅰ-5", title: "이차곡선의 접선과 반사 성질", type: "2D", time: "12분",
    tags: ["접선의 방정식", "반사", "위성 안테나"], links: ["c2-tangent", "geo-parabola", "lab-ellipse-billiards"],
    desc: "곡선 위의 점에서 접선을 긋고, 접선에 대한 빛의 반사로 포물선은 평행광을 초점에 모으고 타원은 한 초점의 빛을 다른 초점에 모으는 것을 봅니다.",
    obs: ["접선은 두 초점을 향한 선분과 같은 각을 이룹니다.", "포물선 안테나는 축에 평행하게 들어온 전파를 초점 하나에 모읍니다.", "타원의 한 초점에서 나온 빛은 벽에 반사된 뒤 모두 다른 초점을 지납니다."],
    q: "자동차 전조등의 전구는 포물면 거울의 어디에 두어야 빛이 평행하게 나갈까요?",
    formula: "y₁y = 2p(x + x₁) · x₁x/a² + y₁y/b² = 1 · x₁x/a² − y₁y/b² = 1",
    en: { title: "Tangents and Reflection Properties", desc: "Draw tangents and watch parabolic and elliptic mirrors focus light." },
    view: V,
    params: [
      { key: "kind", label: "곡선", type: "seg", value: "par", options: [["par", "포물선 y² = 8x"], ["ell", "타원"], ["hyp", "쌍곡선"]] },
      { key: "t", label: "접점의 위치", min: -2.5, max: 2.5, step: 0.02, value: 0.9 },
      { key: "rays", label: "빛 여러 줄 보기", type: "check", value: true },
    ],
    anim: { key: "t", min: -2.5, max: 2.5, speed: 0.8, label: "접점 움직이기" },
    geo(s, t) {
      if (s.kind === "par") { const p = 2, y = t * 1.6, P = [(y * y) / (4 * p), y]; return { P, T: [2 * p, y], F: [p, 0], F2: null, eq: `${fmt(y)}y = ${fmt(2 * p)}(x + ${fmt(P[0])})` }; }
      if (s.kind === "ell") { const a = 5, b = 3, u = t * 1.2, P = [a * Math.cos(u), b * Math.sin(u)]; return { P, T: [-a * Math.sin(u), b * Math.cos(u)], F: [4, 0], F2: [-4, 0], eq: `${fmt(P[0])}x/25 + ${fmt(P[1])}y/9 = 1` }; }
      const a = 2, b = Math.sqrt(5), P = [a * cosh(t * 0.8), b * sinh(t * 0.8)]; return { P, T: [a * sinh(t * 0.8), b * cosh(t * 0.8)], F: [3, 0], F2: [-3, 0], eq: `${fmt(P[0])}x/4 − ${fmt(P[1])}y/5 = 1` };
    },
    drags: { P: { at: (s) => (s.kind === "par" ? [((s.t * 1.6) ** 2) / 8, s.t * 1.6] : s.kind === "ell" ? [5 * Math.cos(s.t * 1.2), 3 * Math.sin(s.t * 1.2)] : [2 * Math.cosh(s.t * 0.8), Math.sqrt(5) * Math.sinh(s.t * 0.8)]), move: (s, p) => (s.t = s.kind === "par" ? p[1] / 1.6 : s.kind === "ell" ? Math.atan2(p[1] / 3, p[0] / 5) / 1.2 : Math.asinh(p[1] / Math.sqrt(5)) / 0.8) } },
    draw(s, g) {
      g.grid();
      if (s.kind === "par") g.param((y) => [(y * y) / 8, y], -5, 5, { color: "a", w: 3.2 });
      if (s.kind === "ell") g.param((u) => [5 * Math.cos(u), 3 * Math.sin(u)], 0, 6.3, { color: "a", w: 3.2 });
      if (s.kind === "hyp") [1, -1].forEach((k) => g.param((u) => [k * 2 * cosh(u), Math.sqrt(5) * sinh(u)], -2.4, 2.4, { color: "a", w: 3.2 }));
      if (s.rays) {
        const ts = [-2.2, -1.5, -0.8, 0.8, 1.5, 2.2];
        ts.forEach((t) => { const { P, F, F2 } = this.geo(s, t); if (s.kind === "par") { g.seg([7, P[1]], P, { color: "f", w: 1.4, opacity: 0.7 }); g.seg(P, F, { color: "f", w: 1.4, opacity: 0.7 }); } else if (s.kind === "ell") { g.seg(F2, P, { color: "f", w: 1.4, opacity: 0.7 }); g.seg(P, F, { color: "f", w: 1.4, opacity: 0.7 }); } else { g.seg(F, P, { color: "f", w: 1.4, opacity: 0.7 }); const d = norm(sub(P, F2)); g.seg(P, add(P, mul(d, 4)), { color: "f", w: 1.4, opacity: 0.7 }); g.seg(P, F2, { color: "f", w: 1, dash: "3 5", opacity: 0.5 }); } });
      }
      const { P, T, F, F2 } = this.geo(s, s.t);
      g.line(P, add(P, T), { color: "b", w: 2.6 });
      if (s.kind === "par") { g.seg([7, P[1]], P, { color: "d", w: 2.8 }); g.seg(P, F, { color: "d", w: 2.8 }); g.arc(P, add(P, T), [7, P[1]], { r: 24, color: "c", ccw: false }); g.arc(P, F, add(P, mul(T, -1)), { r: 24, color: "c", ccw: false }); }
      else { g.seg(P, F, { color: "d", w: 2.8 }); g.seg(P, F2, { color: "d", w: 2.8 }); }
      g.point(F, "F", { color: "d", dy: 20 }); if (F2) g.point(F2, "F′", { color: "d", dy: 20 });
      g.point(P, "P", { color: "a", r: 7 });
    },
    metrics(s) { const { P, eq } = this.geo(s, s.t); return [["접점", pt2(P)], ["접선의 방정식", eq, "key"], s.kind === "par" ? "축에 평행한 빛은 반사 후 초점 F를 지납니다." : s.kind === "ell" ? "F′에서 나온 빛은 반사 후 F를 지납니다." : "F를 향하던 빛은 반사 후 F′에서 나온 것처럼 퍼집니다."]; },
  },

  // ───────── Ⅱ 공간도형과 공간좌표 ─────────
  {
    id: "geo-space-lines", grade: G, unit: 2, lesson: "Ⅱ-1", title: "정육면체로 보는 두 직선이 이루는 각", type: "3D", time: "12분",
    tags: ["꼬인 위치", "평행이동", "3D"], links: ["position-relations", "geo-three-perp"],
    desc: "정육면체의 모서리와 대각선 가운데 두 직선을 골라 위치 관계를 판정하고, 꼬인 위치의 두 직선은 한 직선을 평행이동하여 이루는 각을 잽니다.",
    obs: ["한 평면 위에 있지 않은 두 직선은 꼬인 위치에 있습니다.", "꼬인 위치의 두 직선이 이루는 각은 한 직선을 평행이동해 만나게 한 뒤 잽니다.", "두 직선이 이루는 각은 0° 이상 90° 이하로 정합니다."],
    q: "정육면체에서 모서리 AB와 대각선 CE가 이루는 각의 코사인 값은 얼마일까요?",
    formula: "cos θ = |u · v| / (|u||v|) (0° ≤ θ ≤ 90°)",
    en: { title: "Angles Between Lines in a Cube", desc: "Choose two lines in a cube, classify them, and measure the angle between skew lines." },
    space: true, cam: { yaw: 32, pitch: 20, scale: 88 },
    params: [
      { key: "l1", label: "직선 1", type: "select", value: "AB", options: LINES.map((e) => [e, e]) },
      { key: "l2", label: "직선 2", type: "select", value: "CE", options: LINES.map((e) => [e, e]) },
    ],
    rel(s) {
      const P1 = CUBE[s.l1[0]], u = sub(CUBE[s.l1[1]], P1), P2 = CUBE[s.l2[0]], v = sub(CUBE[s.l2[1]], P2), c = cross(u, v);
      const ang = rad2deg(Math.acos(clamp(Math.abs(dot(u, v)) / (len(u) * len(v)), 0, 1)));
      if (len(c) < 1e-9) return { kind: len(cross(sub(P2, P1), u)) < 1e-9 ? "일치" : "평행", ang: 0, u, v, P1, P2 };
      const cop = Math.abs(dot(sub(P2, P1), c)) < 1e-9;
      if (cop) { const t = dot(cross(sub(P2, P1), v), c) / dot(c, c); return { kind: "한 점에서 만남", ang, u, v, P1, P2, X: add(P1, mul(u, t)) }; }
      return { kind: "꼬인 위치", ang, u, v, P1, P2, d: Math.abs(dot(sub(P2, P1), c)) / len(c) };
    },
    draw(s, g) {
      drawCube(g);
      const r = this.rel(s), e = (v, k) => [v, add(v, k)];
      g.seg(...e(add(r.P1, mul(r.u, -0.25)), mul(r.u, 1.5)), { color: "a", w: 3.6, bias: 2 });
      g.seg(...e(add(r.P2, mul(r.v, -0.25)), mul(r.v, 1.5)), { color: "b", w: 3.6, bias: 2 });
      if (r.kind === "꼬인 위치") { g.seg(r.P1, add(r.P1, r.v), { color: "b", w: 2, dash: "6 5", bias: 2 }); g.vec(r.P2, r.P1, { color: "e", w: 1.4 }); g.text(add(r.P1, mul(r.v, 0.5)), "평행이동한 직선 2", { color: "b", dy: -10, size: 12 }); }
      if (r.X) g.point(r.X, "", { color: "d", r: 6, bias: 3 });
      g.note(20, 32, `${s.l1} · ${s.l2}`, { color: "ink", bold: true, mono: true });
    },
    metrics(s) {
      const r = this.rel(s);
      const out = [["위치 관계", r.kind, "key"], ["이루는 각", r.kind === "평행" || r.kind === "일치" ? "0°" : `${fmt(r.ang, 2)}°`], ["cos θ", fmt(Math.cos(deg(r.ang)), 4)]];
      if (r.d != null) out.push(["두 직선 사이의 거리", fmt(r.d, 3) + " (한 변 2)"]);
      return out;
    },
  },
  {
    id: "geo-three-perp", grade: G, unit: 2, lesson: "Ⅱ-2", title: "삼수선 정리", type: "3D", time: "12분",
    tags: ["수선", "평면", "증명"], links: ["c2-point-line", "geo-projection"],
    desc: "평면 밖의 점 P에서 평면에 내린 수선 PO와 평면 위 직선 l에 내린 수선 OH를 이용해 PH ⟂ l임을 확인합니다.",
    obs: ["PO ⟂ α, OH ⟂ l이면 PH ⟂ l입니다(정리 1).", "PO ⟂ α, PH ⟂ l이면 OH ⟂ l입니다(정리 2).", "PH ⟂ l, OH ⟂ l, PO ⟂ OH이면 PO ⟂ α입니다(정리 3)."],
    q: "건물 옥상 P에서 도로 l까지의 최단 거리를 구하려면 어떤 수선이 필요할까요?",
    formula: "PO ⟂ α, OH ⟂ l ⇒ PH ⟂ l · PH² = PO² + OH²",
    en: { title: "Theorem of Three Perpendiculars", desc: "From a point above a plane, drop perpendiculars to the plane and to a line in it to verify PH ⟂ l." },
    space: true, cam: { yaw: 40, pitch: 24, scale: 60 },
    params: [
      { key: "h", label: "PO (평면까지 높이)", min: 0.8, max: 3, step: 0.1, value: 2.2 },
      { key: "r", label: "OH (O와 직선 l 사이 거리)", min: 0.6, max: 2.8, step: 0.1, value: 1.8 },
      { key: "psi", label: "직선 l의 방향", min: 0, max: 180, step: 1, value: 30, unit: "°" },
    ],
    draw(s, g) {
      const ps = deg(s.psi), nH = [Math.cos(ps), Math.sin(ps), 0], dir = [-Math.sin(ps), Math.cos(ps), 0];
      const O = [0, 0, 0], P = [0, 0, s.h], H = mul(nH, s.r);
      g.plane([0, 0, 0], [1, 0, 0], [0, 1, 0], 3.2, 3.2, { fill: "b", color: "b", fo: 0.12, grid: 0.8 });
      g.text([3.1, -3.1, 0], "α", { color: "b", italic: true, size: 22 });
      g.seg(add(H, mul(dir, -3.4)), add(H, mul(dir, 3.4)), { color: "ink", w: 3, bias: 1 });
      g.text(add(H, mul(dir, 3.3)), "l", { color: "ink", italic: true, dy: -8 });
      g.seg(P, O, { color: "a", w: 3, bias: 2 }).seg(O, H, { color: "c", w: 3, bias: 2 }).seg(P, H, { color: "d", w: 3, bias: 2 });
      g.right(O, P, H, { size: 0.26, color: "a" }).right(H, O, add(H, dir), { size: 0.26, color: "c" }).right(H, P, add(H, dir), { size: 0.26, color: "d" });
      g.point(P, "P", { color: "a" }).point(O, "O", { color: "ink", dy: 18 }).point(H, "H", { color: "d", dy: 18 });
    },
    metrics(s) {
      const PH = Math.hypot(s.h, s.r);
      return [["PO ⟂ α, OH ⟂ l", "가정"], ["PH · (l의 방향)", "0 → PH ⟂ l", "key"], ["PH = √(PO² + OH²)", fmt(PH, 3)]];
    },
  },
  {
    id: "geo-projection", grade: G, unit: 2, lesson: "Ⅱ-3", title: "정사영과 그림자의 넓이", type: "3D", time: "12분",
    tags: ["정사영", "cos θ", "그림자"], links: ["geo-three-perp", "geo-dot-product"],
    desc: "기울어진 평면 위의 도형을 바닥에 수직으로 투영해 넓이가 cos θ배가 됨을 확인합니다. 선분 길이에 같은 비율을 적용하려면 선분이 두 평면의 교선에 수직이어야 합니다.",
    obs: ["두 평면이 이루는 각이 θ이면 정사영의 넓이는 S cos θ입니다.", "기울어진 원의 정사영은 타원이 됩니다.", "θ = 90°이면 정사영은 선분(넓이 0)이 됩니다."],
    q: "태양이 바로 머리 위에 있을 때 비스듬히 든 판자의 그림자 넓이는 어떻게 구할까요?",
    formula: "l′ = l cos θ (선분이 교선에 수직일 때) · S′ = S cos θ",
    en: { title: "Orthogonal Projection and Shadows", desc: "Project a tilted figure onto a base plane. Area scales by cos θ. A segment has the same factor only when perpendicular to the line of intersection." },
    space: true, cam: { yaw: 36, pitch: 26, scale: 58 },
    params: [
      { key: "shape", label: "도형", type: "seg", value: "circle", options: [["tri", "삼각형"], ["sq", "정사각형"], ["circle", "원"]] },
      { key: "th", label: "두 평면이 이루는 각 θ", min: 0, max: 90, step: 1, value: 50, unit: "°" },
    ],
    anim: { key: "th", min: 0, max: 90, speed: 18, label: "평면 기울이기" },
    local(s) {
      if (s.shape === "tri") return { pts: [[-1.6, 0.4], [1.8, 0.8], [0, 3]], area: 0.5 * Math.abs((1.8 + 1.6) * (3 - 0.4) - (0 + 1.6) * (0.8 - 0.4)) };
      if (s.shape === "sq") return { pts: [[-1.2, 0.4], [1.2, 0.4], [1.2, 2.8], [-1.2, 2.8]], area: 2.4 * 2.4 };
      return { pts: Array.from({ length: 72 }, (_, i) => [1.3 * Math.cos((i / 72) * 2 * Math.PI), 1.7 + 1.3 * Math.sin((i / 72) * 2 * Math.PI)]), area: Math.PI * 1.69 };
    },
    draw(s, g) {
      const th = deg(s.th), up = (q) => [q[0], q[1] * Math.cos(th), q[1] * Math.sin(th)], dn = (q) => [q[0], q[1] * Math.cos(th), 0];
      g.plane([0, 1.7, 0], [1, 0, 0], [0, 1, 0], 3, 2.2, { fill: "b", color: "b", fo: 0.1, grid: 0.6 });
      g.plane(up([0, 1.7]), [1, 0, 0], [0, Math.cos(th), Math.sin(th)], 3, 2.2, { fill: "e", color: "e", fo: 0.1 });
      g.seg([-3.4, 0, 0], [3.4, 0, 0], { color: "ink", w: 2.2 });
      const L = this.local(s), U = L.pts.map(up), D = L.pts.map(dn);
      g.face(U, { fill: "a", color: "a", fo: 0.3, w: 2.2, bias: 1 });
      g.face(D, { fill: "d", color: "d", fo: 0.3, w: 2.2, bias: 0.5 });
      (s.shape === "circle" ? U.filter((_, i) => i % 9 === 0) : U).forEach((p, i) => g.seg(p, dn(L.pts[s.shape === "circle" ? i * 9 : i]), { color: "muted", w: 1, dash: "3 4", bias: 0.8 }));
      g.text([3.3, 0, 0], "교선", { color: "ink", dx: 8, anchor: "start", size: 12 });
    },
    metrics(s) { const L = this.local(s), c = Math.cos(deg(s.th)); return [["cos θ", fmt(c, 4)], ["원래 넓이 S", fmt(L.area, 3)], ["정사영 넓이 S cos θ", fmt(L.area * c, 3), "key"], s.shape === "circle" ? s.th === 90 ? "투영면과 수직이면 정사영은 선분입니다. 넓이는 0입니다." : s.th === 0 ? "원판과 투영면이 평행하면 정사영은 같은 크기의 원입니다." : "원의 정사영은 장축 2r과 단축 2r cos θ인 타원입니다." : ""].filter(Boolean); },
  },
  {
    id: "geo-dihedral", grade: G, unit: 2, lesson: "Ⅱ-3", title: "이면각 — 두 평면이 이루는 각", type: "3D", time: "10분",
    tags: ["이면각", "정사면체", "교선"], links: ["geo-projection"],
    desc: "교선 위의 한 점에서 교선에 수직인 두 반직선을 각 평면에 그어 이면각을 만들고, 정사면체의 이면각도 같은 방법으로 구합니다.",
    obs: ["이면각의 크기는 교선에 수직인 두 반직선이 이루는 각입니다.", "교선 위의 점을 옮겨도 그 각의 크기는 같습니다.", "정사면체의 이면각의 코사인 값은 1/3입니다."],
    q: "정육면체의 한 면과 대각면이 이루는 각은 몇 도일까요?",
    formula: "정사면체의 이면각 θ: cos θ = 1/3 (θ ≈ 70.53°)",
    en: { title: "Dihedral Angles", desc: "Build the plane angle of a dihedral angle and apply it to a regular tetrahedron." },
    space: true, cam: { yaw: 50, pitch: 22, scale: 62 },
    params: [
      { key: "mode", label: "보기", type: "seg", value: "base", options: [["base", "두 반평면"], ["tet", "정사면체"]] },
      { key: "th", label: "이면각", min: 10, max: 170, step: 1, value: 70, unit: "°", when: (s) => s.mode === "base" },
      { key: "x", label: "교선 위의 점 위치", min: -1.8, max: 1.8, step: 0.05, value: 0.4, when: (s) => s.mode === "base" },
    ],
    draw(s, g) {
      if (s.mode === "base") {
        const th = deg(s.th), v2 = [0, Math.cos(th), Math.sin(th)];
        g.face([[-2.5, 0, 0], [2.5, 0, 0], [2.5, 2.6, 0], [-2.5, 2.6, 0]], { fill: "b", color: "b", fo: 0.14, bias: -1.5 });
        g.face([[-2.5, 0, 0], [2.5, 0, 0], add([2.5, 0, 0], mul(v2, 2.6)), add([-2.5, 0, 0], mul(v2, 2.6))], { fill: "e", color: "e", fo: 0.14, bias: -1.5 });
        g.seg([-2.8, 0, 0], [2.8, 0, 0], { color: "ink", w: 2.6 });
        const P = [s.x, 0, 0], A = [s.x, 1.8, 0], B = add(P, mul(v2, 1.8));
        g.seg(P, A, { color: "b", w: 3.2, bias: 2 }).seg(P, B, { color: "e", w: 3.2, bias: 2 });
        g.right(P, A, [3, 0, 0], { size: 0.22 }).right(P, B, [3, 0, 0], { size: 0.22 });
        const arc = []; for (let i = 0; i <= 30; i++) { const t = (th * i) / 30; arc.push(add(P, [0, 0.6 * Math.cos(t), 0.6 * Math.sin(t)])); }
        g.path(arc, { color: "a", w: 2.6, bias: 3 });
        g.text(add(P, [0, 0.95 * Math.cos(th / 2), 0.95 * Math.sin(th / 2)]), `${s.th}°`, { color: "a", bold: true });
        g.point(P, "P", { dy: 18 }).point(A, "A", { color: "b" }).point(B, "B", { color: "e" });
      } else {
        const a = 2.4, V = [[0, 0, 0], [a, 0, 0], [a / 2, (a * Math.sqrt(3)) / 2, 0]], c = [a / 2, (a * Math.sqrt(3)) / 6, 0], T = [c[0], c[1], a * Math.sqrt(2 / 3)];
        const sh = (p) => sub(p, [a / 2, a / 3, 0.6]);
        const P = V.map(sh), TT = sh(T);
        g.face([P[0], P[1], P[2]], { fill: "b", color: "b", fo: 0.12 }).face([P[0], P[1], TT], { fill: "e", color: "e", fo: 0.12 });
        g.face([P[1], P[2], TT], { fill: "muted", color: "muted", fo: 0.05 }).face([P[0], P[2], TT], { fill: "muted", color: "muted", fo: 0.05 });
        const M = lerp(P[0], P[1], 0.5);
        g.seg(M, P[2], { color: "b", w: 3, bias: 2 }).seg(M, TT, { color: "e", w: 3, bias: 2 });
        g.right(M, P[2], P[1], { size: 0.18 }).right(M, TT, P[1], { size: 0.18 });
        g.point(M, "M", { dy: 18 }).point(TT, "D").point(P[0], "A", { dy: 18 }).point(P[1], "B", { dy: 18 }).point(P[2], "C");
      }
    },
    metrics(s) {
      if (s.mode === "base") return [["이면각", `${s.th}°`, "key"], "점 P를 교선을 따라 옮겨도 ∠APB는 변하지 않습니다."];
      return [["CM = DM", "정삼각형의 높이 (√3/2)a"], ["cos ∠CMD", "1/3", "key"], ["이면각", `${fmt(rad2deg(Math.acos(1 / 3)), 2)}°`]];
    },
  },
  {
    id: "geo-space-coord", grade: G, unit: 2, lesson: "Ⅱ-4", title: "좌표공간의 거리와 내분점", type: "3D", time: "12분",
    tags: ["공간좌표", "거리", "내분점"], links: ["c2-distance", "c2-division"],
    desc: "두 점의 좌표를 바꾸며 x, y, z 좌표 차를 모서리로 하는 직육면체의 대각선으로 거리를 구하고, 선분을 m : n으로 내분합니다.",
    obs: ["거리 공식은 피타고라스 정리를 두 번 쓴 것입니다.", "내분점 공식은 평면에서와 같은 꼴에 z좌표가 더해집니다."],
    q: "원점과 점 (1, 2, 2) 사이의 거리는 얼마일까요?",
    formula: "AB = √((x₂−x₁)² + (y₂−y₁)² + (z₂−z₁)²) · P = (mB + nA)/(m + n)",
    en: { title: "Distance and Division in Space", desc: "Use the box diagonal for distance in space and divide a segment internally." },
    space: true, cam: { yaw: 36, pitch: 22, scale: 44, center: [1, 1, 1] },
    params: [
      { key: "head", label: "점 A", type: "head" },
      { key: "ax", label: "x₁", min: -2, max: 4, step: 1, value: 3 }, { key: "ay", label: "y₁", min: -2, max: 4, step: 1, value: 0 }, { key: "az", label: "z₁", min: -2, max: 4, step: 1, value: 0 },
      { key: "head2", label: "점 B", type: "head" },
      { key: "bx", label: "x₂", min: -2, max: 4, step: 1, value: 0 }, { key: "by", label: "y₂", min: -2, max: 4, step: 1, value: 3 }, { key: "bz", label: "z₂", min: -2, max: 4, step: 1, value: 2 },
      { key: "m", label: "m", min: 1, max: 5, step: 1, value: 2 }, { key: "n", label: "n", min: 1, max: 5, step: 1, value: 1 },
    ],
    draw(s, g) {
      g.floor(4); g.axes(4.6, { ticks: true });
      const A = [s.ax, s.ay, s.az], B = [s.bx, s.by, s.bz];
      const C1 = [B[0], A[1], A[2]], C2 = [B[0], B[1], A[2]];
      g.seg(A, C1, { color: "b", w: 2.4, dash: "6 4" }).seg(C1, C2, { color: "c", w: 2.4, dash: "6 4" }).seg(C2, B, { color: "e", w: 2.4, dash: "6 4" }).seg(A, C2, { color: "muted", w: 1.4, dash: "3 5" });
      [A, B].forEach((p) => g.seg(p, [p[0], p[1], 0], { color: "muted", w: 1, dash: "2 5" }));
      g.seg(A, B, { color: "a", w: 3.6, bias: 2 });
      const P = lerp(A, B, s.m / (s.m + s.n));
      g.point(A, `A${pt(A)}`, { color: "ink" }).point(B, `B${pt(B)}`, { color: "ink" }).point(P, `P${pt(P)}`, { color: "a", r: 6.5 });
    },
    metrics(s) {
      const A = [s.ax, s.ay, s.az], B = [s.bx, s.by, s.bz], d = sub(B, A), sq = dot(d, d), P = lerp(A, B, s.m / (s.m + s.n));
      return [["Δx, Δy, Δz", `${d.map((v) => fmt(v)).join(", ")}`], ["AB²", fmt(sq)], ["AB", `${surd(sq)} ≈ ${fmt(Math.sqrt(sq))}`, "key"], [`${s.m} : ${s.n} 내분점`, pt(P)]];
    },
  },
  {
    id: "geo-sphere-eq", grade: G, unit: 2, lesson: "Ⅱ-5", title: "구의 방정식과 좌표평면의 단면", type: "3D", time: "10분",
    tags: ["구", "단면의 원", "접함"], links: ["c2-circle-eq", "sphere-area"],
    desc: "중심과 반지름을 바꾸며 구의 방정식을 만들고, 구가 xy평면·yz평면·zx평면과 만나서 생기는 원을 확인합니다.",
    obs: ["구와 xy평면(z = 0)이 만나면 반지름 √(r² − c²)인 원이 생깁니다.", "|c| = r이면 구는 xy평면에 접합니다.", "원의 방정식에 z항이 더해진 꼴입니다."],
    q: "x² + y² + z² − 2x + 4y − 6z + 5 = 0인 구의 중심과 반지름은 무엇일까요?",
    formula: "(x − a)² + (y − b)² + (z − c)² = r²",
    en: { title: "Equation of a Sphere", desc: "Change center and radius and see the circles where the sphere meets the coordinate planes." },
    space: true, cam: { yaw: 36, pitch: 20, scale: 42 },
    params: [
      { key: "a", label: "중심 a", min: -2, max: 3, step: 0.5, value: 1 }, { key: "b", label: "중심 b", min: -2, max: 3, step: 0.5, value: 1.5 }, { key: "c", label: "중심 c", min: -1, max: 3, step: 0.5, value: 1.5 },
      { key: "r", label: "반지름 r", min: 0.5, max: 3, step: 0.1, value: 2 },
      { key: "cut", label: "xy평면과의 단면 보기", type: "check", value: true },
    ],
    draw(s, g) {
      g.floor(4); g.axes(4.6);
      const C = [s.a, s.b, s.c];
      g.sphere(C, s.r, { color: "b" });
      g.seg(C, [s.a, s.b, 0], { color: "muted", w: 1.4, dash: "4 4" });
      if (s.cut && Math.abs(s.c) < s.r) g.circle([s.a, s.b, 0], [1, 0, 0], [0, 1, 0], Math.sqrt(s.r * s.r - s.c * s.c), { color: "a", w: 3.2, fill: "a", fo: 0.25, bias: 1 });
      if (s.cut && Math.abs(Math.abs(s.c) - s.r) < 1e-9) g.point([s.a, s.b, 0], "접점", { color: "a" });
      g.point(C, `C${pt(C)}`, { color: "ink" });
    },
    metrics(s) {
      const r2 = s.r * s.r, k = s.a * s.a + s.b * s.b + s.c * s.c - r2;
      const out = [["표준형", `${shiftSq("x", s.a)} + ${shiftSq("y", s.b)} + ${shiftSq("z", s.c)} = ${fmt(r2)}`, "key"], ["일반형", `${poly([[1, "x²"], [1, "y²"], [1, "z²"], [-2 * s.a, "x"], [-2 * s.b, "y"], [-2 * s.c, "z"]], k)} = 0`]];
      const d = s.r * s.r - s.c * s.c;
      out.push(["xy평면과의 관계", d > 1e-9 ? `반지름 ${fmt(Math.sqrt(d))}인 원` : Math.abs(d) <= 1e-9 ? "접함" : "만나지 않음"]);
      return out;
    },
  },

  // ───────── Ⅲ 벡터 ─────────
  {
    id: "geo-vector-add", grade: G, unit: 3, lesson: "Ⅲ-1", title: "벡터의 덧셈과 뺄셈", type: "2D", time: "10분",
    tags: ["삼각형법", "평행사변형법", "뺄셈"], links: ["geo-vector-scalar"],
    desc: "두 벡터의 끝점을 끌며 삼각형법과 평행사변형법으로 a + b를, 시점을 맞춰 a − b를 만듭니다.",
    obs: ["a + b = b + a (교환법칙)가 평행사변형에서 바로 보입니다.", "a − b는 b의 끝점에서 a의 끝점으로 향하는 벡터입니다.", "크기와 방향이 같으면 위치가 달라도 같은 벡터입니다."],
    q: "|a + b|와 |a| + |b|가 같아지는 때는 언제일까요?",
    formula: "a + b = (a₁ + b₁, a₂ + b₂) · a − b = a + (−b)",
    en: { title: "Adding and Subtracting Vectors", desc: "Drag vector tips to build a + b with the triangle and parallelogram rules, and a − b." },
    view: V, snap: 0.5, points: { A: [4, 1], B: [1, 3] },
    params: [{ key: "mode", label: "연산", type: "seg", value: "par", options: [["tri", "삼각형법"], ["par", "평행사변형법"], ["sub", "뺄셈 a − b"]] }],
    draw(s, g) {
      g.grid();
      const O = [0, 0], a = s.A, b = s.B;
      if (s.mode === "tri") { g.vec(O, a, { color: "a", label: "a" }); g.vec(a, add(a, b), { color: "b", label: "b" }); g.vec(O, add(a, b), { color: "d", label: "a + b", w: 3.6 }); }
      if (s.mode === "par") { g.poly([O, a, add(a, b), b], { fill: "e", fo: 0.08, color: "muted", w: 1.2, dash: "4 5" }); g.vec(O, a, { color: "a", label: "a" }); g.vec(O, b, { color: "b", label: "b" }); g.vec(O, add(a, b), { color: "d", label: "a + b", w: 3.6 }); }
      if (s.mode === "sub") { g.vec(O, a, { color: "a", label: "a" }); g.vec(O, b, { color: "b", label: "b" }); g.vec(b, a, { color: "d", label: "a − b", w: 3.6 }); g.vec(O, sub(a, b), { color: "d", w: 2, opacity: 0.4 }); }
      g.handle(a, "A").handle(b, "B", { color: "b" });
    },
    metrics(s) {
      const a = s.A, b = s.B, r = s.mode === "sub" ? sub(a, b) : add(a, b);
      return [["a", pt(a)], ["b", pt(b)], [s.mode === "sub" ? "a − b" : "a + b", pt(r), "key"], ["크기", `${surd(dot(r, r))} ≈ ${fmt(len(r))}`]];
    },
  },
  {
    id: "geo-vector-scalar", grade: G, unit: 3, lesson: "Ⅲ-2", title: "실수배와 일차결합 — 벡터 격자", type: "2D", time: "12분",
    tags: ["실수배", "일차결합", "격자"], links: ["geo-vector-add", "geo-position-vector"],
    desc: "평행하지 않은 두 벡터로 비스듬한 격자를 만들고, 평면 위의 모든 점을 sa + tb로 나타냅니다.",
    obs: ["a, b가 평행하지 않으면 평면의 모든 벡터를 sa + tb로 한 가지씩 나타낼 수 있습니다.", "a, b가 평행하면 격자가 한 직선으로 찌그러집니다.", "s가 음수이면 a와 반대 방향입니다."],
    q: "a = (1, 2), b = (2, 1)일 때 (4, 5)를 sa + tb로 나타내면 s, t는 얼마일까요?",
    formula: "p = sa + tb (a ∦ b이면 s, t는 하나로 정해짐)",
    en: { title: "Scalar Multiples and Linear Combinations", desc: "Two non-parallel vectors form a skewed grid; every point is sa + tb." },
    view: V, snap: 0.5, points: { A: [2, 0.5], B: [0.5, 1.5] },
    params: [
      { key: "s", label: "s", min: -3, max: 3, step: 0.25, value: 1.5 },
      { key: "t", label: "t", min: -3, max: 3, step: 0.25, value: 2 },
      { key: "grid", label: "벡터 격자 보기", type: "check", value: true },
    ],
    draw(s, g) {
      g.grid({ labels: false });
      const a = s.A, b = s.B;
      if (s.grid && Math.abs(a[0] * b[1] - a[1] * b[0]) > 1e-6) for (let k = -8; k <= 8; k++) { g.line(mul(b, k), add(mul(b, k), a), { color: "a", w: 1, opacity: 0.35 }); g.line(mul(a, k), add(mul(a, k), b), { color: "b", w: 1, opacity: 0.35 }); }
      const P = add(mul(a, s.s), mul(b, s.t));
      g.vec([0, 0], mul(a, s.s), { color: "a", w: 3, label: `${fmt(s.s)}a` });
      g.vec(mul(a, s.s), P, { color: "b", w: 3, label: `${fmt(s.t)}b` });
      g.vec([0, 0], P, { color: "d", w: 3.6, label: "p" });
      g.vec([0, 0], a, { color: "a", w: 4, opacity: 0.6 }).vec([0, 0], b, { color: "b", w: 4, opacity: 0.6 });
      g.handle(a, "A").handle(b, "B", { color: "b" });
    },
    metrics(s) { const P = add(mul(s.A, s.s), mul(s.B, s.t)), det = s.A[0] * s.B[1] - s.A[1] * s.B[0]; return [["p = sa + tb", pt(P), "key"], ["a, b의 관계", Math.abs(det) < 1e-9 ? "평행 (격자가 만들어지지 않음)" : "평행하지 않음"]]; },
  },
  {
    id: "geo-position-vector", grade: G, unit: 3, lesson: "Ⅲ-3", title: "위치벡터로 본 내분점과 무게중심", type: "2D", time: "10분",
    tags: ["위치벡터", "내분점", "무게중심"], links: ["c2-division", "c2-centroid"],
    desc: "원점 O를 시점으로 하는 위치벡터로 선분의 내분점과 삼각형의 무게중심을 나타냅니다.",
    obs: ["내분점의 위치벡터는 두 끝점 위치벡터의 가중평균입니다.", "무게중심의 위치벡터는 세 꼭짓점 위치벡터의 평균입니다.", "좌표로 나타내면 공통수학2의 공식과 같습니다."],
    q: "OP = (2a + 3b)/5이면 점 P는 선분 AB를 어떤 비로 나눌까요?",
    formula: "p = (mb + na)/(m + n) · g = (a + b + c)/3",
    en: { title: "Position Vectors", desc: "Express dividing points and centroids with position vectors from O." },
    view: V, snap: 0.5, points: { A: [-4, 3], B: [4, 2], C: [1, -3.5] },
    params: [
      { key: "mode", label: "보기", type: "seg", value: "div", options: [["div", "내분점"], ["cen", "무게중심"]] },
      { key: "m", label: "m", min: 1, max: 5, step: 1, value: 2, when: (s) => s.mode === "div" },
      { key: "n", label: "n", min: 1, max: 5, step: 1, value: 3, when: (s) => s.mode === "div" },
    ],
    draw(s, g) {
      g.grid({ labels: false });
      const O = [-5.5, -3.5];
      g.point(O, "O", { color: "ink", dx: -12, anchor: "end" });
      const pts = s.mode === "div" ? [s.A, s.B] : [s.A, s.B, s.C];
      const names = ["a", "b", "c"], cols = ["a", "b", "c"];
      pts.forEach((p, i) => g.vec(O, p, { color: cols[i], w: 2.4, label: names[i], opacity: 0.85 }));
      let P;
      if (s.mode === "div") { g.seg(s.A, s.B, { color: "ink", w: 2 }); P = lerp(s.A, s.B, s.m / (s.m + s.n)); }
      else { g.poly([s.A, s.B, s.C], { fill: "e", fo: 0.08, color: "ink", w: 2 }); P = mul(add(add(s.A, s.B), s.C), 1 / 3); }
      g.vec(O, P, { color: "d", w: 3.6, label: s.mode === "div" ? "p" : "g" });
      g.point(P, s.mode === "div" ? "P" : "G", { color: "d", r: 6 });
      pts.forEach((p, i) => { g.point(p, "ABC"[i], { color: "ink" }); g.handle(p, "ABC"[i], { color: cols[i] }); });
    },
    metrics(s) {
      const O = [-5.5, -3.5], rel = (p) => sub(p, O);
      if (s.mode === "div") { const P = lerp(s.A, s.B, s.m / (s.m + s.n)); return [["p", `(${s.m}b + ${s.n}a) / ${s.m + s.n}`, "key"], ["O 기준 성분", pt(rel(P))]]; }
      const G2 = mul(add(add(s.A, s.B), s.C), 1 / 3); return [["g", "(a + b + c) / 3", "key"], ["O 기준 성분", pt(rel(G2))]];
    },
  },
  {
    id: "geo-vector-component", grade: G, unit: 3, lesson: "Ⅲ-4", title: "벡터의 성분과 농구공의 위치벡터", type: "2D", time: "12분",
    tags: ["성분", "단위벡터", "포물 운동"], links: ["geo-vector-add", "calc-param-motion"],
    desc: "벡터를 단위벡터 e₁, e₂ 방향으로 나누어 성분으로 나타내고, 쏘아 올린 농구공의 위치벡터를 수평·수직 성분으로 분해합니다.",
    obs: ["a = a₁e₁ + a₂e₂이고 |a| = √(a₁² + a₂²)입니다.", "a/|a|는 a와 방향이 같은 단위벡터입니다.", "농구공의 수평 성분은 일정하게, 수직 성분은 이차식으로 변합니다."],
    q: "농구공이 가장 높이 올라갔을 때 속도의 수직 성분은 얼마일까요?",
    formula: "a = (a₁, a₂) = a₁e₁ + a₂e₂ · |a| = √(a₁² + a₂²)",
    en: { title: "Components and a Basketball's Position Vector", desc: "Decompose vectors along unit vectors and follow a basketball's position vector." },
    view: V, snap: 0.5, points: { A: [4, 3] },
    params: [
      { key: "mode", label: "보기", type: "seg", value: "comp", options: [["comp", "성분 분해"], ["ball", "농구공"]] },
      { key: "v", label: "처음 속력", min: 6, max: 11, step: 0.5, value: 9, when: (s) => s.mode === "ball" },
      { key: "ang", label: "던진 각", min: 30, max: 75, step: 1, value: 55, unit: "°", when: (s) => s.mode === "ball" },
      { key: "t", label: "시각 t (초)", min: 0, max: 2, step: 0.01, value: 0.7, when: (s) => s.mode === "ball" },
    ],
    anim: { key: "t", min: 0, max: 2, speed: 0.6, loop: "wrap", label: "공 던지기" },
    ball(s, t) { const k = 0.55, g0 = 9.8; return [-6 + k * s.v * Math.cos(deg(s.ang)) * t, -3.5 + k * (s.v * Math.sin(deg(s.ang)) * t - 0.5 * g0 * t * t)]; },
    draw(s, g) {
      g.grid({ labels: s.mode === "comp" });
      if (s.mode === "comp") {
        const a = s.A;
        g.vec([0, 0], [a[0], 0], { color: "b", w: 3, label: `${fmt(a[0])}e₁`, dy: 20 }).vec([a[0], 0], a, { color: "c", w: 3, label: `${fmt(a[1])}e₂` });
        g.vec([0, 0], [1, 0], { color: "ink", w: 4 }).vec([0, 0], [0, 1], { color: "ink", w: 4 });
        g.text([0.5, 0], "e₁", { dy: 22, italic: true, color: "ink" }).text([0, 0.5], "e₂", { dx: -14, italic: true, color: "ink" });
        const l = len(a); if (l > 0.1) g.vec([0, 0], mul(a, 1 / l), { color: "d", w: 4 });
        g.circle([0, 0], 1, { color: "d", w: 1, dash: "3 5" });
        g.vec([0, 0], a, { color: "a", w: 3.4, label: "a" });
        g.handle(a, "A");
      } else {
        const O = [-6, -3.5];
        g.seg([-7, -3.5], [7, -3.5], { color: "ink", w: 2 });
        g.param((t) => this.ball(s, t), 0, 2.2, { color: "muted", w: 1.4, dash: "4 6" });
        const P = this.ball(s, s.t);
        g.vec(O, [P[0], O[1]], { color: "b", w: 2.6, label: "수평 성분", dy: 20 }).vec([P[0], O[1]], P, { color: "c", w: 2.6, label: "수직 성분" });
        g.vec(O, P, { color: "a", w: 3.4, label: "p(t)" });
        g.circle(P, 0.28, { color: "f", fill: "f", fo: 0.9, w: 1.6 });
        g.seg([5.2, -3.5], [5.2, 0.4], { color: "muted", w: 3 }).seg([4.6, 0.4], [5.2, 0.4], { color: "d", w: 3 });
      }
    },
    metrics(s) {
      if (s.mode === "comp") { const a = s.A, l = len(a); return [["성분", pt(a), "key"], ["|a|", `${surd(dot(a, a))} ≈ ${fmt(l)}`], ["단위벡터 a/|a|", l ? pt2(mul(a, 1 / l)) : "—"]]; }
      const vx = s.v * Math.cos(deg(s.ang)), vy = s.v * Math.sin(deg(s.ang));
      return [["위치 (m)", `(${fmt(vx * s.t)}, ${fmt(vy * s.t - 4.9 * s.t * s.t)})`, "key"], ["수평 성분", `${fmt(vx, 2)} t`], ["수직 성분", `${fmt(vy, 2)} t − 4.9 t²`]];
    },
  },
  {
    id: "geo-dot-product", grade: G, unit: 3, lesson: "Ⅲ-5", title: "벡터의 내적과 정사영", type: "2D", time: "12분",
    tags: ["내적", "사잇각", "수직"], links: ["c2-parallel-perp", "alg-cosine-law", "geo-projection"],
    desc: "두 벡터의 끝점을 끌며 a · b = |a||b|cos θ를 a 방향으로 내린 b의 정사영 길이로 보고, 성분 계산 a₁b₁ + a₂b₂와 비교합니다.",
    obs: ["θ가 예각이면 내적은 양수, 둔각이면 음수, 직각이면 0입니다.", "a · b = |a| × (b의 a 방향 정사영의 부호 있는 길이)입니다.", "두 계산 방법의 값은 항상 같습니다."],
    q: "a · b = 0이면 두 벡터는 어떤 관계일까요?",
    formula: "a · b = |a||b|cos θ = a₁b₁ + a₂b₂",
    en: { title: "Dot Product and Projection", desc: "See a · b = |a||b|cos θ as a projection and compare with a₁b₁ + a₂b₂." },
    view: V, snap: 0.5, points: { A: [5, 1], B: [2, 3.5] },
    draw(s, g) {
      g.grid();
      const a = s.A, b = s.B, l = len(a) || 1, u = mul(a, 1 / l), pr = dot(b, u), Pb = mul(u, pr), d = dot(a, b);
      g.line([0, 0], a, { color: "muted", w: 1, dash: "3 6" });
      g.seg(b, Pb, { color: "muted", w: 1.6, dash: "5 4" });
      if (len(sub(b, Pb)) > 0.3 && Math.abs(pr) > 0.2) g.right(Pb, b, [0, 0], { size: 10 });
      g.seg([0, 0], Pb, { color: d >= 0 ? "c" : "d", w: 6, opacity: 0.6 });
      g.text(mul(Pb, 0.5), `정사영 ${fmt(pr)}`, { dy: 22, color: d >= 0 ? "c" : "d", bold: true, size: 13 });
      g.arc([0, 0], a, b, { r: 30, color: "e", ccw: false, label: `${fmt(rad2deg(Math.acos(clamp(d / (l * (len(b) || 1)), -1, 1))), 1)}°` });
      g.vec([0, 0], a, { color: "a", label: "a", w: 3.4 }).vec([0, 0], b, { color: "b", label: "b", w: 3.4 });
      g.handle(a, "A").handle(b, "B", { color: "b" });
    },
    metrics(s) {
      const a = s.A, b = s.B, d = dot(a, b), la = len(a), lb = len(b), th = Math.acos(clamp(d / (la * lb || 1), -1, 1));
      return [["a₁b₁ + a₂b₂", `${fmt(a[0])}·${fmt(b[0])} + ${fmt(a[1])}·${fmt(b[1])} = ${fmt(d)}`], ["|a||b|cos θ", `${fmt(la)} × ${fmt(lb)} × ${fmt(Math.cos(th), 3)} = ${fmt(la * lb * Math.cos(th))}`], ["a · b", fmt(d), "key"], ["관계", Math.abs(d) < 1e-9 ? "수직 (a · b = 0)" : d > 0 ? "사잇각이 예각" : "사잇각이 둔각"]];
    },
  },

  // ───────── Ⅳ 벡터의 활용 ─────────
  {
    id: "geo-vector-line", grade: G, unit: 4, lesson: "Ⅳ-1", title: "벡터로 나타낸 직선의 방정식", type: "조작", time: "12분",
    tags: ["방향벡터", "법선벡터", "매개변수"], links: ["c2-line-eq", "geo-space-line"],
    desc: "한 점 A와 방향벡터 u로 p = a + tu를 만들어 t를 움직이고, 법선벡터 n으로 n · (p − a) = 0 꼴의 직선도 만듭니다.",
    obs: ["t가 변하면 점 P가 직선 위를 움직입니다.", "방향벡터 (u₁, u₂)로 (x − x₁)/u₁ = (y − y₁)/u₂를 얻습니다.", "법선벡터 (a, b)인 직선은 ax + by + c = 0 꼴입니다."],
    q: "방향벡터가 (2, 3)인 직선의 법선벡터 하나를 말해 보세요.",
    formula: "p = a + tu · (x − x₁)/u₁ = (y − y₁)/u₂ · n · (p − a) = 0",
    en: { title: "Vector Equations of Lines", desc: "Build p = a + tu with a direction vector, and n · (p − a) = 0 with a normal vector." },
    view: V, snap: 0.5, points: { A: [-2, -1], U: [0, 1] },
    params: [
      { key: "mode", label: "벡터", type: "seg", value: "dir", options: [["dir", "방향벡터 u"], ["nor", "법선벡터 n"]] },
      { key: "t", label: "t", min: -3, max: 3, step: 0.05, value: 1.2, when: (s) => s.mode === "dir" },
    ],
    anim: { key: "t", min: -3, max: 3, speed: 1.4, label: "t 움직이기" },
    draw(s, g) {
      g.grid();
      const a = s.A, u = sub(s.U, a);
      if (len(u) < 0.1) { g.point(a, "A"); g.handle(a, "A").handle(s.U, "U", { color: "b" }); return; }
      const dir = s.mode === "dir" ? u : [-u[1], u[0]];
      g.line(a, add(a, dir), { color: "a", w: 3 });
      if (s.mode === "dir") { const P = add(a, mul(u, s.t)); g.vec(a, P, { color: "e", w: 2, opacity: 0.6 }); g.point(P, `P (t = ${fmt(s.t)})`, { color: "d", r: 6.5 }); g.vec(a, s.U, { color: "b", w: 3.4, label: "u" }); }
      else { g.vec(a, s.U, { color: "b", w: 3.4, label: "n" }); g.right(a, s.U, add(a, dir), { size: 12 }); }
      g.point(a, `A${pt(a)}`, { color: "ink" });
      g.handle(a, "A").handle(s.U, "U", { color: "b" });
    },
    metrics(s) {
      const a = s.A, u = sub(s.U, a);
      if (len(u) < 0.1) return ["벡터의 끝점을 A와 다른 곳에 두세요."];
      if (s.mode === "dir") { const eq = u[0] && u[1] ? `(x − ${frac(a[0])})/${frac(u[0])} = (y − ${frac(a[1])})/${frac(u[1])}` : u[0] ? `y = ${frac(a[1])}` : `x = ${frac(a[0])}`; return [["방향벡터 u", pt(u)], ["직선", eq, "key"], ["P", pt2(add(a, mul(u, s.t)))]]; }
      return [["법선벡터 n", pt(u)], ["직선", `${poly([[u[0], "x"], [u[1], "y"]], -dot(u, a))} = 0`, "key"]];
    },
  },
  {
    id: "geo-space-line", grade: G, unit: 4, lesson: "Ⅳ-1", title: "좌표공간의 직선", type: "3D", time: "10분",
    tags: ["공간 직선", "방향벡터", "3D"], links: ["geo-vector-line", "geo-plane-eq"],
    desc: "좌표공간에서 한 점과 방향벡터로 직선을 만들고, t를 바꾸며 직선 위의 점과 좌표평면과의 교점을 찾습니다.",
    obs: ["공간의 직선도 p = a + tu 꼴입니다.", "방향벡터의 성분 가운데 0이 있으면 그 좌표는 일정합니다.", "z = 0이 되는 t로 xy평면과의 교점을 구합니다."],
    q: "점 (1, 2, 3)을 지나고 방향벡터가 (1, −1, 2)인 직선이 xy평면과 만나는 점은?",
    formula: "(x − x₁)/u₁ = (y − y₁)/u₂ = (z − z₁)/u₃",
    en: { title: "Lines in Space", desc: "Build a line in space from a point and a direction vector and find where it meets the xy-plane." },
    space: true, cam: { yaw: 36, pitch: 22, scale: 40 },
    params: [
      { key: "ax", label: "A의 x", min: -2, max: 3, step: 1, value: 1 }, { key: "ay", label: "A의 y", min: -2, max: 3, step: 1, value: 2 }, { key: "az", label: "A의 z", min: 0, max: 4, step: 1, value: 3 },
      { key: "ux", label: "u₁", min: -2, max: 2, step: 1, value: 1 }, { key: "uy", label: "u₂", min: -2, max: 2, step: 1, value: -1 }, { key: "uz", label: "u₃", min: -2, max: 2, step: 1, value: 2 },
      { key: "t", label: "t", min: -3, max: 3, step: 0.05, value: 0.5 },
    ],
    anim: { key: "t", min: -3, max: 3, speed: 1.5, label: "t 움직이기" },
    draw(s, g) {
      g.floor(4); g.axes(4.6);
      const A = [s.ax, s.ay, s.az], u = [s.ux, s.uy, s.uz];
      if (len(u) < 1e-9) { g.point(A, "A"); return; }
      g.seg(add(A, mul(u, -3.5)), add(A, mul(u, 3.5)), { color: "a", w: 3, bias: 1 });
      g.vec(A, add(A, u), { color: "b", w: 3.4, label: "u" });
      const P = add(A, mul(u, s.t));
      g.seg(P, [P[0], P[1], 0], { color: "muted", w: 1, dash: "3 4" });
      if (u[2]) { const t0 = -A[2] / u[2], Z = add(A, mul(u, t0)); if (Math.abs(Z[0]) < 5 && Math.abs(Z[1]) < 5) g.point(Z, "xy평면과의 교점", { color: "d" }); }
      g.point(A, `A${pt(A)}`, { color: "ink" }).point(P, "P", { color: "d", r: 6 });
    },
    metrics(s) {
      const A = [s.ax, s.ay, s.az], u = [s.ux, s.uy, s.uz];
      if (len(u) < 1e-9) return ["방향벡터가 영벡터이면 직선이 정해지지 않습니다."];
      const part = (v, a, k) => (k ? `(${v} − ${fmt(a)})/${fmt(k)}` : null);
      const eqs = [part("x", A[0], u[0]), part("y", A[1], u[1]), part("z", A[2], u[2])].filter(Boolean).join(" = ");
      const fixed = ["x", "y", "z"].filter((_, i) => !u[i]).map((v, i) => `${v} = ${fmt(A[["x", "y", "z"].indexOf(v)])}`).join(", ");
      const out = [["직선", eqs + (fixed ? `, ${fixed}` : ""), "key"], ["P(t)", pt2(add(A, mul(u, s.t)))]];
      if (u[2]) out.push(["xy평면과의 교점", pt2(add(A, mul(u, -A[2] / u[2])))]);
      return out;
    },
  },
  {
    id: "geo-plane-eq", grade: G, unit: 4, lesson: "Ⅳ-2", title: "법선벡터로 만드는 평면의 방정식", type: "3D", time: "12분",
    tags: ["법선벡터", "평면", "절편"], links: ["geo-space-line", "geo-three-perp"],
    desc: "한 점 A와 법선벡터 n으로 평면을 만들고, 평면 위의 점 P에 대해 AP ⟂ n임을 확인하며 절편과 원점까지의 거리를 봅니다.",
    obs: ["평면 위의 모든 점 P에 대해 n · (p − a) = 0입니다.", "법선벡터의 성분이 평면의 방정식 ax + by + cz + d = 0의 계수가 됩니다.", "원점에서 평면까지의 거리는 |d|/|n|입니다."],
    q: "평면 2x − y + 2z = 6의 x, y, z절편은 무엇일까요?",
    formula: "a(x − x₁) + b(y − y₁) + c(z − z₁) = 0 · 거리 = |d|/√(a² + b² + c²)",
    en: { title: "Planes from Normal Vectors", desc: "Build a plane from a point and a normal vector and check AP ⟂ n." },
    space: true, cam: { yaw: 38, pitch: 22, scale: 40 },
    params: [
      { key: "a", label: "n의 a", min: -2, max: 3, step: 1, value: 1 }, { key: "b", label: "n의 b", min: -2, max: 3, step: 1, value: 1 }, { key: "c", label: "n의 c", min: -2, max: 3, step: 1, value: 2 },
      { key: "px", label: "A의 x", min: -1, max: 3, step: 1, value: 1 }, { key: "py", label: "A의 y", min: -1, max: 3, step: 1, value: 1 }, { key: "pz", label: "A의 z", min: 0, max: 3, step: 1, value: 1 },
      { key: "u", label: "점 P 이동 (평면 위)", min: -2, max: 2, step: 0.05, value: 1.2 },
    ],
    anim: { key: "u", min: -2, max: 2, speed: 1.2, label: "P 움직이기" },
    draw(s, g) {
      g.axes(4.6);
      const n = [s.a, s.b, s.c], A = [s.px, s.py, s.pz];
      if (len(n) < 1e-9) { g.point(A, "A"); return; }
      const e1 = norm(Math.abs(n[2]) < 0.9 * len(n) ? cross(n, [0, 0, 1]) : cross(n, [1, 0, 0])), e2 = norm(cross(n, e1));
      g.plane(A, e1, e2, 2.6, 2.6, { fill: "b", color: "b", fo: 0.18, grid: 0.65 });
      const nn = norm(n);
      g.vec(A, add(A, mul(nn, 1.8)), { color: "a", w: 3.4, label: "n" });
      const P = add(A, add(mul(e1, s.u), mul(e2, 0.7 * Math.sin(s.u * 1.3))));
      g.vec(A, P, { color: "c", w: 2.6 });
      g.right(A, add(A, nn), P, { size: 0.3 });
      const d = -dot(n, A);
      [[0, "x"], [1, "y"], [2, "z"]].forEach(([i]) => { if (n[i]) { const X = [0, 0, 0]; X[i] = -d / n[i]; if (Math.abs(X[i]) < 6) g.point(X, "", { color: "e", r: 4.5 }); } });
      const H = mul(n, -d / dot(n, n)); g.seg([0, 0, 0], H, { color: "d", w: 1.8, dash: "4 4" });
      g.point(A, "A", { color: "ink" }).point(P, "P", { color: "c" });
    },
    metrics(s) {
      const n = [s.a, s.b, s.c], A = [s.px, s.py, s.pz];
      if (len(n) < 1e-9) return ["법선벡터가 영벡터이면 평면이 정해지지 않습니다."];
      const d = -dot(n, A), ints = ["x", "y", "z"].map((v, i) => (n[i] ? `${v}: ${frac(-d / n[i])}` : `${v}: 없음`)).join(" · ");
      return [["평면", `${poly([[n[0], "x"], [n[1], "y"], [n[2], "z"]], d)} = 0`, "key"], ["n · AP", "0 (항상 수직)"], ["절편", ints], ["원점까지 거리", `|${fmt(d)}|/${surd(dot(n, n))} ≈ ${fmt(Math.abs(d) / len(n), 3)}`]];
    },
  },
  {
    id: "geo-bezier", grade: G, unit: 4, lesson: "Ⅳ 프로젝트", title: "내분을 되풀이해 그리는 베지어 곡선", type: "조작", time: "12분",
    tags: ["베지어 곡선", "내분", "컴퓨터 그래픽"], links: ["c2-division", "geo-position-vector"],
    desc: "조절점을 끌고 t를 움직이며, 이웃한 점을 t : (1 − t)로 내분하는 과정을 되풀이해 부드러운 곡선을 만듭니다.",
    obs: ["2차 곡선은 내분을 두 번, 3차 곡선은 세 번 되풀이합니다.", "곡선은 처음과 끝 조절점을 지나지만 가운데 조절점은 지나지 않습니다.", "곡선은 조절점이 만드는 다각형 안에 있습니다."],
    q: "글꼴이나 자동차 디자인에서 베지어 곡선을 쓰면 어떤 점이 편할까요?",
    formula: "B(t) = (1 − t)³P₀ + 3(1 − t)²tP₁ + 3(1 − t)t²P₂ + t³P₃",
    en: { title: "Bézier Curves by Repeated Division", desc: "Repeat internal division of neighboring points to build a smooth curve." },
    view: V, points: { P0: [-5.5, -3], P1: [-3, 3.5], P2: [2.5, 3.8], P3: [5.5, -2.5] },
    params: [
      { key: "deg", label: "차수", type: "seg", value: 3, options: [[2, "2차 (점 3개)"], [3, "3차 (점 4개)"]] },
      { key: "t", label: "t", min: 0, max: 1, step: 0.005, value: 0.4 },
    ],
    anim: { key: "t", min: 0, max: 1, speed: 0.3, label: "곡선 그리기" },
    draw(s, g) {
      g.grid({ labels: false });
      const P = s.deg === 3 ? [s.P0, s.P1, s.P2, s.P3] : [s.P0, s.P1, s.P3];
      const B = (t) => { let L = P; while (L.length > 1) L = L.slice(1).map((q, i) => lerp(L[i], q, t)); return L[0]; };
      g.path(P, { color: "muted", w: 1.6, dash: "5 5" });
      g.param(B, 0, 1, { color: "muted", w: 1.6, opacity: 0.5 });
      g.param(B, 0, s.t, { color: "a", w: 4 });
      let L = P, lvl = 0; const cols = ["b", "c", "e"];
      while (L.length > 1) { L = L.slice(1).map((q, i) => lerp(L[i], q, s.t)); if (L.length > 1) { g.path(L, { color: cols[lvl], w: 2 }); L.forEach((q) => g.point(q, "", { color: cols[lvl], r: 4 })); } lvl++; }
      g.point(B(s.t), "B(t)", { color: "a", r: 7 });
      P.forEach((q, i) => { const k = ["P0", "P1", "P2", "P3"][s.deg === 3 ? i : [0, 1, 3][i]]; g.point(q, k.replace("P", "P"), { color: "ink" }); g.handle(q, k); });
    },
    metrics(s) { const P = s.deg === 3 ? [s.P0, s.P1, s.P2, s.P3] : [s.P0, s.P1, s.P3]; let L = P; while (L.length > 1) L = L.slice(1).map((q, i) => lerp(L[i], q, s.t)); return [["t", fmt(s.t, 3)], ["B(t)", pt2(L[0]), "key"], ["내분 횟수", `${s.deg}번`]]; },
  },
];
