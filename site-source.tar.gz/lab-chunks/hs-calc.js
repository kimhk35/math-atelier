// 미적분Ⅰ·Ⅱ — 도형과 관련된 시각화: 접선·넓이·부피·운동
import { fmt, frac, piFmt, dist, sub, add, mul, norm, dot, len, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const G = 7;
const FUN = {
  sq: { name: "y = x²/2", f: (x) => x * x / 2, d: (x) => x, F: (x) => x ** 3 / 6 },
  cub: { name: "y = (x³ − 6x)/4", f: (x) => (x ** 3 - 6 * x) / 4, d: (x) => (3 * x * x - 6) / 4, F: (x) => (x ** 4 / 4 - 3 * x * x) / 4 },
  quar: { name: "y = (x⁴ − 8x²)/8 + 1", f: (x) => (x ** 4 - 8 * x * x) / 8 + 1, d: (x) => (4 * x ** 3 - 16 * x) / 8, F: (x) => (x ** 5 / 5 - 8 * x ** 3 / 3) / 8 + x },
  sin: { name: "y = 2 sin x", f: (x) => 2 * Math.sin(x), d: (x) => 2 * Math.cos(x), F: (x) => -2 * Math.cos(x) },
};
const funOpts = (keys) => keys.map((k) => [k, FUN[k].name]);

export default [
  {
    id: "calc-secant-tangent", grade: 7, unit: 2, lesson: "Ⅱ-1", title: "할선에서 접선으로 — 미분계수", type: "조작", time: "10분",
    tags: ["평균변화율", "순간변화율", "극한"], links: ["c2-line-eq", "calc-derivative-graph"],
    desc: "두 점을 지나는 할선에서 h를 0으로 보내며 기울기가 접선의 기울기, 즉 미분계수로 다가가는 과정을 봅니다.",
    obs: ["할선의 기울기는 평균변화율 (f(a + h) − f(a))/h입니다.", "h가 0에 가까워질수록 할선은 접선에 가까워집니다.", "h가 음수여도 같은 값으로 다가갑니다."],
    q: "그래프가 뾰족하게 꺾인 점에서도 h → 0일 때 할선의 기울기가 하나로 모일까요?",
    formula: "f′(a) = lim(h→0) (f(a + h) − f(a)) / h",
    en: { title: "From Secant to Tangent", desc: "Send h to zero and watch secant slopes approach the derivative." },
    view: { x: [-5, 5], y: [-4, 5] },
    params: [
      { key: "fn", label: "함수", type: "select", value: "sq", options: funOpts(["sq", "cub", "sin"]) },
      { key: "a", label: "a", min: -3, max: 3, step: 0.1, value: 1 },
      { key: "h", label: "h", min: -3, max: 3, step: 0.01, value: 2 },
    ],
    anim: { key: "h", min: 0.01, max: 3, speed: 0.9, label: "h를 0으로" },
    derive(s) { if (Math.abs(s.h) < 0.01) s.h = 0.01; },
    drags: { A: { at: (s) => [s.a, FUN[s.fn].f(s.a)], move: (s, p) => (s.a = p[0]) }, B: { at: (s) => [s.a + s.h, FUN[s.fn].f(s.a + s.h)], move: (s, p) => { s.h = p[0] - s.a; if (Math.abs(s.h) < 0.01) s.h = 0.01; }, color: "b" } },
    draw(s, g) {
      g.grid();
      const F = FUN[s.fn], A = [s.a, F.f(s.a)], B = [s.a + s.h, F.f(s.a + s.h)];
      g.fx(F.f, { color: "a", w: 3.2 });
      g.line(A, add(A, [1, F.d(s.a)]), { color: "c", w: 2, dash: "7 5" });
      g.line(A, B, { color: "b", w: 2.8 });
      g.seg(A, [B[0], A[1]], { color: "muted", w: 1.4, dash: "4 4" }).seg([B[0], A[1]], B, { color: "muted", w: 1.4, dash: "4 4" });
      g.text([(A[0] + B[0]) / 2, A[1]], `h = ${fmt(s.h)}`, { dy: 18, color: "muted", size: 13 });
      g.point(A, "A", { color: "ink" }).point(B, "B", { color: "b" });
    },
    metrics(s) { const F = FUN[s.fn], m = (F.f(s.a + s.h) - F.f(s.a)) / s.h; return [["할선의 기울기", fmt(m, 4)], ["접선의 기울기 f′(a)", fmt(F.d(s.a), 4), "key"], ["차이", fmt(m - F.d(s.a), 4)]]; },
  },
  {
    id: "calc-derivative-graph", grade: 7, unit: 3, lesson: "Ⅲ-2", title: "도함수의 부호와 그래프의 개형", type: "2D", time: "12분",
    tags: ["증가·감소", "극값", "도함수"], links: ["calc-secant-tangent", "calc-mean-value"],
    desc: "위에는 y = f(x)와 접선을, 아래에는 y = f′(x)를 나란히 두고 점을 움직이며 f′의 부호와 f의 증가·감소, 극대·극소를 연결합니다.",
    obs: ["f′(x) > 0인 구간에서 f는 증가합니다.", "f′의 부호가 +에서 −로 바뀌는 점에서 f는 극대입니다.", "접선의 기울기가 아래 그래프의 높이가 됩니다."],
    q: "f′(a) = 0이면 x = a에서 반드시 극값을 가질까요?",
    formula: "f′(x) > 0 ⇒ 증가 · f′(x) < 0 ⇒ 감소 · 부호 변화 + → − : 극대",
    en: { title: "Derivative Sign and Graph Shape", desc: "Link the sign of f′ with increasing, decreasing and extrema of f." },
    view: { x: [-4, 4], y: [-5.2, 5.2] },
    params: [
      { key: "fn", label: "함수", type: "select", value: "cub", options: funOpts(["cub", "quar", "sin"]) },
      { key: "x", label: "x", min: -3.6, max: 3.6, step: 0.02, value: -0.6 },
    ],
    anim: { key: "x", min: -3.6, max: 3.6, speed: 1.2, label: "점 움직이기" },
    drags: { X: { at: (s) => [s.x, clamp(2.6 + 0.6 * FUN[s.fn].f(s.x), 0.2, 5.2)], move: (s, p) => (s.x = p[0]) } },
    draw(s, g) {
      const F = FUN[s.fn], up = 2.6, dn = -2.6, k = 0.6;
      g.grid({ labels: false, axes: false });
      g.seg([-4, up], [4, up], { color: "axis", w: 1.3 }).seg([-4, dn], [4, dn], { color: "axis", w: 1.3 });
      g.text([-3.9, up + 2.3], "y = f(x)", { anchor: "start", color: "a", bold: true }).text([-3.9, dn + 2.3], "y = f′(x)", { anchor: "start", color: "b", bold: true });
      const fU = (x) => clamp(up + k * F.f(x), 0.2, 5.2), fD = (x) => dn + k * F.d(x);
      for (let i = 0; i < 400; i++) { const x0 = -4 + (8 * i) / 400, x1 = x0 + 8 / 400, dv = F.d((x0 + x1) / 2); if (Math.abs(dv) > 1e-9) g.seg([x0, dn], [x1, dn], { color: dv > 0 ? "c" : "d", w: 6, opacity: 0.35 }); }
      const band = (v, lo, hi) => (v >= lo && v <= hi ? v : NaN);
      g.fx((x) => band(up + k * F.f(x), 0.1, 5.2), { color: "a", w: 3.2 }).fx((x) => band(fD(x), -5.2, -0.1), { color: "b", w: 3 });
      const P = [s.x, up + k * F.f(s.x)], m = F.d(s.x);
      g.seg(add(P, [-1.2, -1.2 * k * m]), add(P, [1.2, 1.2 * k * m]), { color: "c", w: 2.6 });
      g.seg(P, [s.x, fD(s.x)], { color: "muted", w: 1, dash: "3 4" });
      g.point(P, "", { color: "a", r: 6 }).point([s.x, fD(s.x)], "", { color: "b", r: 6 });
      for (let i = 0; i < 800; i++) { const x0 = -4 + (8 * i) / 800, x1 = x0 + 0.01; if (F.d(x0) * F.d(x1) < 0) { const ex = (x0 + x1) / 2; g.point([ex, up + k * F.f(ex)], F.d(x0) > 0 ? "극대" : "극소", { color: "e", r: 4.5, dy: F.d(x0) > 0 ? -12 : 22, anchor: "middle", dx: 0 }); } }
    },
    metrics(s) { const F = FUN[s.fn], m = F.d(s.x); return [["x", fmt(s.x)], ["f′(x)", fmt(m, 3), "key"], ["f의 상태", Math.abs(m) < 0.02 ? "접선이 수평" : m > 0 ? "증가 중" : "감소 중"]]; },
  },
  {
    id: "calc-mean-value", grade: 7, unit: 3, lesson: "Ⅲ-1", title: "평균값 정리", type: "2D", time: "10분",
    tags: ["평균값 정리", "롤의 정리", "평행한 접선"], links: ["calc-secant-tangent"],
    desc: "구간 [a, b]의 양 끝을 이은 할선과 기울기가 같은 접선이 구간 안에 반드시 있음을 찾아봅니다.",
    obs: ["f(a) = f(b)이면 수평인 접선이 생깁니다(롤의 정리).", "그런 점 c가 여러 개일 수도 있습니다.", "과속 단속 구간의 평균 속력과 같은 순간 속력이 반드시 있다는 뜻입니다."],
    q: "구간 단속에서 평균 속력이 110 km/h였다면 어떤 결론을 내릴 수 있을까요?",
    formula: "f′(c) = (f(b) − f(a)) / (b − a), a < c < b",
    en: { title: "Mean Value Theorem", desc: "Find tangents parallel to the secant over [a, b]." },
    view: { x: [-4.5, 4.5], y: [-4, 4.5] },
    params: [
      { key: "fn", label: "함수", type: "select", value: "cub", options: funOpts(["cub", "quar", "sin", "sq"]) },
      { key: "a", label: "a", min: -4, max: 3.5, step: 0.1, value: -2.6 },
      { key: "b", label: "b", min: -3.5, max: 4, step: 0.1, value: 2.2 },
    ],
    derive(s) { if (s.b < s.a + 0.4) s.b = Math.min(4, s.a + 0.4); },
    cs(s) { const F = FUN[s.fn], m = (F.f(s.b) - F.f(s.a)) / (s.b - s.a), out = []; const N = 1500; for (let i = 0; i < N; i++) { const x0 = s.a + ((s.b - s.a) * i) / N, x1 = x0 + (s.b - s.a) / N, g0 = F.d(x0) - m, g1 = F.d(x1) - m; if (g0 * g1 <= 0 && i > 0) out.push((x0 + x1) / 2); } return { m, cs: out.filter((c, i, a) => !i || c - a[i - 1] > 0.02) }; },
    drags: { A: { at: (s) => [s.a, FUN[s.fn].f(s.a)], move: (s, p) => (s.a = Math.min(p[0], s.b - 0.4)), color: "c" }, B: { at: (s) => [s.b, FUN[s.fn].f(s.b)], move: (s, p) => (s.b = Math.max(p[0], s.a + 0.4)), color: "c" } },
    draw(s, g) {
      g.grid();
      const F = FUN[s.fn], A = [s.a, F.f(s.a)], B = [s.b, F.f(s.b)], { m, cs } = this.cs(s);
      g.fx(F.f, { color: "a", w: 3.2 });
      g.line(A, B, { color: "b", w: 2.4 });
      cs.forEach((c) => { const C = [c, F.f(c)]; g.line(C, add(C, [1, m]), { color: "c", w: 2, dash: "7 5" }); g.point(C, "c", { color: "c" }); });
      g.point(A, "a", { color: "ink", dy: 20 }).point(B, "b", { color: "ink", dy: 20 });
    },
    metrics(s) { const { m, cs } = this.cs(s); return [["할선의 기울기", fmt(m, 4)], ["평행한 접선의 접점 c", cs.length ? cs.map((c) => fmt(c, 3)).join(", ") : "없음", "key"]]; },
  },
  {
    id: "calc-string-art", grade: 7, unit: 2, lesson: "Ⅱ 프로젝트", title: "접선을 모아 만드는 스트링아트", type: "조작", time: "10분",
    tags: ["접선", "포락선", "스트링아트"], links: ["calc-secant-tangent", "lab-cardioid"],
    desc: "곡선 위 여러 점의 접선만 그려도 곡선이 떠오르는 스트링아트를 만들고, 두 선분의 눈금을 잇는 실 걸기가 포물선을 만드는 이유를 봅니다.",
    obs: ["접선이 촘촘할수록 곡선의 모양이 또렷해집니다.", "두 선분을 같은 간격으로 나눈 점을 엇갈려 이으면 포물선의 접선들이 됩니다."],
    q: "x축과 y축의 눈금을 (k, 0)과 (0, 10 − k)로 이으면 어떤 곡선이 보일까요?",
    formula: "y = f′(a)(x − a) + f(a) (a를 바꾸며 반복)",
    en: { title: "String Art from Tangents", desc: "Draw only tangent lines and watch the curve appear." },
    view: { x: [-6, 6], y: [-4, 6] },
    params: [
      { key: "mode", label: "방법", type: "seg", value: "tan", options: [["tan", "접선 모으기"], ["two", "두 선분 잇기"]] },
      { key: "n", label: "실의 개수", min: 4, max: 60, step: 1, value: 24 },
      { key: "k", label: "곡선 y = kx²", min: 0.1, max: 0.5, step: 0.02, value: 0.2, when: (s) => s.mode === "tan" },
      { key: "ang", label: "두 선분의 사잇각", min: 30, max: 150, step: 1, value: 90, unit: "°", when: (s) => s.mode === "two" },
    ],
    anim: { key: "n", min: 4, max: 60, speed: 8, label: "실 늘리기" },
    draw(s, g) {
      g.grid({ labels: false, axes: s.mode === "tan" });
      const N = Math.round(s.n);
      if (s.mode === "tan") {
        for (let i = 0; i <= N; i++) { const a = -5 + (10 * i) / N, f = s.k * a * a, m = 2 * s.k * a; g.line([a, f], [a + 1, f + m], { color: i % 2 ? "a" : "e", w: 1.2, opacity: 0.75 }); }
        g.fx((x) => s.k * x * x, { color: "ink", w: 1, opacity: 0.3 });
      } else {
        const O = [-4, -3], L = 9, u = [1, 0], v = [Math.cos(deg(s.ang)), Math.sin(deg(s.ang))];
        g.seg(O, add(O, mul(u, L)), { color: "ink", w: 2 }).seg(O, add(O, mul(v, L)), { color: "ink", w: 2 });
        for (let i = 0; i <= N; i++) { const t = i / N; g.seg(add(O, mul(u, L * t)), add(O, mul(v, L * (1 - t))), { color: i % 2 ? "a" : "b", w: 1.2, opacity: 0.8 }); }
      }
    },
    metrics(s) { return [["실의 개수", String(Math.round(s.n))], ["보이는 곡선", s.mode === "tan" ? `포물선 y = ${fmt(s.k)}x²` : "포물선의 일부 (두 선분에 접함)", "key"]]; },
  },
  {
    id: "calc-riemann", grade: 7, unit: 4, lesson: "Ⅳ-3", title: "구분구적법과 정적분", type: "2D", time: "12분",
    tags: ["직사각형 합", "극한", "넓이"], links: ["pi-estimation", "calc-area-between"],
    desc: "구간을 n등분한 직사각형의 넓이 합을 왼쪽·오른쪽·가운데 끝점으로 계산하고, n을 늘리며 정적분 값에 다가가는 모습을 봅니다.",
    obs: ["분할을 충분히 촘촘하게 하면 직사각형의 부호 있는 합은 정적분으로 수렴합니다. 각 단계의 오차가 언제나 감소하는 것은 아닙니다.", "증가함수에서는 왼쪽 합 ≤ 정적분 ≤ 오른쪽 합입니다. x축 아래에서는 넓이와 정적분을 구별합니다.", "x축 아래 부분의 직사각형은 음수로 더해집니다."],
    q: "n을 두 배로 늘리면 오차는 대략 어떻게 변할까요?",
    formula: "∫ₐᵇ f(x)dx = lim(n→∞) Σ f(xₖ)Δx, Δx = (b − a)/n",
    en: { title: "Riemann Sums and the Integral", desc: "Add up n rectangles and watch the sum approach the definite integral." },
    view: { x: [-4.5, 4.5], y: [-3, 5] },
    params: [
      { key: "fn", label: "함수", type: "select", value: "sq", options: funOpts(["sq", "cub", "sin"]) },
      { key: "a", label: "a", min: -4, max: 3, step: 0.1, value: 0 },
      { key: "b", label: "b", min: -3, max: 4, step: 0.1, value: 3 },
      { key: "n", label: "n (나누는 개수)", min: 1, max: 100, step: 1, value: 6 },
      { key: "rule", label: "높이를 정하는 점", type: "seg", value: "r", options: [["l", "왼쪽"], ["m", "가운데"], ["r", "오른쪽"]] },
    ],
    anim: { key: "n", min: 1, max: 100, speed: 14, label: "n 늘리기" },
    derive(s) { if (s.b < s.a + 0.2) s.b = s.a + 0.2; s.n = Math.round(s.n); },
    sum(s) { const F = FUN[s.fn], dx = (s.b - s.a) / s.n, off = { l: 0, m: 0.5, r: 1 }[s.rule]; let S = 0; for (let k = 0; k < s.n; k++) S += F.f(s.a + (k + off) * dx) * dx; return S; },
    drags: { A: { at: (s) => [s.a, 0], move: (s, p) => (s.a = Math.min(p[0], s.b - 0.2)), color: "c" }, B: { at: (s) => [s.b, 0], move: (s, p) => (s.b = Math.max(p[0], s.a + 0.2)), color: "c" } },
    draw(s, g) {
      g.grid();
      const F = FUN[s.fn], dx = (s.b - s.a) / s.n, off = { l: 0, m: 0.5, r: 1 }[s.rule];
      for (let k = 0; k < s.n; k++) { const x0 = s.a + k * dx, h = F.f(s.a + (k + off) * dx); g.poly([[x0, 0], [x0 + dx, 0], [x0 + dx, h], [x0, h]], { fill: h >= 0 ? "b" : "d", fo: 0.28, color: h >= 0 ? "b" : "d", w: s.n > 40 ? 0.6 : 1.3 }); }
      g.fx(F.f, { color: "a", w: 3.2 });
    },
    metrics(s) { const F = FUN[s.fn], S = this.sum(s), I = F.F(s.b) - F.F(s.a); return [["직사각형 넓이의 합", fmt(S, 5)], ["정적분 값", fmt(I, 5), "key"], ["오차", fmt(S - I, 5)]]; },
  },
  {
    id: "calc-area-between", grade: 7, unit: 4, lesson: "Ⅳ-5", title: "곡선과 곡선 사이의 넓이", type: "2D", time: "10분",
    tags: ["넓이", "교점", "정적분"], links: ["calc-riemann"],
    desc: "두 그래프의 교점을 찾고, 위에 있는 함수에서 아래 함수를 뺀 식을 적분해 둘러싸인 부분의 넓이를 구합니다.",
    obs: ["넓이는 (위 − 아래)를 적분합니다.", "두 그래프의 위아래가 바뀌는 교점에서 구간을 나눕니다.", "정적분 값과 넓이는 부호 때문에 다를 수 있습니다."],
    q: "y = x²과 y = x로 둘러싸인 부분의 넓이는 얼마일까요?",
    formula: "S = ∫ₐᵇ |f(x) − g(x)| dx",
    en: { title: "Area Between Curves", desc: "Find intersection points and integrate top minus bottom." },
    view: { x: [-4.5, 4.5], y: [-4, 5] },
    params: [{ key: "pair", label: "두 곡선", type: "select", value: "pl", options: [["pl", "y = x²/2, y = x + 1.5"], ["cc", "y = (x³ − 6x)/4, y = x/2"], ["ss", "y = 2 sin x, y = 2 cos x (0 ~ 2π)"]] }],
    fs(s) {
      if (s.pair === "pl") return { f: (x) => x * x / 2, g: (x) => x + 1.5, r: [-4.5, 4.5] };
      if (s.pair === "cc") return { f: (x) => (x ** 3 - 6 * x) / 4, g: (x) => x / 2, r: [-4.5, 4.5] };
      return { f: (x) => 2 * Math.sin(x), g: (x) => 2 * Math.cos(x), r: [0, 2 * Math.PI] };
    },
    roots(s) { const { f, g, r } = this.fs(s), out = [], d = (x) => f(x) - g(x); const N = 3001; for (let i = 0; i < N; i++) { let a = r[0] + ((r[1] - r[0]) * i) / N, b = r[0] + ((r[1] - r[0]) * (i + 1)) / N; if (d(a) * d(b) >= 0) continue; for (let k = 0; k < 50; k++) { const m = (a + b) / 2; if (d(a) * d(m) <= 0) b = m; else a = m; } out.push((a + b) / 2); } return out; },
    area(s) { const { f, g } = this.fs(s), R = this.roots(s); let S = 0; for (let i = 0; i + 1 < R.length; i++) { const N = 2000, h = (R[i + 1] - R[i]) / N; for (let k = 0; k < N; k++) { const x = R[i] + (k + 0.5) * h; S += Math.abs(f(x) - g(x)) * h; } } return S; },
    draw(s, g) {
      g.grid();
      const { f, g: h, r } = this.fs(s), R = this.roots(s);
      for (let i = 0; i + 1 < R.length; i++) { const m = (R[i] + R[i + 1]) / 2, top = f(m) > h(m); g.region(top ? f : h, top ? h : f, R[i], R[i + 1], { fill: i % 2 ? "c" : "e", fo: 0.3 }); }
      g.fx(f, { color: "a", w: 3.2, from: r[0], to: r[1] }).fx(h, { color: "b", w: 3.2, from: r[0], to: r[1] });
      R.forEach((x) => g.point([x, f(x)], `x = ${fmt(x, 2)}`, { color: "ink", r: 5 }));
    },
    metrics(s) { const R = this.roots(s); return [["교점의 x좌표", R.map((x) => fmt(x, 3)).join(", ") || "없음"], ["둘러싸인 넓이", fmt(this.area(s), 4), "key"]]; },
  },
  {
    id: "calc-motion", grade: 7, unit: 4, lesson: "Ⅳ-6", title: "속도 그래프로 본 위치와 움직인 거리", type: "조작", time: "12분",
    tags: ["속도", "변위", "거리"], links: ["calc-riemann", "calc-param-motion"],
    desc: "수직선 위를 움직이는 점의 속도 그래프 아래 넓이로 위치의 변화(변위)와 실제로 움직인 거리를 구분합니다.",
    obs: ["속도가 음수인 동안 점은 왼쪽으로 움직입니다.", "위치의 변화량은 ∫v dt, 움직인 거리는 ∫|v| dt입니다.", "속도가 0이 되는 순간 방향이 바뀔 수 있습니다."],
    q: "출발점으로 되돌아왔다면 위치의 변화량은 얼마일까요?",
    formula: "x(t) = x(0) + ∫₀ᵗ v(s) ds · 거리 = ∫₀ᵗ |v(s)| ds",
    en: { title: "Velocity, Displacement and Distance", desc: "Use areas under a velocity graph to separate displacement from distance traveled." },
    view: { x: [-0.6, 8.4], y: [-4, 4.6] },
    params: [{ key: "t", label: "시각 t", min: 0, max: 8, step: 0.02, value: 5 }],
    anim: { key: "t", min: 0, max: 8, speed: 1.2, loop: "wrap", label: "움직이기" },
    v: (t) => 0.3 * (t - 1) * (t - 5) * 0.9,
    X(t) { let S = 0; const N = 400; for (let k = 0; k < N; k++) S += this.v(((k + 0.5) * t) / N) * (t / N); return S; },
    D(t) { let S = 0; const N = 400; for (let k = 0; k < N; k++) S += Math.abs(this.v(((k + 0.5) * t) / N)) * (t / N); return S; },
    drags: { T: { at: (s) => [s.t, 0.3 * (s.t - 1) * (s.t - 5) * 0.9], move: (s, p) => (s.t = p[0]) } },
    draw(s, g) {
      g.grid({ xName: "t", yName: "v" });
      const v = (t) => this.v(t);
      g.region(v, () => 0, 0, s.t, { fill: "c", fo: 0.3 });
      g.fx(v, { color: "a", w: 3.2, from: 0, to: 8 });
      g.seg([s.t, 0], [s.t, v(s.t)], { color: "ink", w: 1.6, dash: "3 4" }).point([s.t, v(s.t)], "", { color: "a" });
      const y0 = 3.9, x0 = 1.2, k = 0.9;
      g.seg([-0.4, y0], [8.2, y0], { color: "ink", w: 1.6 });
      for (let i = -1; i <= 8; i++) { g.seg([x0 + i * k, y0 - 0.08], [x0 + i * k, y0 + 0.08], { color: "ink", w: 1.2 }); }
      g.text([x0, y0], "0", { dy: 20, color: "muted", size: 12 });
      g.circle([x0 + this.X(s.t) * k, y0], 0.16, { color: "d", fill: "d", fo: 1 });
      g.note(18, 24, "수직선 위의 점 P", { color: "d", bold: true });
    },
    metrics(s) { return [["속도 v(t)", fmt(this.v(s.t), 3)], ["위치의 변화량 ∫v dt", fmt(this.X(s.t), 3), "key"], ["움직인 거리 ∫|v| dt", fmt(this.D(s.t), 3)], ["운동 방향", this.v(s.t) > 0.01 ? "오른쪽" : this.v(s.t) < -0.01 ? "왼쪽" : "멈춤(방향 전환)"]]; },
  },
  {
    id: "calc-volume-slice", grade: 13, unit: 4, lesson: "Ⅳ-6", title: "단면으로 구하는 입체의 부피", type: "3D", time: "12분",
    tags: ["단면적", "부피", "3D"], links: ["cone-volume", "calc-riemann"],
    desc: "밑면 영역 위에 x축에 수직인 단면(정사각형·반원·정삼각형)을 세워 얇은 조각의 부피를 더하고 적분으로 정확한 부피를 구합니다.",
    obs: ["단면의 넓이 S(x)를 알면 부피는 ∫S(x)dx입니다.", "조각을 얇게 할수록 조각 부피의 합이 정확한 값에 가까워집니다.", "회전체는 단면이 원인 특별한 경우입니다."],
    q: "단면이 모두 원이면 입체는 어떤 모양이 될까요?",
    formula: "V = ∫ₐᵇ S(x) dx",
    en: { title: "Volume by Cross Sections", desc: "Stack square, semicircular or triangular slices and integrate their areas." },
    space: true, cam: { yaw: 40, pitch: 24, scale: 58 },
    params: [
      { key: "shape", label: "단면 모양", type: "seg", value: "sq", options: [["sq", "정사각형"], ["semi", "반원"], ["tri", "정삼각형"], ["disk", "원 (회전체)"]] },
      { key: "n", label: "조각 수", min: 3, max: 40, step: 1, value: 10 },
    ],
    anim: { key: "n", min: 3, max: 40, speed: 6, label: "조각 늘리기" },
    w: (x) => 2 * Math.sqrt(Math.max(0, 1 - (x * x) / 4)) * 1.1, // 밑면: 타원 영역의 폭
    area(s, x) { const w = this.w(x); return { sq: w * w, semi: (Math.PI * w * w) / 8, tri: (Math.sqrt(3) / 4) * w * w, disk: (Math.PI * w * w) / 4 }[s.shape]; },
    vol(s) { let V = 0; const N = 2000; for (let k = 0; k < N; k++) { const x = -2 + ((k + 0.5) * 4) / N; V += this.area(s, x) * (4 / N); } return V; },
    draw(s, g) {
      g.axes(3.2, { neg: true });
      const base = []; for (let i = 0; i <= 80; i++) { const x = -2 + (4 * i) / 80; base.push([x, this.w(x) / 2, 0]); }
      for (let i = 80; i >= 0; i--) { const x = -2 + (4 * i) / 80; base.push([x, -this.w(x) / 2, 0]); }
      g.face(base, { fill: "b", color: "b", fo: 0.12, bias: -2 });
      const n = Math.round(s.n), dx = 4 / n;
      for (let k = 0; k < n; k++) {
        const x = -2 + (k + 0.5) * dx, w = this.w(x), h = w / 2;
        const sec = s.shape === "sq" ? [[0, -h, 0], [0, h, 0], [0, h, w], [0, -h, w]]
          : s.shape === "tri" ? [[0, -h, 0], [0, h, 0], [0, 0, (Math.sqrt(3) / 2) * w]]
          : s.shape === "semi" ? Array.from({ length: 25 }, (_, i) => [0, h * Math.cos((Math.PI * i) / 24), h * Math.sin((Math.PI * i) / 24)])
          : Array.from({ length: 36 }, (_, i) => [0, h * Math.cos((2 * Math.PI * i) / 36), h * Math.sin((2 * Math.PI * i) / 36)]);
        g.face(sec.map((p) => add(p, [x - dx / 2, 0, 0])), { fill: "a", color: "a", fo: 0.35, w: 1 });
        g.face(sec.map((p) => add(p, [x + dx / 2, 0, 0])), { fill: "a", color: "a", fo: 0.25, w: 1 });
      }
    },
    metrics(s) { const n = Math.round(s.n), dx = 4 / n; let S = 0; for (let k = 0; k < n; k++) S += this.area(s, -2 + (k + 0.5) * dx) * dx; return [["조각 부피의 합", fmt(S, 4)], ["∫S(x)dx", fmt(this.vol(s), 4), "key"], ["밑면", "x²/4 + y²/1.21 ≤ 1 인 타원 영역"]]; },
  },
  {
    id: "calc-cup", grade: 13, unit: 3, lesson: "Ⅲ 프로젝트", title: "원뿔 컵에 차오르는 물 — 컵 속의 미분", type: "조작", time: "12분",
    tags: ["변화율", "원뿔", "부피"], links: ["cone-volume", "calc-volume-slice"],
    desc: "원뿔 모양 컵에 물을 일정하게 부을 때 물의 높이가 처음에는 빠르게, 나중에는 천천히 오르는 이유를 부피와 높이의 관계로 설명합니다.",
    obs: ["물의 부피 V = (π/3)(r/H)²h³입니다.", "dV/dt가 일정해도 dh/dt는 h²에 반비례합니다.", "높이-시간 그래프의 기울기가 점점 줄어듭니다."],
    q: "원기둥 컵이라면 높이 그래프는 어떤 모양이 될까요?",
    formula: "dV/dt = π(r/H)²h² · dh/dt",
    en: { title: "Water Rising in a Conical Cup", desc: "Pour at a constant rate and explain why the water level slows down." },
    view: { x: [-6.5, 7], y: [-3.8, 4.4] },
    params: [
      { key: "cup", label: "컵 모양", type: "seg", value: "cone", options: [["cone", "원뿔 (꼭짓점 아래)"], ["cyl", "원기둥"]] },
      { key: "t", label: "시간 (초)", min: 0, max: 10, step: 0.02, value: 4 },
    ],
    anim: { key: "t", min: 0, max: 10, speed: 1.4, loop: "wrap", label: "물 붓기" },
    H: 6, R: 3, rate: 5.6,
    h(s, t) { const V = this.rate * t, k = this.R / this.H; if (s.cup === "cyl") return Math.min(this.H, V / (Math.PI * 1.9 * 1.9)); return Math.min(this.H, Math.cbrt((3 * V) / (Math.PI * k * k))); },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const base = [-4.2, -3.2], sc = 1, H = this.H, R = this.R, h = this.h(s, s.t);
      const cupL = (y) => (s.cup === "cone" ? (R * y) / H : 1.9);
      const water = [], cup = [];
      for (let i = 0; i <= 30; i++) { const y = (h * i) / 30; water.push([base[0] - cupL(y), base[1] + y]); }
      for (let i = 30; i >= 0; i--) { const y = (h * i) / 30; water.push([base[0] + cupL(y), base[1] + y]); }
      g.poly(water, { fill: "b", fo: 0.45, stroke: false });
      g.path([[base[0] - cupL(H), base[1] + H], [base[0] - cupL(0), base[1]], [base[0] + cupL(0), base[1]], [base[0] + cupL(H), base[1] + H]], { color: "ink", w: 3 });
      g.seg([base[0] + cupL(H) + 0.3, base[1]], [base[0] + cupL(H) + 0.3, base[1] + h], { color: "d", w: 2.4 }).text([base[0] + cupL(H) + 0.4, base[1] + h / 2], `h = ${fmt(h, 2)}`, { anchor: "start", dx: 6, color: "d", bold: true, size: 13 });
      const O = [0.4, -3.2], kx = 0.6, ky = 1;
      g.seg(O, [O[0] + 10 * kx + 0.2, O[1]], { color: "axis", w: 1.4 }).seg(O, [O[0], O[1] + H * ky + 0.3], { color: "axis", w: 1.4 });
      g.text([O[0] + 10 * kx, O[1]], "t", { dy: 20, italic: true, color: "muted" }).text([O[0], O[1] + H * ky + 0.3], "h", { dx: -12, italic: true, color: "muted" });
      g.param((t) => [O[0] + t * kx, O[1] + this.h(s, t) * ky], 0, 10, { color: "muted", w: 1.4, dash: "4 5" });
      g.param((t) => [O[0] + t * kx, O[1] + this.h(s, t) * ky], 0, s.t, { color: "a", w: 3.2 });
      g.point([O[0] + s.t * kx, O[1] + h * ky], "", { color: "a" });
    },
    metrics(s) {
      const h = this.h(s, s.t), k = this.R / this.H, dh = s.cup === "cone" ? (h > 1e-6 && h < this.H ? this.rate / (Math.PI * k * k * h * h) : 0) : h < this.H ? this.rate / (Math.PI * 1.9 * 1.9) : 0;
      return [["부은 물의 부피", fmt(this.rate * s.t, 2)], ["물의 높이 h", fmt(h, 3)], ["높이 변화율 dh/dt", h >= this.H ? "가득 참" : fmt(dh, 3), "key"]];
    },
  },
  {
    id: "calc-param-motion", grade: 13, unit: 3, lesson: "Ⅲ-6", title: "평면 위의 운동 — 속도·가속도 벡터", type: "조작", time: "12분",
    tags: ["매개변수", "속도 벡터", "이동 거리"], links: ["geo-vector-component", "lab-cycloid"],
    desc: "원·타원·사이클로이드·리사주 곡선 위를 움직이는 점의 속도 벡터(접선 방향)와 가속도 벡터를 함께 보고 이동 거리를 잽니다.",
    obs: ["속도 벡터 (x′(t), y′(t))는 곡선의 접선 방향입니다.", "등속 원운동의 가속도는 항상 중심을 향합니다.", "이동 거리는 속력 √(x′² + y′²)을 시간에 대해 적분한 값입니다."],
    q: "사이클로이드에서 점이 바닥에 닿는 순간 속력은 얼마일까요?",
    formula: "v = (dx/dt, dy/dt) · a = (d²x/dt², d²y/dt²) · s = ∫√((dx/dt)² + (dy/dt)²) dt",
    en: { title: "Motion in the Plane", desc: "Follow velocity and acceleration vectors along parametric curves and measure distance." },
    view: { x: [-6.5, 6.5], y: [-4.4, 4.4] },
    params: [
      { key: "c", label: "곡선", type: "seg", value: "cyc", options: [["circ", "원"], ["ell", "타원"], ["cyc", "사이클로이드"], ["lis", "리사주"]] },
      { key: "t", label: "t", min: 0, max: 6.2832, step: 0.01, value: 2, show: (v) => fmt(v, 2) },
      { key: "acc", label: "가속도 벡터 보기", type: "check", value: true },
    ],
    anim: { key: "t", min: 0, max: 6.2832, speed: 0.8, loop: "wrap", label: "움직이기" },
    P(s, t) {
      if (s.c === "circ") return [3 * Math.cos(t), 3 * Math.sin(t)];
      if (s.c === "ell") return [5 * Math.cos(t), 2.6 * Math.sin(t)];
      if (s.c === "cyc") return [-6 + 1.9 * t - 1.9 * Math.sin(t), -3 + 1.9 - 1.9 * Math.cos(t)];
      return [5 * Math.sin(2 * t), 3.6 * Math.sin(3 * t)];
    },
    D(s, t, k = 1) { const e = 1e-4; if (k === 1) return mul(sub(this.P(s, t + e), this.P(s, t - e)), 1 / (2 * e)); return mul(add(sub(this.P(s, t + e), mul(this.P(s, t), 2)), this.P(s, t - e)), 1 / (e * e)); },
    draw(s, g) {
      g.grid({ labels: false });
      if (s.c === "cyc") { g.seg([-6.5, -3], [6.5, -3], { color: "ink", w: 1.6 }); const cx = this.P(s, s.t)[0] + 1.9 * Math.sin(s.t); g.circle([cx, -1.1], 1.9, { color: "muted", w: 1.6, dash: "4 5" }); g.seg([cx, -1.1], this.P(s, s.t), { color: "muted", w: 1.4 }); }
      g.param((t) => this.P(s, t), 0, 2 * Math.PI, { color: "muted", w: 1.6, dash: "4 5", n: 500 });
      g.param((t) => this.P(s, t), 0, s.t, { color: "a", w: 3.2, n: 500 });
      const P = this.P(s, s.t), v = this.D(s, s.t), a = this.D(s, s.t, 2);
      g.vec(P, add(P, mul(v, 0.5)), { color: "c", w: 3, label: "v" });
      if (s.acc) g.vec(P, add(P, mul(a, 0.25)), { color: "d", w: 3, label: "a" });
      g.point(P, "P", { color: "a", r: 6.5 });
    },
    metrics(s) { const v = this.D(s, s.t); let L = 0; const N = 600; for (let k = 0; k < N; k++) L += len(this.D(s, ((k + 0.5) * s.t) / N)) * (s.t / N); return [["속도", `(${fmt(v[0])}, ${fmt(v[1])})`], ["속력", fmt(len(v), 3), "key"], ["지금까지 이동 거리", fmt(L, 3)]]; },
  },
  {
    id: "calc-trig-limit", grade: 13, unit: 2, lesson: "Ⅱ-4", title: "sin x / x → 1 의 넓이 증명", type: "2D", time: "10분",
    tags: ["삼각함수의 극한", "부채꼴", "샌드위치"], links: ["alg-radian", "alg-unit-circle"],
    desc: "단위원에서 삼각형 OAP < 부채꼴 OAP < 삼각형 OAT의 넓이 비교로 x → 0일 때 sin x / x가 1로 다가감을 봅니다.",
    obs: ["넓이 부등식 ½sin x < ½x < ½tan x가 성립합니다.", "각 변을 ½sin x로 나누면 1 < x/sin x < 1/cos x입니다.", "x → 0이면 cos x → 1이므로 가운데 값도 1로 다가갑니다."],
    q: "x를 라디안이 아닌 도(°)로 재면 극한값은 어떻게 될까요?",
    formula: "sin x < x < tan x (0 < x < π/2) ⇒ lim(x→0) sin x / x = 1",
    en: { title: "Why sin x / x → 1", desc: "Compare the areas of two triangles and a sector in the unit circle." },
    view: { x: [-0.8, 5.2], y: [-0.8, 4.2] },
    params: [{ key: "x", label: "x (라디안)", min: 0.02, max: 1.4, step: 0.01, value: 0.9 }],
    anim: { key: "x", min: 0.02, max: 1.4, speed: 0.25, label: "x를 0으로" },
    drags: { P: { at: (s) => [3.6 * Math.cos(s.x), 3.6 * Math.sin(s.x)], move: (s, p) => (s.x = Math.atan2(p[1], p[0])) } },
    draw(s, g) {
      g.grid({ labels: false });
      const R = 3.6, x = s.x, O = [0, 0], A = [R, 0], P = [R * Math.cos(x), R * Math.sin(x)], T = [R, R * Math.tan(x)];
      g.param((u) => [R * Math.cos(u), R * Math.sin(u)], 0, Math.PI / 2, { color: "muted", w: 1.4, dash: "4 5" });
      if (T[1] < 4.2) g.poly([O, A, T], { fill: "d", fo: 0.16, color: "d", w: 1.8 });
      g.poly([O, ...Array.from({ length: 41 }, (_, i) => [R * Math.cos((x * i) / 40), R * Math.sin((x * i) / 40)])], { fill: "c", fo: 0.22, color: "c", w: 1.8 });
      g.poly([O, A, P], { fill: "b", fo: 0.3, color: "b", w: 2 });
      g.seg(P, [P[0], 0], { color: "b", w: 2.4 }).text([P[0], P[1] / 2], "sin x", { dx: -8, anchor: "end", color: "b", bold: true, size: 13 });
      if (T[1] < 4.2) g.seg(A, T, { color: "d", w: 2.4 }).text([R, T[1] / 2], "tan x", { dx: 8, anchor: "start", color: "d", bold: true, size: 13 });
      g.arc(O, A, P, { r: 30, color: "e", label: "x" });
      g.point(O, "O", { dx: -12, anchor: "end" }).point(A, "A", { dy: 20 }).point(P, "P");
      if (T[1] < 4.2) g.point(T, "T", { color: "d" });
    },
    metrics(s) { return [["½ sin x (△OAP)", fmt(Math.sin(s.x) / 2, 5)], ["½ x (부채꼴)", fmt(s.x / 2, 5)], ["½ tan x (△OAT)", fmt(Math.tan(s.x) / 2, 5)], ["sin x / x", fmt(Math.sin(s.x) / s.x, 6), "key"]]; },
  },
  {
    id: "calc-addition", grade: 13, unit: 2, lesson: "Ⅱ-3", title: "삼각함수의 덧셈정리 — 직사각형 증명", type: "2D", time: "12분",
    tags: ["덧셈정리", "그림 증명", "직각삼각형"], links: ["alg-identities", "alg-unit-circle"],
    desc: "빗변이 1인 직각삼각형 두 개를 직사각형 안에 쌓아, 변의 길이를 비교하는 것만으로 sin(α + β)와 cos(α + β)의 공식을 얻습니다.",
    obs: ["직사각형의 오른쪽 세로 변 = 왼쪽 두 조각의 합입니다.", "위쪽 가로 변의 차가 cos(α + β)입니다.", "α + β가 90°를 넘지 않을 때 그림이 성립하고, 일반각으로 확장됩니다."],
    q: "같은 그림에서 cos(α + β) = cos α cos β − sin α sin β를 찾아보세요.",
    formula: "sin(α + β) = sin α cos β + cos α sin β · cos(α + β) = cos α cos β − sin α sin β",
    en: { title: "Addition Formulas by a Rectangle", desc: "Stack two right triangles in a rectangle to read off sin(α + β) and cos(α + β)." },
    view: { x: [-0.8, 5.6], y: [-0.6, 4.4] },
    params: [
      { key: "a", label: "α", min: 5, max: 60, step: 1, value: 30, unit: "°" },
      { key: "b", label: "β", min: 5, max: 60, step: 1, value: 40, unit: "°" },
    ],
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const R = 4, a = deg(s.a), b = deg(s.b);
      const O = [0, 0], Q = [R * Math.cos(b) * Math.cos(a), R * Math.cos(b) * Math.sin(a)], P = [R * Math.cos(a + b), R * Math.sin(a + b)];
      const W = Q[0], Ht = P[1];
      g.poly([O, [W, 0], [W, Ht], [0, Ht]], { color: "muted", w: 1.6, dash: "5 5" });
      g.poly([O, [W, 0], Q], { fill: "b", fo: 0.18, color: "b", w: 2 });
      g.poly([O, Q, P], { fill: "a", fo: 0.18, color: "a", w: 2 });
      g.poly([Q, [W, Ht], P], { fill: "c", fo: 0.18, color: "c", w: 2 });
      g.right([W, 0], O, Q, { size: 10 }).right(Q, O, P, { size: 10 });
      g.arc(O, [1, 0], Q, { r: 34, color: "b", label: "α" }).arc(O, Q, P, { r: 50, color: "a", label: "β" });
      g.text(lerp(O, P, 0.55), "1", { dx: -10, color: "a", bold: true });
      g.text([W, Q[1] / 2], "sin α cos β", { dx: 8, anchor: "start", color: "b", size: 13, bold: true });
      g.text([W, (Q[1] + Ht) / 2], "cos α sin β", { dx: 8, anchor: "start", color: "c", size: 13, bold: true });
      g.text([P[0] / 2, Ht], "cos(α + β)", { dy: -8, color: "e", size: 13, bold: true });
      g.text([0, Ht / 2], "sin(α + β)", { dx: -6, anchor: "end", color: "e", size: 13, bold: true });
      g.point(O, "O", { dx: -10, anchor: "end", dy: 16 }).point(Q, "Q").point(P, "P");
    },
    metrics(s) { const a = deg(s.a), b = deg(s.b); return [["sin(α + β)", fmt(Math.sin(a + b), 4), "key"], ["sin α cos β + cos α sin β", fmt(Math.sin(a) * Math.cos(b) + Math.cos(a) * Math.sin(b), 4)], ["cos(α + β)", fmt(Math.cos(a + b), 4), "key"], ["cos α cos β − sin α sin β", fmt(Math.cos(a) * Math.cos(b) - Math.sin(a) * Math.sin(b), 4)]]; },
  },
  {
    id: "calc-implicit", grade: 13, unit: 2, lesson: "Ⅱ-8", title: "데카르트의 엽선과 음함수의 미분", type: "2D", time: "10분",
    tags: ["음함수", "접선", "엽선"], links: ["calc-secant-tangent"],
    desc: "x³ + y³ = 3axy로 나타나는 데카르트의 엽선 위의 점에서 음함수의 미분법으로 구한 기울기의 접선을 그립니다.",
    obs: ["y를 x의 식으로 풀지 않아도 양변을 x에 대해 미분하면 dy/dx를 구할 수 있습니다.", "잎 모양의 끝점에서는 접선이 수직이 됩니다.", "곡선은 점근선 x + y + a = 0에 가까워집니다."],
    q: "원 x² + y² = r² 위의 점에서 접선의 기울기를 음함수의 미분법으로 구해 보세요.",
    formula: "x³ + y³ = 3axy ⇒ dy/dx = (ay − x²)/(y² − ax)",
    en: { title: "Folium of Descartes and Implicit Differentiation", desc: "Draw tangents to x³ + y³ = 3axy using implicit differentiation." },
    view: { x: [-5, 5], y: [-5, 5] },
    params: [{ key: "a", label: "a", min: 1, max: 2.5, step: 0.1, value: 1.8 }, { key: "t", label: "점의 위치 (매개변수)", min: -0.6, max: 4, step: 0.01, value: 0.7 }],
    anim: { key: "t", min: -0.6, max: 4, speed: 0.7, label: "점 움직이기" },
    P(s, t) { const d = 1 + t ** 3; return [(3 * s.a * t) / d, (3 * s.a * t * t) / d]; },
    draw(s, g) {
      g.grid();
      g.param((t) => this.P(s, t), -0.75, 12, { color: "a", w: 3.2, n: 800 });
      g.param((t) => this.P(s, t), -12, -1.3, { color: "a", w: 3.2, n: 600 });
      g.line([0, -s.a], [-s.a, 0], { color: "muted", w: 1.4, dash: "5 6" });
      const P = this.P(s, s.t), [x, y] = P, den = y * y - s.a * x, m = (s.a * y - x * x) / den;
      if (Math.abs(den) < 1e-6) g.line(P, add(P, [0, 1]), { color: "b", w: 2.6 }); else g.line(P, add(P, [1, m]), { color: "b", w: 2.6 });
      g.point(P, "P", { color: "b", r: 6.5 });
    },
    metrics(s) { const [x, y] = this.P(s, s.t), den = y * y - s.a * x; return [["P", `(${fmt(x)}, ${fmt(y)})`], ["dy/dx", Math.abs(den) < 1e-6 ? "수직 접선" : fmt((s.a * y - x * x) / den, 3), "key"], ["점근선", `x + y + ${fmt(s.a)} = 0`]]; },
  },
];
