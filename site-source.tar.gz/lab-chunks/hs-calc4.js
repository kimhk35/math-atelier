// 미적분Ⅱ 빈 차시 8개 + 확률과 통계 2개 (20차 이후 추가)
import { fmt, frac, clamp, lerp, add, mul } from "./hs-core.js";

const II = 13, PS = 8;
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const lcg = (seed) => { let x = seed % 2147483647 || 7; return () => ((x = (x * 16807) % 2147483647) / 2147483647); };

const SERIES = {
  harm: { a: (n) => 1 / n, lim: Infinity, name: "1 + 1/2 + 1/3 + ⋯", ys: 6 },
  sq: { a: (n) => 1 / (n * n), lim: (Math.PI * Math.PI) / 6, limS: "π²/6 ≈ 1.645", name: "1 + 1/4 + 1/9 + ⋯", ys: 2 },
  tele: { a: (n) => 1 / (n * (n + 1)), lim: 1, limS: "1", name: "1/(1·2) + 1/(2·3) + ⋯", ys: 1.3 },
  alt: { a: (n) => (n % 2 ? 1 : -1) / n, lim: Math.LN2, limS: "ln 2 ≈ 0.693", name: "1 − 1/2 + 1/3 − ⋯", ys: 1.3 },
};
const ELIM = {
  e: { f: (x) => (1 + x) ** (1 / x), L: Math.E, Ls: "e ≈ 2.718", n: "(1 + x)^(1/x)", lo: -0.95 },
  ex: { f: (x) => (Math.exp(x) - 1) / x, L: 1, Ls: "1", n: "(eˣ − 1)/x", lo: -2 },
  ln: { f: (x) => Math.log(1 + x) / x, L: 1, Ls: "1", n: "ln(1 + x)/x", lo: -0.95 },
};
const RF = {
  sq: { f: (x) => x * x, I: 1 / 3, Is: "1/3", n: "x²" },
  rt: { f: (x) => Math.sqrt(x), I: 2 / 3, Is: "2/3", n: "√x" },
  rec: { f: (x) => 1 / (1 + x), I: Math.LN2, Is: "ln 2 ≈ 0.6931", n: "1/(1 + x)" },
};
const ARC = {
  circ: { x: (t) => Math.cos(t), y: (t) => Math.sin(t), t0: 0, t1: Math.PI / 2, L: Math.PI / 2, Ls: "π/2 ≈ 1.5708", n: "사분원 x² + y² = 1" },
  par: { x: (t) => t, y: (t) => t * t, t0: 0, t1: 1, L: (2 * Math.sqrt(5) + Math.log(2 + Math.sqrt(5))) / 4, Ls: "≈ 1.4789", n: "y = x² (0 ≤ x ≤ 1)" },
  line: { x: (t) => t, y: (t) => t, t0: 0, t1: 1, L: Math.SQRT2, Ls: "√2 ≈ 1.4142", n: "y = x (0 ≤ x ≤ 1)" },
};

export default [
  // ───────── Ⅰ 수열의 극한 ─────────
  {
    id: "calc2-series", grade: II, unit: 1, lesson: "Ⅰ-4", title: "급수의 수렴과 발산 — 부분합이 멈출까, 끝없이 커질까", type: "조작", time: "12분",
    tags: ["급수", "부분합", "조화급수"], links: ["calc2-geo-series", "calc2-seq-limit"],
    desc: "여러 급수의 부분합 Sₙ을 점으로 찍어 n을 늘리며, 한 값에 다가가는 급수(수렴)와 끝없이 커지는 급수(발산)를 비교합니다. 항이 0으로 가도 발산할 수 있음을 조화급수로 확인합니다.",
    obs: ["급수 ∑aₙ이 수렴하면 aₙ → 0이지만, 그 역은 성립하지 않습니다.", "조화급수 1 + 1/2 + 1/3 + ⋯은 아주 느리게, 그러나 끝없이 커집니다.", "1/(n(n + 1)) = 1/n − 1/(n + 1)로 쪼개면 부분합이 1 − 1/(n + 1)로 정리됩니다."],
    q: "조화급수의 부분합이 10을 넘으려면 대략 몇 개의 항을 더해야 할까요?",
    formula: "∑aₙ 수렴 ⇒ aₙ → 0 · Sₙ = 1 − 1/(n + 1) → 1",
    en: { title: "Convergent and Divergent Series", desc: "Compare partial sums of several series." },
    view: (s) => ({ x: [-0.6, 7], y: [-0.25 * SERIES[s.kind].ys, 1.15 * SERIES[s.kind].ys] }),
    params: [
      { key: "kind", label: "급수", type: "select", value: "harm", options: Object.entries(SERIES).map(([k, v]) => [k, v.name]) },
      { key: "N", label: "더한 항의 수 n", min: 1, max: 200, step: 1, value: 40 },
    ],
    anim: { key: "N", min: 1, max: 200, speed: 30, label: "항 더하기" },
    S(s, n) { const a = SERIES[s.kind].a; let t = 0; for (let k = 1; k <= n; k++) t += a(k); return t; },
    draw(s, g) {
      const K = SERIES[s.kind], X = (n) => (n / 200) * 6.6, ys = K.ys, sy = (v) => v; let t = 0;
      g.grid({ labels: false });
      g.seg([0, 0], [6.8, 0], { color: "axis", w: 1.4 }).seg([0, -0.2 * ys], [0, 1.1 * ys], { color: "axis", w: 1.4 });
      [0, 50, 100, 150, 200].forEach((n) => g.text([X(n), 0], String(n), { dy: 16, size: 11, color: "muted" }));
      for (let i = 1; i <= 4; i++) { const v = (ys * i) / 4; g.text([0, v], fmt(v, 2), { dx: -6, anchor: "end", dy: 4, size: 11, color: "muted" }); }
      if (Number.isFinite(K.lim)) { g.seg([0, K.lim], [6.8, K.lim], { color: "c", w: 1.6, dash: "7 5" }); g.text([6.8, K.lim], `극한 ${K.limS}`, { anchor: "end", dy: -6, size: 12, bold: true, color: "c" }); }
      for (let n = 1; n <= s.N; n++) { t += K.a(n); if (n === s.N || n % Math.max(1, Math.round(s.N / 120)) === 0) g.point([X(n), sy(Math.min(t, 1.1 * ys))], "", { color: n === s.N ? "a" : "b", r: n === s.N ? 5.5 : 2.4 }); }
      g.text([0.2, 1.05 * ys], `Sₙ = ${K.name}`, { anchor: "start", bold: true, color: "b" });
    },
    metrics(s) {
      const K = SERIES[s.kind], S = this.S(s, s.N);
      return [[`부분합 (n = ${s.N})`, fmt(S, 5), "key"], ["n번째 항", fmt(K.a(s.N), 5)], ["판정", Number.isFinite(K.lim) ? `수렴 (극한 ${K.limS})` : "발산 (끝없이 커짐)"]];
    },
    predict: [
      { q: "조화급수 1 + 1/2 + 1/3 + ⋯은 수렴할까요?", options: O("발산한다", "수렴한다"), set: (s) => Object.assign(s, { kind: "harm", N: 10 }), reveal: (s) => (s.N = 200), answer: () => "a", why: "1/3 + 1/4 > 1/2, 1/5 + ⋯ + 1/8 > 1/2처럼 묶음마다 1/2보다 커서 끝없이 커집니다." },
      { q: "1/(1·2) + 1/(2·3) + 1/(3·4) + ⋯의 합은?", set: (s) => Object.assign(s, { kind: "tele", N: 3 }), reveal: (s) => (s.N = 200), answer: () => 1, why: "1/n − 1/(n + 1)로 쪼개면 가운데가 모두 지워져 Sₙ = 1 − 1/(n + 1) → 1입니다." },
    ],
  },
  // ───────── Ⅱ 미분법 ─────────
  {
    id: "calc2-e-limit", grade: II, unit: 2, lesson: "Ⅱ-1", title: "e로 가는 극한 — (1 + x)^(1/x)과 (eˣ − 1)/x", type: "조작", time: "10분",
    tags: ["자연상수 e", "극한", "지수함수"], links: ["calc2-e-slope", "calc2-seq-limit"],
    desc: "x를 0에 가까이 가져가며 (1 + x)^(1/x)이 e로, (eˣ − 1)/x와 ln(1 + x)/x가 1로 다가가는 모습을 그래프의 '구멍'과 함께 확인합니다.",
    obs: ["(1 + x)^(1/x)은 x = 0에서 정의되지 않지만 x → 0이면 e ≈ 2.718에 다가갑니다.", "lim(x→0) (eˣ − 1)/x = 1은 y = eˣ의 (0, 1)에서 접선의 기울기가 1이라는 뜻입니다.", "ln(1 + x)/x → 1은 로그함수의 미분 공식의 바탕입니다."],
    q: "(1 + 1/n)ⁿ에서 n → ∞와 (1 + x)^(1/x)에서 x → 0은 왜 같은 극한일까요?",
    formula: "\\lim_{x\\to0}(1+x)^{1/x}=e\\quad\\lim_{x\\to0}\\frac{e^x-1}{x}=1",
    en: { title: "Limits that Lead to e", desc: "Approach the holes at x = 0." },
    view: { x: [-1.3, 3], y: [-0.4, 4] },
    params: [
      { key: "fn", label: "함수", type: "select", value: "e", options: Object.entries(ELIM).map(([k, v]) => [k, "y = " + v.n]) },
      { key: "x", label: "x", min: -0.9, max: 2.5, step: 0.01, value: 1 },
    ],
    anim: { key: "x", min: -0.9, max: 2.5, speed: 0.8, loop: "bounce", label: "x 움직이기" },
    derive(s) { if (Math.abs(s.x) < 0.005) s.x = 0.01; },
    drags: { P: { at: (s) => [s.x, ELIM[s.fn].f(s.x)], move: (s, p) => (s.x = clamp(Math.round(p[0] * 100) / 100, -0.9, 2.5)), color: "a", label: "P" } },
    draw(s, g) {
      const E = ELIM[s.fn];
      g.grid();
      g.line([0, E.L], [1, E.L], { color: "c", w: 1.4, dash: "7 5" });
      g.fx((x) => (Math.abs(x) < 1e-3 ? NaN : E.f(x)), { color: "b", w: 3.2, from: E.lo, to: 3 });
      g.point([0, E.L], "", { color: "c", r: 5.5, hollow: true });
      g.text([0, E.L], E.Ls, { dx: 10, dy: -10, anchor: "start", bold: true, color: "c" });
      g.point([s.x, E.f(s.x)], "", { color: "a", r: 6 });
      g.text([g.xr[0] + 0.1, g.yr[1] - 0.3], `y = ${E.n}`, { anchor: "start", bold: true, color: "b" });
    },
    metrics(s) { const E = ELIM[s.fn]; return [["x", fmt(s.x, 3)], ["함숫값", fmt(E.f(s.x), 6), "key"], ["극한값과의 차", fmt(E.f(s.x) - E.L, 6)], ["x → 0일 때", E.Ls]]; },
    predict: [
      { q: "lim(x→0) (1 + x)^(1/x)의 값은 약 얼마일까요? (소수 셋째 자리)", set: (s) => Object.assign(s, { fn: "e", x: 1 }), reveal: (s) => (s.x = 0.01), answer: () => Math.E, tol: 0.01, show: () => "e ≈ 2.718", why: "자연상수 e의 정의입니다. x = 1이면 2, x = 0.01이면 약 2.705입니다." },
      { q: "lim(x→0) (eˣ − 1)/x의 값은?", set: (s) => Object.assign(s, { fn: "ex", x: 2 }), reveal: (s) => (s.x = 0.01), answer: () => 1, why: "y = eˣ의 x = 0에서 미분계수이며, 그 기울기가 1이 되도록 정한 밑이 e입니다." },
    ],
  },
  {
    id: "calc2-sin-deriv", grade: II, unit: 2, lesson: "Ⅱ-5", title: "sin x의 기울기를 그리면 cos x가 된다", type: "조작", time: "10분",
    tags: ["삼각함수의 미분", "도함수", "기울기"], links: ["calc-trig-limit", "calc-addition", "calc-derivative-graph"],
    desc: "위쪽 y = sin x 위의 점을 움직이며 접선의 기울기를 아래쪽에 점으로 찍어 나가면, 그 자취가 y = cos x와 겹치는 것을 확인합니다. cos x의 기울기는 −sin x가 됩니다.",
    obs: ["sin x가 가장 높은 x = π/2에서 기울기는 0이므로 cos(π/2) = 0입니다.", "기울기의 자취가 cos x와 정확히 겹칩니다: (sin x)′ = cos x.", "(cos x)′ = −sin x이며, 네 번 미분하면 처음 함수로 돌아옵니다."],
    q: "y = sin 2x의 도함수는 무엇일까요? 기울기가 어떻게 달라질지 예상해 봅시다.",
    formula: "(sin x)′ = cos x · (cos x)′ = −sin x",
    en: { title: "Slopes of sin x Trace cos x", desc: "Record tangent slopes of sin x and watch cos x appear." },
    view: { x: [-0.4, 6.7], y: [-3.4, 3.4] },
    params: [
      { key: "fn", label: "함수", type: "seg", value: "sin", options: [["sin", "y = sin x"], ["cos", "y = cos x"]] },
      { key: "t", label: "x", min: 0, max: 6.28, step: 0.02, value: 1.2 },
      { key: "ghost", label: "도함수 곡선 겹쳐 보기", type: "check", value: true },
    ],
    anim: { key: "t", min: 0, max: 6.28, speed: 1.2, label: "기울기 기록하기" },
    F(s) { return s.fn === "sin" ? { f: Math.sin, d: Math.cos, n: "sin x", dn: "cos x" } : { f: Math.cos, d: (x) => -Math.sin(x), n: "cos x", dn: "−sin x" }; },
    drags: { T: { at: (s) => [s.t, 1.7 + (s.fn === "sin" ? Math.sin(s.t) : Math.cos(s.t))], move: (s, p) => (s.t = clamp(Math.round(p[0] * 50) / 50, 0, 6.28)), color: "a", label: "점" } },
    draw(s, g) {
      const F = this.F(s), up = 1.7, dn = -1.7;
      g.grid({ labels: false });
      g.seg([0, up], [6.5, up], { color: "axis", w: 1.2 }).seg([0, dn], [6.5, dn], { color: "axis", w: 1.2 });
      [[Math.PI / 2, "π/2"], [Math.PI, "π"], [1.5 * Math.PI, "3π/2"], [2 * Math.PI, "2π"]].forEach(([x, l]) => { g.seg([x, up - 0.06], [x, up + 0.06], { color: "axis", w: 1 }).text([x, dn], l, { dy: 16, size: 11, color: "muted" }); });
      g.fx((x) => up + F.f(x), { color: "b", w: 3, from: 0, to: 6.4 });
      if (s.ghost) g.fx((x) => dn + F.d(x), { color: "c", w: 1.6, dash: "6 5", from: 0, to: 6.4 });
      const pts = []; for (let x = 0; x <= s.t + 1e-9; x += 0.04) pts.push([x, dn + F.d(x)]);
      if (pts.length > 1) g.path(pts, { color: "a", w: 3.2 });
      const P = [s.t, up + F.f(s.t)], m = F.d(s.t), u = 0.6 / Math.sqrt(1 + m * m);
      g.seg([P[0] - u, P[1] - m * u], [P[0] + u, P[1] + m * u], { color: "d", w: 2.6 });
      g.seg(P, [s.t, dn + m], { color: "muted", w: 1, dash: "3 4" }).point([s.t, dn + m], "", { color: "a", r: 5.5 }).point(P, "", { color: "b", r: 5 });
      g.text([0.1, up + 1.45], `y = ${F.n}`, { anchor: "start", bold: true, color: "b" }).text([0.1, dn + 1.45], `기울기의 자취 (점선: y = ${F.dn})`, { anchor: "start", bold: true, color: "a", size: 12 });
    },
    metrics(s) { const F = this.F(s); return [["x", fmt(s.t, 3)], ["접선의 기울기", fmt(F.d(s.t), 4), "key"], [F.dn.replace("x", fmt(s.t, 3)), fmt(F.d(s.t), 4)], ["결론", `(${F.n})′ = ${F.dn}`]]; },
    predict: [
      { q: "y = sin x의 x = 0에서 접선의 기울기는?", set: (s) => Object.assign(s, { fn: "sin", t: 1.5, ghost: false }), reveal: (s) => Object.assign(s, { t: 0, ghost: true }), answer: () => 1, why: "cos 0 = 1입니다(lim sin x/x = 1과 같은 이야기)." },
      { q: "y = cos x를 미분하면?", options: O("−sin x", "sin x", "cos x"), set: (s) => Object.assign(s, { fn: "cos", t: 0.5, ghost: false }), reveal: (s) => Object.assign(s, { t: 6.28, ghost: true }), answer: () => "a", why: "cos x는 x = 0부터 내려가므로 기울기가 처음에 음수입니다. 자취가 −sin x와 겹칩니다." },
    ],
  },
  {
    id: "calc2-chain", grade: II, unit: 2, lesson: "Ⅱ-7", title: "합성함수의 미분 — 톱니바퀴 연쇄", type: "조작", time: "10분",
    tags: ["합성함수의 미분", "연쇄법칙", "변화율"], links: ["cm2-composition", "calc2-sin-deriv"],
    desc: "x 바퀴를 돌리면 u 바퀴가 du/dx배, u 바퀴를 돌리면 y 바퀴가 dy/du배 돌아가도록 이어진 세 바퀴를 돌려, y가 x에 대해 (dy/du)·(du/dx)배로 변한다는 연쇄법칙을 확인합니다.",
    obs: ["x가 조금 변할 때 u는 du/dx배, y는 다시 dy/du배 변합니다.", "그래서 dy/dx = (dy/du)·(du/dx)입니다.", "y = (2x + 1)³에서 u = 2x + 1로 두면 y′ = 3u² · 2입니다."],
    q: "y = sin(x²)의 도함수를 연쇄법칙으로 구해 봅시다.",
    formula: "y = f(g(x)) ⇒ y′ = f′(g(x))·g′(x) · dy/dx = (dy/du)(du/dx)",
    en: { title: "Chain Rule as Linked Wheels", desc: "Rates multiply along a chain." },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [
      { key: "a", label: "du/dx (u 바퀴의 배율)", min: 0.5, max: 4, step: 0.5, value: 2 },
      { key: "b", label: "dy/du (y 바퀴의 배율)", min: 0.5, max: 4, step: 0.5, value: 3 },
      { key: "th", label: "x 바퀴를 돌린 각", min: 0, max: 360, step: 1, value: 40, unit: "°" },
    ],
    anim: { key: "th", min: 0, max: 360, speed: 40, loop: "wrap", label: "x 바퀴 돌리기" },
    draw(s, g) {
      const C = [[3, 5.5], [8, 5.5], [13, 5.5]], ang = [s.th, s.th * s.a, s.th * s.a * s.b], name = ["x", "u", "y"], col = ["b", "c", "a"];
      C.forEach((c, i) => {
        const pts = []; for (let k = 0; k < 24; k++) { const t = (k / 24) * 2 * Math.PI, r = k % 2 ? 1.9 : 2.15; pts.push([c[0] + r * Math.cos(t + (ang[i] * Math.PI) / 180), c[1] + r * Math.sin(t + (ang[i] * Math.PI) / 180)]); }
        g.poly(pts, { fill: col[i], fo: 0.18, color: col[i], w: 1.6 });
        const t = (ang[i] * Math.PI) / 180; g.vec(c, [c[0] + 1.7 * Math.cos(t), c[1] + 1.7 * Math.sin(t)], { color: col[i], w: 3 });
        g.text([c[0], c[1] - 2.6], `${name[i]} 바퀴`, { bold: true, size: 15, color: col[i] }).text([c[0], c[1] - 3.3], `${fmt(ang[i] % 360 || 0, 0)}° (누적 ${fmt(ang[i], 0)}°)`, { size: 12, color: "muted" });
      });
      g.text([5.5, 8.6], `× ${fmt(s.a)}`, { bold: true, size: 16, color: "c" }).text([10.5, 8.6], `× ${fmt(s.b)}`, { bold: true, size: 16, color: "a" });
      g.vec([4.9, 8.2], [6.3, 8.2], { color: "muted", w: 1.6 }).vec([9.9, 8.2], [11.3, 8.2], { color: "muted", w: 1.6 });
    },
    metrics(s) { return [["dy/dx", `${fmt(s.b)} × ${fmt(s.a)} = ${fmt(s.a * s.b)}`, "key"], ["x 바퀴 1회전이면", `y 바퀴 ${fmt(s.a * s.b)}회전`], ["예", "y = (2x + 1)³, x = 0: 3·1²·2 = 6"]]; },
    predict: [
      { q: "u가 x의 2배 빠르기로, y가 u의 3배 빠르기로 변하면 dy/dx는?", set: (s) => Object.assign(s, { a: 2, b: 3, th: 0 }), reveal: (s) => (s.th = 60), answer: () => 6, why: "변화율이 곱해집니다: 3 × 2 = 6." },
      { q: "y = (2x + 1)³의 x = 0에서 미분계수는?", set: (s) => Object.assign(s, { a: 2, b: 3, th: 0 }), answer: () => 6, why: "u = 2x + 1, dy/du = 3u² = 3, du/dx = 2이므로 6입니다." },
    ],
  },
  // ───────── Ⅲ 도함수의 활용 ─────────
  {
    id: "calc2-inverse-deriv", grade: II, unit: 3, lesson: "Ⅲ-1", title: "역함수의 미분 — 기울기는 역수가 된다", type: "2D", time: "10분",
    tags: ["역함수의 미분", "y = x 대칭", "로그함수의 미분"], links: ["cm2-inverse", "alg-exp-log-inverse", "calc-implicit"],
    desc: "y = f(x) 위의 점 P(a, b)에서의 접선과, y = x에 대칭인 역함수 위의 점 P′(b, a)에서의 접선을 함께 그려 두 기울기가 서로 역수임을 확인합니다.",
    obs: ["직선 y = x에 대칭이동하면 가로 변화와 세로 변화가 서로 바뀝니다.", "그래서 (f⁻¹)′(b) = 1/f′(a) (단, b = f(a), f′(a) ≠ 0)입니다.", "y = ln x는 y = eˣ의 역함수이므로 (ln x)′ = 1/eʸ = 1/x입니다."],
    q: "f′(a) = 0인 점에서 역함수의 접선은 어떤 모양일까요?",
    formula: "(f⁻¹)′(b) = 1 / f′(a) (b = f(a))",
    en: { title: "Derivative of an Inverse Function", desc: "Reflected tangents have reciprocal slopes." },
    view: { x: [-3, 6], y: [-3, 6] },
    params: [
      { key: "fn", label: "함수", type: "select", value: "exp", options: [["exp", "y = eˣ"], ["cub", "y = x³ + x"]] },
      { key: "a", label: "점 P의 x좌표 a", min: -1.5, max: 1.5, step: 0.05, value: 0.5 },
    ],
    anim: { key: "a", min: -1.5, max: 1.5, speed: 0.8, loop: "bounce", label: "점 움직이기" },
    F(s) { return s.fn === "exp" ? { f: Math.exp, d: Math.exp, n: "y = eˣ", inv: "y = ln x" } : { f: (x) => x ** 3 + x, d: (x) => 3 * x * x + 1, n: "y = x³ + x", inv: "역함수" }; },
    drags: { P: { at: (s) => [s.a, s.fn === "exp" ? Math.exp(s.a) : s.a ** 3 + s.a], move: (s, p) => (s.a = clamp(Math.round(p[0] * 20) / 20, -1.5, 1.5)), color: "a", label: "P" } },
    draw(s, g) {
      const F = this.F(s), b = F.f(s.a), m = F.d(s.a);
      g.grid();
      g.line([0, 0], [1, 1], { color: "muted", w: 1.4, dash: "7 5" });
      g.param((t) => [t, F.f(t)], -3, 3, { color: "b", w: 3, n: 600 }).param((t) => [F.f(t), t], -3, 3, { color: "e", w: 3, n: 600 });
      g.line([s.a, b], [s.a + 1, b + m], { color: "b", w: 1.8, dash: "6 4" }).line([b, s.a], [b + m, s.a + 1], { color: "e", w: 1.8, dash: "6 4" });
      g.point([s.a, b], `P(${fmt(s.a)}, ${fmt(b, 2)})`, { color: "b" }).point([b, s.a], `P′(${fmt(b, 2)}, ${fmt(s.a)})`, { color: "e", dy: 20 });
      g.text([g.xr[0] + 0.2, g.yr[1] - 0.4], F.n, { anchor: "start", bold: true, color: "b" }).text([g.xr[0] + 0.2, g.yr[1] - 1.1], F.inv, { anchor: "start", bold: true, color: "e" });
    },
    metrics(s) { const F = this.F(s), b = F.f(s.a), m = F.d(s.a); return [["f′(a)", fmt(m, 4)], ["(f⁻¹)′(b)", fmt(1 / m, 4), "key"], ["곱", `${fmt(m, 3)} × ${fmt(1 / m, 3)} = 1`]]; },
    predict: [
      { q: "f(x) = x³ + x에서 f(1) = 2, f′(1) = 4일 때 (f⁻¹)′(2)는? (분수나 소수로)", set: (s) => Object.assign(s, { fn: "cub", a: 0 }), reveal: (s) => (s.a = 1), answer: () => 0.25, tol: 0.001, why: "1/f′(1) = 1/4입니다." },
      { q: "y = ln x의 x = 1에서 기울기는?", set: (s) => Object.assign(s, { fn: "exp", a: 1 }), reveal: (s) => (s.a = 0), answer: () => 1, why: "eˣ의 x = 0에서 기울기 1의 역수이므로 1, 곧 1/x에 x = 1을 넣은 값입니다." },
    ],
  },
  // ───────── Ⅳ 적분법 ─────────
  {
    id: "calc2-parts", grade: II, unit: 4, lesson: "Ⅳ-3", title: "부분적분의 넓이 모형 — 두 넓이를 더하면 직사각형", type: "조작", time: "12분",
    tags: ["부분적분", "넓이", "곱의 미분"], links: ["calc-riemann", "calc2-riemann-limit"],
    desc: "곡선 v = f(u) 아래의 넓이 ∫v du와 왼쪽의 넓이 ∫u dv를 색으로 나누어, 둘을 더하면 큰 직사각형에서 작은 직사각형을 뺀 [uv]가 됨을 보고 부분적분 공식 ∫u dv = [uv] − ∫v du를 얻습니다.",
    obs: ["곡선 아래(파랑)와 곡선 왼쪽(주황) 넓이의 합은 u₁v₁ − u₀v₀입니다.", "그래서 ∫u dv = [uv] − ∫v du, 곧 부분적분 공식입니다.", "곱의 미분 (uv)′ = u′v + uv′을 적분한 것과 같습니다."],
    q: "∫₀¹ x eˣ dx를 부분적분으로 구해 봅시다.",
    formula: "∫ u dv = uv − ∫ v du · ∫ f(x)g′(x) dx = f(x)g(x) − ∫ f′(x)g(x) dx",
    en: { title: "Area Model for Integration by Parts", desc: "Two areas add to a rectangle." },
    view: { x: [-0.4, 3.4], y: [-0.4, 3.4] },
    params: [
      { key: "fn", label: "곡선", type: "select", value: "sq", options: [["sq", "v = u²"], ["rt", "v = √u"], ["cube", "v = u³/3"]] },
      { key: "a", label: "u의 범위 끝 a", min: 0.3, max: 1.7, step: 0.05, value: 1.2 },
    ],
    anim: { key: "a", min: 0.3, max: 1.7, speed: 0.4, loop: "bounce", label: "끝 움직이기" },
    FN: { sq: { f: (u) => u * u, A: (a) => a ** 3 / 3, n: "v = u²" }, rt: { f: (u) => Math.sqrt(u), A: (a) => (2 / 3) * a ** 1.5, n: "v = √u" }, cube: { f: (u) => u ** 3 / 3, A: (a) => a ** 4 / 12, n: "v = u³/3" } },
    draw(s, g) {
      const D = this.FN[s.fn], V = D.f(s.a);
      g.grid();
      g.region(D.f, () => 0, 0, s.a, { fill: "b", fo: 0.35, n: 200 });
      const left = []; for (let i = 0; i <= 200; i++) { const u = (s.a * i) / 200; left.push([u, D.f(u)]); }
      g.poly([[0, 0], ...left, [0, V]], { fill: "a", fo: 0.3, stroke: false });
      g.fx(D.f, { color: "ink", w: 3, from: 0, to: 3.2 });
      g.poly([[0, 0], [s.a, 0], [s.a, V], [0, V]], { color: "ink", w: 2, dash: "6 4" });
      g.text([s.a / 2, V * 0.18], "∫v du", { bold: true, color: "b", size: 14 }).text([s.a * 0.22, V * 0.8], "∫u dv", { bold: true, color: "a", size: 14 });
      g.text([g.xr[0] + 0.1, g.yr[1] - 0.2], D.n, { anchor: "start", bold: true });
    },
    metrics(s) {
      const D = this.FN[s.fn], V = D.f(s.a), A = D.A(s.a), B = s.a * V - A;
      return [["∫v du (파랑)", fmt(A, 4)], ["∫u dv (주황)", fmt(B, 4)], ["합 = uv", `${fmt(A + B, 4)} = ${fmt(s.a, 3)} × ${fmt(V, 4)}`, "key"]];
    },
    predict: [
      { q: "v = u², 0 ≤ u ≤ 1에서 주황 넓이 ∫u dv는? (분수나 소수로)", set: (s) => Object.assign(s, { fn: "sq", a: 0.6 }), reveal: (s) => (s.a = 1), answer: () => 2 / 3, tol: 0.005, why: "직사각형 1 × 1에서 파랑 ∫₀¹ u² du = 1/3을 빼면 2/3입니다." },
      { q: "∫₀¹ x eˣ dx의 값은?", set: (s) => Object.assign(s, { fn: "sq", a: 1 }), answer: () => 1, why: "[x eˣ]₀¹ − ∫₀¹ eˣ dx = e − (e − 1) = 1입니다." },
    ],
  },
  {
    id: "calc2-riemann-limit", grade: II, unit: 4, lesson: "Ⅳ-4", title: "정적분과 급수의 합 — lim ∑ f(k/n)·(1/n)", type: "조작", time: "10분",
    tags: ["급수의 합", "정적분", "구분구적법"], links: ["calc-riemann", "calc2-series"],
    desc: "[0, 1]을 n등분한 직사각형 넓이의 합 ∑ₖ₌₁ⁿ f(k/n)·(1/n)이 n → ∞일 때 정적분 ∫₀¹ f(x) dx로 다가가는 것을 확인하고, 급수의 극한을 정적분으로 바꾸어 계산합니다.",
    obs: ["k/n은 x좌표, 1/n은 직사각형의 폭 dx에 해당합니다.", "lim ∑ₖ₌₁ⁿ (k/n)²·(1/n) = ∫₀¹ x² dx = 1/3입니다.", "lim ∑ₖ₌₁ⁿ 1/(n + k) = ∫₀¹ 1/(1 + x) dx = ln 2입니다."],
    q: "lim(n→∞) (1/n)(√(1/n) + √(2/n) + ⋯ + √(n/n))의 값은 얼마일까요?",
    formula: "lim(n→∞) ∑ₖ₌₁ⁿ f(k/n)·(1/n) = ∫₀¹ f(x) dx",
    en: { title: "Definite Integrals as Limits of Sums", desc: "Turn a limit of sums into an integral." },
    view: { x: [-0.15, 1.25], y: [-0.15, 1.1] },
    params: [
      { key: "fn", label: "f(x)", type: "select", value: "sq", options: Object.entries(RF).map(([k, v]) => [k, "f(x) = " + v.n]) },
      { key: "n", label: "등분 수 n", min: 1, max: 100, step: 1, value: 8 },
    ],
    anim: { key: "n", min: 1, max: 100, speed: 12, label: "n 늘리기" },
    sum(s) { const f = RF[s.fn].f; let t = 0; for (let k = 1; k <= s.n; k++) t += f(k / s.n) / s.n; return t; },
    draw(s, g) {
      const F = RF[s.fn];
      g.grid({ step: 0.25 });
      for (let k = 1; k <= s.n; k++) { const x0 = (k - 1) / s.n, x1 = k / s.n, h = F.f(x1); g.poly([[x0, 0], [x1, 0], [x1, h], [x0, h]], { fill: "b", fo: 0.32, color: "b", w: s.n > 40 ? 0.4 : 1 }); }
      g.fx(F.f, { color: "a", w: 3, from: 0, to: 1.15 });
      g.text([0.02, 1.02], `f(x) = ${F.n}`, { anchor: "start", bold: true, color: "a" });
    },
    metrics(s) { const F = RF[s.fn], S = this.sum(s); return [["∑ f(k/n)·(1/n)", fmt(S, 5), "key"], ["∫₀¹ f(x) dx", F.Is], ["차이", fmt(S - F.I, 5)]]; },
    predict: [
      { q: "lim(n→∞) ∑ₖ₌₁ⁿ (k/n)²·(1/n)의 값은? (분수나 소수로)", set: (s) => Object.assign(s, { fn: "sq", n: 4 }), reveal: (s) => (s.n = 100), answer: () => 1 / 3, tol: 0.005, why: "∫₀¹ x² dx = 1/3입니다." },
      { q: "lim(n→∞) (1/(n + 1) + 1/(n + 2) + ⋯ + 1/(2n))의 값은 약 얼마일까요? (소수로)", set: (s) => Object.assign(s, { fn: "rec", n: 4 }), reveal: (s) => (s.n = 100), answer: () => Math.LN2, tol: 0.005, show: () => "ln 2 ≈ 0.693", why: "1/(n + k) = (1/n)·1/(1 + k/n)이므로 ∫₀¹ 1/(1 + x) dx = ln 2입니다." },
    ],
  },
  {
    id: "calc2-arc-length", grade: II, unit: 4, lesson: "Ⅳ-7", title: "곡선의 길이 — 꺾은선으로 다가가기", type: "조작", time: "10분",
    tags: ["곡선의 길이", "정적분", "근사"], links: ["calc-param-motion", "calc2-riemann-limit"],
    desc: "곡선 위에 점 n + 1개를 찍어 꺾은선으로 이은 길이가 n이 커질수록 곡선의 길이 ∫√(1 + (y′)²) dx(또는 ∫√((dx/dt)² + (dy/dt)²) dt)에 다가가는 것을 봅니다.",
    obs: ["꺾은선의 길이는 항상 곡선의 길이보다 짧거나 같습니다.", "작은 조각의 길이는 √(Δx² + Δy²) ≈ √(1 + (y′)²)·Δx입니다.", "사분원의 길이는 π/2이고, 꺾은선 길이는 그 아래에서 다가갑니다."],
    q: "y = x²의 0 ≤ x ≤ 1 부분의 길이를 구하는 정적분 식을 세워 봅시다.",
    formula: "L = ∫ₐᵇ √(1 + {f′(x)}²) dx = ∫ √((dx/dt)² + (dy/dt)²) dt",
    en: { title: "Arc Length by Polygonal Approximation", desc: "Polylines approach the length of a curve." },
    view: { x: [-0.3, 1.5], y: [-0.25, 1.25] },
    params: [
      { key: "fn", label: "곡선", type: "select", value: "circ", options: Object.entries(ARC).map(([k, v]) => [k, v.n]) },
      { key: "n", label: "꺾은선 조각 수 n", min: 1, max: 40, step: 1, value: 3 },
    ],
    anim: { key: "n", min: 1, max: 40, speed: 6, label: "조각 늘리기" },
    poly(s) { const A = ARC[s.fn], P = []; for (let k = 0; k <= s.n; k++) { const t = A.t0 + ((A.t1 - A.t0) * k) / s.n; P.push([A.x(t), A.y(t)]); } return P; },
    len(P) { let L = 0; for (let i = 1; i < P.length; i++) L += Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]); return L; },
    draw(s, g) {
      const A = ARC[s.fn], P = this.poly(s);
      g.grid({ step: 0.25 });
      g.param((t) => [A.x(t), A.y(t)], A.t0, A.t1, { color: "b", w: 3, n: 300 });
      g.path(P, { color: "a", w: 2.4 });
      P.forEach((p) => g.point(p, "", { color: "a", r: s.n > 20 ? 2.5 : 4 }));
      g.text([g.xr[0] + 0.05, g.yr[1] - 0.06], A.n, { anchor: "start", bold: true, color: "b" });
    },
    metrics(s) { const A = ARC[s.fn], L = this.len(this.poly(s)); return [["꺾은선의 길이", fmt(L, 5), "key"], ["곡선의 길이", A.Ls], ["차이", fmt(A.L - L, 5)]]; },
    predict: [
      { q: "반지름 1인 사분원의 길이는 약 얼마일까요? (소수로)", set: (s) => Object.assign(s, { fn: "circ", n: 2 }), reveal: (s) => (s.n = 40), answer: () => Math.PI / 2, tol: 0.005, show: () => "π/2 ≈ 1.571", why: "원둘레 2π의 1/4입니다." },
      { q: "꺾은선의 길이는 곡선의 길이보다?", options: O("항상 짧거나 같다", "항상 길다", "그때그때 다르다"), set: (s) => Object.assign(s, { fn: "par", n: 3 }), answer: () => "a", why: "두 점 사이의 가장 짧은 길은 선분이므로 각 조각이 곡선보다 짧습니다." },
    ],
  },
  // ───────── 확률과 통계 ─────────
  {
    id: "pst-lottery", grade: PS, unit: 2, lesson: "Ⅱ-5", title: "제비뽑기는 먼저 뽑아야 유리할까? — 확률의 곱셈정리", type: "데이터", time: "10분",
    tags: ["확률의 곱셈정리", "조건부확률", "비복원 추출"], links: ["pst-bayes", "pst-total-prob", "g2-probability-calc"],
    desc: "제비 n개 중 당첨 k개를 차례로 한 개씩 뽑을 때(돌려놓지 않음) 몇 번째 사람이든 당첨 확률이 k/n으로 같다는 것을 확률의 곱셈정리와 시뮬레이션으로 확인합니다.",
    obs: ["두 번째 사람의 당첨 확률은 P(당첨·당첨) + P(꽝·당첨) = (k/n)·((k − 1)/(n − 1)) + ((n − k)/n)·(k/(n − 1)) = k/n입니다.", "뽑는 순서와 상관없이 당첨 확률은 같습니다.", "앞사람의 결과를 알면(조건부확률) 확률이 달라집니다."],
    q: "앞사람이 당첨된 것을 알고 나면 두 번째 사람의 당첨 확률은 얼마일까요?",
    formula: "P(A ∩ B) = P(A)·P(B | A) · P(i번째 당첨) = k/n",
    en: { title: "Does Drawing First Help?", desc: "Every position has the same chance in a lottery without replacement." },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [
      { key: "n", label: "제비 수 n", min: 3, max: 10, step: 1, value: 5 },
      { key: "k", label: "당첨 제비 수 k", min: 1, max: (s) => s.n - 1, step: 1, value: 1 },
    ],
    buttons: [["run100", "100번 뽑기"], ["run1000", "1000번 뽑기"], ["reset", "비우기"]],
    init: () => ({ wins: Array(10).fill(0), runs: 0 }),
    derive(s) { s.k = clamp(s.k, 1, s.n - 1); },
    onChange(s, key) { if (key === "n" || key === "k") { s.wins = Array(10).fill(0); s.runs = 0; } },
    onDo(k, s) {
      if (k === "reset") { s.wins = Array(10).fill(0); s.runs = 0; return; }
      const R = k === "run100" ? 100 : 1000;
      for (let r = 0; r < R; r++) { const a = Array.from({ length: s.n }, (_, i) => i < s.k); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } a.forEach((w, i) => w && s.wins[i]++); s.runs++; }
    },
    draw(s, g) {
      const p = s.k / s.n, x0 = 1.5, W = 13.5, w = W / s.n, H = 7.5 / Math.min(1, p * 2 + 0.1), y0 = 1.4;
      g.seg([x0, y0], [x0 + W, y0], { color: "axis", w: 1.4 });
      g.seg([x0, y0 + H * p], [x0 + W, y0 + H * p], { color: "e", w: 2, dash: "7 5" });
      g.note(20, 54, `보라 점선: 이론값 k/n = ${frac(p)}`, { bold: true, color: "e" });
      for (let i = 0; i < s.n; i++) {
        const r = s.runs ? s.wins[i] / s.runs : 0, x = x0 + i * w;
        g.poly([[x + w * 0.15, y0], [x + w * 0.85, y0], [x + w * 0.85, y0 + H * r], [x + w * 0.15, y0 + H * r]], { fill: "b", fo: 0.5, color: "b", w: 1 });
        g.text([x + w / 2, y0], `${i + 1}번째`, { dy: 16, size: 12, color: "muted" });
        if (s.runs) g.text([x + w / 2, y0 + H * r], fmt(r, 3), { dy: -6, size: 11, bold: true });
      }
      g.note(20, 30, s.runs ? `${s.runs}번 뽑은 결과 — 뽑는 순서별 당첨 비율` : "단추를 눌러 제비뽑기를 여러 번 해 보세요", { bold: true, color: "ink" });
    },
    metrics(s) { const p = s.k / s.n; return [["어느 순서든 당첨 확률", `${s.k}/${s.n} = ${fmt(p, 4)}`, "key"], ["2번째 사람 (곱셈정리)", `(${s.k}/${s.n})·(${s.k - 1}/${s.n - 1}) + (${s.n - s.k}/${s.n})·(${s.k}/${s.n - 1}) = ${frac(p)}`], ["뽑은 횟수", `${s.runs}번`]]; },
    predict: [
      { q: "제비 5개 중 당첨 1개일 때 두 번째로 뽑는 사람의 당첨 확률은? (분수나 소수로)", set: (s) => Object.assign(s, { n: 5, k: 1, wins: Array(10).fill(0), runs: 0 }), answer: () => 0.2, tol: 0.001, why: "(4/5)·(1/4) = 1/5로 첫 번째 사람과 같습니다." },
      { q: "제비 10개 중 당첨 3개일 때 7번째 사람의 당첨 확률은? (분수나 소수로)", set: (s) => Object.assign(s, { n: 10, k: 3, wins: Array(10).fill(0), runs: 0 }), answer: () => 0.3, tol: 0.001, why: "순서와 상관없이 k/n = 3/10입니다." },
    ],
  },
  {
    id: "pst-sampling-bias", grade: PS, unit: 4, lesson: "Ⅳ-1", title: "모집단과 표본 — 치우친 표본이 만드는 착각", type: "데이터", time: "12분",
    tags: ["모집단", "표본", "임의추출"], links: ["pst-sample-mean", "cul-population"],
    desc: "학생 400명의 하루 독서 시간을 모집단으로 두고, 무작위로 뽑은 표본과 도서관 근처 학생만 뽑은 표본(편의 표본)의 평균을 비교해 표본을 임의로 뽑아야 하는 까닭을 확인합니다.",
    obs: ["임의추출한 표본의 평균은 모평균 둘레에서 흔들립니다.", "도서관 근처 학생만 조사하면 표본평균이 모평균보다 계속 크게 나옵니다(편향).", "표본을 크게 해도 치우친 방법의 오차는 줄어들지 않습니다."],
    q: "온라인 설문에 자발적으로 응답한 사람들의 의견은 전체 의견을 대표할까요?",
    formula: "임의추출: 모든 대상이 뽑힐 가능성이 같다 · 표본평균 X̄ ≈ 모평균 m",
    en: { title: "Population and Biased Samples", desc: "Random samples vs convenience samples." },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [
      { key: "how", label: "표본 뽑는 방법", type: "seg", value: "rand", options: [["rand", "무작위(임의추출)"], ["near", "도서관 근처만"]] },
      { key: "m", label: "표본의 크기", min: 10, max: 100, step: 5, value: 30 },
    ],
    buttons: [["again", "다시 뽑기"], ["many", "50번 뽑아 평균들 보기"]],
    init: () => ({ seed: 11, hist: [] }),
    onChange(s, key) { if (key === "how" || key === "m") s.hist = []; },
    onDo(k, s) {
      if (k === "again") { s.seed++; s.hist.push(this.sampleMean(s)); }
      if (k === "many") for (let i = 0; i < 50; i++) { s.seed++; s.hist.push(this.sampleMean(s)); }
      if (s.hist.length > 400) s.hist = s.hist.slice(-400);
    },
    pop() { if (this._pop) return this._pop; const r = lcg(2024), P = []; for (let i = 0; i < 20; i++) for (let j = 0; j < 20; j++) { const x = 0.6 + i * 0.5, y = 0.8 + j * 0.48, base = 20 + 4 * i + 25 * r() + (i > 14 ? 20 : 0); P.push({ x, y, v: Math.round(base) }); } return (this._pop = P); },
    pick(s) { const P = this.pop(), r = lcg(s.seed * 7919 + s.m); if (s.how === "near") { const idx = P.map((p, i) => [Math.hypot(p.x - 10.6, p.y - 5.4), i]).sort((a, b) => a[0] - b[0]); const near = idx.slice(0, Math.min(P.length, s.m * 2)).map(([, i]) => i); for (let i = near.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [near[i], near[j]] = [near[j], near[i]]; } return near.slice(0, s.m); } const all = P.map((_, i) => i); for (let i = all.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [all[i], all[j]] = [all[j], all[i]]; } return all.slice(0, s.m); },
    sampleMean(s) { const P = this.pop(), I = this.pick(s); return I.reduce((t, i) => t + P[i].v, 0) / I.length; },
    draw(s, g) {
      const P = this.pop(), I = new Set(this.pick(s)), mx = Math.max(...P.map((p) => p.v)), mn = Math.min(...P.map((p) => p.v));
      g.poly([[10.2, 0.4], [11, 0.4], [11, 10.2], [10.2, 10.2]], { fill: "f", fo: 0.15, stroke: false });
      g.text([10.6, 10.5], "도서관", { bold: true, size: 13, color: "f" });
      P.forEach((p, i) => { const t = (p.v - mn) / (mx - mn); g.circle([p.x, p.y], I.has(i) ? 0.2 : 0.13, { fill: t > 0.66 ? "a" : t > 0.33 ? "e" : "b", fo: I.has(i) ? 0.95 : 0.3, color: I.has(i) ? "ink" : "muted", w: I.has(i) ? 1.4 : 0.3 }); });
      const pm = P.reduce((t, p) => t + p.v, 0) / P.length, H = s.hist, x0 = 11.6, W = 4.1;
      g.text([x0 + W / 2, 10.5], "표본평균들", { bold: true, size: 12 });
      g.seg([x0, 1], [x0 + W, 1], { color: "axis", w: 1 });
      const lo = Math.floor(mn / 20) * 20, hi = Math.ceil(mx / 20) * 20, sc = (v) => x0 + ((v - lo) / (hi - lo)) * W;
      g.seg([sc(pm), 1], [sc(pm), 9.8], { color: "c", w: 2, dash: "6 4" }).text([sc(pm), 9.8], "모평균", { dy: -4, size: 11, bold: true, color: "c" });
      const bins = {}; H.forEach((v) => { const b = Math.round(v); bins[b] = (bins[b] || 0) + 1; });
      Object.entries(bins).forEach(([b, c]) => g.seg([sc(+b), 1], [sc(+b), 1 + Math.min(8.5, c * 0.35)], { color: s.how === "near" ? "a" : "b", w: 3 }));
      for (let v = lo; v <= hi; v += 40) g.text([sc(v), 1], String(v), { dy: 14, size: 10, color: "muted" });
    },
    metrics(s) {
      const P = this.pop(), pm = P.reduce((t, p) => t + p.v, 0) / P.length, sm = this.sampleMean(s), H = s.hist;
      return [["모평균 (400명)", `${fmt(pm, 2)}분`], ["이번 표본평균", `${fmt(sm, 2)}분`, "key"], ["차이", fmt(sm - pm, 2)], ["뽑은 표본평균들의 평균", H.length ? `${fmt(H.reduce((a, b) => a + b, 0) / H.length, 2)}분 (${H.length}번)` : "—"]];
    },
    predict: [
      { q: "도서관 근처 학생만 조사한 표본평균은 모평균과 비교해 어떨까요?", options: O("계속 더 크게 나온다", "모평균 둘레에서 고르게 흔들린다", "계속 더 작게 나온다"), set: (s) => Object.assign(s, { how: "near", m: 30, hist: [] }), answer: () => "a", why: "도서관 근처에 책을 많이 읽는 학생이 모여 있어 표본이 한쪽으로 치우칩니다." },
      { q: "무작위 표본의 크기를 키우면 표본평균들은?", options: O("모평균 가까이 더 좁게 모인다", "더 넓게 퍼진다", "변화 없다"), set: (s) => Object.assign(s, { how: "rand", m: 10, hist: [] }), answer: () => "a", why: "표본평균의 표준편차 σ/√n이 줄어듭니다." },
    ],
  },
];
