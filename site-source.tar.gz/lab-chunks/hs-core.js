import { parseAnswer, feedbackFingerprint, normalizePreset, reconcileParams } from "./answer-input.js";
// McKay Math Atelier — 고등 실험 공통 엔진 (2D 좌표평면 · 3D 공간 · 조작판)
export { reconcileParams } from "./answer-input.js";
import { mathHTML, setMath } from "./mathtex.js";
export const W = 640, H = 440;
const TAU = Math.PI * 2;
export const deg = (d) => (d * Math.PI) / 180;
export const rad2deg = (r) => (r * 180) / Math.PI;
export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const dist = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1]);
export const add = (p, q) => p.map((v, i) => v + q[i]);
export const sub = (p, q) => p.map((v, i) => v - q[i]);
export const mul = (p, k) => p.map((v) => v * k);
export const dot = (p, q) => p.reduce((s, v, i) => s + v * q[i], 0);
export const len = (p) => Math.hypot(...p);
export const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
export const norm = (p) => { const l = len(p) || 1; return p.map((v) => v / l); };
export const lerp = (p, q, t) => p.map((v, i) => v + (q[i] - v) * t);
export const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

// ── 수 표기 ─────────────────────────────────────────────
export function fmt(x, d = 2) {
  if (!Number.isFinite(x)) return "—";
  if (Math.abs(x) < 1e-10) return "0";
  const r = Math.round(x);
  if (Math.abs(x - r) < 1e-9) return String(r).replace("-", "−");
  return String(Number(x.toFixed(d))).replace("-", "−");
}
export function frac(x, maxDen = 12) {
  if (!Number.isFinite(x)) return "—";
  for (let q = 1; q <= maxDen; q++) {
    const p = Math.round(x * q);
    if (Math.abs(p / q - x) < 1e-9) return q === 1 ? fmt(p) : `${p < 0 ? "−" : ""}${Math.abs(p)}/${q}`;
  }
  return fmt(x);
}
// 제곱값 sq에 대하여 √sq를 k√m 꼴로 (정수일 때만)
export function surd(sq) {
  if (!Number.isFinite(sq) || sq < -1e-9) return "—";
  const n = Math.round(sq);
  if (Math.abs(sq - n) > 1e-9) return fmt(Math.sqrt(Math.max(0, sq)));
  if (n === 0) return "0";
  let k = 1, m = n;
  for (let f = 2; f * f <= m; f++) while (m % (f * f) === 0) { m /= f * f; k *= f; }
  return m === 1 ? String(k) : `${k === 1 ? "" : k}√${m}`;
}
export function piFmt(r) {
  const t = r / Math.PI;
  for (let q = 1; q <= 72; q++) {
    const p = Math.round(t * q);
    if (Math.abs(p / q - t) < 1e-9) {
      if (p === 0) return "0";
      const num = Math.abs(p) === 1 ? "π" : `${Math.abs(p)}π`;
      return (p < 0 ? "−" : "") + (q === 1 ? num : `${num}/${q}`);
    }
  }
  return fmt(r, 3);
}
// 일차식 계수 표기: [[계수, 문자], ...], 상수
export function poly(terms, c = 0) {
  let s = "";
  for (const [k, v] of terms) {
    if (Math.abs(k) < 1e-10) continue;
    const a = Math.abs(k), sign = k < 0 ? "−" : "+";
    const co = Math.abs(a - 1) < 1e-10 && v ? "" : fmt(a);
    s += s ? ` ${sign} ${co}${v}` : `${k < 0 ? "−" : ""}${co}${v}`;
  }
  if (Math.abs(c) > 1e-10 || !s) s += s ? ` ${c < 0 ? "−" : "+"} ${fmt(Math.abs(c))}` : fmt(c);
  return s;
}
// (x − a)² 꼴
export function shiftSq(v, a) {
  if (Math.abs(a) < 1e-10) return `${v}²`;
  return `(${v} ${a > 0 ? "−" : "+"} ${fmt(Math.abs(a))})²`;
}

export const COLORS = { ink: "var(--pl-ink)", muted: "var(--pl-muted)", grid: "var(--pl-grid)", axis: "var(--pl-axis)", a: "var(--pl-a)", b: "var(--pl-b)", c: "var(--pl-c)", d: "var(--pl-d)", e: "var(--pl-e)", f: "var(--pl-f)", paper: "var(--pl-paper)" };
const col = (c) => COLORS[c] || c || COLORS.ink;
const attrs = (o = {}) => {
  let s = "";
  if (o.dash) s += ` stroke-dasharray="${o.dash === true ? "6 6" : o.dash}"`;
  if (o.opacity != null) s += ` opacity="${o.opacity}"`;
  if (o.cls) s += ` class="${o.cls}"`;
  return s;
};

// ── 2D 좌표평면 ─────────────────────────────────────────
export class Plot {
  constructor(view = {}, size = [W, H]) {
    this.W = size[0]; this.H = size[1];
    const x = view.x || [-6, 6], y = view.y || [-4.5, 4.5];
    const pad = view.pad ?? 18;
    this.s = Math.min((this.W - 2 * pad) / (x[1] - x[0]), (this.H - 2 * pad) / (y[1] - y[0]));
    this.cx = (x[0] + x[1]) / 2; this.cy = (y[0] + y[1]) / 2;
    this.xr = [this.cx - this.W / 2 / this.s, this.cx + this.W / 2 / this.s];
    this.yr = [this.cy - this.H / 2 / this.s, this.cy + this.H / 2 / this.s];
    this.L = { grid: [], fill: [], line: [], top: [], point: [], text: [], handle: [] };
    this.thumb = false;
  }
  X(p) { return [this.W / 2 + (p[0] - this.cx) * this.s, this.H / 2 - (p[1] - this.cy) * this.s]; }
  inv(q) { return [this.cx + (q[0] - this.W / 2) / this.s, this.cy - (q[1] - this.H / 2) / this.s]; }
  n(v) { return Math.round(v * 10) / 10; }
  xy(p) { const q = this.X(p); return `${this.n(q[0])},${this.n(q[1])}`; }
  grid(o = {}) {
    const step = o.step || 1, lab = o.labels !== false && !this.thumb;
    const [x0, x1] = this.xr, [y0, y1] = this.yr;
    let g = "";
    for (let x = Math.ceil(x0 / step) * step; x <= x1; x += step) {
      const [sx] = this.X([x, 0]);
      g += `<line x1="${this.n(sx)}" y1="0" x2="${this.n(sx)}" y2="${this.H}" stroke="${COLORS.grid}" stroke-width="1"/>`;
    }
    for (let y = Math.ceil(y0 / step) * step; y <= y1; y += step) {
      const [, sy] = this.X([0, y]);
      g += `<line x1="0" y1="${this.n(sy)}" x2="${this.W}" y2="${this.n(sy)}" stroke="${COLORS.grid}" stroke-width="1"/>`;
    }
    if (o.axes !== false) {
      const [ox, oy] = this.X([0, 0]);
      g += `<line x1="0" y1="${this.n(oy)}" x2="${this.W - 6}" y2="${this.n(oy)}" stroke="${COLORS.axis}" stroke-width="1.6" marker-end="url(#ax-arrow)"/>`;
      g += `<line x1="${this.n(ox)}" y1="${this.H}" x2="${this.n(ox)}" y2="6" stroke="${COLORS.axis}" stroke-width="1.6" marker-end="url(#ax-arrow)"/>`;
      if (lab) {
        const every = o.every || (this.s < 26 ? 2 : 1);
        for (let x = Math.ceil(x0); x <= x1 - 0.5; x++) {
          if (!x || x % every) continue;
          const [sx, sy] = this.X([x, 0]);
          g += `<text x="${this.n(sx)}" y="${this.n(clamp(sy + 16, 14, this.H - 4))}" class="tick" text-anchor="middle">${String(x).replace("-", "−")}</text>`;
        }
        for (let y = Math.ceil(y0); y <= y1 - 0.5; y++) {
          if (!y || y % every) continue;
          const [sx, sy] = this.X([0, y]);
          g += `<text x="${this.n(clamp(sx - 7, 16, this.W - 4))}" y="${this.n(sy + 4)}" class="tick" text-anchor="end">${String(y).replace("-", "−")}</text>`;
        }
        const [sx, sy] = this.X([0, 0]);
        g += `<text x="${this.n(sx - 7)}" y="${this.n(sy + 16)}" class="tick" text-anchor="end">O</text>`;
        g += `<text x="${this.W - 10}" y="${this.n(clamp(sy - 8, 14, this.H))}" class="axis-name" text-anchor="end">${o.xName || "x"}</text>`;
        g += `<text x="${this.n(clamp(sx + 10, 0, this.W - 12))}" y="16" class="axis-name">${o.yName || "y"}</text>`;
      }
    }
    this.L.grid.push(g);
    return this;
  }
  seg(p, q, o = {}) {
    const a = this.X(p), b = this.X(q);
    this.L[o.layer || "line"].push(`<line x1="${this.n(a[0])}" y1="${this.n(a[1])}" x2="${this.n(b[0])}" y2="${this.n(b[1])}" stroke="${col(o.color)}" stroke-width="${o.w || 2.4}" stroke-linecap="round"${attrs(o)}/>`);
    return this;
  }
  // 두 점을 지나는 직선 (화면 끝까지)
  line(p, q, o = {}) {
    const d = sub(q, p); if (len(d) < 1e-12) return this;
    const big = (this.xr[1] - this.xr[0] + this.yr[1] - this.yr[0]) * 2;
    const u = norm(d);
    return this.seg(add(p, mul(u, -big)), add(p, mul(u, big)), o);
  }
  // ax + by + c = 0
  lineABC(a, b, c, o = {}) {
    if (Math.abs(b) > 1e-12) return this.line([0, -c / b], [1, -(a + c) / b], o);
    if (Math.abs(a) > 1e-12) return this.line([-c / a, 0], [-c / a, 1], o);
    return this;
  }
  ray(p, dir, o = {}) { const big = (this.xr[1] - this.xr[0]) * 3; return this.seg(p, add(p, mul(norm(dir), big)), o); }
  vec(p, q, o = {}) {
    const a = this.X(p), b = this.X(q);
    const L = Math.hypot(b[0] - a[0], b[1] - a[1]); if (L < 1) return this;
    const ux = (b[0] - a[0]) / L, uy = (b[1] - a[1]) / L, hl = Math.min(14, L * 0.45), hw = hl * 0.45;
    const e = [b[0] - ux * hl, b[1] - uy * hl];
    const c = col(o.color);
    this.L[o.layer || "top"].push(`<line x1="${this.n(a[0])}" y1="${this.n(a[1])}" x2="${this.n(e[0])}" y2="${this.n(e[1])}" stroke="${c}" stroke-width="${o.w || 3}" stroke-linecap="round"${attrs(o)}/><polygon points="${this.n(b[0])},${this.n(b[1])} ${this.n(e[0] - uy * hw)},${this.n(e[1] + ux * hw)} ${this.n(e[0] + uy * hw)},${this.n(e[1] - ux * hw)}" fill="${c}"${o.opacity != null ? ` opacity="${o.opacity}"` : ""}/>`);
    if (o.label && !this.thumb) this.text(lerp(p, q, o.at ?? 0.55), o.label, { color: o.color, dx: o.dx ?? -uy * 16, dy: o.dy ?? ux * 16 + 5, italic: true, bold: true });
    return this;
  }
  circle(c, r, o = {}) {
    const q = this.X(c);
    this.L[o.layer || (o.fill ? "fill" : "line")].push(`<circle cx="${this.n(q[0])}" cy="${this.n(q[1])}" r="${this.n(Math.abs(r) * this.s)}" fill="${o.fill ? col(o.fill) : "none"}" fill-opacity="${o.fo ?? 0.14}" stroke="${o.stroke === false ? "none" : col(o.color)}" stroke-width="${o.w || 2.4}"${attrs(o)}/>`);
    return this;
  }
  poly(pts, o = {}) {
    const s = pts.map((p) => this.xy(p)).join(" ");
    this.L[o.layer || "fill"].push(`<polygon points="${s}" fill="${o.fill ? col(o.fill) : "none"}" fill-opacity="${o.fo ?? 0.14}" stroke="${o.stroke === false ? "none" : col(o.color || o.fill)}" stroke-width="${o.w || 2}" stroke-linejoin="round"${attrs(o)}/>`);
    return this;
  }
  path(pts, o = {}) {
    if (pts.length < 2) return this;
    const d = pts.map((p, i) => (i ? "L" : "M") + this.xy(p)).join("");
    this.L[o.layer || "line"].push(`<path d="${d}${o.close ? "Z" : ""}" fill="${o.fill ? col(o.fill) : "none"}" fill-opacity="${o.fo ?? 0.14}" stroke="${o.stroke === false ? "none" : col(o.color)}" stroke-width="${o.w || 2.6}" stroke-linejoin="round" stroke-linecap="round"${attrs(o)}/>`);
    return this;
  }
  // 매개변수 곡선 (끊김 자동 처리)
  param(fn, t0, t1, o = {}) {
    const n = o.n || 360, segs = []; let cur = [];
    const [x0, x1] = this.xr, [y0, y1] = this.yr, mx = (x1 - x0), my = (y1 - y0);
    let prev = null;
    for (let i = 0; i <= n; i++) {
      const p = fn(t0 + ((t1 - t0) * i) / n);
      const ok = p && Number.isFinite(p[0]) && Number.isFinite(p[1]) && p[0] > x0 - mx && p[0] < x1 + mx && p[1] > y0 - my && p[1] < y1 + my;
      if (ok && prev && Math.abs(p[1] - prev[1]) > my * 0.9) { if (cur.length > 1) segs.push(cur); cur = []; }
      if (ok) cur.push(p); else { if (cur.length > 1) segs.push(cur); cur = []; }
      prev = ok ? p : null;
    }
    if (cur.length > 1) segs.push(cur);
    segs.forEach((s) => this.path(s, o));
    return this;
  }
  fx(f, o = {}) { const a = o.from ?? this.xr[0], b = o.to ?? this.xr[1]; return this.param((x) => [x, f(x)], a, b, { n: 480, ...o }); }
  // y=f(x), y=g(x) 사이 영역
  region(f, g, a, b, o = {}) {
    const n = o.n || 160, top = [], bot = [];
    for (let i = 0; i <= n; i++) { const x = a + ((b - a) * i) / n; top.push([x, f(x)]); bot.push([x, g(x)]); }
    return this.poly([...top, ...bot.reverse()], { stroke: false, fo: o.fo ?? 0.22, ...o });
  }
  point(p, label, o = {}) {
    const q = this.X(p), r = o.r || 5.5;
    this.L.point.push(`<circle cx="${this.n(q[0])}" cy="${this.n(q[1])}" r="${r}" fill="${o.hollow ? COLORS.paper : col(o.color)}" stroke="${o.hollow ? col(o.color) : COLORS.paper}" stroke-width="2"/>`);
    if (label && !this.thumb) this.text(p, label, { dx: o.dx ?? 12, dy: o.dy ?? -10, color: o.lcolor || "ink", bold: true, anchor: o.anchor || "start", size: o.size });
    return this;
  }
  text(p, s, o = {}) {
    if (this.thumb && !o.keep) return this;
    const q = this.X(p);
    const x = clamp(q[0] + (o.dx || 0), 6, this.W - 6), y = clamp(q[1] + (o.dy || 0), 14, this.H - 6);
    this.L.text.push(`<text x="${this.n(x)}" y="${this.n(y)}" fill="${col(o.color)}" text-anchor="${o.anchor || "middle"}" class="pl-text${o.bold ? " b" : ""}${o.italic ? " i" : ""}${o.mono ? " m" : ""}"${o.size ? ` font-size="${o.size}"` : ""}>${esc(s)}</text>`);
    return this;
  }
  // 화면 고정 위치 텍스트(범례·안내)
  note(x, y, s, o = {}) { if (this.thumb) return this; this.L.text.push(`<text x="${x}" y="${y}" fill="${col(o.color)}" text-anchor="${o.anchor || "start"}" class="pl-text${o.bold ? " b" : ""}${o.mono ? " m" : ""}"${o.size ? ` font-size="${o.size}"` : ""}>${esc(s)}</text>`); return this; }
  // 각 표시 (꼭짓점 v, 두 방향 점 p1, p2) — 반시계 p1→p2
  arc(v, p1, p2, o = {}) {
    const a1 = Math.atan2(p1[1] - v[1], p1[0] - v[0]);
    let a2 = Math.atan2(p2[1] - v[1], p2[0] - v[0]);
    if (o.ccw !== false) { while (a2 < a1) a2 += TAU; } else { const t = Math.min(a1, a2); const u = Math.max(a1, a2); return this.arc(v, [v[0] + Math.cos(t), v[1] + Math.sin(t)], [v[0] + Math.cos(u), v[1] + Math.sin(u)], { ...o, ccw: true }); }
    const r = (o.r || 26) / this.s, pts = [v];
    for (let i = 0; i <= 40; i++) { const t = a1 + ((a2 - a1) * i) / 40; pts.push([v[0] + r * Math.cos(t), v[1] + r * Math.sin(t)]); }
    this.poly(pts, { fill: o.color || "a", fo: o.fo ?? 0.18, stroke: false, layer: "fill" });
    this.path(pts.slice(1), { color: o.color || "a", w: 1.8 });
    if (o.label && !this.thumb) { const m = (a1 + a2) / 2, rr = r + (o.lr || 16) / this.s; this.text([v[0] + rr * Math.cos(m), v[1] + rr * Math.sin(m) - 4 / this.s], o.label, { color: o.color || "a", bold: true, size: o.size }); }
    return this;
  }
  right(v, p1, p2, o = {}) {
    const k = (o.size || 12) / this.s, u = mul(norm(sub(p1, v)), k), w = mul(norm(sub(p2, v)), k);
    return this.path([add(v, u), add(add(v, u), w), add(v, w)], { color: o.color || "muted", w: 1.6 });
  }
  handle(p, key, o = {}) {
    if (this.thumb) return this;
    const q = this.X(p);
    this.L.handle.push(`<g class="hs-handle" data-drag="${key}" tabindex="0" role="slider" aria-label="${esc(o.label || key)} 움직이기 (방향키)" aria-valuetext="(${fmt(p[0])}, ${fmt(p[1])})"><circle cx="${this.n(q[0])}" cy="${this.n(q[1])}" r="20" fill="transparent"/><circle class="ring" cx="${this.n(q[0])}" cy="${this.n(q[1])}" r="10" fill="none" stroke="${col(o.color || "a")}" stroke-width="2"/></g>`);
    return this;
  }
  svg(label = "수학 시각화") {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${this.W} ${this.H}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="${esc(label)}" class="hs-svg"><defs><marker id="ax-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="${COLORS.axis}"/></marker></defs><rect width="${this.W}" height="${this.H}" fill="${COLORS.paper}"/>${Object.values(this.L).map((a) => a.join("")).join("")}</svg>`;
  }
}

// ── 3D 공간 (정사영 + 약한 원근, 드래그 회전) ───────────────────
export class Space {
  constructor(cam = {}, size = [W, H]) {
    this.W = size[0]; this.H = size[1];
    this.az = deg(cam.yaw ?? 35); this.el = deg(cam.pitch ?? 22);
    this.scale = cam.scale ?? 38; this.D = cam.persp ?? 28;
    this.center = cam.center || [0, 0, 0];
    const a = this.az, e = this.el;
    this.r = [-Math.sin(a), Math.cos(a), 0];
    this.u = [-Math.sin(e) * Math.cos(a), -Math.sin(e) * Math.sin(a), Math.cos(e)];
    this.d = [Math.cos(e) * Math.cos(a), Math.cos(e) * Math.sin(a), Math.sin(e)];
    this.items = []; this.over = []; this.thumb = false;
    this.oy = cam.oy ?? 0;
  }
  P(v) {
    const p = sub(v, this.center);
    const depth = dot(p, this.d), f = this.D / (this.D - depth);
    return [this.W / 2 + dot(p, this.r) * this.scale * f, this.H / 2 + this.oy - dot(p, this.u) * this.scale * f, depth];
  }
  n(v) { return Math.round(v * 10) / 10; }
  seg(a, b, o = {}) {
    const p = this.P(a), q = this.P(b);
    this.items.push({ z: (p[2] + q[2]) / 2 + (o.bias || 0), s: `<line x1="${this.n(p[0])}" y1="${this.n(p[1])}" x2="${this.n(q[0])}" y2="${this.n(q[1])}" stroke="${col(o.color)}" stroke-width="${o.w || 2.2}" stroke-linecap="round"${attrs(o)}/>` });
    return this;
  }
  path(pts, o = {}) {
    for (let i = 0; i < pts.length - 1; i++) this.seg(pts[i], pts[i + 1], o);
    if (o.close && pts.length > 2) this.seg(pts[pts.length - 1], pts[0], o);
    return this;
  }
  face(pts, o = {}) {
    const q = pts.map((v) => this.P(v));
    const z = q.reduce((s, v) => s + v[2], 0) / q.length + (o.bias || 0);
    this.items.push({ z, s: `<polygon points="${q.map((v) => `${this.n(v[0])},${this.n(v[1])}`).join(" ")}" fill="${col(o.fill || o.color || "b")}" fill-opacity="${o.fo ?? 0.18}" stroke="${o.stroke === false ? "none" : col(o.color || o.fill || "b")}" stroke-width="${o.w || 1.4}" stroke-linejoin="round"${attrs(o)}/>` });
    return this;
  }
  vec(a, b, o = {}) {
    const p = this.P(a), q = this.P(b);
    const L = Math.hypot(q[0] - p[0], q[1] - p[1]); if (L < 1) return this;
    const ux = (q[0] - p[0]) / L, uy = (q[1] - p[1]) / L, hl = Math.min(13, L * 0.4), hw = hl * 0.45, e = [q[0] - ux * hl, q[1] - uy * hl], c = col(o.color);
    this.items.push({ z: (p[2] + q[2]) / 2 + 0.01 + (o.bias || 0), s: `<line x1="${this.n(p[0])}" y1="${this.n(p[1])}" x2="${this.n(e[0])}" y2="${this.n(e[1])}" stroke="${c}" stroke-width="${o.w || 3}" stroke-linecap="round"/><polygon points="${this.n(q[0])},${this.n(q[1])} ${this.n(e[0] - uy * hw)},${this.n(e[1] + ux * hw)} ${this.n(e[0] + uy * hw)},${this.n(e[1] - ux * hw)}" fill="${c}"/>` });
    if (o.label) this.text(lerp(a, b, 0.6), o.label, { color: o.color, dx: -uy * 14, dy: ux * 14 + 4, bold: true, italic: true });
    return this;
  }
  point(v, label, o = {}) {
    const p = this.P(v);
    this.items.push({ z: p[2] + 0.05 + (o.bias || 0), s: `<circle cx="${this.n(p[0])}" cy="${this.n(p[1])}" r="${o.r || 5}" fill="${o.hollow ? COLORS.paper : col(o.color)}" stroke="${o.hollow ? col(o.color) : COLORS.paper}" stroke-width="1.8"/>` });
    if (label) this.text(v, label, { dx: o.dx ?? 11, dy: o.dy ?? -9, anchor: "start", bold: true, color: o.lcolor });
    return this;
  }
  text(v, s, o = {}) {
    if (this.thumb) return this;
    const p = this.P(v);
    this.over.push(`<text x="${this.n(clamp(p[0] + (o.dx || 0), 6, this.W - 6))}" y="${this.n(clamp(p[1] + (o.dy || 0), 14, this.H - 6))}" fill="${col(o.color)}" text-anchor="${o.anchor || "middle"}" class="pl-text${o.bold ? " b" : ""}${o.italic ? " i" : ""}"${o.size ? ` font-size="${o.size}"` : ""}>${esc(s)}</text>`);
    return this;
  }
  note(x, y, s, o = {}) { if (this.thumb) return this; this.over.push(`<text x="${x}" y="${y}" fill="${col(o.color)}" text-anchor="${o.anchor || "start"}" class="pl-text${o.bold ? " b" : ""}${o.mono ? " m" : ""}">${esc(s)}</text>`); return this; }
  right(v, p1, p2, o = {}) {
    const k = o.size || 0.28, u = mul(norm(sub(p1, v)), k), w = mul(norm(sub(p2, v)), k);
    return this.path([add(v, u), add(add(v, u), w), add(v, w)], { color: o.color || "muted", w: 1.6, bias: 0.02 });
  }
  // 두 벡터 u, v로 펼친 평면 조각 (중심 c, 반폭 hu, hv)
  plane(c, u, v, hu, hv, o = {}) {
    const p = (a, b) => add(c, add(mul(u, a), mul(v, b)));
    this.face([p(-hu, -hv), p(hu, -hv), p(hu, hv), p(-hu, hv)], { fo: 0.14, w: 1.2, bias: -1.5, ...o });
    if (o.grid) for (let i = -hu; i <= hu + 1e-9; i += o.grid) this.seg(p(i, -hv), p(i, hv), { color: o.color || "b", w: 0.8, opacity: 0.35, bias: -1.4 });
    if (o.grid) for (let j = -hv; j <= hv + 1e-9; j += o.grid) this.seg(p(-hu, j), p(hu, j), { color: o.color || "b", w: 0.8, opacity: 0.35, bias: -1.4 });
    return this;
  }
  axes(n = 4, o = {}) {
    const names = o.names || ["x", "y", "z"];
    [[n, 0, 0], [0, n, 0], [0, 0, n]].forEach((e, i) => {
      this.seg(mul(e, o.neg === false ? 0 : -0.35), e, { color: "axis", w: 1.5, bias: -0.02 });
      const tip = this.P(e), base = this.P(mul(e, 0.9));
      const ux = tip[0] - base[0], uy = tip[1] - base[1], L = Math.hypot(ux, uy) || 1;
      this.items.push({ z: tip[2], s: `<polygon points="${this.n(tip[0] + (ux / L) * 6)},${this.n(tip[1] + (uy / L) * 6)} ${this.n(tip[0] - (uy / L) * 4)},${this.n(tip[1] + (ux / L) * 4)} ${this.n(tip[0] + (uy / L) * 4)},${this.n(tip[1] - (ux / L) * 4)}" fill="${COLORS.axis}"/>` });
      this.text(mul(e, 1.1), names[i], { color: "muted", italic: true, bold: true });
    });
    if (o.ticks) for (let i = 1; i < n; i++) [[i, 0, 0], [0, i, 0], [0, 0, i]].forEach((e) => this.point(e, "", { r: 1.8, color: "muted" }));
    return this;
  }
  floor(n = 4, o = {}) {
    for (let i = -n; i <= n; i++) {
      this.seg([i, -n, 0], [i, n, 0], { color: "grid", w: 1, bias: -50 });
      this.seg([-n, i, 0], [n, i, 0], { color: "grid", w: 1, bias: -50 });
    }
    return this;
  }
  // 원(중심 c, 서로 수직인 단위벡터 u, v, 반지름 r)
  circle(c, u, v, r, o = {}) {
    const pts = []; const n = o.n || 72, a0 = o.from ?? 0, a1 = o.to ?? TAU;
    for (let i = 0; i <= n; i++) { const t = a0 + ((a1 - a0) * i) / n; pts.push(add(c, add(mul(u, r * Math.cos(t)), mul(v, r * Math.sin(t))))); }
    if (o.fill) this.face(pts, { ...o, stroke: false });
    return this.path(pts, o);
  }
  sphere(c, r, o = {}) {
    const E = [1, 0, 0], F = [0, 1, 0], Z = [0, 0, 1];
    for (let k = -2; k <= 2; k++) { const h = (r * k) / 3, rr = Math.sqrt(r * r - h * h); this.circle(add(c, mul(Z, h)), E, F, rr, { color: o.color || "b", w: 1, opacity: 0.55, n: 60 }); }
    for (let k = 0; k < 6; k++) { const a = (k * Math.PI) / 6, u = [Math.cos(a), Math.sin(a), 0]; this.circle(c, u, Z, r, { color: o.color || "b", w: 1, opacity: 0.55, n: 60 }); }
    // 윤곽선: 시선에 수직인 대원
    this.circle(c, this.r, this.u, r, { color: o.color || "b", w: 2, bias: 5 });
    if (o.fill !== false) { const p = this.P(c); this.items.push({ z: -100, s: `<circle cx="${this.n(p[0])}" cy="${this.n(p[1])}" r="${this.n(r * this.scale * (this.D / (this.D - dot(sub(c, this.center), this.d))))}" fill="${col(o.color || "b")}" fill-opacity="0.08"/>` }); }
    return this;
  }
  svg(label = "공간 시각화") {
    const body = this.items.sort((a, b) => a.z - b.z).map((i) => i.s).join("");
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${this.W} ${this.H}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="${esc(label)}" class="hs-svg hs-3d"><rect width="${this.W}" height="${this.H}" fill="${COLORS.paper}"/>${body}${this.over.join("")}${this.thumb ? "" : `<text x="${this.W - 12}" y="${this.H - 12}" text-anchor="end" class="pl-hint">끌어서 회전</text>`}</svg>`;
  }
}

// ── 조작판 HTML ────────────────────────────────────────
const pmax = (p, s) => (typeof p.max === "function" ? p.max(s) : p.max);
function ctrlHTML(p, v, s) {
  const id = `hs-${p.key}`;
  if (p.type === "select")
    return `<label class="lab-control" for="${id}"><span>${p.label}</span><select id="${id}" data-key="${p.key}">${p.options.map(([a, b]) => `<option value="${a}"${String(a) === String(v) ? " selected" : ""}>${b}</option>`).join("")}</select></label>`;
  if (p.type === "seg")
    return `<div class="lab-control"><span>${p.label}</span><div class="hs-seg" role="group" aria-label="${esc(p.label)}">${p.options.map(([a, b]) => `<button type="button" data-seg="${p.key}" data-val="${a}" aria-pressed="${String(a) === String(v)}">${b}</button>`).join("")}</div></div>`;
  if (p.type === "check")
    return `<label class="lab-check" for="${id}"><input id="${id}" data-key="${p.key}" type="checkbox"${v ? " checked" : ""}>${p.label}</label>`;
  if (p.type === "head") return `<h3>${p.label}</h3>`;
  const show = p.show ? p.show(v) : fmt(v, (p.step ?? 0.1) >= 1 ? 0 : p.digits ?? 2) + (p.unit || "");
  return `<label class="lab-control" for="${id}"><span>${p.label}<output data-output="${p.key}">${show}</output></span><input id="${id}" data-key="${p.key}" type="range" min="${p.min}" max="${pmax(p, s)}" step="${p.step ?? 0.1}" value="${v}"></label>`;
}

// ── 마운트 ───────────────────────────────────────────
export const is3D = (spec, s) => (typeof spec.space === "function" ? !!spec.space(s) : !!spec.space);
// 휴대폰처럼 좁은 화면에서는 그림 전체를 줄여 보여 주므로, 줄어든 만큼 그림 속 글자를 키운다(atelier.css의 --pl-k).
// 그다음 그림 밖으로 나간 글자를 안쪽으로 밀어 넣는다.
// 글꼴 파일이 늦게 도착하면 글자 폭이 바뀌므로 다시 맞춘다
const STAGES = new Set();
if (typeof document !== "undefined" && document.fonts) document.fonts.addEventListener("loadingdone", () => { for (const st of STAGES) { if (st.isConnected) fitText(st); else STAGES.delete(st); } });
export function fitText(stage) {
  const svg = stage && stage.querySelector("svg.hs-svg"), r = svg && svg.getBoundingClientRect();
  if (!r || !r.width || !r.height) return;
  const vb = svg.viewBox.baseVal, k = Math.max(vb.width / r.width, vb.height / r.height);
  stage.style.setProperty("--pl-k", k > 1 ? k.toFixed(3) : "1");
  const all = [...svg.querySelectorAll("text.pl-text, text.axis-name, text.tick")];
  for (const t of all) { // 다시 맞출 때는 처음 자리·크기에서 시작한다
    t.style.visibility = ""; t.style.fontSize = "";
    if (t.dataset.fx == null) { t.dataset.fx = t.getAttribute("x") || ""; t.dataset.fy = t.getAttribute("y") || ""; }
    else { if (t.dataset.fx) t.setAttribute("x", t.dataset.fx); if (t.dataset.fy) t.setAttribute("y", t.dataset.fy); }
  }
  if (k <= 1.02) return; // 넉넉한 화면에서는 그대로 둔다
  const bb = (t) => { try { return t.getBBox(); } catch { return null; } };
  const fsOf = (t) => parseFloat(getComputedStyle(t).fontSize) || 15;
  // 원래(넓은 화면) 글자 크기 — 이보다 작게 줄이지는 않는다
  const baseOf = (t) => (t.classList.contains("tick") ? 11.5 : t.classList.contains("axis-name") ? 20 : t.classList.contains("i") ? 19 : t.classList.contains("m") ? 14 : 15);
  const setFs = (t, v) => { t.style.fontSize = v.toFixed(2) + "px"; };
  // 1) 축 눈금 숫자가 서로 부딪히면 하나씩 건너뛰어 보여 준다
  const ticks = all.filter((t) => t.classList.contains("tick")).map((t) => ({ t, b: bb(t) })).filter((o) => o.b && o.b.width);
  const group = (arr, f) => { const m = new Map(); for (const o of arr) { const key = Math.round(f(o.b)); if (!m.has(key)) m.set(key, []); m.get(key).push(o); } return [...m.values()]; };
  const rows = group(ticks, (b) => b.y).filter((g) => g.length >= 3), inRow = new Set(rows.flat());
  const cols = group(ticks.filter((o) => !inRow.has(o)), (b) => b.x + b.width).filter((g) => g.length >= 3);
  const thin = (arr, h) => { arr.sort((a, b) => (h ? a.b.x - b.b.x : a.b.y - b.b.y)); let last = null; for (const o of arr) { if (last && (h ? o.b.x < last.b.x + last.b.width + 4 : o.b.y < last.b.y + last.b.height - 2)) o.t.style.visibility = "hidden"; else last = o; } };
  rows.forEach((g) => thin(g, true)); cols.forEach((g) => thin(g, false));
  // 2) 같은 높이에 늘어선 글자(막대 이름, 수직선 숫자, 값)가 서로 부딪히면 그 줄을 함께 줄인다
  const items = all.filter((t) => t.classList.contains("pl-text")).map((t) => ({ t, b: bb(t), fs: fsOf(t) })).filter((o) => o.b && o.b.width).sort((a, b) => a.b.y + a.b.height / 2 - (b.b.y + b.b.height / 2));
  const lines = []; for (const o of items) { const cy = o.b.y + o.b.height / 2, L = lines[lines.length - 1]; if (L && Math.abs(cy - L.cy) < o.fs * 0.5) L.a.push(o); else lines.push({ cy, a: [o] }); }
  for (const { a } of lines) {
    if (a.length < 3) continue;
    a.sort((p, q) => p.b.x - q.b.x);
    let f = 1;
    for (let i = 1; i < a.length; i++) { const p = a[i - 1], q = a[i], have = q.b.x + q.b.width / 2 - (p.b.x + p.b.width / 2), need = (p.b.width + q.b.width) / 2 + 3; if (have > 0 && have < need) f = Math.min(f, have / need); }
    if (f >= 1) continue;
    // 고르게 늘어선 숫자(수직선 눈금)는 하나씩 건너뛰고, 그 밖의 이름표·값은 줄을 함께 줄인다
    const NUM = /^[−\-+]?\d+([.,]\d+)?[°%]?$/, cx = a.map((o) => o.b.x + o.b.width / 2), gaps = cx.slice(1).map((v, i) => v - cx[i]);
    if (a.every((o) => NUM.test(o.t.textContent.trim())) && Math.max(...gaps) <= Math.min(...gaps) * 1.3 + 1) {
      let last = null; for (const o of a) { if (last && o.b.x < last.b.x + last.b.width + 4) o.t.style.visibility = "hidden"; else last = o; }
    } else for (const o of a) setFs(o.t, Math.max(baseOf(o.t), o.fs * f));
  }
  // 3) 그림 밖으로 나간 글자: 먼저 원래 크기까지 줄여 보고, 그래도 나가면 안쪽으로 민다
  const x0 = vb.x + 3, x1 = vb.x + vb.width - 3, y0 = vb.y + 3, y1 = vb.y + vb.height - 3;
  for (const t of all) {
    if (t.style.visibility === "hidden") continue;
    let b = bb(t); if (!b || !b.width) continue;
    const fs = fsOf(t), anchor = t.getAttribute("text-anchor") || getComputedStyle(t).textAnchor || "start";
    const right = b.x + b.width - x1, left = x0 - b.x;
    if (b.width > x1 - x0) { setFs(t, (fs * (x1 - x0)) / b.width); b = bb(t); }
    else if (right > 0 || left > 0) {
      const share = right > 0 ? (anchor === "start" ? 1 : anchor === "middle" ? 0.5 : 0) : (anchor === "end" ? 1 : anchor === "middle" ? 0.5 : 0);
      if (share > 0) { const minW = (b.width * Math.min(fs, baseOf(t))) / fs, w2 = Math.max(minW, b.width - Math.max(right, left) / share); if (w2 < b.width) { setFs(t, (fs * w2) / b.width); b = bb(t); } }
    }
    if (!b) continue;
    const dx = b.x < x0 ? x0 - b.x : b.x + b.width > x1 ? x1 - b.x - b.width : 0, dy = b.y < y0 ? y0 - b.y : b.y + b.height > y1 ? y1 - b.y - b.height : 0;
    if (dx) t.setAttribute("x", +t.getAttribute("x") + dx);
    if (dy) t.setAttribute("y", +t.getAttribute("y") + dy);
  }
}
export function render(spec, s, thumb = false) {
  reconcileParams(spec, s);
  let g;
  if (is3D(spec, s)) {
    const cam = typeof spec.cam === "function" ? spec.cam(s) : spec.cam || {};
    g = new Space({ ...cam, yaw: s._yaw ?? cam.yaw, pitch: s._pitch ?? cam.pitch });
  } else g = new Plot(typeof spec.view === "function" ? spec.view(s) : spec.view);
  g.thumb = thumb;
  spec.draw(s, g);
  if (!thumb && spec.drags && !is3D(spec, s)) for (const [k, d] of Object.entries(spec.drags)) { if (d.when && !d.when(s)) continue; const q = d.at(s); if (q && Number.isFinite(q[0]) && Number.isFinite(q[1])) g.handle(q, k, { color: d.color || "a", label: d.label }); }
  return g;
}
export function defaults(spec) {
  const s = {};
  (spec.params || []).forEach((p) => { if (p.key) s[p.key] = p.value; });
  Object.entries(spec.points || {}).forEach(([k, v]) => (s[k] = [...v]));
  if (spec.space) { s._yaw = spec.cam?.yaw ?? 35; s._pitch = spec.cam?.pitch ?? 22; }
  if (spec.init) Object.assign(s, spec.init(s));
  if (spec.prefill) spec.prefill(s);
  reconcileParams(spec, s);
  return s;
}
export function thumbSVG(spec) {
  try { const s = defaults(spec); if (spec.thumbState) Object.assign(s, spec.thumbState); const g = render(spec, s, true); return g.svg(spec.title || ""); } catch (e) { console.error(e); return ""; }
}

export function mount(spec, ctx) {
  const s = normalizePreset(spec, ctx.preset, defaults(spec));
  let playing = false, raf = 0, last = 0, dir = 1, dragKey = null, rot = null, focusKey = null, animV = null;
  const P = spec.params || [];
  const anim = spec.anim;

  const btns = () => { const b = typeof spec.buttons === "function" ? spec.buttons(s) : spec.buttons; return b && b.length ? b : null; };
  function controls() {
    const visible = P.filter((p) => !p.when || p.when(s));
    ctx.controls.innerHTML = `<h2>${spec.panel || "조작하기"}</h2>` + visible.map((p) => ctrlHTML(p, s[p.key], s)).join("") +
      (anim && (!anim.when || anim.when(s)) ? `<div class="hs-actions"><button type="button" class="btn primary" data-do="play">${playing ? "❚❚ 멈추기" : "▶ " + (anim.label || "자동 재생")}</button></div>` : "") +
      (btns() ? `<div class="hs-actions">${btns().map(([k, l]) => `<button type="button" class="btn" data-do="${k}">${l}</button>`).join("")}</div>` : "") +
      (Object.keys(spec.points || {}).length || spec.drags ? `<p class="hs-tip">주황 고리가 있는 점은 끌어서 옮길 수 있어요. 점을 누른 뒤 방향키로도 움직입니다.</p>` : "") +
      (is3D(spec, s) ? `<p class="hs-tip">그림을 끌면 공간을 돌려 볼 수 있어요.</p>` : "") +
      (spec.tip ? `<p class="hs-tip">${spec.tip}</p>` : "") + predHTML();
  }
  // ── 예측하고 확인하기 ──
  const pred = { i: 0, ans: {}, res: {} };
  const PR = spec.predict || [];
  const val = (x) => (typeof x === "function" ? x(s) : x);
  const parseNum = parseAnswer;
  function predHTML() {
    if (!PR.length) return "";
    const it = PR[pred.i], r = pred.res[pred.i], a = pred.ans[pred.i] ?? "";
    const input = it.options
      ? `<div class="hs-seg hs-pred-opts" role="group">${it.options.map(([v, l]) => `<button type="button" data-pred-opt="${esc(v)}" aria-pressed="${String(a) === String(v)}">${esc(l)}</button>`).join("")}</div>`
      : `<input class="hs-pred-in" data-pred-in type="text" inputmode="decimal" value="${esc(a)}" placeholder="${esc(it.ph || "내 예측")}" aria-label="내 예측">`;
    const res = r ? `<div class="hs-pred-res ${r.ok == null ? "" : r.ok ? "ok" : "no"}">${r.ok == null ? "" : `<strong>${r.ok ? "✓ 예측이 맞았어요" : "✗ 다시 생각해 볼까요?"}</strong>`}${r.showAnswer ? `<p>${mathHTML("답: " + r.ans)}</p>` : ""}${r.showWhy && r.why ? `<p>${mathHTML(r.why)}</p>` : ""}</div>` : "";
    return `<section class="hs-pred" aria-label="예측하고 확인하기"><h3>예측하고 확인하기 <small>${pred.i + 1} / ${PR.length}</small></h3>` +
      `<p class="hs-pred-q">${mathHTML(val(it.q))}</p>` + (it.set ? `<button type="button" class="btn ghost" data-pred="go">이 장면 펼치기</button>` : "") +
      `<div class="hs-pred-row">${input}<button type="button" class="btn primary" data-pred="check">확인</button></div>${res}` +
      `<div class="hs-actions"><button type="button" class="btn" data-pred="answer">${r?.showAnswer ? "정답 숨기기" : "정답 보기"}</button><button type="button" class="btn" data-pred="why">${r?.showWhy ? "풀이 숨기기" : "풀이 보기"}</button></div><div class="hs-pred-nav"><button type="button" class="btn" data-pred="prev"${pred.i ? "" : " disabled"}>◀ 이전</button><button type="button" class="btn" data-pred="next"${pred.i < PR.length - 1 ? "" : " disabled"}>다음 ▶</button></div></section>`;
  }
  function predDo(act) {
    const it = PR[pred.i];
    if (act === "prev" || act === "next") { pred.i = clamp(pred.i + (act === "next" ? 1 : -1), 0, PR.length - 1); const n = PR[pred.i]; if (n.set && !pred.res[pred.i]) n.set(s); }
    else if (act === "go") { if (it.set) it.set(s); }
    else if (act === "check" || act === "answer" || act === "why") {
      if (it.set && !pred.res[pred.i]) it.set(s);
      const ans = it.answer(s), mine = pred.ans[pred.i] ?? "";
      let ok;
      if (it.check) ok = it.check(mine, s);
      else if (typeof ans === "number") { const v = parseNum(mine), tol = it.tol ?? 1e-6; ok = Number.isFinite(v) && Math.abs(v - ans) <= tol * (it.rel ? Math.abs(ans) : 1) + 1e-9; }
      else ok = String(mine).replace(/\s/g, "") === String(ans).replace(/\s/g, "");
      if (it.reveal) it.reveal(s);
      const before = pred.res[pred.i];
      pred.res[pred.i] = { ok: act === "check" ? ok : before?.ok ?? null, showAnswer: act === "answer" ? !before?.showAnswer : act === "check" || !!before?.showAnswer, showWhy: act === "why" ? !before?.showWhy : !!before?.showWhy, ans: it.show ? it.show(s) : typeof ans === "number" ? fmt(ans, 4) : (it.options?.find(([v]) => String(v) === String(ans))?.[1] ?? ans), why: val(it.why) };
    }
    fitParams(); if (spec.onChange) spec.onChange(s, "_pred"); if (spec.derive) spec.derive(s); if (pred.res[pred.i]) pred.res[pred.i].fingerprint = feedbackFingerprint(s); controls(); draw();
  }
  function syncOutputs() {
    for (const p of P) {
      const o = ctx.controls.querySelector(`[data-output="${p.key}"]`);
      if (o) setMath(o, p.show ? p.show(s[p.key]) : fmt(s[p.key], (p.step ?? 0.1) >= 1 ? 0 : p.digits ?? 2) + (p.unit || ""));
      const inp = ctx.controls.querySelector(`input[type=range][data-key="${p.key}"]`);
      if (inp && typeof p.max === "function") inp.max = pmax(p, s);
      if (inp && document.activeElement !== inp) inp.value = s[p.key];
    }
  }
  if (typeof document !== "undefined" && document.fonts) { STAGES.add(ctx.stage); document.fonts.ready.then(() => fitText(ctx.stage)); }
  if (typeof ResizeObserver !== "undefined") { let w0 = 0; new ResizeObserver(() => { const w = ctx.stage.clientWidth; if (Math.abs(w - w0) > 4) { w0 = w; fitText(ctx.stage); } }).observe(ctx.stage); }
  function draw() {
    reconcileParams(spec, s);
    if (spec.derive) spec.derive(s);
    const previous = pred.res[pred.i];
    if (previous && previous.fingerprint !== feedbackFingerprint(s)) { delete pred.res[pred.i]; ctx.controls.querySelectorAll(".hs-pred-res").forEach(el => el.remove()); }
    const question = ctx.controls.querySelector(".hs-pred-q"); if (question && PR[pred.i]) { const html = mathHTML(val(PR[pred.i].q)); if (question.innerHTML !== html) question.innerHTML = html; }
    const g = render(spec, s);
    ctx.stage.classList.toggle("hs-stage-3d", is3D(spec, s));
    ctx.stage.innerHTML = g.svg(spec.title);
    fitText(ctx.stage);
    const m = spec.metrics ? spec.metrics(s) : [];
    ctx.metrics.innerHTML = m.map((x) => (typeof x === "string" ? `<p class="hs-note">${mathHTML(x)}</p>` : `<div class="${x[2] ? "tone-" + x[2] : ""}"><small>${mathHTML(x[0])}</small><strong>${mathHTML(x[1])}</strong></div>`)).join("");
    if (ctx.caption) { const c = spec.caption ? spec.caption(s) : ""; ctx.caption.hidden = !c; ctx.caption.innerHTML = c ? mathHTML(c) : ""; }
    if (focusKey) { const h = ctx.stage.querySelector(`[data-drag="${focusKey}"]`); if (h && document.activeElement !== h) h.focus({ preventScroll: true }); }
    syncOutputs();
  }
  function setParam(key, val) {
    const p = P.find((q) => q.key === key);
    const before = P.filter((q) => q.when).map((q) => q.when(s)).join();
    s[key] = val;
    if (spec.onChange) spec.onChange(s, key);
    const after = P.filter((q) => q.when).map((q) => q.when(s)).join();
    if (before !== after || p?.type === "seg" || p?.rebuild) controls();
    draw();
  }
  function tick(t) {
    if (!playing) return;
    const dt = last ? Math.min(0.06, (t - last) / 1000) : 0.016; last = t;
    if (anim.step) anim.step(s, dt, spec);
    else {
      const p = P.find((q) => q.key === anim.key), lo = Math.max(anim.min ?? p.min, p.min), hi = Math.min(anim.max ?? pmax(p, s), pmax(p, s));
      if (animV == null) animV = s[anim.key];
      let v = animV + dir * (anim.speed || (hi - lo) / 5) * dt;
      if (anim.loop === "wrap") { if (v > hi) v = lo; }
      else if (v > hi || v < lo) { dir *= -1; v = clamp(v, lo, hi); }
      animV = v;
      const st = p.step ?? 0.1, isInt = st >= 1 && Number.isInteger(st);
      const nv = isInt ? clamp(Math.round(v / st) * st, lo, hi) : v;
      if (isInt && nv === s[anim.key]) { raf = requestAnimationFrame(tick); return; }
      s[anim.key] = nv;
      if (spec.onChange) spec.onChange(s, anim.key);
    }
    draw();
    raf = requestAnimationFrame(tick);
  }
  function snap(v) { const k = spec.snap; return k ? v.map((x) => Math.round(x / k) * k) : v; }
  function fitParams() { for (const p of P) if (p.min != null && typeof s[p.key] === "number") { let v = clamp(s[p.key], p.min, pmax(p, s)); const st = p.step ?? 0.1; if (st >= 1 && Number.isInteger(st)) v = Math.round(v / st) * st; s[p.key] = v; } }
  function place(key, w) {
    if (spec.drags && spec.drags[key]) { spec.drags[key].move(s, w); fitParams(); if (spec.onChange) spec.onChange(s, key); draw(); return; }
    let p = snap(w);
    if (spec.constrain) p = spec.constrain(s, key, p) || p;
    const b = spec.bounds || (spec.view && typeof spec.view !== "function" ? spec.view : null);
    if (b && !spec.constrain) p = [clamp(p[0], b.x[0], b.x[1]), clamp(p[1], b.y[0], b.y[1])];
    s[key] = p;
    if (spec.onChange) spec.onChange(s, key);
    draw();
  }
  function svgPoint(e) {
    const svg = ctx.stage.querySelector("svg"); if (!svg) return null;
    const pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY;
    const q = pt.matrixTransform(svg.getScreenCTM().inverse());
    return [q.x, q.y];
  }
  const plot = () => (is3D(spec, s) ? null : new Plot(typeof spec.view === "function" ? spec.view(s) : spec.view));
  function down(e) {
    const h = e.target.closest?.("[data-drag]");
    if (h) { dragKey = h.dataset.drag; focusKey = dragKey; ctx.stage.setPointerCapture?.(e.pointerId); e.preventDefault(); return; }
    if (is3D(spec, s)) { rot = { x: e.clientX, y: e.clientY, yaw: s._yaw, pitch: s._pitch }; ctx.stage.setPointerCapture?.(e.pointerId); ctx.stage.classList.add("rotating"); e.preventDefault(); return; }
    // 칸 누르기(spec.tap): 그림 위를 누른 좌표를 실험에 넘긴다 (라이츠 아웃 등)
    if (spec.tap) { const q = svgPoint(e); if (q && spec.tap(s, plot().inv(q)) !== false) { fitParams(); if (spec.onChange) spec.onChange(s, "_tap"); draw(); e.preventDefault(); } }
  }
  function move(e) {
    if (dragKey) { const q = svgPoint(e); if (q) place(dragKey, plot().inv(q)); }
    else if (rot) { s._yaw = rot.yaw - (e.clientX - rot.x) * 0.45; s._pitch = clamp(rot.pitch + (e.clientY - rot.y) * 0.35, -85, 85); draw(); }
  }
  function up() { dragKey = null; rot = null; ctx.stage.classList.remove("rotating"); }
  function key(e) {
    const h = e.target.closest?.("[data-drag]"); if (!h) return;
    const d = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, 1], ArrowDown: [0, -1] }[e.key]; if (!d) return;
    e.preventDefault(); focusKey = h.dataset.drag;
    const st = spec.snap || 0.1; const c = spec.drags && spec.drags[focusKey] ? spec.drags[focusKey].at(s) : s[focusKey];
    place(focusKey, [c[0] + d[0] * st, c[1] + d[1] * st]);
  }
  function onInput(e) {
    if (e.target.matches?.("[data-pred-in]")) { pred.ans[pred.i] = e.target.value; return; }
    const el = e.target.closest("[data-key]"); if (!el) return;
    const k = el.dataset.key;
    const v = el.type === "checkbox" ? el.checked : el.tagName === "SELECT" ? (isNaN(+el.value) || el.value === "" ? el.value : +el.value) : +el.value;
    setParam(k, v);
  }
  function onClick(e) {
    const po = e.target.closest("[data-pred-opt]");
    if (po) { pred.ans[pred.i] = po.dataset.predOpt; controls(); return; }
    const pd = e.target.closest("[data-pred]");
    if (pd) { predDo(pd.dataset.pred); return; }
    const sg = e.target.closest("[data-seg]");
    if (sg) { const raw = sg.dataset.val; setParam(sg.dataset.seg, isNaN(+raw) ? raw : +raw); return; }
    const b = e.target.closest("[data-do]"); if (!b) return;
    if (b.dataset.do === "play") { playing = !playing; last = 0; animV = null; cancelAnimationFrame(raf); if (playing) { if (anim.start) anim.start(s); raf = requestAnimationFrame(tick); } controls(); return; }
    if (spec.onDo) { spec.onDo(b.dataset.do, s); controls(); draw(); }
  }
  ctx.stage.classList.add("hs-stage");
  ctx.stage.addEventListener("pointerdown", down);
  ctx.stage.addEventListener("pointermove", move);
  ctx.stage.addEventListener("pointerup", up);
  ctx.stage.addEventListener("pointercancel", up);
  ctx.stage.addEventListener("keydown", key);
  ctx.stage.addEventListener("focusout", () => { if (!dragKey) focusKey = null; });
  ctx.controls.addEventListener("input", onInput);
  ctx.controls.addEventListener("change", onInput);
  ctx.controls.addEventListener("click", onClick);
  const onKey = (e) => { if (e.key === "Enter" && e.target.matches?.("[data-pred-in]")) { pred.ans[pred.i] = e.target.value; predDo("check"); } };
  ctx.controls.addEventListener("keydown", onKey);
  if (ctx.hint && spec.hint) ctx.hint.textContent = spec.hint;
  controls(); draw();
  if (anim?.autoplay && !window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) { playing = true; if (anim.start) anim.start(s); raf = requestAnimationFrame(tick); controls(); }
  return {
    state: s,
    pred,
    theme() { draw(); },
    destroy() {
      playing = false; cancelAnimationFrame(raf);
      ctx.stage.removeEventListener("pointerdown", down); ctx.stage.removeEventListener("pointermove", move);
      ctx.stage.removeEventListener("pointerup", up); ctx.stage.removeEventListener("pointercancel", up); ctx.stage.removeEventListener("keydown", key);
      ctx.controls.removeEventListener("input", onInput); ctx.controls.removeEventListener("change", onInput); ctx.controls.removeEventListener("click", onClick); ctx.controls.removeEventListener("keydown", onKey);
      ctx.stage.classList.remove("hs-stage", "hs-stage-3d");
    },
  };
}
