// 23차 묶음 12 — 대수 추가 실험 12개
import { fmt, frac, clamp, piFmt } from "./hs-core.js";

const AL = 5;
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
const SUB = "₀₁₂₃₄₅₆₇₈₉", subN = (n) => [...String(n)].map((d) => SUB[d]).join("");
const QUAKE = [[3, "실내에서 조금 느낌"], [5, "물건이 떨어짐"], [6, "건물 일부 손상"], [7, "큰 피해"], [8, "매우 큰 피해"]];
const regions = (n) => 1 + (n * (n - 1)) / 2 + (n * (n - 1) * (n - 2) * (n - 3)) / 24;

export default [
  {
    id: "alg-log-base", grade: AL, unit: 1, lesson: "Ⅰ-2", title: "로그의 밑 변환 — log₂x와 log₁₀x는 일정한 비율", type: "조작", time: "10분",
    tags: ["밑의 변환", "로그", "그래프"], links: ["alg-slide-rule", "alg-digits"],
    desc: "y = log₂x와 y = log₁₀x의 그래프를 함께 그리면, 같은 x에서 두 값의 비가 늘 log₂10 ≈ 3.32로 일정합니다. 밑을 바꾸는 것은 그래프를 세로로 일정하게 늘이거나 줄이는 것이라는 밑 변환 공식 logₐx = log x / log a를 확인합니다.",
    obs: ["logₐx = log_b x / log_b a입니다.", "그래서 밑이 다른 로그의 그래프는 세로 방향으로 몇 배 한 관계입니다.", "모든 로그함수의 그래프는 점 (1, 0)을 지납니다."],
    q: "log₂3 × log₃4의 값을 밑 변환 공식으로 구해 봅시다.",
    formula: "logₐx = (log x)/(log a)",
    en: { title: "Change of Base", desc: "Different bases differ by a constant factor." },
    view: { x: [-0.5, 10.5], y: [-3, 4] },
    params: [{ key: "a", label: "밑 a", min: 1.5, max: 10, step: 0.5, value: 2 }, { key: "x", label: "x", min: 0.2, max: 10, step: 0.1, value: 8 }],
    draw(s, g) {
      g.grid();
      g.fx((x) => Math.log10(x), { color: "b", w: 2.6, from: 0.05 });
      g.fx((x) => Math.log(x) / Math.log(s.a), { color: "a", w: 3, from: 0.05 });
      const ya = Math.log(s.x) / Math.log(s.a), yb = Math.log10(s.x);
      g.seg([s.x, 0], [s.x, ya], { color: "muted", w: 1.2, dash: "3 4" }).point([s.x, ya], `밑 ${fmt(s.a)}: ${fmt(ya, 3)}`, { color: "a" }).point([s.x, yb], `밑 10: ${fmt(yb, 3)}`, { color: "b", dy: 18 });
      g.point([1, 0], "(1, 0)", { color: "ink", r: 4, dy: 18 });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.4], `주황: y = log_${fmt(s.a)} x   파랑: y = log₁₀ x`, { anchor: "start", bold: true });
    },
    metrics(s) { const ya = Math.log(s.x) / Math.log(s.a), yb = Math.log10(s.x); return [["두 값의 비", s.x === 1 ? "—" : fmt(ya / yb, 4)], ["1 / log a", fmt(1 / Math.log10(s.a), 4), "key"]]; },
    predict: [
      { q: "log₂8 ÷ log₁₀8의 값은 대략? (소수 둘째 자리까지)", set: (s) => Object.assign(s, { a: 2, x: 2 }), reveal: (s) => (s.x = 8), answer: () => 1 / Math.log10(2), tol: 0.01, why: "log₂8 = log 8/log 2이므로 비는 1/log 2 ≈ 3.32입니다." },
      { q: "log₂3 × log₃4의 값은?", answer: () => 2, why: "(log 3/log 2) × (log 4/log 3) = log 4/log 2 = 2입니다." },
    ],
  },
  {
    id: "alg-log-scale", grade: AL, unit: 1, lesson: "Ⅰ-3", title: "지진의 규모와 로그 눈금 — 1이 오르면 에너지는 약 32배", type: "조작", time: "10분",
    tags: ["상용로그", "로그 눈금", "실생활"], links: ["alg-digits"],
    desc: "지진의 규모가 1 오를 때 방출 에너지는 약 10^1.5 ≈ 31.6배가 됩니다. 규모 3부터 8까지의 에너지를 보통 눈금과 로그 눈금 막대로 비교하며, 아주 큰 차이를 다루기 위해 로그 눈금을 쓰는 까닭을 확인합니다.",
    obs: ["규모 M의 에너지 E는 log E = 1.5M + (상수)로 나타냅니다.", "규모 2 차이는 에너지 10³ = 1000배입니다.", "보통 눈금으로는 작은 지진이 보이지도 않지만 로그 눈금에서는 고르게 보입니다."],
    q: "소리의 크기(데시벨)도 10 dB 오를 때 세기가 10배입니다. 60 dB와 90 dB의 세기는 몇 배 차이일까요?",
    formula: "\\log E=1.5M+k\\quad\\Rightarrow\\quad\\frac{E_2}{E_1}=10^{1.5(M_2-M_1)}",
    en: { title: "Earthquake Magnitude and Log Scales", desc: "One step up means about 32 times the energy." },
    view: BOX,
    params: [{ key: "sc", label: "눈금", type: "seg", value: "log", options: [["lin", "보통 눈금"], ["log", "로그 눈금"]] }, { key: "m", label: "비교할 규모", min: 3, max: 8, step: 0.1, value: 6 }],
    draw(s, g) {
      const E = (M) => 10 ** (1.5 * (M - 3)), max = E(8), Y = (e) => (s.sc === "lin" ? (e / max) * 8.6 : (Math.log10(e) / Math.log10(max)) * 8.6);
      QUAKE.forEach(([M, t], i) => { const x = 1 + i * 2.9, h = Math.max(0.03, Y(E(M))); rect(g, x, 1.2, 2, h, { fill: "b", fo: 0.45, color: "b", w: 1.2 }); g.text([x + 1, 1.2], `규모 ${M}`, { dy: 18, bold: true, size: 13 }); g.text([x + 1, 1.2], t, { dy: 34, size: 10, color: "muted" }); g.text([x + 1, 1.2 + h], `×${fmt(E(M), 0)}`, { dy: -6, size: 11, color: "b", bold: true }); });
      const hm = Y(E(s.m)); g.seg([0.6, 1.2 + hm], [15.6, 1.2 + hm], { color: "a", w: 1.6, dash: "6 4" }).text([15.6, 1.2 + hm], `규모 ${fmt(s.m, 1)}`, { anchor: "end", dy: -6, bold: true, color: "a", size: 13 });
      g.text([1, 10.4], s.sc === "lin" ? "보통 눈금: 큰 지진만 보여요" : "로그 눈금: 한 칸 = 약 31.6배", { anchor: "start", bold: true, size: 14 });
    },
    metrics(s) { return [[`규모 ${fmt(s.m, 1)}의 에너지 (규모 3 대비)`, `${fmt(10 ** (1.5 * (s.m - 3)), 0)}배`, "key"], ["규모 1 차이", `10^1.5 ≈ ${fmt(10 ** 1.5, 1)}배`]]; },
    predict: [
      { q: "규모 7 지진은 규모 5 지진보다 에너지가 몇 배?", set: (s) => Object.assign(s, { sc: "lin", m: 5 }), reveal: (s) => Object.assign(s, { sc: "log", m: 7 }), answer: () => 1000, why: "10^(1.5 × 2) = 10³ = 1000배입니다." },
      { q: "90 dB 소리는 60 dB 소리보다 세기가 몇 배?", answer: () => 1000, why: "10 dB마다 10배이므로 30 dB 차이는 10³ = 1000배입니다." },
    ],
  },
  {
    id: "alg-half-life", grade: AL, unit: 2, lesson: "Ⅱ 탐구", title: "반감기 — 탄소로 재는 유물의 나이", type: "조작", time: "12분",
    tags: ["지수함수", "로그", "반감기"], links: ["alg-exp-graph", "alg-explog-eq"],
    desc: "탄소-14는 약 5730년마다 절반으로 줄어듭니다. 남은 비율 y = (1/2)^(t/5730)의 그래프에서 시간이 지나면 어떻게 줄어드는지 보고, 거꾸로 남은 비율을 재면 로그로 나이를 t = 5730 × log₂(1/y)처럼 구할 수 있음을 확인합니다.",
    obs: ["반감기마다 남은 양이 1/2, 1/4, 1/8, …로 줄어듭니다.", "y = (1/2)^(t/T)는 감소하는 지수함수입니다.", "남은 비율을 알면 로그로 지난 시간을 거꾸로 구합니다."],
    q: "남은 비율이 10%인 유물은 대략 몇 년 전 것일까요?",
    formula: "y=\\left(\\frac12\\right)^{t/T}\\quad\\Leftrightarrow\\quad t=T\\log_2\\left(\\frac1y\\right)",
    en: { title: "Half-Life and Carbon Dating", desc: "Exponentials forward, logarithms backward." },
    view: { x: [-1.4, 13], y: [-1.4, 11] },
    params: [{ key: "T", label: "반감기 T (년)", min: 1000, max: 10000, step: 10, value: 5730 }, { key: "y", label: "남은 비율 (%)", min: 1, max: 100, step: 1, value: 25 }],
    draw(s, g) {
      const tmax = 5 * s.T, X = (t) => (t / tmax) * 11.5, Y = (p) => (p / 100) * 9.6, t = s.T * Math.log2(100 / s.y);
      g.seg([0, 0], [11.8, 0], { color: "axis", w: 1.6 }).seg([0, 0], [0, 10], { color: "axis", w: 1.6 });
      for (let k = 1; k <= 5; k++) { g.seg([X(k * s.T), 0], [X(k * s.T), Y(100 / 2 ** k)], { color: "grid", w: 1, dash: "3 3" }); g.text([X(k * s.T), 0], `${k}T`, { dy: 16, size: 11, color: "muted" }); g.point([X(k * s.T), Y(100 / 2 ** k)], `${fmt(100 / 2 ** k, 2)}%`, { color: "b", r: 3.5, size: 11 }); }
      [25, 50, 75, 100].forEach((p) => g.text([0, Y(p)], `${p}%`, { dx: -6, anchor: "end", dy: 4, size: 11, color: "muted" }));
      g.param((u) => [X(u), Y(100 * 0.5 ** (u / s.T))], 0, tmax, { color: "b", w: 3 });
      g.seg([0, Y(s.y)], [X(Math.min(t, tmax)), Y(s.y)], { color: "a", w: 1.6, dash: "5 4" }).seg([X(Math.min(t, tmax)), Y(s.y)], [X(Math.min(t, tmax)), 0], { color: "a", w: 1.6, dash: "5 4" });
      if (t <= tmax) g.point([X(t), Y(s.y)], `${fmt(t, 0)}년`, { color: "a" });
    },
    metrics(s) { const t = s.T * Math.log2(100 / s.y); return [["남은 비율", `${s.y}%`], ["지난 시간 T × log₂(100/y)", `${fmt(t, 0)}년`, "key"], ["반감기 몇 번", fmt(t / s.T, 3)]]; },
    predict: [
      { q: "탄소-14가 25% 남은 유물은 몇 년 전 것일까요? (반감기 5730년)", set: (s) => Object.assign(s, { T: 5730, y: 50 }), reveal: (s) => (s.y = 25), answer: () => 11460, tol: 1, why: "25% = (1/2)²이므로 반감기 2번, 11460년입니다." },
      { q: "남은 비율이 10%이면 반감기를 대략 몇 번 지난 것일까요? (소수 첫째 자리까지)", set: (s) => Object.assign(s, { T: 5730, y: 50 }), reveal: (s) => (s.y = 10), answer: () => Math.log2(10), tol: 0.05, why: "log₂10 ≈ 3.3번, 약 19000년입니다." },
    ],
  },
  {
    id: "alg-pythag-trig", grade: AL, unit: 3, lesson: "Ⅲ-2", title: "sin²θ + cos²θ = 1 — 단위원 위의 두 정사각형", type: "조작", time: "8분",
    tags: ["삼각함수 사이의 관계", "단위원", "피타고라스"], links: ["alg-unit-circle"],
    desc: "단위원 위의 점 P(cos θ, sin θ)에서 가로 길이와 세로 길이로 정사각형을 그리면 두 넓이의 합이 늘 1(반지름의 제곱)입니다. θ를 돌려 사분면마다 부호가 바뀌어도 제곱의 합은 1임을 확인하고, tan θ = sin θ / cos θ도 함께 봅니다.",
    obs: ["P의 좌표가 (cos θ, sin θ)이고 OP = 1이므로 cos²θ + sin²θ = 1입니다.", "부호와 관계없이 제곱하면 양수라 넓이로 볼 수 있습니다.", "sin θ의 값을 알면 cos θ의 크기를 √(1 − sin²θ)로 구할 수 있습니다."],
    q: "sin θ = 3/5이고 θ가 제2사분면의 각일 때 cos θ의 값은?",
    formula: "sin²θ + cos²θ = 1, tan θ = sin θ / cos θ",
    en: { title: "sin²θ + cos²θ = 1", desc: "Two squares on the unit circle." },
    view: { x: [-2.4, 2.4], y: [-1.6, 1.6] },
    params: [{ key: "t", label: "θ", min: 0, max: 6.28, step: 0.01, value: 0.9 }],
    anim: { key: "t", min: 0, max: 6.28, speed: 0.6, label: "돌리기", loop: "wrap" },
    draw(s, g) {
      const c = Math.cos(s.t), si = Math.sin(s.t);
      g.grid({ step: 0.5, labels: false });
      g.circle([0, 0], 1, { color: "muted", w: 1.6 });
      g.poly([[0, 0], [c, 0], [c, -c * Math.sign(si || 1)], [0, -c * Math.sign(si || 1)]], { fill: "b", fo: 0.3, color: "b", w: 1.4 });
      g.poly([[c, 0], [c, si], [c + si * Math.sign(c || 1), si], [c + si * Math.sign(c || 1), 0]], { fill: "a", fo: 0.3, color: "a", w: 1.4 });
      g.seg([0, 0], [c, si], { color: "ink", w: 2.4 }).seg([0, 0], [c, 0], { color: "b", w: 3 }).seg([c, 0], [c, si], { color: "a", w: 3 });
      g.point([c, si], "P", { color: "ink" });
      g.text([-2.3, 1.4], `cos²θ = ${fmt(c * c, 3)}`, { anchor: "start", bold: true, color: "b" }).text([-2.3, 1.15], `sin²θ = ${fmt(si * si, 3)}`, { anchor: "start", bold: true, color: "a" }).text([-2.3, 0.9], `합 = ${fmt(c * c + si * si, 3)}`, { anchor: "start", bold: true });
    },
    metrics(s) { const c = Math.cos(s.t), si = Math.sin(s.t); return [["θ", piFmt(s.t)], ["cos θ, sin θ", `${fmt(c, 3)}, ${fmt(si, 3)}`], ["sin²θ + cos²θ", fmt(c * c + si * si, 6), "key"], ["tan θ", Math.abs(c) < 1e-3 ? "정의되지 않음" : fmt(si / c, 3)]]; },
    predict: [
      { q: "sin θ = 3/5, θ가 제2사분면의 각이면 cos θ는?", set: (s) => (s.t = 0.6435), reveal: (s) => (s.t = Math.PI - 0.6435), answer: () => -0.8, tol: 0.001, why: "cos²θ = 1 − 9/25 = 16/25이고 제2사분면에서 음수이므로 −4/5입니다." },
      { q: "θ를 어떻게 바꾸어도 sin²θ + cos²θ의 값은?", set: (s) => (s.t = 4), answer: () => 1, why: "단위원의 반지름이 1이기 때문입니다." },
    ],
  },
  {
    id: "alg-beats", grade: AL, unit: 3, lesson: "Ⅲ 탐구", title: "맥놀이 — 두 사인 곡선을 더하면 생기는 울림", type: "조작", time: "10분",
    tags: ["삼각함수의 그래프", "주기", "합성"], links: ["alg-graph-wrap", "lab-fourier"],
    desc: "진동수가 조금 다른 두 소리 y = sin(ax)와 y = sin(bx)를 더하면 소리가 커졌다 작아졌다 하는 맥놀이가 생깁니다. 두 진동수를 바꾸며 합의 그래프를 감싸는 곡선(점선)의 주기가 진동수의 차에 따라 정해짐을 확인합니다.",
    obs: ["두 그래프의 마루가 겹치는 곳에서 커지고, 마루와 골이 겹치는 곳에서 작아집니다.", "합은 2cos((a − b)x/2)·sin((a + b)x/2)로 나타낼 수 있습니다(교과 밖 보충 공식).", "두 진동수가 가까울수록 울림이 느리게 반복됩니다."],
    q: "악기를 조율할 때 맥놀이가 사라지게 맞추는 까닭은 무엇일까요?",
    formula: "sin ax + sin bx = 2 cos((a − b)x/2) sin((a + b)x/2)",
    en: { title: "Beats", desc: "Adding two nearby sine waves." },
    view: { x: [-0.3, 25], y: [-3.4, 3.4] },
    params: [{ key: "a", label: "첫째 진동수 a", min: 2, max: 8, step: 0.1, value: 5 }, { key: "b", label: "둘째 진동수 b", min: 2, max: 8, step: 0.1, value: 5.5 }, { key: "each", label: "두 곡선도 보이기", type: "check", value: false }],
    draw(s, g) {
      g.seg([0, 0], [24.8, 0], { color: "axis", w: 1.2 });
      if (s.each) { g.fx((x) => Math.sin(s.a * x) + 2.4, { color: "b", w: 1.2, from: 0, to: 24.6, n: 2000 }); g.fx((x) => Math.sin(s.b * x) - 2.4, { color: "c", w: 1.2, from: 0, to: 24.6, n: 2000 }); }
      const env = (x) => 2 * Math.abs(Math.cos(((s.a - s.b) * x) / 2));
      g.fx(env, { color: "e", w: 1.6, dash: "5 4", from: 0, to: 24.6, n: 800 }).fx((x) => -env(x), { color: "e", w: 1.6, dash: "5 4", from: 0, to: 24.6, n: 800 });
      g.fx((x) => Math.sin(s.a * x) + Math.sin(s.b * x), { color: "a", w: 2.2, from: 0, to: 24.6, n: 3000 });
    },
    metrics(s) { const d = Math.abs(s.a - s.b); return [["진동수의 차", fmt(d, 2)], ["울림이 반복되는 주기", d < 1e-9 ? "울림 없음" : `2π/${fmt(d, 2)} ≈ ${fmt((2 * Math.PI) / d, 2)}`, "key"]]; },
    predict: [
      { q: "a = 5, b = 5.5일 때 울림의 주기는 약 얼마? (소수 첫째 자리까지)", set: (s) => Object.assign(s, { a: 5, b: 6 }), reveal: (s) => (s.b = 5.5), answer: () => (2 * Math.PI) / 0.5, tol: 0.1, why: "2π/|a − b| = 2π/0.5 = 4π ≈ 12.6입니다." },
      { q: "두 진동수가 같아지면 울림은?", options: O("사라진다", "더 빨라진다"), set: (s) => Object.assign(s, { a: 5, b: 5.5 }), reveal: (s) => (s.b = 5), answer: () => "a", why: "두 곡선이 늘 겹쳐 진폭 2인 하나의 사인 곡선이 됩니다." },
    ],
  },
  {
    id: "alg-sine-ambiguous", grade: AL, unit: 4, lesson: "Ⅳ-1", title: "사인법칙과 두 삼각형 — 두 변과 한 각이 주어질 때", type: "조작", time: "12분",
    tags: ["사인법칙", "삼각형의 결정", "작도"], links: ["alg-sine-law"],
    desc: "∠A와 두 변 b, a(∠A의 대변)가 주어지면 C에서 반지름 a인 원을 그려 직선과 만나는 점을 B로 잡습니다. 원이 직선과 두 점에서 만나면 삼각형이 두 개, 접하면 하나, 만나지 않으면 없습니다. sin B = b sin A / a로 두 경우를 확인합니다.",
    obs: ["b sin A는 C에서 반대쪽 직선까지의 높이입니다.", "a < b sin A이면 삼각형이 없고, a = b sin A이면 직각삼각형 하나입니다.", "b sin A < a < b이면 B가 두 곳, 곧 ∠B와 180° − ∠B의 두 삼각형이 됩니다."],
    q: "∠A = 30°, b = 10일 때 삼각형이 두 개 생기는 a의 범위를 구해 봅시다.",
    formula: "sin B = (b sin A)/a",
    en: { title: "The Ambiguous Case", desc: "Two sides and a non-included angle." },
    view: { x: [-0.8, 17.5], y: [-1.6, 8.6] },
    params: [{ key: "A", label: "∠A (°)", min: 15, max: 80, step: 1, value: 30 }, { key: "b", label: "b = AC", min: 4, max: 10, step: 0.5, value: 10 }, { key: "a", label: "a = BC", min: 1, max: 12, step: 0.1, value: 7 }],
    draw(s, g) {
      const A = [0, 0], th = (s.A * Math.PI) / 180, C = [s.b * Math.cos(th), s.b * Math.sin(th)], h = C[1];
      g.seg([-0.5, 0], [17.3, 0], { color: "ink", w: 2 });
      g.seg(A, C, { color: "b", w: 3 }).text([C[0] / 2, C[1] / 2], `b = ${fmt(s.b)}`, { dx: -10, anchor: "end", bold: true, color: "b" });
      g.circle(C, s.a, { color: "a", w: 1.4, dash: "5 4" });
      g.seg(C, [C[0], 0], { color: "muted", w: 1.2, dash: "3 4" }).text([C[0], h / 2], `b sin A = ${fmt(h, 2)}`, { dx: 6, anchor: "start", size: 12, color: "muted" });
      g.arc(A, [1, 0], C, { color: "c", r: 30, label: `${s.A}°` });
      if (s.a >= h - 1e-9) { const dx = Math.sqrt(Math.max(0, s.a * s.a - h * h)); [C[0] - dx, C[0] + dx].forEach((x, i) => { if (x > 1e-6) { g.seg(C, [x, 0], { color: i ? "a" : "e", w: 2.6 }); g.point([x, 0], i ? "B₁" : "B₂", { color: i ? "a" : "e", dy: 20 }); } }); }
      g.point(A, "A", { color: "ink", dy: 20 }).point(C, "C", { color: "ink" });
    },
    count(s) { const h = s.b * Math.sin((s.A * Math.PI) / 180); if (s.a < h - 1e-9) return 0; if (Math.abs(s.a - h) < 1e-9 || s.a >= s.b) return 1; return 2; },
    metrics(s) { const h = s.b * Math.sin((s.A * Math.PI) / 180), sB = h / s.a; return [["b sin A", fmt(h, 3)], ["sin B = b sin A / a", sB <= 1 ? fmt(sB, 4) : "1보다 큼"], ["만들 수 있는 삼각형", `${this.count(s)}개`, "key"]]; },
    predict: [
      { q: "∠A = 30°, b = 10, a = 7이면 삼각형은 몇 개 생길까요?", set: (s) => Object.assign(s, { A: 30, b: 10, a: 4 }), reveal: (s) => (s.a = 7), answer: () => 2, why: "b sin A = 5 < 7 < 10이라 원이 직선과 두 점에서 만납니다." },
      { q: "같은 조건에서 a가 몇이면 직각삼각형 하나만 생길까요?", set: (s) => Object.assign(s, { A: 30, b: 10, a: 7 }), reveal: (s) => (s.a = 5), answer: () => 5, why: "a = b sin A = 10 × 1/2 = 5이면 원이 직선에 접합니다." },
    ],
  },
  {
    id: "alg-arith-graph", grade: AL, unit: 5, lesson: "Ⅴ-1", title: "등차수열의 그래프 — 직선 위에 놓인 점들", type: "조작", time: "8분",
    tags: ["등차수열", "공차", "일차함수"], links: ["alg-arith-sum", "alg-geo-graph"],
    desc: "등차수열 aₙ = a + (n − 1)d를 점 (n, aₙ)으로 찍으면 모두 기울기가 공차 d인 한 직선 위에 놓입니다. 첫째항과 공차를 바꾸며 등차수열이 일차함수의 자연수 부분과 같음을 확인합니다.",
    obs: ["이웃한 두 점의 높이 차가 늘 d입니다.", "aₙ = dn + (a − d)이므로 기울기 d인 직선 위의 점입니다.", "d < 0이면 점들이 오른쪽 아래로 내려갑니다."],
    q: "제3항이 7, 제7항이 19인 등차수열의 공차와 첫째항을 그래프로 구해 봅시다.",
    formula: "aₙ = a + (n − 1)d",
    en: { title: "Graphing Arithmetic Sequences", desc: "Points on a straight line." },
    view: { x: [-0.6, 11], y: [-9, 14] },
    params: [{ key: "a", label: "첫째항 a", min: -6, max: 8, step: 1, value: 1 }, { key: "d", label: "공차 d", min: -2, max: 2, step: 0.5, value: 1.5 }, { key: "N", label: "찍을 항의 수", min: 1, max: 10, step: 1, value: 10 }],
    draw(s, g) {
      g.grid({ step: 1, every: 2 });
      g.fx((x) => s.a + (x - 1) * s.d, { color: "muted", w: 1.4, dash: "6 5" });
      for (let n = 1; n <= s.N; n++) { const v = s.a + (n - 1) * s.d; g.point([n, v], n <= 3 || n === s.N ? `a${subN(n)}` : "", { color: "a", size: 11 }); if (n > 1) g.seg([n - 1, v - s.d], [n, v - s.d], { color: "b", w: 1.2 }).seg([n, v - s.d], [n, v], { color: "c", w: 1.6 }); }
    },
    metrics(s) { return [["일반항", `aₙ = ${fmt(s.a)} + (n − 1) × ${fmt(s.d)}`], [`a${subN(s.N)}`, fmt(s.a + (s.N - 1) * s.d), "key"], ["직선의 기울기", fmt(s.d)]]; },
    predict: [
      { q: "제3항이 7, 제7항이 19인 등차수열의 공차는?", answer: () => 3, why: "4칸 동안 12가 늘었으므로 d = 12/4 = 3입니다." },
      { q: "a = 1, d = 1.5인 등차수열의 제10항은?", set: (s) => Object.assign(s, { a: 1, d: 1.5, N: 3 }), reveal: (s) => (s.N = 10), answer: () => 14.5, tol: 1e-9, why: "1 + 9 × 1.5 = 14.5입니다." },
    ],
  },
  {
    id: "alg-geo-graph", grade: AL, unit: 5, lesson: "Ⅴ-2", title: "등비수열의 그래프 — 지수함수 위의 점과 부호 바꾸기", type: "조작", time: "8분",
    tags: ["등비수열", "공비", "지수함수"], links: ["alg-geo-seq", "alg-arith-graph"],
    desc: "등비수열 aₙ = arⁿ⁻¹의 점 (n, aₙ)은 r > 0이면 지수함수 곡선 위에, r < 0이면 x축 위아래를 번갈아 오가며 찍힙니다. 공비의 크기가 1보다 크면 멀어지고 작으면 0에 가까워지는 모습을 확인합니다.",
    obs: ["이웃한 두 항의 비가 늘 r입니다.", "r > 1이면 빠르게 커지고, 0 < r < 1이면 0에 가까워집니다.", "r < 0이면 부호가 번갈아 바뀝니다."],
    q: "제2항이 6, 제5항이 162인 등비수열의 공비를 구해 봅시다.",
    formula: "aₙ = arⁿ⁻¹",
    en: { title: "Graphing Geometric Sequences", desc: "Points on an exponential curve." },
    view: { x: [-0.6, 11], y: [-12, 14] },
    params: [{ key: "a", label: "첫째항 a", min: -3, max: 4, step: 0.5, value: 1 }, { key: "r", label: "공비 r", min: -2, max: 2, step: 0.1, value: 1.4 }, { key: "N", label: "찍을 항의 수", min: 1, max: 10, step: 1, value: 8 }],
    draw(s, g) {
      g.grid({ step: 1, every: 2 });
      if (s.r > 0) g.fx((x) => s.a * s.r ** (x - 1), { color: "muted", w: 1.4, dash: "6 5", from: 0.5 });
      for (let n = 1; n <= s.N; n++) { const v = s.a * s.r ** (n - 1); if (Math.abs(v) < 13.5) g.point([n, v], n <= 3 ? `a${subN(n)}` : "", { color: v >= 0 ? "a" : "e", size: 11 }); else g.vec([n, Math.sign(v) * 12], [n, Math.sign(v) * 13.5], { color: "e", w: 2 }); }
    },
    metrics(s) { return [["일반항", `aₙ = ${fmt(s.a)} × ${fmt(s.r)}ⁿ⁻¹`], [`a${subN(s.N)}`, fmt(s.a * s.r ** (s.N - 1), 4), "key"], ["모양", Math.abs(s.r) > 1 ? "멀어짐" : Math.abs(s.r) < 1 ? "0에 가까워짐" : "크기 일정"]]; },
    predict: [
      { q: "제2항이 6, 제5항이 162인 등비수열의 공비는?", answer: () => 3, why: "r³ = 162/6 = 27이므로 r = 3입니다." },
      { q: "a = 1, r = −2인 등비수열의 제5항은?", set: (s) => Object.assign(s, { a: 1, r: 2, N: 5 }), reveal: (s) => (s.r = -2), answer: () => 16, why: "(−2)⁴ = 16입니다. 짝수 번째 거듭제곱이라 양수입니다." },
    ],
  },
  {
    id: "alg-diff-seq", grade: AL, unit: 5, lesson: "Ⅴ 탐구", title: "계차수열 — 차이를 한 번 더 보면 규칙이", type: "조작", time: "10분",
    tags: ["계차수열", "규칙", "탐구"], links: ["alg-arith-graph", "alg-square-sum"],
    desc: "1, 2, 4, 7, 11, …처럼 바로 규칙이 보이지 않는 수열도 이웃한 항의 차를 적으면 1, 2, 3, 4, …라는 등차수열이 숨어 있습니다. 첫째항과 차의 규칙을 바꾸며 계차를 더해 일반항을 만드는 방법을 확인합니다.",
    obs: ["bₙ = aₙ₊₁ − aₙ인 수열 {bₙ}을 계차수열이라 합니다.", "aₙ = a₁ + (b₁ + b₂ + ⋯ + bₙ₋₁)입니다.", "계차가 등차수열이면 aₙ은 n에 대한 이차식입니다."],
    q: "삼각수 1, 3, 6, 10, 15, …의 계차수열은 무엇일까요?",
    formula: "aₙ = a₁ + Σₖ₌₁ⁿ⁻¹ bₖ",
    en: { title: "Difference Sequences", desc: "Look at the differences of differences." },
    view: BOX,
    params: [{ key: "a1", label: "첫째항 a₁", min: 0, max: 5, step: 1, value: 1 }, { key: "b1", label: "첫 차 b₁", min: 1, max: 5, step: 1, value: 1 }, { key: "e", label: "차가 늘어나는 양", min: 0, max: 3, step: 1, value: 1 }, { key: "N", label: "항의 수", min: 2, max: 8, step: 1, value: 7 }],
    seq(s) { const a = [s.a1]; for (let k = 1; k < s.N; k++) a.push(a[k - 1] + s.b1 + (k - 1) * s.e); return a; },
    draw(s, g) {
      const A = this.seq(s), dx = 15 / s.N;
      A.forEach((v, i) => { const x = 0.6 + (i + 0.5) * dx; g.circle([x, 8.4], 0.55, { fill: "a", fo: 0.35, color: "a", w: 1.6 }); g.text([x, 8.4], String(v), { dy: 5, bold: true, size: 15 }); if (i) { const xm = x - dx / 2; g.text([xm, 6.6], `+${A[i] - A[i - 1]}`, { bold: true, color: "b", size: 14 }); g.seg([x - dx + 0.4, 7.9], [xm, 6.95], { color: "b", w: 1 }).seg([x - 0.4, 7.9], [xm, 6.95], { color: "b", w: 1 }); if (i > 1) g.text([x - dx, 4.9], `+${s.e}`, { bold: true, color: "c", size: 13 }); } });
      g.text([0.6, 9.8], "수열 aₙ", { anchor: "start", bold: true, color: "a", size: 13 }).text([0.6, 7.4], "계차 bₙ", { anchor: "start", bold: true, color: "b", size: 12 }).text([0.6, 5.4], "계차의 계차", { anchor: "start", bold: true, color: "c", size: 12 });
      const n = s.N, an = s.a1 + (n - 1) * s.b1 + (s.e * (n - 1) * (n - 2)) / 2;
      g.text([0.6, 2.4], `aₙ = ${s.a1} + ${s.b1}(n − 1) + ${s.e}(n − 1)(n − 2)/2`, { anchor: "start", bold: true, size: 15 }).text([0.6, 1.3], `a${subN(n)} = ${an}`, { anchor: "start", size: 14, color: "e", bold: true });
    },
    metrics(s) { const A = this.seq(s); return [["수열", A.join(", ")], ["계차수열", A.slice(1).map((v, i) => v - A[i]).join(", ")], ["다음 항", String(A.at(-1) + s.b1 + (s.N - 1) * s.e), "key"]]; },
    predict: [
      { q: "1, 2, 4, 7, 11, … 의 다음 항은?", set: (s) => Object.assign(s, { a1: 1, b1: 1, e: 1, N: 5 }), reveal: (s) => (s.N = 6), answer: () => 16, why: "차가 1, 2, 3, 4로 1씩 늘어 다음 차는 5, 11 + 5 = 16입니다." },
      { q: "삼각수 1, 3, 6, 10, …의 제10항은?", set: (s) => Object.assign(s, { a1: 1, b1: 2, e: 1, N: 4 }), reveal: (s) => (s.N = 8), answer: () => 55, why: "1 + (2 + 3 + ⋯ + 10) = 55 = 10 × 11/2입니다." },
    ],
  },
  {
    id: "alg-sigma", grade: AL, unit: 6, lesson: "Ⅵ-1", title: "∑의 성질 — 막대를 나누고 합치기", type: "조작", time: "10분",
    tags: ["합의 기호", "∑의 성질", "수열의 합"], links: ["alg-square-sum", "alg-arith-sum"],
    desc: "각 항 aₖ + bₖ를 두 색 막대로 쌓으면 전체 넓이가 Σaₖ와 Σbₖ의 합과 같습니다. 모든 막대를 c배 하면 합도 c배이고, 상수 c를 n번 더하면 cn임을 막대 그림으로 확인합니다. 단 Σaₖbₖ ≠ (Σaₖ)(Σbₖ)인 것도 비교합니다.",
    obs: ["Σ(aₖ + bₖ) = Σaₖ + Σbₖ입니다.", "Σ caₖ = cΣaₖ, Σ c = cn입니다.", "곱의 합은 합의 곱과 다릅니다."],
    q: "Σₖ₌₁¹⁰ (2k + 3)을 성질을 써서 계산해 봅시다.",
    formula: "Σ(aₖ ± bₖ) = Σaₖ ± Σbₖ, Σcaₖ = cΣaₖ, Σc = cn",
    en: { title: "Properties of Sigma", desc: "Split and merge bars." },
    view: BOX,
    params: [{ key: "n", label: "항의 수 n", min: 2, max: 10, step: 1, value: 6 }, { key: "p", label: "aₖ = pk의 p", min: 0, max: 2, step: 0.5, value: 1 }, { key: "c", label: "bₖ = c (상수)", min: 0, max: 4, step: 1, value: 3 }],
    draw(s, g) {
      const u = 14 / s.n, k0 = 8.4 / Math.max(1, s.p * s.n + s.c);
      for (let k = 1; k <= s.n; k++) { const x = 1 + (k - 1) * u, A = s.p * k, B = s.c; rect(g, x + 0.1, 1, u - 0.2, A * k0, { fill: "a", fo: 0.5, color: "a", w: 1 }); rect(g, x + 0.1, 1 + A * k0, u - 0.2, B * k0, { fill: "b", fo: 0.5, color: "b", w: 1 }); g.text([x + u / 2, 1], String(k), { dy: 16, size: 11, color: "muted" }); }
      g.text([1, 10.4], `주황: aₖ = ${fmt(s.p)}k   파랑: bₖ = ${s.c}`, { anchor: "start", bold: true, size: 13 });
    },
    metrics(s) { const SA = (s.p * s.n * (s.n + 1)) / 2, SB = s.c * s.n; return [["Σaₖ = p × n(n + 1)/2", fmt(SA, 2)], ["Σbₖ = cn", String(SB)], ["Σ(aₖ + bₖ)", fmt(SA + SB, 2), "key"]]; },
    predict: [
      { q: "Σₖ₌₁¹⁰ (2k + 3)의 값은?", answer: () => 140, why: "2 × 55 + 3 × 10 = 110 + 30 = 140입니다." },
      { q: "Σₖ₌₁⁶ 3의 값은?", set: (s) => Object.assign(s, { n: 6, p: 0, c: 3 }), answer: () => 18, why: "3을 6번 더하므로 18입니다." },
    ],
  },
  {
    id: "alg-odd-sum", grade: AL, unit: 7, lesson: "Ⅶ-2", title: "홀수의 합은 제곱수 — ㄱ자 조각을 덧붙이며", type: "조작", time: "8분",
    tags: ["수학적 귀납법", "홀수의 합", "그림 증명"], links: ["alg-domino"],
    desc: "한 변이 k인 정사각형에 ㄱ자 모양 조각 2k + 1개를 덧붙이면 한 변이 k + 1인 정사각형이 됩니다. 1 + 3 + 5 + ⋯ + (2n − 1) = n²이 성립함을 그림으로 보고, 이것이 수학적 귀납법의 'k에서 k + 1로' 단계와 같음을 확인합니다.",
    obs: ["k² + (2k + 1) = (k + 1)²입니다.", "ㄱ자 조각의 칸 수는 차례로 1, 3, 5, 7, …입니다.", "n = 1에서 시작해 한 단계씩 덧붙이면 모든 n에서 성립합니다."],
    q: "2 + 4 + 6 + ⋯ + 2n은 어떤 그림으로 나타낼 수 있을까요?",
    formula: "1 + 3 + ⋯ + (2n − 1) = n²",
    en: { title: "Sums of Odd Numbers", desc: "Add L-shaped gnomons." },
    view: BOX,
    params: [{ key: "n", label: "n", min: 1, max: 10, step: 1, value: 5 }],
    anim: { key: "n", min: 1, max: 10, speed: 1, label: "ㄱ자 붙이기" },
    draw(s, g) {
      const u = Math.min(0.9, 9.2 / s.n), x0 = 1, y0 = 1, cols = ["a", "b", "c", "d", "e", "f"];
      for (let i = 0; i < s.n; i++) for (let j = 0; j < s.n; j++) { const k = Math.max(i, j); rect(g, x0 + i * u, y0 + j * u, u - 0.06, u - 0.06, { fill: cols[k % 6], fo: k === s.n - 1 ? 0.75 : 0.4, stroke: false }); }
      const tx = x0 + s.n * u + 0.8;
      g.text([tx, 9.8], Array.from({ length: s.n }, (_, k) => 2 * k + 1).join(" + "), { anchor: "start", bold: true, size: s.n > 7 ? 13 : 16 });
      g.text([tx, 8.6], `= ${s.n * s.n} = ${s.n}²`, { anchor: "start", bold: true, size: 18, color: "e" });
      if (s.n > 1) g.text([tx, 7.2], `${s.n - 1}² + ${2 * s.n - 1} = ${s.n}²  (진한 ㄱ자가 새로 붙은 조각)`, { anchor: "start", size: 13, color: "muted" });
    },
    metrics(s) { return [["홀수의 합", String(s.n * s.n), "key"], ["마지막 ㄱ자 조각", `${2 * s.n - 1}칸`]]; },
    predict: [
      { q: "1 + 3 + 5 + ⋯ + 19의 값은?", set: (s) => (s.n = 4), reveal: (s) => (s.n = 10), answer: () => 100, why: "홀수 10개의 합이므로 10² = 100입니다." },
      { q: "한 변 6인 정사각형을 한 변 7로 키우려면 몇 칸짜리 ㄱ자 조각이 필요할까요?", set: (s) => (s.n = 6), reveal: (s) => (s.n = 7), answer: () => 13, why: "2 × 6 + 1 = 13칸입니다." },
    ],
  },
  {
    id: "alg-circle-regions", grade: AL, unit: 7, lesson: "Ⅶ 탐구", title: "원을 나누는 영역 — 1, 2, 4, 8, 16, 그다음은?", type: "조작", time: "10분",
    tags: ["수학적 귀납법", "규칙 추측", "반례"], links: ["alg-domino", "alg-odd-sum"],
    desc: "원 위에 점을 n개 찍고 모든 두 점을 이으면 원이 몇 조각으로 나뉠까요? n = 1부터 5까지는 1, 2, 4, 8, 16으로 2배씩 늘어 보이지만 n = 6에서는 32가 아니라 31입니다. 몇 개의 예만 보고 규칙을 단정하면 안 되는 까닭, 곧 증명이 필요한 까닭을 확인합니다.",
    obs: ["몇 개의 경우만 확인한 규칙은 추측일 뿐입니다.", "n = 6에서 31조각으로 2ⁿ⁻¹ 규칙이 깨집니다(세 현이 한 점에서 만나지 않을 때).", "실제 개수는 1 + C(n, 2) + C(n, 4)입니다."],
    q: "이 예처럼 처음 몇 개는 맞다가 나중에 틀리는 규칙을 하나 더 찾아봅시다.",
    formula: "영역의 수 = 1 + ₙC₂ + ₙC₄",
    en: { title: "Regions of a Circle", desc: "1, 2, 4, 8, 16, … then 31!" },
    view: { x: [-4.6, 9], y: [-4.2, 4.2] },
    params: [{ key: "n", label: "점의 개수 n", min: 1, max: 8, step: 1, value: 5 }],
    anim: { key: "n", min: 1, max: 8, speed: 0.8, label: "점 늘리기" },
    draw(s, g) {
      const R = 3.6, P = Array.from({ length: s.n }, (_, i) => { const a = Math.PI / 2 + (2 * Math.PI * i) / s.n + (i % 2 ? 0.17 : 0) + i * 0.05; return [R * Math.cos(a), R * Math.sin(a)]; });
      g.circle([0, 0], R, { color: "ink", w: 2.4, fill: "b", fo: 0.06 });
      for (let i = 0; i < s.n; i++) for (let j = i + 1; j < s.n; j++) g.seg(P[i], P[j], { color: "b", w: 1.6 });
      P.forEach((p) => g.point(p, "", { color: "a", r: 5 }));
      for (let n = 1; n <= 8; n++) { const y = 3.6 - (n - 1) * 0.95, r = regions(n), guess = 2 ** (n - 1); g.text([5.2, y], `n = ${n}: ${r}`, { anchor: "start", bold: n === s.n, size: 14, color: n === s.n ? "a" : "muted" }); g.text([8.9, y], r === guess ? "= 2ⁿ⁻¹" : `≠ ${guess}`, { anchor: "end", size: 12, color: r === guess ? "c" : "e", bold: r !== guess }); }
    },
    metrics(s) { return [["영역의 수", String(regions(s.n)), "key"], ["2ⁿ⁻¹ 추측", String(2 ** (s.n - 1))], ["맞나?", regions(s.n) === 2 ** (s.n - 1) ? "이번에는 맞음" : "틀림!"]]; },
    predict: [
      { q: "점이 6개이면 원은 몇 조각으로 나뉠까요?", set: (s) => (s.n = 5), reveal: (s) => (s.n = 6), answer: () => 31, why: "1 + 15 + 15 = 31입니다. 32가 아닙니다!" },
      { q: "1, 2, 4, 8, 16만 보고 '다음은 32'라고 할 수 있을까요?", options: O("증명 없이는 알 수 없다", "그렇다"), set: (s) => (s.n = 5), reveal: (s) => (s.n = 6), answer: () => "a", why: "규칙은 추측이고, 모든 n에서 성립함을 보이려면 증명(예: 수학적 귀납법)이 필요합니다." },
    ],
  },
];
