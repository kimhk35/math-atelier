// 23차 묶음 4 — 중학교 1학년 수·식·함수 (소인수분해 · 정수와 유리수 · 문자와 식 · 좌표평면과 그래프)
import { fmt, clamp } from "./hs-core.js";

const G1 = 1;
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const gcd = (a, b) => { while (b) [a, b] = [b, a % b]; return a; };
const SUP = "⁰¹²³⁴⁵⁶⁷⁸⁹";
const supN = (n) => [...String(n)].map((d) => SUP[d]).join("");
function factor(n) { const f = []; let m = n; for (let p = 2; p * p <= m; p++) { let e = 0; while (m % p === 0) { m /= p; e++; } if (e) f.push([p, e]); } if (m > 1) f.push([m, 1]); return f; }
const factStr = (n) => (n < 2 ? String(n) : factor(n).map(([p, e]) => (e > 1 ? `${p}${supN(e)}` : String(p))).join(" × "));
const signed = (v) => (v < 0 ? `(${String(v).replace("-", "−")})` : String(v));
const PR = [2, 3, 5, 7];
const PCOL = { 2: "a", 3: "b", 5: "c", 7: "d" };

// 물통
const TANK = {
  cyl: { n: "원기둥", w: (h) => 1 },
  cone: { n: "아래가 좁은 깔때기", w: (h) => 0.25 + 0.75 * h },
  flask: { n: "아래가 넓은 플라스크", w: (h) => 1 - 0.7 * h },
  step: { n: "아래는 넓고 위는 좁은 통", w: (h) => (h < 0.5 ? 1 : 0.45) },
};
// 단면의 넓이(반폭²에 비례) → 부피 V(h), 시간에 따른 높이 h(t)
function tankH(K, t) {
  const n = 400; let V = 0, tot = 0; for (let i = 0; i < n; i++) tot += K.w((i + 0.5) / n) ** 2 / n;
  const target = t * tot;
  for (let i = 0; i < n; i++) { const dv = K.w((i + 0.5) / n) ** 2 / n; if (V + dv >= target) return (i + (target - V) / dv) / n; V += dv; }
  return 1;
}

export default [
  // ───────── 1단원 소인수분해 ─────────
  {
    id: "m1-sieve", grade: G1, unit: 1, lesson: "1.1", title: "에라토스테네스의 체 — 배수를 지워 소수 찾기", type: "조작", time: "10분",
    tags: ["소수", "합성수", "배수"], links: ["m1-divisor-rect"],
    desc: "1부터 100까지의 수에서 2의 배수, 3의 배수, 5의 배수, 7의 배수를 차례로 지우면 남은 수가 모두 소수입니다. 단계마다 지워지는 수와 남는 수를 보며 7까지만 지워도 충분한 까닭을 생각해 봅니다.",
    obs: ["1은 소수도 합성수도 아니므로 먼저 지웁니다.", "소수 p 자신은 남기고 p의 배수만 지웁니다.", "100보다 작은 합성수는 반드시 2, 3, 5, 7 가운데 하나를 약수로 가집니다. 11 × 11 = 121 > 100이기 때문입니다."],
    q: "200까지의 소수를 찾으려면 어떤 수의 배수까지 지워야 할까요?",
    formula: "소수: 1과 자기 자신만을 약수로 가지는 1보다 큰 자연수",
    en: { title: "The Sieve of Eratosthenes", desc: "Cross out multiples to find primes." },
    view: { x: [0, 15], y: [0, 10.4], pad: 4 },
    params: [{ key: "st", label: "단계", type: "seg", value: 4, step: 1, options: [[0, "시작"], [1, "2의 배수"], [2, "3의 배수"], [3, "5의 배수"], [4, "7의 배수"]] }],
    anim: { key: "st", min: 0, max: 4, speed: 0.8, label: "차례로 지우기" },
    killer(n, st) { if (n === 1) return 1; for (let i = 0; i < st; i++) { const p = PR[i]; if (n !== p && n % p === 0) return p; } return 0; },
    draw(s, g) {
      for (let n = 1; n <= 100; n++) {
        const r = Math.floor((n - 1) / 10), c = (n - 1) % 10, x = 0.6 + c * 1.02, y = 9.8 - r * 0.98, k = this.killer(n, s.st), prime = !k && n > 1;
        g.poly([[x, y], [x + 0.94, y], [x + 0.94, y - 0.9], [x, y - 0.9]], { fill: k > 1 ? PCOL[k] : prime && s.st === 4 ? "e" : "paper", fo: k ? 0.18 : prime && s.st === 4 ? 0.3 : 1, color: "grid", w: 1 });
        g.text([x + 0.47, y - 0.45], String(n), { dy: 5, size: 13, bold: prime, color: k ? "muted" : "ink" });
        if (k) g.seg([x + 0.15, y - 0.75], [x + 0.79, y - 0.15], { color: k > 1 ? PCOL[k] : "muted", w: 1.6 });
      }
      PR.forEach((p, i) => g.text([11.6, 9.3 - i * 0.8], `${p}의 배수`, { anchor: "start", bold: true, color: s.st > i ? PCOL[p] : "muted", size: 14 }));
      if (s.st === 4) g.text([11.6, 5.6], "남은 수 = 소수", { anchor: "start", bold: true, color: "e", size: 14 });
    },
    metrics(s) { let left = 0; for (let n = 2; n <= 100; n++) if (!this.killer(n, s.st)) left++; return [["남은 수 (1 제외)", `${left}개`, "key"], ["이번에 지운 배수", s.st ? `${PR[s.st - 1]}의 배수` : "—"]]; },
    predict: [
      { q: "100 이하의 소수는 모두 몇 개일까요?", set: (s) => (s.st = 0), reveal: (s) => (s.st = 4), answer: () => 25, why: "2, 3, 5, 7의 배수를 지우고 남은 수가 2, 3, 5, 7, 11, …, 97의 25개입니다." },
      { q: "100까지는 7의 배수까지만 지워도 되는 까닭은?", options: O("11 × 11 = 121이 100보다 커서", "7이 가장 큰 한 자리 소수라서", "100이 7의 배수가 아니라서"), set: (s) => (s.st = 3), reveal: (s) => (s.st = 4), answer: () => "a", why: "11 이상의 소수로만 이루어진 합성수는 가장 작아도 121입니다." },
    ],
  },
  {
    id: "m1-divisor-rect", grade: G1, unit: 1, lesson: "1.2", title: "약수 직사각형 — 바둑돌로 만드는 직사각형의 수", type: "조작", time: "10분",
    tags: ["약수", "소인수분해", "제곱수"], links: ["m1-sieve", "m1-gcd-tiles"],
    desc: "바둑돌 n개를 빈틈없이 직사각형으로 늘어놓는 방법을 모두 찾으면, 가로·세로의 수가 n의 약수입니다. 소수는 한 줄로만 놓을 수 있고, 제곱수는 정사각형이 생겨 약수의 개수가 홀수임을 확인합니다. 소인수분해로 약수의 개수를 세는 방법과도 비교합니다.",
    obs: ["가로 a, 세로 b인 직사각형이면 a × b = n이므로 a, b는 n의 약수입니다.", "소수는 1 × n의 한 가지뿐입니다.", "n = pᵃ × qᵇ이면 약수의 개수는 (a + 1)(b + 1)입니다."],
    q: "약수가 정확히 3개인 수는 어떤 수일까요?",
    formula: "n = pᵃ × qᵇ ⇒ 약수의 개수 = (a + 1)(b + 1)",
    en: { title: "Divisor Rectangles", desc: "Arrange n stones into rectangles." },
    view: BOX,
    params: [{ key: "n", label: "바둑돌의 개수 n", min: 1, max: 36, step: 1, value: 12 }],
    anim: { key: "n", min: 1, max: 36, speed: 2, label: "n 늘리기" },
    rects(n) { const r = []; for (let a = 1; a * a <= n; a++) if (n % a === 0) r.push([n / a, a]); return r; },
    draw(s, g) {
      const R = this.rects(s.n); let x = 0.6, y = 10.2, rowH = 0;
      R.forEach(([w, h]) => {
        const d = Math.min(0.42, 14.6 / Math.max(w, 1) / 1.05, 3 / h);
        if (x + w * d > 15.6) { x = 0.6; y -= rowH + 0.9; rowH = 0; }
        for (let i = 0; i < w; i++) for (let j = 0; j < h; j++) g.circle([x + (i + 0.5) * d, y - (j + 0.5) * d], d * 0.4, { fill: w === h ? "e" : "b", fo: 0.7, color: w === h ? "e" : "b", w: 1 });
        g.text([x + (w * d) / 2, y - h * d], `${w} × ${h}`, { dy: 15, size: 12, bold: true, color: w === h ? "e" : "ink" });
        x += w * d + 0.8; rowH = Math.max(rowH, h * d + 0.3);
      });
    },
    metrics(s) { const R = this.rects(s.n), D = []; R.forEach(([w, h]) => { D.push(h); if (w !== h) D.push(w); }); D.sort((a, b) => a - b); return [["약수", D.join(", ")], ["약수의 개수", `${D.length}개`, "key"], ["소인수분해", factStr(s.n)], s.n > 1 && D.length === 2 ? "한 줄로만 놓을 수 있으니 소수입니다." : D.length % 2 ? "정사각형이 있어 약수의 개수가 홀수인 제곱수입니다." : "직사각형은 가로·세로를 바꾼 것을 같은 것으로 셉니다."]; },
    predict: [
      { q: "12의 약수는 모두 몇 개?", set: (s) => (s.n = 7), reveal: (s) => (s.n = 12), answer: () => 6, why: "12 = 2² × 3이므로 (2 + 1)(1 + 1) = 6개입니다. 직사각형 3가지에서 가로·세로를 모두 셉니다." },
      { q: "36의 약수의 개수는?", set: (s) => (s.n = 30), reveal: (s) => (s.n = 36), answer: () => 9, why: "36 = 2² × 3²이므로 3 × 3 = 9개, 6 × 6 정사각형이 있어 홀수 개입니다." },
    ],
  },
  {
    id: "m1-gcd-tiles", grade: G1, unit: 1, lesson: "1.3", title: "타일로 보는 최대공약수와 최소공배수", type: "조작", time: "12분",
    tags: ["최대공약수", "최소공배수", "타일"], links: ["m1-divisor-rect"],
    desc: "가로 a, 세로 b인 직사각형을 같은 크기의 정사각형 타일로 빈틈없이 덮을 때, 가장 큰 타일의 한 변이 최대공약수입니다. 반대로 a × b 타일을 이어 붙여 만드는 가장 작은 정사각형의 한 변은 최소공배수입니다.",
    obs: ["정사각형 타일의 한 변은 a와 b를 모두 나누어떨어지게 해야 하므로 공약수입니다.", "가장 큰 타일의 한 변이 최대공약수입니다.", "a × b = 최대공약수 × 최소공배수입니다."],
    q: "두 수가 서로소이면 가장 큰 타일과 가장 작은 정사각형은 어떻게 될까요?",
    formula: "a × b = gcd(a, b) × lcm(a, b)",
    en: { title: "GCD and LCM with Tiles", desc: "Biggest square tiles and smallest square." },
    view: BOX,
    params: [
      { key: "mode", label: "보기", type: "seg", value: "g", options: [["g", "최대공약수 (타일로 덮기)"], ["l", "최소공배수 (정사각형 만들기)"]] },
      { key: "a", label: "가로 a", min: 2, max: 24, step: 1, value: 18 },
      { key: "b", label: "세로 b", min: 2, max: 24, step: 1, value: 12 },
      { key: "t", label: "타일 한 변", min: 1, max: 24, step: 1, value: 6, when: (s) => s.mode === "g" },
    ],
    draw(s, g) {
      const G = gcd(s.a, s.b), Lm = (s.a * s.b) / G;
      if (s.mode === "g") {
        const k = Math.min(14 / s.a, 9.4 / s.b), x0 = 1, y0 = 10.2, ok = s.a % s.t === 0 && s.b % s.t === 0;
        for (let i = 0; i * s.t < s.a; i++) for (let j = 0; j * s.t < s.b; j++) { const w = Math.min(s.t, s.a - i * s.t), h = Math.min(s.t, s.b - j * s.t); g.poly([[x0 + i * s.t * k, y0 - j * s.t * k], [x0 + (i * s.t + w) * k, y0 - j * s.t * k], [x0 + (i * s.t + w) * k, y0 - (j * s.t + h) * k], [x0 + i * s.t * k, y0 - (j * s.t + h) * k]], { fill: ok ? ((i + j) % 2 ? "b" : "c") : w < s.t || h < s.t ? "e" : "b", fo: 0.35, color: "paper", w: 1.4 }); }
        g.poly([[x0, y0], [x0 + s.a * k, y0], [x0 + s.a * k, y0 - s.b * k], [x0, y0 - s.b * k]], { color: "ink", w: 2.4 });
        g.text([x0 + (s.a * k) / 2, y0 - s.b * k], ok ? `빈틈없이 덮임 ✓${s.t === G ? " — 가장 큰 타일!" : ""}` : "남는 부분(분홍)이 생겨요", { dy: 22, bold: true, color: ok ? "c" : "e" });
      } else {
        const n = Lm, k = Math.min(9.2 / n, 14 / n), x0 = 1, y0 = 10.2;
        for (let i = 0; i < n / s.a; i++) for (let j = 0; j < n / s.b; j++) g.poly([[x0 + i * s.a * k, y0 - j * s.b * k], [x0 + (i + 1) * s.a * k, y0 - j * s.b * k], [x0 + (i + 1) * s.a * k, y0 - (j + 1) * s.b * k], [x0 + i * s.a * k, y0 - (j + 1) * s.b * k]], { fill: (i + j) % 2 ? "a" : "d", fo: 0.35, color: "paper", w: 1.2 });
        g.poly([[x0, y0], [x0 + n * k, y0], [x0 + n * k, y0 - n * k], [x0, y0 - n * k]], { color: "ink", w: 2.4 });
        g.text([x0 + n * k + 0.4, y0 - (n * k) / 2], `한 변 ${n}`, { anchor: "start", bold: true, color: "a" }).text([x0 + n * k + 0.4, y0 - (n * k) / 2 - 0.8], `타일 ${(n / s.a) * (n / s.b)}장`, { anchor: "start", size: 13, color: "muted" });
      }
    },
    metrics(s) { const G = gcd(s.a, s.b), L = (s.a * s.b) / G; return [["최대공약수", String(G), s.mode === "g" ? "key" : ""], ["최소공배수", String(L), s.mode === "l" ? "key" : ""], ["a × b = 최대공약수 × 최소공배수", `${s.a * s.b} = ${G} × ${L}`], ["소인수분해", `${factStr(s.a)} / ${factStr(s.b)}`]]; },
    predict: [
      { q: "가로 18, 세로 12인 직사각형을 덮는 가장 큰 정사각형 타일의 한 변은?", set: (s) => Object.assign(s, { mode: "g", a: 18, b: 12, t: 4 }), reveal: (s) => (s.t = 6), answer: () => 6, why: "18과 12의 최대공약수는 6입니다." },
      { q: "가로 4, 세로 6인 타일을 이어 붙여 만드는 가장 작은 정사각형의 한 변은?", set: (s) => Object.assign(s, { mode: "l", a: 4, b: 6 }), answer: () => 12, why: "4와 6의 최소공배수는 12입니다." },
    ],
  },

  // ───────── 2단원 정수와 유리수 ─────────
  {
    id: "m1-numberline", grade: G1, unit: 2, lesson: "2.2", title: "수직선 위의 화살표로 하는 덧셈과 뺄셈", type: "조작", time: "10분",
    tags: ["정수", "덧셈", "뺄셈"], links: ["m1-neg-times"],
    desc: "a에서 출발해 b만큼 화살표를 그립니다. 양수는 오른쪽, 음수는 왼쪽입니다. 뺄셈 a − b는 '빼는 수의 부호를 바꾸어 더하기', 곧 화살표를 반대로 돌리는 것임을 확인합니다.",
    obs: ["(양수) + (음수)는 큰 쪽 화살표의 방향으로 차이만큼 갑니다.", "a − b = a + (−b): 빼는 수의 화살표를 뒤집어 더합니다.", "a − b는 수직선에서 b에서 a까지 가는 화살표이기도 합니다."],
    q: "온도가 −3℃에서 5℃ 올랐다가 8℃ 내려가면 몇 ℃일까요? 화살표로 나타내 봅시다.",
    formula: "a − b = a + (−b)",
    en: { title: "Adding and Subtracting on a Number Line", desc: "Arrows to the right and left." },
    view: { x: [-10.5, 10.5], y: [-3.4, 4] },
    params: [
      { key: "op", label: "계산", type: "seg", value: "-", options: [["+", "덧셈 a + b"], ["-", "뺄셈 a − b"]] },
      { key: "a", label: "a", min: -6, max: 6, step: 1, value: 2 },
      { key: "b", label: "b", min: -6, max: 6, step: 1, value: -4 },
    ],
    draw(s, g) {
      const step = s.op === "+" ? s.b : -s.b, r = s.a + step;
      g.seg([-10.2, 0], [10.2, 0], { color: "axis", w: 1.8 });
      for (let x = -10; x <= 10; x++) { g.seg([x, -0.15], [x, 0.15], { color: "axis", w: 1.2 }); g.text([x, 0], String(x).replace("-", "−"), { dy: 22, size: 12, color: x === 0 ? "ink" : "muted", bold: x === 0 }); }
      g.vec([0, 1], [s.a, 1], { color: "b", w: 3 }).text([s.a / 2, 1], `a = ${signed(s.a)}`, { dy: -10, bold: true, color: "b", size: 13 });
      if (s.op === "-" && s.b) { g.vec([s.a, 3.1], [s.a + s.b, 3.1], { color: "muted", w: 2, dash: "5 4" }); g.text([s.a + s.b / 2, 3.1], `b = ${signed(s.b)} → 뒤집기`, { dy: -8, size: 12, color: "muted" }); }
      if (step) g.vec([s.a, 2], [r, 2], { color: "a", w: 3.4 }).text([s.a + step / 2, 2], s.op === "+" ? `+ ${signed(s.b)}` : `+ ${signed(-s.b)}`, { dy: -10, bold: true, color: "a", size: 13 });
      g.point([r, 0], "", { color: "e", r: 7 });
      g.text([r, 0], `= ${signed(r)}`, { dy: -14, bold: true, color: "e", size: 15 });
    },
    metrics(s) { const r = s.op === "+" ? s.a + s.b : s.a - s.b; return [["식", s.op === "+" ? `${signed(s.a)} + ${signed(s.b)}` : `${signed(s.a)} − ${signed(s.b)} = ${signed(s.a)} + ${signed(-s.b)}`], ["결과", signed(r).replace(/[()]/g, ""), "key"]]; },
    predict: [
      { q: "(−3) + 5의 값은?", set: (s) => Object.assign(s, { op: "+", a: -3, b: 0 }), reveal: (s) => (s.b = 5), answer: () => 2, why: "−3에서 오른쪽으로 5칸 가면 2입니다." },
      { q: "2 − (−4)의 값은?", set: (s) => Object.assign(s, { op: "-", a: 2, b: 0 }), reveal: (s) => (s.b = -4), answer: () => 6, why: "−4를 빼는 것은 +4를 더하는 것과 같으므로 2 + 4 = 6입니다." },
    ],
  },
  {
    id: "m1-neg-times", grade: G1, unit: 2, lesson: "2.3", title: "(음수) × (음수) = (양수) — 규칙을 이어 가면", type: "조작", time: "10분",
    tags: ["정수의 곱셈", "부호", "규칙"], links: ["m1-numberline"],
    desc: "(−3) × 3, (−3) × 2, (−3) × 1, …처럼 곱하는 수를 1씩 줄이면 곱이 3씩 커집니다. 이 규칙을 0 아래로 이어 가면 (−3) × (−1) = 3이 되어야 함을 표와 점의 그래프로 확인합니다.",
    obs: ["곱하는 수가 1 줄 때마다 곱은 a만큼 줄어듭니다.", "a가 음수이면 곱하는 수가 줄수록 곱이 커집니다.", "점들이 원점을 지나는 한 직선 위에 있어 규칙이 0 아래로도 이어집니다."],
    q: "(−1) × (−1) = 1이 아니라 −1이라고 하면 어떤 계산 규칙이 깨질까요?",
    formula: "(−) × (−) = (+), (−) × (+) = (−)",
    en: { title: "Why Negative × Negative Is Positive", desc: "Continue the pattern below zero." },
    view: { x: [-4.2, 4.2], y: [-13, 13] },
    params: [
      { key: "a", label: "곱해지는 수 a", min: -3, max: 3, step: 1, value: -3 },
      { key: "b", label: "곱하는 수 b", min: -4, max: 4, step: 1, value: -2 },
    ],
    anim: { key: "b", min: -4, max: 4, speed: 1.2, loop: "bounce", label: "곱하는 수 바꾸기" },
    draw(s, g) {
      g.grid({ step: 1, every: 2, labels: false });
      for (let y = -12; y <= 12; y += 4) if (y) g.text([0, y], String(y).replace("-", "−"), { dx: -6, anchor: "end", dy: 4, size: 11, color: "muted" });
      for (let x = -4; x <= 4; x++) if (x) g.text([x, 0], String(x).replace("-", "−"), { dy: 16, size: 11, color: "muted" });
      g.line([0, 0], [1, s.a || 1e-9], { color: "muted", w: 1.2, dash: "4 5", opacity: s.a ? 1 : 0.4 });
      for (let b = 4; b >= -4; b--) { const on = b === s.b, past = b >= s.b; g.point([b, s.a * b], "", { color: on ? "e" : b < 0 ? "a" : "b", r: on ? 7 : 4.5, hollow: !past }); }
      g.text([g.xr[0] + 0.2, g.yr[1] - 1], `${signed(s.a)} × ${signed(s.b)} = ${signed(s.a * s.b)}`, { anchor: "start", bold: true, size: 18, color: "e" });
      let y = g.yr[1] - 3; for (let b = 3; b >= -3; b--) { g.text([2.4, y], `${signed(s.a)} × ${signed(b)} = ${signed(s.a * b)}`, { anchor: "start", size: 12, color: b < 0 ? "a" : "muted", bold: b === s.b }); y -= 1.6; }
    },
    metrics(s) { return [["곱", String(s.a * s.b).replace("-", "−"), "key"], ["곱하는 수가 1 줄면 곱은", s.a ? `${s.a < 0 ? "+" : "−"}${Math.abs(s.a)}` : "그대로 0"]]; },
    predict: [
      { q: "(−2) × (−4)의 값은?", set: (s) => Object.assign(s, { a: -2, b: 1 }), reveal: (s) => (s.b = -4), answer: () => 8, why: "(−2) × 1 = −2에서 곱하는 수가 1씩 줄 때마다 2씩 커지므로 −2, 0, 2, 4, 6, 8입니다." },
      { q: "(−3) × 0 = 0 다음 (−3) × (−1)은 규칙에 따라 얼마일까요?", set: (s) => Object.assign(s, { a: -3, b: 0 }), reveal: (s) => (s.b = -1), answer: () => 3, why: "곱하는 수가 1 줄 때마다 곱이 3씩 커지므로 0 + 3 = 3입니다." },
    ],
  },

  // ───────── 3단원 문자와 식 ─────────
  {
    id: "m1-matchstick", grade: G1, unit: 3, lesson: "3.1", title: "성냥개비 무늬와 문자식 — n번째 모양 세기", type: "조작", time: "10분",
    tags: ["문자의 사용", "규칙", "일차식"], links: ["m1-balance"],
    desc: "성냥개비로 정사각형·삼각형·집 모양을 이어 붙일 때 n번째 모양에 필요한 성냥개비 수를 문자식으로 나타냅니다. 처음 하나와 '하나 더 붙일 때 드는 개수'로 식을 세우고 그림으로 확인합니다.",
    obs: ["정사각형을 이어 붙이면 처음 1개만 4개, 그 뒤로는 3개씩 늘어납니다.", "그래서 n개를 이으면 3n + 1개입니다.", "같은 규칙을 다른 방법으로 세어도 식을 정리하면 같아집니다."],
    q: "정사각형 무늬의 개수를 '가로선 + 세로선'으로 세면 어떤 식이 나올까요? 3n + 1과 같을까요?",
    formula: "정사각형 3n + 1 · 삼각형 2n + 1 · 집 모양 5n + 1",
    en: { title: "Matchstick Patterns", desc: "Write the nth term as an expression." },
    view: { x: [0, 16], y: [0, 9], pad: 6 },
    params: [
      { key: "p", label: "무늬", type: "seg", value: "sq", options: [["sq", "정사각형"], ["tri", "삼각형"], ["house", "집 모양"]] },
      { key: "n", label: "이어 붙인 개수 n", min: 1, max: 10, step: 1, value: 4 },
    ],
    anim: { key: "n", min: 1, max: 10, speed: 1.2, label: "하나씩 붙이기" },
    F: { sq: [3, 1], tri: [2, 1], house: [5, 1] },
    draw(s, g) {
      const n = s.n, u = Math.min(1.35, 14.6 / (n + 0.2)), x0 = 0.7, y0 = 2.2, st = (p, q, i) => g.seg(p, q, { color: i ? "a" : "b", w: 4 });
      for (let i = 0; i < n; i++) {
        const x = x0 + i * u, nw = i > 0;
        if (s.p === "sq") { if (!nw) st([x, y0], [x, y0 + u], 0); st([x, y0], [x + u, y0], nw); st([x, y0 + u], [x + u, y0 + u], nw); st([x + u, y0], [x + u, y0 + u], nw); }
        else if (s.p === "tri") {
          const ut = Math.min(1.7, 14.6 / ((n + 1) / 2 + 0.5)), Bp = (k) => [x0 + k * ut, y0], Tp = (k) => [x0 + ut / 2 + k * ut, y0 + ut * 0.87];
          const E = i % 2 === 0 ? [[Bp(i / 2), Tp(i / 2)], [Bp(i / 2), Bp(i / 2 + 1)], [Bp(i / 2 + 1), Tp(i / 2)]] : [[Tp((i - 1) / 2), Bp((i + 1) / 2)], [Tp((i - 1) / 2), Tp((i + 1) / 2)], [Tp((i + 1) / 2), Bp((i + 1) / 2)]];
          E.forEach((e, j) => { if (i && j === 0) return; st(e[0], e[1], nw); });
        }
        else { if (!nw) st([x, y0], [x, y0 + u], 0); st([x, y0], [x + u, y0], nw); st([x + u, y0], [x + u, y0 + u], nw); st([x, y0 + u], [x + u / 2, y0 + 1.6 * u], nw); st([x + u / 2, y0 + 1.6 * u], [x + u, y0 + u], nw); st([x, y0 + u], [x + u, y0 + u], nw); }
      }
      const [k, c] = this.F[s.p];
      g.text([0.7, 7.8], `n = ${n}일 때 ${k}n + ${c} = ${k} × ${n} + ${c} = ${k * n + c}개`, { anchor: "start", bold: true, size: 17 });
      g.text([0.7, 6.9], `파랑: 처음 ${c}개 · 주황: 하나 붙일 때마다 ${k}개`, { anchor: "start", size: 13, color: "muted" });
    },
    metrics(s) { const [k, c] = this.F[s.p]; return [["필요한 성냥개비", `${k * s.n + c}개`, "key"], ["문자식", `${k}n + ${c}`]]; },
    predict: [
      { q: "정사각형 10개를 이어 붙이려면 성냥개비가 몇 개 필요할까요?", set: (s) => Object.assign(s, { p: "sq", n: 3 }), reveal: (s) => (s.n = 10), answer: () => 31, why: "3n + 1에 n = 10을 넣으면 31개입니다." },
      { q: "삼각형 n개를 이은 무늬의 성냥개비 수를 나타내는 식은?", options: O("2n + 1", "3n", "3n − 1"), set: (s) => Object.assign(s, { p: "tri", n: 1 }), reveal: (s) => (s.n = 6), answer: () => "a", why: "처음 삼각형은 3개, 하나 더 붙일 때마다 2개씩 들어 2n + 1입니다." },
    ],
  },
  {
    id: "m1-balance", grade: G1, unit: 3, lesson: "3.2", title: "양팔 저울로 푸는 일차방정식", type: "조작", time: "12분",
    tags: ["일차방정식", "등식의 성질", "해"], links: ["m1-matchstick"],
    desc: "왼쪽 접시에는 x 상자 a개와 추 b개, 오른쪽에는 x 상자 c개와 추 d개를 올립니다. x의 값을 바꾸어 저울이 수평이 되는 값, 곧 방정식의 해를 찾고, 양쪽에서 똑같이 빼고 나누는 등식의 성질로 푸는 과정과 비교합니다.",
    obs: ["저울이 수평이면 양쪽의 무게가 같아 등식이 성립합니다.", "양쪽에서 같은 것을 빼거나 같은 수로 나누어도 수평은 유지됩니다.", "그래서 x만 한쪽에 남기면 해를 얻습니다."],
    q: "왼쪽 접시의 추를 오른쪽으로 '옮기는' 이항은 등식의 성질로 어떻게 설명할 수 있을까요?",
    formula: "ax + b = cx + d ⇒ (a − c)x = d − b ⇒ x = (d − b)/(a − c)",
    en: { title: "Solving Equations on a Balance", desc: "Find the x that levels the scale." },
    view: BOX,
    params: [
      { key: "a", label: "왼쪽 x 상자 a", min: 1, max: 5, step: 1, value: 3 },
      { key: "b", label: "왼쪽 추 b", min: 0, max: 9, step: 1, value: 2 },
      { key: "c", label: "오른쪽 x 상자 c", min: 0, max: 4, step: 1, value: 1 },
      { key: "d", label: "오른쪽 추 d", min: 0, max: 12, step: 1, value: 8 },
      { key: "x", label: "x의 값 (상자 하나의 무게)", min: 0, max: 8, step: 0.5, value: 1 },
    ],
    onChange(s) { if (s.c >= s.a) s.c = s.a - 1; },
    draw(s, g) {
      const L = s.a * s.x + s.b, R = s.c * s.x + s.d, tilt = clamp((L - R) * 0.06, -0.35, 0.35), P = [8, 4.2], arm = 5.4;
      const end = (sg) => [P[0] + sg * arm * Math.cos(tilt), P[1] + sg * arm * Math.sin(tilt)];
      g.poly([[7.2, 1], [8.8, 1], [8, 4.2]], { fill: "muted", fo: 0.3, color: "muted", w: 1.6 });
      g.seg(end(-1), end(1), { color: "ink", w: 4 });
      const pan = (q, nX, nW, col) => {
        g.seg(q, [q[0], q[1] - 0.9], { color: "muted", w: 1.2 });
        g.path([[q[0] - 2.2, q[1] - 0.9], [q[0] - 1.8, q[1] - 1.4], [q[0] + 1.8, q[1] - 1.4], [q[0] + 2.2, q[1] - 0.9]], { color: "ink", w: 2 });
        const items = [...Array(nX).fill("x"), ...Array(nW).fill("1")];
        items.forEach((t, i) => { const cx = q[0] - 1.6 + (i % 6) * 0.64, cy = q[1] - 0.9 + Math.floor(i / 6) * 0.62 + 0.3; if (t === "x") g.poly([[cx - 0.27, cy - 0.27], [cx + 0.27, cy - 0.27], [cx + 0.27, cy + 0.27], [cx - 0.27, cy + 0.27]], { fill: col, fo: 0.6, color: col, w: 1.2 }); else g.circle([cx, cy], 0.24, { fill: "muted", fo: 0.7, color: "ink", w: 1 }); g.text([cx, cy], t, { dy: 4, size: 10, bold: true }); });
      };
      pan(end(-1), s.a, s.b, "a"); pan(end(1), s.c, s.d, "b");
      g.text([8, 10.2], `${s.a === 1 ? "" : s.a}x${s.b ? ` + ${s.b}` : ""} = ${s.c ? `${s.c === 1 ? "" : s.c}x` : ""}${s.c && s.d ? " + " : ""}${s.d || (s.c ? "" : "0")}`, { bold: true, size: 20 });
      g.text([8, 9.1], Math.abs(L - R) < 1e-9 ? `수평! x = ${fmt(s.x)}이 해입니다` : L > R ? "왼쪽이 무거워요" : "오른쪽이 무거워요", { bold: true, color: Math.abs(L - R) < 1e-9 ? "c" : "e", size: 15 });
    },
    metrics(s) { const L = s.a * s.x + s.b, R = s.c * s.x + s.d, sol = (s.d - s.b) / (s.a - s.c); return [["왼쪽 무게", fmt(L, 2)], ["오른쪽 무게", fmt(R, 2)], ["등식의 성질로 풀면", `${s.a - s.c}x = ${s.d - s.b} → x = ${fmt(sol, 3)}`, "key"]]; },
    predict: [
      { q: "3x + 2 = x + 8의 해는?", set: (s) => Object.assign(s, { a: 3, b: 2, c: 1, d: 8, x: 1 }), reveal: (s) => (s.x = 3), answer: () => 3, why: "양쪽에서 x와 2를 빼면 2x = 6, 양쪽을 2로 나누면 x = 3입니다." },
      { q: "양쪽 접시에서 x 상자를 하나씩 내려도 저울의 수평은?", options: O("유지된다", "깨진다"), set: (s) => Object.assign(s, { a: 3, b: 2, c: 1, d: 8, x: 3 }), answer: () => "a", why: "양쪽에서 같은 무게를 빼므로 수평이 그대로입니다. 등식의 성질입니다." },
    ],
  },

  // ───────── 4단원 좌표평면과 그래프 ─────────
  {
    id: "m1-quadrant", grade: G1, unit: 4, lesson: "4.1", title: "좌표와 사분면 — 점을 옮기며 부호 읽기", type: "조작", time: "10분",
    tags: ["순서쌍", "좌표평면", "사분면"], links: ["m1-proportion"],
    desc: "점 P를 끌어 옮기며 좌표 (a, b)와 점이 놓인 사분면을 읽습니다. x축, y축, 원점에 대하여 대칭인 점의 좌표가 부호만 바뀐다는 것도 함께 확인합니다.",
    obs: ["제1사분면은 (+, +), 제2사분면은 (−, +), 제3사분면은 (−, −), 제4사분면은 (+, −)입니다.", "축 위의 점은 어느 사분면에도 속하지 않습니다.", "x축 대칭은 y좌표의 부호, y축 대칭은 x좌표의 부호, 원점 대칭은 두 부호를 모두 바꿉니다."],
    q: "점 (a, b)가 제2사분면 위에 있으면 점 (b, a)는 어느 사분면 위에 있을까요?",
    formula: "P(a, b) → x축 대칭 (a, −b), y축 대칭 (−a, b), 원점 대칭 (−a, −b)",
    en: { title: "Coordinates and Quadrants", desc: "Move a point and read the signs." },
    view: { x: [-6.5, 6.5], y: [-5, 5] },
    init: () => ({ P: [3, 2] }),
    params: [
      { key: "sx", label: "x축 대칭인 점", type: "check", value: false },
      { key: "sy", label: "y축 대칭인 점", type: "check", value: false },
      { key: "so", label: "원점 대칭인 점", type: "check", value: true },
    ],
    drags: { P: { at: (s) => s.P, move: (s, p) => (s.P = [clamp(Math.round(p[0]), -6, 6), clamp(Math.round(p[1]), -4, 4)]), label: "P" } },
    quad: ([x, y]) => (!x || !y ? "축 위 (사분면 아님)" : x > 0 ? (y > 0 ? "제1사분면" : "제4사분면") : y > 0 ? "제2사분면" : "제3사분면"),
    draw(s, g) {
      g.grid();
      [["제1사분면", 3.5, 4.3], ["제2사분면", -3.5, 4.3], ["제3사분면", -3.5, -4.3], ["제4사분면", 3.5, -4.3]].forEach(([t, x, y]) => g.text([x, y], t, { size: 13, color: "muted", bold: true }));
      const [a, b] = s.P, pc = (q) => `(${fmt(q[0])}, ${fmt(q[1])})`;
      g.seg([a, 0], s.P, { color: "a", w: 1.2, dash: "3 4" }).seg([0, b], s.P, { color: "a", w: 1.2, dash: "3 4" });
      if (s.sx) g.point([a, -b], `x축 대칭 ${pc([a, -b])}`, { color: "b" });
      if (s.sy) g.point([-a, b], `y축 대칭 ${pc([-a, b])}`, { color: "c" });
      if (s.so) { g.seg(s.P, [-a, -b], { color: "d", w: 1.2, dash: "5 5" }); g.point([-a, -b], `원점 대칭 ${pc([-a, -b])}`, { color: "d" }); }
      g.point(s.P, `P${pc(s.P)}`, { color: "a" });
    },
    metrics(s) { return [["P의 좌표", `(${fmt(s.P[0])}, ${fmt(s.P[1])})`], ["놓인 곳", this.quad(s.P), "key"], ["부호", `(${s.P[0] > 0 ? "+" : s.P[0] < 0 ? "−" : "0"}, ${s.P[1] > 0 ? "+" : s.P[1] < 0 ? "−" : "0"})`]]; },
    predict: [
      { q: "점 (2, −5)는 제몇 사분면 위의 점일까요?", options: O("제1사분면", "제2사분면", "제3사분면", "제4사분면"), set: (s) => (s.P = [-3, 2]), reveal: (s) => (s.P = [2, -4]), answer: () => "d", why: "x좌표는 양수, y좌표는 음수이므로 제4사분면입니다." },
      { q: "점 (−3, 2)와 원점에 대하여 대칭인 점의 x좌표는?", set: (s) => Object.assign(s, { P: [-3, 2], so: false }), reveal: (s) => (s.so = true), answer: () => 3, why: "원점 대칭은 두 좌표의 부호를 모두 바꾸므로 (3, −2)입니다." },
    ],
  },
  {
    id: "m1-proportion", grade: G1, unit: 4, lesson: "4.2", title: "정비례와 반비례의 그래프", type: "조작", time: "12분",
    tags: ["정비례", "반비례", "그래프"], links: ["m1-quadrant", "m1-tank-graph"],
    desc: "y = ax(정비례)와 y = a/x(반비례)의 표를 만들고 점을 찍어 그래프를 그립니다. a의 부호와 크기에 따라 그래프가 지나는 사분면과 기울어진 정도, 원점에서 멀어지는 모습이 어떻게 달라지는지 확인합니다.",
    obs: ["정비례 y = ax의 그래프는 원점을 지나는 직선입니다.", "반비례 y = a/x의 그래프는 두 좌표축에 한없이 가까워지는 한 쌍의 곡선입니다.", "a > 0이면 제1·3사분면, a < 0이면 제2·4사분면을 지납니다."],
    q: "반비례에서 x가 2배가 되면 y는 어떻게 될까요? 그래프의 점으로 확인해 봅시다.",
    formula: "정비례 y = ax (a ≠ 0) · 반비례 y = a/x (a ≠ 0)",
    en: { title: "Graphs of Direct and Inverse Proportion", desc: "y = ax and y = a/x." },
    view: { x: [-7, 7], y: [-6, 6] },
    params: [
      { key: "mode", label: "관계", type: "seg", value: "d", options: [["d", "정비례 y = ax"], ["i", "반비례 y = a/x"]] },
      { key: "a", label: "a", min: -6, max: 6, step: 0.5, value: 2 },
      { key: "x", label: "살펴볼 x", min: -6, max: 6, step: 1, value: 2 },
    ],
    onChange(s) { if (!s.a) s.a = 0.5; if (s.mode === "i" && !s.x) s.x = 1; },
    f(s, x) { return s.mode === "d" ? s.a * x : s.a / x; },
    draw(s, g) {
      g.grid();
      if (s.mode === "d") g.fx((x) => s.a * x, { color: "b", w: 3 }); else { g.fx((x) => s.a / x, { color: "b", w: 3, to: -0.05 }); g.fx((x) => s.a / x, { color: "b", w: 3, from: 0.05 }); }
      for (let x = -6; x <= 6; x++) { if (s.mode === "i" && !x) continue; const y = this.f(s, x); if (Math.abs(y) < 6) g.point([x, y], "", { color: "b", r: 3.5 }); }
      if (s.x || s.mode === "d") { const y = this.f(s, s.x); if (Math.abs(y) <= 6) { g.seg([s.x, 0], [s.x, y], { color: "a", w: 1.2, dash: "3 4" }).seg([0, y], [s.x, y], { color: "a", w: 1.2, dash: "3 4" }); g.point([s.x, y], `(${fmt(s.x)}, ${fmt(y, 2)})`, { color: "a" }); } }
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], s.mode === "d" ? `y = ${fmt(s.a)}x` : `y = ${fmt(s.a)}/x`, { anchor: "start", bold: true, color: "b", size: 16 });
    },
    metrics(s) { const xs = [1, 2, 3, 4, 6]; return [["표 (x → y)", xs.map((x) => `${x} → ${fmt(this.f(s, x), 2)}`).join(", ")], [`x = ${fmt(s.x)}일 때 y`, s.mode === "i" && !s.x ? "정의되지 않음" : fmt(this.f(s, s.x), 3), "key"], ["지나는 사분면", s.a > 0 ? "제1·3사분면" : "제2·4사분면"]]; },
    predict: [
      { q: "y = 3x에서 x = 4일 때 y는?", set: (s) => Object.assign(s, { mode: "d", a: 3, x: 1 }), reveal: (s) => (s.x = 4), answer: () => 12, why: "y = 3 × 4 = 12입니다." },
      { q: "y = 12/x에서 x = 3일 때 y는?", set: (s) => Object.assign(s, { mode: "i", a: 6, x: 3 }), reveal: (s) => (s.a = 6), answer: () => 4, why: "y = 12 ÷ 3 = 4입니다. xy = 12로 일정합니다." },
    ],
  },
  {
    id: "m1-tank-graph", grade: G1, unit: 4, lesson: "4.3", title: "물통 모양과 수위 그래프 — 그래프로 이야기 읽기", type: "조작", time: "12분",
    tags: ["그래프의 해석", "변화", "상황 그래프"], links: ["m1-proportion"],
    desc: "같은 빠르기로 물을 붓는 동안 물의 높이가 시간에 따라 어떻게 변하는지 그래프로 그립니다. 통이 좁은 곳에서는 높이가 빨리, 넓은 곳에서는 천천히 올라가 그래프의 기울어진 정도가 달라짐을 확인합니다.",
    obs: ["원기둥 통이면 높이가 일정하게 올라가 그래프가 곧은 직선입니다.", "통이 좁은 부분에서는 같은 양으로도 높이가 많이 올라가 그래프가 가파릅니다.", "통의 폭이 갑자기 바뀌면 그래프가 꺾입니다."],
    q: "그래프가 처음에는 완만하다가 점점 가팔라졌다면 어떤 모양의 통일까요?",
    formula: "같은 시간에 붓는 물의 양은 일정 → 높이의 변화는 통의 폭에 따라 다름",
    en: { title: "Water Level Graphs", desc: "How the vessel shape bends the graph." },
    view: BOX,
    params: [
      { key: "v", label: "물통", type: "select", value: "cone", options: Object.entries(TANK).map(([k, v]) => [k, v.n]) },
      { key: "t", label: "시간 (가득 찰 때까지의 비율)", min: 0, max: 1, step: 0.01, value: 0.5 },
    ],
    anim: { key: "t", min: 0, max: 1, speed: 0.2, label: "물 붓기" },
    draw(s, g) {
      const K = TANK[s.v], cx = 3, by = 1.2, H = 8, hw = 2.2, h = tankH(K, s.t);
      const L = [], R = []; for (let i = 0; i <= 50; i++) { const y = i / 50; L.push([cx - hw * K.w(y), by + y * H]); R.push([cx + hw * K.w(y), by + y * H]); }
      const WL = [], WR = []; for (let i = 0; i <= 50; i++) { const y = (h * i) / 50; WL.push([cx - hw * K.w(y), by + y * H]); WR.push([cx + hw * K.w(y), by + y * H]); }
      g.poly([...WL, ...WR.reverse()], { fill: "b", fo: 0.45, stroke: false });
      g.path(L, { color: "ink", w: 2.6 }).path(R, { color: "ink", w: 2.6 }).seg(L[0], R[0], { color: "ink", w: 2.6 });
      // 그래프
      const gx = 7.4, gy = 1.2, GW = 8, GH = 8;
      g.seg([gx, gy], [gx + GW + 0.2, gy], { color: "axis", w: 1.6 }).seg([gx, gy], [gx, gy + GH + 0.3], { color: "axis", w: 1.6 });
      g.text([gx + GW, gy], "시간", { dy: 18, size: 12, color: "muted" }).text([gx, gy + GH + 0.3], "높이", { dx: 6, anchor: "start", dy: 4, size: 12, color: "muted" });
      g.param((u) => [gx + u * GW, gy + tankH(K, u) * GH], 0, 1, { color: "muted", w: 1.4, dash: "5 5", n: 120 });
      g.param((u) => [gx + u * GW, gy + tankH(K, u) * GH], 0, s.t, { color: "a", w: 3.2, n: 120 });
      g.point([gx + s.t * GW, gy + h * GH], "", { color: "a" });
      g.seg([cx + hw * K.w(h), by + h * H], [gx, gy + h * GH], { color: "a", w: 1, dash: "3 4" });
    },
    metrics(s) { const K = TANK[s.v], h = tankH(K, s.t), d = (tankH(K, Math.min(1, s.t + 0.01)) - tankH(K, Math.max(0, s.t - 0.01))) / (Math.min(1, s.t + 0.01) - Math.max(0, s.t - 0.01)); return [["물의 높이 (가득 = 1)", fmt(h, 2)], ["지금 올라가는 빠르기", fmt(d, 2), "key"], ["지금 수면의 폭", fmt(K.w(h) * 2, 2)]]; },
    predict: [
      { q: "아래가 좁은 깔때기 통에 물을 부으면 높이 그래프는 어떤 모양일까요?", options: O("처음엔 가파르다가 점점 완만해진다", "처음엔 완만하다가 점점 가팔라진다", "곧은 직선이다"), set: (s) => Object.assign(s, { v: "cone", t: 0 }), reveal: (s) => (s.t = 1), answer: () => "a", why: "좁은 아래쪽은 적은 물로도 높이가 빨리 오르고, 넓은 위쪽에서는 천천히 오릅니다." },
      { q: "원기둥 통에서 시간이 절반 지났을 때 물의 높이는 가득 찬 높이의 몇 배일까요?", set: (s) => Object.assign(s, { v: "cyl", t: 0.2 }), reveal: (s) => (s.t = 0.5), answer: () => 0.5, tol: 0.01, why: "폭이 일정하므로 높이가 시간에 정비례합니다." },
    ],
  },
];
