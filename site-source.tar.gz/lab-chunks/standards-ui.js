// 성취기준 화면: 실험의 '설명' 탭에 붙는 성취기준 목록과, 과목별 성취기준 → 실험 찾기 화면(#/standards)
// 자료(standards.js)는 필요할 때만 불러온다.
let DATA = null;
export const load = () => (DATA ??= import("./standards.js"));
const esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
const isEN = () => document.documentElement.lang === "en";
const subjOf = (S, code) => Object.keys(S.SUBJ).sort((a, b) => b.length - a.length).find((p) => code.startsWith(p));

// 실험 하나의 성취기준 (설명 탭)
export async function fillLab(el, id) {
  if (!el) return;
  const S = await load(), raw = S.LAB[id];
  if (!raw || !el.isConnected) return;
  const en = isEN(), rel = raw[0][0] === "~", codes = raw.map((c) => c.replace("~", "")); // ~ = 특별관의 심화·연계
  el.innerHTML = `<h2>${rel ? (en ? "Related standards (enrichment)" : "심화·연계 성취기준") : en ? "Achievement standards" : "성취기준"} <small>${en ? "Korea, 2022 national curriculum" : "2022 개정 교육과정"}</small></h2><ul class="v3-std-list">${codes.map((c) => `<li><a href="#/standards?c=${encodeURIComponent(c)}" class="v3-std-code" translate="no">[${esc(c)}]</a> <span lang="ko" translate="no">${esc(S.STD[c])}</span></li>`).join("")}</ul><p class="v3-std-note">${rel ? (en ? "An enrichment topic connected to these standards — it goes beyond the textbook." : "교과서 범위를 넘는 심화 주제로, 이 성취기준과 이어서 다룰 수 있어요.") : en ? "Linked automatically by unit and keywords — please check before planning a lesson." : "단원과 낱말로 자동 연결했어요. 수업 계획에 쓰기 전에 한 번 확인해 주세요."}</p>`;
  el.hidden = false;
}

// 과목별 성취기준 → 실험 (#/standards?s=과목&c=코드)
export async function renderPage(el, labs, { match, query, onPack, onSheet } = {}) {
  const S = await load(), en = isEN();
  const byStd = {};
  const REL = new Set(); // 특별관 심화·연계로 이어진 (기준|실험)
  for (const [id, codes] of Object.entries(S.LAB)) for (const c0 of codes) { const c = c0.replace("~", ""); if (c0[0] === "~") REL.add(c + "|" + id); (byStd[c] ??= []).push(id); }
  const L = Object.fromEntries(labs.map((l) => [l.id, l])), ORD = Object.fromEntries(labs.map((l, i) => [l.id, i]));
  for (const c in byStd) byStd[c].sort((a, b) => REL.has(c + "|" + a) - REL.has(c + "|" + b) || (ORD[a] ?? 1e9) - (ORD[b] ?? 1e9)); // 교과 실험 먼저, 과정·단원 순서대로
  const code0 = query?.get("c") || "", subj0 = query?.get("s") || (code0 && subjOf(S, code0)) || "9수";
  const total = Object.keys(S.STD).length, linked = Object.keys(byStd).length;
  el.innerHTML = `<section class="at-page-head"><p class="at-eyebrow">${en ? `${total} standards · ${linked} linked to experiments` : `성취기준 ${total}개 · 실험과 연결된 것 ${linked}개`}</p><h1>${en ? "Find by achievement standard" : "성취기준으로 찾기"}</h1><p class="at-desc">${en ? "Achievement standards of the 2022 Korean national mathematics curriculum and the experiments for each one." : "2022 개정 수학과 교육과정의 성취기준마다 쓸 수 있는 실험을 모았어요. 번호나 낱말로 찾고, 실험 제목을 누르면 바로 열려요."}</p>
    <div class="std-tools"><div class="std-subj" role="group" aria-label="${en ? "Subject" : "과목"}">${Object.entries(S.SUBJ).filter(([p]) => Object.keys(S.STD).some((c) => c.startsWith(p))).map(([p, n]) => `<button type="button" data-std-s="${esc(p)}" aria-pressed="${p === subj0}">${esc(n)}</button>`).join("")}</div>
    <label class="at-search at-search-wide" for="std-search"><span aria-hidden="true">⌕</span><input id="std-search" placeholder="${en ? "Code or words, e.g. 9수03-15, 피타고라스" : "번호나 낱말로 찾기 — 예: 9수03-15, 피타고라스, ㅇㅊㅎㅅ"}" aria-label="${en ? "Search standards" : "성취기준 찾기"}"></label></div>
    </section><ol class="std-list" id="std-list"></ol>`;
  const list = el.querySelector("#std-list"), inp = el.querySelector("#std-search");
  let subj = subj0;
  const draw = () => {
    const w = inp.value.trim().replace(/[\[\]]/g, "");
    const codes = Object.keys(S.STD).filter((c) => (w ? true : subjOf(S, c) === subj) && (!w || c.startsWith(w) || (match ? match(w, S.STD[c] + " " + (byStd[c] || []).map((id) => L[id]?.title || "").join(" ")) : S.STD[c].includes(w))));
    list.innerHTML = codes.length ? codes.map((c) => { const ids = (byStd[c] || []).filter((id) => L[id]); return `<li class="std-item${c === code0 ? " on" : ""}" id="std-${esc(c)}"><p><b class="v3-std-code" translate="no">[${esc(c)}]</b> <span lang="ko" translate="no">${esc(S.STD[c])}</span></p>${ids.length ? `<ul class="std-labs">${ids.map((id) => `<li><a href="#/lab/${esc(id)}">${esc(L[id].title)}</a>${REL.has(c + "|" + id) ? ` <small class="std-rel">${en ? "enrichment" : "심화·연계"}</small>` : ""}</li>`).join("")}</ul><div class="std-acts">${onPack ? `<button type="button" class="btn" data-std-pack="${esc(c)}">${en ? "Lesson set QR" : "수업 꾸러미 QR"}${ids.length > 1 ? ` (${ids.length})` : ""}</button>` : ""}${onSheet ? `<button type="button" class="btn" data-std-sheet="${esc(c)}">${en ? "Add all to worksheet" : "학습지에 모두 담기"}</button>` : ""}</div>` : `<p class="std-none">${en ? "No experiment yet" : "아직 연결된 실험이 없어요"}</p>`}</li>`; }).join("") : `<li class="std-none">${en ? "No matching standard." : "맞는 성취기준이 없어요. 다른 낱말로 찾아보세요."}</li>`;
  };
  el.querySelector(".std-subj").onclick = (e) => { const b = e.target.closest("[data-std-s]"); if (!b) return; subj = b.dataset.stdS; inp.value = ""; el.querySelectorAll("[data-std-s]").forEach((x) => x.setAttribute("aria-pressed", String(x === b))); draw(); };
  inp.oninput = draw;
  list.onclick = (e) => {
    const b = e.target.closest("[data-std-pack],[data-std-sheet]"); if (!b) return;
    const c = b.dataset.stdPack || b.dataset.stdSheet, ids = (byStd[c] || []).filter((id) => L[id]);
    if (b.dataset.stdPack) onPack?.(ids, `[${c}] ${S.STD[c].replace(/(을|를|이|가)? ?(이해하고|알고|구하고|탐구하고).*$/, "").slice(0, 40)}`);
    else onSheet?.(ids, b);
  };
  draw();
  if (code0) document.getElementById("std-" + code0)?.scrollIntoView({ block: "center" });
}

// 찾기 창: 번호(9수03-15, [12대수01-04], 9수03)로 찾을 때 맞는 실험 id
export async function labsByCode(code) {
  const S = await load(), c = code.replace(/[\[\]\s]/g, "");
  return Object.entries(S.LAB).filter(([, codes]) => codes.some((x) => x.replace("~", "").startsWith(c))).map(([id]) => id);
}
