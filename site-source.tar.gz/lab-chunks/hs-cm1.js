// 공통수학1 — Ⅰ 다항식 · Ⅲ 이차방정식과 이차함수 · Ⅳ 여러 가지 방정식과 부등식 (10차 이후 추가)
import { fmt, frac, poly, clamp } from "./hs-core.js";

const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a; };
// √n = k√m (n은 0 이상의 정수)
function surdParts(n) { let k = 1, m = Math.round(n); for (let f = 2; f * f <= m; f++) while (m % (f * f) === 0) { m /= f * f; k *= f; } return [k, m]; }
// 다항식 계수(높은 차수부터) → 문자열
function polyStr(cs, v = "x") {
  const n = cs.length - 1, terms = cs.map((c, i) => [c, n - i === 0 ? "" : n - i === 1 ? v : `${v}${"⁰¹²³⁴⁵⁶"[n - i]}`]);
  const t = terms.filter(([c, s]) => s);
  return poly(t, cs[n]);
}
// ax² + bx + c = 0의 두 근 (2a, b, D가 정수일 때 정확한 꼴) — [작은 근, 큰 근] 문자열과 값
function quadRoots(a, b, c) {
  const D = b * b - 4 * a * c, Dr = Math.round(D);
  let den = Math.round(2 * a), nb = Math.round(-b);
  if (den < 0) { den = -den; nb = -nb; }
  const exact = Math.abs(D - Dr) < 1e-9 && Math.abs(2 * a - Math.round(2 * a)) < 1e-9 && Math.abs(b - Math.round(b)) < 1e-9;
  const val = (sg) => (-b + sg * Math.sqrt(Math.max(0, D))) / (2 * a);
  const lo = Math.min(val(1), val(-1)), hi = Math.max(val(1), val(-1));
  if (!exact) return { D, lo, hi, los: fmt(lo, 3), his: fmt(hi, 3), pm: `${fmt(lo, 3)}, ${fmt(hi, 3)}` };
  const [k0, m] = surdParts(Math.abs(Dr));
  if (m === 1 && Dr >= 0) return { D, lo, hi, los: frac(lo), his: frac(hi), pm: Dr === 0 ? frac(lo) : `${frac(lo)}, ${frac(hi)}` };
  const g = gcd(gcd(nb, k0), den), N = nb / g, k = k0 / g, d = den / g, im = Dr < 0;
  const rad = (m === 1 ? (k === 1 ? "" : String(k)) : `${k === 1 ? "" : k}√${m}`) + (im ? "i" : "");
  const one = (sg) => { const core = N === 0 ? `${sg}${rad}` : `${fmt(N)} ${sg} ${rad}`; return d === 1 ? core : N === 0 ? `${core}/${d}` : `(${core})/${d}`; };
  return { D, lo, hi, los: one("−"), his: one("+"), pm: one("±") };
}
const opTxt = (o) => ({ ">": ">", ">=": "≥", "<": "<", "<=": "≤" })[o];

export default [
  // ───────── Ⅰ 다항식 ─────────
  {
    id: "cm1-poly-area", grade: 14, unit: 1, lesson: "Ⅰ-2", title: "다항식의 곱셈 — 넓이 모형으로 전개하기", type: "조작", time: "10분",
    tags: ["다항식의 곱셈", "전개", "넓이 모형"], links: ["cm1-remainder"],
    desc: "가로가 ax + b, 세로가 cx + d인 직사각형을 x² 타일, x 타일, 1 타일로 나누어 (ax + b)(cx + d)의 전개식이 넓이의 합과 같음을 확인합니다.",
    obs: ["x² 타일은 ac개, x 타일은 ad + bc개, 1 타일은 bd개입니다.", "같은 종류의 타일을 모으는 것이 동류항끼리 정리하는 것입니다.", "x의 값을 바꿔도 직사각형 넓이와 전개식의 값은 항상 같습니다."],
    q: "(x + 2)²의 넓이 모형에서 x 타일은 몇 개일까요? 그 까닭은 무엇일까요?",
    formula: "(ax + b)(cx + d) = acx² + (ad + bc)x + bd",
    en: { title: "Multiplying Polynomials with an Area Model", desc: "Split an (ax + b) by (cx + d) rectangle into x², x and 1 tiles." },
    view: BOX,
    params: [
      { key: "a", label: "가로의 x 개수 a", min: 1, max: 3, step: 1, value: 2 }, { key: "b", label: "가로의 1 개수 b", min: 0, max: 4, step: 1, value: 1 },
      { key: "c", label: "세로의 x 개수 c", min: 1, max: 3, step: 1, value: 1 }, { key: "d", label: "세로의 1 개수 d", min: 0, max: 4, step: 1, value: 3 },
      { key: "x", label: "x의 길이", min: 1.5, max: 4, step: 0.1, value: 2.5 },
    ],
    anim: { key: "x", min: 1.5, max: 4, speed: 0.8, label: "x 늘이고 줄이기" },
    draw(s, g) {
      const { a, b, c, d, x } = s, Wd = a * x + b, Hd = c * x + d, k = Math.min(12.4 / Wd, 8.4 / Hd);
      const L = 2.4, T = 9.6, cols = [...Array(a).fill(x), ...Array(b).fill(1)], rows = [...Array(c).fill(x), ...Array(d).fill(1)];
      let yy = T;
      rows.forEach((h, ri) => {
        let xx = L;
        cols.forEach((w, ci) => {
          const big = w > 1 && h > 1, one = w === 1 && h === 1, fill = big ? "a" : one ? "e" : w > 1 ? "b" : "c";
          const P = [[xx, yy], [xx + w * k, yy], [xx + w * k, yy - h * k], [xx, yy - h * k]];
          g.poly(P, { fill, fo: big ? 0.28 : 0.42, color: fill, w: 1.4 });
          const px = Math.min(w, h) * k * g.s;
          if (px > 22) g.text([xx + (w * k) / 2, yy - (h * k) / 2], big ? "x²" : one ? "1" : "x", { dy: 5, bold: true, size: px > 40 ? 15 : 12, color: fill });
          xx += w * k;
        });
        yy -= h * k;
      });
      g.poly([[L, T], [L + Wd * k, T], [L + Wd * k, T - Hd * k], [L, T - Hd * k]], { color: "ink", w: 2.6 });
      let xx = L; cols.forEach((w) => { g.text([xx + (w * k) / 2, T], w > 1 ? "x" : "1", { dy: -8, bold: true, size: 13, color: w > 1 ? "a" : "muted" }); xx += w * k; });
      let yy2 = T; rows.forEach((h) => { g.text([L, yy2 - (h * k) / 2], h > 1 ? "x" : "1", { dx: -12, dy: 5, bold: true, size: 13, color: h > 1 ? "a" : "muted" }); yy2 -= h * k; });
      g.text([L + (Wd * k) / 2, T + 0.75], `가로 ${poly([[a, "x"]], b)}`, { bold: true, size: 14 });
      g.text([L + Wd * k + 0.3, T - (Hd * k) / 2], `세로 ${poly([[c, "x"]], d)}`, { anchor: "start", bold: true, size: 14 });
    },
    metrics(s) {
      const { a, b, c, d, x } = s, A2 = a * c, A1 = a * d + b * c, A0 = b * d, area = (a * x + b) * (c * x + d);
      return [
        ["타일 수", `x² 타일 ${A2}개, x 타일 ${A1}개, 1 타일 ${A0}개`],
        ["전개", `(${poly([[a, "x"]], b)})(${poly([[c, "x"]], d)}) = ${polyStr([A2, A1, A0])}`, "key"],
        [`x = ${fmt(x)}일 때 넓이`, `${fmt(a * x + b)} × ${fmt(c * x + d)} = ${fmt(area, 3)}`],
        ["전개식에 대입", `${fmt(A2 * x * x, 3)} + ${fmt(A1 * x, 3)} + ${A0} = ${fmt(A2 * x * x + A1 * x + A0, 3)}`],
      ];
    },
  },
  {
    id: "cm1-remainder", grade: 14, unit: 1, lesson: "Ⅰ-3", title: "나머지정리 — 나머지는 그래프의 높이", type: "2D", time: "12분",
    tags: ["나머지정리", "인수정리", "조립제법"], links: ["cm1-poly-area", "cm1-discriminant"],
    desc: "다항식 P(x)를 x − a로 나눈 나머지가 P(a), 곧 그래프 위의 점 (a, P(a))의 높이임을 조립제법과 그래프로 함께 확인합니다. 나머지가 0이면 x − a가 인수입니다.",
    obs: ["P(x) = (x − a)Q(x) + R에 x = a를 넣으면 R = P(a)입니다.", "그래프가 x축과 만나는 점에서는 나머지가 0이므로 x − a가 P(x)의 인수입니다.", "조립제법의 마지막 칸이 나머지, 나머지 칸이 몫의 계수입니다."],
    q: "P(x)를 x − 2로 나눈 나머지가 0이면, 그래프는 어떤 점을 지날까요?",
    formula: "P(x) = (x − a)Q(x) + R ⇒ R = P(a)",
    en: { title: "Remainder Theorem as a Height", desc: "The remainder of P(x) divided by x − a equals P(a), the height of the graph." },
    view: (s) => (s.fn === "q2" ? { x: [-4.5, 4.5], y: [-3.5, 7.5] } : { x: [-4.5, 4.5], y: [-7, 7] }),
    params: [
      { key: "fn", label: "다항식 P(x)", type: "select", value: "c1", options: [["c1", "x³ − 4x"], ["c2", "x³ − 2x² − x + 2"], ["c3", "x³ − 3x + 2"], ["q2", "x² − x − 2"]] },
      { key: "a", label: "나누는 식 x − a의 a", min: -2.5, max: 3, step: 0.5, value: 1 },
    ],
    anim: { key: "a", min: -2.5, max: 3, speed: 1, loop: "bounce", label: "a 움직이기" },
    CS: { c1: [1, 0, -4, 0], c2: [1, -2, -1, 2], c3: [1, 0, -3, 2], q2: [1, -1, -2] },
    P(cs, x) { return cs.reduce((v, c) => v * x + c, 0); },
    syn(cs, a) { const q = [cs[0]]; for (let i = 1; i < cs.length; i++) q.push(cs[i] + q[i - 1] * a); return q; },
    drags: { A: { at: (s) => [s.a, 0], move: (s, p) => (s.a = Math.round(p[0] * 2) / 2), color: "a", label: "a" } },
    draw(s, g) {
      const cs = this.CS[s.fn], f = (x) => this.P(cs, x), R = f(s.a);
      g.grid();
      g.fx(f, { color: "b", w: 3.2 });
      for (let x = -4; x <= 4; x += 0.5) if (Math.abs(f(x)) < 1e-9) g.point([x, 0], "", { color: "c", r: 5, hollow: true });
      const top = clamp(R, g.yr[0] + 0.3, g.yr[1] - 0.3);
      g.seg([s.a, 0], [s.a, top], { color: Math.abs(R) < 1e-9 ? "c" : "a", w: 4 });
      if (Math.abs(R) > 1e-9 && R === top) g.point([s.a, R], "", { color: "a", r: 6 });
      g.text([s.a, top / 2], Math.abs(R) < 1e-9 ? "" : `R = ${fmt(R)}`, { dx: s.a > 2 ? -12 : 12, anchor: s.a > 2 ? "end" : "start", bold: true, color: "a" });
      if (Math.abs(R) < 1e-9) g.text([s.a, 0], "나머지 0 → 인수!", { dy: -16, bold: true, color: "c" });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], `y = ${polyStr(cs)}`, { anchor: "start", bold: true, color: "b" });
    },
    metrics(s) {
      const cs = this.CS[s.fn], q = this.syn(cs, s.a), R = q.pop();
      return [
        ["나눗셈의 결과", `${polyStr(cs)} = (${s.a ? `x ${s.a > 0 ? "−" : "+"} ${frac(Math.abs(s.a))}` : "x"})(${polyStr(q.map((c) => Math.round(c * 1e9) / 1e9))})${Math.abs(R) < 1e-9 ? "" : ` ${R > 0 ? "+" : "−"} ${frac(Math.abs(R))}`}`],
        ["몫 Q(x)", polyStr(q.map((c) => Math.round(c * 1e9) / 1e9))],
        [`P(${frac(s.a)})`, frac(this.P(cs, s.a))],
        ["나머지 R", Math.abs(R) < 1e-9 ? `0 → x − ${frac(s.a)}는 인수` : frac(R), "key"],
      ];
    },
  },
  // ───────── Ⅲ 이차방정식과 이차함수 ─────────
  {
    id: "cm1-discriminant", grade: 14, unit: 3, lesson: "Ⅲ-1", title: "판별식과 x축의 교점", type: "조작", time: "10분",
    tags: ["판별식", "이차방정식", "허근"], links: ["cm1-quad-line", "cm1-quad-ineq"],
    desc: "y = ax² + bx + c의 계수를 바꾸며 판별식 D = b² − 4ac의 부호와 그래프가 x축과 만나는 점의 개수, 이차방정식의 근의 종류를 연결합니다.",
    obs: ["D > 0이면 그래프가 x축과 두 점에서 만나고 서로 다른 두 실근을 가집니다.", "D = 0이면 x축에 접하고 중근을 가집니다.", "D < 0이면 x축과 만나지 않고 서로 다른 두 허근을 가집니다."],
    q: "c만 바꾸어 D = 0이 되게 하면 그래프는 위아래로 어떻게 움직였을까요?",
    formula: "D = b² − 4ac · x = (−b ± √D)/2a",
    en: { title: "Discriminant and x-intercepts", desc: "Relate the sign of b² − 4ac to the number of x-intercepts." },
    view: { x: [-6, 6], y: [-5, 6] },
    params: [
      { key: "a", label: "a", min: -2, max: 2, step: 0.5, value: 1 },
      { key: "b", label: "b", min: -6, max: 6, step: 1, value: -2 },
      { key: "c", label: "c", min: -5, max: 5, step: 1, value: -3 },
    ],
    anim: { key: "c", min: -5, max: 5, speed: 2, loop: "bounce", label: "c 바꾸기" },
    derive(s) { if (Math.abs(s.a) < 1e-9) s.a = 0.5; },
    draw(s, g) {
      const { a, b, c } = s, f = (x) => a * x * x + b * x + c, r = quadRoots(a, b, c), D = r.D, vx = -b / (2 * a);
      g.grid();
      g.fx(f, { color: D > 1e-9 ? "c" : Math.abs(D) < 1e-9 ? "e" : "d", w: 3.2 });
      g.point([vx, f(vx)], "꼭짓점", { color: "muted", r: 4, dy: a > 0 ? 22 : -12 });
      if (D > 1e-9) { g.point([r.lo, 0], "", { color: "c", r: 6 }).point([r.hi, 0], "", { color: "c", r: 6 }); g.seg([r.lo, 0], [r.hi, 0], { color: "c", w: 5, opacity: 0.4 }); }
      else if (Math.abs(D) < 1e-9) g.point([vx, 0], "접점", { color: "e", r: 6, dy: a > 0 ? 22 : -12 });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], `y = ${polyStr([a, b, c])}`, { anchor: "start", bold: true, color: "ink" });
    },
    metrics(s) {
      const { a, b, c } = s, r = quadRoots(a, b, c), D = r.D;
      const kind = D > 1e-9 ? "서로 다른 두 실근" : Math.abs(D) < 1e-9 ? "중근 (실근 1개)" : "서로 다른 두 허근";
      return [
        ["D = b² − 4ac", `${b < 0 ? `(${fmt(b)})` : fmt(b)}² − 4·(${fmt(a)})·(${fmt(c)}) = ${fmt(D)}`, "key"],
        ["근의 종류", kind],
        ["x축과 만나는 점", D > 1e-9 ? "2개" : Math.abs(D) < 1e-9 ? "1개 (접한다)" : "0개"],
        ["근", `x = ${r.pm}`],
      ];
    },
  },
  {
    id: "cm1-quad-line", grade: 14, unit: 3, lesson: "Ⅲ-1", title: "이차함수의 그래프와 직선의 위치 관계", type: "조작", time: "12분",
    tags: ["위치 관계", "판별식", "접선"], links: ["cm1-discriminant", "geo-slope-tangent"],
    desc: "포물선 y = x² − 2x − 1과 직선 y = mx + k를 함께 그리고, 두 식을 연립한 이차방정식의 판별식으로 만나는 점의 개수(2개·접함·0개)를 판단합니다.",
    obs: ["x² − 2x − 1 = mx + k를 정리한 x² − (m + 2)x − (k + 1) = 0의 실근이 교점의 x좌표입니다.", "D > 0이면 두 점, D = 0이면 접하고, D < 0이면 만나지 않습니다.", "기울기 m을 정하면 접하게 하는 k는 하나뿐입니다."],
    q: "기울기가 2인 직선 가운데 포물선에 접하는 직선의 y절편은 얼마일까요?",
    formula: "x² − (m + 2)x − (k + 1) = 0 · D = (m + 2)² + 4(k + 1)",
    en: { title: "Parabola and Line", desc: "Use the discriminant to decide whether a line cuts, touches or misses a parabola." },
    view: { x: [-5, 7], y: [-4, 7] },
    params: [
      { key: "m", label: "직선의 기울기 m", min: -4, max: 4, step: 0.5, value: 1 },
      { key: "k", label: "직선의 y절편 k", min: -6, max: 5, step: 0.25, value: -2 },
    ],
    anim: { key: "k", min: -6, max: 5, speed: 2, loop: "bounce", label: "직선 위아래로" },
    drags: { K: { at: (s) => [0, s.k], move: (s, p) => (s.k = Math.round(p[1] * 4) / 4), color: "a", label: "y절편" } },
    draw(s, g) {
      const f = (x) => x * x - 2 * x - 1, l = (x) => s.m * x + s.k, B = -(s.m + 2), Cq = -(s.k + 1), D = B * B - 4 * Cq;
      g.grid();
      g.fx(f, { color: "b", w: 3.2 }).fx(l, { color: "a", w: 2.8 });
      if (D > 1e-9) { [(-B - Math.sqrt(D)) / 2, (-B + Math.sqrt(D)) / 2].forEach((x) => g.point([x, f(x)], "", { color: "c", r: 6 })); }
      else if (Math.abs(D) < 1e-9) { const x = -B / 2; g.point([x, f(x)], "접점", { color: "e", r: 6 }); }
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], "y = x² − 2x − 1", { anchor: "start", bold: true, color: "b" });
      g.text([g.xr[0] + 0.3, g.yr[1] - 1.4], `y = ${poly([[s.m, "x"]], s.k)}`, { anchor: "start", bold: true, color: "a" });
    },
    metrics(s) {
      const B = -(s.m + 2), Cq = -(s.k + 1), D = B * B - 4 * Cq, kt = -1 - (s.m + 2) ** 2 / 4;
      return [
        ["연립한 이차방정식", `${polyStr([1, B, Cq])} = 0`],
        ["D", `(${fmt(B)})² − 4·(${fmt(Cq)}) = ${fmt(D, 3)}`],
        ["위치 관계", D > 1e-9 ? "두 점에서 만난다" : Math.abs(D) < 1e-9 ? "접한다" : "만나지 않는다", "key"],
        [`기울기 ${fmt(s.m)}일 때 접하는 k`, fmt(kt, 4)],
      ];
    },
  },
  {
    id: "cm1-minmax-interval", grade: 14, unit: 3, lesson: "Ⅲ-2", title: "제한된 범위에서 이차함수의 최대·최소", type: "조작", time: "12분",
    tags: ["최댓값", "최솟값", "꼭짓점"], links: ["cm1-discriminant", "calc-derivative-graph"],
    desc: "x의 범위 α ≤ x ≤ β를 움직이며, 꼭짓점이 범위 안에 있는지 밖에 있는지에 따라 최댓값과 최솟값이 어디에서 생기는지 확인합니다.",
    obs: ["꼭짓점이 범위 안에 있으면 꼭짓점에서 최솟값(아래로 볼록) 또는 최댓값(위로 볼록)을 가집니다.", "나머지 하나는 범위의 양 끝 중 꼭짓점에서 더 먼 쪽에서 생깁니다.", "꼭짓점이 범위 밖에 있으면 최댓값·최솟값 모두 양 끝에서 생깁니다."],
    q: "범위의 양 끝이 꼭짓점에서 같은 거리에 있으면 어느 끝에서 최댓값을 가질까요?",
    formula: "y = a(x − p)² + q (α ≤ x ≤ β) · 비교할 값: f(α), f(β), f(p)",
    en: { title: "Max and Min on an Interval", desc: "Find the extreme values of a quadratic on a closed interval." },
    view: { x: [-5.5, 5.5], y: [-4.5, 6.5] },
    params: [
      { key: "dir", label: "볼록한 방향", type: "seg", value: "up", options: [["up", "아래로 볼록"], ["down", "위로 볼록"]] },
      { key: "p", label: "꼭짓점의 x좌표 p", min: -3, max: 3, step: 0.5, value: 1 },
      { key: "q", label: "꼭짓점의 y좌표 q", min: -3, max: 4, step: 0.5, value: -2 },
      { key: "al", label: "범위의 왼쪽 끝 α", min: -5, max: 4.5, step: 0.5, value: -1 },
      { key: "be", label: "범위의 오른쪽 끝 β", min: -4.5, max: 5, step: 0.5, value: 2 },
    ],
    anim: { key: "p", min: -3, max: 3, speed: 1.2, loop: "bounce", label: "꼭짓점 옮기기" },
    derive(s) { if (s.be <= s.al) { if (s.al >= 4.5) s.al = s.be - 0.5; else s.be = s.al + 0.5; } },
    A: (s) => (s.dir === "up" ? 0.5 : -0.5),
    f(s, x) { return this.A(s) * (x - s.p) ** 2 + s.q; },
    ext(s) {
      const c = [[s.al, this.f(s, s.al)], [s.be, this.f(s, s.be)]];
      if (s.p >= s.al && s.p <= s.be) c.push([s.p, s.q]);
      const mx = c.reduce((m, v) => (v[1] > m[1] + 1e-9 ? v : m)), mn = c.reduce((m, v) => (v[1] < m[1] - 1e-9 ? v : m));
      return { mx, mn, inside: s.p >= s.al && s.p <= s.be };
    },
    drags: { L: { at: (s) => [s.al, 0], move: (s, p) => (s.al = clamp(Math.round(p[0] * 2) / 2, -5, s.be - 0.5)), color: "a", label: "α" }, R: { at: (s) => [s.be, 0], move: (s, p) => (s.be = clamp(Math.round(p[0] * 2) / 2, s.al + 0.5, 5)), color: "a", label: "β" } },
    draw(s, g) {
      const f = (x) => this.f(s, x), { mx, mn } = this.ext(s);
      g.grid();
      g.region(f, () => 0, s.al, s.be, { fill: "f", fo: 0.12 });
      g.fx(f, { color: "muted", w: 1.6, dash: "6 5" }).fx(f, { from: s.al, to: s.be, color: "b", w: 4 });
      g.seg([s.al, 0], [s.al, f(s.al)], { color: "muted", w: 1.2, dash: "3 4" }).seg([s.be, 0], [s.be, f(s.be)], { color: "muted", w: 1.2, dash: "3 4" });
      g.point([s.p, s.q], "꼭짓점", { color: "muted", r: 4, hollow: true, dy: s.dir === "up" ? 22 : -12, lcolor: "muted" });
      g.point(mx, `최대 ${fmt(mx[1])}`, { color: "d", r: 6.5, dy: -12 });
      g.point(mn, `최소 ${fmt(mn[1])}`, { color: "c", r: 6.5, dy: 24, dx: 14 });
      g.text([s.al, 0], "α", { dy: 34, bold: true, color: "a" }).text([s.be, 0], "β", { dy: 34, bold: true, color: "a" });
    },
    metrics(s) {
      const a = this.A(s), { mx, mn, inside } = this.ext(s), fs = `y = ${a > 0 ? "" : "−"}½${s.p ? `(x ${s.p > 0 ? "−" : "+"} ${fmt(Math.abs(s.p))})²` : "x²"}${s.q ? ` ${s.q > 0 ? "+" : "−"} ${fmt(Math.abs(s.q))}` : ""}`;
      return [
        ["함수와 범위", `${fs} (${fmt(s.al)} ≤ x ≤ ${fmt(s.be)})`],
        ["꼭짓점의 위치", inside ? "범위 안" : "범위 밖"],
        ["최댓값", `x = ${fmt(mx[0])}일 때 ${fmt(mx[1], 3)}`, "key"],
        ["최솟값", `x = ${fmt(mn[0])}일 때 ${fmt(mn[1], 3)}`, "key"],
      ];
    },
  },
  // ───────── Ⅳ 여러 가지 방정식과 부등식 ─────────
  {
    id: "cm1-quad-ineq", grade: 14, unit: 4, lesson: "Ⅳ-5", title: "이차부등식의 해 — 그래프에서 읽기", type: "조작", time: "12분",
    tags: ["이차부등식", "판별식", "해의 범위"], links: ["cm1-discriminant", "cm1-quad-line"],
    desc: "y = ax² + bx + c의 그래프에서 x축보다 위(또는 아래)에 있는 부분의 x의 범위가 이차부등식의 해임을 확인합니다. 판별식이 0이거나 음수일 때의 특별한 해도 살펴봅니다.",
    obs: ["ax² + bx + c > 0의 해는 그래프가 x축보다 위쪽에 있는 x의 범위입니다.", "등호가 있으면 x축과 만나는 점(근)도 해에 들어갑니다.", "D < 0이고 a > 0이면 그래프가 항상 x축 위에 있어 '> 0'의 해는 모든 실수입니다."],
    q: "x² − 2x + 1 ≤ 0의 해는 무엇일까요?",
    formula: "a > 0, α < β일 때 a(x − α)(x − β) > 0 ⇔ x < α 또는 x > β",
    en: { title: "Solving Quadratic Inequalities by Graph", desc: "Read the solution of a quadratic inequality from where the graph lies above or below the x-axis." },
    view: { x: [-6, 6], y: [-5, 6] },
    params: [
      { key: "op", label: "부등호", type: "seg", value: ">", options: [[">", "> 0"], [">=", "≥ 0"], ["<", "< 0"], ["<=", "≤ 0"]] },
      { key: "a", label: "x²의 계수 a", type: "seg", value: "1", options: [["1", "1"], ["-1", "−1"]] },
      { key: "b", label: "b", min: -6, max: 6, step: 1, value: -1 },
      { key: "c", label: "c", min: -6, max: 6, step: 1, value: -6 },
    ],
    anim: { key: "c", min: -6, max: 6, speed: 2, loop: "bounce", label: "c 바꾸기" },
    sol(s) {
      const a = +s.a, { b, c } = s, r = quadRoots(a, b, c), D = r.D, gt = s.op[0] === ">", eq = s.op.length === 2, up = (a > 0) === gt;
      // up: 양 끝 쪽이 해 (그래프가 원하는 쪽으로 열림)
      if (D > 1e-9) return { r, txt: up ? `x ${eq ? "≤" : "<"} ${r.los} 또는 x ${eq ? "≥" : ">"} ${r.his}` : `${r.los} ${eq ? "≤" : "<"} x ${eq ? "≤" : "<"} ${r.his}`, set: up ? [[-Infinity, r.lo], [r.hi, Infinity]] : [[r.lo, r.hi]], ends: [r.lo, r.hi], eq };
      if (Math.abs(D) < 1e-9) return { r, txt: up ? (eq ? "모든 실수" : `x ≠ ${r.los}인 모든 실수`) : eq ? `x = ${r.los}` : "해가 없다", set: up ? [[-Infinity, Infinity]] : eq ? [[r.lo, r.lo]] : [], ends: [r.lo], eq, hole: up && !eq };
      return { r, txt: up ? "모든 실수" : "해가 없다", set: up ? [[-Infinity, Infinity]] : [], ends: [], eq };
    },
    draw(s, g) {
      const a = +s.a, f = (x) => a * x * x + s.b * x + s.c, S = this.sol(s), gt = s.op[0] === ">";
      g.grid();
      g.region((x) => (gt ? Math.max(f(x), 0) : 0), (x) => (gt ? 0 : Math.min(f(x), 0)), g.xr[0], g.xr[1], { fill: "c", fo: 0.1, n: 240 });
      g.fx(f, { color: "b", w: 3.2 });
      S.set.forEach(([u, v]) => { const L = Math.max(u, g.xr[0] - 1), R = Math.min(v, g.xr[1] + 1); if (R - L > 1e-9) g.seg([L, 0], [R, 0], { color: "c", w: 7, opacity: 0.85 }); else g.point([L, 0], "", { color: "c", r: 6.5 }); });
      S.ends.forEach((x) => g.point([x, 0], "", { color: "c", r: 6.5, hollow: !S.eq || S.hole }));
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], `${polyStr([a, s.b, s.c])} ${opTxt(s.op)} 0`, { anchor: "start", bold: true, color: "ink" });
    },
    metrics(s) {
      const a = +s.a, S = this.sol(s), D = S.r.D;
      return [
        ["판별식 D", fmt(D)],
        ["방정식의 근", D > 1e-9 ? `x = ${S.r.los}, ${S.r.his}` : Math.abs(D) < 1e-9 ? `x = ${S.r.los} (중근)` : "실근 없음"],
        ["부등식의 해", S.txt, "key"],
        "색칠한 x축 위 굵은 선이 해, 속이 빈 점은 해에 포함되지 않는 수입니다.",
      ];
    },
  },
];
