// 이항정리 통합 실험 — 부피 모형 · 파스칼의 삼각형 · 갈톤 보드 사고실험 · 예측하고 확인하기
import { fmt, frac, clamp } from "./hs-core.js";

const FACT = (n) => (n <= 1 ? 1 : n * FACT(n - 1));
const C = (n, k) => (k < 0 || k > n ? 0 : Math.round(FACT(n) / (FACT(k) * FACT(n - k))));
const SUPS = "⁰¹²³⁴⁵⁶⁷⁸⁹";
const sup = (e) => (e <= 1 ? "" : String(e).split("").map((d) => SUPS[d]).join(""));
const mono = (ex, L = ["a", "b", "c"]) => ex.map((e, i) => (e ? L[i] + sup(e) : "")).join("") || "1";
const SUBS = "₀₁₂₃₄₅₆₇₈₉";
const sub = (n) => String(n).split("").map((d) => SUBS[d]).join("");
const nCk = (n, k) => `${sub(n)}C${sub(k)}`;
const LETTER_COLS = ["a", "c", "e", "b", "d"];
const TERM_COLS = ["a", "c", "e", "b", "d", "f"];
const EXPRS = { "2_1": [2, 1], "2_2": [2, 2], "2_3": [2, 3], "2_4": [2, 4], "3_2": [3, 2], "3_3": [3, 3] };
// (a + b + c)ⁿ의 항 목록 [i, j, k] — a의 차수가 큰 것부터
function terms(m, n) {
  const out = [];
  if (m === 2) { for (let k = 0; k <= n; k++) out.push([n - k, k]); return out; }
  for (let i = n; i >= 0; i--) for (let j = n - i; j >= 0; j--) out.push([i, j, n - i - j]);
  return out;
}
const coef = (ex) => FACT(ex.reduce((a, b) => a + b, 0)) / ex.reduce((p, e) => p * FACT(e), 1);
const expansion = (m, n) => terms(m, n).map((ex) => { const c = coef(ex); return (c > 1 ? c : "") + mono(ex); }).join(" + ");
// 갈톤: 칸 k로 가는 idx번째 길 (오른쪽으로 가는 줄 번호 조합, 사전순)
function kthComb(n, k, idx) {
  const out = []; let start = 0, r = idx;
  for (let left = k; left > 0; left--) { for (let x = start; x < n; x++) { const c = C(n - x - 1, left - 1); if (r < c) { out.push(x); start = x + 1; break; } r -= c; } }
  return out;
}
const fib = (n) => { let a = 1, b = 1; for (let i = 2; i <= n; i++) [a, b] = [b, a + b]; return n < 1 ? 1 : a; };

export default [
  {
    id: "pst-binomial-lab", grade: 8, unit: 1, lesson: "Ⅰ-4 탐구 & 융합", title: "이항정리 실험실 — 부피 모형 · 파스칼의 삼각형 · 갈톤 보드", type: "조작", time: "25분",
    tags: ["이항정리", "파스칼의 삼각형", "갈톤 보드"], links: ["pst-binomial-cube", "pst-binomial-area", "pst-pascal", "lab-galton", "pst-binomial"],
    desc: "(a + b)ⁿ과 (a + b + c)ⁿ을 넓이·부피 모형의 조각으로 세어 계수를 얻고, 그 계수가 파스칼의 삼각형과 갈톤 보드에서 공이 지나는 길의 수와 같음을 연결합니다. 장면마다 먼저 예측하고 확인합니다.",
    obs: [
      "(a + b)ⁿ을 전개하면 n개의 괄호에서 b를 k번 고르는 방법의 수 ₙCₖ가 aⁿ⁻ᵏbᵏ의 계수가 됩니다.",
      "(a + b)⁴은 (a + b)³의 부피 모형에 a를 곱한 덩어리와 b를 곱한 덩어리의 합으로 볼 수 있습니다.",
      "파스칼의 삼각형의 각 수는 바로 위 두 수의 합이고(ₙ₋₁Cₖ₋₁ + ₙ₋₁Cₖ = ₙCₖ), 각 줄은 좌우 대칭입니다.",
      "n번째 줄의 합은 2ⁿ, 번갈아 더하고 빼면 0입니다.",
      "갈톤 보드에서 공이 n줄의 못을 지나 칸 k에 이르는 길은 ₙCₖ가지이고, 그 칸에 들어갈 확률은 ₙCₖ/2ⁿ입니다.",
      "홀수만 칠하면 시에르핀스키 삼각형이, 얕은 대각선의 합에서는 피보나치 수열이 나타납니다.",
    ],
    q: "(a + b + c)⁴의 전개식에서 a²bc의 계수는 몇일까요? 부피 모형 없이 세는 방법을 설명해 봅시다.",
    formula: "(a + b)ⁿ = ₙC₀aⁿ + ₙC₁aⁿ⁻¹b + ⋯ + ₙCₙbⁿ",
    en: { title: "Binomial Theorem Lab", desc: "Volume models, Pascal's triangle and a Galton board, with predict-and-check prompts." },
    panel: "장면 고르기",
    space: (s) => s.scene === "model",
    cam: (s) => { const [m, n] = EXPRS[s.expr], side = s.a + s.b + (m === 3 ? s.c : 0) + s.gap * (m - 1); return { yaw: 36, pitch: 24, scale: (n === 4 ? 92 : 150) / side }; },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [
      { key: "scene", label: "장면", type: "seg", value: "model", options: [["model", "부피 모형"], ["pascal", "파스칼"], ["galton", "갈톤 보드"]] },
      { key: "expr", label: "전개할 식", type: "select", value: "2_3", options: [["2_1", "(a + b)¹"], ["2_2", "(a + b)² — 넓이"], ["2_3", "(a + b)³ — 부피"], ["2_4", "(a + b)⁴ — 부피 두 덩어리"], ["3_2", "(a + b + c)² — 넓이"], ["3_3", "(a + b + c)³ — 부피"]], when: (s) => s.scene === "model" },
      { key: "a", label: "a", min: 1, max: 3, step: 0.25, value: 2, when: (s) => s.scene === "model" },
      { key: "b", label: "b", min: 0.5, max: 2, step: 0.25, value: 1.25, when: (s) => s.scene === "model" },
      { key: "c", label: "c", min: 0.5, max: 1.5, step: 0.25, value: 0.75, when: (s) => s.scene === "model" && EXPRS[s.expr][0] === 3 },
      { key: "gap", label: "조각 벌리기", min: 0, max: 1, step: 0.05, value: 0.35, when: (s) => s.scene === "model" },
      { key: "hj", label: "강조할 항: b의 차수", min: 0, max: (s) => EXPRS[s.expr][1], step: 1, value: 1, when: (s) => s.scene === "model" },
      { key: "hk", label: "강조할 항: c의 차수", min: 0, max: (s) => EXPRS[s.expr][1] - s.hj, step: 1, value: 0, when: (s) => s.scene === "model" && EXPRS[s.expr][0] === 3 },
      { key: "pn", label: "보여 줄 줄 수 (0번째 줄부터)", min: 3, max: 15, step: 1, value: 8, when: (s) => s.scene === "pascal" },
      { key: "pat", label: "찾아볼 규칙", type: "select", value: "add", options: [["none", "기본"], ["add", "이웃한 두 수의 합"], ["sym", "좌우 대칭"], ["sum", "한 줄의 합 = 2ⁿ"], ["alt", "번갈아 더하고 빼기"], ["hockey", "하키스틱 규칙"], ["diag", "대각선의 합 (피보나치)"], ["odd", "홀수만 색칠"], ["eleven", "11의 거듭제곱"]], when: (s) => s.scene === "pascal" },
      { key: "pr", label: "줄 번호 n", min: 0, max: (s) => s.pn, step: 1, value: 5, when: (s) => s.scene === "pascal" && s.pat !== "odd" && s.pat !== "none" },
      { key: "pk", label: "왼쪽부터 k번째", min: 0, max: (s) => s.pr, step: 1, value: 2, when: (s) => s.scene === "pascal" && ["add", "sym", "hockey"].includes(s.pat) },
      { key: "gn", label: "못의 줄 수 n", min: 1, max: 10, step: 1, value: 6, when: (s) => s.scene === "galton" },
      { key: "gk", label: "도착할 칸 k", min: 0, max: (s) => s.gn, step: 1, value: 2, when: (s) => s.scene === "galton" },
      { key: "gp", label: "길 번호", min: 1, max: (s) => C(s.gn, s.gk), step: 1, value: 1, when: (s) => s.scene === "galton" },
      { key: "shownum", label: "갈림목마다 길의 수 보기", type: "check", value: true, when: (s) => s.scene === "galton" },
    ],
    anim: { key: "gap", min: 0, max: 1, speed: 0.5, label: "조각 벌렸다 모으기", when: (s) => s.scene === "model" },
    buttons: (s) => (s.scene === "galton" ? [["drop1", "공 1개"], ["drop100", "공 100개"], ["drop1000", "공 1000개"], ["reset", "비우기"]] : []),
    init: () => ({ cnt: Array(7).fill(0), N: 0, last: null, hide: false }),
    derive(s) {
      const [m, n] = EXPRS[s.expr];
      s.hj = clamp(s.hj, 0, n); s.hk = m === 3 ? clamp(s.hk, 0, n - s.hj) : 0;
      s.pr = clamp(s.pr, 0, s.pn); s.pk = clamp(s.pk, 0, s.pr);
      s.gk = clamp(s.gk, 0, s.gn); s.gp = clamp(s.gp, 1, C(s.gn, s.gk));
      if (!s.cnt || s.cnt.length !== s.gn + 1) { s.cnt = Array(s.gn + 1).fill(0); s.N = 0; s.last = null; }
    },
    onDo(k, s) {
      if (k === "reset") { s.cnt = Array(s.gn + 1).fill(0); s.N = 0; s.last = null; return; }
      const times = { drop1: 1, drop100: 100, drop1000: 1000 }[k] || 0;
      for (let t = 0; t < times; t++) { const path = []; let r = 0; for (let i = 0; i < s.gn; i++) { const R = Math.random() < 0.5; path.push(R); r += R; } s.cnt[r]++; s.N++; s.last = path; }
    },
    onChange(s, key) { if (key === "scene") s.hide = false; },
    hl(s) { const [m, n] = EXPRS[s.expr]; return m === 2 ? [n - s.hj, s.hj] : [n - s.hj - s.hk, s.hj, s.hk]; },
    draw(s, g) { if (s.scene === "model") this.drawModel(s, g); else if (s.scene === "pascal") this.drawPascal(s, g); else this.drawGalton(s, g); },
    // ── 부피 모형 ──
    drawModel(s, g) {
      const [m, n] = EXPRS[s.expr], Ls = [s.a, s.b, s.c].slice(0, m), d = Math.min(n, 3), side = Ls.reduce((x, y) => x + y, 0) + s.gap * (m - 1), T = 0.28;
      const want = this.hl(s), key = want.join(), copies = n === 4 ? 2 : 1, shift = n === 4 ? side / 2 + 0.6 : 0;
      const start = (i) => Ls.slice(0, i).reduce((x, y) => x + y, 0) + i * s.gap;
      const digits = (idx) => { const t = []; for (let q = 0; q < d; q++) { t.push(idx % m); idx = Math.floor(idx / m); } return t; };
      for (let cp = 0; cp < copies; cp++) {
        const ox = (cp ? 1 : -1) * shift - side / 2;
        for (let idx = 0; idx < m ** d; idx++) {
          const t = digits(idx), ex = Array(m).fill(0);
          t.forEach((x) => ex[x]++); if (n === 4) ex[cp]++;
          const on = ex.join() === key, col = m === 2 ? LETTER_COLS[ex[1]] : TERM_COLS[terms(m, n).findIndex((e) => e.join() === ex.join()) % TERM_COLS.length];
          const lo = [0, 1, 2].map((ax) => (ax < d ? start(t[ax]) : 0)), sz = [0, 1, 2].map((ax) => (ax < d ? Ls[t[ax]] : T));
          const x0 = ox + lo[0], y0 = -side / 2 + (d > 1 ? lo[1] : side / 2 - T / 2), z0 = -side / 2 + (d > 2 ? lo[2] : side / 2 - T / 2);
          const P = (u, v, w) => [x0 + u * sz[0], y0 + v * sz[1], z0 + w * sz[2]];
          [[P(0, 0, 0), P(1, 0, 0), P(1, 1, 0), P(0, 1, 0)], [P(0, 0, 1), P(1, 0, 1), P(1, 1, 1), P(0, 1, 1)], [P(0, 0, 0), P(1, 0, 0), P(1, 0, 1), P(0, 0, 1)], [P(0, 1, 0), P(1, 1, 0), P(1, 1, 1), P(0, 1, 1)], [P(0, 0, 0), P(0, 1, 0), P(0, 1, 1), P(0, 0, 1)], [P(1, 0, 0), P(1, 1, 0), P(1, 1, 1), P(1, 0, 1)]]
            .forEach((f) => g.face(f, { fill: on ? col : col, color: "ink", fo: on ? 0.72 : 0.16, w: on ? 1.3 : 0.6 }));
          if (on && !g.thumb) g.text(P(0.5, 0.5, 0.5), mono(ex), { size: 12, bold: true, color: "ink" });
        }
        if (n === 4) g.text([ox + side / 2, -side / 2, side / 2 + 0.5], cp ? "(a + b)³ × b" : "(a + b)³ × a", { bold: true, size: 14 });
      }
      const cnt = coef(want);
      g.note(20, 30, `강조한 조각: ${mono(want)}${s.hide ? " — 몇 개일까요?" : ` × ${cnt}개`}`, { bold: true, color: "ink" });
      if (m === 2 && !s.hide) g.note(20, 52, `색: ${terms(2, n).map((ex) => mono(ex)).join(" · ")}`, { size: 12, color: "muted" });
    },
    // ── 파스칼의 삼각형 ──
    pos(s, r, k) { const N = s.pn + 1, w = Math.min(1.1, 15 / N), h = Math.min(0.78, 10 / N); return [8 + (k - r / 2) * w, 10.4 - r * h]; },
    pmark(s) {
      const M = {}, mark = (r, k, c) => { if (r >= 0 && k >= 0 && k <= r && r <= s.pn) M[r + "," + k] = c; };
      const { pr: r, pk: k, pat } = s;
      if (s.hide) return M;
      if (pat === "add") { mark(r, k, "a"); mark(r - 1, k - 1, "b"); mark(r - 1, k, "b"); }
      if (pat === "sym") { mark(r, k, "a"); mark(r, r - k, "b"); }
      if (pat === "sum" || pat === "alt" || pat === "eleven") for (let i = 0; i <= r; i++) mark(r, i, pat === "alt" ? (i % 2 ? "d" : "c") : "a");
      if (pat === "hockey") { const kk = Math.min(k, Math.max(0, r - 1)); for (let i = kk; i < r; i++) mark(i, kk, "b"); mark(r, kk + 1, "a"); }
      if (pat === "diag") for (let j = 0; j <= r - j; j++) mark(r - j, j, "e");
      if (pat === "odd") for (let i = 0; i <= s.pn; i++) for (let j = 0; j <= i; j++) if (C(i, j) % 2) mark(i, j, "a");
      return M;
    },
    drawPascal(s, g) {
      const N = s.pn + 1, w = Math.min(1.1, 15 / N), M = this.pmark(s), big = N <= 9;
      for (let r = 0; r <= s.pn; r++) {
        if (!g.thumb && big) g.text(this.pos(s, r, 0), `n = ${r}`, { dx: -w * g.s * 0.55 - 8, dy: 4, anchor: "end", size: 11, color: "muted" });
        for (let k = 0; k <= r; k++) {
          const p = this.pos(s, r, k), c = M[r + "," + k];
          g.circle(p, w * 0.46, { fill: c || "muted", fo: c ? 0.42 : 0.07, color: c || "muted", w: c ? 1.8 : 0.8 });
          const v = C(r, k);
          if (!g.thumb) g.text(p, String(v), { dy: 4, size: clamp(Math.round(w * g.s * (v >= 1000 ? 0.23 : v >= 100 ? 0.31 : 0.42)), 7, 16), bold: !!c, color: c ? "ink" : "muted" });
        }
      }
      if (s.pat === "diag" && !s.hide) { const P = []; for (let j = 0; j <= s.pr - j; j++) P.push(this.pos(s, s.pr - j, j)); if (P.length > 1) g.path(P, { color: "e", w: 2, dash: "5 4" }); }
    },
    // ── 갈톤 보드 ──
    gpos(s, r, i) { const n = s.gn, dx = Math.min(1.25, 13 / (n + 1)), dy = Math.min(0.62, 5.6 / n); return [8 + (i - r / 2) * dx, 10 - r * dy]; },
    drawGalton(s, g) {
      const n = s.gn, dx = Math.min(1.25, 13 / (n + 1)), path = kthComb(n, s.gk, s.gp - 1);
      for (let r = 0; r < n; r++) for (let i = 0; i <= r; i++) {
        const p = this.gpos(s, r, i); g.circle(p, 0.09, { fill: "ink", fo: 0.8, color: "ink", w: 1 });
        if (s.shownum && !g.thumb && !s.hide) g.text(p, String(C(r, i)), { dy: -7, size: 11, color: "e", bold: true });
      }
      const route = (rs) => { const pts = [[8, 10.75]]; let i = 0; for (let r = 0; r < n; r++) { pts.push(this.gpos(s, r, i)); if (rs[r]) i++; } pts.push(this.gpos(s, n, i)); return pts; };
      const sel = Array(n).fill(false); path.forEach((x) => (sel[x] = true));
      g.path(route(sel), { color: "a", w: 3.4 });
      if (s.last) g.path(route(s.last), { color: "d", w: 1.8, dash: "4 4" });
      const y0 = 0.5, top = this.gpos(s, n, 0)[1] - 0.45, H = top - y0, mx = Math.max(1, ...s.cnt), ex = s.cnt.map((_, k) => (C(n, k) / 2 ** n) * s.N), sc = Math.max(mx, ...ex);
      for (let k = 0; k <= n; k++) {
        const [x] = this.gpos(s, n, k), hw = dx * 0.42;
        g.poly([[x - hw, y0], [x + hw, y0], [x + hw, y0 + (H * s.cnt[k]) / sc], [x - hw, y0 + (H * s.cnt[k]) / sc]], { fill: k === s.gk ? "a" : "b", fo: 0.45, color: k === s.gk ? "a" : "b", w: 1 });
        if (s.N) g.seg([x - hw, y0 + (H * ex[k]) / sc], [x + hw, y0 + (H * ex[k]) / sc], { color: "e", w: 2.6 });
        g.seg([x - dx / 2, y0], [x - dx / 2, top], { color: "muted", w: 0.8 });
        if (!g.thumb) g.text([x, top], s.hide ? "?" : String(C(n, k)), { dy: -4, size: 12, bold: true, color: k === s.gk ? "a" : "ink" });
        if (!g.thumb) g.text([x, y0], String(k), { dy: 14, size: 11, color: "muted" });
      }
      g.seg([this.gpos(s, n, n)[0] + dx / 2, y0], [this.gpos(s, n, n)[0] + dx / 2, top], { color: "muted", w: 0.8 });
      g.note(20, 30, s.N ? `떨어뜨린 공 ${s.N}개 · 보라 선: 기대 개수` : "주황 길: 고른 칸으로 가는 길 하나", { size: 12, color: "muted", bold: true });
    },
    metrics(s) {
      if (s.scene === "model") {
        const [m, n] = EXPRS[s.expr], want = this.hl(s), lab = m === 2 ? `(a + b)${sup(n) || "¹"}` : `(a + b + c)${sup(n)}`;
        const tot = (s.a + s.b + (m === 3 ? s.c : 0)) ** n, parts = terms(m, n).reduce((acc, ex) => acc + coef(ex) * ex.reduce((p, e, i) => p * [s.a, s.b, s.c][i] ** e, 1), 0);
        return [
          ["전개식", s.hide ? "확인을 누르면 보여요" : `${lab} = ${expansion(m, n)}`],
          [`${mono(want)} 조각의 수`, s.hide ? "?" : m === 2 ? `${nCk(n, want[1])} = ${coef(want)}` : `${n}!/(${want.join("!·")}!) = ${coef(want)}`, "key"],
          ["조각 전체 개수", s.hide ? "?" : `${m}${sup(n) || ""} = ${m ** n}개 · 항 ${terms(m, n).length}종류`],
          ["부피(넓이) 확인", `${fmt(tot, 3)} = ${fmt(parts, 3)}`],
        ];
      }
      if (s.scene === "pascal") {
        const r = s.pr, k = s.pk, row = Array.from({ length: r + 1 }, (_, i) => C(r, i)), H = s.hide;
        const T = {
          none: ["파스칼의 삼각형", `n번째 줄 = (a + b)ⁿ의 계수`],
          add: [`${nCk(r - 1, k - 1)} + ${nCk(r - 1, k)}`, H ? "?" : r ? `${C(r - 1, k - 1)} + ${C(r - 1, k)} = ${C(r, k)} = ${nCk(r, k)}` : "맨 위 1"],
          sym: [`${nCk(r, k)}와 ${nCk(r, r - k)}`, H ? "?" : `${C(r, k)} = ${C(r, r - k)}`],
          sum: [`${r}번째 줄의 합`, H ? "?" : `${row.join(" + ")} = ${2 ** r} = 2${sup(r) || "¹"}`],
          alt: [`${r}번째 줄을 번갈아`, H ? "?" : `${row.map((v, i) => (i ? (i % 2 ? " − " : " + ") : "") + v).join("")} = ${r ? 0 : 1}`],
          hockey: ["하키스틱", H ? "?" : (() => { const kk = Math.min(k, Math.max(0, r - 1)); const vs = []; for (let i = kk; i < r; i++) vs.push(C(i, kk)); return `${vs.join(" + ")} = ${C(r, kk + 1)}`; })()],
          diag: [`${r}번째 대각선의 합`, H ? "?" : (() => { const vs = []; for (let j = 0; j <= r - j; j++) vs.push(C(r - j, j)); return `${vs.join(" + ")} = ${fib(r + 1)}`; })()],
          odd: ["홀수만 색칠", H ? "?" : "시에르핀스키 삼각형 — 줄 수를 늘려 보세요"],
          eleven: [`${r}번째 줄을 이어 쓰면`, H ? "?" : r <= 4 ? `${row.join("")} = 11${sup(r) || (r ? "¹" : "⁰")}` : `받아올림하면 11${sup(r)} = ${11 ** r}`],
        }[s.pat];
        return [[T[0], T[1], "key"], ["이 줄의 수", row.join(", ")], ["이 줄의 합", H ? "?" : `2${sup(r) || (r ? "¹" : "⁰")} = ${2 ** r}`]];
      }
      const n = s.gn, k = s.gk;
      return [
        [`칸 ${k}로 가는 길`, s.hide ? "?" : `${nCk(n, k)} = ${C(n, k)}가지`, "key"],
        [`칸 ${k}에 들어갈 확률`, s.hide ? "?" : `${C(n, k)}/${2 ** n} ≈ ${fmt(C(n, k) / 2 ** n, 4)}`],
        ["지금 길", `${s.gp}번째 — 오른쪽 ${k}번, 왼쪽 ${n - k}번`],
        ["떨어뜨린 공", s.N ? `${s.N}개 · 칸 ${k}에 ${s.cnt[k]}개 (기대 ${fmt((C(n, k) / 2 ** n) * s.N, 1)}개)` : "아직 없음"],
      ];
    },
    predict: [
      { q: "(a + b)⁴을 전개하면 a²b² 조각은 몇 개일까요?", set: (s) => Object.assign(s, { scene: "model", expr: "2_4", hj: 2, hk: 0, gap: 0.35, hide: true }), reveal: (s) => (s.hide = false), answer: () => 6, why: "괄호 4개 중 b를 고를 2개를 정하는 방법의 수 ₄C₂ = 6입니다. 두 덩어리에서 a²b² 조각을 세어 보세요(3 + 3)." },
      { q: "(a + b)³의 부피 모형은 모두 몇 조각으로 나뉠까요?", set: (s) => Object.assign(s, { scene: "model", expr: "2_3", hj: 1, hide: true }), reveal: (s) => (s.hide = false), answer: () => 8, why: "괄호마다 a 또는 b를 고르므로 2 × 2 × 2 = 2³ = 8조각, 계수의 합 1 + 3 + 3 + 1과 같습니다." },
      { q: "(a + b + c)³을 전개하면 서로 다른 항은 몇 종류일까요?", set: (s) => Object.assign(s, { scene: "model", expr: "3_3", hj: 1, hk: 1, hide: true }), reveal: (s) => (s.hide = false), answer: () => 10, why: "i + j + k = 3을 만족하는 (i, j, k)의 개수, 곧 ₅C₂ = 10입니다(중복조합 ₃H₃)." },
      { q: "(a + b + c)³에서 abc 조각은 몇 개일까요?", set: (s) => Object.assign(s, { scene: "model", expr: "3_3", hj: 1, hk: 1, hide: true }), reveal: (s) => (s.hide = false), answer: () => 6, why: "세 괄호에서 a, b, c를 하나씩 서로 다르게 고르는 순서의 수 3! = 6입니다." },
      { q: "파스칼의 삼각형 7번째 줄(n = 7)에 있는 수를 모두 더하면 얼마일까요?", set: (s) => Object.assign(s, { scene: "pascal", pn: 8, pat: "sum", pr: 7, hide: true }), reveal: (s) => (s.hide = false), answer: () => 128, why: "(1 + 1)⁷ = ₇C₀ + ₇C₁ + ⋯ + ₇C₇이므로 2⁷ = 128입니다." },
      { q: "₆C₂ + ₆C₃은 파스칼의 삼각형에서 어느 수와 같을까요? 값을 적어 보세요.", set: (s) => Object.assign(s, { scene: "pascal", pn: 8, pat: "add", pr: 7, pk: 3, hide: true }), reveal: (s) => (s.hide = false), answer: () => 35, why: "바로 아래 칸의 수 ₇C₃ = 15 + 20 = 35입니다. ₙ₋₁Cₖ₋₁ + ₙ₋₁Cₖ = ₙCₖ" },
      { q: "₁₀C₃과 같은 값을 갖는 ₁₀Cₖ (k ≠ 3)에서 k는 얼마일까요?", set: (s) => Object.assign(s, { scene: "pascal", pn: 10, pat: "sym", pr: 10, pk: 3, hide: true }), reveal: (s) => (s.hide = false), answer: () => 7, why: "ₙCₖ = ₙCₙ₋ₖ이므로 ₁₀C₃ = ₁₀C₇ = 120. b를 3개 고르는 것은 a를 7개 고르는 것과 같습니다." },
      { q: "₂C₂ + ₃C₂ + ₄C₂ + ₅C₂의 값은 얼마일까요?", set: (s) => Object.assign(s, { scene: "pascal", pn: 8, pat: "hockey", pr: 6, pk: 2, hide: true }), reveal: (s) => (s.hide = false), answer: () => 20, why: "하키스틱 규칙: 1 + 3 + 6 + 10 = 20 = ₆C₃. 비스듬히 내려가며 더한 합은 끝에서 꺾인 칸의 수입니다." },
      { q: "₅C₀ − ₅C₁ + ₅C₂ − ₅C₃ + ₅C₄ − ₅C₅의 값은?", set: (s) => Object.assign(s, { scene: "pascal", pn: 8, pat: "alt", pr: 5, hide: true }), reveal: (s) => (s.hide = false), answer: () => 0, why: "(1 − 1)⁵ = 0을 전개한 것과 같습니다. 1 − 5 + 10 − 10 + 5 − 1 = 0" },
      { q: "얕은 대각선의 합 1, 1, 2, 3, 5, …에서 그다음 수는?", set: (s) => Object.assign(s, { scene: "pascal", pn: 10, pat: "diag", pr: 5, hide: true }), reveal: (s) => { s.hide = false; s.pr = 5; }, answer: () => 8, why: "5번째 대각선 1 + 4 + 3 = 8. 앞의 두 대각선의 합이 다음 대각선의 합이 되는 피보나치 수열입니다." },
      { q: "줄 수를 늘리고 홀수만 색칠하면 어떤 무늬가 나타날까요?", options: [["sier", "삼각형 속에 빈 삼각형이 되풀이된다"], ["stripe", "가로 줄무늬"], ["check", "체크무늬"], ["rand", "규칙 없이 흩어진다"]], set: (s) => Object.assign(s, { scene: "pascal", pn: 15, pat: "none", hide: true }), reveal: (s) => { s.hide = false; s.pat = "odd"; }, answer: () => "sier", why: "홀수 칸은 시에르핀스키 삼각형을 만듭니다. 바로 위 두 수의 홀짝만으로 아래 칸의 홀짝이 정해지기 때문입니다." },
      { q: "4번째 줄 1 4 6 4 1을 이어 쓴 수 14641은 11의 몇 제곱일까요?", set: (s) => Object.assign(s, { scene: "pascal", pn: 8, pat: "eleven", pr: 4, hide: true }), reveal: (s) => (s.hide = false), answer: () => 4, why: "11⁴ = (10 + 1)⁴ = 1·10⁴ + 4·10³ + 6·10² + 4·10 + 1 = 14641. 5번째 줄부터는 받아올림이 생깁니다." },
      { q: "못이 4줄인 갈톤 보드에서 맨 왼쪽 칸(k = 0)으로 가는 길은 몇 가지일까요?", set: (s) => Object.assign(s, { scene: "galton", gn: 4, gk: 0, gp: 1, hide: true }), reveal: (s) => (s.hide = false), answer: () => 1, why: "네 번 모두 왼쪽으로 가는 길 하나뿐입니다. ₄C₀ = 1" },
      { q: "못이 6줄일 때 공이 가장 많이 모이는 칸 번호 k는? (맨 왼쪽이 0)", set: (s) => Object.assign(s, { scene: "galton", gn: 6, gk: 0, gp: 1, hide: true }), reveal: (s) => { s.hide = false; s.gk = 3; s.gp = 1; }, answer: () => 3, why: "₆Cₖ가 가장 큰 k = 3(값 20)입니다. 오른쪽과 왼쪽이 반반 섞이는 길이 가장 많습니다." },
      { q: "못이 6줄일 때 공 하나가 칸 3에 들어갈 확률은? (분수나 소수로)", set: (s) => Object.assign(s, { scene: "galton", gn: 6, gk: 3, gp: 1, hide: true }), reveal: (s) => (s.hide = false), answer: () => 20 / 64, tol: 0.005, show: () => "20/64 = 5/16 ≈ 0.3125", why: "갈 수 있는 길은 모두 2⁶ = 64가지이고 그중 칸 3으로 가는 길이 ₆C₃ = 20가지입니다." },
      { q: "못이 10줄인 보드에 공 1000개를 떨어뜨리면 칸 5에는 대략 몇 개가 모일까요?", set: (s) => { Object.assign(s, { scene: "galton", gn: 10, gk: 5, gp: 1, hide: true }); s.cnt = Array(11).fill(0); s.N = 0; s.last = null; }, reveal: function (s) { s.hide = false; s.cnt = Array(11).fill(0); s.N = 0; for (let t = 0; t < 1000; t++) { let r = 0; for (let i = 0; i < 10; i++) r += Math.random() < 0.5; s.cnt[r]++; s.N++; } }, answer: () => 246, tol: 0.15, rel: true, show: (s) => `기대값 1000 × 252/1024 ≈ 246개 (이번 실험 ${s.cnt[5]}개)`, why: "₁₀C₅ = 252, 252/1024 ≈ 0.246이므로 약 246개. 실제 개수는 실험마다 조금씩 달라집니다." },
    ],
  },
];
