// 수학실험실 추가 8개
import { fmt, frac, clamp } from "./hs-core.js";

const LB = 9;
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const RNG = (seed) => { let x = (Math.abs(seed | 0) * 7919 + 104729) % 2147483647 || 1; return () => (x = (x * 16807) % 2147483647) / 2147483647; };
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
const SEED = { buttons: [["seed", "다시 넣기"]], onDo(a, s) { if (a === "seed") s.seed = (s.seed % 97) + 1; } };
const memo = (fn) => { let k = null, v = null; return (...a) => { const kk = JSON.stringify(a); if (kk !== k) { k = kk; v = fn(...a); } return v; }; };
const gcd = (a, b) => (b ? gcd(b, a % b) : a);

const CUBE = { V: [[-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1], [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]], E: [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]] };
const OCTA = { V: [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]], E: [[0, 2], [0, 3], [0, 4], [0, 5], [1, 2], [1, 3], [1, 4], [1, 5], [2, 4], [2, 5], [3, 4], [3, 5]] };
const TET = { V: [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]], E: [[0, 1], [0, 2], [0, 3], [1, 2], [1, 3], [2, 3]] };
const TETD = { V: TET.V.map((v) => v.map((x) => -x / 3)), E: TET.E };
const DUALS = { co: { n: "정육면체 ↔ 정팔면체", A: CUBE, B: OCTA, sb: 1, a: ["정육면체", 8, 12, 6], b: ["정팔면체", 6, 12, 8] }, tt: { n: "정사면체 ↔ 정사면체", A: TET, B: TETD, sb: 1, a: ["정사면체", 4, 6, 4], b: ["정사면체", 4, 6, 4] } };
const proj = (v, a, b) => { const [x, y, z] = v, x1 = x * Math.cos(a) + z * Math.sin(a), z1 = -x * Math.sin(a) + z * Math.cos(a), y1 = y * Math.cos(b) - z1 * Math.sin(b); return [x1, y1]; };
const JCACHE = {};
function juliaURL(key, cr, ci, W, H, it) { if (JCACHE[key]) return JCACHE[key]; if (typeof document === "undefined") return ""; const cv = document.createElement("canvas"); cv.width = W; cv.height = H; const ctx = cv.getContext("2d"), im = ctx.createImageData(W, H); for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) { let x = -1.8 + (3.6 * (i + 0.5)) / W, y = 1.2 - (2.4 * (j + 0.5)) / H, n = 0; while (n < it && x * x + y * y < 4) { const t = x * x - y * y + cr; y = 2 * x * y + ci; x = t; n++; } const o = (j * W + i) * 4, v = n === it ? 0 : Math.sqrt(n / it); im.data[o] = n === it ? 20 : 30 + 220 * v; im.data[o + 1] = n === it ? 30 : 60 + 120 * v; im.data[o + 2] = n === it ? 70 : 140 + 100 * (1 - v); im.data[o + 3] = 255; } ctx.putImageData(im, 0, 0); return (JCACHE[key] = cv.toDataURL("image/png")); }
const JC = { a: ["토끼 모양", -0.123, 0.745], b: ["덴드라이트", 0, 1], c: ["산마르코 (c = −0.75)", -0.75, 0], d: ["먼지 (c = 0.3 + 0.5i)", 0.3, 0.5], e: ["원 (c = 0)", 0, 0] };
const langton = memo((n) => { const B = new Set(); let x = 0, y = 0, d = 0; for (let i = 0; i < n; i++) { const k = x + "," + y, black = B.has(k); d = (d + (black ? 3 : 1)) % 4; if (black) B.delete(k); else B.add(k); x += [0, 1, 0, -1][d]; y += [1, 0, -1, 0][d]; } return { B, x, y }; });
const dragon = memo((n) => { let T = []; for (let i = 0; i < n; i++) T = [...T, 1, ...T.slice().reverse().map((t) => -t)]; let x = 0, y = 0, d = 0; const P = [[0, 0]]; const step = () => { x += [1, 0, -1, 0][d]; y += [0, 1, 0, -1][d]; P.push([x, y]); }; step(); T.forEach((t) => { d = (d + (t > 0 ? 1 : 3)) % 4; step(); }); return P; });
const hilbert = memo((n) => { const N = 2 ** n, P = []; for (let k = 0; k < N * N; k++) { let t = k, x = 0, y = 0; for (let s = 1; s < N; s *= 2) { const rx = 1 & (t >> 1), ry = 1 & (t ^ rx); if (ry === 0) { if (rx === 1) { x = s - 1 - x; y = s - 1 - y; } [x, y] = [y, x]; } x += s * rx; y += s * ry; t >>= 2; } P.push([(x + 0.5) / N, (y + 0.5) / N]); } return P; });
const pendT = (L, th) => { let a = 1, b = Math.cos(th / 2); for (let i = 0; i < 20; i++) [a, b] = [(a + b) / 2, Math.sqrt(a * b)]; return (2 * Math.PI * Math.sqrt(L / 9.8)) / a; };
const pendSim = memo((L, th0, T) => { let th = th0, w = 0; const h = 0.005, P = [[0, th]]; for (let t = 0; t < T; t += h) { const f = (q) => -(9.8 / L) * Math.sin(q); const k1 = [w, f(th)], k2 = [w + (h / 2) * k1[1], f(th + (h / 2) * k1[0])], k3 = [w + (h / 2) * k2[1], f(th + (h / 2) * k2[0])], k4 = [w + h * k3[1], f(th + h * k3[0])]; th += (h / 6) * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0]); w += (h / 6) * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1]); P.push([t + h, th]); } return P; });

export default [
  {
    id: "lab-dual", grade: LB, unit: 3, lesson: "주제 3", title: "정다면체의 쌍대 — 면의 중심을 이으면 짝이 나온다", type: "3D", time: "10분",
    tags: ["정다면체", "꼭짓점·모서리·면", "오일러 공식"], links: ["m1-polyhedra", "lab-four-color"],
    desc: "정육면체의 여섯 면의 중심을 이으면 정팔면체가, 정팔면체의 여덟 면의 중심을 이으면 다시 정육면체가 생깁니다. 이렇게 짝을 이루는 관계를 쌍대라 하며, 꼭짓점 수와 면의 수가 서로 바뀌고 모서리 수는 같습니다. 정사면체는 자기 자신과 쌍대입니다. 입체를 돌려 가며 확인합니다.",
    obs: ["쌍대에서 (꼭짓점, 모서리, 면) = (v, e, f) ↔ (f, e, v)입니다.", "정십이면체와 정이십면체도 쌍대입니다.", "어느 쪽이든 v − e + f = 2(오일러 공식)를 만족합니다."],
    q: "정십이면체(v = 20, e = 30, f = 12)의 쌍대는 꼭짓점이 몇 개일까요?",
    formula: "쌍대: (v, e, f) ↔ (f, e, v), v − e + f = 2",
    en: { title: "Duals of Platonic Solids", desc: "Face centres make the partner." },
    view: { x: [-2.2, 2.2], y: [-1.7, 1.8] },
    params: [{ key: "p", label: "짝", type: "seg", value: "co", options: Object.entries(DUALS).map(([k, v]) => [k, v.n]) }, { key: "a", label: "돌리기 (°)", min: 0, max: 360, step: 1, value: 30 }, { key: "b", label: "기울이기 (°)", min: -60, max: 60, step: 1, value: 20 }],
    anim: { key: "a", min: 0, max: 360, speed: 40, label: "돌리기" },
    draw(s, g) { const D = DUALS[s.p], a = (s.a * Math.PI) / 180, b = (s.b * Math.PI) / 180, P = (v) => proj(v, a, b); D.A.E.forEach(([i, j]) => g.seg(P(D.A.V[i]), P(D.A.V[j]), { color: "b", w: 2.4 })); D.B.E.forEach(([i, j]) => g.seg(P(D.B.V[i]), P(D.B.V[j]), { color: "a", w: 2.4 })); D.B.V.forEach((v) => g.point(P(v), "", { color: "a", r: 4 })); g.text([-2.1, 1.65], `파랑: ${D.a[0]} · 주황: 면의 중심을 이은 ${D.b[0]}`, { anchor: "start", bold: true, size: 12 }); },
    metrics(s) { const D = DUALS[s.p]; return [[D.a[0], `v ${D.a[1]} · e ${D.a[2]} · f ${D.a[3]}`], [D.b[0], `v ${D.b[1]} · e ${D.b[2]} · f ${D.b[3]}`, "key"], ["v − e + f", "2"]]; },
    predict: [
      { q: "정육면체의 쌍대인 정팔면체의 꼭짓점은 몇 개?", set: (s) => Object.assign(s, { p: "co" }), answer: () => 6, why: "정육면체의 면이 6개이므로 6개입니다." },
      { q: "정십이면체(면 12개)의 쌍대는 꼭짓점이 몇 개?", answer: () => 12, why: "정이십면체로 꼭짓점이 12개입니다." },
    ],
  },
  {
    id: "lab-pigeonhole", grade: LB, unit: 4, lesson: "주제 4", title: "비둘기집 원리 — 서울에 머리카락 수가 같은 두 사람이 있다", type: "데이터", time: "8분",
    tags: ["논리", "나눗셈", "존재 증명"], links: ["lab-birthday", "par-hat-check"],
    desc: "비둘기 n마리를 집 m개에 넣으면 n > m일 때 어느 집에는 반드시 두 마리 이상이 들어갑니다. 더 정확히는 ⌈n/m⌉마리 이상이 든 집이 있습니다. 사람의 머리카락은 많아야 약 20만 개이고 서울 인구는 900만 명이 넘으니, 머리카락 수가 같은 사람이 적어도 45명은 있습니다. 무작위로 넣어 보며 확인합니다.",
    obs: ["n > m이면 어떻게 넣어도 겹치는 집이 생깁니다.", "가장 많이 든 집에는 적어도 ⌈n/m⌉마리가 있습니다.", "‘있다’는 것은 알지만 ‘어느 집인지’는 알려 주지 않는 증명입니다."],
    q: "양말 5짝(검정·흰색·회색)이 섞여 있을 때 같은 색 한 켤레를 확실히 얻으려면 몇 개를 꺼내야 할까요?",
    formula: "가장 많이 든 집 ≥ ⌈n / m⌉",
    en: { title: "The Pigeonhole Principle", desc: "Someone must share." },
    view: { x: [-0.6, 12.6], y: [-1.4, 7.4] },
    params: [{ key: "n", label: "비둘기 n", min: 1, max: 60, step: 1, value: 13 }, { key: "m", label: "비둘기집 m", min: 1, max: 12, step: 1, value: 12 }, { key: "seed", label: "씨앗값", min: 1, max: 97, step: 1, value: 1 }],
    ...SEED,
    fill(s) { const r = RNG(s.seed), H = Array(s.m).fill(0); for (let i = 0; i < s.n; i++) H[Math.floor(r() * s.m)]++; return H; },
    draw(s, g) { const H = this.fill(s), W = 12 / s.m, mx = Math.max(...H); H.forEach((h, i) => { const x = 0.2 + i * W; rect(g, x, 0, W * 0.85, 6.6, { fill: "paper", color: "muted", w: 1 }); for (let k = 0; k < h; k++) g.circle([x + W * 0.425, 0.3 + k * 0.55], Math.min(0.24, W * 0.3), { fill: h === mx ? "a" : "b", fo: 0.85, stroke: false }); g.text([x + W * 0.425, 0], `${h}`, { dy: 14, size: 11, bold: h === mx }); }); },
    metrics(s) { const H = this.fill(s); return [["가장 많이 든 집", `${Math.max(...H)}마리`], ["보장되는 최솟값 ⌈n/m⌉", `${Math.ceil(s.n / s.m)}마리`, "key"]]; },
    predict: [
      { q: "13명이 있으면 같은 달에 태어난 사람이 적어도 몇 명 있을까요?", set: (s) => Object.assign(s, { n: 12, m: 12 }), reveal: (s) => Object.assign(s, { n: 13, m: 12 }), answer: () => 2, why: "⌈13/12⌉ = 2명입니다." },
      { q: "세 색 양말에서 같은 색 한 켤레를 확실히 얻으려면 최소 몇 개를 꺼내야 할까요?", answer: () => 4, why: "색이 3가지이므로 4개를 꺼내면 반드시 겹칩니다." },
    ],
  },
  {
    id: "lab-julia", grade: LB, unit: 2, lesson: "주제 2", title: "줄리아 집합 — c 하나가 정하는 프랙털 무늬", type: "조작", time: "10분",
    tags: ["복소수", "프랙털", "반복"], links: ["lab-mandelbrot", "lab-koch"],
    desc: "망델브로 집합이 ‘0에서 출발하는 c들’의 모임이라면, 줄리아 집합은 c를 하나 고정하고 ‘z ← z² + c를 되풀이해도 달아나지 않는 출발점 z들’의 모임입니다. c를 바꾸면 토끼 모양, 나뭇가지 모양, 먼지처럼 흩어진 모양 등 전혀 다른 무늬가 나옵니다. c가 망델브로 집합 안에 있으면 줄리아 집합은 한 덩어리로 이어집니다.",
    obs: ["c = 0이면 줄리아 집합은 단위원 안쪽(경계는 원)입니다.", "c가 망델브로 집합 안이면 연결, 밖이면 먼지처럼 끊어집니다.", "1918년 줄리아가 연구했지만 컴퓨터가 생긴 뒤에야 모양을 볼 수 있었습니다."],
    q: "c = −1일 때의 줄리아 집합은 어떤 모양일까요? 예상한 뒤 확인해 봅시다.",
    formula: "zₙ₊₁ = zₙ² + c, 줄리아 집합 = {z₀ : |zₙ|이 유계}",
    en: { title: "Julia Sets", desc: "One c, one fractal." },
    view: { x: [-1.8, 1.8], y: [-1.2, 1.2] },
    params: [{ key: "c", label: "c", type: "select", value: "a", options: Object.entries(JC).map(([k, v]) => [k, v[0]]) }],
    draw(s, g) { const [, cr, ci] = JC[s.c], url = juliaURL(s.c + (g.thumb ? "t" : ""), cr, ci, g.thumb ? 150 : 420, g.thumb ? 100 : 280, g.thumb ? 40 : 100), A = g.X([-1.8, 1.2]), B = g.X([1.8, -1.2]); if (url) g.L.grid.push(`<image href="${url}" x="${g.n(A[0])}" y="${g.n(A[1])}" width="${g.n(B[0] - A[0])}" height="${g.n(B[1] - A[1])}" preserveAspectRatio="none"/>`); g.text([-1.75, 1.1], `c = ${fmt(cr, 3)} ${ci >= 0 ? "+" : "−"} ${fmt(Math.abs(ci), 3)}i`, { anchor: "start", bold: true, color: "paper" }); },
    metrics(s) { const [nm, cr, ci] = JC[s.c]; let x = 0, y = 0, n = 0; while (n < 200 && x * x + y * y < 4) { [x, y] = [x * x - y * y + cr, 2 * x * y + ci]; n++; } return [["c", `${fmt(cr, 3)} + ${fmt(ci, 3)}i`], ["c가 망델브로 집합 안?", n === 200 ? "예 → 줄리아 집합 연결" : "아니요 → 먼지처럼 끊어짐", "key"]]; },
    predict: [
      { q: "c = 0일 때 z₀ = 0.5에서 시작하면 zₙ은 어떻게 될까요?", options: O("0으로 다가간다", "무한히 커진다"), set: (s) => (s.c = "a"), reveal: (s) => (s.c = "e"), answer: () => "a", why: "z ← z²이므로 0.25, 0.0625, …로 0에 다가갑니다." },
      { q: "c = 0.3 + 0.5i는 망델브로 집합 밖입니다. 줄리아 집합은?", options: O("한 덩어리", "먼지처럼 흩어짐"), set: (s) => (s.c = "a"), reveal: (s) => (s.c = "d"), answer: () => "b", why: "c가 망델브로 집합 밖이면 줄리아 집합은 끊어진 먼지(칸토어 먼지)입니다." },
    ],
  },
  {
    id: "lab-langton", grade: LB, unit: 5, lesson: "주제 5", title: "랭턴의 개미 — 단순한 규칙이 만든 혼돈과 고속도로", type: "조작", time: "10분",
    tags: ["알고리즘", "규칙", "창발"], links: ["lab-cellular", "his-turing"],
    desc: "흰 칸에서는 오른쪽으로 돌고, 검은 칸에서는 왼쪽으로 돈 뒤, 칸의 색을 뒤집고 한 칸 나아갑니다. 규칙은 이것뿐인데, 개미는 처음 수백 걸음 동안 대칭 무늬를 만들다가 약 1만 걸음 동안 혼돈스럽게 움직이고, 갑자기 약 10 000걸음 뒤부터 같은 모양을 104걸음마다 되풀이하는 ‘고속도로’를 만들며 끝없이 뻗어 나갑니다(1986년 랭턴).",
    obs: ["처음 약 400걸음은 대칭적인 무늬가 생깁니다.", "그 뒤 약 1만 걸음은 규칙이 없어 보이는 혼돈입니다.", "약 10 000걸음 뒤 104걸음 주기의 고속도로가 시작됩니다. 왜 늘 그런지는 아직 증명되지 않았습니다."],
    q: "처음에 검은 칸이 몇 개 섞여 있어도 결국 고속도로가 생길까요?",
    formula: "흰 칸: 오른쪽으로 90° · 검은 칸: 왼쪽으로 90° → 색 뒤집기 → 앞으로 한 칸",
    en: { title: "Langton's Ant", desc: "Simple rules, chaos, then a highway." },
    view: { x: [-42, 42], y: [-30, 30] },
    params: [{ key: "n", label: "걸음 수", min: 0, max: 12000, step: 100, value: 11000 }],
    anim: { key: "n", min: 0, max: 12000, speed: 800, label: "걷기" },
    draw(s, g) { const { B, x, y } = langton(s.n); let d = ""; B.forEach((k) => { const [i, j] = k.split(",").map(Number); if (Math.abs(i) < 42 && Math.abs(j) < 30) { const [X, Y] = g.X([i - 0.5, j + 0.5]); d += `M${g.n(X)},${g.n(Y)}h${g.n(g.s)}v${g.n(g.s)}h${g.n(-g.s)}z`; } }); if (d) g.L.fill.push(`<path d="${d}" fill="var(--pl-ink)"/>`); g.circle([x, y], 0.9, { fill: "a", fo: 1, stroke: false }); },
    metrics(s) { const { B } = langton(s.n); return [["걸음 수", `${s.n}`], ["검은 칸 수", `${B.size}`, "key"], ["단계", s.n < 500 ? "대칭 무늬" : s.n < 10000 ? "혼돈" : "고속도로"]]; },
    predict: [
      { q: "고속도로가 시작되는 것은 대략 몇 걸음 뒤일까요?", options: O("약 100걸음", "약 10 000걸음", "영원히 안 생긴다"), set: (s) => (s.n = 3000), reveal: (s) => (s.n = 12000), answer: () => "b", why: "약 10 000걸음의 혼돈 뒤에 104걸음 주기의 고속도로가 생깁니다." },
      { q: "첫 걸음(흰 칸에서 시작) 뒤 검은 칸은 몇 개?", set: (s) => (s.n = 100), reveal: (s) => (s.n = 0), answer: () => 1, why: "시작 칸을 검게 칠하고 나아갑니다." },
    ],
  },
  {
    id: "lab-pendulum", grade: LB, unit: 6, lesson: "주제 6", title: "진자의 주기 — 줄 길이의 제곱근에 비례한다", type: "조작", time: "10분",
    tags: ["제곱근", "주기", "근삿값"], links: ["his-galileo-ramp", "alg-graph-wrap"],
    desc: "흔들리는 진자의 한 번 왕복 시간(주기)은 진폭이 작으면 추의 무게나 진폭과 상관없이 T = 2π√(L/g)입니다. 줄 길이가 4배면 주기는 2배입니다. 갈릴레이가 성당의 샹들리에를 보고 알아챘다는 이 성질(등시성)은 진폭이 커지면 조금씩 깨집니다. 정확한 계산과 근사식을 비교합니다.",
    obs: ["주기는 √L에 비례합니다: L이 4배 → T가 2배.", "작은 진폭에서는 진폭과 상관없습니다(등시성).", "진폭 60°에서는 근사식보다 약 7% 길어집니다."],
    q: "주기가 정확히 2초인 ‘초 진자’의 줄 길이는 얼마일까요?",
    formula: "T ≈ 2π√(L/g) (진폭이 작을 때)",
    en: { title: "The Period of a Pendulum", desc: "Proportional to √L." },
    view: { x: [-2.6, 9.6], y: [-3.4, 1.6] },
    params: [{ key: "L", label: "줄 길이 L (m)", min: 0.25, max: 4, step: 0.05, value: 1 }, { key: "th", label: "진폭 θ₀ (°)", min: 5, max: 170, step: 1, value: 20 }, { key: "t", label: "시각 (초)", min: 0, max: 8, step: 0.02, value: 0.5 }],
    anim: { key: "t", min: 0, max: 8, speed: 1, label: "흔들기" },
    draw(s, g) { const P0 = pendSim(s.L, (s.th * Math.PI) / 180, 8), k = Math.min(P0.length - 1, Math.round(s.t / 0.005)), th = P0[k][1], len = Math.min(2.6, 0.9 + s.L * 0.45), B = [len * Math.sin(th), -len * Math.cos(th)]; g.seg([-1.2, 0], [1.2, 0], { color: "ink", w: 3 }); g.seg([0, 0], [0, -len], { color: "muted", w: 1, dash: "3 4" }); g.seg([0, 0], B, { color: "ink", w: 1.6 }); g.circle(B, 0.18, { fill: "a", fo: 1, stroke: false }); const X = (t) => 3 + (t / 8) * 6.4, Y = (q) => q * 1.3; g.seg([3, 0 - 1.6], [9.4, -1.6], { color: "axis", w: 1 }); g.path(P0.filter((_, i) => i % 8 === 0).map(([t, q]) => [X(t), -1.6 + Y(q)]), { color: "b", w: 2 }); g.point([X(s.t), -1.6 + Y(th)], "", { color: "a", r: 4 }); g.text([3, 1.1], "흔들림 각도 그래프 (가로: 시간)", { anchor: "start", bold: true, size: 12 }); },
    metrics(s) { const T0 = 2 * Math.PI * Math.sqrt(s.L / 9.8), T = pendT(s.L, (s.th * Math.PI) / 180); return [["근사 주기 2π√(L/g)", `${fmt(T0, 3)}초`], ["정확한 주기", `${fmt(T, 3)}초`, "key"], ["차이", `${fmt((T / T0 - 1) * 100, 2)}%`]]; },
    predict: [
      { q: "줄 길이를 4배로 하면 주기는 몇 배?", set: (s) => Object.assign(s, { L: 0.5, th: 10 }), reveal: (s) => (s.L = 2), answer: () => 2, why: "T ∝ √L이므로 √4 = 2배입니다." },
      { q: "주기 2초인 초 진자의 줄 길이는 약 몇 m? (소수 둘째 자리까지, g = 9.8)", answer: () => 9.8 / (Math.PI * Math.PI), tol: 0.01, why: "L = g(T/2π)² = 9.8/π² ≈ 0.99 m입니다." },
    ],
  },
  {
    id: "lab-dragon", grade: LB, unit: 2, lesson: "주제 2", title: "드래곤 곡선 — 종이 띠를 반으로 접기를 되풀이하면", type: "조작", time: "8분",
    tags: ["프랙털", "규칙", "자기 닮음"], links: ["lab-koch", "lab-hilbert"],
    desc: "긴 종이 띠를 같은 방향으로 반씩 접기를 n번 한 뒤 펼쳐 모든 접힌 곳을 직각으로 세우면 용 모양의 곡선이 나옵니다. 접는 횟수가 늘수록 곡선은 2ⁿ개의 선분으로 늘어나지만 결코 자기 자신과 겹치지 않고, 같은 곡선 네 개로 평면을 빈틈없이 덮을 수 있습니다. 소설 『쥬라기 공원』의 장 표지에도 쓰였습니다.",
    obs: ["접을 때마다 선분의 수가 두 배가 됩니다.", "다음 단계의 꺾임 순서 = (지금) + 오른쪽 + (지금을 거꾸로 뒤집은 것)입니다.", "곡선은 서로 겹치지 않고 꼭짓점에서만 닿습니다."],
    q: "종이를 10번 접을 수 있다면 선분은 몇 개가 될까요?",
    formula: "선분 수 = 2ⁿ, 꺾임 순서 Sₙ₊₁ = Sₙ R (Sₙ의 뒤집힌 역순)",
    en: { title: "The Dragon Curve", desc: "Fold a strip of paper in half again and again." },
    view: (s) => { const P0 = dragon(s.n), xs = P0.map((p) => p[0]), ys = P0.map((p) => p[1]), x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys), w = Math.max(x1 - x0, (y1 - y0) * 1.45) / 2 + 1, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2; return { x: [cx - w, cx + w], y: [cy - w / 1.45, cy + w / 1.45] }; },
    params: [{ key: "n", label: "접은 횟수 n", min: 1, max: 13, step: 1, value: 8 }],
    anim: { key: "n", min: 1, max: 13, speed: 1, label: "접기" },
    draw(s, g) { const P0 = dragon(s.n); g.path(P0, { color: "e", w: s.n > 10 ? 1 : 2 }); g.point(P0[0], "", { color: "ink", r: 4 }); },
    metrics(s) { return [["선분 수", `${2 ** s.n}`, "key"], ["꺾인 곳", `${2 ** s.n - 1}`]]; },
    predict: [
      { q: "종이를 3번 접어 펼치면 선분은 몇 개?", set: (s) => (s.n = 1), reveal: (s) => (s.n = 3), answer: () => 8, why: "2³ = 8개입니다." },
      { q: "드래곤 곡선은 자기 자신과 겹칠까요?", options: O("겹친다", "겹치지 않는다"), answer: () => "b", why: "꼭짓점에서만 닿을 뿐 선분이 겹치지 않습니다." },
    ],
  },
  {
    id: "lab-hilbert", grade: LB, unit: 2, lesson: "주제 2", title: "힐베르트 곡선 — 선 하나로 정사각형을 가득 채우기 (1891년)", type: "조작", time: "8분",
    tags: ["프랙털", "극한", "곡선"], links: ["lab-dragon", "par-coastline"],
    desc: "정사각형을 4칸으로 나눠 ㄷ자로 지나가고, 각 칸을 다시 4칸으로 나눠 같은 모양을 돌려 이어 붙이기를 되풀이합니다. 단계 n에서 곡선은 4ⁿ칸을 한 번씩 모두 지나며 길이가 거의 두 배씩 늘어나고, 끝없이 되풀이하면 정사각형의 모든 점을 지나는 ‘공간을 채우는 곡선’이 됩니다. 이미지 저장이나 지도 검색에서 가까운 점을 가깝게 늘어놓는 데 쓰입니다.",
    obs: ["단계마다 칸 수는 4배, 곡선 길이는 거의 2배가 됩니다.", "곡선 위에서 가까운 점은 정사각형에서도 가깝습니다.", "1차원 선이 2차원 넓이를 채운다는 놀라운 예입니다."],
    q: "단계 n일 때 한 변 1인 정사각형 안 곡선의 길이는 얼마일까요?",
    formula: "칸 수 = 4ⁿ, 길이 = 2ⁿ − 2⁻ⁿ (한 변 1)",
    en: { title: "The Hilbert Curve", desc: "A line that fills a square." },
    view: { x: [-0.3, 1.75], y: [-0.2, 1.2] },
    params: [{ key: "n", label: "단계 n", min: 1, max: 7, step: 1, value: 4 }],
    anim: { key: "n", min: 1, max: 7, speed: 1, label: "단계 올리기" },
    draw(s, g) { const P0 = hilbert(s.n); rect(g, 0, 0, 1, 1, { fill: "none", color: "muted", w: 1 }); g.path(P0, { color: "b", w: s.n > 5 ? 1 : 2.2 }); g.point(P0[0], "", { color: "a", r: 4 }).point(P0.at(-1), "", { color: "e", r: 4 }); },
    metrics(s) { return [["지나는 칸", `${4 ** s.n}`], ["곡선 길이", fmt(2 ** s.n - 2 ** -s.n, 4), "key"]]; },
    predict: [
      { q: "단계 3에서 곡선이 지나는 칸은 몇 개?", set: (s) => (s.n = 1), reveal: (s) => (s.n = 3), answer: () => 64, why: "4³ = 64칸입니다." },
      { q: "단계가 하나 올라가면 곡선 길이는 대략 몇 배?", answer: () => 2, why: "칸 수는 4배, 칸 한 변은 1/2이라 길이는 약 2배입니다." },
    ],
  },
  {
    id: "lab-clock-cipher", grade: LB, unit: 5, lesson: "주제 5", title: "시계 산술 — 12시 다음은 1시, 나머지로 하는 계산과 암호", type: "조작", time: "10분",
    tags: ["나머지", "합동식", "암호"], links: ["his-alkindi", "puz-zeller"],
    desc: "시계는 12를 넘으면 다시 0부터 셉니다. n으로 나눈 나머지만 생각하는 계산을 ‘mod n 산술’이라 합니다. 시계 위에서 a를 곱해 가며 0부터 n − 1까지가 모두 한 번씩 나오면 a로 곱하는 암호를 풀 수 있고(역원이 있음), 이는 gcd(a, n) = 1일 때뿐입니다. 이 원리는 오늘날 RSA 같은 암호의 바탕입니다.",
    obs: ["a × k mod n이 모든 나머지를 한 번씩 지나면 a는 n과 서로소입니다.", "서로소가 아니면 몇몇 나머지에 몰리고 나머지는 나오지 않습니다.", "역원 a⁻¹을 곱하면 곱셈 암호를 되돌릴 수 있습니다."],
    q: "mod 26(알파벳)에서 곱셈 암호에 쓸 수 있는 a는 몇 개일까요?",
    formula: "a × a⁻¹ ≡ 1 (mod n) ⇔ gcd(a, n) = 1",
    en: { title: "Clock Arithmetic", desc: "Remainders, inverses and ciphers." },
    view: { x: [-1.5, 3.2], y: [-1.35, 1.4] },
    params: [{ key: "n", label: "시계의 칸 수 n", min: 5, max: 26, step: 1, value: 12 }, { key: "a", label: "곱하는 수 a", min: 1, max: 25, step: 1, value: 5, max: (s) => s.n - 1 }],
    draw(s, g) { const pos = (k) => [Math.cos(Math.PI / 2 - (2 * Math.PI * k) / s.n), Math.sin(Math.PI / 2 - (2 * Math.PI * k) / s.n)], hit = new Set(); g.circle([0, 0], 1, { color: "ink", w: 2 }); for (let k = 0; k < s.n; k++) { const t = (s.a * k) % s.n; hit.add(t); g.vec(pos(k).map((v) => v * 0.9), pos(t).map((v) => v * 0.9), { color: "b", w: 1 }); } for (let k = 0; k < s.n; k++) { g.circle(pos(k), 0.08, { fill: hit.has(k) ? "a" : "muted", fo: 0.9, stroke: false }); g.text(pos(k).map((v) => v * 1.17), `${k}`, { dy: 4, size: s.n > 16 ? 9 : 11 }); } const inv = [...Array(s.n).keys()].find((x) => (s.a * x) % s.n === 1); g.text([1.6, 0.6], `gcd(${s.a}, ${s.n}) = ${gcd(s.a, s.n)}`, { anchor: "start", bold: true }); g.text([1.6, 0], inv !== undefined ? `역원 ${s.a}⁻¹ = ${inv}` : "역원 없음", { anchor: "start", bold: true, color: inv !== undefined ? "c" : "e" }); g.text([1.6, -0.6], "화살표: k → a·k mod n", { anchor: "start", size: 11, color: "muted" }); },
    metrics(s) { const hit = new Set([...Array(s.n).keys()].map((k) => (s.a * k) % s.n)); const ok = [...Array(s.n).keys()].filter((a) => a && gcd(a, s.n) === 1).length; return [["나오는 나머지 수", `${hit.size}/${s.n}`, "key"], [`mod ${s.n}에서 역원이 있는 a의 수`, `${ok}개`]]; },
    predict: [
      { q: "mod 12에서 5의 역원은? (5 × ? ≡ 1)", set: (s) => Object.assign(s, { n: 12, a: 4 }), reveal: (s) => (s.a = 5), answer: () => 5, why: "5 × 5 = 25 = 2 × 12 + 1이므로 5입니다." },
      { q: "mod 12에서 4를 곱하면 나오는 나머지는 몇 가지?", set: (s) => Object.assign(s, { n: 12, a: 5 }), reveal: (s) => (s.a = 4), answer: () => 3, why: "0, 4, 8만 나옵니다(gcd = 4)." },
    ],
  },
];
