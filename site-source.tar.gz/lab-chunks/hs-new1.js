// 23차 묶음 1 — 미적분Ⅱ 치환적분 + 공통수학1 다항식·복소수·방정식과 부등식·행렬
import { fmt, frac, poly, clamp } from "./hs-core.js";

const CM = 14, II = 13;
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const SUP = "⁰¹²³⁴⁵⁶⁷⁸⁹";
// 다항식 계수(높은 차수부터) → 문자열
function polyStr(cs, v = "x") {
  const n = cs.length - 1, t = cs.slice(0, n).map((c, i) => [c, n - i === 1 ? v : `${v}${SUP[n - i]}`]);
  return poly(t, cs[n]);
}
const simpson = (f, a, b, n = 200) => { const h = (b - a) / n; let s = f(a) + f(b); for (let i = 1; i < n; i++) s += f(a + i * h) * (i % 2 ? 4 : 2); return (s * h) / 3; };
// ax² + bx + c = 0의 두 근을 문자열로 (허근 포함)
function rootsStr(a, b, c) {
  const D = b * b - 4 * a * c, re = -b / (2 * a);
  if (Math.abs(D) < 1e-9) return { D, real: [re], s: `x = ${frac(re)} (중근)` };
  if (D > 0) { const r = Math.sqrt(D) / (2 * Math.abs(a)); return { D, real: [re - r, re + r], s: `x = ${fmt(re - r, 3)}, ${fmt(re + r, 3)}` }; }
  const im = Math.sqrt(-D) / (2 * Math.abs(a)), ims = fmt(im, 3) === "1" ? "" : fmt(im, 3);
  return { D, real: [], s: `x = ${Math.abs(re) < 1e-9 ? "" : frac(re) + " "}± ${ims}i`, re, im };
}
// 행렬 그리기: 왼쪽 위 (x, y), 칸 cw × ch, hl(i, j) → 색 이름
function matrix(g, x, y, M, o = {}) {
  const cw = o.cw || 1.25, ch = o.ch || 0.95, r = M.length, c = M[0].length, Wd = c * cw, Hd = r * ch;
  M.forEach((row, i) => row.forEach((v, j) => {
    const col = o.hl ? o.hl(i, j) : null, x0 = x + j * cw, y0 = y - i * ch;
    if (col) g.poly([[x0 + 0.05, y0 - 0.05], [x0 + cw - 0.05, y0 - 0.05], [x0 + cw - 0.05, y0 - ch + 0.05], [x0 + 0.05, y0 - ch + 0.05]], { fill: col, fo: 0.3, stroke: false });
    g.text([x0 + cw / 2, y0 - ch / 2], typeof v === "number" ? fmt(v, 2) : v, { dy: 5, bold: !!col, size: o.size || 15, color: o.color || "ink" });
  }));
  const br = 0.18;
  g.path([[x + br, y], [x, y], [x, y - Hd], [x + br, y - Hd]], { color: "ink", w: 2 });
  g.path([[x + Wd - br, y], [x + Wd, y], [x + Wd, y - Hd], [x + Wd - br, y - Hd]], { color: "ink", w: 2 });
  if (o.name) g.text([x + Wd / 2, y + 0.45], o.name, { bold: true, color: o.ncolor || "ink", size: 14 });
  return Wd;
}

// ───────── 치환적분 ─────────
const SUB = {
  cos: { n: "∫2x·cos(x²) dx", sub: "u = x²", g: (x) => x * x, gp: (x) => 2 * x, f: Math.cos, F: Math.sin, h: (x) => 2 * x * Math.cos(x * x), D: 1.25, hs: "2x·cos(x²)", fs: "cos u", gps: "2x" },
  sqrt: { n: "∫2x√(x² + 1) dx", sub: "u = x² + 1", g: (x) => x * x + 1, gp: (x) => 2 * x, f: Math.sqrt, F: (u) => (2 / 3) * u ** 1.5, h: (x) => 2 * x * Math.sqrt(x * x + 1), D: 1.5, hs: "2x√(x² + 1)", fs: "√u", gps: "2x" },
  ln: { n: "∫ln(x + 1)/(x + 1) dx", sub: "u = ln(x + 1)", g: (x) => Math.log(1 + x), gp: (x) => 1 / (1 + x), f: (u) => u, F: (u) => (u * u) / 2, h: (x) => Math.log(1 + x) / (1 + x), D: 3, hs: "ln(x + 1)/(x + 1)", fs: "u", gps: "1/(x + 1)" },
};
const STRIP = ["a", "b", "c", "d", "e", "f"];
function subGeom(K) {
  let hm = 0, fm = 0; const u0 = K.g(0), u1 = K.g(K.D);
  for (let i = 0; i <= 200; i++) { hm = Math.max(hm, K.h((K.D * i) / 200)); fm = Math.max(fm, K.f(u0 + ((u1 - u0) * i) / 200)); }
  return { kx: 12.4 / Math.max(K.D, u1 - u0), ky: 3.5 / Math.max(hm, fm), u0 };
}

// ───────── 조립제법 ─────────
const SYN = { a: [1, -6, 11, -6], b: [2, -3, 0, 5], c: [1, 0, -7, 6], d: [1, 2, -5, -6] };
function synth(cs, k) { const sums = [cs[0]], prods = [null]; for (let i = 1; i < cs.length; i++) { prods.push(k * sums[i - 1]); sums.push(cs[i] + prods[i]); } return { sums, prods }; }

// ───────── 항등식 ─────────
const IDL = { a: { n: "(x + 1)²", c: [1, 2, 1] }, b: { n: "(x − 2)(x + 3)", c: [1, 1, -6] }, c: { n: "(2x − 1)²", c: [4, -4, 1] } };

// ───────── 부등식 ─────────
const OPS = [[">", ">"], [">=", "≥"], ["<", "<"], ["<=", "≤"]];
const opS = (o) => ({ ">": ">", ">=": "≥", "<": "<", "<=": "≤" })[o];
// 반직선 x op a → {lo, hi, loC, hiC}
const ray = (op, a) => (op[0] === ">" ? { lo: a, loC: op === ">=", hi: Infinity, hiC: false } : { lo: -Infinity, loC: false, hi: a, hiC: op === "<=" });
function meet(A, B) {
  const lo = Math.max(A.lo, B.lo), hi = Math.min(A.hi, B.hi);
  const loC = lo === A.lo && lo === B.lo ? A.loC && B.loC : lo === A.lo ? A.loC : B.loC;
  const hiC = hi === A.hi && hi === B.hi ? A.hiC && B.hiC : hi === A.hi ? A.hiC : B.hiC;
  if (lo > hi || (lo === hi && !(loC && hiC))) return null;
  return { lo, hi, loC, hiC };
}
function ivStr(I) {
  if (!I) return "해가 없다";
  if (I.lo === I.hi) return `x = ${fmt(I.lo)}`;
  const L = Number.isFinite(I.lo) ? `${fmt(I.lo)} ${I.loC ? "≤" : "<"} ` : "", R = Number.isFinite(I.hi) ? ` ${I.hiC ? "≤" : "<"} ${fmt(I.hi)}` : "";
  if (!L && !R) return "모든 실수";
  if (!L) return `x${R}`;
  if (!R) return `x ${I.loC ? "≥" : ">"} ${fmt(I.lo)}`;
  return `${L}x${R}`;
}
function drawIv(g, I, y, color, o = {}) {
  if (!I) return;
  const x0 = Math.max(I.lo, g.xr[0] + 0.3), x1 = Math.min(I.hi, g.xr[1] - 0.3);
  if (I.lo === I.hi) { g.point([I.lo, y], "", { color, r: 6 }); return; }
  g.seg([x0, y], [x1, y], { color, w: o.w || 5 });
  if (!Number.isFinite(I.hi)) g.vec([x1 - 0.4, y], [x1, y], { color, w: o.w || 5 });
  if (!Number.isFinite(I.lo)) g.vec([x0 + 0.4, y], [x0, y], { color, w: o.w || 5 });
  if (Number.isFinite(I.lo)) g.point([I.lo, y], "", { color, hollow: !I.loC, r: 6 });
  if (Number.isFinite(I.hi)) g.point([I.hi, y], "", { color, hollow: !I.hiC, r: 6 });
}

// ───────── 행렬 자료 (학교 매점) ─────────
const ITEMS = ["빵", "우유", "주스"], DAYS = ["월", "화"];
const SALE = [[12, 15], [20, 18], [8, 11]];
const SEP = [[30, 42], [25, 38]], OCT = [[34, 40], [31, 45]];
const QTY = [[3, 5, 2], [4, 2, 6]], PRICE = [[12, 250], [9, 130], [15, 110]];
const MA = [[1, 2], [0, 1]], MB = [[1, 0], [3, 1]];
const mmul = (A, B) => A.map((r) => B[0].map((_, j) => r.reduce((t, v, k) => t + v * B[k][j], 0)));

export default [
  // ───────── 미적분Ⅱ Ⅳ-2 치환적분 ─────────
  {
    id: "calc2-substitution", grade: II, unit: 4, lesson: "Ⅳ-2", title: "치환적분 — x축의 넓이를 u축으로 옮기기", type: "조작", time: "12분",
    tags: ["치환적분", "정적분", "넓이"], links: ["calc2-parts", "calc-riemann", "calc2-chain"],
    desc: "위에는 y = f(g(x))·g′(x) 아래의 넓이를, 아래에는 u = g(x)로 바꾼 y = f(u) 아래의 넓이를 그립니다. 같은 색 띠끼리 짝을 지어 보면 폭은 g′(x)배로 바뀌지만 높이가 그만큼 반대로 바뀌어 넓이는 그대로임을 확인합니다.",
    obs: ["x축의 띠 하나의 폭 Δx는 u축에서 Δu ≈ g′(x)Δx로 바뀝니다.", "위 그래프의 높이 f(g(x))·g′(x)에 이미 g′(x)가 곱해져 있어 두 띠의 넓이가 같습니다.", "그래서 ∫ₐᵇ f(g(x))g′(x) dx = ∫ f(u) du이고, u의 구간은 g(a)부터 g(b)까지입니다."],
    q: "치환적분에서 적분 구간을 g(a)부터 g(b)까지로 바꾸어야 하는 까닭을 그림으로 설명해 봅시다.",
    formula: "∫ₐᵇ f(g(x))g′(x) dx = ∫ f(u) du (u: g(a) → g(b))",
    en: { title: "Integration by Substitution", desc: "Move area from the x-axis to the u-axis." },
    view: BOX,
    params: [
      { key: "fn", label: "적분", type: "select", value: "cos", options: Object.entries(SUB).map(([k, v]) => [k, `${v.n} (${v.sub})`]), rebuild: true },
      { key: "a", label: "아래끝 a", min: 0, max: (s) => SUB[s.fn].D, step: 0.01, value: 0 },
      { key: "b", label: "위끝 b", min: 0, max: (s) => SUB[s.fn].D, step: 0.01, value: 1 },
      { key: "n", label: "띠의 개수", min: 1, max: 24, step: 1, value: 6 },
      { key: "j", label: "살펴볼 띠", min: 1, max: (s) => s.n, step: 1, value: 3 },
    ],
    anim: { key: "b", min: 0.1, max: 1.25, speed: 0.3, loop: "bounce", label: "위끝 움직이기" },
    onChange(s, k) {
      const K = SUB[s.fn];
      if (k === "fn") { s.a = 0; s.b = Math.round(K.D * 80) / 100; }
      s.a = clamp(s.a, 0, K.D - 0.05); if (s.b < s.a + 0.05) s.b = Math.min(K.D, s.a + 0.05);
      this.anim.max = K.D; s.j = clamp(s.j, 1, s.n);
    },
    draw(s, g) {
      const K = SUB[s.fn], { kx, ky, u0 } = subGeom(K), X0 = 1.3, YT = 6.1, YB = 1.0;
      const PT = (x, y) => [X0 + x * kx, YT + y * ky], PB = (u, y) => [X0 + (u - u0) * kx, YB + y * ky];
      // 띠
      for (let i = 0; i < s.n; i++) {
        const x0 = s.a + ((s.b - s.a) * i) / s.n, x1 = s.a + ((s.b - s.a) * (i + 1)) / s.n, c = STRIP[i % 6], on = i === s.j - 1;
        const top = [], bot = [];
        for (let t = 0; t <= 12; t++) { const x = x0 + ((x1 - x0) * t) / 12; top.push(PT(x, K.h(x))); const u = K.g(x); bot.push(PB(u, K.f(u))); }
        g.poly([PT(x0, 0), ...top, PT(x1, 0)], { fill: c, fo: on ? 0.7 : 0.3, color: c, w: on ? 2.4 : 0.8, stroke: on || s.n <= 12 });
        g.poly([PB(K.g(x0), 0), ...bot, PB(K.g(x1), 0)], { fill: c, fo: on ? 0.7 : 0.3, color: c, w: on ? 2.4 : 0.8, stroke: on || s.n <= 12 });
      }
      // 축과 곡선
      [[YT, "x"], [YB, "u"]].forEach(([y, nm]) => { g.seg([X0 - 0.2, y], [X0 + 12.9, y], { color: "axis", w: 1.5 }); g.text([X0 + 13.2, y], nm, { dy: 5, italic: true, bold: true, color: "muted" }); g.seg([X0, y - 0.1], [X0, y + 3.9], { color: "axis", w: 1.2 }); });
      g.param((x) => PT(x, K.h(x)), 0, K.D, { color: "ink", w: 2.6 });
      g.param((t) => { const u = u0 + (K.g(K.D) - u0) * t; return PB(u, K.f(u)); }, 0, 1, { color: "ink", w: 2.6 });
      g.text(PT(s.a, 0), `a = ${fmt(s.a)}`, { dy: 17, size: 12, color: "muted" }).text(PT(s.b, 0), `b = ${fmt(s.b)}`, { dy: 17, size: 12, color: "muted" });
      g.text(PB(K.g(s.a), 0), `g(a) = ${fmt(K.g(s.a), 3)}`, { dy: 17, size: 12, color: "muted" }).text(PB(K.g(s.b), 0), `g(b) = ${fmt(K.g(s.b), 3)}`, { dy: 17, size: 12, color: "muted" });
      g.text([X0 + 0.2, YT + 4.3], `x축: y = ${K.hs}`, { anchor: "start", bold: true }).text([X0 + 0.2, YB + 4.15], `u축: y = ${K.fs}  (${K.sub})`, { anchor: "start", bold: true });
    },
    metrics(s) {
      const K = SUB[s.fn], I1 = simpson(K.h, s.a, s.b), I2 = K.F(K.g(s.b)) - K.F(K.g(s.a));
      const x0 = s.a + ((s.b - s.a) * (s.j - 1)) / s.n, x1 = x0 + (s.b - s.a) / s.n, du = K.g(x1) - K.g(x0), dx = x1 - x0;
      return [["x축 넓이 ∫ f(g(x))g′(x) dx", fmt(I1, 4)], ["u축 넓이 ∫ f(u) du", fmt(I2, 4)], ["두 넓이의 차", fmt(Math.abs(I1 - I2), 6), "key"], [`${s.j}번째 띠: Δu ÷ Δx`, `${fmt(du / dx, 3)} ≈ g′(x) = ${K.gps} = ${fmt(K.gp((x0 + x1) / 2), 3)}`]];
    },
    predict: [
      { q: "∫₀¹ 2x·cos(x²) dx의 값은? (소수 둘째 자리까지)", set: (s) => Object.assign(s, { fn: "cos", a: 0, b: 0.5, n: 6, j: 3 }), reveal: (s) => (s.b = 1), answer: () => Math.sin(1), tol: 0.01, why: "u = x²으로 바꾸면 u는 0부터 1까지이므로 ∫₀¹ cos u du = sin 1 ≈ 0.84입니다." },
      { q: "u = x² + 1로 치환하면 ∫₀¹ 2x√(x² + 1) dx는 u가 어느 구간에서의 적분이 될까요?", options: O("1부터 2까지", "0부터 1까지", "0부터 2까지"), set: (s) => Object.assign(s, { fn: "sqrt", a: 0, b: 1, n: 6, j: 3 }), answer: () => "a", why: "x = 0이면 u = 1, x = 1이면 u = 2입니다. 아래 그림의 색 띠가 1부터 2까지 놓입니다." },
      { q: "x축의 띠 폭이 Δx이면 u축에서 짝이 되는 띠의 폭은 약 몇 배가 될까요?", options: O("g′(x)배", "1배 (그대로)", "1/g′(x)배"), set: (s) => Object.assign(s, { fn: "cos", a: 0, b: 1.2, n: 8, j: 7 }), answer: () => "a", why: "Δu = g(x + Δx) − g(x) ≈ g′(x)Δx입니다. 대신 높이가 g′(x)로 나누어져 넓이는 같습니다." },
    ],
  },

  // ───────── 공통수학1 Ⅰ 다항식 ─────────
  {
    id: "cm1-synthetic", grade: CM, unit: 1, lesson: "Ⅰ-3", title: "조립제법 — 한 칸씩 내려 쓰고 곱해 올리기", type: "조작", time: "10분",
    tags: ["조립제법", "다항식의 나눗셈", "나머지정리"], links: ["cm1-remainder", "cm1-identity"],
    desc: "삼차식을 일차식 x − k로 나누는 조립제법을 한 단계씩 진행하며, 내려 쓴 수와 곱해 올린 수가 어떻게 몫의 계수와 나머지가 되는지 확인합니다. 마지막 수가 f(k)와 같은지도 비교합니다.",
    obs: ["맨 앞 계수는 그대로 내려 씁니다.", "내려 쓴 수에 k를 곱해 다음 칸에 더하는 일을 되풀이합니다.", "맨 끝의 수가 나머지이고, 나머지정리에 따라 f(k)와 같습니다."],
    q: "x − k가 아니라 2x − 1로 나눌 때는 조립제법을 어떻게 바꿔 써야 할까요?",
    formula: "f(x) = (x − k)Q(x) + R, R = f(k)",
    en: { title: "Synthetic Division", desc: "Bring down, multiply, add — step by step." },
    view: BOX,
    params: [
      { key: "p", label: "나누어지는 식 f(x)", type: "select", value: "a", options: Object.entries(SYN).map(([k, v]) => [k, polyStr(v)]) },
      { key: "k", label: "나누는 식 x − k의 k", min: -3, max: 3, step: 1, value: 2 },
      { key: "st", label: "단계", min: 0, max: 7, step: 1, value: 7 },
    ],
    anim: { key: "st", min: 0, max: 7, speed: 1.4, label: "한 단계씩 진행" },
    draw(s, g) {
      const cs = SYN[s.p], { sums, prods } = synth(cs, s.k), X = (i) => 4.6 + i * 2.6, Y1 = 8.6, Y2 = 6.9, Y3 = 5.2;
      const showSum = (i) => (i === 0 ? s.st >= 1 : s.st >= 2 * i + 1), showProd = (i) => s.st >= 2 * i;
      g.poly([[1.2, 9.4], [2.9, 9.4], [2.9, 7.8], [1.2, 7.8]], { fill: "a", fo: 0.16, color: "a", w: 1.6 });
      g.text([2.05, Y1], fmt(s.k), { dy: 6, bold: true, size: 20, color: "a" });
      g.seg([3.3, 9.5], [3.3, 6.2], { color: "ink", w: 2 }).seg([3.3, 6.2], [X(3) + 1.2, 6.2], { color: "ink", w: 2 });
      cs.forEach((c, i) => {
        g.text([X(i), Y1], fmt(c), { dy: 6, bold: true, size: 20 });
        if (i && showProd(i)) g.text([X(i), Y2], fmt(prods[i]), { dy: 6, size: 18, color: "b" });
        if (showSum(i)) g.text([X(i), Y3], fmt(sums[i]), { dy: 6, bold: true, size: 20, color: i === 3 ? "c" : "ink" });
      });
      g.poly([[X(3) - 1, 5.9], [X(3) + 1, 5.9], [X(3) + 1, 4.5], [X(3) - 1, 4.5]], { color: "c", w: 2, dash: "5 4", fill: s.st >= 7 ? "c" : null, fo: 0.12 });
      g.text([X(3), 4.0], "나머지", { size: 12, color: "c", bold: true });
      // 이번 단계의 화살표
      if (s.st === 1) g.vec([X(0), Y1 - 0.45], [X(0), Y3 + 0.45], { color: "a" });
      for (let i = 1; i <= 3; i++) {
        if (s.st === 2 * i) g.vec([X(i - 1) + 0.3, Y3 + 0.3], [X(i) - 0.4, Y2 - 0.25], { color: "b", label: `× ${fmt(s.k)}` });
        if (s.st === 2 * i + 1) { g.vec([X(i) + 0.75, Y1 - 0.3], [X(i) + 0.75, Y3 + 0.2], { color: "a", w: 2.4 }); g.text([X(i) + 0.95, (Y1 + Y3) / 2], "더하기", { anchor: "start", dy: 5, bold: true, size: 13, color: "a" }); }
      }
      const step = ["계수를 차례로 적고 시작합니다", "맨 앞 계수를 그대로 내려 씁니다", `내려 쓴 수에 ${fmt(s.k)}를 곱해 다음 칸에 씁니다`, "위아래를 더해 내려 씁니다"][s.st === 0 ? 0 : s.st === 1 ? 1 : s.st % 2 === 0 ? 2 : 3];
      g.text([1.2, 2.6], step, { anchor: "start", bold: true, size: 15 });
      if (s.st >= 7) g.text([1.2, 1.3], `몫 ${polyStr(sums.slice(0, 3))}, 나머지 ${fmt(sums[3])}`, { anchor: "start", size: 15, color: "c", bold: true });
    },
    metrics(s) {
      const cs = SYN[s.p], { sums } = synth(cs, s.k), fk = cs.reduce((t, c) => t * s.k + c, 0);
      if (s.st < 7) return [["나누는 식", s.k ? `x ${s.k > 0 ? "−" : "+"} ${Math.abs(s.k)}` : "x"], ["진행", `${s.st} / 7 단계`]];
      return [["몫 Q(x)", polyStr(sums.slice(0, 3))], ["나머지 R", fmt(sums[3])], [`f(${fmt(s.k)})`, `${fmt(fk)} ${fk === sums[3] ? "= R ✓" : ""}`, "key"]];
    },
    predict: [
      { q: "x³ − 6x² + 11x − 6을 x − 2로 나눈 나머지는?", set: (s) => Object.assign(s, { p: "a", k: 2, st: 3 }), reveal: (s) => (s.st = 7), answer: () => 0, why: "f(2) = 8 − 24 + 22 − 6 = 0이므로 x − 2는 인수입니다." },
      { q: "2x³ − 3x² + 5를 x − 2로 나눈 나머지는?", set: (s) => Object.assign(s, { p: "b", k: 2, st: 1 }), reveal: (s) => (s.st = 7), answer: () => 9, why: "조립제법의 마지막 수는 f(2) = 16 − 12 + 0 + 5 = 9입니다. 빠진 x항의 계수 0도 꼭 적어야 합니다." },
    ],
  },
  {
    id: "cm1-identity", grade: CM, unit: 1, lesson: "Ⅰ-3", title: "항등식 — 두 그래프가 완전히 포개질 때", type: "조작", time: "10분",
    tags: ["항등식", "계수비교법", "미정계수"], links: ["cm1-synthetic", "cm1-poly-area"],
    desc: "왼쪽 식은 고정하고 오른쪽 식 ax² + bx + c의 계수를 바꾸며 두 그래프를 겹쳐 봅니다. 몇 개의 x에서만 같은 '방정식'과 모든 x에서 같은 '항등식'을 구별하고, 계수가 모두 같아야 항등식임을 확인합니다.",
    obs: ["두 그래프가 만나는 점의 x좌표에서만 등식이 성립하면 방정식입니다.", "계수가 모두 같으면 두 그래프가 완전히 포개져 모든 x에서 성립합니다. 이것이 항등식입니다.", "이차 이하의 두 다항식이 서로 다른 세 x에서 같으면 항등식입니다."],
    q: "x에 0, 1, −1을 대입해 a, b, c를 구하는 방법(수치대입법)이 왜 통하는지 설명해 봅시다.",
    formula: "ax² + bx + c = a′x² + b′x + c′ (항등식) ⇔ a = a′, b = b′, c = c′",
    en: { title: "Identities", desc: "When two graphs overlap completely." },
    view: { x: [-4.5, 4.5], y: [-7, 9] },
    params: [
      { key: "L", label: "왼쪽 식", type: "select", value: "a", options: Object.entries(IDL).map(([k, v]) => [k, v.n]) },
      { key: "a", label: "a", min: -4, max: 4, step: 1, value: 1 },
      { key: "b", label: "b", min: -4, max: 4, step: 1, value: 0 },
      { key: "c", label: "c", min: -6, max: 6, step: 1, value: 3 },
    ],
    roots(s) { const [p, q, r] = IDL[s.L].c, A = s.a - p, B = s.b - q, C = s.c - r; if (!A && !B && !C) return "all"; if (!A) return B ? [-C / B] : []; const D = B * B - 4 * A * C; if (D < -1e-9) return []; if (Math.abs(D) < 1e-9) return [-B / (2 * A)]; return [(-B - Math.sqrt(D)) / (2 * A), (-B + Math.sqrt(D)) / (2 * A)]; },
    draw(s, g) {
      const [p, q, r] = IDL[s.L].c, f = (x) => p * x * x + q * x + r, h = (x) => s.a * x * x + s.b * x + s.c, R = this.roots(s);
      g.grid({ step: 1, every: 2 });
      g.fx(f, { color: "b", w: 7, opacity: 0.45 });
      g.fx(h, { color: "a", w: 2.6, dash: R === "all" ? "8 6" : false });
      if (R !== "all") R.forEach((x) => g.point([x, f(x)], `x = ${fmt(x, 2)}`, { color: "c" }));
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.8], `파랑: y = ${IDL[s.L].n}`, { anchor: "start", bold: true, color: "b" }).text([g.xr[0] + 0.3, g.yr[1] - 2], `주황: y = ${polyStr([s.a, s.b, s.c])}`, { anchor: "start", bold: true, color: "a" });
    },
    metrics(s) {
      const [p, q, r] = IDL[s.L].c, R = this.roots(s);
      return [["전개한 왼쪽 식", polyStr([p, q, r])], ["계수 비교", `a: ${s.a} | ${p}   b: ${s.b} | ${q}   c: ${s.c} | ${r}`], ["같아지는 x", R === "all" ? "모든 x — 항등식" : R.length ? `${R.length}개 — 방정식` : "없음", "key"]];
    },
    predict: [
      { q: "(x − 2)(x + 3) = ax² + bx + c가 항등식이 되려면 c는?", set: (s) => Object.assign(s, { L: "b", a: 1, b: 1, c: 0 }), reveal: (s) => (s.c = -6), answer: () => -6, why: "x = 0을 대입하면 (−2)·3 = c이므로 c = −6입니다." },
      { q: "이차 이하의 두 다항식이 서로 다른 세 x에서 값이 같다면?", options: O("항등식이다", "항등식이 아닐 수도 있다"), answer: () => "a", why: "두 식의 차는 이차 이하인데 근이 3개이므로 0인 다항식, 곧 계수가 모두 같습니다." },
    ],
  },

  // ───────── 공통수학1 Ⅱ 복소수와 이차방정식 ─────────
  {
    id: "cm1-i-power", grade: CM, unit: 2, lesson: "Ⅱ-1", title: "i의 거듭제곱 — 곱할 때마다 90°씩 돈다", type: "조작", time: "10분",
    tags: ["허수단위", "복소수", "거듭제곱"], links: ["cm1-complex-roots"],
    desc: "i, i², i³, i⁴, …가 i, −1, −i, 1로 네 개씩 되풀이되는 것을 화살표가 90°씩 도는 그림으로 확인합니다. 아무 복소수 z에 i를 곱해도 같은 회전이 일어나는지 점을 끌어 봅니다. (가로·세로를 실수부·허수부로 그린 복소평면은 교과서 밖 보충 그림입니다.)",
    obs: ["i² = −1이므로 i를 두 번 곱하면 방향이 반대가 됩니다.", "i⁴ = 1이므로 iⁿ은 n을 4로 나눈 나머지만 보면 됩니다.", "z = a + bi에 i를 곱하면 −b + ai가 되어 길이는 그대로, 방향은 90° 돕니다."],
    q: "i + i² + i³ + i⁴ = 0이 되는 까닭을 화살표로 설명해 봅시다.",
    formula: "i² = −1, i⁴ = 1, i⁴ᵏ⁺ʳ = iʳ",
    en: { title: "Powers of i", desc: "Each multiplication by i turns 90°." },
    view: { x: [-2.6, 2.6], y: [-1.8, 1.8] },
    init: () => ({ z: [1.2, 0.5] }),
    params: [
      { key: "mode", label: "보기", type: "seg", value: "pow", options: [["pow", "iⁿ"], ["rot", "z × i"]] },
      { key: "n", label: "곱한 횟수 n", min: 0, max: 12, step: 1, value: 3, when: (s) => s.mode === "pow" },
    ],
    anim: { key: "n", min: 0, max: 12, speed: 1.5, label: "i 곱하기", when: (s) => s.mode === "pow" },
    drags: { z: { at: (s) => (s.mode === "rot" ? s.z : null), move: (s, p) => (s.z = [clamp(Math.round(p[0] * 10) / 10, -1.6, 1.6), clamp(Math.round(p[1] * 10) / 10, -1.6, 1.6)]), label: "z", when: (s) => s.mode === "rot" } },
    draw(s, g) {
      g.grid({ step: 0.5, labels: false, xName: "실수", yName: "허수" });
      g.circle([0, 0], 1, { color: "muted", w: 1.2, dash: "5 5" });
      [[1, 0, "1"], [0, 1, "i"], [-1, 0, "−1"], [0, -1, "−i"]].forEach(([x, y, t]) => g.text([x * 1.18, y * 1.18], t, { dy: 5, bold: true, color: "muted", size: 15 }));
      if (s.mode === "pow") {
        const P = (k) => [Math.cos((k * Math.PI) / 2), Math.sin((k * Math.PI) / 2)];
        for (let k = 1; k <= s.n; k++) {
          const pts = []; for (let t = 0; t <= 20; t++) { const a = ((k - 1 + t / 20) * Math.PI) / 2, r = 0.55 + 0.04 * k; pts.push([r * Math.cos(a), r * Math.sin(a)]); }
          g.path(pts, { color: "b", w: 1.6, opacity: 0.4 + (0.6 * k) / Math.max(1, s.n) });
        }
        if (s.n) g.vec([0, 0], P(s.n - 1), { color: "muted", w: 2, opacity: 0.4 });
        g.vec([0, 0], P(s.n), { color: "a", w: 4, label: `i${s.n > 1 ? [...String(s.n)].map((d) => SUP[d]).join("") : s.n === 0 ? "⁰" : ""}` });
        g.note(14, 26, `i를 ${s.n}번 곱함 → ${s.n % 4 === 0 && s.n ? `${s.n / 4}바퀴` : `${s.n * 90}°`} 회전`, { bold: true });
      } else {
        const [a, b] = s.z, rot = [[a, b], [-b, a], [-a, -b], [b, -a]], nm = ["z", "iz", "i²z", "i³z"], cl = ["a", "b", "c", "d"];
        rot.forEach((p, k) => g.vec([0, 0], p, { color: cl[k], w: k ? 2.6 : 3.4, label: nm[k], opacity: k > 1 ? 0.55 : 1 }));
        g.arc([0, 0], rot[0], rot[1], { color: "b", r: 34, label: "90°" });
        g.point(s.z, "", { color: "a" });
      }
    },
    metrics(s) {
      if (s.mode === "pow") { const v = ["1", "i", "−1", "−i"][s.n % 4]; return [[`i^${s.n}`, v, "key"], ["n ÷ 4의 나머지", String(s.n % 4)], ["되풀이", "i → −1 → −i → 1"]]; }
      const [a, b] = s.z, cs = (x, y) => `${fmt(x)} ${y < 0 ? "−" : "+"} ${fmt(Math.abs(y))}i`;
      return [["z", cs(a, b)], ["iz = i(a + bi)", cs(-b, a), "key"], ["|z|와 |iz|", `${fmt(Math.hypot(a, b), 3)} = ${fmt(Math.hypot(a, b), 3)}`]];
    },
    predict: [
      { q: "i²⁰²⁶의 값은?", options: O("1", "i", "−1", "−i"), set: (s) => Object.assign(s, { mode: "pow", n: 4 }), reveal: (s) => (s.n = 2), answer: () => "c", why: "2026 = 4 × 506 + 2이므로 i²⁰²⁶ = i² = −1입니다." },
      { q: "i + i² + i³ + ⋯ + i¹⁰⁰의 값은?", set: (s) => Object.assign(s, { mode: "pow", n: 4 }), answer: () => 0, why: "i + i² + i³ + i⁴ = i − 1 − i + 1 = 0이 25번 되풀이되므로 합은 0입니다." },
      { q: "(1 + i) × i는?", options: O("−1 + i", "1 − i", "1 + i", "−1 − i"), set: (s) => Object.assign(s, { mode: "rot", z: [1, 1] }), answer: () => "a", why: "i + i² = i − 1 = −1 + i입니다. 화살표 z를 90° 돌린 iz와 같습니다." },
    ],
  },
  {
    id: "cm1-complex-roots", grade: CM, unit: 2, lesson: "Ⅱ-2", title: "x축과 만나지 않는 포물선의 근 — 켤레 복소수", type: "조작", time: "12분",
    tags: ["판별식", "허근", "켤레복소수"], links: ["cm1-discriminant", "cm1-i-power", "cm1-vieta"],
    desc: "y = x² − 2px + q의 꼭짓점을 위로 올려 그래프가 x축과 만나지 않게 하면, 이차방정식의 두 근은 p ± ki 꼴의 켤레 복소수가 됩니다. 오른쪽 아래 작은 복소평면에 두 근을 찍어 실근에서 허근으로 바뀌는 모습과, 그때도 두 근의 합과 곱이 2p와 q로 그대로인 것을 확인합니다.",
    obs: ["D/4 = p² − q < 0이면 그래프가 x축과 만나지 않고, 두 근은 서로 켤레인 허근입니다.", "두 허근은 실수부가 p로 같고, 허수부는 부호만 반대입니다.", "실근이든 허근이든 두 근의 합은 2p, 곱은 q입니다."],
    q: "실수 계수 이차방정식의 한 근이 2 + 3i이면 다른 한 근은 무엇일까요? 그 까닭은?",
    formula: "x² − 2px + q = 0, D/4 = p² − q < 0 ⇒ x = p ± √(q − p²) i",
    en: { title: "Complex Conjugate Roots", desc: "Roots of a parabola that misses the x-axis." },
    view: { x: [-4.2, 4.2], y: [-3, 5] },
    params: [
      { key: "p", label: "꼭짓점의 x좌표 p", min: -2, max: 2, step: 0.1, value: 1 },
      { key: "q", label: "상수항 q", min: -2, max: 5, step: 0.1, value: 2 },
    ],
    anim: { key: "q", min: -2, max: 5, speed: 1.2, loop: "bounce", label: "상수항 바꾸기" },
    draw(s, g) {
      const f = (x) => x * x - 2 * s.p * x + s.q, R = rootsStr(1, -2 * s.p, s.q);
      g.grid();
      g.fx(f, { color: "b", w: 3 });
      g.point([s.p, f(s.p)], "꼭짓점", { color: "b", dy: 18 });
      R.real.forEach((x) => g.point([x, 0], "", { color: "a" }));
      // 작은 복소평면
      // 작은 복소평면 (오른쪽 아래 빈 곳)
      const x1 = g.xr[1] - 0.15, x0 = x1 - 3.6, y0 = g.yr[0] + 0.15, y1 = y0 + 3.1, C = [(x0 + x1) / 2, y0 + 1.35], k = 0.42, Q = (re, im) => [C[0] + re * k, C[1] + im * k];
      g.poly([[x0, y0], [x1, y0], [x1, y1], [x0, y1]], { fill: "paper", fo: 0.95, color: "muted", w: 1.2, layer: "top" });
      g.seg([x0 + 0.15, C[1]], [x1 - 0.15, C[1]], { color: "axis", w: 1.2, layer: "top" }).seg([C[0], y0 + 0.15], [C[0], y1 - 0.55], { color: "axis", w: 1.2, layer: "top" });
      g.text([x0 + 0.15, y1 - 0.3], "복소평면 (보충)", { anchor: "start", dy: 4, size: 11, color: "muted", bold: true }).text([x1 - 0.15, C[1]], "실수", { anchor: "end", dy: -5, size: 10, color: "muted" }).text([C[0], y1 - 0.62], "허수", { anchor: "start", dx: 4, dy: 8, size: 10, color: "muted" });
      if (R.real.length) R.real.forEach((x, i) => g.point(Q(clamp(x, -3.8, 3.8), 0), i || R.real.length === 1 ? fmt(x, 2) : "", { color: "a", r: 4.5, size: 11, dy: i ? -8 : 16 }));
      else { const re = Math.abs(R.re) < 1e-9 ? "" : fmt(R.re, 2) + " ", im = fmt(R.im, 2) === "1" ? "" : fmt(R.im, 2), yy = Math.min(R.im, 1.6); g.seg(Q(R.re, yy), Q(R.re, -yy), { color: "c", w: 1.2, dash: "3 3", layer: "top" }); g.point(Q(R.re, yy), `${re}+ ${im}i`, { color: "c", r: 4.5, size: 11 }); g.point(Q(R.re, -yy), `${re}− ${im}i`, { color: "c", r: 4.5, size: 11, dy: 14 }); }
    },
    metrics(s) {
      const R = rootsStr(1, -2 * s.p, s.q), D4 = s.p * s.p - s.q;
      return [["D/4 = p² − q", fmt(D4, 2)], ["두 근", R.s, "key"], ["두 근의 합 · 곱", `${fmt(2 * s.p, 2)} · ${fmt(s.q, 2)}`], D4 < -1e-9 ? "그래프는 x축과 만나지 않고, 두 근은 켤레 복소수입니다." : "그래프가 x축과 만나는 점의 x좌표가 실근입니다."];
    },
    predict: [
      { q: "x² − 2x + 5 = 0의 두 근은?", options: O("1 ± 2i", "−1 ± 2i", "1 ± 4i"), set: (s) => Object.assign(s, { p: 1, q: 0 }), reveal: (s) => (s.q = 5), answer: () => "a", why: "x = 1 ± √(1 − 5) = 1 ± 2i입니다." },
      { q: "x² − 2x + 5 = 0의 두 근의 곱은?", set: (s) => Object.assign(s, { p: 1, q: 5 }), answer: () => 5, why: "(1 + 2i)(1 − 2i) = 1 + 4 = 5 = c/a입니다. 허근이어도 근과 계수의 관계가 성립합니다." },
    ],
  },
  {
    id: "cm1-vieta", grade: CM, unit: 2, lesson: "Ⅱ-3", title: "근과 계수의 관계 — 두 근의 한가운데는 대칭축", type: "조작", time: "10분",
    tags: ["근과 계수의 관계", "대칭축", "이차방정식"], links: ["cm1-complex-roots", "cm1-discriminant"],
    desc: "x축 위의 두 근 α, β를 끌어 옮기면 y = a(x − α)(x − β)가 따라 바뀝니다. 두 근의 합 α + β가 −b/a, 곱 αβ가 c/a와 같고, 두 근의 한가운데가 포물선의 대칭축임을 확인합니다.",
    obs: ["a(x − α)(x − β)를 전개하면 ax² − a(α + β)x + aαβ입니다.", "그래서 α + β = −b/a, αβ = c/a입니다.", "대칭축 x = −b/(2a)는 두 근의 평균 (α + β)/2입니다."],
    q: "두 근의 합이 4, 곱이 1인 이차방정식(x²의 계수 1)을 만들어 봅시다.",
    formula: "ax² + bx + c = 0의 두 근 α, β: α + β = −b/a, αβ = c/a",
    en: { title: "Sum and Product of Roots", desc: "The axis of symmetry lies midway between the roots." },
    view: { x: [-5, 5], y: [-4.5, 4.5] },
    params: [
      { key: "a", label: "x²의 계수 a", min: -2, max: 2, step: 0.5, value: 1 },
    ],
    init: () => ({ al: -1, be: 3 }),
    onChange(s) { if (s.a === 0) s.a = 0.5; },
    drags: {
      A: { at: (s) => [s.al, 0], move: (s, p) => (s.al = clamp(Math.round(p[0] * 2) / 2, -4.5, 4.5)), color: "a", label: "α" },
      B: { at: (s) => [s.be, 0], move: (s, p) => (s.be = clamp(Math.round(p[0] * 2) / 2, -4.5, 4.5)), color: "c", label: "β" },
    },
    draw(s, g) {
      const f = (x) => s.a * (x - s.al) * (x - s.be), m = (s.al + s.be) / 2;
      g.grid();
      g.fx(f, { color: "b", w: 3 });
      g.seg([m, g.yr[0]], [m, g.yr[1]], { color: "e", w: 1.6, dash: "7 5" });
      g.text([m, g.yr[1] - 0.4], `대칭축 x = ${fmt(m, 2)}`, { bold: true, color: "e", size: 13 });
      g.point([s.al, 0], "α", { color: "a", dy: 22 }).point([s.be, 0], "β", { color: "c", dy: 22 });
      g.point([m, f(m)], "", { color: "b", r: 4 });
    },
    metrics(s) {
      const b = -s.a * (s.al + s.be), c = s.a * s.al * s.be;
      return [["식", `y = ${polyStr([s.a, b, c])}`], ["α + β = −b/a", `${fmt(s.al + s.be)} = ${fmt(-b / s.a)}`, "key"], ["αβ = c/a", `${fmt(s.al * s.be)} = ${fmt(c / s.a)}`], ["두 근의 평균", fmt((s.al + s.be) / 2, 2)]];
    },
    predict: [
      { q: "두 근이 −1, 3인 포물선의 대칭축은 x = ?", set: (s) => Object.assign(s, { al: -1, be: 3, a: 1 }), answer: () => 1, why: "대칭축은 두 근의 평균 (−1 + 3)/2 = 1입니다." },
      { q: "x² − 6x + 4 = 0의 두 근의 합은?", set: (s) => Object.assign(s, { a: 1, al: 0, be: 0 }), reveal: (s) => Object.assign(s, { al: 3 - Math.sqrt(5), be: 3 + Math.sqrt(5) }), answer: () => 6, why: "−b/a = −(−6)/1 = 6입니다. 근을 직접 구하지 않아도 됩니다." },
    ],
  },

  // ───────── 공통수학1 Ⅳ 여러 가지 방정식과 부등식 ─────────
  {
    id: "cm1-cubic-roots", grade: CM, unit: 4, lesson: "Ⅳ-1", title: "삼차방정식의 실근 — 그래프가 x축을 몇 번 지날까", type: "조작", time: "12분",
    tags: ["삼차방정식", "인수정리", "허근"], links: ["cm1-synthetic", "cm1-complex-roots"],
    desc: "f(x) = (x − r)(x² + bx + c)의 그래프가 x축과 만나는 횟수로 실근의 개수를 셉니다. 뒤쪽 이차식의 판별식이 음수이면 실근은 r 하나이고, 나머지 두 근은 켤레 복소수가 됨을 확인합니다.",
    obs: ["삼차방정식은 복소수 범위에서 항상 근이 3개(중근 포함)입니다.", "실수 계수 삼차방정식은 실근을 적어도 하나 가집니다. 그래프가 반드시 x축을 지나기 때문입니다.", "x² + bx + c의 판별식이 음수면 실근 1개와 켤레 허근 2개입니다."],
    q: "x³ = 1의 세 근을 모두 구하고, 그중 허근 ω가 ω² + ω + 1 = 0을 만족하는 까닭을 설명해 봅시다.",
    formula: "(x − r)(x² + bx + c) = 0 ⇔ x = r 또는 x² + bx + c = 0",
    en: { title: "Real Roots of a Cubic", desc: "Count how many times the graph crosses the x-axis." },
    view: { x: [-4.5, 4.5], y: [-6, 6] },
    params: [
      { key: "r", label: "알고 있는 근 r", min: -2, max: 2, step: 0.5, value: 1 },
      { key: "b", label: "b", min: -3, max: 3, step: 0.5, value: 1 },
      { key: "c", label: "c", min: -3, max: 4, step: 0.5, value: 1 },
    ],
    anim: { key: "c", min: -3, max: 4, speed: 1.2, loop: "bounce", label: "c 바꾸기" },
    draw(s, g) {
      const f = (x) => (x - s.r) * (x * x + s.b * x + s.c), R = rootsStr(1, s.b, s.c);
      g.grid({ every: 2 });
      g.fx(f, { color: "b", w: 3 });
      g.point([s.r, 0], "r", { color: "a", dy: 22 });
      R.real.forEach((x) => g.point([x, 0], "", { color: "c" }));
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], `y = ${s.r ? `(x ${s.r < 0 ? "+" : "−"} ${fmt(Math.abs(s.r))})` : "x"}(${polyStr([1, s.b, s.c])})`, { anchor: "start", bold: true });
    },
    metrics(s) {
      const R = rootsStr(1, s.b, s.c), real = new Set([s.r, ...R.real].map((x) => fmt(x, 3)));
      return [["이차식의 판별식 b² − 4c", fmt(R.D, 2)], ["이차식의 근", R.s], ["서로 다른 실근의 개수", String(real.size), "key"]];
    },
    predict: [
      { q: "x³ − 1 = (x − 1)(x² + x + 1) = 0의 서로 다른 실근은 몇 개?", set: (s) => Object.assign(s, { r: 1, b: 1, c: -2 }), reveal: (s) => Object.assign(s, { r: 1, b: 1, c: 1 }), answer: () => 1, why: "x² + x + 1의 판별식은 1 − 4 < 0이라 허근 2개이고, 실근은 x = 1 하나입니다." },
      { q: "x³ − 1 = 0의 두 허근의 합은?", set: (s) => Object.assign(s, { r: 1, b: 1, c: 1 }), answer: () => -1, why: "두 허근은 x² + x + 1 = 0의 근이므로 합은 −1입니다." },
    ],
  },
  {
    id: "cm1-two-numbers", grade: CM, unit: 4, lesson: "Ⅳ-2", title: "합과 곱이 주어진 두 수 — 직선과 쌍곡선의 교점", type: "조작", time: "10분",
    tags: ["연립이차방정식", "근과 계수의 관계", "대칭"], links: ["cm1-vieta", "cm1-quad-line"],
    desc: "x + y = s(직선)와 xy = p(반비례 그래프)를 함께 그려 연립이차방정식의 해를 교점으로 찾습니다. 해가 직선 y = x에 대해 대칭으로 짝지어 나오고, t² − st + p = 0의 판별식으로 해의 개수를 미리 알 수 있음을 확인합니다.",
    obs: ["x와 y는 이차방정식 t² − st + p = 0의 두 근입니다.", "그래서 해 (α, β)가 있으면 (β, α)도 해입니다. 두 교점은 y = x에 대해 대칭입니다.", "s² − 4p < 0이면 실수인 해가 없고, 직선과 곡선이 만나지 않습니다."],
    q: "둘레가 20, 넓이가 30인 직사각형의 가로와 세로를 이 방법으로 구해 봅시다.",
    formula: "x + y = s, xy = p ⇒ x, y는 t² − st + p = 0의 두 근",
    en: { title: "Two Numbers from Their Sum and Product", desc: "Intersect a line with a hyperbola." },
    view: { x: [-5, 5], y: [-4.5, 4.5] },
    params: [
      { key: "s", label: "합 x + y = s", min: -4, max: 4, step: 0.5, value: 4 },
      { key: "p", label: "곱 xy = p", min: -3, max: 4, step: 0.5, value: 3 },
    ],
    anim: { key: "p", min: -3, max: 4, speed: 1, loop: "bounce", label: "곱 바꾸기" },
    draw(s, g) {
      g.grid();
      g.line([0, 0], [1, 1], { color: "muted", w: 1.2, dash: "4 5" });
      g.text([3.8, 4.2], "y = x", { size: 12, color: "muted" });
      if (s.p) { g.fx((x) => s.p / x, { color: "b", w: 3, from: g.xr[0], to: -0.02 }); g.fx((x) => s.p / x, { color: "b", w: 3, from: 0.02, to: g.xr[1] }); }
      else { g.seg([g.xr[0], 0], [g.xr[1], 0], { color: "b", w: 3 }).seg([0, g.yr[0]], [0, g.yr[1]], { color: "b", w: 3 }); }
      g.lineABC(1, 1, -s.s, { color: "a", w: 3 });
      const D = s.s * s.s - 4 * s.p;
      if (D >= -1e-9) { const r = Math.sqrt(Math.max(0, D)), t1 = (s.s - r) / 2, t2 = (s.s + r) / 2; g.point([t1, t2], `(${fmt(t1, 2)}, ${fmt(t2, 2)})`, { color: "c" }); if (r > 1e-9) g.point([t2, t1], `(${fmt(t2, 2)}, ${fmt(t1, 2)})`, { color: "c", dy: 20 }); }
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], `주황: x + y = ${fmt(s.s)}`, { anchor: "start", bold: true, color: "a" }).text([g.xr[0] + 0.3, g.yr[1] - 1.3], `파랑: xy = ${fmt(s.p)}`, { anchor: "start", bold: true, color: "b" });
    },
    metrics(s) {
      const D = s.s * s.s - 4 * s.p, R = rootsStr(1, -s.s, s.p);
      return [["t² − st + p = 0", `t² ${s.s > 0 ? "−" : "+"} ${fmt(Math.abs(s.s))}t ${s.p < 0 ? "−" : "+"} ${fmt(Math.abs(s.p))} = 0`], ["판별식 s² − 4p", fmt(D, 2)], ["실수인 해", D < -1e-9 ? "없음" : Math.abs(D) < 1e-9 ? "1쌍 (x = y)" : "2쌍 (자리 바꿈)", "key"], ["t의 값", R.s.replace(/x/g, "t")]];
    },
    predict: [
      { q: "x + y = 4, xy = 3의 해는?", options: O("(1, 3), (3, 1)", "(2, 2)", "(−1, 5), (5, −1)"), set: (s) => Object.assign(s, { s: 4, p: -3 }), reveal: (s) => (s.p = 3), answer: () => "a", why: "t² − 4t + 3 = (t − 1)(t − 3) = 0이므로 x, y는 1과 3입니다." },
      { q: "합이 2, 곱이 2인 실수 두 개가 있을까요?", options: O("없다", "있다"), set: (s) => Object.assign(s, { s: 2, p: 0 }), reveal: (s) => (s.p = 2), answer: () => "a", why: "판별식 4 − 8 < 0이라 직선과 곡선이 만나지 않습니다." },
    ],
  },
  {
    id: "cm1-ineq-system", grade: CM, unit: 4, lesson: "Ⅳ-3", title: "연립부등식과 절댓값 부등식 — 수직선에서 겹쳐 보기", type: "조작", time: "10분",
    tags: ["연립일차부등식", "절댓값", "수직선"], links: ["cm1-quad-ineq"],
    desc: "두 부등식의 해를 수직선 위에 따로 그린 뒤 겹치는 부분을 찾아 연립부등식의 해를 구합니다. 절댓값 부등식 |x − a| < b는 'a까지의 거리가 b보다 작은 점'으로 읽어 봅니다.",
    obs: ["연립부등식의 해는 두 해가 겹치는 부분(공통부분)입니다.", "끝점에 등호가 있으면 속이 찬 점, 없으면 빈 점으로 나타냅니다.", "|x − a|는 수직선에서 x와 a 사이의 거리입니다."],
    q: "|x − a| > b의 해는 왜 두 부분으로 나뉠까요?",
    formula: "|x − a| < b ⇔ a − b < x < a + b (b > 0)",
    en: { title: "Systems and Absolute-Value Inequalities", desc: "Overlap solution sets on a number line." },
    view: { x: [-6.5, 6.5], y: [-2.6, 2.4] },
    params: [
      { key: "mode", label: "부등식", type: "seg", value: "sys", options: [["sys", "연립일차부등식"], ["abs", "절댓값 부등식"]] },
      { key: "o1", label: "첫째: x ○ a", type: "select", value: ">", options: OPS, when: (s) => s.mode === "sys" },
      { key: "a", label: "a", min: -5, max: 5, step: 0.5, value: -1 },
      { key: "o2", label: "둘째: x ○ c", type: "select", value: "<=", options: OPS, when: (s) => s.mode === "sys" },
      { key: "c", label: "c", min: -5, max: 5, step: 0.5, value: 3, when: (s) => s.mode === "sys" },
      { key: "ao", label: "|x − a| ○ b", type: "select", value: "<", options: OPS, when: (s) => s.mode === "abs" },
      { key: "b", label: "b", min: 0, max: 5, step: 0.5, value: 2, when: (s) => s.mode === "abs" },
    ],
    sol(s) {
      if (s.mode === "sys") { const A = ray(s.o1, s.a), B = ray(s.o2, s.c); return { A, B, M: [meet(A, B)] }; }
      const lt = s.ao[0] === "<", eq = s.ao.length > 1;
      if (lt) return { M: [s.b === 0 && !eq ? null : { lo: s.a - s.b, hi: s.a + s.b, loC: eq, hiC: eq }] };
      if (s.b === 0 && eq) return { M: [{ lo: -Infinity, hi: Infinity }] };
      return { M: [{ lo: -Infinity, hi: s.a - s.b, hiC: eq }, { lo: s.a + s.b, loC: eq, hi: Infinity }] };
    },
    draw(s, g) {
      const R = this.sol(s);
      g.seg([g.xr[0] + 0.2, 0], [g.xr[1] - 0.2, 0], { color: "axis", w: 1.6 });
      for (let x = -6; x <= 6; x++) { g.seg([x, -0.12], [x, 0.12], { color: "axis", w: 1.2 }); g.text([x, 0], String(x).replace("-", "−"), { dy: 22, size: 12, color: "muted" }); }
      if (s.mode === "sys") {
        drawIv(g, R.A, 1.5, "a"); drawIv(g, R.B, 0.85, "b");
        g.text([g.xr[0] + 0.3, 1.5], `x ${opS(s.o1)} ${fmt(s.a)}`, { anchor: "start", dy: -10, bold: true, color: "a" });
        g.text([g.xr[0] + 0.3, 0.85], `x ${opS(s.o2)} ${fmt(s.c)}`, { anchor: "start", dy: -10, bold: true, color: "b" });
      } else {
        g.point([s.a, 1.2], "a", { color: "e", dy: -12, dx: -4 });
        if (s.b > 0) { g.vec([s.a, 1.2], [s.a - s.b, 1.2], { color: "e", w: 2 }); g.vec([s.a, 1.2], [s.a + s.b, 1.2], { color: "e", w: 2 }); g.text([s.a + s.b / 2, 1.2], `거리 ${fmt(s.b)}`, { dy: -10, size: 12, color: "e" }); }
      }
      R.M.forEach((I) => drawIv(g, I, -1.15, "c", { w: 7 }));
      g.text([g.xr[0] + 0.3, -1.15], "해", { anchor: "start", dy: -12, bold: true, color: "c" });
    },
    metrics(s) {
      const R = this.sol(s), txt = R.M.every((I) => !I) ? "해가 없다" : R.M.filter(Boolean).map(ivStr).join(" 또는 ");
      const ints = R.M.filter(Boolean).reduce((t, I) => { if (!Number.isFinite(I.lo) || !Number.isFinite(I.hi)) return Infinity; let k = 0; for (let x = Math.ceil(I.lo); x <= Math.floor(I.hi); x++) if ((x > I.lo || I.loC) && (x < I.hi || I.hiC)) k++; return t + k; }, 0);
      return [[s.mode === "sys" ? "연립부등식" : "부등식", s.mode === "sys" ? `x ${opS(s.o1)} ${fmt(s.a)}, x ${opS(s.o2)} ${fmt(s.c)}` : `|x ${s.a < 0 ? "+" : "−"} ${fmt(Math.abs(s.a))}| ${opS(s.ao)} ${fmt(s.b)}`], ["해", txt, "key"], ["해 속의 정수", ints === Infinity ? "무수히 많다" : `${ints}개`]];
    },
    predict: [
      { q: "x > −1, x ≤ 3을 함께 만족하는 정수는 몇 개?", set: (s) => Object.assign(s, { mode: "sys", o1: ">", a: -1, o2: "<=", c: 5 }), reveal: (s) => (s.c = 3), answer: () => 4, why: "해는 −1 < x ≤ 3이므로 정수는 0, 1, 2, 3의 4개입니다." },
      { q: "|x − 1| < 3의 해는?", options: O("−2 < x < 4", "x < −2 또는 x > 4", "−4 < x < 2"), set: (s) => Object.assign(s, { mode: "abs", a: 1, ao: "<", b: 0 }), reveal: (s) => (s.b = 3), answer: () => "a", why: "1까지의 거리가 3보다 작은 점이므로 1 − 3 < x < 1 + 3입니다." },
    ],
  },

  // ───────── 공통수학1 Ⅵ 행렬 ─────────
  {
    id: "cm1-matrix-meaning", grade: CM, unit: 6, lesson: "Ⅵ-1", title: "행렬의 뜻 — 매점 판매표를 수의 묶음으로", type: "조작", time: "10분",
    tags: ["행렬", "성분", "행과 열"], links: ["cm1-matrix-add", "cm1-matrix-mul"],
    desc: "학교 매점의 요일별 판매표에서 제목을 떼어 내고 수만 괄호로 묶으면 행렬이 됩니다. 가로줄(행)과 세로줄(열)을 골라 (i, j) 성분이 무엇을 뜻하는지 읽어 봅니다.",
    obs: ["가로줄을 행, 세로줄을 열이라 하고, 행이 m개·열이 n개이면 m × n 행렬입니다.", "i행 j열에 있는 수를 (i, j) 성분 aᵢⱼ라 합니다.", "같은 수라도 행과 열의 뜻(품목·요일)을 알아야 읽을 수 있습니다."],
    q: "판매표의 행과 열을 바꾸어 적으면 어떤 행렬이 될까요? 성분의 뜻은 어떻게 바뀔까요?",
    formula: "A = (aᵢⱼ), aᵢⱼ = i행 j열의 성분",
    en: { title: "What Is a Matrix?", desc: "Turn a school-store sales table into a matrix." },
    view: BOX,
    params: [
      { key: "i", label: "행 i (품목)", min: 1, max: 3, step: 1, value: 2 },
      { key: "j", label: "열 j (요일)", min: 1, max: 2, step: 1, value: 1 },
      { key: "asM", label: "제목을 떼고 행렬로 보기", type: "check", value: false },
    ],
    draw(s, g) {
      const x0 = 6.2, y0 = 8.6, cw = 2.2, ch = 1.5;
      if (!s.asM) {
        DAYS.forEach((d, j) => g.text([x0 + j * cw + cw / 2, y0 + 0.55], `${d}요일`, { bold: true, color: j === s.j - 1 ? "c" : "muted" }));
        ITEMS.forEach((t, i) => g.text([x0 - 0.3, y0 - i * ch - ch / 2], t, { anchor: "end", dy: 5, bold: true, color: i === s.i - 1 ? "b" : "muted" }));
        for (let i = 0; i <= 3; i++) g.seg([x0 - 2.2, y0 - i * ch], [x0 + 2 * cw, y0 - i * ch], { color: "grid", w: 1.4 });
        g.seg([x0, y0 + 1], [x0, y0 - 3 * ch], { color: "grid", w: 1.4 });
        g.text([x0 - 1.2, y0 + 0.55], "품목", { color: "muted", size: 12 });
      } else { g.text([x0 - 1.1, y0 - 1.5 * ch], "A =", { anchor: "end", dy: 6, bold: true, size: 18 }); ["1행", "2행", "3행"].forEach((t, i) => g.text([x0 - 2.6, y0 - i * ch - ch / 2], t, { dy: 5, size: 11, color: i === s.i - 1 ? "b" : "muted" })); ["1열", "2열"].forEach((t, j) => g.text([x0 + j * cw + cw / 2, y0 + 0.5], t, { size: 11, color: j === s.j - 1 ? "c" : "muted" })); }
      matrix(g, x0, y0, SALE, { cw, ch, size: 18, hl: (i, j) => (i === s.i - 1 && j === s.j - 1 ? "a" : i === s.i - 1 ? "b" : j === s.j - 1 ? "c" : null) });
      g.text([1, 2.4], `a${"₀₁₂₃"[s.i]}${"₀₁₂₃"[s.j]} = ${SALE[s.i - 1][s.j - 1]}  →  ${DAYS[s.j - 1]}요일에 팔린 ${ITEMS[s.i - 1]}의 개수`, { anchor: "start", bold: true, size: 15, color: "a" });
    },
    metrics(s) { return [[`(${s.i}, ${s.j}) 성분`, String(SALE[s.i - 1][s.j - 1]), "key"], ["뜻", `${DAYS[s.j - 1]}요일 · ${ITEMS[s.i - 1]} 판매량`], ["행렬의 꼴", "3 × 2 (3행 2열)"]]; },
    predict: [
      { q: "판매표 행렬 A의 (3, 2) 성분은?", set: (s) => Object.assign(s, { i: 1, j: 1, asM: true }), reveal: (s) => Object.assign(s, { i: 3, j: 2 }), answer: () => 11, why: "3행은 주스, 2열은 화요일이므로 화요일에 팔린 주스 11개입니다." },
      { q: "행이 2개, 열이 3개인 행렬의 성분은 모두 몇 개?", answer: () => 6, why: "2 × 3 행렬은 2 × 3 = 6개의 성분을 가집니다." },
    ],
  },
  {
    id: "cm1-matrix-add", grade: CM, unit: 6, lesson: "Ⅵ-2", title: "행렬의 덧셈·뺄셈·실수배 — 같은 자리끼리", type: "조작", time: "10분",
    tags: ["행렬의 덧셈", "실수배", "성분"], links: ["cm1-matrix-meaning", "cm1-matrix-mul"],
    desc: "9월(A)과 10월(B) 학급별 매점 판매량 행렬을 더하고 빼고, 판매량을 k배 늘려 봅니다. 같은 자리의 성분끼리만 계산된다는 것을 칸을 골라 확인합니다.",
    obs: ["꼴이 같은 행렬끼리만 더하거나 뺄 수 있습니다.", "A + B의 (i, j) 성분은 aᵢⱼ + bᵢⱼ입니다.", "kA는 모든 성분에 k를 곱한 행렬입니다."],
    q: "B − A는 무엇을 뜻할까요? 음수 성분이 나오면 어떻게 읽어야 할까요?",
    formula: "(A ± B)ᵢⱼ = aᵢⱼ ± bᵢⱼ, (kA)ᵢⱼ = k·aᵢⱼ",
    en: { title: "Adding Matrices and Scalar Multiples", desc: "Combine entries in the same position." },
    view: BOX,
    params: [
      { key: "op", label: "계산", type: "seg", value: "add", options: [["add", "A + B"], ["sub", "B − A"], ["k", "kA"]] },
      { key: "k", label: "k", min: 0.5, max: 3, step: 0.5, value: 2, when: (s) => s.op === "k" },
      { key: "i", label: "행 i", min: 1, max: 2, step: 1, value: 2 },
      { key: "j", label: "열 j", min: 1, max: 2, step: 1, value: 1 },
    ],
    res(s) { return s.op === "add" ? SEP.map((r, i) => r.map((v, j) => v + OCT[i][j])) : s.op === "sub" ? SEP.map((r, i) => r.map((v, j) => OCT[i][j] - v)) : SEP.map((r) => r.map((v) => s.k * v)); },
    draw(s, g) {
      const hl = (i, j) => (i === s.i - 1 && j === s.j - 1 ? "a" : null), Y = 7.4, R = this.res(s);
      g.text([1, 10.2], "행: 1반, 2반  ·  열: 빵, 우유", { anchor: "start", size: 12, color: "muted" });
      if (s.op === "k") {
        g.text([1.6, Y - 0.95], fmt(s.k), { dy: 6, bold: true, size: 20, color: "b" });
        matrix(g, 2.6, Y, SEP, { hl, name: "A (9월)" });
        g.text([6.2, Y - 0.95], "=", { dy: 6, size: 22, bold: true });
        matrix(g, 7.2, Y, R, { hl, cw: 1.6, name: `${fmt(s.k)}A` });
      } else {
        const [L, Rm] = s.op === "add" ? [[SEP, "A (9월)"], [OCT, "B (10월)"]] : [[OCT, "B (10월)"], [SEP, "A (9월)"]];
        matrix(g, 0.8, Y, L[0], { hl, name: L[1] });
        g.text([4.1, Y - 0.95], s.op === "add" ? "+" : "−", { dy: 7, size: 24, bold: true });
        matrix(g, 4.9, Y, Rm[0], { hl, name: Rm[1] });
        g.text([8.3, Y - 0.95], "=", { dy: 7, size: 24, bold: true });
        matrix(g, 9.2, Y, R, { hl, name: s.op === "add" ? "A + B" : "B − A" });
      }
      const a = SEP[s.i - 1][s.j - 1], b = OCT[s.i - 1][s.j - 1], r = R[s.i - 1][s.j - 1];
      const t = s.op === "add" ? `${a} + ${b} = ${r}` : s.op === "sub" ? `${b} − ${a} = ${fmt(r)}` : `${fmt(s.k)} × ${a} = ${fmt(r)}`;
      g.text([1, 3.2], `(${s.i}, ${s.j}) 성분: ${t}`, { anchor: "start", bold: true, size: 16, color: "a" });
      g.text([1, 2.0], s.op === "add" ? "두 달 동안의 판매량" : s.op === "sub" ? "9월보다 늘어난 판매량 (음수면 줄어듦)" : `판매량이 ${fmt(s.k)}배가 되었을 때`, { anchor: "start", size: 14, color: "muted" });
    },
    metrics(s) { const R = this.res(s); return [[`(${s.i}, ${s.j}) 성분`, fmt(R[s.i - 1][s.j - 1]), "key"], ["행렬의 꼴", "2 × 2 (같은 꼴끼리 계산)"]]; },
    predict: [
      { q: "A + B의 (2, 1) 성분은?", set: (s) => Object.assign(s, { op: "add", i: 1, j: 1 }), reveal: (s) => Object.assign(s, { i: 2, j: 1 }), answer: () => 56, why: "2반의 빵 판매량 25 + 31 = 56입니다." },
      { q: "2A의 (1, 2) 성분은?", set: (s) => Object.assign(s, { op: "k", k: 1, i: 1, j: 2 }), reveal: (s) => (s.k = 2), answer: () => 84, why: "모든 성분에 2를 곱하므로 2 × 42 = 84입니다." },
    ],
  },
  {
    id: "cm1-matrix-mul", grade: CM, unit: 6, lesson: "Ⅵ-3", title: "행렬의 곱셈 — 수량 × 가격 = 매출", type: "조작", time: "12분",
    tags: ["행렬의 곱셈", "교환법칙", "성분"], links: ["cm1-matrix-add", "ai-image-transform"],
    desc: "학급별 구입 수량 행렬과 품목별 가격·열량 행렬을 곱해, 학급별 총액과 총열량을 한 번에 구합니다. 앞 행렬의 행과 뒤 행렬의 열을 짝지어 곱해 더하는 과정을 칸마다 확인하고, AB와 BA가 다를 수 있음을 봅니다.",
    obs: ["AB의 (i, j) 성분은 A의 i행과 B의 j열에서 같은 자리끼리 곱해 더한 값입니다.", "(m × n)(n × p) = m × p: 앞 행렬의 열 수와 뒤 행렬의 행 수가 같아야 곱할 수 있습니다.", "AB = BA가 항상 성립하지는 않습니다."],
    q: "수량 행렬과 가격 행렬의 순서를 바꾸어 곱하면 왜 뜻이 없어질까요?",
    formula: "(AB)ᵢⱼ = aᵢ₁b₁ⱼ + aᵢ₂b₂ⱼ + ⋯ + aᵢₙbₙⱼ",
    en: { title: "Matrix Multiplication", desc: "Quantity × price = sales." },
    view: BOX,
    params: [
      { key: "mode", label: "보기", type: "seg", value: "sale", options: [["sale", "매점 계산"], ["order", "AB와 BA"]] },
      { key: "i", label: "행 i", min: 1, max: 2, step: 1, value: 1 },
      { key: "j", label: "열 j", min: 1, max: 2, step: 1, value: 1 },
    ],
    draw(s, g) {
      const I = s.i - 1, J = s.j - 1, Y = 7.8;
      const hA = (i) => (i === I ? "b" : null), hB = (_, j) => (j === J ? "c" : null), hC = (i, j) => (i === I && j === J ? "a" : null);
      if (s.mode === "sale") {
        const C = mmul(QTY, PRICE);
        g.text([0.6, 10.45], "A: 학급(1반, 2반)별 빵·우유·주스 구입 수량", { anchor: "start", size: 12, color: "muted" }).text([0.6, 9.85], "B: 품목별 가격(백 원)과 열량(kcal)", { anchor: "start", size: 12, color: "muted" });
        matrix(g, 0.6, Y, QTY, { cw: 1.05, hl: (i) => hA(i), name: "A (2 × 3)" });
        g.text([4.1, Y - 1.2], "×", { dy: 7, size: 22, bold: true });
        matrix(g, 4.7, Y + 0.45, PRICE, { cw: 1.35, hl: hB, name: "B (3 × 2)" });
        g.text([8.0, Y - 1.2], "=", { dy: 7, size: 22, bold: true });
        matrix(g, 8.6, Y, C, { cw: 1.7, hl: hC, name: "AB (2 × 2)" });
        const terms = QTY[I].map((v, k) => `${v}×${PRICE[k][J]}`).join(" + ");
        g.text([0.6, 2.9], `(${s.i}, ${s.j}) 성분 = ${terms} = ${C[I][J]}`, { anchor: "start", bold: true, size: 15, color: "a" });
        g.text([0.6, 1.7], `${s.i}반이 산 물건의 ${J ? "총열량 (kcal)" : "총 가격 (백 원)"}`, { anchor: "start", size: 14, color: "muted" });
      } else {
        const AB = mmul(MA, MB), BA = mmul(MB, MA);
        matrix(g, 0.6, Y, MA, { hl: (i) => hA(i), name: "A" });
        matrix(g, 3.3, Y, MB, { hl: hB, name: "B" });
        g.text([6.3, Y - 0.95], "=", { dy: 7, size: 22, bold: true });
        matrix(g, 6.9, Y, AB, { hl: hC, name: "AB" });
        matrix(g, 11.4, Y, BA, { hl: (i, j) => (AB[i][j] !== BA[i][j] ? "e" : null), name: "BA", ncolor: "e" });
        const terms = MA[I].map((v, k) => `${v}×${MB[k][J]}`).join(" + ");
        g.text([0.6, 3.6], `AB의 (${s.i}, ${s.j}) 성분 = ${terms} = ${AB[I][J]}`, { anchor: "start", bold: true, size: 15, color: "a" });
        g.text([0.6, 2.3], "BA에서 AB와 다른 칸을 분홍으로 표시했어요 → AB ≠ BA", { anchor: "start", size: 14, color: "e", bold: true });
      }
    },
    metrics(s) {
      if (s.mode === "sale") { const C = mmul(QTY, PRICE); return [[`AB의 (${s.i}, ${s.j}) 성분`, String(C[s.i - 1][s.j - 1]), "key"], ["꼴", "(2 × 3)(3 × 2) = 2 × 2"]]; }
      const AB = mmul(MA, MB); return [[`AB의 (${s.i}, ${s.j}) 성분`, String(AB[s.i - 1][s.j - 1]), "key"], ["AB = BA?", "아니요"]];
    },
    predict: [
      { q: "1반이 산 물건의 총 가격(백 원)은? (AB의 (1, 1) 성분)", set: (s) => Object.assign(s, { mode: "sale", i: 2, j: 2 }), reveal: (s) => Object.assign(s, { i: 1, j: 1 }), answer: () => 111, why: "3 × 12 + 5 × 9 + 2 × 15 = 36 + 45 + 30 = 111입니다." },
      { q: "두 행렬 A, B에 대하여 AB = BA는?", options: O("항상 성립한다", "성립하지 않을 수 있다"), set: (s) => Object.assign(s, { mode: "order", i: 1, j: 1 }), answer: () => "b", why: "그림의 A, B에서 AB와 BA의 성분이 서로 다릅니다. 행렬의 곱셈에서는 교환법칙이 성립하지 않습니다." },
    ],
  },
];
