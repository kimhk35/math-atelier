// 공통수학2 — Ⅰ 평면좌표와 직선의 방정식 · Ⅱ 원의 방정식과 도형의 이동
import { fmt, frac, surd, poly, shiftSq, dist, sub, add, mul, norm, dot, lerp, clamp, deg } from "./hs-core.js";

const V = { x: [-7, 7], y: [-5, 5] };
const pt = (p) => `(${frac(p[0])}, ${frac(p[1])})`;
const G = 4; // grade code: 공통수학2

export default [
  {
    id: "c2-distance", grade: G, unit: 1, lesson: "Ⅰ-1", title: "두 점 사이의 거리", type: "2D", time: "8분",
    tags: ["좌표평면", "거리", "피타고라스"], links: ["g2-pythagoras", "geo-space-coord"],
    desc: "두 점을 움직이며 가로·세로 차이로 만든 직각삼각형의 빗변으로 거리를 구합니다.",
    obs: ["두 점의 x좌표 차와 y좌표 차가 직각을 낀 두 변이 됩니다.", "두 점의 순서를 바꾸어도 차를 제곱하므로 거리는 같습니다."],
    q: "x좌표가 같은 두 점 사이의 거리는 어떻게 구하면 될까요?",
    formula: "AB = √((x₂ − x₁)² + (y₂ − y₁)²)",
    en: { title: "Distance Between Two Points", desc: "Move two points and find their distance as the hypotenuse of the right triangle formed by horizontal and vertical differences." },
    view: V, snap: 0.5, points: { A: [-3, -1], B: [3, 3] },
    params: [{ key: "ring", label: "A를 중심으로 AB를 반지름으로 하는 원", type: "check", value: false }],
    draw(s, g) {
      const { A, B } = s, C = [B[0], A[1]];
      g.grid();
      if (s.ring) g.circle(A, dist(A, B), { color: "e", dash: "5 6", w: 1.6 });
      g.poly([A, C, B], { fill: "f", fo: 0.1, stroke: false });
      g.seg(A, C, { color: "b", w: 2, dash: "7 5" }).seg(C, B, { color: "c", w: 2, dash: "7 5" });
      if (Math.abs(A[0] - B[0]) > 0.2 && Math.abs(A[1] - B[1]) > 0.2) g.right(C, A, B);
      g.text(lerp(A, C, 0.5), `|x₂ − x₁| = ${fmt(Math.abs(B[0] - A[0]))}`, { color: "b", dy: A[1] > B[1] ? -10 : 22, bold: true });
      g.text(lerp(C, B, 0.5), `|y₂ − y₁| = ${fmt(Math.abs(B[1] - A[1]))}`, { color: "c", dx: B[0] > A[0] ? 12 : -12, anchor: B[0] > A[0] ? "start" : "end", bold: true });
      g.seg(A, B, { color: "a", w: 3.4 });
      g.point(A, `A${pt(A)}`, { color: "a" }).point(B, `B${pt(B)}`, { color: "a" });
      g.handle(A, "A").handle(B, "B");
    },
    metrics(s) {
      const dx = s.B[0] - s.A[0], dy = s.B[1] - s.A[1], sq = dx * dx + dy * dy;
      return [["x좌표의 차", fmt(dx)], ["y좌표의 차", fmt(dy)], ["AB²", fmt(sq)], ["AB", `${surd(sq)} ≈ ${fmt(Math.sqrt(sq))}`, "key"]];
    },
    caption: (s) => `A${pt(s.A)}, B${pt(s.B)}`,
  },
  {
    id: "c2-division", grade: G, unit: 1, lesson: "Ⅰ-1", title: "선분의 내분점", type: "2D", time: "10분",
    tags: ["내분", "비", "좌표"], links: ["g2-parallel-ratios", "geo-position-vector"],
    desc: "m : n을 바꾸며 선분을 나누는 점의 좌표가 두 끝점 좌표의 가중평균이 되는 과정을 봅니다.",
    obs: ["선분을 m + n개의 같은 칸으로 나누면 내분점은 A에서 m칸째에 있습니다.", "x좌표와 y좌표가 각각 같은 비로 나뉩니다.", "m = n이면 중점이 됩니다."],
    q: "m : n과 n : m으로 나눈 두 점은 어떤 관계일까요?",
    formula: "P = ( (mx₂ + nx₁)/(m + n), (my₂ + ny₁)/(m + n) )",
    en: { title: "Internal Division of a Segment", desc: "Change m : n to see that the dividing point is a weighted average of the endpoints." },
    view: V, snap: 0.5, points: { A: [-5, -3], B: [4, 3] },
    params: [
      { key: "m", label: "m (A 쪽 부분)", min: 1, max: 6, step: 1, value: 2 },
      { key: "n", label: "n (B 쪽 부분)", min: 1, max: 6, step: 1, value: 1 },
      { key: "proj", label: "x축·y축으로 비 옮겨 보기", type: "check", value: true },
    ],
    draw(s, g) {
      const { A, B, m, n } = s, P = lerp(A, B, m / (m + n));
      g.grid();
      if (s.proj) {
        [A, B, P].forEach((q, i) => {
          g.seg(q, [q[0], 0], { color: i === 2 ? "a" : "muted", w: 1.2, dash: "3 5" });
          g.seg(q, [0, q[1]], { color: i === 2 ? "a" : "muted", w: 1.2, dash: "3 5" });
        });
        g.seg([A[0], 0], [P[0], 0], { color: "a", w: 5, opacity: 0.55 }).seg([P[0], 0], [B[0], 0], { color: "b", w: 5, opacity: 0.55 });
        g.seg([0, A[1]], [0, P[1]], { color: "a", w: 5, opacity: 0.55 }).seg([0, P[1]], [0, B[1]], { color: "b", w: 5, opacity: 0.55 });
      }
      g.seg(A, P, { color: "a", w: 4 }).seg(P, B, { color: "b", w: 4 });
      const N = m + n, d = sub(B, A), nn = norm([-d[1], d[0]]);
      for (let i = 1; i < N; i++) { const q = lerp(A, B, i / N); g.seg(add(q, mul(nn, 0.14)), add(q, mul(nn, -0.14)), { color: "ink", w: 1.6 }); }
      g.text(lerp(A, P, 0.5), `m = ${m}`, { color: "a", dx: nn[0] * 22, dy: -nn[1] * 22, bold: true });
      g.text(lerp(P, B, 0.5), `n = ${n}`, { color: "b", dx: nn[0] * 22, dy: -nn[1] * 22, bold: true });
      g.point(A, "A", { color: "ink" }).point(B, "B", { color: "ink" }).point(P, `P${pt(P)}`, { color: "a", r: 7 });
      g.handle(A, "A").handle(B, "B");
    },
    metrics(s) {
      const { A, B, m, n } = s, P = lerp(A, B, m / (m + n));
      return [["비", `${m} : ${n}`], ["x좌표", `(${m}·${frac(B[0])} + ${n}·${frac(A[0])}) / ${m + n} = ${frac(P[0])}`], ["y좌표", `(${m}·${frac(B[1])} + ${n}·${frac(A[1])}) / ${m + n} = ${frac(P[1])}`], ["내분점 P", pt(P), "key"], m === n ? "m = n이므로 P는 선분 AB의 중점입니다." : ""].filter(Boolean);
    },
  },
  {
    id: "c2-centroid", grade: G, unit: 1, lesson: "Ⅰ-1", title: "삼각형의 무게중심 좌표", type: "2D", time: "8분",
    tags: ["무게중심", "중선", "평균"], links: ["g2-centroid", "geo-position-vector"],
    desc: "세 꼭짓점을 움직이며 무게중심의 좌표가 세 꼭짓점 좌표의 평균임을 확인합니다.",
    obs: ["무게중심은 중선을 꼭짓점에서부터 2 : 1로 내분합니다.", "x좌표, y좌표가 각각 세 수의 평균입니다."],
    q: "세 꼭짓점을 모두 오른쪽으로 2만큼 옮기면 무게중심은 어떻게 될까요?",
    formula: "G = ( (x₁ + x₂ + x₃)/3, (y₁ + y₂ + y₃)/3 )",
    en: { title: "Centroid Coordinates", desc: "Move the vertices and confirm that the centroid is the average of the vertex coordinates." },
    view: V, snap: 0.5, points: { A: [-1, 4], B: [-5, -3], C: [5, -2] },
    draw(s, g) {
      const { A, B, C } = s, Gc = mul(add(add(A, B), C), 1 / 3);
      const M = [lerp(B, C, 0.5), lerp(C, A, 0.5), lerp(A, B, 0.5)];
      g.grid();
      g.poly([A, B, C], { fill: "b", fo: 0.08, color: "ink", w: 2.2 });
      [[A, M[0]], [B, M[1]], [C, M[2]]].forEach(([v, m]) => { g.seg(v, lerp(v, m, 2 / 3), { color: "a", w: 2.6 }); g.seg(lerp(v, m, 2 / 3), m, { color: "b", w: 2.6 }); });
      M.forEach((m, i) => g.point(m, ["M₁", "M₂", "M₃"][i], { r: 3.5, color: "muted" }));
      g.point(A, `A${pt(A)}`, { color: "ink" }).point(B, `B${pt(B)}`, { color: "ink", dy: 20 }).point(C, `C${pt(C)}`, { color: "ink", dy: 20 });
      g.point(Gc, `G${pt(Gc)}`, { color: "a", r: 7 });
      g.handle(A, "A").handle(B, "B").handle(C, "C");
    },
    metrics(s) {
      const { A, B, C } = s, Gc = mul(add(add(A, B), C), 1 / 3), M = lerp(B, C, 0.5);
      return [["x좌표 평균", `(${frac(A[0])} + ${frac(B[0])} + ${frac(C[0])}) / 3 = ${frac(Gc[0])}`], ["y좌표 평균", `(${frac(A[1])} + ${frac(B[1])} + ${frac(C[1])}) / 3 = ${frac(Gc[1])}`], ["AG : GM₁", `${fmt(dist(A, Gc))} : ${fmt(dist(Gc, M))} = 2 : 1`], ["무게중심 G", pt(Gc), "key"]];
    },
  },
  {
    id: "c2-line-eq", grade: G, unit: 1, lesson: "Ⅰ-2", title: "직선의 방정식", type: "2D", time: "10분",
    tags: ["기울기", "절편", "일차방정식"], links: ["geo-vector-line"],
    desc: "한 점과 기울기, 두 점, 두 절편 가운데 조건을 골라 직선의 방정식을 만들고 서로 바꿔 봅니다.",
    obs: ["기울기는 x가 1만큼 늘 때 y가 늘어난 양입니다.", "같은 직선도 y = mx + k, ax + by + c = 0 등 여러 꼴로 나타납니다.", "x축에 수직인 직선은 기울기가 없고 x = a 꼴입니다."],
    q: "x절편과 y절편만으로 직선이 하나로 정해지지 않는 경우는 언제일까요?",
    formula: "y − y₁ = m(x − x₁) · x/a + y/b = 1",
    en: { title: "Equations of Lines", desc: "Build a line from a point and slope, two points, or two intercepts, and convert between forms." },
    view: V, snap: 0.5, points: { A: [-2, -1], B: [3, 2] },
    params: [
      { key: "mode", label: "조건", type: "seg", value: "pt", options: [["pt", "한 점 + 기울기"], ["two", "두 점"], ["int", "두 절편"]] },
      { key: "m", label: "기울기 m", min: -5, max: 5, step: 0.25, value: 0.5, when: (s) => s.mode === "pt" },
      { key: "a", label: "x절편 a", min: -6, max: 6, step: 0.5, value: 4, when: (s) => s.mode === "int" },
      { key: "b", label: "y절편 b", min: -4, max: 4, step: 0.5, value: 2, when: (s) => s.mode === "int" },
    ],
    line(s) {
      if (s.mode === "pt") return { p: s.A, d: [1, s.m] };
      if (s.mode === "two") return { p: s.A, d: sub(s.B, s.A) };
      return { p: [s.a, 0], d: [-s.a, s.b] };
    },
    draw(s, g) {
      g.grid();
      const L = this.line(s);
      if (Math.hypot(...L.d) < 1e-9) { g.note(20, 30, "두 점이 같아 직선이 정해지지 않습니다.", { color: "d", bold: true }); g.point(s.A, "A").handle(s.A, "A").handle(s.B, "B"); return; }
      g.line(L.p, add(L.p, L.d), { color: "a", w: 3.2 });
      if (Math.abs(L.d[0]) > 1e-9) {
        const m = L.d[1] / L.d[0], P = s.mode === "int" ? [0, s.b] : s.A, Q = [P[0] + 1, P[1]], R = [P[0] + 1, P[1] + m];
        if (Math.abs(m) < 8) { g.seg(P, Q, { color: "b", w: 2, dash: "6 4" }).seg(Q, R, { color: "c", w: 2, dash: "6 4" }); g.text(lerp(P, Q, 0.5), "1", { color: "b", dy: m >= 0 ? 18 : -8, bold: true }); g.text(lerp(Q, R, 0.5), `m = ${fmt(m)}`, { color: "c", dx: 10, anchor: "start", bold: true }); }
        const k = L.p[1] - m * L.p[0]; g.point([0, k], "", { r: 4.5, color: "e", hollow: true });
        if (Math.abs(m) > 1e-9) g.point([-k / m, 0], "", { r: 4.5, color: "e", hollow: true });
      }
      if (s.mode === "int") { g.point([s.a, 0], `(${fmt(s.a)}, 0)`, { color: "e", dy: 20 }).point([0, s.b], `(0, ${fmt(s.b)})`, { color: "e" }); }
      else { g.point(s.A, `A${pt(s.A)}`, { color: "a" }).handle(s.A, "A"); if (s.mode === "two") g.point(s.B, `B${pt(s.B)}`, { color: "a" }).handle(s.B, "B"); }
    },
    metrics(s) {
      const L = this.line(s), d = L.d, p = L.p;
      if (Math.hypot(...d) < 1e-9) return ["두 점을 서로 다른 곳에 놓아 주세요."];
      if (Math.abs(d[0]) < 1e-9) return [["기울기", "정의되지 않음"], ["방정식", `x = ${frac(p[0])}`, "key"], "y축에 평행한 직선입니다."];
      const m = d[1] / d[0], k = p[1] - m * p[0];
      const A = -d[1], B = d[0], C = d[1] * p[0] - d[0] * p[1];
      const out = [["기울기 m", frac(m)], ["y절편", frac(k)], ["y = mx + k", `y = ${poly([[m, "x"]], k)}`, "key"], ["일반형", `${poly([[A, "x"], [B, "y"]], C)} = 0`]];
      if (s.mode === "int") out.push(s.a === 0 || s.b === 0 ? ["절편 꼴", "절편이 0이면 x/a + y/b = 1 꼴로 쓸 수 없습니다"] : ["절편 꼴", `x/${fmt(s.a)} + y/${fmt(s.b)} = 1`]);
      if (s.mode === "pt") out.push(["점-기울기 꼴", `y − ${frac(s.A[1])} = ${frac(m)}(x − ${frac(s.A[0])})`]);
      return out;
    },
  },
  {
    id: "c2-parallel-perp", grade: G, unit: 1, lesson: "Ⅰ-3", title: "두 직선의 평행과 수직", type: "2D", time: "8분",
    tags: ["평행", "수직", "기울기의 곱"], links: ["parallel-angles", "geo-dot-product"],
    desc: "두 직선의 기울기를 바꾸며 평행 조건(기울기가 같음)과 수직 조건(기울기의 곱이 −1)을 찾습니다.",
    obs: ["기울기가 같고 y절편이 다르면 두 직선은 만나지 않습니다.", "한 직선을 90° 돌리면 기울기 m은 −1/m이 됩니다."],
    q: "기울기의 곱이 −1인데 한 직선이 y축에 평행한 경우도 있을까요?",
    formula: "평행: m = m′, k ≠ k′ · 수직: m·m′ = −1",
    en: { title: "Parallel and Perpendicular Lines", desc: "Change slopes to find the parallel condition (equal slopes) and the perpendicular condition (product −1)." },
    view: V, snap: 0.5, points: { P: [1, -2] },
    params: [
      { key: "m1", label: "직선 l의 기울기 m", min: -4, max: 4, step: 0.25, value: 0.5 },
      { key: "k1", label: "직선 l의 y절편", min: -4, max: 4, step: 0.5, value: 1 },
      { key: "m2", label: "직선 l′의 기울기 m′", min: -4, max: 4, step: 0.25, value: 1.5 },
    ],
    buttons: [["par", "l′을 l과 평행하게"], ["perp", "l′을 l에 수직으로"]],
    onDo(k, s) { if (k === "par") s.m2 = s.m1; if (k === "perp" && Math.abs(s.m1) > 1e-9) s.m2 = clamp(-1 / s.m1, -4, 4); },
    draw(s, g) {
      g.grid();
      const A = [0, s.k1];
      g.line(A, [1, s.k1 + s.m1], { color: "b", w: 3 });
      g.line(s.P, [s.P[0] + 1, s.P[1] + s.m2], { color: "a", w: 3 });
      const par = Math.abs(s.m1 - s.m2) < 1e-9, perp = Math.abs(s.m1 * s.m2 + 1) < 1e-9;
      if (!par) {
        const x = (s.P[1] - s.m2 * s.P[0] - s.k1) / (s.m1 - s.m2), X = [x, s.m1 * x + s.k1];
        if (perp) g.right(X, add(X, [1, s.m1]), add(X, [1, s.m2]), { size: 16, color: "ink" });
        g.point(X, "", { r: 4.5, color: "ink" });
      }
      g.note(18, 28, `l : y = ${poly([[s.m1, "x"]], s.k1)}`, { color: "b", bold: true, mono: true });
      g.note(18, 52, `l′ : y = ${poly([[s.m2, "x"]], s.P[1] - s.m2 * s.P[0])}`, { color: "a", bold: true, mono: true });
      g.point(s.P, "P", { color: "a" }).handle(s.P, "P");
    },
    metrics(s) {
      const k2 = s.P[1] - s.m2 * s.P[0], par = Math.abs(s.m1 - s.m2) < 1e-9, perp = Math.abs(s.m1 * s.m2 + 1) < 1e-9;
      const st = par ? (Math.abs(k2 - s.k1) < 1e-9 ? "일치 (같은 직선)" : "평행 (만나지 않음)") : perp ? "수직으로 만남" : "한 점에서 만남";
      return [["m", frac(s.m1)], ["m′", frac(s.m2)], ["m · m′", frac(s.m1 * s.m2)], ["두 직선의 관계", st, par || perp ? "key" : ""]];
    },
  },
  {
    id: "c2-point-line", grade: G, unit: 1, lesson: "Ⅰ-4", title: "점과 직선 사이의 거리", type: "2D", time: "10분",
    tags: ["수선의 발", "거리 공식", "멀리뛰기"], links: ["c2-circle-line", "geo-three-perp"],
    desc: "점 P에서 직선에 내린 수선의 길이를 공식으로 계산한 값과 비교하고, 그 거리를 반지름으로 하는 원을 그립니다.",
    obs: ["점과 직선 사이의 거리는 수선의 발까지의 길이이며, 직선 위의 다른 점까지의 거리보다 짧습니다.", "P를 직선에 평행하게 옮기면 거리는 변하지 않습니다."],
    q: "점 P가 직선 위에 있으면 |ax₁ + by₁ + c|의 값은 얼마일까요?",
    formula: "d = |ax₁ + by₁ + c| / √(a² + b²)",
    en: { title: "Distance from a Point to a Line", desc: "Compare the perpendicular length from P with the formula value and draw the tangent circle." },
    view: V, snap: 0.5, points: { P: [2, 3], Q: [-3, -1.5] },
    params: [
      { key: "a", label: "a", min: -4, max: 4, step: 1, value: 1 },
      { key: "b", label: "b", min: -4, max: 4, step: 1, value: 2 },
      { key: "c", label: "c", min: -8, max: 8, step: 1, value: 2 },
      { key: "other", label: "직선 위 다른 점 Q까지의 거리와 비교", type: "check", value: true },
    ],
    derive(s) { if (!s.a && !s.b) s.b = 1; },
    constrain(s, k, p) { if (!s.a && !s.b) s.b = 1; if (k !== "Q") return [clamp(p[0], -7, 7), clamp(p[1], -5, 5)]; const n = [s.a, s.b], nn = dot(n, n), t = (dot(n, p) + s.c) / nn; return sub(p, mul(n, t)); },
    onChange(s) { if (!s.a && !s.b) s.b = 1; const n = [s.a, s.b], nn = dot(n, n); s.Q = sub(s.Q, mul(n, (dot(n, s.Q) + s.c) / nn)); },
    draw(s, g) {
      const n = [s.a, s.b], nn = dot(n, n), H = sub(s.P, mul(n, (dot(n, s.P) + s.c) / nn)), d = dist(s.P, H);
      g.grid();
      g.circle(s.P, d, { color: "e", w: 1.4, dash: "4 6", fill: "e", fo: 0.05 });
      g.lineABC(s.a, s.b, s.c, { color: "b", w: 3 });
      if (s.other) { g.seg(s.P, s.Q, { color: "muted", w: 1.8, dash: "5 5" }); g.point(s.Q, "Q", { color: "muted" }).handle(s.Q, "Q", { color: "b" }); }
      g.seg(s.P, H, { color: "a", w: 3.2 });
      if (d > 0.3) g.right(H, s.P, add(H, [s.b, -s.a]), { color: "ink" });
      g.point(H, "H", { color: "ink", r: 4.5 }).point(s.P, `P${pt(s.P)}`, { color: "a" }).handle(s.P, "P");
      g.note(18, 28, `${poly([[s.a, "x"], [s.b, "y"]], s.c)} = 0`, { color: "b", bold: true, mono: true });
    },
    metrics(s) {
      const v = s.a * s.P[0] + s.b * s.P[1] + s.c, nn = s.a * s.a + s.b * s.b, d = Math.abs(v) / Math.sqrt(nn);
      const out = [["|ax₁ + by₁ + c|", fmt(Math.abs(v))], ["√(a² + b²)", surd(nn)], ["거리 d", `${fmt(Math.abs(v))}/${surd(nn)} ≈ ${fmt(d)}`, "key"]];
      if (s.other) out.push(["PQ (비교)", `${fmt(dist(s.P, s.Q))} ≥ ${fmt(d)}`]);
      if (Math.abs(v) < 1e-9) out.push("점 P가 직선 위에 있어 거리가 0입니다.");
      return out;
    },
  },
  {
    id: "c2-circle-eq", grade: G, unit: 2, lesson: "Ⅱ-1", title: "원의 방정식", type: "2D", time: "10분",
    tags: ["표준형", "일반형", "완전제곱식"], links: ["pi-estimation", "geo-sphere-eq"],
    desc: "중심과 반지름으로 원의 방정식을 만들고, 일반형 x² + y² + Ax + By + C = 0을 완전제곱식으로 바꿔 중심과 반지름을 찾습니다.",
    obs: ["원 위의 모든 점은 중심까지의 거리가 반지름과 같습니다.", "일반형에서 A² + B² − 4C가 0 이하이면 원이 되지 않습니다."],
    q: "x² + y² − 4x + 6y + 13 = 0은 어떤 도형을 나타낼까요?",
    formula: "(x − a)² + (y − b)² = r² ⇔ x² + y² + Ax + By + C = 0",
    en: { title: "Equation of a Circle", desc: "Build the standard form from center and radius, and complete squares to read the general form." },
    view: V, snap: 0.5, points: { O: [1, 0.5], P: [4, 3] },
    params: [
      { key: "mode", label: "보기", type: "seg", value: "std", options: [["std", "중심·반지름으로"], ["gen", "일반형 계수로"]] },
      { key: "r", label: "반지름 r", min: 0.5, max: 5, step: 0.5, value: 3, when: (s) => s.mode === "std" },
      { key: "A", label: "A", min: -10, max: 10, step: 1, value: -2, when: (s) => s.mode === "gen" },
      { key: "B", label: "B", min: -10, max: 10, step: 1, value: 4, when: (s) => s.mode === "gen" },
      { key: "C", label: "C", min: -20, max: 20, step: 1, value: -4, when: (s) => s.mode === "gen" },
    ],
    circ(s) { if (s.mode === "std") return { c: s.O, r2: s.r * s.r }; return { c: [-s.A / 2, -s.B / 2], r2: (s.A * s.A + s.B * s.B - 4 * s.C) / 4 }; },
    draw(s, g) {
      g.grid();
      const { c, r2 } = this.circ(s);
      if (r2 > 1e-9) {
        const r = Math.sqrt(r2);
        g.circle(c, r, { color: "a", w: 3.2, fill: "a", fo: 0.06 });
        g.seg(c, add(c, [r, 0]), { color: "a", w: 1.8, dash: "5 4" }).text(add(c, [r / 2, 0]), `r = ${surd(r2)}`, { dy: -8, color: "a", bold: true });
        const P = s.P, dP = dist(P, c);
        g.seg(c, P, { color: "b", w: 1.6, dash: "3 5" });
        g.point(P, `P${pt(P)}`, { color: "b" }).handle(P, "P", { color: "b" });
      } else if (Math.abs(r2) <= 1e-9) g.note(18, 28, "반지름이 0 → 한 점만 나타냅니다", { color: "d", bold: true });
      else g.note(18, 28, "A² + B² − 4C < 0 → 방정식을 만족하는 점이 없습니다", { color: "d", bold: true });
      g.point(c, `중심${pt(c)}`, { color: "ink", dy: 22 });
      if (s.mode === "std") g.handle(s.O, "O");
    },
    metrics(s) {
      const { c, r2 } = this.circ(s);
      const A = -2 * c[0], B = -2 * c[1], C = c[0] * c[0] + c[1] * c[1] - r2;
      const std = `${shiftSq("x", c[0])} + ${shiftSq("y", c[1])} = ${fmt(r2)}`;
      const out = [["표준형", r2 > 1e-9 ? std : "원이 아님", "key"], ["일반형", `${poly([[1, "x²"], [1, "y²"], [A, "x"], [B, "y"]], C)} = 0`], ["중심", pt(c)], ["r²", fmt(r2)]];
      if (r2 > 1e-9) { const q = (s.P[0] - c[0]) ** 2 + (s.P[1] - c[1]) ** 2; out.push(["점 P의 위치", q < r2 - 1e-9 ? `원의 내부 (${fmt(q)} < ${fmt(r2)})` : q > r2 + 1e-9 ? `원의 외부 (${fmt(q)} > ${fmt(r2)})` : "원 위"]); }
      return out;
    },
  },
  {
    id: "c2-circle-line", grade: G, unit: 2, lesson: "Ⅱ-2", title: "원과 직선의 위치 관계 · 충돌 판정", type: "2D", time: "12분",
    tags: ["판별식", "거리", "게임 충돌"], links: ["c2-point-line", "g3-circle-tangent"],
    desc: "직선을 움직여 원과 만나는 점의 개수를 판별식과 중심-직선 거리 두 방법으로 비교하고, 게임 속 공과 벽의 충돌을 판정합니다.",
    obs: ["중심에서 직선까지의 거리 d와 반지름 r을 비교하면 교점 개수를 알 수 있습니다.", "연립한 이차방정식의 판별식 부호가 같은 결론을 줍니다."],
    q: "원이 벽을 향해 1초에 1씩 움직일 때 충돌 시각은 어떻게 계산할까요?",
    formula: "d < r ⇔ D > 0 (두 점) · d = r ⇔ D = 0 (접함) · d > r ⇔ D < 0",
    en: { title: "Circle and Line · Collision Test", desc: "Compare the discriminant and the center-to-line distance to classify intersections, as in game collision detection." },
    view: V,
    params: [
      { key: "r", label: "반지름 r", min: 1, max: 4, step: 0.5, value: 2.5 },
      { key: "m", label: "직선의 기울기 m", min: -3, max: 3, step: 0.25, value: -0.5 },
      { key: "k", label: "직선의 y절편 k", min: -6, max: 6, step: 0.05, value: 4.5, digits: 2 },
      { key: "game", label: "게임 화면처럼 보기 (공과 벽)", type: "check", value: false },
    ],
    anim: { key: "k", min: -6, max: 6, speed: 1.6, label: "벽 움직이기" },
    drags: { K: { at: (s) => [0, s.k], move: (s, p) => (s.k = p[1]), label: "y절편" }, M: { at: (s) => [2, s.k + 2 * s.m], move: (s, p) => (s.m = Math.round(((p[1] - s.k) / 2) * 4) / 4), color: "b", label: "기울기" } },
    draw(s, g) {
      g.grid({ labels: !s.game });
      const d = Math.abs(s.k) / Math.sqrt(1 + s.m * s.m), H = [-s.m * s.k / (1 + s.m * s.m), s.k / (1 + s.m * s.m)];
      const tone = d < s.r - 1e-9 ? "d" : Math.abs(d - s.r) < 1e-9 ? "c" : "b";
      g.circle([0, 0], s.r, { color: s.game ? tone : "a", w: 3, fill: s.game ? tone : "a", fo: s.game ? 0.3 : 0.06 });
      g.line([0, s.k], [1, s.k + s.m], { color: "ink", w: s.game ? 7 : 3, opacity: s.game ? 0.75 : 1 });
      g.seg([0, 0], H, { color: "e", w: 2, dash: "5 4" }).text(lerp([0, 0], H, 0.5), `d = ${fmt(d)}`, { color: "e", dx: 14, anchor: "start", bold: true });
      if (d > 0.25) g.right(H, [0, 0], add(H, [1, s.m]));
      const a = 1 + s.m * s.m, b = 2 * s.m * s.k, c = s.k * s.k - s.r * s.r, D = b * b - 4 * a * c;
      if (D >= -1e-9) { const sq = Math.sqrt(Math.max(0, D)); [(-b + sq) / (2 * a), (-b - sq) / (2 * a)].forEach((x) => g.point([x, s.m * x + s.k], "", { color: "d", r: 6 })); }
      g.point([0, 0], "", { color: "ink", r: 4 });
    },
    metrics(s) {
      const d = Math.abs(s.k) / Math.sqrt(1 + s.m * s.m), D4 = s.r * s.r * (1 + s.m * s.m) - s.k * s.k;
      const rel = D4 > 1e-9 ? "서로 다른 두 점에서 만남" : Math.abs(D4) <= 1e-9 ? "접함 (한 점)" : "만나지 않음";
      return [["중심과 직선 사이 거리 d", fmt(d)], ["반지름 r", fmt(s.r)], ["판별식 D/4", fmt(D4)], ["위치 관계", rel, "key"], s.game ? (D4 > 1e-9 ? "충돌! 공이 벽을 뚫고 들어갔습니다." : Math.abs(D4) <= 1e-9 ? "딱 닿은 순간입니다." : "아직 충돌하지 않았습니다.") : `연립: ${fmt(1 + s.m * s.m)}x² ${s.m * s.k >= 0 ? "+" : "−"} ${fmt(Math.abs(2 * s.m * s.k))}x ${s.k * s.k - s.r * s.r >= 0 ? "+" : "−"} ${fmt(Math.abs(s.k * s.k - s.r * s.r))} = 0`];
    },
  },
  {
    id: "c2-tangent", grade: G, unit: 2, lesson: "Ⅱ-2", title: "원의 접선의 방정식", type: "2D", time: "12분",
    tags: ["접선", "접점", "기울기"], links: ["g3-circle-tangent", "geo-tangent-reflect"],
    desc: "원 위의 점에서의 접선, 기울기가 주어진 접선, 원 밖의 점에서 그은 두 접선을 차례로 만들어 봅니다.",
    obs: ["접선은 접점을 지나는 반지름과 수직입니다.", "기울기가 m인 접선은 항상 두 개 있습니다.", "원 밖의 한 점에서 그은 두 접선의 길이는 같습니다."],
    q: "원 위의 점 (x₁, y₁)에서의 접선이 x₁x + y₁y = r²인 이유를 수직 조건으로 설명해 보세요.",
    formula: "x₁x + y₁y = r² · y = mx ± r√(m² + 1)",
    en: { title: "Tangent Lines to a Circle", desc: "Construct tangents at a point on the circle, with a given slope, and from an external point." },
    view: V, points: { T: [2.4, 1.8], P: [5.5, -2] },
    params: [
      { key: "mode", label: "접선 조건", type: "seg", value: "on", options: [["on", "원 위의 점"], ["slope", "기울기"], ["out", "원 밖의 점"]] },
      { key: "r", label: "반지름 r", min: 1.5, max: 4, step: 0.5, value: 3 },
      { key: "m", label: "기울기 m", min: -3, max: 3, step: 0.25, value: 1, when: (s) => s.mode === "slope" },
    ],
    constrain(s, k, p) {
      if (k === "T") { const l = Math.hypot(...p) || 1; return mul(p, s.r / l); }
      const l = Math.hypot(...p); return l < s.r + 0.4 ? mul(p, (s.r + 0.4) / (l || 1)) : [clamp(p[0], -7, 7), clamp(p[1], -5, 5)];
    },
    onChange(s) { s.T = mul(s.T, s.r / (Math.hypot(...s.T) || 1)); const l = Math.hypot(...s.P); if (l < s.r + 0.4) s.P = mul(s.P, (s.r + 0.4) / l); },
    draw(s, g) {
      g.grid();
      const O = [0, 0], r = s.r;
      g.circle(O, r, { color: "b", w: 3, fill: "b", fo: 0.05 });
      if (s.mode === "on") {
        const T = s.T;
        g.seg(O, T, { color: "muted", w: 1.8, dash: "5 4" });
        g.line(T, add(T, [-T[1], T[0]]), { color: "a", w: 3 });
        g.right(T, O, add(T, [-T[1], T[0]]), { size: 14, color: "ink" });
        g.point(T, `(${fmt(T[0])}, ${fmt(T[1])})`, { color: "a" }).handle(T, "T");
      } else if (s.mode === "slope") {
        const c = r * Math.sqrt(s.m * s.m + 1);
        [c, -c].forEach((k, i) => { g.line([0, k], [1, k + s.m], { color: i ? "e" : "a", w: 3 }); const Tp = mul(norm([-s.m, 1]), i ? -r : r); g.seg(O, Tp, { color: "muted", w: 1.6, dash: "5 4" }); g.point(Tp, "", { color: i ? "e" : "a" }); });
        g.line(O, [1, s.m], { color: "muted", w: 1, dash: "2 6" });
      } else {
        const P = s.P, d = Math.hypot(...P), th = Math.acos(r / d), base = Math.atan2(P[1], P[0]);
        [th, -th].forEach((t, i) => { const T = [r * Math.cos(base + t), r * Math.sin(base + t)]; g.line(P, T, { color: i ? "e" : "a", w: 2.6 }); g.seg(O, T, { color: "muted", w: 1.6, dash: "5 4" }); g.right(T, O, P, { size: 11 }); g.seg(P, T, { color: i ? "e" : "a", w: 4.5, opacity: 0.5 }); g.point(T, i ? "B" : "A", { color: i ? "e" : "a" }); });
        g.point(P, "P", { color: "ink" }).handle(P, "P");
      }
      g.point(O, "", { color: "ink", r: 4 });
    },
    metrics(s) {
      const r2 = s.r * s.r;
      if (s.mode === "on") return [["접점", `(${fmt(s.T[0])}, ${fmt(s.T[1])})`], ["접선", `${poly([[s.T[0], "x"], [s.T[1], "y"]])} = ${fmt(r2)}`, "key"], ["반지름과 접선", "서로 수직"]];
      if (s.mode === "slope") { const c = s.r * Math.sqrt(s.m * s.m + 1); return [["r√(m² + 1)", `${surd(r2 * (s.m * s.m + 1))} ≈ ${fmt(c)}`], ["접선 1", `y = ${poly([[s.m, "x"]], c)}`, "key"], ["접선 2", `y = ${poly([[s.m, "x"]], -c)}`, "key"]]; }
      const d2 = dot(s.P, s.P), L = Math.sqrt(d2 - r2);
      return [["OP", fmt(Math.sqrt(d2))], ["PA = PB", `√(OP² − r²) = ${fmt(L)}`, "key"], ["접점 수", "2개"]];
    },
  },
  {
    id: "c2-translation", grade: G, unit: 2, lesson: "Ⅱ-3", title: "도형의 평행이동", type: "조작", time: "10분",
    tags: ["평행이동", "방정식 변환", "게임 이동"], links: ["geo-conic-shift"],
    desc: "점·직선·원·포물선을 x축으로 a, y축으로 b만큼 옮기며 방정식에서 x를 x − a, y를 y − b로 바꾸는 이유를 봅니다.",
    obs: ["점의 좌표는 (x + a, y + b)로 바뀝니다.", "도형의 방정식은 x 대신 x − a, y 대신 y − b를 넣습니다.", "모양과 크기는 그대로입니다."],
    q: "점은 +a인데 방정식은 왜 x − a로 바뀔까요?",
    formula: "f(x, y) = 0 → f(x − a, y − b) = 0",
    en: { title: "Translations", desc: "Translate points, lines, circles and parabolas and see why x becomes x − a in equations." },
    view: V,
    params: [
      { key: "shape", label: "도형", type: "seg", value: "para", options: [["pt", "점"], ["line", "직선"], ["circle", "원"], ["para", "포물선"]] },
      { key: "a", label: "x축 방향 a", min: -5, max: 5, step: 0.5, value: 3 },
      { key: "b", label: "y축 방향 b", min: -4, max: 4, step: 0.5, value: -2 },
      { key: "t", label: "이동 진행", min: 0, max: 1, step: 0.01, value: 1, show: (v) => `${Math.round(v * 100)}%` },
    ],
    anim: { key: "t", min: 0, max: 1, speed: 0.5, label: "이동 애니메이션" },
    shp(s, a, b) {
      if (s.shape === "pt") return { pts: [[1 + a, 2 + b]] };
      if (s.shape === "line") return { f: (x) => 2 * (x - a) - 1 + b };
      if (s.shape === "circle") return { c: [-1 + a, 1 + b], r: 2 };
      return { f: (x) => 0.5 * (x - a) ** 2 - 2 + b };
    },
    drags: { T: { at: (s) => { const an = s.shape === "circle" ? [-1, 1] : s.shape === "pt" ? [1, 2] : s.shape === "line" ? [0, -1] : [0, -2]; return [an[0] + s.a * s.t, an[1] + s.b * s.t]; }, move: (s, p) => { const an = s.shape === "circle" ? [-1, 1] : s.shape === "pt" ? [1, 2] : s.shape === "line" ? [0, -1] : [0, -2]; s.t = 1; s.a = Math.round((p[0] - an[0]) * 2) / 2; s.b = Math.round((p[1] - an[1]) * 2) / 2; } } },
    draw(s, g) {
      g.grid();
      const draw = (sh, o) => { if (sh.pts) sh.pts.forEach((p) => g.point(p, o.label, { color: o.color, hollow: o.ghost })); if (sh.f) g.fx(sh.f, { color: o.color, w: 3, dash: o.ghost ? "6 6" : null }); if (sh.c) g.circle(sh.c, sh.r, { color: o.color, w: 3, dash: o.ghost ? "6 6" : null }); };
      const a = s.a * s.t, b = s.b * s.t;
      draw(this.shp(s, 0, 0), { color: "muted", ghost: true, label: "P" });
      const anchor = s.shape === "circle" ? [-1, 1] : s.shape === "pt" ? [1, 2] : s.shape === "line" ? [0, -1] : [0, -2];
      g.vec(anchor, add(anchor, [a, b]), { color: "e", w: 2.4 });
      [[-3, 3], [3, 3], [-4, -3]].forEach((q) => g.vec(q, add(q, [a, b]), { color: "e", w: 1.4, opacity: 0.35 }));
      draw(this.shp(s, a, b), { color: "a", label: "P′" });
    },
    metrics(s) {
      const a = s.a, b = s.b, X = (v, k) => (Math.abs(k) < 1e-9 ? v : `(${v} ${k > 0 ? "−" : "+"} ${fmt(Math.abs(k))})`);
      const m = {
        pt: ["P(1, 2)", `P′(${fmt(1 + a)}, ${fmt(2 + b)})`],
        line: ["y = 2x − 1", `${X("y", b)} = 2${X("x", a)} − 1  →  y = ${poly([[2, "x"]], -1 - 2 * a + b)}`],
        circle: ["(x + 1)² + (y − 1)² = 4", `${shiftSq("x", -1 + a)} + ${shiftSq("y", 1 + b)} = 4`],
        para: ["y = ½x² − 2", `${X("y", b)} = ½${X("x", a)}² − 2`],
      }[s.shape];
      return [["이동", `(x, y) → (x ${a >= 0 ? "+" : "−"} ${fmt(Math.abs(a))}, y ${b >= 0 ? "+" : "−"} ${fmt(Math.abs(b))})`], ["처음", m[0]], ["옮긴 뒤", m[1], "key"]];
    },
  },
  {
    id: "c2-reflection", grade: G, unit: 2, lesson: "Ⅱ-3", title: "도형의 대칭이동", type: "조작", time: "10분",
    tags: ["대칭이동", "x축", "y = x"], links: ["c2-shortest"],
    desc: "x축, y축, 원점, 직선 y = x에 대하여 점과 도형을 접어 옮기며 좌표와 방정식의 변화를 확인합니다.",
    obs: ["대칭축은 대응점을 이은 선분의 수직이등분선입니다.", "y = x 대칭은 x와 y를 서로 바꿉니다.", "원점 대칭은 x축 대칭 후 y축 대칭한 것과 같습니다."],
    q: "y = x에 대한 대칭이동을 두 번 하면 어떻게 될까요?",
    formula: "x축: (x, −y) · y축: (−x, y) · 원점: (−x, −y) · y = x: (y, x)",
    en: { title: "Reflections", desc: "Reflect points and figures across the axes, the origin, and y = x, and track the equations." },
    view: V, snap: 0.5, points: { P: [3, 2] },
    params: [
      { key: "ax", label: "기준", type: "seg", value: "yx", options: [["x", "x축"], ["y", "y축"], ["o", "원점"], ["yx", "y = x"]] },
      { key: "shape", label: "함께 옮길 도형", type: "select", value: "para", options: [["none", "점만"], ["para", "포물선 y = (x − 2)² − 1"], ["circle", "원 (x − 3)² + (y − 1)² = 1"]] },
      { key: "t", label: "접기 진행", min: 0, max: 1, step: 0.01, value: 1, show: (v) => `${Math.round(v * 100)}%` },
    ],
    anim: { key: "t", min: 0, max: 1, speed: 0.55, label: "접기 애니메이션" },
    R(s, p) { const [x, y] = p; return { x: [x, -y], y: [-x, y], o: [-x, -y], yx: [y, x] }[s.ax]; },
    draw(s, g) {
      g.grid();
      if (s.ax === "yx") g.line([0, 0], [1, 1], { color: "e", w: 2.4, dash: "8 5" });
      if (s.ax === "x") g.seg([-7, 0], [7, 0], { color: "e", w: 3.2, opacity: 0.6 });
      if (s.ax === "y") g.seg([0, -5], [0, 5], { color: "e", w: 3.2, opacity: 0.6 });
      const mv = (p) => lerp(p, this.R(s, p), s.t);
      if (s.shape === "para") { const c = (u) => [u, (u - 2) ** 2 - 1]; g.param(c, -2, 6, { color: "muted", w: 2.4, dash: "6 6" }); g.param((u) => mv(c(u)), -2, 6, { color: "a", w: 3 }); }
      if (s.shape === "circle") { const c = (u) => [3 + Math.cos(u), 1 + Math.sin(u)]; g.param(c, 0, 7, { color: "muted", w: 2.4, dash: "6 6" }); g.param((u) => mv(c(u)), 0, 7, { color: "a", w: 3 }); }
      const P = s.P, Q = this.R(s, P), M = lerp(P, Q, 0.5);
      g.seg(P, Q, { color: "muted", w: 1.4, dash: "3 5" });
      if (s.ax !== "o" && dist(P, Q) > 0.4) g.right(M, P, s.ax === "yx" ? [M[0] + 1, M[1] + 1] : s.ax === "x" ? [M[0] + 1, 0] : [0, M[1] + 1], { size: 10 });
      g.point(M, "", { r: 3, color: "e" });
      g.point(P, `P${pt(P)}`, { color: "b" }).point(mv(P), s.t > 0.98 ? `P′${pt(Q)}` : "", { color: "a" });
      g.handle(P, "P", { color: "b" });
    },
    metrics(s) {
      const Q = this.R(s, s.P), rule = { x: "y 대신 −y", y: "x 대신 −x", o: "x 대신 −x, y 대신 −y", yx: "x와 y를 서로 바꿈" }[s.ax];
      const eq = { none: null, para: { x: "−y = (x − 2)² − 1", y: "y = (−x − 2)² − 1 = (x + 2)² − 1", o: "−y = (−x − 2)² − 1", yx: "x = (y − 2)² − 1" }, circle: { x: "(x − 3)² + (y + 1)² = 1", y: "(x + 3)² + (y − 1)² = 1", o: "(x + 3)² + (y + 1)² = 1", yx: "(x − 1)² + (y − 3)² = 1" } }[s.shape];
      const out = [["점의 이동", `${pt(s.P)} → ${pt(Q)}`, "key"], ["방정식 규칙", rule]];
      if (eq) out.push(["옮긴 도형", eq[s.ax]]);
      return out;
    },
  },
  {
    id: "c2-shortest", grade: G, unit: 2, lesson: "Ⅱ-3", title: "대칭이동으로 찾는 최단 거리", type: "조작", time: "10분",
    tags: ["최단 경로", "대칭", "강가 문제"], links: ["c2-reflection", "geo-tangent-reflect"],
    desc: "x축 위의 점 P를 움직여 AP + PB를 재고, A를 x축에 대칭이동한 A′로 최단 경로를 찾습니다.",
    obs: ["AP = A′P이므로 AP + PB = A′P + PB입니다.", "A′, P, B가 한 직선 위에 있을 때 합이 가장 작습니다.", "그때 빛의 반사처럼 들어가는 각과 나오는 각이 같습니다."],
    q: "A와 B가 x축의 서로 반대쪽에 있으면 최단 경로는 어떻게 될까요?",
    formula: "AP + PB = A′P + PB ≥ A′B",
    en: { title: "Shortest Path by Reflection", desc: "Move P on the x-axis and use the reflection A′ to find the minimum of AP + PB." },
    view: { x: [-7, 7], y: [-4, 6] }, snap: 0.25, points: { A: [-4, 3], B: [3, 2], P: [1, 0] },
    params: [{ key: "ghost", label: "대칭점 A′와 직선 A′B 보이기", type: "check", value: true }],
    buttons: [["best", "P를 최단 위치로"]],
    best(s) { const A2 = [s.A[0], -s.A[1]], t = A2[1] / (A2[1] - s.B[1]); return [A2[0] + (s.B[0] - A2[0]) * t, 0]; },
    onDo(k, s) { if (k === "best") s.P = this.best(s); },
    constrain(s, k, p) { if (k === "P") return [clamp(p[0], -7, 7), 0]; return [clamp(p[0], -7, 7), clamp(p[1], 0.5, 5.5)]; },
    draw(s, g) {
      g.grid();
      const { A, B, P } = s, A2 = [A[0], -A[1]], Pb = this.best(s);
      g.poly([[-7, 0], [7, 0], [7, -4], [-7, -4]], { fill: "b", fo: 0.07, stroke: false });
      g.note(18, 420, "강 (x축 아래)", { color: "b" });
      if (s.ghost) { g.seg(A, A2, { color: "muted", w: 1.2, dash: "3 5" }); g.seg(A2, B, { color: "e", w: 1.8, dash: "6 5" }); g.seg(A2, P, { color: "a", w: 2, dash: "6 5", opacity: 0.6 }); g.point(A2, "A′", { color: "muted", hollow: true }); g.point(Pb, "", { color: "e", r: 4, hollow: true }); }
      g.seg(A, P, { color: "a", w: 3.2 }).seg(P, B, { color: "a", w: 3.2 });
      if (dist(P, Pb) < 0.02) { g.arc(P, [-7, 0], A, { color: "c", r: 26, ccw: false }); g.arc(P, B, [7, 0], { color: "c", r: 26, ccw: false }); }
      g.point(A, "A", { color: "ink" }).point(B, "B", { color: "ink" }).point(P, "P", { color: "a", r: 7 });
      g.handle(A, "A", { color: "b" }).handle(B, "B", { color: "b" }).handle(P, "P");
    },
    metrics(s) {
      const { A, B, P } = s, A2 = [A[0], -A[1]], sum = dist(A, P) + dist(P, B), mn = dist(A2, B);
      return [["AP + PB", fmt(sum)], ["최솟값 A′B", fmt(mn)], ["차이", fmt(sum - mn)], sum - mn < 0.005 ? ["상태", "최단 경로입니다", "key"] : ["상태", "P를 더 옮겨 보세요"]];
    },
  },
];
