// 인공지능 수학 · 수학과 문화 · 직무 수학 — 기하·통계와 관련된 실험
import { fmt, frac, surd, dist, sub, add, mul, norm, dot, len, cross, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const V = { x: [-7, 7], y: [-5, 5] };
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const rot = (p, a) => [p[0] * Math.cos(a) - p[1] * Math.sin(a), p[0] * Math.sin(a) + p[1] * Math.cos(a)];
let seed = 11;
const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-12)) * Math.cos(2 * Math.PI * rnd());
// 분류용 두 무리의 점 (고정)
const CLS = [...Array.from({ length: 22 }, () => [-1.8 + 1.3 * gauss(), 1 + 1.1 * gauss(), 0]), ...Array.from({ length: 22 }, () => [1.8 + 1.3 * gauss(), -0.8 + 1.1 * gauss(), 1])];
// 추세선용 자료 (공부 시간 → 점수)
const TREND = Array.from({ length: 16 }, (_, i) => { const x = 0.6 + i * 0.55 + 0.2 * gauss(); return [x, 1.2 + 0.72 * x + 0.55 * gauss()]; });
const lsq = (P) => { const n = P.length, mx = P.reduce((a, p) => a + p[0], 0) / n, my = P.reduce((a, p) => a + p[1], 0) / n, sxy = P.reduce((a, p) => a + (p[0] - mx) * (p[1] - my), 0), sxx = P.reduce((a, p) => a + (p[0] - mx) ** 2, 0); const a = sxy / sxx; return [a, my - a * mx]; };
const PIX = ["0111100", "0100010", "0100010", "0111100", "0101000", "0100100", "0100010"]; // 글자 R

export default [
  // ───────── 인공지능 수학 (10) ─────────
  {
    id: "ai-text-vector", grade: 10, unit: 1, lesson: "Ⅱ-1", title: "문장을 벡터로 — 코사인 유사도", type: "조작", time: "10분",
    tags: ["텍스트 벡터", "코사인 유사도", "사잇각"], links: ["geo-dot-product"],
    desc: "두 후기에서 ‘맛있다’와 ‘친절하다’가 나온 횟수를 벡터로 나타내고, 두 벡터가 이루는 각의 코사인으로 두 글이 얼마나 비슷한지 잽니다.",
    obs: ["단어 횟수가 두 배가 되어도 방향이 같으면 유사도는 같습니다.", "코사인 유사도는 1에 가까울수록 비슷하고, 0이면 관련이 없습니다.", "검색 엔진과 추천 시스템이 이 방법을 씁니다."],
    q: "‘맛있다 맛있다’와 ‘맛있다’ 두 후기의 코사인 유사도는 얼마일까요?",
    formula: "cos θ = (a · b) / (|a||b|)",
    en: { title: "Sentences as Vectors: Cosine Similarity", desc: "Represent word counts as vectors and compare texts by the angle between them." },
    view: { x: [-0.8, 9.2], y: [-0.8, 6.4] }, snap: 1, points: { A: [6, 2], B: [3, 5] },
    constrain(s, k, p) { return [clamp(Math.round(p[0]), 0, 9), clamp(Math.round(p[1]), 0, 6)]; },
    draw(s, g) {
      g.grid({ xName: "‘맛있다’ 횟수", yName: "‘친절하다’ 횟수" });
      const a = s.A, b = s.B;
      if (len(a) && len(b)) g.arc([0, 0], a, b, { r: 44, color: "e", ccw: false, label: `${fmt(rad2deg(Math.acos(clamp(dot(a, b) / (len(a) * len(b)), -1, 1))), 1)}°` });
      g.vec([0, 0], a, { color: "a", w: 3.4, label: "후기 A" }).vec([0, 0], b, { color: "b", w: 3.4, label: "후기 B" });
      g.handle(a, "A").handle(b, "B", { color: "b" });
    },
    metrics(s) { const a = s.A, b = s.B, c = len(a) && len(b) ? dot(a, b) / (len(a) * len(b)) : NaN; return [["후기 A", `(${a.join(", ")})`], ["후기 B", `(${b.join(", ")})`], ["코사인 유사도", Number.isFinite(c) ? fmt(c, 4) : "—", "key"]]; },
  },
  {
    id: "ai-distance", grade: 10, unit: 1, lesson: "Ⅱ-3", title: "여러 가지 거리 — 유클리드와 맨해튼", type: "조작", time: "8분",
    tags: ["유클리드 거리", "맨해튼 거리", "데이터 거리"], links: ["c2-distance", "ai-knn"],
    desc: "격자 도시에서 두 점 사이의 곧은 거리(유클리드)와 길을 따라가는 거리(맨해튼)를 비교하고, 각 거리로 그린 ‘원’의 모양이 다름을 봅니다.",
    obs: ["맨해튼 거리는 |Δx| + |Δy|로, 유클리드 거리보다 짧아질 수 없습니다.", "맨해튼 거리로 한 점에서 거리가 r인 점들은 마름모를 이룹니다.", "인공지능은 목적에 맞는 거리를 골라 자료의 가까움을 잽니다."],
    q: "택시 요금이 달린 거리에 비례한다면 어떤 거리를 써야 할까요?",
    formula: "유클리드 √(Δx² + Δy²) · 맨해튼 |Δx| + |Δy|",
    en: { title: "Euclidean vs Manhattan Distance", desc: "Compare straight-line and grid distances and their 'circles'." },
    view: V, snap: 1, points: { A: [-4, -2], B: [3, 2] },
    params: [{ key: "r", label: "‘원’의 반지름 r", min: 1, max: 5, step: 1, value: 3 }],
    draw(s, g) {
      g.grid({ labels: false });
      const { A, B } = s, r = s.r;
      g.circle(A, r, { color: "b", w: 1.6, dash: "5 5" });
      g.poly([add(A, [r, 0]), add(A, [0, r]), add(A, [-r, 0]), add(A, [0, -r])], { color: "a", w: 1.6, dash: "5 5" });
      g.path([A, [B[0], A[1]], B], { color: "a", w: 4, opacity: 0.8 });
      g.seg(A, B, { color: "b", w: 3 });
      g.point(A, "A").point(B, "B").handle(A, "A").handle(B, "B");
      g.note(18, 30, "— 유클리드   — 맨해튼", { color: "ink", bold: true });
    },
    metrics(s) { const d = sub(s.B, s.A); return [["유클리드 거리", `${surd(d[0] ** 2 + d[1] ** 2)} ≈ ${fmt(len(d))}`], ["맨해튼 거리", String(Math.abs(d[0]) + Math.abs(d[1])), "key"]]; },
  },
  {
    id: "ai-image-transform", grade: 10, unit: 2, lesson: "Ⅲ-2", title: "행렬로 이미지 변환하기", type: "조작", time: "12분",
    tags: ["행렬", "회전·확대·대칭", "픽셀"], links: ["c2-reflection", "job-moves"],
    desc: "글자 R 모양의 픽셀 그림의 각 점 좌표에 2×2 행렬을 곱해 확대, 회전, 대칭, 기울이기 변환을 하고, 행렬식이 넓이의 배율임을 확인합니다.",
    obs: ["행렬 [[a, b], [c, d]]는 점 (x, y)를 (ax + by, cx + dy)로 옮깁니다.", "회전 행렬은 모양과 크기를 바꾸지 않습니다.", "행렬식 ad − bc는 넓이가 몇 배가 되는지 알려 주고, 음수이면 뒤집힌 것입니다."],
    q: "행렬식이 0이면 그림은 어떻게 될까요?",
    formula: "(x′, y′) = (ax + by, cx + dy) · 넓이 배율 = |ad − bc|",
    en: { title: "Transforming Images with Matrices", desc: "Multiply pixel coordinates by a 2×2 matrix to scale, rotate, reflect and shear." },
    view: V,
    params: [
      { key: "pre", label: "변환", type: "seg", value: "rot", options: [["id", "그대로"], ["sc", "확대"], ["rot", "회전"], ["ref", "대칭"], ["sh", "기울이기"]], rebuild: true },
      { key: "t", label: "변환 정도", min: 0, max: 1, step: 0.01, value: 1, show: (v) => `${Math.round(v * 100)}%` },
      { key: "ang", label: "회전각", min: -180, max: 180, step: 5, value: 45, unit: "°", when: (s) => s.pre === "rot" },
    ],
    anim: { key: "t", min: 0, max: 1, speed: 0.5, label: "변환 보기" },
    mat(s) { const t = s.t, a = deg(s.ang) * t; return { id: [1, 0, 0, 1], sc: [1 + t, 0, 0, 1 + 0.5 * t], rot: [Math.cos(a), -Math.sin(a), Math.sin(a), Math.cos(a)], ref: [1 - 2 * t, 0, 0, 1], sh: [1, 1.2 * t, 0, 1] }[s.pre]; },
    draw(s, g) {
      g.grid({ labels: false });
      const [a, b, c, d] = this.mat(s), T = (p) => [a * p[0] + b * p[1], c * p[0] + d * p[1]], cell = 0.5;
      PIX.forEach((row, i) => [...row].forEach((ch, j) => { if (ch !== "1") return; const x = (j - 3) * cell, y = (3 - i) * cell, sq = [[x, y], [x + cell, y], [x + cell, y + cell], [x, y + cell]]; g.poly(sq, { color: "muted", w: 0.6, fill: "muted", fo: 0.12 }); g.poly(sq.map(T), { fill: "a", fo: 0.75, color: "a", w: 0.6 }); }));
      g.vec([0, 0], T([2, 0]), { color: "b", w: 2.4, label: "e₁ →" }).vec([0, 0], T([0, 2]), { color: "c", w: 2.4, label: "e₂ →" });
      g.note(18, 30, `[[${fmt(a, 2)}, ${fmt(b, 2)}], [${fmt(c, 2)}, ${fmt(d, 2)}]]`, { color: "ink", bold: true, mono: true });
    },
    metrics(s) { const [a, b, c, d] = this.mat(s), det = a * d - b * c; return [["행렬", `[[${fmt(a, 2)}, ${fmt(b, 2)}], [${fmt(c, 2)}, ${fmt(d, 2)}]]`], ["행렬식 ad − bc", fmt(det, 3), "key"], ["넓이 배율", `${fmt(Math.abs(det), 3)}배${det < 0 ? " (뒤집힘)" : ""}`]]; },
  },
  {
    id: "ai-knn", grade: 10, unit: 2, lesson: "Ⅲ-3", title: "가장 가까운 이웃으로 분류하기 (k-NN)", type: "조작", time: "12분",
    tags: ["분류", "거리", "k-최근접 이웃"], links: ["ai-distance"],
    desc: "두 종류의 자료가 섞인 평면에서 새 점을 옮기며 가장 가까운 k개 이웃의 다수결로 종류를 정하고, k에 따라 경계가 어떻게 바뀌는지 봅니다.",
    obs: ["k = 1이면 경계가 들쭉날쭉하고, k가 크면 매끄러워집니다.", "새 점을 중심으로 k번째 이웃까지 닿는 원 안의 점들이 투표합니다.", "k를 홀수로 하면 동점을 피할 수 있습니다."],
    q: "k를 자료의 개수만큼 크게 하면 결과는 어떻게 될까요?",
    formula: "분류 = 가까운 k개 이웃 중 많은 쪽",
    en: { title: "k-Nearest Neighbors", desc: "Classify a new point by a vote of its k nearest neighbors." },
    view: V, points: { Q: [0.2, 0.6] },
    params: [{ key: "k", label: "이웃 수 k", min: 1, max: 15, step: 2, value: 5 }, { key: "bg", label: "분류 경계 색칠", type: "check", value: true }],
    vote(s, q) { const d = CLS.map((p) => [Math.hypot(p[0] - q[0], p[1] - q[1]), p[2]]).sort((a, b) => a[0] - b[0]).slice(0, s.k); const ones = d.filter((x) => x[1]).length; return { cls: ones * 2 > s.k ? 1 : 0, r: d[d.length - 1][0], ones }; },
    draw(s, g) {
      if (s.bg) for (let x = -7; x < 7; x += 0.5) for (let y = -5; y < 5; y += 0.5) { const v = this.vote(s, [x + 0.25, y + 0.25]); g.poly([[x, y], [x + 0.5, y], [x + 0.5, y + 0.5], [x, y + 0.5]], { fill: v.cls ? "b" : "a", fo: 0.1, stroke: false }); }
      g.grid({ labels: false });
      CLS.forEach((p) => g.circle([p[0], p[1]], 0.14, { color: p[2] ? "b" : "a", fill: p[2] ? "b" : "a", fo: 0.9, w: 1 }));
      const v = this.vote(s, s.Q);
      g.circle(s.Q, v.r, { color: "ink", w: 1.6, dash: "5 4" });
      g.point(s.Q, "새 자료", { color: v.cls ? "b" : "a", r: 7 }).handle(s.Q, "Q");
    },
    metrics(s) { const v = this.vote(s, s.Q); return [["이웃 투표", `주황 ${s.k - v.ones} : 파랑 ${v.ones}`], ["분류 결과", v.cls ? "파랑 무리" : "주황 무리", "key"]]; },
  },
  {
    id: "ai-trendline", grade: 10, unit: 3, lesson: "Ⅳ-2·3", title: "추세선과 오차 제곱 — 최소제곱법", type: "조작", time: "12분",
    tags: ["추세선", "손실함수", "오차 제곱"], links: ["g3-scatter", "ai-gradient"],
    desc: "공부 시간과 점수 자료에 직선을 맞추며 각 점의 오차를 한 변으로 하는 정사각형을 그려, 정사각형 넓이의 평균(평균제곱오차)이 가장 작은 직선을 찾습니다.",
    obs: ["오차는 실제 값과 직선이 예측한 값의 차입니다.", "오차 제곱의 평균이 손실함수입니다.", "‘최적선’ 버튼의 직선에서 손실이 가장 작습니다."],
    q: "오차를 제곱하지 않고 그냥 더하면 어떤 문제가 생길까요?",
    formula: "손실 L = (1/n) Σ (yᵢ − (axᵢ + b))²",
    en: { title: "Trend Lines and Least Squares", desc: "Fit a line and minimize the mean of squared errors drawn as squares." },
    view: { x: [-0.6, 9.8], y: [-0.4, 8.4] },
    params: [{ key: "a", label: "기울기 a", min: 0, max: 1.6, step: 0.01, value: 0.4 }, { key: "b", label: "절편 b", min: -1, max: 5, step: 0.05, value: 2.6 }, { key: "sq", label: "오차 제곱을 정사각형으로 보기", type: "check", value: true }],
    buttons: [["best", "최적선으로"]],
    onDo(k, s) { if (k === "best") [s.a, s.b] = lsq(TREND); },
    L(a, b) { return TREND.reduce((acc, [x, y]) => acc + (y - (a * x + b)) ** 2, 0) / TREND.length; },
    draw(s, g) {
      g.grid({ xName: "공부 시간", yName: "점수" });
      TREND.forEach(([x, y]) => { const yh = s.a * x + s.b, e = y - yh; if (s.sq) g.poly([[x, yh], [x + Math.abs(e) * 0.6, yh], [x + Math.abs(e) * 0.6, y], [x, y]], { fill: "d", fo: 0.12, color: "d", w: 0.8 }); g.seg([x, y], [x, yh], { color: "d", w: 1.4 }); g.circle([x, y], 0.1, { color: "b", fill: "b", fo: 1, w: 1, layer: "point" }); });
      g.line([0, s.b], [1, s.a + s.b], { color: "a", w: 3 });
    },
    metrics(s) { const [a, b] = lsq(TREND); return [["지금 직선의 손실", fmt(this.L(s.a, s.b), 4), "key"], ["최소 손실", fmt(this.L(a, b), 4)], ["최적선", `y = ${fmt(a, 3)}x + ${fmt(b, 3)}`]]; },
  },
  {
    id: "ai-gradient", grade: 10, unit: 3, lesson: "Ⅳ-4", title: "경사하강법 — 기울기를 따라 내려가기", type: "조작", time: "12분",
    tags: ["경사하강법", "학습률", "최솟값"], links: ["ai-trendline", "calc-derivative-graph"],
    desc: "손실함수의 그래프 위에서 현재 위치의 기울기 반대 방향으로 조금씩 이동하는 경사하강법을 단계별로 실행하고, 학습률에 따라 수렴하거나 튕겨 나가는 모습을 봅니다.",
    obs: ["다음 위치는 x − η·f′(x)입니다.", "학습률 η가 너무 작으면 느리고, 너무 크면 최솟값을 지나쳐 발산합니다.", "그래프에 골짜기가 여러 개이면 출발점에 따라 다른 곳에 도착할 수 있습니다."],
    q: "f(x) = x² + 2에서 η = 1이면 어떻게 될까요?",
    formula: "xₙ₊₁ = xₙ − η f′(xₙ)",
    en: { title: "Gradient Descent", desc: "Step against the slope with a learning rate and watch convergence or divergence." },
    view: { x: [-4.5, 4.5], y: [-1, 11] },
    params: [
      { key: "fn", label: "손실함수", type: "seg", value: "q", options: [["q", "f(x) = x² + 2"], ["w", "골짜기 두 개"]] },
      { key: "x0", label: "출발점 x₀", min: -4, max: 4, step: 0.1, value: 3.6 },
      { key: "eta", label: "학습률 η", min: 0.02, max: 1.05, step: 0.01, value: 0.2 },
      { key: "n", label: "단계 수", min: 0, max: 30, step: 1, value: 8 },
    ],
    anim: { key: "n", min: 0, max: 30, speed: 3, label: "한 걸음씩" },
    F(s) { return s.fn === "q" ? { f: (x) => x * x + 2, d: (x) => 2 * x } : { f: (x) => 0.15 * x ** 4 - 1.2 * x * x + 0.4 * x + 4, d: (x) => 0.6 * x ** 3 - 2.4 * x + 0.4 }; },
    path(s) { const F = this.F(s); let x = s.x0; const P = [x]; for (let i = 0; i < Math.round(s.n); i++) { x = x - s.eta * F.d(x); if (!Number.isFinite(x) || Math.abs(x) > 1e3) break; P.push(x); } return P; },
    drags: { X: { at: (s) => [s.x0, s.fn === "q" ? s.x0 * s.x0 + 2 : 0.15 * s.x0 ** 4 - 1.2 * s.x0 * s.x0 + 0.4 * s.x0 + 4], move: (s, p) => (s.x0 = Math.round(p[0] * 10) / 10), label: "출발점" } },
    draw(s, g) {
      g.grid();
      const F = this.F(s), P = this.path(s);
      g.fx(F.f, { color: "b", w: 3 });
      for (let i = 0; i + 1 < P.length; i++) if (Math.abs(P[i + 1]) < 5) g.vec([P[i], Math.min(10.8, F.f(P[i]))], [P[i + 1], Math.min(10.8, F.f(P[i + 1]))], { color: "a", w: 1.8, opacity: 0.8 });
      P.forEach((x, i) => { if (Math.abs(x) < 5 && F.f(x) < 11) g.point([x, F.f(x)], i === P.length - 1 ? `x${P.length - 1}` : "", { color: i === P.length - 1 ? "d" : "a", r: i === P.length - 1 ? 6 : 3.5 }); });
    },
    metrics(s) { const P = this.path(s), x = P[P.length - 1], F = this.F(s); return [["현재 x", Math.abs(x) > 1e3 ? "발산" : fmt(x, 4)], ["f′(x)", Math.abs(x) > 1e3 ? "—" : fmt(F.d(x), 4)], ["상태", Math.abs(x) > 50 ? "발산 — η를 줄이세요" : Math.abs(F.d(x)) < 0.01 ? "최솟값 근처에 도착" : "내려가는 중", "key"]]; },
  },

  // ───────── 수학과 문화 (11) ─────────
  {
    id: "cul-perspective", grade: 11, unit: 1, lesson: "Ⅰ-2", title: "원근법과 소실점", type: "조작", time: "10분",
    tags: ["원근법", "소실점", "닮음"], links: ["m2-shadow-height", "g2-parallel-ratios"],
    desc: "소실점을 옮기며 바닥 타일과 같은 높이의 기둥들을 원근법으로 그리고, 실제로 평행한 선들이 한 점에 모이며 크기가 닮음비로 줄어드는 원리를 봅니다.",
    obs: ["실제로 평행한 선은 그림에서 소실점에서 만납니다.", "같은 높이의 기둥은 소실점에 가까울수록 작게 그려집니다.", "기둥 높이의 비는 소실점까지 거리의 비와 같습니다(닮음)."],
    q: "소실점을 수평선 아래로 내리면 그림은 어떤 느낌이 될까요?",
    formula: "(그린 높이) ∝ (소실점까지의 가로 거리)",
    en: { title: "Perspective and the Vanishing Point", desc: "Parallel lines meet at a vanishing point and sizes shrink by similarity." },
    view: V, points: { O: [1, 2.2] },
    params: [{ key: "n", label: "기둥 수", min: 2, max: 8, step: 1, value: 5 }],
    constrain(s, k, p) { return [clamp(p[0], -5, 5), clamp(p[1], -1, 4.6)]; },
    draw(s, g) {
      const O = s.O, base = -4.6;
      g.poly([[-7, O[1]], [7, O[1]], [7, 5], [-7, 5]], { fill: "b", fo: 0.1, stroke: false });
      g.seg([-7, O[1]], [7, O[1]], { color: "muted", w: 1.4 }).text([6.8, O[1]], "수평선", { dy: -8, anchor: "end", color: "muted", size: 12 });
      for (let x = -12; x <= 12; x += 2) g.seg([x, base], O, { color: "grid", w: 1.4 });
      for (let k = 0; k < 9; k++) { const t = 1 - 0.72 ** k, y = base + (O[1] - base) * t, xl = -12 + (O[0] + 12) * t, xr = 12 + (O[0] - 12) * t; g.seg([xl, y], [xr, y], { color: "grid", w: 1.4 }); }
      const P0 = [-6, base], T0 = [-6, base + 3.4];
      g.seg(P0, O, { color: "e", w: 1.2, dash: "4 4" }).seg(T0, O, { color: "e", w: 1.2, dash: "4 4" });
      for (let i = 0; i < s.n; i++) { const t = i / s.n, P = lerp(P0, O, t), T = lerp(T0, O, t); g.seg(P, T, { color: "a", w: Math.max(1.5, 7 * (1 - t)) }); g.circle(T, 0.35 * (1 - t) + 0.05, { color: "c", fill: "c", fo: 0.8, w: 1 }); }
      g.point(O, "소실점", { color: "d" }).handle(O, "O", { color: "d" });
    },
    metrics(s) { return [["소실점", `(${fmt(s.O[0])}, ${fmt(s.O[1])})`], ["원리", "평행선은 소실점에서 만나고 크기는 닮음비로 줄어듦", "key"]]; },
  },
  {
    id: "cul-escher", grade: 11, unit: 1, lesson: "Ⅰ-2", title: "에셔처럼 — 변형 테셀레이션 만들기", type: "조작", time: "10분",
    tags: ["테셀레이션", "평행이동", "예술"], links: ["lab-tessellation", "c2-translation"],
    desc: "정사각형 타일의 윗변을 휘게 만든 만큼 아랫변을 똑같이 평행이동해 파내면, 복잡한 모양으로도 평면을 빈틈없이 덮을 수 있습니다.",
    obs: ["한 변에서 튀어나온 부분은 맞은편 변에서 같은 모양만큼 들어갑니다.", "타일의 넓이는 원래 정사각형과 같습니다.", "에셔는 이 방법으로 새·물고기 모양의 판화를 만들었습니다."],
    q: "평행이동 대신 회전으로 변을 옮겨도 테셀레이션이 될까요?",
    formula: "윗변 곡선 = 아랫변 곡선 + (0, a) · 왼쪽 곡선 = 오른쪽 곡선 − (a, 0)",
    en: { title: "Escher-Style Tessellations", desc: "Bend one edge and translate the change to the opposite edge to tile the plane." },
    view: V, points: { T: [0.4, 0.55], S: [0.3, 0.2] },
    constrain(s, k, p) { return k === "T" ? [clamp(p[0] / 2, 0.1, 0.9), clamp((p[1] - 2) / 2, -0.4, 0.4)] : [clamp(1 - p[1] / 2, 0.1, 0.9), clamp((p[0] - 2) / 2, -0.4, 0.4)]; },
    tile(s) { const a = 2, tx = s.T[0] * a, ty = s.T[1] * a, sy = (1 - s.S[0]) * a, sx = s.S[1] * a; return [[0, 0], [tx, ty], [a, 0], [a + sx, sy], [a, a], [tx, a + ty], [0, a], [sx, sy]]; },
    draw(s, g) {
      const a = 2, T = this.tile(s), cols = ["a", "b", "c", "e"];
      for (let i = -5; i <= 4; i++) for (let j = -4; j <= 3; j++) g.poly(T.map(([x, y]) => [x + i * a, y + j * a]), { fill: cols[((i + j) % 2 + 2) % 2 + (j % 2 ? 2 : 0)], fo: 0.5, color: "ink", w: 1.2 });
      g.handle([s.T[0] * a, a + s.T[1] * a], "T").handle([a + s.S[1] * a, (1 - s.S[0]) * a], "S");
    },
    metrics() { return [["타일 하나의 넓이", "4 (원래 정사각형과 같음)", "key"], ["규칙", "윗변 ↔ 아랫변, 왼쪽 ↔ 오른쪽을 평행이동으로 짝지음"]]; },
  },
  {
    id: "cul-scale", grade: 11, unit: 1, lesson: "Ⅰ-1", title: "피타고라스 음계 — 현의 길이와 어울림", type: "조작", time: "10분",
    tags: ["음계", "비", "진동수"], links: ["lab-lissajous"],
    desc: "현의 길이를 2/3, 3/4, 1/2로 줄이면 어울리는 음(5도, 4도, 옥타브)이 나는 피타고라스 음계를 보고, 두 음의 파동을 겹쳐 간단한 비일수록 무늬가 규칙적임을 확인합니다.",
    obs: ["현의 길이가 1/2이면 진동수는 2배로, 한 옥타브 높은 음입니다.", "진동수의 비가 간단할수록 두 음이 잘 어울립니다.", "두 진동을 가로·세로로 합치면 리사주 무늬가 됩니다."],
    q: "3/2를 계속 곱해 음을 만들면 왜 옥타브로 정확히 돌아오지 않을까요?",
    formula: "진동수 ∝ 1 / 현의 길이 · 5도 = 3 : 2 · 4도 = 4 : 3 · 옥타브 = 2 : 1",
    en: { title: "Pythagorean Scale", desc: "String length ratios 2/3, 3/4, 1/2 give consonant intervals." },
    view: BOX,
    params: [{ key: "iv", label: "음정", type: "select", value: "5", options: [["1", "같은 음 1 : 1"], ["8", "옥타브 2 : 1"], ["5", "완전 5도 3 : 2"], ["4", "완전 4도 4 : 3"], ["3", "장3도 81 : 64"], ["2", "장2도 9 : 8"]] }],
    buttons: [["sound", "♪ 두 음 들어 보기"]],
    R: { 1: [1, 1], 8: [2, 1], 5: [3, 2], 4: [4, 3], 3: [81, 64], 2: [9, 8] },
    onDo(k, s) {
      if (k !== "sound") return;
      try { const [p, q] = this.R[s.iv], AC = window.AudioContext || window.webkitAudioContext, ctx = new AC(), t0 = ctx.currentTime; [262, (262 * p) / q].forEach((f) => { const o = ctx.createOscillator(), g2 = ctx.createGain(); o.frequency.value = f; o.type = "sine"; g2.gain.setValueAtTime(0.0001, t0); g2.gain.exponentialRampToValueAtTime(0.15, t0 + 0.05); g2.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.6); o.connect(g2).connect(ctx.destination); o.start(t0); o.stop(t0 + 1.7); }); } catch (e) {}
    },
    draw(s, g) {
      const [p, q] = this.R[s.iv];
      g.seg([1, 9.6], [15, 9.6], { color: "b", w: 3 }).seg([1, 8.4], [1 + 14 * (q / p), 8.4], { color: "a", w: 3 });
      g.text([15, 9.6], "현 1", { dx: 8, dy: 4, anchor: "start", size: 12, color: "b" }).text([1 + 14 * (q / p), 8.4], `${q}/${p}`, { dx: 8, dy: 4, anchor: "start", size: 12, color: "a" });
      g.param((t) => [1 + (t / (2 * Math.PI * 2)) * 6.4, 5.4 + 0.9 * Math.sin(t)], 0, 4 * Math.PI, { color: "b", w: 1.8 });
      g.param((t) => [1 + (t / (2 * Math.PI * 2)) * 6.4, 3.2 + 0.9 * Math.sin((t * p) / q)], 0, 4 * Math.PI, { color: "a", w: 1.8 });
      g.param((t) => [1 + (t / (2 * Math.PI * 2)) * 6.4, 1.2 + 0.45 * (Math.sin(t) + Math.sin((t * p) / q))], 0, 4 * Math.PI, { color: "e", w: 1.8 });
      g.param((t) => [11.8 + 2.4 * Math.sin(t), 4.2 + 2.4 * Math.sin((t * p) / q)], 0, 2 * Math.PI * Math.min(q, 64), { color: "d", w: 1.2, n: 3000 });
      g.text([4.2, 6.6], "낮은 음", { size: 12, color: "b" }).text([4.2, 4.4], "높은 음", { size: 12, color: "a" }).text([4.2, 2.1], "두 음의 합", { size: 12, color: "e" });
    },
    metrics(s) { const [p, q] = this.R[s.iv]; return [["진동수 비", `${p} : ${q}`, "key"], ["현의 길이", `${q}/${p}`], ["어울림", p * q <= 12 ? "잘 어울림" : "덜 어울림"]]; },
  },
  {
    id: "cul-golden-card", grade: 11, unit: 1, lesson: "Ⅰ-2", title: "우리 주변의 비율 — 황금비·√2·16:9", type: "조작", time: "8분",
    tags: ["황금비", "A4 용지", "화면 비율"], links: ["lab-golden-spiral"],
    desc: "직사각형의 가로세로 비를 바꾸며 황금 직사각형(1.618), A4 용지(√2), 신용카드, 16:9 화면과 비교하고, 반으로 접거나 정사각형을 떼어도 닮은꼴이 되는 비율의 성질을 확인합니다.",
    obs: ["황금 직사각형에서 정사각형을 떼면 남은 직사각형도 황금 직사각형입니다.", "√2 비율(A4)은 반으로 접어도 같은 비율이 됩니다.", "신용카드의 비율(약 1.586)은 황금비에 가깝습니다."],
    q: "A4 용지를 반으로 접으면 A5가 되는데, 두 종이가 닮은꼴인 이유는 무엇일까요?",
    formula: "φ = 1 + 1/φ ≈ 1.618 · √2 = 2 / √2",
    en: { title: "Ratios Around Us", desc: "Compare golden, √2, card and 16:9 rectangles and their self-similarity." },
    view: V,
    params: [{ key: "r", label: "가로 : 세로 비", min: 1, max: 2, step: 0.001, value: 1.618 }, { key: "show", label: "잘라서 닮음 확인", type: "seg", value: "gold", options: [["gold", "정사각형 떼기"], ["half", "반으로 접기"]] }],
    buttons: [["g", "황금비"], ["a4", "A4 (√2)"], ["card", "신용카드"], ["hd", "16 : 9"]],
    onDo(k, s) { s.r = { g: (1 + Math.sqrt(5)) / 2, a4: Math.SQRT2, card: 85.6 / 53.98, hd: 16 / 9 }[k]; },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const h = 5.6, w = h * s.r, O = [-w / 2, -h / 2];
      g.poly([O, add(O, [w, 0]), add(O, [w, h]), add(O, [0, h])], { fill: "b", fo: 0.12, color: "ink", w: 2.4 });
      if (s.show === "gold") { g.poly([O, add(O, [h, 0]), add(O, [h, h]), add(O, [0, h])], { fill: "f", fo: 0.25, color: "f", w: 1.6 }); g.text(add(O, [h / 2, h / 2]), "정사각형", { color: "f", bold: true }); g.text(add(O, [h + (w - h) / 2, h / 2]), `남은 비 ${fmt(h / (w - h || 1), 3)}`, { color: "a", bold: true, size: 13 }); }
      else { g.seg(add(O, [w / 2, 0]), add(O, [w / 2, h]), { color: "a", w: 2, dash: "6 4" }); g.text(add(O, [w / 4, h / 2]), `반쪽 비 ${fmt(h / (w / 2), 3)}`, { color: "a", bold: true, size: 13 }); }
    },
    metrics(s) { const names = [[1.618, "황금비"], [1.414, "A4 용지 √2"], [1.586, "신용카드"], [1.778, "16 : 9 화면"]], near = names.reduce((a, b) => (Math.abs(b[0] - s.r) < Math.abs(a[0] - s.r) ? b : a)); return [["가로 : 세로", `${fmt(s.r, 3)} : 1`, "key"], ["가장 가까운 비율", near[1]], ["정사각형 뗀 뒤", fmt(1 / (s.r - 1), 3)], ["반으로 접은 뒤", fmt(2 / s.r, 3)]]; },
  },
  {
    id: "cul-voting", grade: 11, unit: 2, lesson: "Ⅱ-4", title: "투표 방법에 따라 달라지는 당선자", type: "데이터", time: "12분",
    tags: ["다수결", "보르다", "결선 투표"], links: ["pst-venn"],
    desc: "세 후보에 대한 유권자의 선호 순위 표를 바꾸며 다수결, 결선 투표, 보르다 점수, 일대일 비교로 뽑은 당선자가 서로 다를 수 있음을 확인합니다.",
    obs: ["같은 선호 자료라도 집계 방법에 따라 당선자가 달라질 수 있습니다.", "보르다 방식은 1위 3점, 2위 2점, 3위 1점으로 순위 전체를 반영합니다.", "모든 일대일 대결에서 이기는 후보(콩도르세 승자)가 없을 수도 있습니다."],
    q: "학급 회장 선거에 가장 공정한 방법은 무엇일까요? 이유를 말해 보세요.",
    formula: "보르다 점수 = Σ (순위별 점수 × 표 수)",
    en: { title: "Voting Methods Change the Winner", desc: "Compare plurality, runoff, Borda count and head-to-head winners on the same ballots." },
    view: BOX,
    params: [
      { key: "v1", label: "가 > 나 > 다", min: 0, max: 20, step: 1, value: 8 },
      { key: "v2", label: "나 > 다 > 가", min: 0, max: 20, step: 1, value: 6 },
      { key: "v3", label: "다 > 나 > 가", min: 0, max: 20, step: 1, value: 5 },
      { key: "v4", label: "다 > 가 > 나", min: 0, max: 20, step: 1, value: 2 },
    ],
    B: [["가", "나", "다"], ["나", "다", "가"], ["다", "나", "가"], ["다", "가", "나"]],
    res(s) {
      const c = ["가", "나", "다"], w = [s.v1, s.v2, s.v3, s.v4], first = {}, borda = {}; c.forEach((x) => { first[x] = 0; borda[x] = 0; });
      this.B.forEach((b, i) => { first[b[0]] += w[i]; b.forEach((x, r) => (borda[x] += (3 - r) * w[i])); });
      const beats = (x, y) => this.B.reduce((a, b, i) => a + (b.indexOf(x) < b.indexOf(y) ? w[i] : 0), 0);
      const plural = c.reduce((a, b) => (first[b] > first[a] ? b : a));
      const top2 = [...c].sort((a, b) => first[b] - first[a]).slice(0, 2), runoff = beats(top2[0], top2[1]) >= beats(top2[1], top2[0]) ? top2[0] : top2[1];
      const bor = c.reduce((a, b) => (borda[b] > borda[a] ? b : a));
      const cond = c.find((x) => c.every((y) => y === x || beats(x, y) > beats(y, x))) || "없음";
      return { first, borda, plural, runoff, bor, cond };
    },
    draw(s, g) {
      const r = this.res(s), c = ["가", "나", "다"], cols = { 가: "a", 나: "b", 다: "c" }, mx = Math.max(...Object.values(r.borda), 1);
      g.note(24, 34, "1순위 표", { color: "muted", bold: true }); g.note(330, 34, "보르다 점수", { color: "muted", bold: true });
      c.forEach((x, i) => { const y = 9 - i * 1.4, tot = s.v1 + s.v2 + s.v3 + s.v4 || 1; g.poly([[1, y], [1 + (r.first[x] / tot) * 6, y], [1 + (r.first[x] / tot) * 6, y + 0.9], [1, y + 0.9]], { fill: cols[x], fo: 0.5, stroke: false }); g.text([0.6, y + 0.45], x, { dy: 5, anchor: "end", bold: true }); g.text([1.2 + (r.first[x] / tot) * 6, y + 0.45], String(r.first[x]), { dy: 5, anchor: "start", size: 12 }); g.poly([[8.6, y], [8.6 + (r.borda[x] / mx) * 6, y], [8.6 + (r.borda[x] / mx) * 6, y + 0.9], [8.6, y + 0.9]], { fill: cols[x], fo: 0.5, stroke: false }); g.text([8.8 + (r.borda[x] / mx) * 6, y + 0.45], String(r.borda[x]), { dy: 5, anchor: "start", size: 12 }); });
      [["다수결", r.plural], ["결선 투표", r.runoff], ["보르다", r.bor], ["콩도르세", r.cond]].forEach(([m, wv], i) => { const x = 1.4 + i * 3.6; g.poly([[x, 1], [x + 3.2, 1], [x + 3.2, 3.6], [x, 3.6]], { fill: cols[wv] || "muted", fo: 0.18, color: cols[wv] || "muted", w: 1.4 }); g.text([x + 1.6, 3.1], m, { size: 12, color: "muted", bold: true }); g.text([x + 1.6, 1.9], wv, { size: 22, bold: true, color: cols[wv] || "muted" }); });
    },
    metrics(s) { const r = this.res(s), set = new Set([r.plural, r.runoff, r.bor, r.cond]); return [["다수결 · 결선 · 보르다 · 콩도르세", `${r.plural} · ${r.runoff} · ${r.bor} · ${r.cond}`], ["결론", set.size > 1 ? "방법에 따라 당선자가 다름" : "모든 방법에서 같은 당선자", "key"]]; },
  },
  {
    id: "cul-braille", grade: 11, unit: 3, lesson: "Ⅲ-2", title: "점자 속 경우의 수", type: "조작", time: "8분",
    tags: ["점자", "경우의 수", "2⁶"], links: ["pst-rep-perm", "pst-pascal"],
    desc: "여섯 개의 점을 볼록하게 하거나 평평하게 두는 두 가지 선택으로 만들 수 있는 점자 모양 64가지를 모두 펼치고, 볼록한 점의 개수별로 조합의 수를 셉니다.",
    obs: ["점 하나마다 2가지씩, 6개이므로 2⁶ = 64가지입니다.", "모두 평평한 한 가지를 빼면 실제로 쓸 수 있는 모양은 63가지입니다.", "볼록한 점이 k개인 모양은 ₆Cₖ가지입니다."],
    q: "점이 8개인 점자라면 몇 가지 모양을 만들 수 있을까요?",
    formula: "2⁶ = ₆C₀ + ₆C₁ + … + ₆C₆ = 64",
    en: { title: "Counting in Braille", desc: "Six dots with two states make 2⁶ = 64 patterns." },
    view: BOX,
    params: [{ key: "k", label: "볼록한 점의 개수 강조", min: 0, max: 6, step: 1, value: 3 }],
    draw(s, g) {
      const C = (n, k) => { let r = 1; for (let i = 1; i <= k; i++) r = (r * (n - k + i)) / i; return Math.round(r); };
      for (let m = 0; m < 64; m++) {
        const bits = [0, 1, 2, 3, 4, 5].map((b) => (m >> b) & 1), cnt = bits.reduce((a, b) => a + b, 0), cx = 0.9 + (m % 16) * 0.93, cy = 9.8 - Math.floor(m / 16) * 2.3, hl = cnt === s.k;
        g.poly([[cx - 0.36, cy - 0.95], [cx + 0.36, cy - 0.95], [cx + 0.36, cy + 0.2], [cx - 0.36, cy + 0.2]], { fill: hl ? "f" : "paper", fo: hl ? 0.3 : 1, color: hl ? "f" : "grid", w: 1 });
        bits.forEach((b, i) => g.circle([cx + (i < 3 ? -0.16 : 0.16), cy - (i % 3) * 0.36], 0.09, { color: b ? "ink" : "grid", fill: b ? "ink" : "paper", fo: 1, w: 0.8, layer: "point" }));
      }
      g.note(24, 424, `볼록한 점 ${s.k}개: ₆C${s.k} = ${C(6, s.k)}가지`, { color: "f", bold: true });
    },
    metrics(s) { const C = (n, k) => { let r = 1; for (let i = 1; i <= k; i++) r = (r * (n - k + i)) / i; return Math.round(r); }; return [["전체", "2⁶ = 64가지"], [`볼록한 점 ${s.k}개`, `₆C${s.k} = ${C(6, s.k)}가지`, "key"], ["쓸 수 있는 모양", "63가지 (모두 평평한 것 제외)"]]; },
  },

  // ───────── 직무 수학 (12) ─────────
  {
    id: "job-orthographic", grade: 12, unit: 3, lesson: "Ⅲ-2", title: "쌓기나무 — 위·앞·옆에서 본 모양", type: "3D", time: "12분",
    tags: ["정투상", "쌓기나무", "도면"], links: ["net-fold", "m1-polyhedra"],
    desc: "쌓기나무로 만든 입체를 돌려 보며 위, 앞, 옆에서 본 모양(도면)을 함께 그리고, 도면만 보고 입체를 떠올리는 연습을 합니다.",
    obs: ["위에서 본 모양은 바닥에 놓인 칸의 배치를 보여 줍니다.", "앞과 옆에서 본 모양은 각 줄에서 가장 높은 층수를 보여 줍니다.", "세 도면이 같아도 서로 다른 입체가 있을 수 있습니다."],
    q: "위·앞·옆 모양이 같지만 쌓기나무 개수가 다른 두 입체를 찾아보세요.",
    formula: "앞에서 본 높이 = 각 열의 최댓값 · 옆에서 본 높이 = 각 행의 최댓값",
    en: { title: "Stacked Cubes: Top, Front and Side Views", desc: "Rotate a cube stack and read its three orthographic views." },
    space: true, cam: { yaw: 40, pitch: 28, scale: 44, oy: 30 },
    params: [{ key: "pre", label: "입체", type: "select", value: "stairs", options: [["stairs", "계단"], ["tower", "탑과 날개"], ["L", "ㄴ자 벽"], ["pyr", "피라미드"], ["rand", "무작위"]] }],
    buttons: [["new", "무작위 다시 만들기"]],
    init: () => ({ seed: 5 }),
    onDo(k, s) { if (k === "new") { s.pre = "rand"; s.seed = Math.floor(Math.random() * 1e6); } },
    H(s) {
      if (s.pre === "stairs") return [[3, 2, 1], [2, 1, 0], [1, 0, 0]];
      if (s.pre === "tower") return [[0, 1, 0], [1, 3, 1], [0, 1, 0]];
      if (s.pre === "L") return [[2, 2, 2], [2, 0, 0], [2, 0, 0]];
      if (s.pre === "pyr") return [[1, 1, 1], [1, 2, 1], [1, 1, 1]];
      let x = s.seed || 5; const r = () => ((x = (x * 16807) % 2147483647) / 2147483647); return [0, 1, 2].map(() => [0, 1, 2].map(() => Math.floor(r() * 4)));
    },
    draw(s, g) {
      const H = this.H(s), c = 0.9, o = -1.35;
      for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) for (let k = 0; k < H[i][j]; k++) {
        const x = o + j * c, y = o + (2 - i) * c, z = k * c - 1.2, P = (a, b, cc) => [x + a * c, y + b * c, z + cc * c];
        const faces = [[P(0, 0, 1), P(1, 0, 1), P(1, 1, 1), P(0, 1, 1)], [P(0, 0, 0), P(1, 0, 0), P(1, 0, 1), P(0, 0, 1)], [P(1, 0, 0), P(1, 1, 0), P(1, 1, 1), P(1, 0, 1)], [P(0, 1, 0), P(1, 1, 0), P(1, 1, 1), P(0, 1, 1)], [P(0, 0, 0), P(0, 1, 0), P(0, 1, 1), P(0, 0, 1)]];
        faces.forEach((f, fi) => g.face(f, { fill: ["f", "b", "c", "b", "c"][fi], color: "ink", fo: 0.55, w: 1 }));
      }
      const cell = 13, draw2 = (x0, title, grid) => { g.over.push(`<text x="${x0}" y="${g.H - 70}" class="pl-text b" fill="var(--pl-muted)" font-size="12">${title}</text>`); grid.forEach((row, r) => row.forEach((v, cI) => { if (v) g.over.push(`<rect x="${x0 + cI * cell}" y="${g.H - 60 + r * cell}" width="${cell - 1}" height="${cell - 1}" fill="var(--pl-a)" fill-opacity=".6"/>`); })); };
      const top = H.map((row) => row.map((v) => (v ? 1 : 0)));
      const front = [3, 2, 1].map((lv) => [0, 1, 2].map((j) => (Math.max(H[0][j], H[1][j], H[2][j]) >= lv ? 1 : 0)));
      const side = [3, 2, 1].map((lv) => [2, 1, 0].map((i) => (Math.max(...H[i]) >= lv ? 1 : 0)));
      draw2(20, "위", top); draw2(90, "앞", front); draw2(160, "옆", side);
    },
    metrics(s) { const H = this.H(s), n = H.flat().reduce((a, b) => a + b, 0); return [["쌓기나무 개수", `${n}개`, "key"], ["가장 높은 층", `${Math.max(...H.flat())}층`]]; },
  },
  {
    id: "job-moves", grade: 12, unit: 3, lesson: "Ⅲ-3", title: "도형의 이동 — 밀기·뒤집기·돌리기", type: "조작", time: "8분",
    tags: ["평행이동", "대칭이동", "회전이동"], links: ["c2-translation", "c2-reflection", "m1-pattern"],
    desc: "깃발 모양 조각을 밀기, 뒤집기, 돌리기로 옮기며 모양과 크기는 그대로이고 방향과 위치만 바뀌는 것을 확인합니다(작업 지시서의 도형 배치에 쓰입니다).",
    obs: ["밀기는 방향이 그대로이고 위치만 바뀝니다.", "뒤집기는 거울에 비친 모양처럼 방향이 반대가 됩니다.", "돌리기는 한 점을 중심으로 정해진 각만큼 회전합니다. 두 번 뒤집으면 돌리기가 됩니다."],
    q: "위아래로 뒤집은 뒤 좌우로 뒤집으면 어떤 돌리기와 같을까요?",
    formula: "밀기 (x + a, y + b) · 뒤집기 (−x, y) · 돌리기 90° (−y, x)",
    en: { title: "Slides, Flips and Turns", desc: "Move a flag shape by translation, reflection and rotation." },
    view: V,
    params: [
      { key: "op", label: "이동", type: "seg", value: "rot", options: [["slide", "밀기"], ["flipx", "좌우 뒤집기"], ["flipy", "위아래 뒤집기"], ["rot", "돌리기"]] },
      { key: "a", label: "돌리는 각", min: -270, max: 270, step: 90, value: 90, unit: "°", when: (s) => s.op === "rot" },
      { key: "t", label: "진행", min: 0, max: 1, step: 0.01, value: 1, show: (v) => `${Math.round(v * 100)}%` },
    ],
    anim: { key: "t", min: 0, max: 1, speed: 0.6, label: "움직이기" },
    F: [[0, 0], [0, 3], [2, 2.3], [0.4, 1.7], [0.4, 0]],
    map(s, p, t) { if (s.op === "slide") return add(p, [4 * t, -1.5 * t]); if (s.op === "flipx") return [p[0] * (1 - 2 * t), p[1]]; if (s.op === "flipy") return [p[0], p[1] * (1 - 2 * t)]; return rot(p, deg(s.a) * t); },
    draw(s, g) {
      g.grid({ labels: false });
      g.poly(this.F, { fill: "muted", fo: 0.15, color: "muted", w: 1.6, dash: "5 4" });
      g.poly(this.F.map((p) => this.map(s, p, s.t)), { fill: "a", fo: 0.5, color: "a", w: 2.4 });
      if (s.op === "flipx") g.seg([0, -5], [0, 5], { color: "e", w: 2.4, dash: "7 5" });
      if (s.op === "flipy") g.seg([-7, 0], [7, 0], { color: "e", w: 2.4, dash: "7 5" });
      if (s.op === "rot") { g.point([0, 0], "회전 중심", { color: "e" }); g.arc([0, 0], [0, 3], this.map(s, [0, 3], s.t), { r: 60, color: "e", ccw: s.a >= 0 }); }
    },
    metrics(s) { return [["이동", { slide: "밀기 (오른쪽 4, 아래 1.5)", flipx: "좌우 뒤집기", flipy: "위아래 뒤집기", rot: `${s.a}° 돌리기` }[s.op], "key"], ["바뀌지 않는 것", "모양 · 크기 · 넓이"]]; },
  },
  {
    id: "job-box", grade: 12, unit: 3, lesson: "Ⅲ 프로젝트", title: "포장 상자 설계 — 부피가 가장 큰 상자", type: "조작", time: "12분",
    tags: ["전개도", "부피", "최대"], links: ["m1-surface-area", "calc-derivative-graph"],
    desc: "한 변이 20 cm인 정사각형 판지의 네 귀퉁이에서 한 변이 x cm인 정사각형을 잘라 접어 뚜껑 없는 상자를 만들 때, 부피가 가장 큰 x를 전개도와 그래프로 찾습니다.",
    obs: ["상자의 부피는 V = x(20 − 2x)²입니다.", "x가 너무 작으면 납작하고, 너무 크면 바닥이 좁아집니다.", "부피가 가장 큰 x는 20/6 ≈ 3.33 cm입니다(미분으로 확인)."],
    q: "판지가 가로 30 cm, 세로 20 cm이면 최적의 x는 어떻게 달라질까요?",
    formula: "V(x) = x(20 − 2x)² (0 < x < 10)",
    en: { title: "Designing a Box with Maximum Volume", desc: "Cut corners from a square sheet and find the cut that maximizes volume." },
    view: BOX,
    params: [{ key: "x", label: "잘라 낼 정사각형 x (cm)", min: 0.5, max: 9.5, step: 0.05, value: 2.5 }],
    anim: { key: "x", min: 0.5, max: 9.5, speed: 2, label: "x 바꾸기" },
    V(x) { return x * (20 - 2 * x) ** 2; },
    drags: { X: { at: (s) => [9.4 + (s.x / 10) * 6, 1.2 + ((s.x * (20 - 2 * s.x) ** 2) / 600) * 8.4], move: (s, p) => (s.x = ((p[0] - 9.4) / 6) * 10) } },
    draw(s, g) {
      const k = 0.34, O = [0.8, 1.6], x = s.x, P = (a, b) => [O[0] + a * k, O[1] + b * k];
      g.poly([P(0, 0), P(20, 0), P(20, 20), P(0, 20)], { color: "muted", w: 1.4, dash: "4 4" });
      g.poly([P(x, 0), P(20 - x, 0), P(20 - x, x), P(20, x), P(20, 20 - x), P(20 - x, 20 - x), P(20 - x, 20), P(x, 20), P(x, 20 - x), P(0, 20 - x), P(0, x), P(x, x)], { fill: "f", fo: 0.3, color: "f", w: 2 });
      g.poly([P(x, x), P(20 - x, x), P(20 - x, 20 - x), P(x, 20 - x)], { color: "f", w: 1.2, dash: "3 3" });
      [[0, 0], [20 - x, 0], [20 - x, 20 - x], [0, 20 - x]].forEach(([a, b]) => g.poly([P(a, b), P(a + x, b), P(a + x, b + x), P(a, b + x)], { fill: "d", fo: 0.25, color: "d", w: 1 }));
      g.text(P(10, 10), `바닥 ${fmt(20 - 2 * x, 1)} cm`, { dy: 4, size: 12, bold: true });
      const G0 = [9.4, 1.2], gw = 6, gh = 8.4, Vm = 600, M = (xx, v) => [G0[0] + (xx / 10) * gw, G0[1] + (v / Vm) * gh];
      g.seg(M(0, 0), M(10, 0), { color: "axis", w: 1.3 }).seg(M(0, 0), M(0, Vm), { color: "axis", w: 1.3 });
      [0, 200, 400, 600].forEach((v) => g.text(M(0, v), String(v), { dx: -5, dy: 4, anchor: "end", size: 11, color: "muted" }));
      [0, 5, 10].forEach((v) => g.text(M(v, 0), String(v), { dy: 16, size: 11, color: "muted" }));
      g.param((u) => M(u, this.V(u)), 0, 10, { color: "b", w: 2.6 });
      g.seg(M(x, 0), M(x, this.V(x)), { color: "a", w: 1.4, dash: "4 4" }).point(M(x, this.V(x)), "", { color: "a", r: 6 });
      g.point(M(10 / 3, this.V(10 / 3)), "최대", { color: "d", r: 4, dy: -10, anchor: "middle", dx: 0 });
    },
    metrics(s) { return [["상자 크기", `${fmt(20 - 2 * s.x, 2)} × ${fmt(20 - 2 * s.x, 2)} × ${fmt(s.x, 2)} cm`], ["부피", `${fmt(this.V(s.x), 1)} cm³`, "key"], ["최대 부피", `${fmt(this.V(10 / 3), 1)} cm³ (x = 10/3)`]]; },
  },
  {
    id: "job-perimeter-area", grade: 12, unit: 3, lesson: "Ⅲ-4", title: "둘레가 같아도 넓이는 다르다 — 울타리 문제", type: "조작", time: "8분",
    tags: ["둘레", "넓이", "최대"], links: ["job-box"],
    desc: "울타리 길이(둘레)가 정해진 직사각형 텃밭에서 가로를 바꾸며 넓이의 변화를 그래프로 보고, 정사각형일 때 넓이가 가장 크다는 것을 확인합니다. 원 모양과도 비교합니다.",
    obs: ["둘레가 같아도 모양에 따라 넓이가 달라집니다.", "직사각형 중에서는 정사각형의 넓이가 가장 큽니다.", "같은 둘레로는 원의 넓이가 가장 큽니다."],
    q: "한쪽이 벽인 텃밭이라면 울타리 세 변으로 넓이를 가장 크게 하려면 어떻게 해야 할까요?",
    formula: "둘레 L일 때 넓이 S = x(L/2 − x), 최대 (L/4)² · 원은 L²/(4π)",
    en: { title: "Same Perimeter, Different Area", desc: "With fixed fencing, see which rectangle (and the circle) gives the largest area." },
    view: BOX,
    params: [{ key: "L", label: "울타리 길이 L (m)", min: 8, max: 40, step: 2, value: 24 }, { key: "x", label: "가로 x (m)", min: 0.5, max: 19.5, step: 0.1, value: 4 }],
    derive(s) { if (s.x > s.L / 2 - 0.5) s.x = s.L / 2 - 0.5; },
    drags: { X: { at: (s) => { const Sm = (s.L / 4) ** 2; return [9 + (s.x / (s.L / 2)) * 6.4, 1.4 + ((s.x * (s.L / 2 - s.x)) / (Sm * 1.3)) * 8.4]; }, move: (s, p) => (s.x = Math.min(s.L / 2 - 0.5, ((p[0] - 9) / 6.4) * (s.L / 2))) } },
    draw(s, g) {
      const w = s.x, h = s.L / 2 - s.x, k = Math.min(6.6 / Math.max(w, h), 0.9), O = [1, 1.4];
      g.poly([O, add(O, [w * k, 0]), add(O, [w * k, h * k]), add(O, [0, h * k])], { fill: "c", fo: 0.25, color: "c", w: 2.4 });
      g.text(add(O, [(w * k) / 2, 0]), `${fmt(w, 1)} m`, { dy: 18, size: 12 }).text(add(O, [w * k, (h * k) / 2]), `${fmt(h, 1)} m`, { dx: 8, anchor: "start", size: 12 });
      const G0 = [9, 1.4], gw = 6.4, gh = 8.4, Sm = (s.L / 4) ** 2, M = (x, v) => [G0[0] + (x / (s.L / 2)) * gw, G0[1] + (v / (Sm * 1.3)) * gh];
      g.seg(M(0, 0), M(s.L / 2, 0), { color: "axis", w: 1.3 }).seg(M(0, 0), M(0, Sm * 1.3), { color: "axis", w: 1.3 });
      g.param((u) => M(u, u * (s.L / 2 - u)), 0, s.L / 2, { color: "b", w: 2.6 });
      g.seg(M(0, s.L ** 2 / (4 * Math.PI)), M(s.L / 2, s.L ** 2 / (4 * Math.PI)), { color: "e", w: 1.4, dash: "5 4" }).text(M(s.L / 2, s.L ** 2 / (4 * Math.PI)), "원", { dx: 6, dy: 4, anchor: "start", color: "e", size: 12, bold: true });
      g.point(M(s.x, s.x * (s.L / 2 - s.x)), "", { color: "a", r: 6 });
      g.text(M(s.L / 4, 0), "가로", { dy: 18, size: 12, color: "muted" });
    },
    metrics(s) { const S = s.x * (s.L / 2 - s.x); return [["넓이", `${fmt(S, 2)} m²`, "key"], ["정사각형일 때", `${fmt((s.L / 4) ** 2, 2)} m²`], ["원일 때", `${fmt(s.L ** 2 / (4 * Math.PI), 2)} m²`]]; },
  },
  {
    id: "job-scale-map", grade: 12, unit: 3, lesson: "Ⅲ-3", title: "축척과 도면 — 닮음으로 실제 거리 구하기", type: "조작", time: "8분",
    tags: ["축척", "닮음비", "도면"], links: ["g2-similarity", "m2-shadow-height"],
    desc: "축척이 1 : n인 도면 위에서 두 지점 사이의 거리를 재고 실제 거리를 계산하며, 넓이는 닮음비의 제곱으로 변한다는 것도 확인합니다.",
    obs: ["도면 위 길이 × n = 실제 길이입니다.", "넓이는 n²배, 부피는 n³배가 됩니다.", "축척의 n이 클수록 넓은 지역을 작게 그린 것입니다."],
    q: "축척 1 : 50000 지도에서 4 cm는 실제로 몇 km일까요?",
    formula: "실제 길이 = 도면 길이 × n · 실제 넓이 = 도면 넓이 × n²",
    en: { title: "Scale Drawings", desc: "Measure on a 1 : n drawing and convert to real distances and areas." },
    view: V, snap: 0.25, points: { A: [-4.5, -2], B: [3.5, 2.5] },
    params: [{ key: "n", label: "축척 1 : n", type: "select", value: 50000, options: [[100, "1 : 100 (건물 도면)"], [1000, "1 : 1000"], [25000, "1 : 25000 (지도)"], [50000, "1 : 50000 (지도)"]] }],
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      g.poly([[-6, -4], [-2, -3.6], [1, -4.2], [5.6, -3], [6, 1.5], [3, 4.2], [-2.5, 4], [-6, 1.8]], { fill: "c", fo: 0.1, color: "c", w: 1.6 });
      g.seg(s.A, s.B, { color: "a", w: 3 });
      g.seg([-6.4, -4.6], [-5.4, -4.6], { color: "ink", w: 3 }).text([-5.9, -4.6], "1 cm", { dy: -8, size: 11 });
      g.point(s.A, "학교").point(s.B, "도서관").handle(s.A, "A").handle(s.B, "B");
    },
    metrics(s) { const d = dist(s.A, s.B), real = d * s.n, str = real >= 100000 ? `${fmt(real / 100000, 2)} km` : `${fmt(real / 100, 1)} m`; return [["도면 위 거리", `${fmt(d, 2)} cm`], ["실제 거리", str, "key"], ["넓이 배율", `n² = ${fmt(s.n * s.n)}배`]]; },
  },
  {
    id: "job-chart-choice", grade: 12, unit: 4, lesson: "Ⅳ-3·4", title: "목적에 맞는 그래프 고르기", type: "데이터", time: "10분",
    tags: ["막대그래프", "꺾은선그래프", "원그래프"], links: ["m1-graph-scale", "histogram"],
    desc: "같은 매출 자료를 막대·꺾은선·원·띠그래프로 바꿔 그리며, 크기 비교·변화 추이·비율 등 목적에 따라 알맞은 그래프가 다름을 확인합니다.",
    obs: ["막대그래프는 항목끼리의 크기 비교에 좋습니다.", "꺾은선그래프는 시간에 따른 변화를 보기에 좋습니다.", "원·띠그래프는 전체에서 차지하는 비율을 보여 줍니다."],
    q: "월별 매출의 증가 추세를 보고할 때 어떤 그래프가 가장 알맞을까요?",
    formula: "비율(%) = 항목 값 / 전체 × 100",
    en: { title: "Choosing the Right Chart", desc: "Draw the same data as bar, line, pie and strip charts and match each to a purpose." },
    view: BOX,
    params: [{ key: "kind", label: "그래프", type: "seg", value: "bar", options: [["bar", "막대"], ["line", "꺾은선"], ["pie", "원"], ["strip", "띠"], ["radar", "방사형"]] }],
    D: [["1월", 32], ["2월", 28], ["3월", 41], ["4월", 47], ["5월", 55], ["6월", 38]],
    draw(s, g) {
      const D = this.D, tot = D.reduce((a, d) => a + d[1], 0), cols = ["a", "b", "c", "e", "f", "d"];
      if (s.kind === "bar" || s.kind === "line") {
        const M = (i, v) => [2 + i * 2.3, 1.2 + (v / 60) * 8.8];
        g.seg([1.2, 1.2], [15.4, 1.2], { color: "axis", w: 1.3 });
        [0, 20, 40, 60].forEach((v) => { g.seg([1.2, M(0, v)[1]], [15.4, M(0, v)[1]], { color: "grid", w: 1 }); g.text([1.2, M(0, v)[1]], String(v), { dx: -5, dy: 4, anchor: "end", size: 11, color: "muted" }); });
        D.forEach(([m, v], i) => { const p = M(i, v); if (s.kind === "bar") g.poly([[p[0] - 0.7, 1.2], [p[0] + 0.7, 1.2], [p[0] + 0.7, p[1]], [p[0] - 0.7, p[1]]], { fill: "b", fo: 0.5, color: "b", w: 1 }); g.text([p[0], 1.2], m, { dy: 16, size: 11.5, color: "muted" }); g.text(p, String(v), { dy: -8, size: 11.5, bold: true }); });
        if (s.kind === "line") { g.path(D.map(([, v], i) => M(i, v)), { color: "a", w: 3 }); D.forEach(([, v], i) => g.point(M(i, v), "", { color: "a", r: 4.5 })); }
      } else if (s.kind === "pie") {
        let a0 = Math.PI / 2; const C = [5.5, 5.6], R = 4.2;
        D.forEach(([m, v], i) => { const a1 = a0 - (2 * Math.PI * v) / tot, pts = [C, ...Array.from({ length: 21 }, (_, k) => add(C, [R * Math.cos(a0 + ((a1 - a0) * k) / 20), R * Math.sin(a0 + ((a1 - a0) * k) / 20)]))]; g.poly(pts, { fill: cols[i], fo: 0.55, color: "paper", w: 2 }); const am = (a0 + a1) / 2; g.text(add(C, [R * 0.66 * Math.cos(am), R * 0.66 * Math.sin(am)]), `${m} ${fmt((100 * v) / tot, 0)}%`, { dy: 4, size: 11.5, bold: true }); a0 = a1; });
      } else if (s.kind === "radar") {
        const Rd = [["맛", 8], ["가격", 6], ["신선도", 9], ["포장", 5], ["배송", 7], ["친환경", 8]], C0 = [8, 5.6], R0 = 4.3, P = (i, v) => add(C0, [(R0 * v) / 10 * Math.cos(Math.PI / 2 - (2 * Math.PI * i) / Rd.length), (R0 * v) / 10 * Math.sin(Math.PI / 2 - (2 * Math.PI * i) / Rd.length)]);
        [2, 4, 6, 8, 10].forEach((lv) => g.poly(Rd.map((_, i) => P(i, lv)), { color: "grid", w: 1 }));
        Rd.forEach(([m], i) => { g.seg(C0, P(i, 10), { color: "grid", w: 1 }); g.text(P(i, 11.6), m, { dy: 4, size: 12, bold: true }); });
        g.poly(Rd.map(([, v], i) => P(i, v)), { fill: "a", fo: 0.3, color: "a", w: 2.6 });
        Rd.forEach(([, v], i) => g.point(P(i, v), "", { color: "a", r: 4 }));
      } else {
        let x = 1; D.forEach(([m, v], i) => { const w = (14 * v) / tot; g.poly([[x, 4.6], [x + w, 4.6], [x + w, 6.6], [x, 6.6]], { fill: cols[i], fo: 0.55, color: "paper", w: 2 }); g.text([x + w / 2, 5.6], m, { dy: -2, size: 11.5, bold: true }).text([x + w / 2, 5.6], `${fmt((100 * v) / tot, 0)}%`, { dy: 14, size: 11 }); x += w; });
      }
    },
    metrics(s) { return [["이 그래프가 좋은 목적", { bar: "월별 매출 크기 비교", line: "월에 따른 증감 추세", pie: "상반기 전체 중 각 달의 비율", strip: "여러 해의 비율 구성을 나란히 비교", radar: "한 상품의 여러 평가 항목의 균형 비교 (예: 채소 품질 평가)" }[s.kind], "key"]]; },
  },
];
