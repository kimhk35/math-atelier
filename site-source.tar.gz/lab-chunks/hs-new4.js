// 23차 묶음 11 — 공통수학1 추가 8개 + 공통수학2 추가 10개
import { fmt, frac, poly, clamp, add, sub, mul, len } from "./hs-core.js";

const CM = 14, C2 = 4;
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);
const SUP = "⁰¹²³⁴⁵⁶⁷⁸⁹";
const polyStr = (cs, v = "x") => { const n = cs.length - 1; return poly(cs.slice(0, n).map((c, i) => [c, n - i === 1 ? v : `${v}${SUP[n - i]}`]), cs[n]); };
const rect = (g, x, y, w, h, o) => g.poly([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], o);
const fact = (n) => (n <= 1 ? 1 : n * fact(n - 1));
function matrixDraw(g, x, y, M, o = {}) {
  const cw = o.cw || 1.4, ch = o.ch || 0.95, r = M.length, c = M[0].length, Wd = c * cw, Hd = r * ch;
  M.forEach((row, i) => row.forEach((v, j) => { const col = o.hl ? o.hl(i, j) : null, x0 = x + j * cw, y0 = y - i * ch; if (col) g.poly([[x0 + 0.05, y0 - 0.05], [x0 + cw - 0.05, y0 - 0.05], [x0 + cw - 0.05, y0 - ch + 0.05], [x0 + 0.05, y0 - ch + 0.05]], { fill: col, fo: 0.3, stroke: false }); g.text([x0 + cw / 2, y0 - ch / 2], typeof v === "number" ? fmt(v, o.d ?? 2) : v, { dy: 5, bold: !!col, size: o.size || 15 }); }));
  const br = 0.18; g.path([[x + br, y], [x, y], [x, y - Hd], [x + br, y - Hd]], { color: "ink", w: 2 }).path([[x + Wd - br, y], [x + Wd, y], [x + Wd, y - Hd], [x + Wd - br, y - Hd]], { color: "ink", w: 2 });
  if (o.name) g.text([x + Wd / 2, y + 0.45], o.name, { bold: true, size: 14 });
  return Wd;
}
const mmul = (A, B) => A.map((r) => B[0].map((_, j) => r.reduce((t, v, k) => t + v * B[k][j], 0)));
const DIVP = { a: [1, 5, 6], b: [2, 7, 3], c: [1, 3, -4], d: [1, 0, -9], e: [1, 4, 1] };
const WEA = [[0.7, 0.4], [0.3, 0.6]];
const PROPS = {
  a: { p: "x = 2", q: "x² = 4", P: (x) => x === 2, Q: (x) => x * x === 4 },
  b: { p: "x > 3", q: "x > 1", P: (x) => x > 3, Q: (x) => x > 1 },
  c: { p: "x는 4의 배수", q: "x는 2의 배수", P: (x) => x % 4 === 0, Q: (x) => x % 2 === 0 },
};
const REL = {
  par: { n: "y = x² − 2", f: (t) => [t, t * t - 2], ok: true, t: [-2.6, 2.6] },
  side: { n: "x = y² − 2", f: (t) => [t * t - 2, t], ok: false, t: [-2.6, 2.6] },
  circ: { n: "x² + y² = 9", f: (t) => [3 * Math.cos(t), 3 * Math.sin(t)], ok: false, t: [0, 2 * Math.PI] },
  cube: { n: "y = x³ − 3x", f: (t) => [t, t ** 3 - 3 * t], ok: true, t: [-2.4, 2.4] },
};

export default [
  // ───────── 공통수학1 ─────────
  {
    id: "cm1-box-divide", grade: CM, unit: 1, lesson: "Ⅰ-1", title: "다항식의 나눗셈 — 넓이 상자로 몫 찾기", type: "조작", time: "12분",
    tags: ["다항식의 나눗셈", "몫과 나머지", "넓이 모형"], links: ["cm1-synthetic", "cm1-poly-area"],
    desc: "이차식을 x + k로 나누는 것을 '한 변이 x + k인 직사각형의 다른 변 찾기'로 생각합니다. 상자 칸을 차례로 채워 몫의 항을 하나씩 정하고, 채우지 못하고 남은 상수가 나머지임을 확인합니다. f(x) = (x + k)Q(x) + R도 함께 확인합니다.",
    obs: ["첫 칸 ax²을 채우려면 몫의 첫 항이 ax여야 합니다.", "그 열의 아래 칸 akx를 빼고 남은 x항으로 몫의 다음 항을 정합니다.", "마지막에 남은 상수가 나머지 R = f(−k)입니다."],
    q: "x² − 9를 x + 3으로 나누면 몫과 나머지는 무엇일까요? 상자에서 빈 x항은 어떻게 처리할까요?",
    formula: "f(x) = (x + k)Q(x) + R, R = f(−k)",
    en: { title: "Polynomial Division with an Area Box", desc: "Fill the box to find the quotient." },
    view: BOX,
    params: [
      { key: "p", label: "나누어지는 식", type: "select", value: "a", options: Object.entries(DIVP).map(([k, v]) => [k, polyStr(v)]) },
      { key: "k", label: "나누는 식 x + k의 k", min: -3, max: 3, step: 1, value: 2 },
      { key: "st", label: "단계", min: 0, max: 3, step: 1, value: 3 },
    ],
    anim: { key: "st", min: 0, max: 3, speed: 0.8, label: "칸 채우기" },
    quot(s) { const [a, b, c] = DIVP[s.p], q1 = a, q0 = b - a * s.k, R = c - q0 * s.k; return { q1, q0, R }; },
    draw(s, g) {
      const [a, b, c] = DIVP[s.p], { q1, q0, R } = this.quot(s), x0 = 3, y0 = 8.6, cw = 3.4, ch = 2.2;
      g.text([x0 - 0.3, y0 - ch / 2], "x", { anchor: "end", dy: 6, bold: true, size: 18, color: "b" }).text([x0 - 0.3, y0 - 1.5 * ch], `${s.k < 0 ? "−" : "+"}${Math.abs(s.k)}`, { anchor: "end", dy: 6, bold: true, size: 18, color: "b" });
      if (s.st >= 1) g.text([x0 + cw / 2, y0 + 0.5], `${q1 === 1 ? "" : fmt(q1)}x`, { bold: true, size: 18, color: "a" });
      if (s.st >= 2) g.text([x0 + 1.5 * cw, y0 + 0.5], `${q0 < 0 ? "−" : "+"}${fmt(Math.abs(q0))}`, { bold: true, size: 18, color: "a" });
      const cells = [[0, 0, `${q1 === 1 ? "" : fmt(q1)}x²`, 1], [0, 1, `${fmt(q1 * s.k)}x`, 1], [1, 0, `${fmt(q0)}x`, 2], [1, 1, fmt(q0 * s.k), 2]];
      cells.forEach(([i, j, t, st]) => { rect(g, x0 + i * cw, y0 - (j + 1) * ch, cw, ch, { fill: s.st >= st ? (i ? "c" : "b") : "paper", fo: s.st >= st ? 0.25 : 1, color: "ink", w: 1.6 }); if (s.st >= st) g.text([x0 + (i + 0.5) * cw, y0 - (j + 0.5) * ch], t, { dy: 6, size: 16, bold: true }); });
      g.text([x0 + 2 * cw + 0.6, y0 - 0.6], `f(x) = ${polyStr([a, b, c])}`, { anchor: "start", bold: true, size: 15 });
      if (s.st >= 3) { g.text([x0 + 2 * cw + 0.6, y0 - 1.8], `상자의 합 = ${polyStr([q1, q1 * s.k + q0, q0 * s.k])}`, { anchor: "start", size: 14 }); g.text([x0 + 2 * cw + 0.6, y0 - 3], `나머지 ${polyStr([a, b, c])} − (상자) = ${fmt(R)}`, { anchor: "start", size: 14, bold: true, color: "e" }); }
    },
    metrics(s) { const { q1, q0, R } = this.quot(s), [a, b, c] = DIVP[s.p], fk = a * s.k * s.k - b * s.k + c; return [["몫 Q(x)", polyStr([q1, q0])], ["나머지 R", fmt(R), "key"], [`f(${-s.k})`, fmt(fk)]]; },
    predict: [
      { q: "x² + 5x + 6을 x + 2로 나눈 몫은 x + □에서 □는?", set: (s) => Object.assign(s, { p: "a", k: 2, st: 1 }), reveal: (s) => (s.st = 3), answer: () => 3, why: "x² + 5x + 6 = (x + 2)(x + 3)이라 나머지 0, 몫 x + 3입니다." },
      { q: "x² + 4x + 1을 x + 2로 나눈 나머지는?", set: (s) => Object.assign(s, { p: "e", k: 2, st: 1 }), reveal: (s) => (s.st = 3), answer: () => -3, why: "f(−2) = 4 − 8 + 1 = −3입니다." },
    ],
  },
  {
    id: "cm1-cube-diff", grade: CM, unit: 1, lesson: "Ⅰ-4", title: "a³ − b³ 부피 모형 — 큰 정육면체에서 작은 정육면체 빼기", type: "3D", time: "12분",
    tags: ["인수분해 공식", "부피 모형", "세제곱"], links: ["cm1-poly-area", "pst-binomial-cube"],
    desc: "한 모서리가 a인 정육면체에서 모서리 b인 정육면체를 떼어 내면 남은 부분은 두께가 a − b인 세 덩어리로 나뉩니다. 세 덩어리의 부피 a²(a − b), ab(a − b), b²(a − b)를 더하면 (a − b)(a² + ab + b²)가 됨을 입체로 확인합니다.",
    obs: ["남은 입체를 두께 a − b인 판 세 개로 자를 수 있습니다.", "세 판의 넓은 면은 각각 a × a, a × b, b × b입니다.", "그래서 a³ − b³ = (a − b)(a² + ab + b²)입니다."],
    q: "a³ + b³ = (a + b)(a² − ab + b²)도 비슷한 방법으로 설명할 수 있을까요?",
    formula: "a³ − b³ = (a − b)(a² + ab + b²)",
    en: { title: "Difference of Cubes in 3D", desc: "Remove a small cube from a big one." },
    space: true,
    cam: { yaw: 35, pitch: 24, scale: 46, center: [1.5, 1.5, 1.5] },
    params: [{ key: "a", label: "a", min: 2, max: 4, step: 0.25, value: 3.5 }, { key: "b", label: "b", min: 0.5, max: 3, step: 0.25, value: 2 }, { key: "sep", label: "덩어리 떼어 보기", min: 0, max: 1.2, step: 0.05, value: 0.6 }],
    onChange(s) { if (s.b >= s.a) s.b = s.a - 0.25; },
    box(g, p, d, col) { const [x, y, z] = p, [w, h, t] = d, V = [[x, y, z], [x + w, y, z], [x + w, y + h, z], [x, y + h, z], [x, y, z + t], [x + w, y, z + t], [x + w, y + h, z + t], [x, y + h, z + t]]; [[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4], [2, 3, 7, 6], [1, 2, 6, 5], [0, 3, 7, 4]].forEach((f) => g.face(f.map((i) => V[i]), { fill: col, fo: 0.32, color: col, w: 1.2 })); },
    draw(s, g) {
      const { a, b } = s, d = a - b, e = s.sep;
      this.box(g, [0, 0, b + e], [a, a, d], "b");
      this.box(g, [b + e, 0, 0], [d, a, b], "c");
      this.box(g, [0, b + e * 0.6, 0], [b, d, b], "a");
      if (e < 0.05) g.text([b / 2, b / 2, b / 2], "빈 곳 b³", { color: "muted" });
    },
    metrics(s) { const { a, b } = s, d = a - b; return [["a²(a − b) 파랑", fmt(a * a * d, 3)], ["ab(a − b) 초록", fmt(a * b * d, 3)], ["b²(a − b) 주황", fmt(b * b * d, 3)], ["합 = a³ − b³", `${fmt(a * a * d + a * b * d + b * b * d, 3)} = ${fmt(a ** 3 - b ** 3, 3)}`, "key"]]; },
    predict: [
      { q: "x³ − 8 = (x − 2)(x² + □x + 4)에서 □는?", answer: () => 2, why: "a = x, b = 2이므로 ab = 2x입니다." },
      { q: "a = 3, b = 2일 때 세 덩어리 부피의 합은?", set: (s) => Object.assign(s, { a: 3, b: 2, sep: 0.6 }), answer: () => 19, why: "27 − 8 = 19 = 1 × (9 + 6 + 4)입니다." },
    ],
  },
  {
    id: "cm1-complex-add", grade: CM, unit: 2, lesson: "Ⅱ-1", title: "복소수의 덧셈 — 화살표 이어 붙이기 (보충)", type: "조작", time: "10분",
    tags: ["복소수", "덧셈", "켤레복소수"], links: ["cm1-i-power", "geo-vector-add"],
    desc: "복소수 a + bi를 점 (a, b)로 나타내면, 두 복소수의 덧셈은 실수부끼리·허수부끼리 더하는 것이라 화살표를 이어 붙인 평행사변형의 대각선이 됩니다. 켤레복소수는 가로축에 대한 대칭이고, z + z̄는 실수임을 확인합니다. (복소평면은 교과서 밖 보충 그림입니다.)",
    obs: ["(a + bi) + (c + di) = (a + c) + (b + d)i입니다.", "켤레복소수 a − bi는 점 (a, b)를 가로축에 대칭시킨 점입니다.", "z + z̄ = 2a는 실수, z − z̄ = 2bi는 순허수입니다."],
    q: "z × z̄가 항상 0 이상의 실수가 되는 까닭을 계산으로 확인해 봅시다.",
    formula: "(a + bi) + (c + di) = (a + c) + (b + d)i, z̄ = a − bi",
    en: { title: "Adding Complex Numbers (Enrichment)", desc: "Tip-to-tail arrows." },
    view: { x: [-5, 5], y: [-3.8, 3.8] },
    init: () => ({ z: [2, 1], w: [-1, 2] }),
    params: [{ key: "conj", label: "켤레복소수 z̄도 보이기", type: "check", value: true }],
    drags: { z: { at: (s) => s.z, move: (s, p) => (s.z = [clamp(Math.round(p[0] * 2) / 2, -4, 4), clamp(Math.round(p[1] * 2) / 2, -3.5, 3.5)]), label: "z", color: "a" }, w: { at: (s) => s.w, move: (s, p) => (s.w = [clamp(Math.round(p[0] * 2) / 2, -4, 4), clamp(Math.round(p[1] * 2) / 2, -3.5, 3.5)]), label: "w", color: "b" } },
    draw(s, g) {
      const S = add(s.z, s.w);
      g.grid({ xName: "실수", yName: "허수" });
      g.poly([[0, 0], s.z, S, s.w], { fill: "c", fo: 0.1, stroke: false });
      g.vec([0, 0], s.z, { color: "a", label: "z" }).vec([0, 0], s.w, { color: "b", label: "w" });
      g.vec(s.z, S, { color: "b", w: 1.6, dash: "5 4" }).vec(s.w, S, { color: "a", w: 1.6, dash: "5 4" });
      g.vec([0, 0], S, { color: "c", w: 3.4, label: "z + w" });
      if (s.conj) { g.seg(s.z, [s.z[0], -s.z[1]], { color: "muted", w: 1, dash: "3 4" }); g.point([s.z[0], -s.z[1]], "z̄", { color: "e" }); }
    },
    metrics(s) { const c = (p) => `${fmt(p[0])} ${p[1] < 0 ? "−" : "+"} ${fmt(Math.abs(p[1]))}i`, S = add(s.z, s.w); return [["z, w", `${c(s.z)}, ${c(s.w)}`], ["z + w", c(S), "key"], ["z + z̄", fmt(2 * s.z[0])], ["z × z̄", fmt(s.z[0] ** 2 + s.z[1] ** 2)]]; },
    predict: [
      { q: "(2 + i) + (−1 + 2i)의 허수부는?", set: (s) => Object.assign(s, { z: [2, 1], w: [0, 0] }), reveal: (s) => (s.w = [-1, 2]), answer: () => 3, why: "허수부끼리 1 + 2 = 3, 합은 1 + 3i입니다." },
      { q: "z = 3 + 2i일 때 z × z̄의 값은?", set: (s) => Object.assign(s, { z: [3, 2], conj: false }), reveal: (s) => (s.conj = true), answer: () => 13, why: "(3 + 2i)(3 − 2i) = 9 + 4 = 13입니다." },
    ],
  },
  {
    id: "cm1-profit", grade: CM, unit: 3, lesson: "Ⅲ-2", title: "가격 정하기 — 이익이 가장 큰 값은 꼭짓점", type: "조작", time: "12분",
    tags: ["이차함수의 최대", "활용", "이익"], links: ["cm1-minmax-interval"],
    desc: "학교 축제에서 음료를 팝니다. 한 잔에 x백 원 받으면 (40 − 2x)잔이 팔리고, 한 잔의 재료비는 c백 원입니다. 이익 (x − c)(40 − 2x)는 x에 대한 이차함수라 꼭짓점에서 가장 큽니다. 재료비를 바꾸며 가장 좋은 가격이 어떻게 달라지는지 확인합니다.",
    obs: ["값을 올리면 한 잔의 이익은 커지지만 팔리는 양이 줄어듭니다.", "이익 = (한 잔의 이익) × (팔리는 양)이 이차함수가 됩니다.", "두 근 x = c와 x = 20의 한가운데에서 이익이 가장 큽니다."],
    q: "재료비가 0이라면 가장 좋은 가격은 얼마일까요? 그때도 '비쌀수록 좋다'가 아닌 까닭은?",
    formula: "이익 y = (x − c)(40 − 2x), 최대 x = (c + 20)/2",
    en: { title: "Setting the Best Price", desc: "Maximum profit at the vertex." },
    view: { x: [-1.4, 22.5], y: [-3.2, 16.4] }, // 이익은 14로 나눠 그린다 (아래 Y)
    params: [{ key: "c", label: "한 잔 재료비 c (백 원)", min: 0, max: 12, step: 1, value: 6 }, { key: "x", label: "판매 가격 x (백 원)", min: 0, max: 20, step: 0.5, value: 10 }],
    draw(s, g) {
      const P = (x) => (x - s.c) * (40 - 2 * x), X = (x) => x, Y = (y) => y / 14, xm = (s.c + 20) / 2;
      g.seg([0, 0], [21, 0], { color: "axis", w: 1.4 }).seg([0, Y(-30)], [0, Y(210)], { color: "axis", w: 1.4 });
      for (let x = 5; x <= 20; x += 5) g.text([x, 0], `${x}`, { dy: 16, size: 11, color: "muted" });
      for (let y = 50; y <= 200; y += 50) g.text([0, Y(y)], `${y}`, { dx: -6, anchor: "end", dy: 4, size: 11, color: "muted" });
      g.param((x) => [X(x), Y(P(x))], s.c - 0.8, 20.5, { color: "b", w: 3 });
      g.point([xm, Y(P(xm))], `최대 ${fmt(P(xm), 1)}`, { color: "e" }).point([s.x, Y(P(s.x))], "", { color: "a" });
      g.seg([xm, 0], [xm, Y(P(xm))], { color: "e", w: 1.2, dash: "4 4" });
      g.text([21, 0], "가격", { dy: 30, size: 11, color: "muted" }).text([0.4, Y(214)], "이익 (백 원)", { anchor: "start", size: 11, color: "muted" });
    },
    metrics(s) { const P = (x) => (x - s.c) * (40 - 2 * x), xm = (s.c + 20) / 2; return [[`가격 ${fmt(s.x)}백 원일 때`, `${40 - 2 * s.x}잔 · 이익 ${fmt(P(s.x), 1)}백 원`], ["가장 좋은 가격", `${fmt(xm, 1)}백 원 (이익 ${fmt(P(xm), 1)}백 원)`, "key"]]; },
    predict: [
      { q: "재료비 600원일 때 이익이 가장 큰 가격은 몇 백 원?", set: (s) => Object.assign(s, { c: 6, x: 8 }), reveal: (s) => (s.x = 13), answer: () => 13, why: "(x − 6)(40 − 2x)의 두 근 6과 20의 한가운데 13입니다." },
      { q: "그때 이익은 몇 백 원?", set: (s) => Object.assign(s, { c: 6, x: 13 }), answer: () => 98, why: "7 × 14 = 98백 원, 곧 9800원입니다." },
    ],
  },
  {
    id: "cm1-biquad", grade: CM, unit: 4, lesson: "Ⅳ-1", title: "복이차방정식 — x² = t로 바꾸어 풀기", type: "조작", time: "12분",
    tags: ["사차방정식", "치환", "실근의 개수"], links: ["cm1-cubic-roots"],
    desc: "x⁴ + px² + q = 0에서 x² = t로 놓으면 t² + pt + q = 0이 됩니다. t의 근 하나가 양수이면 x = ±√t로 실근이 2개, 0이면 1개, 음수이면 0개입니다. 위에는 t의 이차함수, 아래에는 x의 사차함수를 나란히 그려 실근의 개수를 맞추어 봅니다.",
    obs: ["x² = t ≥ 0이므로 t의 양수인 근만 실근 x를 만듭니다.", "t의 양근 하나가 x의 실근 두 개(±)가 됩니다.", "사차함수의 그래프는 y축에 대하여 대칭입니다."],
    q: "x⁴ − 5x² + 4 = 0의 네 실근을 구해 봅시다.",
    formula: "x⁴ + px² + q = 0 ⇒ t² + pt + q = 0 (t = x²)",
    en: { title: "Biquadratic Equations", desc: "Substitute t = x²." },
    view: { x: [-4.4, 4.4], y: [-6.2, 6.4] },
    params: [{ key: "p", label: "p", min: -6, max: 4, step: 0.5, value: -5 }, { key: "q", label: "q", min: -4, max: 8, step: 0.5, value: 4 }],
    roots(s) { const D = s.p * s.p - 4 * s.q; if (D < 0) return { t: [], x: [] }; const t = D === 0 ? [-s.p / 2] : [(-s.p - Math.sqrt(D)) / 2, (-s.p + Math.sqrt(D)) / 2], x = []; t.forEach((v) => { if (v > 1e-9) x.push(-Math.sqrt(v), Math.sqrt(v)); else if (Math.abs(v) < 1e-9) x.push(0); }); return { t, x: [...new Set(x.map((v) => +v.toFixed(9)))].sort((a, b) => a - b) }; },
    draw(s, g) {
      const R = this.roots(s), YT = 2.6, YB = -3.4, sc = 0.25;
      g.seg([-4.3, YT], [4.3, YT], { color: "axis", w: 1.2 }).seg([-4.3, YB], [4.3, YB], { color: "axis", w: 1.2 }).seg([0, YB - 2.7], [0, YT + 3.6], { color: "axis", w: 1 });
      g.param((t) => [t, YT + clamp(sc * (t * t + s.p * t + s.q), -2.5, 3.6)], -4.3, 4.3, { color: "a", w: 2.6 });
      g.param((x) => [x, YB + clamp(sc * 0.5 * (x ** 4 + s.p * x * x + s.q), -2.6, 2.9)], -4.3, 4.3, { color: "b", w: 2.6 });
      g.seg([-4.3, YT - 0.02], [0, YT - 0.02], { color: "e", w: 4, opacity: 0.35 });
      R.t.forEach((t) => g.point([t, YT], `t = ${fmt(t, 2)}`, { color: t >= 0 ? "a" : "e", dy: -10 }));
      R.x.forEach((x) => g.point([x, YB], fmt(x, 2), { color: "b", dy: 20 }));
      g.text([-4.2, YT + 3.3], "위: t² + pt + q (t = x², 분홍 띠 t < 0은 쓸 수 없음)", { anchor: "start", bold: true, size: 12, color: "a" }).text([-4.2, YB + 2.6], "아래: x⁴ + px² + q", { anchor: "start", bold: true, size: 12, color: "b" });
    },
    metrics(s) { const R = this.roots(s); return [["t의 근", R.t.map((v) => fmt(v, 3)).join(", ") || "실근 없음"], ["x의 실근", R.x.map((v) => fmt(v, 3)).join(", ") || "없음"], ["실근의 개수", `${R.x.length}개`, "key"]]; },
    predict: [
      { q: "x⁴ − 5x² + 4 = 0의 실근은 몇 개?", set: (s) => Object.assign(s, { p: -5, q: 6 }), reveal: (s) => (s.q = 4), answer: () => 4, why: "t² − 5t + 4 = 0에서 t = 1, 4이고 x = ±1, ±2입니다." },
      { q: "x⁴ + 3x² + 2 = 0의 실근은 몇 개?", set: (s) => Object.assign(s, { p: -5, q: 4 }), reveal: (s) => Object.assign(s, { p: 3, q: 2 }), answer: () => 0, why: "t = −1, −2로 모두 음수라 x² = t를 만족하는 실수 x가 없습니다." },
    ],
  },
  {
    id: "cm1-quad-system-ineq", grade: CM, unit: 4, lesson: "Ⅳ-5", title: "이차부등식과 일차부등식의 연립 — 두 해의 겹침", type: "조작", time: "10분",
    tags: ["연립부등식", "이차부등식", "수직선"], links: ["cm1-quad-ineq", "cm1-ineq-system"],
    desc: "이차부등식 x² − 4x − 5 < 0의 해를 그래프에서 읽고, 일차부등식 x > a의 해와 수직선 위에서 겹쳐 연립부등식의 해를 구합니다. a를 바꾸며 겹치는 부분이 어떻게 줄거나 사라지는지 확인합니다.",
    obs: ["이차부등식의 해는 그래프가 x축보다 아래(또는 위)에 있는 구간입니다.", "연립부등식의 해는 두 해의 공통부분입니다.", "공통부분이 없으면 해가 없습니다."],
    q: "x² − 4x − 5 < 0과 x > a를 동시에 만족하는 정수가 2개뿐이려면 a는 어떤 범위여야 할까요?",
    formula: "x² − 4x − 5 < 0 ⇔ −1 < x < 5",
    en: { title: "Systems with a Quadratic Inequality", desc: "Overlap the two solution sets." },
    view: { x: [-4, 8], y: [-10, 7] },
    params: [{ key: "a", label: "일차부등식 x > a의 a", min: -3, max: 6, step: 0.5, value: 2 }, { key: "r1", label: "이차식의 작은 근", min: -3, max: 2, step: 1, value: -1 }, { key: "r2", label: "이차식의 큰 근", min: 3, max: 7, step: 1, value: 5 }],
    draw(s, g) {
      const f = (x) => (x - s.r1) * (x - s.r2), lo = Math.max(s.r1, s.a), ok = lo < s.r2;
      g.grid({ step: 1, every: 2 });
      g.fx(f, { color: "b", w: 3 });
      g.region(f, () => 0, s.r1, s.r2, { fill: "b", fo: 0.15 });
      g.seg([s.r1, -7.5], [s.r2, -7.5], { color: "b", w: 5 }).point([s.r1, -7.5], "", { color: "b", hollow: true }).point([s.r2, -7.5], "", { color: "b", hollow: true });
      g.seg([s.a, -8.5], [7.8, -8.5], { color: "a", w: 5 }).point([s.a, -8.5], "", { color: "a", hollow: true });
      if (ok) { g.seg([lo, -9.5], [s.r2, -9.5], { color: "c", w: 7 }).point([lo, -9.5], "", { color: "c", hollow: true }).point([s.r2, -9.5], "", { color: "c", hollow: true }); }
      g.text([-3.8, -7.5], "이차", { anchor: "start", dy: 4, size: 11, bold: true, color: "b" }).text([-3.8, -8.5], "일차", { anchor: "start", dy: 4, size: 11, bold: true, color: "a" }).text([-3.8, -9.5], "공통", { anchor: "start", dy: 4, size: 11, bold: true, color: "c" });
    },
    metrics(s) { const lo = Math.max(s.r1, s.a); let n = 0; for (let x = Math.floor(lo) + 1; x < s.r2; x++) if (x > lo) n++; return [["이차부등식의 해", `${fmt(s.r1)} < x < ${fmt(s.r2)}`], ["연립부등식의 해", lo < s.r2 ? `${fmt(lo)} < x < ${fmt(s.r2)}` : "해가 없다", "key"], ["해 속의 정수", `${n}개`]]; },
    predict: [
      { q: "x² − 4x − 5 < 0, x > 2를 함께 만족하는 정수는 몇 개?", set: (s) => Object.assign(s, { r1: -1, r2: 5, a: -2 }), reveal: (s) => (s.a = 2), answer: () => 2, why: "2 < x < 5이므로 정수 3, 4의 2개입니다." },
      { q: "a = 6이면 연립부등식의 해는?", options: O("해가 없다", "x > 6", "−1 < x < 6"), set: (s) => Object.assign(s, { r1: -1, r2: 5, a: 2 }), reveal: (s) => (s.a = 6), answer: () => "a", why: "x > 6과 −1 < x < 5는 겹치는 부분이 없습니다." },
    ],
  },
  {
    id: "cm1-matrix-power", grade: CM, unit: 6, lesson: "Ⅵ-3", title: "행렬의 거듭제곱 — 내일과 모레의 날씨", type: "조작", time: "12분",
    tags: ["행렬의 곱셈", "거듭제곱", "활용"], links: ["cm1-matrix-mul"],
    desc: "오늘이 맑으면 내일 맑을 확률 0.7, 오늘 비면 내일 맑을 확률 0.4인 날씨 규칙을 행렬 A로 나타냅니다. A를 거듭 곱한 Aⁿ의 성분이 n일 뒤의 날씨 확률이고, n이 커질수록 오늘 날씨와 상관없이 일정한 값에 가까워짐을 확인합니다.",
    obs: ["A의 (i, j) 성분은 'j인 날 다음 날이 i일 확률'입니다.", "A²의 성분은 두 날을 거친 모든 경우의 확률을 더한 것입니다.", "n이 커지면 Aⁿ의 두 열이 같아져 '오래 뒤의 날씨'는 오늘과 무관해집니다."],
    q: "맑은 날의 비율이 결국 4/7 ≈ 0.571에 가까워지는 까닭을 식으로 확인해 봅시다.",
    formula: "Aⁿ = A × A × ⋯ × A (n개)",
    en: { title: "Matrix Powers — Weather Tomorrow", desc: "Powers of a transition matrix." },
    view: BOX,
    params: [{ key: "n", label: "며칠 뒤 n", min: 1, max: 12, step: 1, value: 2 }],
    anim: { key: "n", min: 1, max: 12, speed: 1.5, label: "하루씩" },
    pow(n) { let M = [[1, 0], [0, 1]]; for (let i = 0; i < n; i++) M = mmul(WEA, M); return M; },
    draw(s, g) {
      const M = this.pow(s.n);
      g.text([1, 10.2], "열: 오늘 (맑음, 비)   행: n일 뒤 (맑음, 비)", { anchor: "start", size: 12, color: "muted" });
      matrixDraw(g, 1, 8.6, WEA, { name: "A", d: 2 });
      g.text([4.6, 7.6], `→ A${[...String(s.n)].map((d) => SUP[d]).join("")} =`, { anchor: "start", dy: 6, size: 18, bold: true });
      matrixDraw(g, 7.6, 8.6, M, { cw: 2, d: 4, hl: (i) => (i ? "b" : "a") });
      M[0].forEach((p, j) => { const x = 2 + j * 6.5; rect(g, x, 1.2, 5.6 * p, 1.4, { fill: "a", fo: 0.5, stroke: false }); rect(g, x + 5.6 * p, 1.2, 5.6 * (1 - p), 1.4, { fill: "b", fo: 0.5, stroke: false }); g.text([x, 3.1], `오늘 ${j ? "비" : "맑음"} → ${s.n}일 뒤 맑을 확률 ${fmt(p, 3)}`, { anchor: "start", size: 12, bold: true }); });
    },
    metrics(s) { const M = this.pow(s.n); return [[`오늘 맑음 → ${s.n}일 뒤 맑음`, fmt(M[0][0], 4)], [`오늘 비 → ${s.n}일 뒤 맑음`, fmt(M[0][1], 4)], ["오래 뒤 다가가는 값", `4/7 ≈ ${fmt(4 / 7, 4)}`, "key"]]; },
    predict: [
      { q: "오늘 맑으면 모레(2일 뒤) 맑을 확률은?", set: (s) => (s.n = 1), reveal: (s) => (s.n = 2), answer: () => 0.61, tol: 1e-6, why: "A²의 (1, 1) 성분 = 0.7 × 0.7 + 0.4 × 0.3 = 0.61입니다." },
      { q: "n이 아주 크면 오늘 날씨와 상관없이 n일 뒤 맑을 확률은? (소수 셋째 자리까지)", set: (s) => (s.n = 2), reveal: (s) => (s.n = 12), answer: () => 4 / 7, tol: 0.002, why: "p = 0.7p + 0.4(1 − p)를 풀면 p = 4/7 ≈ 0.571입니다." },
    ],
  },
  {
    id: "cm1-identity-matrix", grade: CM, unit: 6, lesson: "Ⅵ-3", title: "단위행렬과 영행렬 — 곱해도 그대로, 곱하면 0", type: "조작", time: "10분",
    tags: ["단위행렬", "영행렬", "행렬의 곱셈"], links: ["cm1-matrix-mul", "cm1-matrix-power"],
    desc: "단위행렬 E = (1 0; 0 1)은 수의 1처럼 AE = EA = A가 됩니다. 또 수에서는 ab = 0이면 a = 0 또는 b = 0이지만, 행렬에서는 A ≠ O, B ≠ O인데 AB = O가 되는 경우가 있음을 성분을 바꾸며 확인합니다.",
    obs: ["단위행렬은 대각선 성분이 1이고 나머지가 0인 정사각행렬입니다.", "AE = EA = A로 곱셈의 항등원 역할을 합니다.", "A = (1 1; 1 1), B = (1 −1; −1 1)이면 AB = O입니다."],
    q: "A² = O인데 A ≠ O인 2 × 2 행렬을 하나 만들어 봅시다.",
    formula: "AE = EA = A, E = (1 0; 0 1)",
    en: { title: "Identity and Zero Matrices", desc: "Multiplying by E keeps A; AB can be O." },
    view: BOX,
    params: [
      { key: "mode", label: "보기", type: "seg", value: "e", options: [["e", "A × E"], ["z", "AB = O?"]] },
      { key: "a", label: "a₁₁", min: -3, max: 3, step: 1, value: 2 }, { key: "b", label: "a₁₂", min: -3, max: 3, step: 1, value: 1 },
      { key: "c", label: "a₂₁", min: -3, max: 3, step: 1, value: -1 }, { key: "d", label: "a₂₂", min: -3, max: 3, step: 1, value: 3 },
    ],
    draw(s, g) {
      const A = [[s.a, s.b], [s.c, s.d]], B = s.mode === "e" ? [[1, 0], [0, 1]] : [[1, -1], [-1, 1]], C = mmul(A, B), zero = C.flat().every((v) => v === 0);
      matrixDraw(g, 0.8, 7.6, A, { name: "A", d: 0 });
      g.text([4.0, 6.6], "×", { dy: 7, size: 22, bold: true });
      matrixDraw(g, 4.6, 7.6, B, { name: s.mode === "e" ? "E" : "B", d: 0 });
      g.text([7.8, 6.6], "=", { dy: 7, size: 22, bold: true });
      matrixDraw(g, 8.6, 7.6, C, { name: "결과", d: 0, hl: () => (zero ? "c" : null) });
      g.text([1, 3.4], s.mode === "e" ? "A × E = A: 단위행렬은 수의 1과 같아요" : zero ? "A ≠ O, B ≠ O인데 AB = O!" : "AB가 O가 되도록 A를 바꿔 보세요 (힌트: 두 행이 같게)", { anchor: "start", bold: true, size: 15, color: zero || s.mode === "e" ? "c" : "e" });
    },
    metrics(s) { const A = [[s.a, s.b], [s.c, s.d]], B = s.mode === "e" ? [[1, 0], [0, 1]] : [[1, -1], [-1, 1]], C = mmul(A, B); return [["결과", `(${C[0].join(", ")}; ${C[1].join(", ")})`], [s.mode === "e" ? "AE = A?" : "AB = O?", s.mode === "e" ? "예" : C.flat().every((v) => v === 0) ? "예" : "아니요", "key"]]; },
    predict: [
      { q: "A = (1 1; 1 1), B = (1 −1; −1 1)일 때 AB의 (1, 1) 성분은?", set: (s) => Object.assign(s, { mode: "z", a: 2, b: 1, c: -1, d: 3 }), reveal: (s) => Object.assign(s, { a: 1, b: 1, c: 1, d: 1 }), answer: () => 0, why: "1 × 1 + 1 × (−1) = 0이고, 다른 성분도 모두 0이라 AB = O입니다." },
      { q: "행렬에서 AB = O이면 반드시 A = O 또는 B = O일까요?", options: O("아니다", "그렇다"), answer: () => "a", why: "위의 예처럼 둘 다 O가 아니어도 AB = O일 수 있습니다." },
    ],
  },

  // ───────── 공통수학2 ─────────
  {
    id: "c2-collinear", grade: C2, unit: 1, lesson: "Ⅰ-2", title: "세 점이 한 직선 위에 — 기울기가 같을 조건", type: "조작", time: "10분",
    tags: ["직선의 방정식", "기울기", "세 점"], links: ["c2-line-eq", "c2-shoelace"],
    desc: "세 점 A, B, C가 한 직선 위에 있으려면 AB의 기울기와 BC의 기울기가 같아야 합니다. 점 C를 움직이며 두 기울기를 비교하고, 같아지는 순간 세 점이 만드는 삼각형의 넓이가 0이 되는 것도 확인합니다.",
    obs: ["(AB의 기울기) = (BC의 기울기)이면 세 점은 한 직선 위에 있습니다.", "기울기가 다르면 세 점은 삼각형을 이룹니다.", "세 점이 한 직선 위에 있으면 삼각형의 넓이가 0입니다."],
    q: "세 점 (1, 2), (3, 6), (k, 10)이 한 직선 위에 있도록 k를 구해 봅시다.",
    formula: "(y₂ − y₁)/(x₂ − x₁) = (y₃ − y₂)/(x₃ − x₂)",
    en: { title: "Three Collinear Points", desc: "Equal slopes." },
    view: { x: [-6, 6], y: [-4.6, 4.6] },
    init: () => ({ A: [-3, -2], B: [0, 0], C: [3, 3] }),
    drags: ["A", "B", "C"].reduce((o, k, i) => ((o[k] = { at: (s) => s[k], move: (s, p) => (s[k] = [clamp(Math.round(p[0] * 2) / 2, -5.5, 5.5), clamp(Math.round(p[1] * 2) / 2, -4, 4)]), label: k, color: ["a", "b", "c"][i] }), o), {}),
    draw(s, g) { g.grid(); g.poly([s.A, s.B, s.C], { fill: "e", fo: 0.15, color: "muted", w: 1 }); g.seg(s.A, s.B, { color: "a", w: 2.6 }).seg(s.B, s.C, { color: "c", w: 2.6 }); g.point(s.A, "A", { color: "a" }).point(s.B, "B", { color: "b" }).point(s.C, "C", { color: "c" }); },
    metrics(s) { const m = (P, Q) => (Q[0] === P[0] ? "∞" : frac((Q[1] - P[1]) / (Q[0] - P[0]))), area = Math.abs((s.B[0] - s.A[0]) * (s.C[1] - s.A[1]) - (s.C[0] - s.A[0]) * (s.B[1] - s.A[1])) / 2; return [["AB의 기울기", m(s.A, s.B)], ["BC의 기울기", m(s.B, s.C)], ["삼각형의 넓이", fmt(area, 2)], ["한 직선 위?", area < 1e-9 ? "예" : "아니요", "key"]]; },
    predict: [
      { q: "(1, 2), (3, 6), (k, 10)이 한 직선 위에 있으려면 k는?", answer: () => 5, why: "기울기 (6 − 2)/(3 − 1) = 2이므로 (10 − 6)/(k − 3) = 2, k = 5입니다." },
      { q: "A(−3, −2), B(0, 0)일 때 C(3, □)가 한 직선 위에 있으려면 □는?", set: (s) => Object.assign(s, { A: [-3, -2], B: [0, 0], C: [3, 3] }), reveal: (s) => (s.C = [3, 2]), answer: () => 2, why: "AB의 기울기 2/3이므로 C는 (3, 2)입니다." },
    ],
  },
  {
    id: "c2-shoelace", grade: C2, unit: 1, lesson: "Ⅰ 탐구", title: "좌표로 구하는 삼각형의 넓이 — 신발끈 공식", type: "조작", time: "10분",
    tags: ["좌표", "넓이", "탐구"], links: ["c2-collinear", "c2-centroid"],
    desc: "세 꼭짓점의 좌표를 알면 삼각형을 둘러싼 직사각형에서 세 직각삼각형을 빼거나, 좌표를 엇갈려 곱하는 신발끈 공식으로 넓이를 구할 수 있습니다. 꼭짓점을 끌며 두 방법의 값이 같은지 확인합니다.",
    obs: ["둘러싼 직사각형 − (모서리의 직각삼각형 세 개) = 삼각형의 넓이입니다.", "신발끈 공식: ½|x₁y₂ + x₂y₃ + x₃y₁ − x₂y₁ − x₃y₂ − x₁y₃|입니다.", "꼭짓점을 시계 방향으로 쓰든 반대로 쓰든 절댓값을 취하면 같습니다."],
    q: "같은 방법을 사각형에도 쓸 수 있을까요? 꼭짓점을 어떤 순서로 써야 할까요?",
    formula: "S = ½|x₁(y₂ − y₃) + x₂(y₃ − y₁) + x₃(y₁ − y₂)|",
    en: { title: "The Shoelace Formula", desc: "Triangle area from coordinates." },
    view: { x: [-6, 6], y: [-4.6, 4.6] },
    init: () => ({ A: [-4, -2], B: [3, -3], C: [1, 3] }),
    drags: ["A", "B", "C"].reduce((o, k, i) => ((o[k] = { at: (s) => s[k], move: (s, p) => (s[k] = [clamp(Math.round(p[0]), -5, 5), clamp(Math.round(p[1]), -4, 4)]), label: k, color: ["a", "b", "c"][i] }), o), {}),
    draw(s, g) {
      const P = [s.A, s.B, s.C], xs = P.map((p) => p[0]), ys = P.map((p) => p[1]), x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
      g.grid();
      g.poly([[x0, y0], [x1, y0], [x1, y1], [x0, y1]], { color: "muted", w: 1.4, dash: "5 4" });
      g.poly(P, { fill: "b", fo: 0.25, color: "b", w: 2.4 });
      P.forEach((p, i) => g.point(p, `${"ABC"[i]}(${p[0]}, ${p[1]})`, { color: ["a", "b", "c"][i] }));
    },
    metrics(s) { const [[a, b], [c, d], [e, f]] = [s.A, s.B, s.C], S = Math.abs(a * (d - f) + c * (f - b) + e * (b - d)) / 2, xs = [a, c, e], ys = [b, d, f], R = (Math.max(...xs) - Math.min(...xs)) * (Math.max(...ys) - Math.min(...ys)); return [["신발끈 공식", fmt(S, 2), "key"], ["둘러싼 직사각형", fmt(R, 2)], ["빼는 세 직각삼각형의 합", fmt(R - S, 2)]]; },
    predict: [
      { q: "A(0, 0), B(4, 0), C(1, 3)인 삼각형의 넓이는?", set: (s) => Object.assign(s, { A: [-4, -2], B: [3, -3], C: [1, 3] }), reveal: (s) => Object.assign(s, { A: [0, 0], B: [4, 0], C: [1, 3] }), answer: () => 6, why: "밑변 4, 높이 3이므로 6입니다. 공식으로도 ½|0 + 12 + 0| = 6입니다." },
      { q: "세 점이 한 직선 위에 있으면 공식의 값은?", answer: () => 0, why: "삼각형이 납작해져 넓이가 0입니다." },
    ],
  },
  {
    id: "c2-circle-line-dist", grade: C2, unit: 2, lesson: "Ⅱ-2", title: "원 위의 점과 직선 사이의 거리 — 최대 d + r, 최소 d − r", type: "조작", time: "12분",
    tags: ["점과 직선 사이의 거리", "원", "최대와 최소"], links: ["c2-circle-line", "c2-point-line"],
    desc: "원 위의 점 P를 돌리며 직선까지의 거리를 재면, 중심에서 직선까지의 거리 d에 반지름 r을 더한 값이 가장 크고 뺀 값이 가장 작습니다. 그 두 점은 중심을 지나 직선에 수직인 선 위에 있음을 확인합니다.",
    obs: ["중심에서 직선까지의 거리 d는 점과 직선 사이의 거리 공식으로 구합니다.", "원 위의 점과 직선 사이의 거리는 d − r부터 d + r까지입니다.", "d < r이면 원과 직선이 만나 최솟값이 0입니다."],
    q: "원 x² + y² = 4 위의 점과 직선 3x + 4y = 20 사이의 거리의 최솟값을 구해 봅시다.",
    formula: "최대 d + r, 최소 d − r (d > r)",
    en: { title: "Distance from a Circle to a Line", desc: "Max d + r, min d − r." },
    view: { x: [-6, 6.5], y: [-4.6, 4.6] },
    params: [{ key: "r", label: "반지름 r", min: 0.5, max: 3, step: 0.1, value: 2 }, { key: "c", label: "직선 3x + 4y = c의 c", min: -20, max: 25, step: 1, value: 20 }, { key: "t", label: "점 P의 위치", min: 0, max: 6.28, step: 0.01, value: 2.5 }],
    anim: { key: "t", min: 0, max: 6.28, speed: 0.8, label: "P 돌리기", loop: "wrap" },
    draw(s, g) {
      const n = [3 / 5, 4 / 5], d = s.c / 5, P = [s.r * Math.cos(s.t), s.r * Math.sin(s.t)], dP = (3 * P[0] + 4 * P[1] - s.c) / 5, foot = sub(P, mul(n, dP));
      g.grid();
      g.lineABC(3, 4, -s.c, { color: "ink", w: 2.6 });
      g.circle([0, 0], s.r, { color: "b", w: 2.6 });
      g.seg(mul(n, -s.r * Math.sign(d || 1)), mul(n, d), { color: "muted", w: 1.2, dash: "4 4" });
      g.point(mul(n, s.r * Math.sign(d || 1)), "최소", { color: "c", r: 4 }).point(mul(n, -s.r * Math.sign(d || 1)), "최대", { color: "e", r: 4 });
      g.seg(P, foot, { color: "a", w: 2.4 }).point(P, "P", { color: "a" });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], `직선 3x + 4y = ${s.c}`, { anchor: "start", bold: true });
    },
    metrics(s) { const d = Math.abs(s.c) / 5, P = [s.r * Math.cos(s.t), s.r * Math.sin(s.t)]; return [["중심과 직선의 거리 d", fmt(d, 3)], ["P와 직선의 거리", fmt(Math.abs(3 * P[0] + 4 * P[1] - s.c) / 5, 3)], ["최대 · 최소", `${fmt(d + s.r, 3)} · ${fmt(Math.max(0, d - s.r), 3)}`, "key"]]; },
    predict: [
      { q: "원 x² + y² = 4 위의 점과 직선 3x + 4y = 20 사이 거리의 최솟값은?", set: (s) => Object.assign(s, { r: 2, c: 20, t: 4 }), reveal: (s) => (s.t = Math.atan2(4, 3)), answer: () => 2, why: "d = 20/5 = 4이므로 최솟값 4 − 2 = 2입니다." },
      { q: "같은 조건에서 최댓값은?", set: (s) => Object.assign(s, { r: 2, c: 20 }), answer: () => 6, why: "d + r = 4 + 2 = 6입니다." },
    ],
  },
  {
    id: "c2-two-circles", grade: C2, unit: 2, lesson: "Ⅱ 탐구", title: "두 원의 위치 관계 — 중심 거리와 반지름의 합·차", type: "조작", time: "10분",
    tags: ["두 원의 위치 관계", "원", "탐구"], links: ["c2-circle-family", "c2-circle-eq"],
    desc: "두 원의 중심 사이의 거리 d를 반지름의 합 r₁ + r₂, 차 |r₁ − r₂|와 비교하면 두 원이 떨어져 있는지, 외접하는지, 두 점에서 만나는지, 내접하는지, 한 원이 다른 원 안에 있는지 알 수 있습니다. 중심을 끌어 다섯 경우를 모두 만들어 봅니다.",
    obs: ["d > r₁ + r₂: 서로 밖에 있어 만나지 않습니다.", "d = r₁ + r₂: 외접, d = |r₁ − r₂|: 내접(한 점).", "|r₁ − r₂| < d < r₁ + r₂: 두 점에서 만납니다."],
    q: "반지름이 3, 5인 두 원이 두 점에서 만나도록 하는 d의 범위는?",
    formula: "|r₁ − r₂| < d < r₁ + r₂ ⇔ 두 점에서 만남",
    en: { title: "Positions of Two Circles", desc: "Compare d with r₁ + r₂ and |r₁ − r₂|." },
    view: { x: [-6, 8], y: [-4.8, 4.8] },
    init: () => ({ P: [4, 1] }),
    params: [{ key: "r1", label: "r₁", min: 0.5, max: 4, step: 0.1, value: 3 }, { key: "r2", label: "r₂", min: 0.5, max: 4, step: 0.1, value: 2 }],
    drags: { P: { at: (s) => s.P, move: (s, p) => (s.P = [clamp(Math.round(p[0] * 10) / 10, -5, 7), clamp(Math.round(p[1] * 10) / 10, -4, 4)]), label: "둘째 원의 중심", color: "c" } },
    kind(s) { const d = Math.hypot(...s.P), S = s.r1 + s.r2, D = Math.abs(s.r1 - s.r2), e = 0.05; return d > S + e ? "만나지 않음 (밖)" : Math.abs(d - S) <= e ? "외접 (한 점)" : d > D + e ? "두 점에서 만남" : Math.abs(d - D) <= e ? (d < e ? "같은 중심" : "내접 (한 점)") : "만나지 않음 (안)"; },
    draw(s, g) { g.grid(); g.circle([0, 0], s.r1, { color: "b", w: 2.6, fill: "b", fo: 0.06 }); g.circle(s.P, s.r2, { color: "c", w: 2.6, fill: "c", fo: 0.06 }); g.seg([0, 0], s.P, { color: "a", w: 1.6, dash: "5 4" }); g.point([0, 0], "", { color: "b", r: 4 }); g.text([s.P[0] / 2, s.P[1] / 2], `d = ${fmt(Math.hypot(...s.P), 2)}`, { dy: -8, bold: true, color: "a", size: 13 }); },
    metrics(s) { return [["d", fmt(Math.hypot(...s.P), 2)], ["r₁ + r₂ · |r₁ − r₂|", `${fmt(s.r1 + s.r2, 2)} · ${fmt(Math.abs(s.r1 - s.r2), 2)}`], ["위치 관계", this.kind(s), "key"]]; },
    predict: [
      { q: "반지름 3, 2인 두 원의 중심 거리가 5이면?", options: O("외접한다", "두 점에서 만난다", "만나지 않는다"), set: (s) => Object.assign(s, { r1: 3, r2: 2, P: [6, 0] }), reveal: (s) => (s.P = [5, 0]), answer: () => "a", why: "d = r₁ + r₂ = 5이므로 한 점에서 외접합니다." },
      { q: "반지름 3, 5인 두 원이 두 점에서 만나는 d의 범위에서 d가 가질 수 있는 가장 큰 정수는?", answer: () => 7, why: "2 < d < 8이므로 가장 큰 정수는 7입니다." },
    ],
  },
  {
    id: "c2-tangent-length", grade: C2, unit: 2, lesson: "Ⅱ-2", title: "원 밖의 점에서 그은 접선의 길이", type: "조작", time: "10분",
    tags: ["접선", "원", "피타고라스 정리"], links: ["c2-tangent", "c2-circle-line"],
    desc: "원 밖의 점 P에서 원에 접선을 그으면 반지름과 접선이 수직이므로, 접선의 길이는 √(d² − r²)입니다(d는 P와 중심 사이의 거리). 점 P를 끌어 두 접선의 길이가 같다는 것과 접점의 위치를 확인합니다.",
    obs: ["접점에서 반지름과 접선은 수직입니다.", "그래서 (접선의 길이)² + r² = d²입니다.", "한 점에서 그은 두 접선의 길이는 같습니다."],
    q: "원 x² + y² = 9 밖의 점 (5, 0)에서 그은 접선의 길이를 구해 봅시다.",
    formula: "접선의 길이 = √(d² − r²)",
    en: { title: "Length of a Tangent Segment", desc: "√(d² − r²) from Pythagoras." },
    view: { x: [-5, 7.5], y: [-4.6, 4.6] },
    init: () => ({ P: [5, 1] }),
    params: [{ key: "r", label: "반지름 r", min: 1, max: 3.5, step: 0.1, value: 3 }],
    drags: { P: { at: (s) => s.P, move: (s, p) => (s.P = [clamp(Math.round(p[0] * 10) / 10, -4.8, 7), clamp(Math.round(p[1] * 10) / 10, -4.2, 4.2)]), label: "P", color: "a" } },
    draw(s, g) {
      const d = Math.hypot(...s.P);
      g.grid(); g.circle([0, 0], s.r, { color: "b", w: 2.6 });
      g.point(s.P, "P", { color: "a" }).point([0, 0], "O", { color: "b", r: 4 });
      if (d <= s.r + 1e-9) { g.text([s.P[0], s.P[1]], "원 안이에요", { dy: 22, color: "e", bold: true }); return; }
      const a = Math.atan2(s.P[1], s.P[0]), b = Math.acos(s.r / d);
      [a + b, a - b].forEach((t, i) => { const T = [s.r * Math.cos(t), s.r * Math.sin(t)]; g.seg(s.P, T, { color: i ? "c" : "a", w: 2.6 }).seg([0, 0], T, { color: "muted", w: 1.4 }); g.right(T, [0, 0], s.P, { color: "muted", size: 10 }); g.point(T, i ? "T₂" : "T₁", { color: i ? "c" : "a", r: 4 }); });
      g.seg([0, 0], s.P, { color: "muted", w: 1.2, dash: "4 4" });
    },
    metrics(s) { const d = Math.hypot(...s.P); return [["d = OP", fmt(d, 3)], ["접선의 길이 √(d² − r²)", d > s.r ? fmt(Math.sqrt(d * d - s.r * s.r), 3) : "—", "key"]]; },
    predict: [
      { q: "원 x² + y² = 9 밖의 점 (5, 0)에서 그은 접선의 길이는?", set: (s) => Object.assign(s, { r: 3, P: [5, 2] }), reveal: (s) => (s.P = [5, 0]), answer: () => 4, why: "√(25 − 9) = 4입니다." },
      { q: "한 점에서 그은 두 접선의 길이는?", options: O("항상 같다", "다를 수 있다"), set: (s) => Object.assign(s, { r: 2, P: [4, 2] }), answer: () => "a", why: "두 직각삼각형 OPT₁, OPT₂가 빗변과 한 변이 같아 합동입니다." },
    ],
  },
  {
    id: "c2-demorgan", grade: C2, unit: 3, lesson: "Ⅲ-2", title: "드모르간의 법칙 — 벤 다이어그램으로 칠해 보기", type: "조작", time: "10분",
    tags: ["드모르간의 법칙", "여집합", "벤 다이어그램"], links: ["cm2-venn", "c2-incl-excl"],
    desc: "왼쪽에는 (A ∪ B)ᶜ, 오른쪽에는 Aᶜ ∩ Bᶜ를 칠해 두 영역이 똑같음을 확인합니다. 합집합과 교집합을 바꾸어 (A ∩ B)ᶜ = Aᶜ ∪ Bᶜ도 함께 비교합니다.",
    obs: ["(A ∪ B)ᶜ는 A에도 B에도 속하지 않는 부분입니다.", "Aᶜ ∩ Bᶜ도 A 밖이면서 B 밖인 부분이라 같습니다.", "여집합을 취하면 ∪와 ∩가 서로 바뀝니다."],
    q: "'A이거나 B인 것은 아니다'를 드모르간의 법칙으로 바꾸어 말해 봅시다.",
    formula: "(A ∪ B)ᶜ = Aᶜ ∩ Bᶜ, (A ∩ B)ᶜ = Aᶜ ∪ Bᶜ",
    en: { title: "De Morgan's Laws", desc: "Shade both sides and compare." },
    view: { x: [0, 16], y: [0, 9], pad: 6 },
    params: [{ key: "law", label: "법칙", type: "seg", value: "u", options: [["u", "(A ∪ B)ᶜ = Aᶜ ∩ Bᶜ"], ["i", "(A ∩ B)ᶜ = Aᶜ ∪ Bᶜ"]] }],
    venn(g, x0, kind, title) {
      const W = 7, H = 6, cA = [x0 + 2.6, 4], cB = [x0 + 4.4, 4], r = 1.7, R = [[x0 + 0.2, 1], [x0 + 0.2 + W, 1], [x0 + 0.2 + W, 1 + H], [x0 + 0.2, 1 + H]];
      g.poly(R, { fill: "a", fo: 0.45, stroke: false });
      if (kind === "u") { g.circle(cA, r, { fill: "paper", fo: 1, stroke: false, layer: "fill" }).circle(cB, r, { fill: "paper", fo: 1, stroke: false, layer: "fill" }); }
      else { const th = Math.acos((cB[0] - cA[0]) / 2 / r), P = []; for (let i = 0; i <= 30; i++) { const t = th - (2 * th * i) / 30; P.push([cA[0] + r * Math.cos(t), cA[1] + r * Math.sin(t)]); } for (let i = 0; i <= 30; i++) { const t = Math.PI + th - (2 * th * i) / 30; P.push([cB[0] + r * Math.cos(t), cB[1] + r * Math.sin(t)]); } g.poly(P, { fill: "paper", fo: 1, stroke: false }); }
      g.poly(R, { color: "ink", w: 1.8 });
      g.circle(cA, r, { color: "b", w: 2 }).circle(cB, r, { color: "c", w: 2 });
      g.text([cA[0] - 0.9, cA[1] + 1.2], "A", { bold: true, color: "b" }).text([cB[0] + 0.9, cB[1] + 1.2], "B", { bold: true, color: "c" }).text([x0 + 0.2 + W / 2, 7.6], title, { bold: true, size: 15 });
    },
    draw(s, g) { if (s.law === "u") { this.venn(g, 0.4, "u", "(A ∪ B)ᶜ"); this.venn(g, 8.2, "u", "Aᶜ ∩ Bᶜ"); } else { this.venn(g, 0.4, "i", "(A ∩ B)ᶜ"); this.venn(g, 8.2, "i", "Aᶜ ∪ Bᶜ"); } },
    metrics(s) { return [["왼쪽과 오른쪽", "칠한 영역이 같음", "key"], ["바뀌는 것", "∪ ↔ ∩"]]; },
    predict: [
      { q: "(A ∩ B)ᶜ와 같은 것은?", options: O("Aᶜ ∪ Bᶜ", "Aᶜ ∩ Bᶜ", "A ∪ B"), set: (s) => (s.law = "u"), reveal: (s) => (s.law = "i"), answer: () => "a", why: "여집합을 취하면 ∩가 ∪로 바뀝니다." },
      { q: "U = {1, …, 10}, A = {1, 2, 3, 4}, B = {3, 4, 5, 6}일 때 n((A ∪ B)ᶜ)은?", answer: () => 4, why: "A ∪ B = {1, …, 6}이므로 여집합은 {7, 8, 9, 10}의 4개입니다." },
    ],
  },
  {
    id: "c2-converse", grade: C2, unit: 4, lesson: "Ⅳ-1", title: "역과 대우 — 진리집합의 포함 관계로", type: "조작", time: "12분",
    tags: ["명제", "역", "대우"], links: ["cm2-truth-set"],
    desc: "명제 p → q가 참이면 진리집합 P가 Q에 포함됩니다. 1부터 20까지의 수에서 P와 Q를 칠해 p → q, 역 q → p, 대우 ~q → ~p의 참·거짓을 확인하고, 명제와 대우의 참·거짓은 항상 같지만 역은 그렇지 않음을 봅니다.",
    obs: ["p → q가 참 ⇔ P ⊂ Q입니다.", "대우 ~q → ~p는 Qᶜ ⊂ Pᶜ이고, P ⊂ Q와 같은 말입니다.", "역 q → p는 Q ⊂ P라서 명제가 참이어도 거짓일 수 있습니다."],
    q: "'x² = 4이면 x = 2이다'의 대우를 쓰고 참·거짓을 판단해 봅시다.",
    formula: "p → q 참 ⇔ ~q → ~p 참",
    en: { title: "Converse and Contrapositive", desc: "Inclusion of truth sets." },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [{ key: "pr", label: "명제", type: "select", value: "c", options: Object.entries(PROPS).map(([k, v]) => [k, `${v.p} → ${v.q}`]) }],
    U: () => Array.from({ length: 41 }, (_, i) => i - 20),
    draw(s, g) {
      const K = PROPS[s.pr], U = s.pr === "c" ? Array.from({ length: 20 }, (_, i) => i + 1) : this.U();
      const cols = s.pr === "c" ? 10 : 14, rows = Math.ceil(U.length / cols), cw = 15 / cols;
      U.forEach((x, i) => { const r = Math.floor(i / cols), c = i % cols, X = 0.5 + c * cw, Y = 10 - r * 1.1, p = K.P(x), q = K.Q(x); g.poly([[X, Y], [X + cw - 0.1, Y], [X + cw - 0.1, Y - 1], [X, Y - 1]], { fill: p ? "a" : q ? "b" : "paper", fo: p ? 0.6 : q ? 0.3 : 1, color: "grid", w: 1 }); g.text([X + cw / 2 - 0.05, Y - 0.5], String(x).replace("-", "−"), { dy: 4, size: 11, bold: p }); });
      g.text([0.5, 10.6], `진한 칸: P (${K.p}) · 옅은 칸: Q 중 P가 아닌 것 (${K.q})`, { anchor: "start", size: 12, bold: true });
    },
    metrics(s) { const K = PROPS[s.pr], U = s.pr === "c" ? Array.from({ length: 20 }, (_, i) => i + 1) : this.U(), PinQ = U.every((x) => !K.P(x) || K.Q(x)), QinP = U.every((x) => !K.Q(x) || K.P(x)); return [[`명제 ${K.p} → ${K.q}`, PinQ ? "참" : "거짓", "key"], [`역 ${K.q} → ${K.p}`, QinP ? "참" : "거짓"], [`대우 (${K.q}가 아님) → (${K.p}가 아님)`, PinQ ? "참" : "거짓"]]; },
    predict: [
      { q: "'x가 4의 배수이면 x는 2의 배수이다'의 역은 참일까요?", options: O("거짓", "참"), set: (s) => (s.pr = "c"), answer: () => "a", why: "2의 배수 6은 4의 배수가 아닙니다. Q가 P에 포함되지 않습니다." },
      { q: "'x = 2이면 x² = 4이다'의 대우는 참일까요?", options: O("참", "거짓"), set: (s) => (s.pr = "a"), answer: () => "a", why: "원래 명제가 참이므로 대우 'x² ≠ 4이면 x ≠ 2'도 참입니다." },
    ],
  },
  {
    id: "c2-vertical-test", grade: C2, unit: 5, lesson: "Ⅴ-1", title: "함수의 그래프 판정 — 세로선을 대 보기", type: "조작", time: "8분",
    tags: ["함수", "그래프", "대응"], links: ["c2-one-to-one"],
    desc: "세로선 x = k를 좌우로 움직이며 그래프와 몇 번 만나는지 셉니다. 정의역의 모든 x에서 정확히 한 번 만나야 함수의 그래프이고, 원이나 옆으로 누운 포물선처럼 두 번 만나는 곳이 있으면 함수가 아님을 확인합니다.",
    obs: ["함수는 x 하나에 y가 꼭 하나만 대응합니다.", "세로선이 그래프와 두 번 이상 만나면 한 x에 y가 여러 개입니다.", "원 x² + y² = 9는 함수의 그래프가 아니지만 윗반원만 떼면 함수가 됩니다."],
    q: "x = y²의 그래프에서 위쪽 절반만 남기면 어떤 함수가 될까요?",
    formula: "함수: 정의역의 각 x에 y가 오직 하나",
    en: { title: "The Vertical Line Test", desc: "Is this graph a function?" },
    view: { x: [-5, 5], y: [-4, 4.5] },
    params: [{ key: "r", label: "관계", type: "select", value: "circ", options: Object.entries(REL).map(([k, v]) => [k, v.n]) }, { key: "k", label: "세로선 x = k", min: -4, max: 4, step: 0.1, value: 1 }],
    anim: { key: "k", min: -4, max: 4, speed: 1.5, label: "세로선 움직이기", loop: "bounce" },
    hits(s) { const R = REL[s.r], N = 2000, P = []; let prev = null; for (let i = 0; i <= N; i++) { const t = R.t[0] + ((R.t[1] - R.t[0]) * i) / N, p = R.f(t); if (prev && (prev[0] - s.k) * (p[0] - s.k) <= 0 && prev[0] !== p[0]) { const u = (s.k - prev[0]) / (p[0] - prev[0]); P.push([s.k, prev[1] + (p[1] - prev[1]) * u]); } prev = p; } return P.filter((p, i, a) => a.findIndex((q) => Math.abs(q[1] - p[1]) < 0.02) === i); },
    draw(s, g) { const R = REL[s.r], H = this.hits(s); g.grid(); g.param(R.f, R.t[0], R.t[1], { color: "b", w: 3 }); g.seg([s.k, g.yr[0]], [s.k, g.yr[1]], { color: H.length > 1 ? "e" : "a", w: 2.2, dash: "7 5" }); H.forEach((p) => g.point(p, "", { color: H.length > 1 ? "e" : "a" })); g.text([g.xr[0] + 0.3, g.yr[1] - 0.5], R.n, { anchor: "start", bold: true, color: "b" }); },
    metrics(s) { const R = REL[s.r]; return [[`x = ${fmt(s.k)}과 만나는 점`, `${this.hits(s).length}개`], ["함수의 그래프인가?", R.ok ? "예" : "아니요", "key"]]; },
    predict: [
      { q: "원 x² + y² = 9는 함수의 그래프일까요?", options: O("아니다", "그렇다"), set: (s) => Object.assign(s, { r: "circ", k: 3.5 }), reveal: (s) => (s.k = 0), answer: () => "a", why: "x = 0에서 y = 3, −3의 두 값이 대응합니다." },
      { q: "y = x³ − 3x는 함수의 그래프일까요?", options: O("그렇다", "아니다"), set: (s) => Object.assign(s, { r: "cube", k: -3 }), reveal: (s) => (s.k = 1), answer: () => "a", why: "어떤 세로선도 한 번만 만납니다. (일대일함수는 아닙니다.)" },
    ],
  },
  {
    id: "c2-count-functions", grade: C2, unit: 5, lesson: "Ⅴ-1", title: "함수의 개수 — 화살표를 고르는 방법 세기", type: "조작", time: "10분",
    tags: ["함수의 개수", "일대일함수", "경우의 수"], links: ["c2-one-to-one", "cm1-sum-product"],
    desc: "X = {1, 2, …, m}에서 Y = {a, b, …}(원소 n개)로의 함수는 X의 원소마다 Y의 원소 하나를 고르는 것이므로 nᵐ개입니다. 번호를 바꾸어 함수를 하나씩 보며 일대일함수의 개수 n × (n − 1) × ⋯도 함께 셉니다.",
    obs: ["X의 각 원소가 화살표를 하나씩 보내므로 n × n × ⋯ × n = nᵐ개입니다.", "일대일함수는 이미 쓴 Y의 원소를 다시 쓸 수 없습니다.", "m > n이면 일대일함수는 없습니다(비둘기집 원리)."],
    q: "X에서 X로의 일대일대응은 몇 개일까요? (X의 원소 3개)",
    formula: "함수 nᵐ개, 일대일함수 n(n − 1)⋯(n − m + 1)개",
    en: { title: "Counting Functions", desc: "Choose an arrow for each element." },
    view: BOX,
    params: [{ key: "m", label: "X의 원소 수 m", min: 1, max: 4, step: 1, value: 3 }, { key: "n", label: "Y의 원소 수 n", min: 1, max: 4, step: 1, value: 3 }, { key: "id", label: "함수 번호", min: 1, max: 256, step: 1, value: 1 }],
    onChange(s) { s.id = clamp(s.id, 1, s.n ** s.m); },
    draw(s, g) {
      const idx = s.id - 1, f = []; let t = idx; for (let i = 0; i < s.m; i++) { f.push(t % s.n); t = Math.floor(t / s.n); }
      const one = new Set(f).size === s.m, Ys = "abcd";
      g.circle([4, 5.4], 3.2, { color: "b", w: 2, fill: "b", fo: 0.06 }).circle([12, 5.4], 3.2, { color: "c", w: 2, fill: "c", fo: 0.06 });
      const px = (i) => [4, 5.4 + 1.2 * ((s.m - 1) / 2 - i)], py = (j) => [12, 5.4 + 1.2 * ((s.n - 1) / 2 - j)];
      f.forEach((j, i) => g.vec(add(px(i), [0.35, 0]), add(py(j), [-0.35, 0]), { color: one ? "a" : "e", w: 2.2 }));
      for (let i = 0; i < s.m; i++) g.point(px(i), String(i + 1), { color: "b", anchor: "end", dx: -12, dy: 5 });
      for (let j = 0; j < s.n; j++) g.point(py(j), Ys[j], { color: "c", dx: 12, dy: 5 });
      g.text([4, 9.4], "X", { bold: true, size: 16, color: "b" }).text([12, 9.4], "Y", { bold: true, size: 16, color: "c" });
      g.text([8, 1.2], `${s.id}번째 함수 · ${one ? "일대일함수" : "일대일이 아님"}`, { bold: true, color: one ? "a" : "e", size: 14 });
    },
    metrics(s) { let o = 1; for (let i = 0; i < s.m; i++) o *= s.n - i; return [["함수의 개수", `${s.n}^${s.m} = ${s.n ** s.m}`, "key"], ["일대일함수의 개수", s.m > s.n ? "0" : String(o)]]; },
    predict: [
      { q: "원소 3개인 X에서 원소 4개인 Y로의 함수는 몇 개?", set: (s) => Object.assign(s, { m: 3, n: 2, id: 1 }), reveal: (s) => (s.n = 4), answer: () => 64, why: "4 × 4 × 4 = 64개입니다." },
      { q: "같은 X, Y에서 일대일함수는 몇 개?", set: (s) => Object.assign(s, { m: 3, n: 4, id: 7 }), answer: () => 24, why: "4 × 3 × 2 = 24개입니다." },
    ],
  },
  {
    id: "c2-point-reflect", grade: C2, unit: 2, lesson: "Ⅱ-3", title: "점에 대한 대칭이동 — 중점이 대칭의 중심", type: "조작", time: "10분",
    tags: ["대칭이동", "점대칭", "중점"], links: ["c2-reflection", "c2-translation"],
    desc: "점 M(a, b)에 대하여 대칭이동하면 점 P(x, y)는 M이 PP′의 중점이 되는 점 P′(2a − x, 2b − y)로 옮겨 갑니다. 삼각형과 원을 점 M에 대하여 대칭이동하며 도형이 180° 돌아간 모양이 됨을 확인합니다.",
    obs: ["M은 P와 P′의 중점입니다: (x + x′)/2 = a, (y + y′)/2 = b.", "그래서 x′ = 2a − x, y′ = 2b − y입니다.", "원점에 대한 대칭은 a = b = 0인 경우로 (−x, −y)입니다."],
    q: "원 (x − 1)² + y² = 1을 점 (2, 1)에 대하여 대칭이동한 원의 중심은 어디일까요?",
    formula: "P(x, y) → P′(2a − x, 2b − y)",
    en: { title: "Reflection in a Point", desc: "The center is the midpoint." },
    view: { x: [-6, 6], y: [-4.6, 4.6] },
    init: () => ({ M: [1, 0.5] }),
    params: [{ key: "shape", label: "도형", type: "seg", value: "tri", options: [["tri", "삼각형"], ["circ", "원"]] }],
    drags: { M: { at: (s) => s.M, move: (s, p) => (s.M = [clamp(Math.round(p[0] * 2) / 2, -3, 3), clamp(Math.round(p[1] * 2) / 2, -2.5, 2.5)]), label: "M", color: "e" } },
    draw(s, g) {
      const R = (p) => [2 * s.M[0] - p[0], 2 * s.M[1] - p[1]], T = [[-4, -2], [-1.5, -2.5], [-2.5, 0.5]];
      g.grid();
      if (s.shape === "tri") { g.poly(T, { fill: "b", fo: 0.25, color: "b", w: 2.4 }); g.poly(T.map(R), { fill: "a", fo: 0.25, color: "a", w: 2.4 }); T.forEach((p) => g.seg(p, R(p), { color: "muted", w: 1, dash: "3 4" })); }
      else { const C = [-2.5, -1.5]; g.circle(C, 1.2, { color: "b", w: 2.4 }).circle(R(C), 1.2, { color: "a", w: 2.4 }); g.seg(C, R(C), { color: "muted", w: 1, dash: "3 4" }); g.point(C, "", { color: "b", r: 4 }).point(R(C), "", { color: "a", r: 4 }); }
      g.point(s.M, `M(${fmt(s.M[0])}, ${fmt(s.M[1])})`, { color: "e" });
    },
    metrics(s) { const P = s.shape === "tri" ? [-4, -2] : [-2.5, -1.5]; return [["대칭의 중심", `(${fmt(s.M[0])}, ${fmt(s.M[1])})`], [`(${P.join(", ")})의 대칭점`, `(${fmt(2 * s.M[0] - P[0])}, ${fmt(2 * s.M[1] - P[1])})`, "key"]]; },
    predict: [
      { q: "점 (−4, −2)를 점 (1, 0.5)에 대하여 대칭이동한 점의 x좌표는?", set: (s) => Object.assign(s, { shape: "tri", M: [0, 0] }), reveal: (s) => (s.M = [1, 0.5]), answer: () => 6, why: "2 × 1 − (−4) = 6입니다." },
      { q: "원 (x − 1)² + y² = 1을 점 (2, 1)에 대하여 대칭이동한 원의 중심의 y좌표는?", answer: () => 2, why: "중심 (1, 0) → (2 × 2 − 1, 2 × 1 − 0) = (3, 2)입니다." },
    ],
  },
];
