// Gap-led additions. Unequal grade totals reflect missing concepts rather than quotas.
export const SUPPLEMENT_UPPER = [
  {
    "id": "elem4-s-decimal-thousandths",
    "year": 4,
    "title": "소수 셋째 자리까지 자리값 읽기",
    "desc": "소수 첫째 자리부터 0.1과 0.01과 0.001의 수를 나타냅니다. 중간 자리의 0을 없애서 다른 숫자를 옮기면 소수의 크기가 달라집니다.",
    "q": "0.203에서 0인 자리는 무엇을 뜻할까요?",
    "kind": "decimal",
    "mode": "place",
    "controls": [
      {
        "key": "a",
        "label": "소수 첫째 자리",
        "min": 0,
        "max": 9,
        "value": 2,
        "step": 1
      },
      {
        "key": "b",
        "label": "소수 둘째 자리",
        "min": 0,
        "max": 9,
        "value": 0,
        "step": 1
      },
      {
        "key": "c",
        "label": "소수 셋째 자리",
        "min": 0,
        "max": 9,
        "value": 3,
        "step": 1
      }
    ],
    "obs": [
      "소수 첫째 자리부터 0.1과 0.01과 0.001의 수를 나타냅니다.",
      "중간 자리의 0을 없애서 다른 숫자를 옮기면 소수의 크기가 달라집니다."
    ],
    "targets": [
      {
        "label": "0.203 만들기",
        "instruction": "소수 첫째 자리 2 / 소수 둘째 자리 0 / 소수 셋째 자리 3로 맞추세요.",
        "values": {
          "a": 2,
          "b": 0,
          "c": 3
        }
      },
      {
        "label": "0.230과 비교",
        "instruction": "소수 첫째 자리 2 / 소수 둘째 자리 3 / 소수 셋째 자리 0로 맞추세요.",
        "values": {
          "a": 2,
          "b": 3,
          "c": 0
        }
      }
    ]
  },
  {
    "id": "elem4-s-decimal-compare",
    "year": 4,
    "title": "소수는 숫자 개수보다 자리값",
    "desc": "소수의 크기는 자연수 부분부터 같은 자리끼리 차례로 비교합니다. 소수의 오른쪽 끝에 0을 붙여도 크기는 달라지지 않습니다.",
    "q": "1.2와 1.19 중 숫자가 더 긴 수가 항상 클까요?",
    "kind": "decimal",
    "mode": "compare",
    "controls": [
      {
        "key": "a",
        "label": "첫째 소수",
        "min": 0,
        "max": 8,
        "value": 1.2,
        "step": 0.01
      },
      {
        "key": "b",
        "label": "둘째 소수",
        "min": 0,
        "max": 8,
        "value": 1.19,
        "step": 0.01
      }
    ],
    "obs": [
      "소수의 크기는 자연수 부분부터 같은 자리끼리 차례로 비교합니다.",
      "소수의 오른쪽 끝에 0을 붙여도 크기는 달라지지 않습니다."
    ],
    "targets": [
      {
        "label": "1.2와 1.19 비교",
        "instruction": "첫째 소수 1.2 / 둘째 소수 1.19로 맞추세요.",
        "values": {
          "a": 1.2,
          "b": 1.19
        }
      },
      {
        "label": "1.2와 1.02 비교",
        "instruction": "첫째 소수 1.2 / 둘째 소수 1.02로 맞추세요.",
        "values": {
          "a": 1.2,
          "b": 1.02
        }
      }
    ]
  },
  {
    "id": "elem4-s-decimal-add-carry",
    "year": 4,
    "title": "소수 덧셈과 자리 맞추기",
    "desc": "소수점을 맞추면 같은 자리값끼리 더할 수 있습니다. 0.01이 10개 모이면 0.1이 되고 0.1이 10개 모이면 1이 됩니다.",
    "q": "0.8과 0.35를 더할 때 어느 자리끼리 더해야 할까요?",
    "kind": "decimal",
    "mode": "add",
    "controls": [
      {
        "key": "a",
        "label": "첫째 소수",
        "min": 0,
        "max": 5,
        "value": 0.8,
        "step": 0.01
      },
      {
        "key": "b",
        "label": "둘째 소수",
        "min": 0,
        "max": 5,
        "value": 0.35,
        "step": 0.01
      }
    ],
    "obs": [
      "소수점을 맞추면 같은 자리값끼리 더할 수 있습니다.",
      "0.01이 10개 모이면 0.1이 되고 0.1이 10개 모이면 1이 됩니다."
    ],
    "targets": [
      {
        "label": "0.8과 0.35 더하기",
        "instruction": "첫째 소수 0.8 / 둘째 소수 0.35로 맞추세요.",
        "values": {
          "a": 0.8,
          "b": 0.35
        }
      },
      {
        "label": "여러 자리에서 받아올림",
        "instruction": "첫째 소수 1.27 / 둘째 소수 0.86로 맞추세요.",
        "values": {
          "a": 1.27,
          "b": 0.86
        }
      }
    ]
  },
  {
    "id": "elem4-s-decimal-sub-borrow",
    "year": 4,
    "title": "소수 뺄셈에서 받아내림",
    "desc": "자연수 뒤에 소수점과 0을 적어 같은 자리끼리 뺄 수 있습니다. 윗자리 1을 아랫자리 10개로 바꾸어 받아내림합니다.",
    "q": "2에서 0.85를 빼려면 어떤 자리에서 나누어 주어야 할까요?",
    "kind": "decimal",
    "mode": "sub",
    "controls": [
      {
        "key": "a",
        "label": "처음 소수",
        "min": 1,
        "max": 5,
        "value": 2,
        "step": 0.01
      },
      {
        "key": "b",
        "label": "빼는 소수",
        "min": 0,
        "max": 1,
        "value": 0.85,
        "step": 0.01
      }
    ],
    "obs": [
      "자연수 뒤에 소수점과 0을 적어 같은 자리끼리 뺄 수 있습니다.",
      "윗자리 1을 아랫자리 10개로 바꾸어 받아내림합니다."
    ],
    "targets": [
      {
        "label": "2에서 0.85 빼기",
        "instruction": "처음 소수 2 / 빼는 소수 0.85로 맞추세요.",
        "values": {
          "a": 2,
          "b": 0.85
        }
      },
      {
        "label": "1.2에서 0.47 빼기",
        "instruction": "처음 소수 1.2 / 빼는 소수 0.47로 맞추세요.",
        "values": {
          "a": 1.2,
          "b": 0.47
        }
      }
    ]
  },
  {
    "id": "elem4-s-parallel-lines",
    "year": 4,
    "title": "기울어져도 평행한 두 직선",
    "desc": "한 평면에서 아무리 늘여도 만나지 않는 두 직선은 평행합니다. 평행한 두 직선 사이를 수직으로 잰 거리는 어디에서나 같습니다.",
    "q": "두 직선을 함께 기울이면 평행한 관계가 달라질까요?",
    "kind": "geometry",
    "mode": "parallel",
    "controls": [
      {
        "key": "a",
        "label": "함께 기울인 각도 °",
        "min": -60,
        "max": 60,
        "value": 0,
        "step": 15
      },
      {
        "key": "b",
        "label": "두 직선 사이 수직거리",
        "min": 1,
        "max": 5,
        "value": 2,
        "step": 1
      }
    ],
    "obs": [
      "한 평면에서 아무리 늘여도 만나지 않는 두 직선은 평행합니다.",
      "평행한 두 직선 사이를 수직으로 잰 거리는 어디에서나 같습니다."
    ],
    "targets": [
      {
        "label": "가로로 놓인 평행선",
        "instruction": "함께 기울인 각도 ° 0 / 두 직선 사이 수직거리 2로 맞추세요.",
        "values": {
          "a": 0,
          "b": 2
        }
      },
      {
        "label": "기울어진 평행선",
        "instruction": "함께 기울인 각도 ° 45 / 두 직선 사이 수직거리 2로 맞추세요.",
        "values": {
          "a": 45,
          "b": 2
        }
      }
    ],
    "focus": "properties"
  },
  {
    "id": "elem4-s-perpendicular-lines",
    "year": 4,
    "title": "함께 돌려도 수직인 두 직선",
    "desc": "두 직선이 만나 이루는 각이 직각이면 서로 수직입니다. 두 직선을 함께 돌리거나 선분 길이를 바꾸어도 직각은 그대로입니다.",
    "q": "십자 모양을 기울이면 두 직선 사이의 직각이 없어질까요?",
    "kind": "geometry",
    "mode": "perpendicular",
    "controls": [
      {
        "key": "a",
        "label": "함께 돌린 각도 °",
        "min": 0,
        "max": 180,
        "value": 0,
        "step": 15
      },
      {
        "key": "b",
        "label": "그림 속 선분 길이",
        "min": 2,
        "max": 8,
        "value": 5,
        "step": 1
      }
    ],
    "obs": [
      "두 직선이 만나 이루는 각이 직각이면 서로 수직입니다.",
      "두 직선을 함께 돌리거나 선분 길이를 바꾸어도 직각은 그대로입니다."
    ],
    "targets": [
      {
        "label": "가로와 세로의 직각",
        "instruction": "함께 돌린 각도 ° 0 / 그림 속 선분 길이 5로 맞추세요.",
        "values": {
          "a": 0,
          "b": 5
        }
      },
      {
        "label": "기울여 놓은 직각",
        "instruction": "함께 돌린 각도 ° 45 / 그림 속 선분 길이 5로 맞추세요.",
        "values": {
          "a": 45,
          "b": 5
        }
      }
    ],
    "focus": "properties"
  },
  {
    "id": "elem4-s-triangle-angle-sum",
    "year": 4,
    "title": "삼각형의 나머지 한 각 찾기",
    "desc": "삼각형의 세 각의 크기를 더하면 180°입니다. 두 각의 합을 180°에서 빼면 나머지 각을 구할 수 있습니다.",
    "q": "삼각형의 두 각이 50°와 60°이면 남은 각은 몇 도일까요?",
    "kind": "geometry",
    "mode": "angle-sum",
    "controls": [
      {
        "key": "a",
        "label": "첫째 각 °",
        "min": 20,
        "max": 80,
        "value": 50,
        "step": 5
      },
      {
        "key": "b",
        "label": "둘째 각 °",
        "min": 20,
        "max": 80,
        "value": 60,
        "step": 5
      }
    ],
    "obs": [
      "삼각형의 세 각의 크기를 더하면 180°입니다.",
      "두 각의 합을 180°에서 빼면 나머지 각을 구할 수 있습니다."
    ],
    "targets": [
      {
        "label": "남은 각 70° 찾기",
        "instruction": "첫째 각 ° 50 / 둘째 각 ° 60로 맞추세요.",
        "values": {
          "a": 50,
          "b": 60
        }
      },
      {
        "label": "세 각이 같은 삼각형",
        "instruction": "첫째 각 ° 60 / 둘째 각 ° 60로 맞추세요.",
        "values": {
          "a": 60,
          "b": 60
        }
      }
    ],
    "focus": "properties"
  },
  {
    "id": "elem5-s-decimal-times-whole",
    "year": 5,
    "title": "소수 묶음을 여러 번 더하기",
    "desc": "소수에 자연수를 곱하는 것은 같은 소수를 여러 번 더하는 것입니다. 0.6을 4번 더한 값은 6을 4번 더한 값의 십분의 일입니다.",
    "q": "0.6을 4번 모으면 전체 1보다 얼마나 커질까요?",
    "kind": "decimal",
    "mode": "mul",
    "controls": [
      {
        "key": "a",
        "label": "한 묶음의 소수",
        "min": 0.1,
        "max": 5,
        "value": 0.6,
        "step": 0.1
      },
      {
        "key": "b",
        "label": "묶음 수",
        "min": 1,
        "max": 8,
        "value": 4,
        "step": 1
      }
    ],
    "obs": [
      "소수에 자연수를 곱하는 것은 같은 소수를 여러 번 더하는 것입니다.",
      "0.6을 4번 더한 값은 6을 4번 더한 값의 십분의 일입니다."
    ],
    "targets": [
      {
        "label": "0.6을 네 번 모으기",
        "instruction": "한 묶음의 소수 0.6 / 묶음 수 4로 맞추세요.",
        "values": {
          "a": 0.6,
          "b": 4
        }
      },
      {
        "label": "묶음 수를 두 배로",
        "instruction": "한 묶음의 소수 0.6 / 묶음 수 8로 맞추세요.",
        "values": {
          "a": 0.6,
          "b": 8
        }
      }
    ]
  },
  {
    "id": "elem5-s-decimal-times-decimal",
    "year": 5,
    "title": "소수 곱셈으로 부분과 배 비교",
    "desc": "1보다 작은 양수를 곱하면 원래 양의 일부가 됩니다. 1보다 큰 양수를 곱하면 원래 양보다 커집니다.",
    "q": "양의 수에 0.5를 곱한 값과 1.5를 곱한 값은 어떻게 다를까요?",
    "kind": "decimal",
    "mode": "mul",
    "controls": [
      {
        "key": "a",
        "label": "기준 소수",
        "min": 0.1,
        "max": 5,
        "value": 2.4,
        "step": 0.1
      },
      {
        "key": "b",
        "label": "곱하는 소수",
        "min": 0.1,
        "max": 2,
        "value": 0.5,
        "step": 0.1
      }
    ],
    "obs": [
      "1보다 작은 양수를 곱하면 원래 양의 일부가 됩니다.",
      "1보다 큰 양수를 곱하면 원래 양보다 커집니다."
    ],
    "targets": [
      {
        "label": "2.4의 절반",
        "instruction": "기준 소수 2.4 / 곱하는 소수 0.5로 맞추세요.",
        "values": {
          "a": 2.4,
          "b": 0.5
        }
      },
      {
        "label": "2.4의 한 배 반",
        "instruction": "기준 소수 2.4 / 곱하는 소수 1.5로 맞추세요.",
        "values": {
          "a": 2.4,
          "b": 1.5
        }
      }
    ]
  },
  {
    "id": "elem5-s-decimal-powers-ten",
    "year": 5,
    "title": "소수에 10과 100을 곱하면",
    "desc": "10을 곱하면 각 숫자의 자리값이 10배가 됩니다. 100을 곱하면 각 숫자의 자리값이 100배가 됩니다.",
    "q": "0.235에 10을 곱할 때 숫자 2의 자리값은 어떻게 달라질까요?",
    "kind": "decimal",
    "mode": "mul",
    "controls": [
      {
        "key": "a",
        "label": "처음 소수",
        "min": 0.001,
        "max": 0.999,
        "value": 0.235,
        "step": 0.001
      },
      {
        "key": "b",
        "label": "곱할 수",
        "min": 10,
        "max": 100,
        "value": 10,
        "step": 90
      }
    ],
    "obs": [
      "10을 곱하면 각 숫자의 자리값이 10배가 됩니다.",
      "100을 곱하면 각 숫자의 자리값이 100배가 됩니다."
    ],
    "targets": [
      {
        "label": "0.235의 10배",
        "instruction": "처음 소수 0.235 / 곱할 수 10로 맞추세요.",
        "values": {
          "a": 0.235,
          "b": 10
        }
      },
      {
        "label": "0.235의 100배",
        "instruction": "처음 소수 0.235 / 곱할 수 100로 맞추세요.",
        "values": {
          "a": 0.235,
          "b": 100
        }
      }
    ]
  },
  {
    "id": "elem5-s-decimal-rounding",
    "year": 5,
    "title": "나타낼 자리에 따라 소수 반올림",
    "desc": "반올림하여 남길 자리 바로 아래의 숫자를 살펴봅니다. 소수 첫째 자리까지 나타내면 0.1 단위이며 둘째 자리까지이면 0.01 단위입니다.",
    "q": "1.247을 소수 첫째 자리와 둘째 자리까지 나타내면 같은 값일까요?",
    "kind": "decimal",
    "mode": "round",
    "controls": [
      {
        "key": "a",
        "label": "반올림할 소수",
        "min": 1.001,
        "max": 3.999,
        "value": 1.247,
        "step": 0.001
      },
      {
        "key": "b",
        "label": "반올림 단위",
        "min": 0.01,
        "max": 0.1,
        "value": 0.1,
        "step": 0.09
      }
    ],
    "obs": [
      "반올림하여 남길 자리 바로 아래의 숫자를 살펴봅니다.",
      "소수 첫째 자리까지 나타내면 0.1 단위이며 둘째 자리까지이면 0.01 단위입니다."
    ],
    "targets": [
      {
        "label": "소수 첫째 자리까지",
        "instruction": "반올림할 소수 1.247 / 반올림 단위 0.1로 맞추세요.",
        "values": {
          "a": 1.247,
          "b": 0.1
        }
      },
      {
        "label": "소수 둘째 자리까지",
        "instruction": "반올림할 소수 1.247 / 반올림 단위 0.01로 맞추세요.",
        "values": {
          "a": 1.247,
          "b": 0.01
        }
      }
    ]
  },
  {
    "id": "elem5-s-range-at-least",
    "year": 5,
    "title": "이상은 경계의 수를 포함해요",
    "desc": "기준 수 이상은 기준 수와 같거나 큰 수를 뜻합니다. 경계의 수 자체도 범위에 포함됩니다.",
    "q": "10 이상인 수에 10도 들어갈까요?",
    "kind": "number",
    "mode": "range",
    "controls": [
      {
        "key": "a",
        "label": "확인할 수",
        "min": 0,
        "max": 30,
        "value": 10,
        "step": 1
      },
      {
        "key": "b",
        "label": "기준 수",
        "min": 1,
        "max": 29,
        "value": 10,
        "step": 1
      }
    ],
    "obs": [
      "기준 수 이상은 기준 수와 같거나 큰 수를 뜻합니다.",
      "경계의 수 자체도 범위에 포함됩니다."
    ],
    "targets": [
      {
        "label": "경계의 수 확인",
        "instruction": "확인할 수 10 / 기준 수 10로 맞추세요.",
        "values": {
          "a": 10,
          "b": 10
        }
      },
      {
        "label": "경계보다 1 작은 수",
        "instruction": "확인할 수 9 / 기준 수 10로 맞추세요.",
        "values": {
          "a": 9,
          "b": 10
        }
      }
    ],
    "unit": "at-least"
  },
  {
    "id": "elem5-s-range-at-most",
    "year": 5,
    "title": "이하는 경계의 수를 포함해요",
    "desc": "기준 수 이하는 기준 수와 같거나 작은 수를 뜻합니다. 경계보다 큰 수는 범위에 포함되지 않습니다.",
    "q": "15 이하인 수에 15와 16은 각각 들어갈까요?",
    "kind": "number",
    "mode": "range",
    "controls": [
      {
        "key": "a",
        "label": "확인할 수",
        "min": 0,
        "max": 30,
        "value": 15,
        "step": 1
      },
      {
        "key": "b",
        "label": "기준 수",
        "min": 1,
        "max": 29,
        "value": 15,
        "step": 1
      }
    ],
    "obs": [
      "기준 수 이하는 기준 수와 같거나 작은 수를 뜻합니다.",
      "경계보다 큰 수는 범위에 포함되지 않습니다."
    ],
    "targets": [
      {
        "label": "경계의 수 확인",
        "instruction": "확인할 수 15 / 기준 수 15로 맞추세요.",
        "values": {
          "a": 15,
          "b": 15
        }
      },
      {
        "label": "경계보다 1 큰 수",
        "instruction": "확인할 수 16 / 기준 수 15로 맞추세요.",
        "values": {
          "a": 16,
          "b": 15
        }
      }
    ],
    "unit": "at-most"
  },
  {
    "id": "elem5-s-range-more-than",
    "year": 5,
    "title": "초과는 경계의 수를 빼요",
    "desc": "기준 수 초과는 기준 수보다 큰 수만 뜻합니다. 기준 수 자체는 범위에 포함되지 않습니다.",
    "q": "10 초과와 10 이상은 어느 수에서 달라질까요?",
    "kind": "number",
    "mode": "range",
    "controls": [
      {
        "key": "a",
        "label": "확인할 수",
        "min": 0,
        "max": 30,
        "value": 10,
        "step": 1
      },
      {
        "key": "b",
        "label": "기준 수",
        "min": 1,
        "max": 29,
        "value": 10,
        "step": 1
      }
    ],
    "obs": [
      "기준 수 초과는 기준 수보다 큰 수만 뜻합니다.",
      "기준 수 자체는 범위에 포함되지 않습니다."
    ],
    "targets": [
      {
        "label": "경계는 제외",
        "instruction": "확인할 수 10 / 기준 수 10로 맞추세요.",
        "values": {
          "a": 10,
          "b": 10
        }
      },
      {
        "label": "경계보다 1 크게",
        "instruction": "확인할 수 11 / 기준 수 10로 맞추세요.",
        "values": {
          "a": 11,
          "b": 10
        }
      }
    ],
    "unit": "more-than"
  },
  {
    "id": "elem5-s-range-less-than",
    "year": 5,
    "title": "미만은 경계의 수를 빼요",
    "desc": "기준 수 미만은 기준 수보다 작은 수만 뜻합니다. 기준 수 자체를 포함하지 않는다는 점에서 이하와 다릅니다.",
    "q": "15 미만인 수 중 15에 가장 가까운 자연수는 무엇일까요?",
    "kind": "number",
    "mode": "range",
    "controls": [
      {
        "key": "a",
        "label": "확인할 수",
        "min": 0,
        "max": 30,
        "value": 15,
        "step": 1
      },
      {
        "key": "b",
        "label": "기준 수",
        "min": 1,
        "max": 29,
        "value": 15,
        "step": 1
      }
    ],
    "obs": [
      "기준 수 미만은 기준 수보다 작은 수만 뜻합니다.",
      "기준 수 자체를 포함하지 않는다는 점에서 이하와 다릅니다."
    ],
    "targets": [
      {
        "label": "경계는 제외",
        "instruction": "확인할 수 15 / 기준 수 15로 맞추세요.",
        "values": {
          "a": 15,
          "b": 15
        }
      },
      {
        "label": "바로 아래 자연수",
        "instruction": "확인할 수 14 / 기준 수 15로 맞추세요.",
        "values": {
          "a": 14,
          "b": 15
        }
      }
    ],
    "unit": "less-than"
  },
  {
    "id": "elem5-s-range-between",
    "year": 5,
    "title": "두 조건을 함께 만족하는 범위",
    "desc": "두 조건을 함께 만족하려면 아래 기준 이상이면서 위 기준 이하여야 합니다. 이 실험에서는 양 끝의 기준 수를 모두 포함합니다.",
    "q": "20 이상 60 이하에는 양 끝의 수도 들어갈까요?",
    "kind": "number",
    "mode": "range",
    "controls": [
      {
        "key": "a",
        "label": "확인할 수",
        "min": 0,
        "max": 100,
        "value": 20,
        "step": 1
      },
      {
        "key": "b",
        "label": "이상인 기준 수",
        "min": 10,
        "max": 40,
        "value": 20,
        "step": 1
      },
      {
        "key": "c",
        "label": "이하인 기준 수",
        "min": 60,
        "max": 90,
        "value": 60,
        "step": 1
      }
    ],
    "obs": [
      "두 조건을 함께 만족하려면 아래 기준 이상이면서 위 기준 이하여야 합니다.",
      "이 실험에서는 양 끝의 기준 수를 모두 포함합니다."
    ],
    "targets": [
      {
        "label": "아래 경계 포함",
        "instruction": "확인할 수 20 / 이상인 기준 수 20 / 이하인 기준 수 60로 맞추세요.",
        "values": {
          "a": 20,
          "b": 20,
          "c": 60
        }
      },
      {
        "label": "위 경계 밖의 수",
        "instruction": "확인할 수 61 / 이상인 기준 수 20 / 이하인 기준 수 60로 맞추세요.",
        "values": {
          "a": 61,
          "b": 20,
          "c": 60
        }
      }
    ],
    "unit": "between"
  },
  {
    "id": "elem6-s-decimal-divide-whole",
    "year": 6,
    "title": "소수를 똑같은 몫으로 나누기",
    "desc": "소수도 같은 크기의 몫으로 나눌 수 있습니다. 몫에 나누는 수를 곱하면 처음의 양으로 돌아옵니다.",
    "q": "6.4를 4개로 똑같이 나누면 한 몫은 얼마일까요?",
    "kind": "decimal",
    "mode": "div",
    "controls": [
      {
        "key": "a",
        "label": "나누어지는 소수",
        "min": 0,
        "max": 12,
        "value": 6.4,
        "step": 0.1
      },
      {
        "key": "b",
        "label": "같게 나눌 수",
        "min": 1,
        "max": 8,
        "value": 4,
        "step": 1
      }
    ],
    "obs": [
      "소수도 같은 크기의 몫으로 나눌 수 있습니다.",
      "몫에 나누는 수를 곱하면 처음의 양으로 돌아옵니다."
    ],
    "targets": [
      {
        "label": "6.4를 네 몫으로",
        "instruction": "나누어지는 소수 6.4 / 같게 나눌 수 4로 맞추세요.",
        "values": {
          "a": 6.4,
          "b": 4
        }
      },
      {
        "label": "몫의 수를 두 배로",
        "instruction": "나누어지는 소수 6.4 / 같게 나눌 수 8로 맞추세요.",
        "values": {
          "a": 6.4,
          "b": 8
        }
      }
    ]
  },
  {
    "id": "elem6-s-decimal-divide-decimal",
    "year": 6,
    "title": "소수 크기의 묶음이 몇 개일까",
    "desc": "소수로 나누는 것은 그 소수 크기의 묶음 수를 구하는 것입니다. 전체가 같을 때 묶음의 크기를 작게 하면 묶음 수는 커집니다.",
    "q": "1.2 안에는 0.3이 몇 번 들어갈까요?",
    "kind": "decimal",
    "mode": "div",
    "controls": [
      {
        "key": "a",
        "label": "전체 소수",
        "min": 0.1,
        "max": 12,
        "value": 1.2,
        "step": 0.1
      },
      {
        "key": "b",
        "label": "한 묶음의 소수",
        "min": 0.1,
        "max": 3,
        "value": 0.3,
        "step": 0.1
      }
    ],
    "obs": [
      "소수로 나누는 것은 그 소수 크기의 묶음 수를 구하는 것입니다.",
      "전체가 같을 때 묶음의 크기를 작게 하면 묶음 수는 커집니다."
    ],
    "targets": [
      {
        "label": "0.3씩 묶기",
        "instruction": "전체 소수 1.2 / 한 묶음의 소수 0.3로 맞추세요.",
        "values": {
          "a": 1.2,
          "b": 0.3
        }
      },
      {
        "label": "0.6씩 묶기",
        "instruction": "전체 소수 1.2 / 한 묶음의 소수 0.6로 맞추세요.",
        "values": {
          "a": 1.2,
          "b": 0.6
        }
      }
    ]
  },
  {
    "id": "elem6-s-decimal-division-scale",
    "year": 6,
    "title": "두 수를 함께 10배 해도 같은 몫",
    "desc": "나누어지는 수와 나누는 수에 같은 양수를 곱해도 몫은 같습니다. 소수 나눗셈에서 두 수의 단위를 함께 바꾸어 자연수 나눗셈으로 생각할 수 있습니다.",
    "q": "0.84를 0.12로 나눈 몫과 8.4를 1.2로 나눈 몫은 같을까요?",
    "kind": "decimal",
    "mode": "div",
    "controls": [
      {
        "key": "a",
        "label": "나누어지는 수",
        "min": 0.01,
        "max": 12,
        "value": 0.84,
        "step": 0.01
      },
      {
        "key": "b",
        "label": "나누는 수",
        "min": 0.01,
        "max": 12,
        "value": 0.12,
        "step": 0.01
      }
    ],
    "obs": [
      "나누어지는 수와 나누는 수에 같은 양수를 곱해도 몫은 같습니다.",
      "소수 나눗셈에서 두 수의 단위를 함께 바꾸어 자연수 나눗셈으로 생각할 수 있습니다."
    ],
    "targets": [
      {
        "label": "0.84를 0.12로 나누기",
        "instruction": "나누어지는 수 0.84 / 나누는 수 0.12로 맞추세요.",
        "values": {
          "a": 0.84,
          "b": 0.12
        }
      },
      {
        "label": "두 수를 함께 10배",
        "instruction": "나누어지는 수 8.4 / 나누는 수 1.2로 맞추세요.",
        "values": {
          "a": 8.4,
          "b": 1.2
        }
      }
    ]
  },
  {
    "id": "elem6-s-proportional-sharing",
    "year": 6,
    "title": "전체를 비에 맞게 나누기",
    "desc": "비의 두 항을 더하면 전체를 몇 단위로 나눌지 알 수 있습니다. 전체에 각 항을 두 항의 합으로 나눈 비율을 곱하면 각 몫입니다.",
    "q": "전체 60을 2 대 3으로 나누면 두 몫은 각각 얼마일까요?",
    "kind": "ratio",
    "mode": "sharing",
    "controls": [
      {
        "key": "a",
        "label": "나눌 전체",
        "min": 10,
        "max": 120,
        "value": 60,
        "step": 1
      },
      {
        "key": "b",
        "label": "첫째 몫의 비",
        "min": 1,
        "max": 6,
        "value": 2,
        "step": 1
      },
      {
        "key": "c",
        "label": "둘째 몫의 비",
        "min": 1,
        "max": 6,
        "value": 3,
        "step": 1
      }
    ],
    "obs": [
      "비의 두 항을 더하면 전체를 몇 단위로 나눌지 알 수 있습니다.",
      "전체에 각 항을 두 항의 합으로 나눈 비율을 곱하면 각 몫입니다."
    ],
    "targets": [
      {
        "label": "60을 2 대 3으로",
        "instruction": "나눌 전체 60 / 첫째 몫의 비 2 / 둘째 몫의 비 3로 맞추세요.",
        "values": {
          "a": 60,
          "b": 2,
          "c": 3
        }
      },
      {
        "label": "전체가 두 배이면",
        "instruction": "나눌 전체 120 / 첫째 몫의 비 2 / 둘째 몫의 비 3로 맞추세요.",
        "values": {
          "a": 120,
          "b": 2,
          "c": 3
        }
      }
    ]
  }
];
