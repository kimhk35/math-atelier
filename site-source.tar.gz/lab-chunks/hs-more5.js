// 교과서 실생활 예제에서 더 뽑은 실험 (7차)
import { fmt, frac, surd, dist, sub, add, mul, norm, dot, len, cross, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const V = { x: [-7, 7], y: [-5, 5] };
const COLS = ["a", "b", "c", "e", "f", "d"];
const lcg = (seed) => { let x = seed || 1; return () => ((x = (x * 16807) % 2147483647) / 2147483647); };
function erf(x) { const t = 1 / (1 + 0.3275911 * Math.abs(x)), y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return x >= 0 ? y : -y; }
const ncdf = (x, m, s) => 0.5 * (1 + erf((x - m) / (s * Math.SQRT2)));
const npdf = (x, m, s) => Math.exp(-((x - m) ** 2) / (2 * s * s)) / (s * Math.sqrt(2 * Math.PI));
// 해밍 거리 분류용 5×7 숫자 이미지
const DIG = { 1: ["00100", "01100", "00100", "00100", "00100", "00100", "01110"], 7: ["11111", "00001", "00010", "00100", "01000", "01000", "01000"], 0: ["01110", "10001", "10011", "10101", "11001", "10001", "01110"], 4: ["00010", "00110", "01010", "10010", "11111", "00010", "00010"] };
// 정육면체 전개도 11가지: [칸 좌표 목록] (첫 칸이 바닥)
const NETS = [[[1, 0], [1, 1], [1, 2], [1, 3], [0, 0], [2, 0]], [[1, 0], [1, 1], [1, 2], [1, 3], [0, 0], [2, 1]], [[1, 0], [1, 1], [1, 2], [1, 3], [0, 0], [2, 2]], [[1, 0], [1, 1], [1, 2], [1, 3], [0, 0], [2, 3]], [[1, 0], [1, 1], [1, 2], [1, 3], [0, 1], [2, 1]], [[1, 0], [1, 1], [1, 2], [1, 3], [0, 1], [2, 2]], [[1, 1], [2, 1], [3, 1], [0, 2], [1, 2], [1, 0]], [[1, 1], [2, 1], [3, 1], [0, 2], [1, 2], [2, 0]], [[1, 1], [2, 1], [3, 1], [0, 2], [1, 2], [3, 0]], [[1, 1], [0, 2], [1, 2], [2, 1], [2, 0], [3, 0]], [[0, 1], [1, 1], [2, 1], [2, 0], [3, 0], [4, 0]]];

export default [
  {
    id: "geo-kepler", grade: 6, unit: 1, lesson: "Ⅰ-2 실생활", title: "행성의 타원 궤도와 케플러 법칙", type: "조작", time: "12분",
    tags: ["타원", "초점", "면적 속도 일정"], links: ["geo-ellipse", "lab-ellipse-billiards"],
    desc: "태양을 한 초점으로 하는 타원 궤도 위를 행성이 돌 때 근일점에서는 빠르고 원일점에서는 느리지만, 같은 시간 동안 쓸고 지나간 넓이는 같다는 케플러 제2법칙을 봅니다.",
    obs: ["태양은 타원의 중심이 아니라 한 초점에 있습니다.", "이심률이 클수록 궤도가 납작하고 속도 차이도 커집니다.", "같은 시간 동안 태양과 행성을 이은 선분이 쓸고 간 부채꼴 넓이는 같습니다."],
    q: "지구의 궤도 이심률은 약 0.017입니다. 지구 궤도는 거의 어떤 모양일까요?",
    formula: "근일점 거리 a − c · 원일점 거리 a + c · 이심률 e = c/a",
    en: { title: "Elliptical Orbits and Kepler's Laws", desc: "A planet sweeps equal areas in equal times on an elliptical orbit with the Sun at a focus." },
    view: V,
    params: [{ key: "e", label: "이심률 e", min: 0, max: 0.85, step: 0.01, value: 0.6 }, { key: "M", label: "시간 (한 바퀴 = 1)", min: 0, max: 1, step: 0.002, value: 0.15 }, { key: "k", label: "같은 시간 칸 수", min: 4, max: 16, step: 1, value: 8 }],
    anim: { key: "M", min: 0, max: 1, speed: 0.08, loop: "wrap", label: "공전하기" },
    pos(s, M) { const a = 5.4, e = s.e, b = a * Math.sqrt(1 - e * e); let E = 2 * Math.PI * M; for (let i = 0; i < 30; i++) E -= (E - e * Math.sin(E) - 2 * Math.PI * M) / (1 - e * Math.cos(E)); return [a * Math.cos(E), b * Math.sin(E)]; },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const a = 5.4, c = a * s.e, b = a * Math.sqrt(1 - s.e * s.e), S = [c, 0];
      g.param((u) => [a * Math.cos(u), b * Math.sin(u)], 0, 6.3, { color: "muted", w: 1.6 });
      for (let i = 0; i < s.k; i++) { if (i % 2) continue; const pts = [S]; for (let j = 0; j <= 20; j++) pts.push(this.pos(s, (i + j / 20) / s.k)); g.poly(pts, { fill: "f", fo: 0.25, stroke: false }); }
      const P = this.pos(s, s.M), Pn = this.pos(s, s.M + 0.002), sp = Math.sqrt(2 / dist(P, S) - 1 / a) * Math.sqrt(a), v = mul(norm(sub(Pn, P)), Math.min(2.6, 0.9 * sp));
      g.seg(S, P, { color: "b", w: 1.6 }); g.vec(P, add(P, v), { color: "d", w: 2.6, label: "속도" });
      g.circle(S, 0.45, { color: "f", fill: "f", fo: 0.9, w: 1.4 }); g.text(S, "태양", { dy: 30, bold: true, size: 12 });
      g.point([-c, 0], "", { color: "muted", r: 3, hollow: true });
      g.circle(P, 0.22, { color: "b", fill: "b", fo: 1, w: 1 });
      g.point([a, 0], "근일점", { color: "ink", r: 3, dy: 20, anchor: "middle", dx: 0 }).point([-a, 0], "원일점", { color: "ink", r: 3, dy: 20, anchor: "middle", dx: 0 });
    },
    metrics(s) { const a = 5.4, c = a * s.e, P = this.pos(s, s.M), r = dist(P, [c, 0]), sp = Math.sqrt(2 / r - 1 / a); return [["이심률", fmt(s.e, 2)], ["근일점 : 원일점 거리", `${fmt(a - c, 2)} : ${fmt(a + c, 2)}`], ["지금 속력 (평균 = 1)", fmt(sp * Math.sqrt(a), 3), "key"], ["노란 부채꼴의 넓이", "모두 같음"]]; },
  },
  {
    id: "geo-loran", grade: 6, unit: 1, lesson: "Ⅰ-3 실생활", title: "쌍곡선 항법 — 두 신호의 시간 차로 위치 찾기", type: "조작", time: "12분",
    tags: ["쌍곡선", "거리의 차", "위치 결정"], links: ["geo-hyperbola"],
    desc: "배가 두 기지국에서 동시에 보낸 전파를 받는 시간 차가 일정하면 배는 두 기지국을 초점으로 하는 쌍곡선 위에 있습니다. 두 쌍의 기지국으로 쌍곡선 두 개를 그려 교점에서 배의 위치를 찾습니다.",
    obs: ["도착 시간 차 × 전파 속도 = 두 기지국까지 거리의 차입니다.", "거리의 차가 일정한 점들은 쌍곡선의 한 가지 위에 있습니다.", "두 쌍의 기지국에서 얻은 쌍곡선의 교점이 배의 위치입니다."],
    q: "기지국이 하나뿐이라면 위치를 알 수 있을까요?",
    formula: "|PF₁ − PF₂| = (시간 차) × (전파 속도) = 2a",
    en: { title: "Hyperbolic Navigation", desc: "Time differences place a ship on hyperbolas; two pairs of stations pin it down." },
    view: V, points: { P: [2.4, 2] },
    stations: [[-5, -3.5], [5, -3.5], [0, 4.2]],
    branch(g, F1, F2, d, col) { const c = dist(F1, F2) / 2, a = Math.abs(d) / 2; if (a >= c - 1e-6 || a < 1e-6) return; const b = Math.sqrt(c * c - a * a), C = lerp(F1, F2, 0.5), u = norm(sub(F2, F1)), v = [-u[1], u[0]], sg = d > 0 ? 1 : -1; g.param((t) => add(C, add(mul(u, sg * a * Math.cosh(t)), mul(v, b * Math.sinh(t)))), -2.6, 2.6, { color: col, w: 2.6 }); },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const [A, B, Cc] = this.stations, P = s.P;
      const d1 = dist(P, A) - dist(P, B), d2 = dist(P, A) - dist(P, Cc);
      this.branch(g, A, B, d1, "a"); this.branch(g, A, Cc, d2, "b");
      [A, B, Cc].forEach((q, i) => { g.poly([add(q, [-0.3, -0.3]), add(q, [0.3, -0.3]), add(q, [0, 0.35])], { fill: "ink", fo: 1, color: "ink", w: 1 }); g.text(q, `기지국 ${"ABC"[i]}`, { dy: 26, size: 12, bold: true }); });
      g.seg(P, A, { color: "muted", w: 1, dash: "3 4" }).seg(P, B, { color: "muted", w: 1, dash: "3 4" }).seg(P, Cc, { color: "muted", w: 1, dash: "3 4" });
      g.point(P, "배", { color: "d", r: 7 }).handle(P, "P", { color: "d" });
    },
    metrics(s) { const [A, B, Cc] = this.stations, P = s.P; return [["PA − PB (주황 쌍곡선)", fmt(dist(P, A) - dist(P, B), 3)], ["PA − PC (파랑 쌍곡선)", fmt(dist(P, A) - dist(P, Cc), 3)], ["배의 위치", "두 쌍곡선의 교점", "key"]]; },
  },
  {
    id: "alg-ferris", grade: 5, unit: 3, lesson: "Ⅲ-3 실생활", title: "대관람차 높이를 삼각함수로 모델링하기", type: "조작", time: "12분",
    tags: ["주기", "진폭", "모델링"], links: ["alg-graph-wrap", "alg-transform"],
    desc: "대관람차의 반지름, 중심 높이, 한 바퀴 도는 시간을 정해 곤돌라의 높이를 시간에 대한 삼각함수 h(t) = c − r cos(2πt/T)로 나타내고, 원하는 높이 이상인 시간을 구합니다.",
    obs: ["진폭은 반지름, 주기는 한 바퀴 시간, 평행이동은 중심 높이와 같습니다.", "탑승 지점(가장 낮은 곳)에서 출발하면 −cos 꼴이 됩니다.", "기준 높이 이상인 시간은 그래프가 직선 위에 있는 구간입니다."],
    q: "반지름 40 m, 중심 높이 45 m, 한 바퀴 12분인 대관람차에서 60 m 이상에 머무는 시간은 몇 분일까요?",
    formula: "h(t) = c − r cos(2π t / T)",
    en: { title: "Modeling a Ferris Wheel", desc: "Model a gondola's height with h(t) = c − r cos(2πt/T) and find time above a level." },
    view: BOX,
    params: [{ key: "r", label: "반지름 r (m)", min: 10, max: 50, step: 5, value: 40 }, { key: "c", label: "중심 높이 c (m)", min: 15, max: 60, step: 5, value: 45 }, { key: "T", label: "한 바퀴 시간 T (분)", min: 4, max: 20, step: 1, value: 12 }, { key: "L", label: "기준 높이 (m)", min: 0, max: 110, step: 5, value: 60 }, { key: "t", label: "지난 시간 (분)", min: 0, max: 20, step: 0.05, value: 3 }],
    anim: { key: "t", min: 0, max: 20, speed: 2, loop: "wrap", label: "돌리기" },
    derive(s) { if (s.c < s.r + 3) s.c = s.r + 5; if (s.t > s.T) s.t = s.t % s.T; },
    h(s, t) { return s.c - s.r * Math.cos((2 * Math.PI * t) / s.T); },
    draw(s, g) {
      const K = 8.8 / 110, C = [2.8, 0.8 + s.c * K], R = s.r * K, a = (2 * Math.PI * s.t) / s.T - Math.PI / 2;
      g.seg([0.3, 0.8], [5.4, 0.8], { color: "ink", w: 2 });
      g.circle(C, R, { color: "b", w: 2 }); for (let k = 0; k < 12; k++) { const q = add(C, [R * Math.cos((k * Math.PI) / 6), R * Math.sin((k * Math.PI) / 6)]); g.seg(C, q, { color: "b", w: 0.8, opacity: 0.5 }); }
      g.seg(C, [C[0] - 0.4, 0.8], { color: "muted", w: 2 }).seg(C, [C[0] + 0.4, 0.8], { color: "muted", w: 2 });
      const G = add(C, [R * Math.cos(a), R * Math.sin(a)]); g.circle(G, 0.22, { color: "d", fill: "d", fo: 1, w: 1 });
      g.seg([0.3, 0.8 + s.L * K], [5.4, 0.8 + s.L * K], { color: "e", w: 1.4, dash: "5 4" });
      const X0 = 6.6, X1 = 15.4, M = (t, hh) => [X0 + (t / 20) * (X1 - X0), 0.8 + hh * K];
      g.seg(M(0, 0), M(20, 0), { color: "axis", w: 1.2 }).seg(M(0, 0), M(0, 110), { color: "axis", w: 1.2 });
      [0, 5, 10, 15, 20].forEach((t) => g.text(M(t, 0), `${t}분`, { dy: 15, size: 11, color: "muted" })); [0, 50, 100].forEach((v) => g.text(M(0, v), `${v}m`, { dx: -4, dy: 4, anchor: "end", size: 11, color: "muted" }));
      for (let i = 0; i < 400; i++) { const t0 = (20 * i) / 400, t1 = t0 + 0.05; if (this.h(s, t0) >= s.L) g.seg(M(t0, 0), M(t1, 0), { color: "e", w: 5, opacity: 0.5 }); }
      g.seg(M(0, s.L), M(20, s.L), { color: "e", w: 1.4, dash: "5 4" });
      g.param((t) => M(t, this.h(s, t)), 0, 20, { color: "a", w: 2.8, n: 400 });
      g.point(M(s.t, this.h(s, s.t)), "", { color: "d", r: 5 });
    },
    metrics(s) { let above = 0; for (let i = 0; i < 2000; i++) if (this.h(s, (s.T * (i + 0.5)) / 2000) >= s.L) above++; return [["h(t)", `${s.c} − ${s.r} cos(2πt/${s.T})`, ""], ["지금 높이", `${fmt(this.h(s, s.t), 1)} m`], ["한 바퀴 중 기준 이상", `${fmt((above / 2000) * s.T, 2)}분`, "key"]]; },
  },
  {
    id: "pst-gacha", grade: 8, unit: 3, lesson: "Ⅲ 탐구", title: "확률형 아이템 — 원하는 것이 나올 때까지", type: "데이터", time: "12분",
    tags: ["기댓값", "여사건", "게임과 확률"], links: ["pst-expectation", "pst-lln", "cul-voting"],
    desc: "뽑기 한 번에 원하는 아이템이 나올 확률이 p일 때, n번 안에 한 번 이상 나올 확률과 처음 나올 때까지 뽑는 횟수의 분포를 보고, ‘천장(보장)’ 제도가 있을 때 기댓값이 어떻게 바뀌는지 계산합니다.",
    obs: ["n번 안에 적어도 한 번 나올 확률은 1 − (1 − p)ⁿ입니다.", "처음 나올 때까지의 평균 횟수는 1/p입니다.", "확률이 1%라도 100번 뽑아서 반드시 나오는 것은 아닙니다(약 63%)."],
    q: "확률 2%인 아이템을 50번 안에 얻을 확률은 얼마일까요? 몇 번쯤 뽑으면 90% 확률로 얻을까요?",
    formula: "P(n번 안에 성공) = 1 − (1 − p)ⁿ · E(횟수) = 1/p",
    en: { title: "Gacha Probabilities", desc: "Chance of success within n pulls, expected pulls 1/p, and the effect of a pity limit." },
    view: BOX,
    params: [{ key: "p", label: "한 번에 나올 확률 p (%)", min: 0.5, max: 20, step: 0.5, value: 2 }, { key: "n", label: "뽑는 횟수 n", min: 1, max: 300, step: 1, value: 50 }, { key: "cap", label: "천장 (이 횟수면 반드시 지급, 0은 없음)", min: 0, max: 200, step: 10, value: 0 }],
    init: () => ({ sims: [] }),
    buttons: [["sim", "1000명이 뽑아 보기"], ["clear", "지우기"]],
    onDo(k, s) { if (k === "clear") { s.sims = []; return; } const p = s.p / 100; s.sims = Array.from({ length: 1000 }, () => { let t = 1; while (Math.random() >= p && (!s.cap || t < s.cap) && t < 2000) t++; return t; }); },
    onChange(s) { s.sims = []; },
    prefill(s) { this.onDo("sim", s); },
    N(s) { const p = s.p / 100, n98 = Math.log(0.02) / Math.log(1 - p), m = Math.max(s.n * 1.08, s.cap ? Math.min(s.cap * 1.1, n98) : n98, 10), st = m > 150 ? 50 : m > 60 ? 20 : m > 25 ? 10 : 5; return Math.min(300, Math.ceil(m / st) * st); },
    E(s) { const p = s.p / 100; if (!s.cap) return 1 / p; let e = 0; for (let k = 1; k < s.cap; k++) e += k * p * (1 - p) ** (k - 1); return e + s.cap * (1 - p) ** (s.cap - 1); },
    draw(s, g) {
      const p = s.p / 100, N = this.N(s), M = (x, y) => [1.4 + (x / N) * 14, 1.2 + y * 8.6], st = N > 150 ? 50 : N > 60 ? 20 : N > 25 ? 10 : 5, bw = N / 30;
      g.seg(M(0, 0), M(N, 0), { color: "axis", w: 1.2 }).seg(M(0, 0), M(0, 1), { color: "axis", w: 1.2 });
      [0, 0.25, 0.5, 0.75, 1].forEach((v) => { g.seg(M(0, v), M(N, v), { color: "grid", w: 1 }); g.text(M(0, v), `${v * 100}%`, { dx: -4, dy: 4, anchor: "end", size: 11, color: "muted" }); });
      for (let x = 0; x <= N; x += st) g.text(M(x, 0), String(x), { dy: 15, size: 11, color: "muted" });
      const F = (n) => (s.cap && n >= s.cap ? 1 : 1 - (1 - p) ** n);
      g.param((x) => M(x, F(Math.floor(x))), 0, N, { color: "a", w: 2.8, n: 900 });
      if (s.sims.length) { const H = Array(30).fill(0); s.sims.forEach((t) => { if (t <= N) H[Math.min(29, Math.floor((t - 1) / bw))]++; }); const mx = Math.max(...H) || 1; H.forEach((c, i) => { const x0 = M(i * bw, 0)[0], x1 = M(i * bw + bw, 0)[0]; g.poly([[x0, 1.2], [x1 - 0.05, 1.2], [x1 - 0.05, 1.2 + (c / mx) * 3], [x0, 1.2 + (c / mx) * 3]], { fill: "b", fo: 0.35, stroke: false }); }); }
      if (s.n <= N) g.seg(M(s.n, 0), M(s.n, F(s.n)), { color: "d", w: 1.6, dash: "4 4" }).point(M(s.n, F(s.n)), `${fmt(F(s.n) * 100, 1)}%`, { color: "d", r: 5 });
      g.seg(M(Math.min(N, this.E(s)), 0), M(Math.min(N, this.E(s)), 1), { color: "c", w: 1.4, dash: "6 4" }).text(M(Math.min(N, this.E(s)), 1), `평균 ${fmt(this.E(s), 1)}번`, { dy: -4, color: "c", bold: true, size: 12 });
      g.text([8.4, 10.5], "n번 안에 한 번 이상 나올 확률 (파랑 막대: 1000명의 실제 횟수)", { size: 12, bold: true, color: "muted" });
    },
    metrics(s) { const p = s.p / 100, F = s.cap && s.n >= s.cap ? 1 : 1 - (1 - p) ** s.n, n90 = Math.ceil(Math.log(0.1) / Math.log(1 - p)); return [[`${s.n}번 안에 나올 확률`, `${fmt(F * 100, 2)}%`, "key"], ["평균 뽑기 횟수", s.cap ? `${fmt(this.E(s), 1)}번 (천장 ${s.cap})` : `1/p = ${fmt(1 / p, 1)}번`], ["90% 확률로 얻으려면", s.cap && s.cap < n90 ? `${s.cap}번 (천장)` : `${n90}번`]]; },
  },
  {
    id: "pst-quality", grade: 8, unit: 3, lesson: "Ⅲ-5 예제", title: "정규분포로 하는 품질 관리 — 초콜릿 무게", type: "조작", time: "10분",
    tags: ["정규분포", "불량률", "표준화"], links: ["pst-normal", "pst-sample-mean"],
    desc: "초콜릿 한 개의 무게가 정규분포를 따를 때, 기계의 평균 무게와 흩어진 정도를 조절하며 표시 무게보다 가벼운 불량품의 비율을 줄이는 방법을 찾습니다.",
    obs: ["평균을 높이면 불량률은 줄지만 재료가 더 듭니다.", "표준편차(흩어짐)를 줄이면 평균을 크게 올리지 않아도 불량률이 줄어듭니다.", "불량률은 표준화한 Z로 표준정규분포에서 읽습니다."],
    q: "평균 70 g, 표준편차 0.6 g일 때 69 g 미만인 초콜릿의 비율은 약 몇 %일까요?",
    formula: "P(X < 기준) = P(Z < (기준 − m)/σ)",
    en: { title: "Quality Control with the Normal Distribution", desc: "Tune the mean and spread of a machine to cut the share of underweight chocolates." },
    view: BOX,
    params: [{ key: "m", label: "기계의 평균 무게 m (g)", min: 68, max: 72, step: 0.1, value: 70 }, { key: "sd", label: "표준편차 σ (g)", min: 0.2, max: 1.2, step: 0.05, value: 0.6 }, { key: "L", label: "표시 무게(기준) (g)", min: 67, max: 71, step: 0.5, value: 69 }],
    draw(s, g) {
      const M = (x, y) => [1.4 + ((x - 66) / 8) * 14, 1.2 + (y / 2.1) * 8.6];
      g.seg(M(66, 0), M(74, 0), { color: "axis", w: 1.2 }); for (let x = 66; x <= 74; x++) g.text(M(x, 0), `${x}g`, { dy: 15, size: 11, color: "muted" });
      const pts = []; for (let i = 0; i <= 120; i++) { const x = 66 + ((s.L - 66) * i) / 120; pts.push(M(x, npdf(x, s.m, s.sd))); }
      g.poly([M(66, 0), ...pts, M(s.L, 0)], { fill: "d", fo: 0.45, stroke: false });
      g.param((x) => M(x, Math.min(2.1, npdf(x, s.m, s.sd))), 66, 74, { color: "b", w: 2.8, n: 300 });
      g.seg(M(s.L, 0), M(s.L, 2), { color: "d", w: 1.6, dash: "5 4" }).text(M(s.L, 2), "기준", { dy: -4, color: "d", bold: true, size: 12 });
      g.seg(M(s.m, 0), M(s.m, npdf(s.m, s.m, s.sd)), { color: "b", w: 1.2, dash: "3 4" });
    },
    metrics(s) { const z = (s.L - s.m) / s.sd, p = ncdf(s.L, s.m, s.sd); return [["표준화 Z", `(${fmt(s.L)} − ${fmt(s.m)}) / ${fmt(s.sd, 2)} = ${fmt(z, 2)}`], ["불량률 P(X < 기준)", `${fmt(p * 100, 2)}%`, "key"], ["1만 개 중 불량품", `약 ${fmt(p * 10000, 0)}개`]]; },
  },
  {
    id: "ai-hamming", grade: 10, unit: 2, lesson: "Ⅲ-3 탐구", title: "해밍 거리로 숫자 이미지 분류하기", type: "조작", time: "10분",
    tags: ["해밍 거리", "이미지 행렬", "분류"], links: ["ai-knn", "ai-convolution"],
    desc: "0과 1로 된 5×7 숫자 이미지에 잡음을 섞은 뒤, 기준 이미지들과 서로 다른 칸의 수(해밍 거리)를 세어 가장 가까운 숫자로 분류합니다.",
    obs: ["해밍 거리는 두 행렬에서 값이 다른 칸의 개수입니다.", "잡음이 적으면 원래 숫자와의 거리가 가장 작습니다.", "잡음이 많아지면 다른 숫자로 잘못 분류될 수 있습니다."],
    q: "1과 7의 기준 이미지 사이의 해밍 거리는 얼마일까요?",
    formula: "해밍 거리 = Σ |aᵢⱼ − bᵢⱼ|",
    en: { title: "Classifying Digits by Hamming Distance", desc: "Count differing pixels between a noisy image and reference digits." },
    view: BOX,
    params: [{ key: "d", label: "원래 숫자", type: "seg", value: 7, options: [[1, "1"], [7, "7"], [0, "0"], [4, "4"]] }, { key: "noise", label: "잡음 칸 수", min: 0, max: 14, step: 1, value: 4 }],
    init: () => ({ seed: 5 }),
    buttons: [["new", "잡음 다시 넣기"]],
    onDo(k, s) { if (k === "new") s.seed = Math.floor(Math.random() * 1e6); },
    img(s) { const r = lcg(s.seed + s.d * 7), m = DIG[s.d].map((row) => [...row].map(Number)), cells = [...Array(35).keys()]; for (let i = 34; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [cells[i], cells[j]] = [cells[j], cells[i]]; } cells.slice(0, s.noise).forEach((c) => (m[Math.floor(c / 5)][c % 5] ^= 1)); return m; },
    ham(A, key) { let d = 0; DIG[key].forEach((row, i) => [...row].forEach((v, j) => (d += +v !== A[i][j] ? 1 : 0))); return d; },
    draw(s, g) {
      const A = this.img(s), grid = (O, M, cs, col, hl) => M.forEach((row, i) => row.forEach((v, j) => { const p = [O[0] + j * cs, O[1] + (6 - i) * cs]; g.poly([p, add(p, [cs, 0]), add(p, [cs, cs]), add(p, [0, cs])], { fill: v ? col : "paper", fo: v ? 0.85 : 1, color: hl && hl[i][j] ? "d" : "grid", w: hl && hl[i][j] ? 2 : 0.6 }); }));
      grid([0.8, 2.2], A, 0.95, "ink"); g.text([3.2, 9.6], "입력 이미지", { bold: true, size: 13 });
      const keys = [1, 7, 0, 4], dists = keys.map((k) => this.ham(A, k)), best = keys[dists.indexOf(Math.min(...dists))];
      keys.forEach((k, i) => { const O = [7 + i * 2.2, 5.2], M = DIG[k].map((r) => [...r].map(Number)); grid(O, M, 0.36, k === best ? "a" : "muted"); g.text([O[0] + 0.9, 4.3], `거리 ${dists[i]}`, { size: 13, bold: true, color: k === best ? "a" : "muted" }); });
      g.text([11.4, 8.6], "기준 이미지", { bold: true, size: 13 });
      g.text([11.4, 2.6], `분류 결과: ${best}`, { size: 20, bold: true, color: best === s.d ? "c" : "d" });
    },
    metrics(s) { const A = this.img(s), keys = [1, 7, 0, 4], dd = keys.map((k) => this.ham(A, k)), best = keys[dd.indexOf(Math.min(...dd))]; return [["해밍 거리 (1 · 7 · 0 · 4)", dd.join(" · ")], ["분류", `${best} ${best === s.d ? "(정답)" : "(오답)"}`, "key"]]; },
  },
  {
    id: "m2-pizza", grade: 2, unit: 7, lesson: "7.1 활용", title: "피자 크기와 가격 — 닮음비와 넓이의 비", type: "조작", time: "8분",
    tags: ["닮음비", "넓이의 비", "실생활"], color: "#198574", links: ["m2-right-similar", "cul-golden-card"],
    desc: "지름이 다른 두 피자의 넓이는 지름의 비의 제곱만큼 차이 난다는 것을 보고, 1 cm²당 가격으로 어느 쪽이 더 이득인지 비교합니다.",
    obs: ["닮음비가 k이면 넓이의 비는 k²입니다.", "지름이 1.5배이면 넓이는 2.25배입니다.", "넓이당 가격으로 비교해야 공정합니다."],
    q: "지름 20 cm 피자 두 판과 지름 30 cm 피자 한 판 중 어느 쪽이 더 많을까요?",
    formula: "넓이의 비 = (닮음비)² · 1 cm²당 가격 = 가격 ÷ 넓이",
    en: { title: "Pizza Sizes and Prices", desc: "Areas scale with the square of the diameter ratio; compare price per area." },
    view: BOX,
    params: [{ key: "d1", label: "작은 피자 지름 (cm)", min: 15, max: 30, step: 1, value: 20 }, { key: "p1", label: "작은 피자 가격 (천 원)", min: 5, max: 30, step: 1, value: 12 }, { key: "d2", label: "큰 피자 지름 (cm)", min: 20, max: 45, step: 1, value: 30 }, { key: "p2", label: "큰 피자 가격 (천 원)", min: 8, max: 40, step: 1, value: 22 }],
    draw(s, g) {
      const k = 0.13, C1 = [3.4, 5.4], C2 = [10.6, 5.4];
      [[C1, s.d1, "f"], [C2, s.d2, "a"]].forEach(([c, d, col]) => { g.circle(c, (d / 2) * k, { color: col, fill: col, fo: 0.35, w: 2.4 }); for (let i = 0; i < 8; i++) g.seg(c, add(c, [(d / 2) * k * Math.cos((i * Math.PI) / 4), (d / 2) * k * Math.sin((i * Math.PI) / 4)]), { color: col, w: 0.8, opacity: 0.6 }); g.text([c[0], 1.2], `지름 ${d} cm`, { size: 13, bold: true }); });
      const n = (s.d2 / s.d1) ** 2; g.text([8, 10.2], `큰 피자 한 판 = 작은 피자 약 ${fmt(n, 2)}판`, { size: 15, bold: true, color: "c" });
    },
    metrics(s) { const A1 = Math.PI * (s.d1 / 2) ** 2, A2 = Math.PI * (s.d2 / 2) ** 2, u1 = (s.p1 * 1000) / A1, u2 = (s.p2 * 1000) / A2; return [["닮음비 · 넓이의 비", `${fmt(s.d2 / s.d1, 3)} · ${fmt((s.d2 / s.d1) ** 2, 3)}`], ["1 cm²당 가격 (작은 · 큰)", `${fmt(u1, 1)}원 · ${fmt(u2, 1)}원`], ["더 이득인 피자", u2 < u1 ? "큰 피자" : u2 > u1 ? "작은 피자" : "같음", "key"]]; },
  },
  {
    id: "cul-weighted", grade: 11, unit: 3, lesson: "Ⅲ-4", title: "가치소비 — 가중치로 고르는 합리적 선택", type: "데이터", time: "10분",
    tags: ["가중평균", "의사 결정", "가치소비"], links: ["cul-voting", "job-chart-choice"],
    desc: "가격·품질·친환경·디자인 점수에 내가 중요하게 여기는 정도(가중치)를 곱해 더한 가중평균으로 세 제품을 비교하고, 가중치를 바꾸면 선택이 어떻게 달라지는지 봅니다.",
    obs: ["가중평균 = Σ(점수 × 가중치) ÷ Σ가중치입니다.", "가중치가 같으면 산술평균과 같습니다.", "무엇을 중요하게 여기는지에 따라 가장 좋은 선택이 바뀝니다."],
    q: "친환경의 가중치를 가장 높이면 어떤 제품이 선택될까요?",
    formula: "가중평균 = (w₁x₁ + w₂x₂ + ⋯ + wₙxₙ) / (w₁ + w₂ + ⋯ + wₙ)",
    en: { title: "Values-Based Choice with Weights", desc: "Compare products with weighted averages and watch the choice change." },
    view: BOX,
    params: [{ key: "w0", label: "가격 가중치", min: 0, max: 5, step: 1, value: 3 }, { key: "w1", label: "품질 가중치", min: 0, max: 5, step: 1, value: 2 }, { key: "w2", label: "친환경 가중치", min: 0, max: 5, step: 1, value: 1 }, { key: "w3", label: "디자인 가중치", min: 0, max: 5, step: 1, value: 1 }],
    P: [["제품 가", [9, 6, 4, 7], "a"], ["제품 나", [6, 8, 7, 6], "b"], ["제품 다", [4, 7, 10, 8], "c"]],
    score(s, v) { const w = [s.w0, s.w1, s.w2, s.w3], t = w.reduce((a, b) => a + b, 0) || 1; return v.reduce((a, x, i) => a + x * w[i], 0) / t; },
    draw(s, g) {
      const crit = ["가격", "품질", "친환경", "디자인"], w = [s.w0, s.w1, s.w2, s.w3];
      crit.forEach((c, i) => { const y = 9.4 - i * 1.3; g.text([1.2, y], c, { anchor: "start", bold: true, size: 13 }); g.text([3.4, y], `×${w[i]}`, { size: 12, color: "e", bold: true, mono: true }); this.P.forEach(([, v, col], j) => { const x0 = 4.4 + j * 3.6; g.poly([[x0, y - 0.35], [x0 + v[i] * 0.3, y - 0.35], [x0 + v[i] * 0.3, y + 0.25], [x0, y + 0.25]], { fill: col, fo: 0.25 + 0.12 * w[i], stroke: false }); g.text([x0 + v[i] * 0.3, y], String(v[i]), { dx: 5, dy: 4, anchor: "start", size: 11.5 }); }); });
      this.P.forEach(([nm, v, col], j) => { const x0 = 4.4 + j * 3.6, sc = this.score(s, v); g.text([x0 + 1.4, 10.5], nm, { bold: true, size: 13, color: col }); g.poly([[x0, 1], [x0 + 2.8, 1], [x0 + 2.8, 1 + sc * 0.35], [x0, 1 + sc * 0.35]], { fill: col, fo: 0.6, color: col, w: 1 }); g.text([x0 + 1.4, 1 + sc * 0.35], fmt(sc, 2), { dy: -6, bold: true, size: 13 }); });
      g.text([1.2, 2.2], "가중평균", { anchor: "start", bold: true, size: 13 });
    },
    metrics(s) { const sc = this.P.map(([nm, v]) => [nm, this.score(s, v)]), best = sc.reduce((a, b) => (b[1] > a[1] ? b : a)); return [["가중평균", sc.map(([n, v]) => `${n.slice(-1)} ${fmt(v, 2)}`).join(" · ")], ["선택", best[0], "key"]]; },
  },
  {
    id: "job-chance-scale", grade: 12, unit: 4, lesson: "Ⅳ-2", title: "가능성을 0부터 1까지의 수로", type: "조작", time: "6분",
    tags: ["가능성", "확률", "수직선"], links: ["pst-dice-sum", "pst-lln"],
    desc: "여러 직무 상황의 일이 일어날 가능성을 0(불가능)부터 1(반드시)까지의 수직선 위에 놓고, 비율로 계산한 값과 비교합니다.",
    obs: ["반드시 일어나는 일의 가능성은 1, 절대 일어나지 않는 일은 0입니다.", "가능성은 (해당하는 경우의 수) ÷ (전체 경우의 수)로 수치화할 수 있습니다.", "자료가 많을수록 비율로 구한 가능성을 믿을 수 있습니다."],
    q: "예매된 249만 건 중 93만 건이 취소되었다면, 예매 1건이 취소될 가능성은 얼마일까요?",
    formula: "가능성 = (해당하는 경우) ÷ (전체 경우), 0 ≤ 가능성 ≤ 1",
    en: { title: "Chance on a 0-to-1 Scale", desc: "Place workplace events on a scale from impossible (0) to certain (1)." },
    view: BOX,
    params: [{ key: "i", label: "상황", type: "select", value: 2, options: [[0, "주사위 눈이 7"], [1, "동전 앞면"], [2, "예매 취소 (93만/249만)"], [3, "임금 인상 없음 (70%)"], [4, "제비 10개 중 당첨 1개"], [5, "내일 해가 뜸"]] }],
    E: [["주사위 눈이 7", 0], ["동전 앞면", 0.5], ["예매 취소", 928804 / 2491168], ["임금 인상 없음", 0.7], ["당첨", 0.1], ["해가 뜸", 1]],
    draw(s, g) {
      const M = (p) => [1.6 + p * 12.8, 5];
      g.seg(M(0), M(1), { color: "ink", w: 3 });
      [[0, "불가능"], [0.5, "반반"], [1, "반드시"]].forEach(([p, nm]) => { g.seg(add(M(p), [0, -0.3]), add(M(p), [0, 0.3]), { color: "ink", w: 2 }); g.text(M(p), `${p}`, { dy: 24, size: 13, bold: true }); g.text(M(p), nm, { dy: 42, size: 12, color: "muted" }); });
      this.E.forEach(([nm, p], i) => { const on = i === +s.i, y = 6.2 + (i % 3) * 1.2; g.seg(M(p), [M(p)[0], y - 0.3], { color: on ? "d" : "grid", w: 1.2 }); g.circle(M(p), on ? 0.28 : 0.16, { color: on ? "d" : "b", fill: on ? "d" : "b", fo: 1, w: 1 }); g.text([M(p)[0], y], nm, { size: on ? 14 : 11.5, bold: on, color: on ? "d" : "muted" }); });
    },
    metrics(s) { const [nm, p] = this.E[+s.i]; return [["상황", nm], ["가능성", `${fmt(p, 4)} (${fmt(p * 100, 1)}%)`, "key"]]; },
  },
  {
    id: "m1-cube-nets", grade: 1, unit: 7, lesson: "7.3 탐구", title: "정육면체 전개도 11가지 — 접어서 확인하기", type: "3D", time: "12분",
    tags: ["전개도", "정육면체", "공간 감각"], color: "#198574", links: ["net-fold", "job-orthographic"],
    desc: "서로 다른 정육면체 전개도 11가지를 하나씩 골라 3D로 접었다 펴 보며 모든 면이 겹치지 않고 정육면체가 되는지 확인합니다.",
    obs: ["정육면체의 서로 다른 전개도는 모두 11가지입니다.", "한 줄로 4칸이 이어진 전개도가 6가지 있습니다.", "전개도에서 한 칸 건너 이웃한 두 면은 접으면 마주 봅니다."],
    q: "정사각형 6개를 이어 붙였지만 정육면체로 접히지 않는 모양을 찾아보세요.",
    formula: "정육면체 전개도의 종류 = 11",
    en: { title: "The 11 Nets of a Cube", desc: "Fold each of the eleven cube nets in 3D." },
    space: true, cam: { yaw: 30, pitch: 34, scale: 92 },
    params: [{ key: "k", label: "전개도 번호", min: 1, max: 11, step: 1, value: 1 }, { key: "t", label: "접은 정도", min: 0, max: 1, step: 0.01, value: 0.7, show: (v) => `${Math.round(v * 100)}%` }],
    anim: { key: "t", min: 0, max: 1, speed: 0.4, label: "접었다 펴기" },
    fold(s) {
      const cells = NETS[s.k - 1], n = cells.length, key = (c) => c.join(","), idx = new Map(cells.map((c, i) => [key(c), i]));
      const parent = Array(n).fill(-1), order = [0], seen = new Set([0]);
      while (order.length < n) { let grown = false; for (const i of [...order]) for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) { const j = idx.get(key([cells[i][0] + dx, cells[i][1] + dy])); if (j != null && !seen.has(j)) { seen.add(j); parent[j] = i; order.push(j); grown = true; } } if (!grown) break; }
      const ang = (Math.PI / 2) * s.t, faces = [];
      // 각 면을 부모 기준으로 변환: 로컬 좌표계에서 칸 사각형을 3D로 누적 변환
      const R = (axis, a, p, o) => { const v = sub(p, o), c = Math.cos(a), sn = Math.sin(a), k = norm(axis); return add(o, add(add(mul(v, c), mul(cross(k, v), sn)), mul(k, dot(k, v) * (1 - c)))); };
      const quad = (c) => [[c[0], c[1], 0], [c[0] + 1, c[1], 0], [c[0] + 1, c[1] + 1, 0], [c[0], c[1] + 1, 0]];
      const chain = (i) => { const path = []; let j = i; while (parent[j] >= 0) { path.push(j); j = parent[j]; } return path; };
      for (let i = 0; i < n; i++) {
        let pts = quad(cells[i]);
        for (const j of chain(i)) { const p = cells[parent[j]], c = cells[j], dx = c[0] - p[0], dy = c[1] - p[1]; const o = dx === 1 ? [p[0] + 1, p[1], 0] : dx === -1 ? [p[0], p[1], 0] : dy === 1 ? [p[0], p[1] + 1, 0] : [p[0], p[1], 0]; const axis = dx !== 0 ? [0, 1, 0] : [1, 0, 0], sg = dx === 1 ? -1 : dx === -1 ? 1 : dy === 1 ? 1 : -1; pts = pts.map((q) => R(axis, sg * ang, q, o)); }
        faces.push(pts);
      }
      return faces;
    },
    draw(s, g) {
      const F = this.fold(s), all = F.flat(), C = [0, 1, 2].map((i) => all.reduce((a, p) => a + p[i], 0) / all.length);
      F.forEach((f, i) => g.face(f.map((p) => sub(p, C)), { fill: COLS[i], color: "ink", fo: 0.62, w: 1.4 }));
      if (s.t < 0.02) g.note(20, 54, "펼친 전개도 — 접은 정도를 올려 보세요", { color: "muted" });
      g.note(20, 30, `전개도 ${s.k} / 11`, { color: "ink", bold: true });
    },
    metrics(s) { return [["전개도", `${s.k}번째 (모두 11가지)`, "key"], ["접은 정도", `${Math.round(s.t * 90)}°`]]; },
  },
];
