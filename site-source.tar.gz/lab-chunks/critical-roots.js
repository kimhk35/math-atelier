// For a continuous function that is monotone between the supplied critical points.
// Critical points are explicit mathematical data supplied by the polynomial experiment.
export function criticalRoots(f,critical,lo,hi){
 const xs=[lo,...critical.filter(x=>x>lo&&x<hi),hi].sort((a,b)=>a-b),roots=[],tol=1e-9;
 const put=x=>{if(!roots.some(r=>Math.abs(r-x)<1e-7))roots.push(x);};
 for(const x of xs)if(Math.abs(f(x))<tol)put(x);
 for(let i=0;i<xs.length-1;i++){let a=xs[i],b=xs[i+1],fa=f(a),fb=f(b);if(!Number.isFinite(fa)||!Number.isFinite(fb)||fa*fb>=0)continue;for(let k=0;k<64;k++){const m=(a+b)/2,fm=f(m);if(Math.abs(fm)<1e-13){a=b=m;break;}if(fa*fm<=0){b=m;fb=fm;}else{a=m;fa=fm;}}put((a+b)/2);}
 return roots.sort((a,b)=>a-b);
}
