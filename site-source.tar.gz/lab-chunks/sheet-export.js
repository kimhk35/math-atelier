// 학습지 내보내기 — PDF(화면 그대로) · DOCX · HWPX(zip에 담아) · 공통 문서 모형
import { data, blankify, stepsOf, tt, isEN } from "./sheet.js";
import { toTex } from "./mathtex.js";

const CDN = {
  jszip: "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js",
  h2c: "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js",
  jspdf: "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js",
};
const loaded = {};
function loadScript(k) {
  return (loaded[k] ||= new Promise((ok, no) => { const s = document.createElement("script"); s.src = CDN[k]; s.onload = ok; s.onerror = () => { delete loaded[k]; no(new Error(isEN() ? "Could not load a library" : "라이브러리를 불러오지 못했어요")); }; document.head.append(s); }));
}
const xml = (s) => String(s ?? "").replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
const hex = (c) => c.replace("#", "").toUpperCase();
function mix(c, base = "#fbf8f1", t = 0.14) {
  const p = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  if (!/^#[0-9a-f]{6}$/i.test(c || "")) c = "#9a7a3c";
  const a = p(c), b = p(base);
  return "#" + a.map((v, i) => Math.round(v * t + b[i] * (1 - t)).toString(16).padStart(2, "0")).join("");
}

// ── 파일 저장: 아티팩트의 downloads 능력, 없으면 브라우저 내려받기 ──
// 연결은 파일을 읽자마자 미리 시작한다(응답에 10초까지 걸릴 수 있음). 한 번 받은 결과는 다시 쓴다.
let dlPending = null;
function downloads() {
  const p = (dlPending ??= (async () => { try { if (!window.claude?.use) return null; return await Promise.race([window.claude.use("downloads"), new Promise((r) => setTimeout(() => r(null), 12000))]); } catch { return null; } })());
  p.then((v) => { if (!v) dlPending = null; }); // 실패는 기억하지 않고 다음에 다시 연결
  return p;
}
downloads();
export async function saveFile(name, blob) {
  const dl = await downloads();
  if (dl) {
    try { await dl.save({ filename: name, data: blob }); return "saved"; }
    catch (e) { if (e?.code === "declined") return "declined"; if (["rejected_extension", "extension_not_enabled", "too_large", "bad_request"].includes(e?.code)) throw new Error(e.message || e.code); }
  }
  const url = URL.createObjectURL(blob), a = document.createElement("a");
  a.href = url; a.download = name; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  return "saved";
}

// ── 그림 → PNG ──
async function svgToPng(svgText, w, h, scale = 2, bg = "#ffffff") {
  const url = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svgText);
  const img = new Image(); img.decoding = "sync";
  await new Promise((ok, no) => { img.onload = ok; img.onerror = no; img.src = url; });
  const c = document.createElement("canvas"); c.width = Math.round(w * scale); c.height = Math.round(h * scale);
  const g = c.getContext("2d"); if (bg) { g.fillStyle = bg; g.fillRect(0, 0, c.width, c.height); } g.drawImage(img, 0, 0, c.width, c.height);
  return { bytes: dataUrlBytes(c.toDataURL("image/png")), w: c.width, h: c.height };
}
function dataUrlBytes(u) { const b = atob(u.split(",")[1]); const a = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
async function figPng(f) {
  if (!f) return null;
  try {
    if (f.kind === "png") { const img = new Image(); await new Promise((ok, no) => { img.onload = ok; img.onerror = no; img.src = f.data; }); return { bytes: dataUrlBytes(f.data), w: img.naturalWidth, h: img.naturalHeight }; }
    return await svgToPng(f.data, f.w, f.h, 2, "#ffffff");
  } catch { return null; }
}
// 핵심 식: MathJax로 한 줄 SVG를 만들어 PNG로
async function formulaPng(src) {
  try {
    const MJ = window.MathJax; if (!MJ?.tex2svg) return null;
    const node = MJ.tex2svg(toTex(src), { display: false }), svg = node.querySelector("svg"); if (!svg) return null;
    const box = document.createElement("div"); box.style.cssText = "position:absolute;left:-9999px;top:0;font-size:17px;color:#1f2a2e"; box.append(node); document.body.append(box);
    const r = svg.getBoundingClientRect(); box.remove();
    if (!r.width) return null;
    svg.setAttribute("width", r.width); svg.setAttribute("height", r.height); svg.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    const text = new XMLSerializer().serializeToString(svg).replace(/currentColor/g, "#1f2a2e");
    return await svgToPng(text, r.width, r.height, 3, "#faf1de");
  } catch { return null; }
}

// ── 공통 문서 모형 ──
// 블록: title · box{fill,label,paras} · head{no,title,color,meta} · img{png,cm} · table{head,rows,fill} · gap
// 문단: [{t, b, red, u, gray, big}] 의 배열
export async function buildModel(teacher) {
  const S = data(), B = [];
  B.push({ k: "title", text: tt(S.title), teacher, nameRow: S.nameRow });
  for (const [i, it] of S.items.filter((x) => !x.skip).entries()) { // 인쇄에서 뺀 실험은 파일에도 넣지 않는다
    const col = it.color || "#9a7a3c";
    B.push({ k: "head", no: i + 1, title: it.title, color: col, fill: mix(col, "#fbf8f1", 0.16), meta: [it.course, it.unit, it.lesson].filter(Boolean).join(" · ") });
    B.push({ k: "box", fill: "#ecf3f7", label: tt("학습 목표"), paras: [[{ t: it.desc }]] });
    if (it.formula) { const png = await formulaPng(it.formula); B.push({ k: "box", fill: "#faf1de", label: tt("핵심 식"), paras: [png ? [{ img: png, cm: Math.min(15, (png.w / 3) * 0.024) }] : [{ t: it.formula }]] }); }
    const fp = await figPng(it.fig); if (fp) B.push({ k: "img", png: fp, cm: 12.5 });
    B.push({ k: "box", fill: "#f4f6ef", label: tt("활동"), paras: stepsOf(it).map((s, j) => [{ t: `${j + 1}. ${s.text || s}` }]) });
    if (it.metrics.length) B.push({ k: "table", label: tt("실험 기록표"), fill: mix(col, "#ffffff", 0.16), head: ["항목", "담을 때의 값 (예시)", "내 실험 1", "내 실험 2"].map(tt), rows: it.metrics.map(([a, b]) => [a, b, "", ""]) });
    if (it.predict.length) B.push({ k: "box", fill: "#f3f0f9", label: tt("예측하고 확인하기"), paras: it.predict.flatMap((p, j) => [[{ t: `${j + 1}. ${p.q}`, b: true }], ...(p.options ? [[{ t: p.options.map((o, m) => `${"①②③④⑤⑥"[m]} ${o}`).join("    "), gray: true }]] : []), [{ t: tt("내 예측 "), gray: true }, { t: " ".repeat(28), u: true }, { t: tt("   확인한 결과 "), gray: true }, { t: " ".repeat(28), u: true }], ...(teacher ? [[{ t: `${tt("답: ")}${p.ans}${p.why ? " — " + p.why : ""}`, red: true }]] : [])]) });
    if (it.obs.length) B.push({ k: "box", fill: "#ebf5f1", label: tt("관찰 정리"), paras: it.obs.map((o) => { const [a, b, c] = blankify(o); return b ? [{ t: "• " + a }, teacher ? { t: ` ${b} `, red: true, u: true } : { t: " ".repeat(Math.max(14, b.length * 2)), u: true }, { t: c }] : [{ t: "• " + a + " ☐" }]; }) });
    if (it.extra) {
      const X = it.extra, P = [];
      (X.questions || []).forEach((q, j) => { P.push([{ t: `${j + 1}. ${q.q}`, b: true }]); P.push(teacher ? [{ t: `${tt("답: ")}${q.answer}`, red: true }] : [{ t: " ".repeat(60), u: true }]); });
      if (teacher && X.prompts?.length) { P.push([{ t: tt("핵심 발문"), b: true }]); X.prompts.forEach((x) => P.push([{ t: "· " + x, red: true }])); }
      if (teacher && X.misconceptions?.length) { P.push([{ t: tt("예상 오개념"), b: true }]); X.misconceptions.forEach((x) => P.push([{ t: "· " + x, red: true }])); }
      if (P.length) B.push({ k: "box", fill: "#fff6e3", label: tt("더 생각해 보기 (Claude가 더한 문항)"), paras: P });
    }
    if (it.q) B.push({ k: "box", fill: "#fcf0ec", label: tt("생각해 보기"), paras: [[{ t: it.q }], ...(teacher ? [[{ t: tt("지도 포인트: ") + (it.obs[0] || ""), red: true }]] : [[{ t: " ".repeat(80), u: true }], [{ t: " ".repeat(80), u: true }], [{ t: " ".repeat(80), u: true }]])] });
    B.push({ k: "gap" });
  }
  return B;
}

// ── DOCX ──
const EMU = 360000; // 1cm
function docxRun(r, rid) {
  if (r.img) { const id = rid(r.img), cx = Math.round(r.cm * EMU), cy = Math.round((r.cm * EMU * r.img.h) / r.img.w); return `<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="${cx}" cy="${cy}"/><wp:docPr id="${id.n}" name="그림 ${id.n}"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="${id.n}" name="image${id.n}.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="${id.rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>`; }
  const pr = (r.b || r.red ? "<w:b/>" : "") + (r.red ? '<w:color w:val="B23A48"/>' : r.gray ? '<w:color w:val="6B6458"/>' : "") + (r.u ? '<w:u w:val="single"/>' : "") + (r.big ? `<w:sz w:val="${r.big}"/>` : r.gray ? '<w:sz w:val="18"/>' : "");
  return `<w:r>${pr ? `<w:rPr>${pr}</w:rPr>` : ""}<w:t xml:space="preserve">${xml(r.t)}</w:t></w:r>`;
}
const docxP = (runs, rid, o = {}) => `<w:p><w:pPr>${o.center ? '<w:jc w:val="center"/>' : ""}<w:spacing w:before="${o.before ?? 0}" w:after="${o.after ?? 60}"/></w:pPr>${runs.map((r) => docxRun(r, rid)).join("")}</w:p>`;
function docxBox(fill, inner, o = {}) {
  const bd = o.left ? `<w:tblBorders><w:left w:val="single" w:sz="24" w:color="${hex(o.left)}"/><w:top w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/></w:tblBorders>` : `<w:tblBorders><w:top w:val="nil"/><w:left w:val="nil"/><w:bottom w:val="nil"/><w:right w:val="nil"/></w:tblBorders>`;
  return `<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/>${bd}<w:tblCellMar><w:top w:w="110" w:type="dxa"/><w:left w:w="180" w:type="dxa"/><w:bottom w:w="110" w:type="dxa"/><w:right w:w="180" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid><w:gridCol w:w="9900"/></w:tblGrid><w:tr><w:tc><w:tcPr><w:tcW w:w="5000" w:type="pct"/><w:shd w:val="clear" w:color="auto" w:fill="${hex(fill)}"/></w:tcPr>${inner}</w:tc></w:tr></w:tbl><w:p><w:pPr><w:spacing w:before="0" w:after="0"/></w:pPr><w:r><w:rPr><w:sz w:val="8"/></w:rPr><w:t> </w:t></w:r></w:p>`;
}
export async function toDocx(teacher) {
  await loadScript("jszip");
  const B = await buildModel(teacher), media = [];
  const rid = (png) => { let m = media.find((x) => x.png === png); if (!m) { m = { png, n: media.length + 1, rid: "rIdImg" + (media.length + 1) }; media.push(m); } return m; };
  let body = "";
  for (const b of B) {
    if (b.k === "title") body += docxBox("#f1e6cc", docxP([{ t: b.text, b: true, big: 36 }, ...(b.teacher ? [{ t: tt("    교사용"), red: true }] : [])], rid, { after: 120 }) + (b.nameRow ? docxP([{ t: tt("학교 "), gray: true }, { t: " ".repeat(20), u: true }, { t: tt("  학년 "), gray: true }, { t: " ".repeat(6), u: true }, { t: tt("  반 "), gray: true }, { t: " ".repeat(6), u: true }, { t: tt("  번호 "), gray: true }, { t: " ".repeat(6), u: true }, { t: tt("  이름 "), gray: true }, { t: " ".repeat(20), u: true }], rid) : ""));
    else if (b.k === "head") body += docxP([], rid, { after: 60 }) + docxBox(b.fill, docxP([{ t: `${b.no}  ${b.title}`, b: true, big: 26 }], rid, { after: 20 }) + docxP([{ t: b.meta, gray: true }], rid, { after: 0 }), { left: b.color });
    else if (b.k === "box") body += docxBox(b.fill, docxP([{ t: "■ " + b.label, b: true }], rid, { after: 80 }) + b.paras.map((p) => docxP(p, rid)).join(""));
    else if (b.k === "img") body += docxP([{ img: b.png, cm: b.cm }], rid, { center: true, before: 80, after: 120 });
    else if (b.k === "table") {
      const cell = (t, fill, bold) => `<w:tc><w:tcPr>${fill ? `<w:shd w:val="clear" w:color="auto" w:fill="${hex(fill)}"/>` : ""}</w:tcPr>${docxP([{ t, b: bold }], rid, { after: 0 })}</w:tc>`;
      const brd = '<w:tblBorders><w:top w:val="single" w:sz="4" w:color="D9D2C1"/><w:left w:val="single" w:sz="4" w:color="D9D2C1"/><w:bottom w:val="single" w:sz="4" w:color="D9D2C1"/><w:right w:val="single" w:sz="4" w:color="D9D2C1"/><w:insideH w:val="single" w:sz="4" w:color="E6DFCF"/><w:insideV w:val="single" w:sz="4" w:color="E6DFCF"/></w:tblBorders>';
      body += docxP([{ t: "■ " + b.label, b: true }], rid, { before: 80, after: 60 }) + `<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/>${brd}<w:tblCellMar><w:top w:w="60" w:type="dxa"/><w:left w:w="100" w:type="dxa"/><w:bottom w:w="60" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid><w:gridCol w:w="2400"/><w:gridCol w:w="3300"/><w:gridCol w:w="2100"/><w:gridCol w:w="2100"/></w:tblGrid>` +
        `<w:tr>${b.head.map((h) => cell(h, b.fill, true)).join("")}</w:tr>` + b.rows.map((r) => `<w:tr>${r.map((c, j) => cell(c, j ? null : "#faf8f3", !j)).join("")}</w:tr>`).join("") + `</w:tbl>` + docxP([], rid, { after: 60 });
    } else if (b.k === "gap") body += docxP([], rid, { after: 200 });
  }
  const doc = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>${body}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1000" w:right="1000" w:bottom="1000" w:left="1000" w:header="600" w:footer="600" w:gutter="0"/></w:sectPr></w:body></w:document>`;
  const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Malgun Gothic" w:hAnsi="Malgun Gothic" w:eastAsia="맑은 고딕" w:cs="Malgun Gothic"/><w:color w:val="1F2A2E"/><w:sz w:val="20"/><w:szCs w:val="20"/><w:lang w:val="en-US" w:eastAsia="ko-KR"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="60" w:line="300" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style></w:styles>`;
  const z = new window.JSZip();
  z.file("[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>`);
  z.file("_rels/.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`);
  z.file("word/_rels/document.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>${media.map((m) => `<Relationship Id="${m.rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/image${m.n}.png"/>`).join("")}</Relationships>`);
  z.file("word/document.xml", doc); z.file("word/styles.xml", styles);
  media.forEach((m) => z.file(`word/media/image${m.n}.png`, m.png.bytes));
  return z.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", compression: "DEFLATE" });
}

// ── HWPX ──
const HU = 283.465; // 1mm = 283.465 HWPUNIT
const TEXTW = 48000;
function hwpxHeader(fills) {
  const fonts = (lang) => `<hh:fontface lang="${lang}" fontCnt="2"><hh:font id="0" face="함초롬돋움" type="TTF" isEmbedded="0"><hh:typeInfo familyType="FCAT_GOTHIC" weight="6" proportion="4" contrast="0" strokeVariation="1" armStyle="1" letterform="1" midline="1" xHeight="1"/></hh:font><hh:font id="1" face="맑은 고딕" type="TTF" isEmbedded="0"><hh:typeInfo familyType="FCAT_GOTHIC" weight="6" proportion="4" contrast="0" strokeVariation="1" armStyle="1" letterform="1" midline="1" xHeight="1"/></hh:font></hh:fontface>`;
  const border = (t, w = "0.12 mm", c = "#000000") => `<hh:leftBorder type="${t}" width="${w}" color="${c}"/><hh:rightBorder type="${t}" width="${w}" color="${c}"/><hh:topBorder type="${t}" width="${w}" color="${c}"/><hh:bottomBorder type="${t}" width="${w}" color="${c}"/>`;
  const bf = (id, inner, fill) => `<hh:borderFill id="${id}" threeD="0" shadow="0" centerLine="NONE" breakCellSeparateLine="0"><hh:slash type="NONE" Crooked="0" isCounter="0"/><hh:backSlash type="NONE" Crooked="0" isCounter="0"/>${inner}<hh:diagonal type="SOLID" width="0.1 mm" color="#000000"/>${fill ? `<hc:fillBrush><hc:winBrush faceColor="${fill}" hatchColor="#999999" alpha="0"/></hc:fillBrush>` : ""}</hh:borderFill>`;
  const list = [bf(1, border("NONE", "0.1 mm")), bf(2, border("SOLID", "0.12 mm", "#C9C0AC"))];
  fills.forEach((f, i) => { const [c, bd] = f.split("|"); list.push(bf(3 + i, bd ? border("SOLID", "0.12 mm", "#C9C0AC") : border("NONE", "0.1 mm"), c)); });
  const cp = (id, h, color, extra = "") => `<hh:charPr id="${id}" height="${h}" textColor="${color}" shadeColor="none" useFontSpace="0" useKerning="0" symMark="NONE" borderFillIDRef="1"><hh:fontRef hangul="0" latin="1" hanja="0" japanese="0" other="0" symbol="0" user="0"/><hh:ratio hangul="100" latin="100" hanja="100" japanese="100" other="100" symbol="100" user="100"/><hh:spacing hangul="0" latin="0" hanja="0" japanese="0" other="0" symbol="0" user="0"/><hh:relSz hangul="100" latin="100" hanja="100" japanese="100" other="100" symbol="100" user="100"/><hh:offset hangul="0" latin="0" hanja="0" japanese="0" other="0" symbol="0" user="0"/>${extra}</hh:charPr>`;
  const U = '<hh:underline type="BOTTOM" shape="SOLID" color="#5A4A2A"/>';
  const chars = [cp(0, 1000, "#1F2A2E"), cp(1, 1000, "#1F2A2E", "<hh:bold/>"), cp(2, 1800, "#2B2416", "<hh:bold/>"), cp(3, 1300, "#1F2A2E", "<hh:bold/>"), cp(4, 900, "#6B6458"), cp(5, 1000, "#B23A48", "<hh:bold/>"), cp(6, 1000, "#1F2A2E", U), cp(7, 1000, "#B23A48", "<hh:bold/>" + U.replace("#5A4A2A", "#B23A48"))];
  const pp = (id, align, line, prev = 0, next = 0) => `<hh:paraPr id="${id}" tabPrIDRef="0" condense="0" fontLineHeight="0" snapToGrid="0" suppressLineNumbers="0" checked="0" textDir="AUTO"><hh:align horizontal="${align}" vertical="BASELINE"/><hh:heading type="NONE" idRef="0" level="0"/><hh:breakSetting breakLatinWord="KEEP_WORD" breakNonLatinWord="BREAK_WORD" widowOrphan="0" keepWithNext="0" keepLines="0" pageBreakBefore="0" lineWrap="BREAK"/><hh:autoSpacing eAsianEng="0" eAsianNum="0"/><hh:margin><hc:intent value="0" unit="HWPUNIT"/><hc:left value="0" unit="HWPUNIT"/><hc:right value="0" unit="HWPUNIT"/><hc:prev value="${prev}" unit="HWPUNIT"/><hc:next value="${next}" unit="HWPUNIT"/></hh:margin><hh:lineSpacing type="PERCENT" value="${line}"/><hh:border borderFillIDRef="1" offsetLeft="0" offsetRight="0" offsetTop="0" offsetBottom="0" connect="0" ignoreMargin="0"/></hh:paraPr>`;
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes" ?><hh:head xmlns:hh="http://www.hancom.co.kr/hwpml/2011/head" xmlns:hp="http://www.hancom.co.kr/hwpml/2011/paragraph" xmlns:hc="http://www.hancom.co.kr/hwpml/2011/core" version="1.4" secCnt="1"><hh:beginNum page="1" footnote="1" endnote="1" pic="1" tbl="1" equation="1"/><hh:refList><hh:fontfaces itemCnt="7">${["HANGUL", "LATIN", "HANJA", "JAPANESE", "OTHER", "SYMBOL", "USER"].map(fonts).join("")}</hh:fontfaces><hh:borderFills itemCnt="${list.length}">${list.join("")}</hh:borderFills><hh:charProperties itemCnt="${chars.length}">${chars.join("")}</hh:charProperties><hh:tabProperties itemCnt="0"/><hh:numberings itemCnt="0"/><hh:bullets itemCnt="0"/><hh:paraProperties itemCnt="3">${pp(0, "LEFT", 160)}${pp(1, "CENTER", 130, 300, 300)}${pp(2, "LEFT", 150, 0, 500)}</hh:paraProperties><hh:styles itemCnt="1"><hh:style id="0" type="PARA" name="바탕글" engName="Normal" paraPrIDRef="0" charPrIDRef="0" nextStyleIDRef="0" langID="1042" lockForm="0"/></hh:styles></hh:refList><hh:compatibleDocument targetProgram="HWP2018"><hh:layoutCompatibility/></hh:compatibleDocument></hh:head>`;
}
const SECPR = `<hp:secPr textDirection="HORIZONTAL" spaceColumns="1134" tabStop="8000" outlineShapeIDRef="0" memoShapeIDRef="0" textVerticalWidthHead="0" masterPageCnt="0"><hp:grid lineGrid="0" charGrid="0" wonggojiFormat="0"/><hp:startNum pageStartsOn="BOTH" page="0" pic="0" tbl="0" equation="0"/><hp:visibility hideFirstHeader="0" hideFirstFooter="0" hideFirstMasterPage="0" border="SHOW_ALL" fill="SHOW_ALL" hideFirstPageNum="0" hideFirstEmptyLine="0" showLineNumber="0"/><hp:pagePr landscape="WIDELY" width="59528" height="84188" gutterType="LEFT_ONLY"><hp:margin header="2835" footer="2835" gutter="0" left="5102" right="5102" top="4252" bottom="4252"/></hp:pagePr><hp:footNotePr><hp:autoNumFormat type="DIGIT" userChar="" prefixChar="" suffixChar=")" supscript="0"/><hp:noteLine length="-1" type="SOLID" width="0.12 mm" color="#000000"/><hp:noteSpacing betweenNotes="283" belowLine="567" aboveLine="850"/><hp:numbering type="CONTINUOUS" newNum="1"/><hp:placement place="EACH_COLUMN" beneathText="0"/></hp:footNotePr><hp:endNotePr><hp:autoNumFormat type="DIGIT" userChar="" prefixChar="" suffixChar=")" supscript="0"/><hp:noteLine length="14692344" type="SOLID" width="0.12 mm" color="#000000"/><hp:noteSpacing betweenNotes="0" belowLine="567" aboveLine="850"/><hp:numbering type="CONTINUOUS" newNum="1"/><hp:placement place="END_OF_DOCUMENT" beneathText="0"/></hp:endNotePr></hp:secPr><hp:ctrl><hp:colPr id="" type="NEWSPAPER" layout="LEFT" colCount="1" sameSz="1" sameGap="0"/></hp:ctrl>`;
export async function toHwpx(teacher) {
  await loadScript("jszip");
  const B = await buildModel(teacher), fills = [], bins = [];
  const fillId = (f, bd) => { const c = f.toUpperCase() + (bd ? "|B" : ""); let i = fills.indexOf(c); if (i < 0) { fills.push(c); i = fills.length - 1; } return 3 + i; };
  let objId = 1000;
  const binId = (png) => { let m = bins.find((x) => x.png === png); if (!m) { m = { png, id: "image" + (bins.length + 1) }; bins.push(m); } return m.id; };
  const run = (r) => {
    if (r.img) { const w = Math.round(r.cm * 10 * HU), h = Math.round((w * r.img.h) / r.img.w), id = ++objId; return `<hp:run charPrIDRef="0"><hp:pic id="${id}" zOrder="0" numberingType="PICTURE" textWrap="TOP_AND_BOTTOM" textFlow="BOTH_SIDES" lock="0" dropcapstyle="None" href="" groupLevel="0" instid="${id}" reverse="0"><hp:offset x="0" y="0"/><hp:orgSz width="${w}" height="${h}"/><hp:curSz width="${w}" height="${h}"/><hp:flip horizontal="0" vertical="0"/><hp:rotationInfo angle="0" centerX="${w >> 1}" centerY="${h >> 1}" rotateimage="1"/><hp:renderingInfo><hc:transMatrix e1="1" e2="0" e3="0" e4="0" e5="1" e6="0"/><hc:scaMatrix e1="1" e2="0" e3="0" e4="0" e5="1" e6="0"/><hc:rotMatrix e1="1" e2="0" e3="0" e4="0" e5="1" e6="0"/></hp:renderingInfo><hp:imgRect><hc:pt0 x="0" y="0"/><hc:pt1 x="${w}" y="0"/><hc:pt2 x="${w}" y="${h}"/><hc:pt3 x="0" y="${h}"/></hp:imgRect><hp:imgClip left="0" right="${r.img.w * 75}" top="0" bottom="${r.img.h * 75}"/><hp:inMargin left="0" right="0" top="0" bottom="0"/><hp:imgDim dimwidth="${r.img.w * 75}" dimheight="${r.img.h * 75}"/><hc:img binaryItemIDRef="${binId(r.img)}" bright="0" contrast="0" effect="REAL_PIC" alpha="0"/><hp:effects/><hp:sz width="${w}" widthRelTo="ABSOLUTE" height="${h}" heightRelTo="ABSOLUTE" protect="0"/><hp:pos treatAsChar="1" affectLSpacing="0" flowWithText="1" allowOverlap="0" holdAnchorAndSO="0" vertRelTo="PARA" horzRelTo="PARA" vertAlign="TOP" horzAlign="LEFT" vertOffset="0" horzOffset="0"/><hp:outMargin left="0" right="0" top="0" bottom="0"/></hp:pic></hp:run>`; }
    const c = r.big ? (r.big >= 30 ? 2 : 3) : r.red ? (r.u ? 7 : 5) : r.u ? 6 : r.b ? 1 : r.gray ? 4 : 0;
    return `<hp:run charPrIDRef="${c}"><hp:t>${xml(r.t)}</hp:t></hp:run>`;
  };
  const P = (runs, pp = 0) => `<hp:p id="0" paraPrIDRef="${pp}" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">${runs.length ? runs.map(run).join("") : '<hp:run charPrIDRef="0"><hp:t></hp:t></hp:run>'}</hp:p>`;
  const cell = (inner, col, row, w, bfid, h = 1000) => `<hp:tc name="" header="0" hasMargin="0" protect="0" editable="0" dirty="0" borderFillIDRef="${bfid}"><hp:subList id="" textDirection="HORIZONTAL" lineWrap="BREAK" vertAlign="TOP" linkListIDRef="0" linkListNextIDRef="0" textWidth="0" textHeight="0" hasTextRef="0" hasNumRef="0">${inner}</hp:subList><hp:cellAddr colAddr="${col}" rowAddr="${row}"/><hp:cellSpan colSpan="1" rowSpan="1"/><hp:cellSz width="${w}" height="${h}"/><hp:cellMargin left="567" right="567" top="425" bottom="425"/></hp:tc>`;
  const tbl = (rowsXml, rows, cols, h, bfid = 1) => { const id = ++objId; return `<hp:p id="0" paraPrIDRef="2" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="0"><hp:tbl id="${id}" zOrder="0" numberingType="TABLE" textWrap="TOP_AND_BOTTOM" textFlow="BOTH_SIDES" lock="0" dropcapstyle="None" pageBreak="CELL" repeatHeader="0" rowCnt="${rows}" colCnt="${cols}" cellSpacing="0" borderFillIDRef="${bfid}" noShading="0"><hp:sz width="${TEXTW}" widthRelTo="ABSOLUTE" height="${h}" heightRelTo="ABSOLUTE" protect="0"/><hp:pos treatAsChar="0" affectLSpacing="0" flowWithText="1" allowOverlap="0" holdAnchorAndSO="0" vertRelTo="PARA" horzRelTo="COLUMN" vertAlign="TOP" horzAlign="LEFT" vertOffset="0" horzOffset="0"/><hp:outMargin left="0" right="0" top="0" bottom="567"/><hp:inMargin left="510" right="510" top="141" bottom="141"/>${rowsXml}</hp:tbl></hp:run></hp:p>`; };
  const box = (fill, paras) => tbl(`<hp:tr>${cell(paras.map((p) => P(p)).join(""), 0, 0, TEXTW, fillId(fill), 1000 * paras.length)}</hp:tr>`, 1, 1, 1000 * paras.length);
  let sec = "", first = true;
  const lead = () => { if (!first) return ""; first = false; return `<hp:p id="0" paraPrIDRef="0" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0"><hp:run charPrIDRef="0">${SECPR}</hp:run></hp:p>`; };
  for (const b of B) {
    sec += lead();
    if (b.k === "title") sec += box("#f1e6cc", [[{ t: b.text, big: 36 }, ...(b.teacher ? [{ t: tt("   [교사용]"), red: true }] : [])], ...(b.nameRow ? [[{ t: tt("학교 "), gray: true }, { t: " ".repeat(20), u: true }, { t: tt("  학년 "), gray: true }, { t: " ".repeat(6), u: true }, { t: tt("  반 "), gray: true }, { t: " ".repeat(6), u: true }, { t: tt("  번호 "), gray: true }, { t: " ".repeat(6), u: true }, { t: tt("  이름 "), gray: true }, { t: " ".repeat(20), u: true }]] : [])]);
    else if (b.k === "head") sec += box(b.fill, [[{ t: `${b.no}  ${b.title}`, big: 26 }], [{ t: b.meta, gray: true }]]);
    else if (b.k === "box") sec += box(b.fill, [[{ t: "■ " + b.label, b: true }], ...b.paras]);
    else if (b.k === "img") sec += P([{ img: b.png, cm: b.cm }], 1);
    else if (b.k === "table") {
      const W = [9600, 16800, 10800, 10800], hb = fillId(b.fill, true), lb = fillId("#faf8f3", true);
      const rowXml = (cells, r, head) => `<hp:tr>${cells.map((c, j) => cell(P([{ t: c, b: head || !j }]), j, r, W[j], head ? hb : !j ? lb : 2, 1200)).join("")}</hp:tr>`;
      sec += P([{ t: "■ " + b.label, b: true }]) + tbl(rowXml(b.head, 0, true) + b.rows.map((r, i) => rowXml(r, i + 1, false)).join(""), b.rows.length + 1, 4, 1200 * (b.rows.length + 1), 2);
    } else if (b.k === "gap") sec += P([]);
  }
  // 표 셀 바깥 테두리: 데이터 표의 일반 칸은 borderFill 2(실선)
  const section = `<?xml version="1.0" encoding="UTF-8" standalone="yes" ?><hs:sec xmlns:hs="http://www.hancom.co.kr/hwpml/2011/section" xmlns:hp="http://www.hancom.co.kr/hwpml/2011/paragraph" xmlns:hc="http://www.hancom.co.kr/hwpml/2011/core">${sec}</hs:sec>`;
  const header = hwpxHeader(fills);
  const z = new window.JSZip();
  z.file("mimetype", "application/hwp+zip", { compression: "STORE" });
  z.file("version.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes" ?><hv:HCFVersion xmlns:hv="http://www.hancom.co.kr/hwpml/2011/version" tagetApplication="WORDPROCESSOR" major="5" minor="1" micro="0" buildNumber="1" os="1" xmlVersion="1.4" application="McKay Math Atelier" appVersion="1.0"/>`);
  z.file("META-INF/container.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes" ?><ocf:container xmlns:ocf="urn:oasis:names:tc:opendocument:xmlns:container" xmlns:hpf="http://www.hancom.co.kr/schema/2011/hpf"><ocf:rootfiles><ocf:rootfile full-path="Contents/content.hpf" media-type="application/hwpml-package+xml"/></ocf:rootfiles></ocf:container>`);
  z.file("Contents/content.hpf", `<?xml version="1.0" encoding="UTF-8" standalone="yes" ?><opf:package xmlns:opf="http://www.idpf.org/2007/opf/" xmlns:hpf="http://www.hancom.co.kr/schema/2011/hpf" xmlns:hh="http://www.hancom.co.kr/hwpml/2011/head"><opf:metadata><opf:title>${xml(data().title)}</opf:title><opf:meta name="generator" content="McKay Math Atelier"/></opf:metadata><opf:manifest><opf:item id="header" href="Contents/header.xml" media-type="application/xml"/><opf:item id="section0" href="Contents/section0.xml" media-type="application/xml"/>${bins.map((m) => `<opf:item id="${m.id}" href="BinData/${m.id}.png" media-type="image/png" isEmbeded="1"/>`).join("")}</opf:manifest><opf:spine><opf:itemref idref="header" linear="no"/><opf:itemref idref="section0" linear="yes"/></opf:spine></opf:package>`);
  z.file("Contents/header.xml", header);
  z.file("Contents/section0.xml", section);
  bins.forEach((m) => z.file(`BinData/${m.id}.png`, m.png.bytes));
  z.file("Preview/PrvText.txt", data().title);
  return z.generateAsync({ type: "uint8array", compression: "DEFLATE" });
}
// 아티팩트 저장 허용 목록에 hwpx가 없으므로 zip에 담는다
export async function toHwpxZip(teacher, name) {
  const bytes = await toHwpx(teacher), z = new window.JSZip(), inner = `McKay-worksheet${teacher ? "-teacher" : ""}.hwpx`;
  z.file(inner, bytes);
  z.file("README.txt", "\ufeff" + `압축을 풀면 나오는 ${inner} 파일을 한글(한컴오피스)에서 여세요.\r\n학습지 제목: ${name}\r\n`);
  return z.generateAsync({ type: "blob", compression: "DEFLATE" });
}

// ── PDF: 학습지 전체를 한 번 찍고, 문항·줄 사이의 안전한 경계에서 쪽을 나눈다 ──
export async function toPdf(paper) {
  await Promise.all([loadScript("h2c"), loadScript("jspdf")]);
  const { jsPDF } = window.jspdf, pdf = new jsPDF({ unit: "mm", format: "a4" });
  const PW = 210, PH = 297, M = 8, CW = PW - 2 * M;
  paper.classList.add("sh-exporting");
  try {
    const pr = paper.getBoundingClientRect(), H = Math.ceil(pr.height), sc = Math.min(2, 30000 / H);
    const big = await window.html2canvas(paper, { scale: sc, backgroundColor: "#fbf8f1", logging: false, useCORS: true });
    // 자를 수 있는 위치: 덩어리(큰 것은 그 안의 문항·줄·표의 행까지)의 윗선 바로 위
    const cuts = new Set([0]);
    const walk = (el, depth) => {
      const r = el.getBoundingClientRect(); if (!r.height) return;
      const pv = el.previousElementSibling; if (!(pv && (pv.classList.contains("sh-item-head") || pv.classList.contains("sh-meta")))) cuts.add(Math.max(0, Math.floor(r.top - pr.top) - 3));
      if (r.height > 110 && depth < 5) for (const c of el.children) if (!/^(SPAN|B|I|EM|STRONG|SVG|svg|IMG|MJX-CONTAINER)$/.test(c.tagName) && !c.classList.contains("mx")) walk(c, depth + 1);
    };
    [paper.querySelector(".sh-paper-head"), ...paper.querySelectorAll(".sh-item")].filter(Boolean).forEach((e) => walk(e, 0));
    const C = [...cuts].sort((x, y) => x - y), mmPerPx = CW / pr.width, pageH = (PH - 2 * M) / mmPerPx;
    let start = 0, first = true;
    while (start < H - 2) {
      let end = start + pageH;
      if (end >= H) end = H;
      else { const ok = C.filter((c) => c > start + pageH * 0.35 && c <= end); if (ok.length) end = ok[ok.length - 1]; }
      if (!first) pdf.addPage(); first = false;
      pdf.setFillColor(251, 248, 241); pdf.rect(0, 0, PW, PH, "F");
      const c = document.createElement("canvas"); c.width = big.width; c.height = Math.max(1, Math.round((end - start) * sc));
      c.getContext("2d").drawImage(big, 0, Math.round(start * sc), c.width, c.height, 0, 0, c.width, c.height);
      pdf.addImage(c, "JPEG", M, M, CW, (end - start) * mmPerPx, undefined, "FAST");
      start = end;
    }
  } finally { paper.classList.remove("sh-exporting"); }
  return pdf.output("blob");
}
