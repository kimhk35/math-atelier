// 학습지 — 실험을 담아 학생용·교사용 학습지로 엮는다 (이 기기의 브라우저에만 저장)
import { mathHTML, mathBlock } from "./mathtex.js";
import { render as renderSpec, defaults } from "./hs-core.js";
import { bankFor } from "./predict-ui.js";

const KEY = "mckay-sheet-v1";
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
function tint(c, t = 0.14, base = "#fbf8f1") { const p = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)); if (!/^#[0-9a-f]{6}$/i.test(c || "")) c = "#9a7a3c"; const a = p(c), b = p(base); return "#" + a.map((v, i) => Math.round(v * t + b[i] * (1 - t)).toString(16).padStart(2, "0")).join(""); }
const fmtN = (x) => (Number.isFinite(x) ? String(Math.round(x * 1e4) / 1e4).replace("-", "−") : String(x));

// 영어 모드: 학습지의 틀 문구만 바꾼다 (실험 내용은 담을 때의 언어 그대로 저장됨)
export const isEN = () => document.documentElement.lang === "en";
const SX = {
  "수학 실험 학습지": "Math Lab Worksheet", "학습지": "Worksheet", "학습 목표": "Learning goal", "핵심 식": "Key formula", "활동": "Activity", "실험 기록표": "Record table",
  "항목": "Item", "담을 때의 값 (예시)": "Value when added (example)", "내 실험 1": "My trial 1", "내 실험 2": "My trial 2", "예측하고 확인하기": "Predict and check",
  "내 예측": "My prediction", "확인한 결과": "Result", "답: ": "Answer: ", "관찰 정리": "Summing up observations", "더 생각해 보기": "Think further",
  "(Claude가 더한 문항)": "(questions added by Claude)", "더 생각해 보기 (Claude가 더한 문항)": "Think further (questions added by Claude)", "핵심 발문": "Key questions to ask",
  "예상 오개념과 지도": "Likely misconceptions and how to teach them", "예상 오개념": "Likely misconceptions", "생각해 보기": "Think about it", "지도 포인트: ": "Teaching point: ",
  "교사용": "Teacher's", " (교사용)": " (teacher's)", "   [교사용]": "   [Teacher's]", "    교사용": "    Teacher's", "학교": "School", "학년": "Grade", "반": "Class", "번호": "No.", "이름": "Name",
  "학교 ": "School ", "  학년 ": "  Grade ", "  반 ": "  Class ", "  번호 ": "  No. ", "  이름 ": "  Name ", "내 예측 ": "My prediction ", "   확인한 결과 ": "   Result ",
  "도입": "Opening", "질문을 던지고 학생이 결과를 먼저 예측하게 합니다.": "Pose the question and have students predict the result first.", "탐구": "Explore", "정리": "Wrap-up",
  "실험 그림": "Experiment figure", "그림": "Figure", "순서 바꾸기": "reorder", "위로": "Move up", "아래로": "Move down", "실험 열기": "Open experiment", "Claude로 문항 더하기": "Add questions with Claude", "✦ Claude로 더 풍부하게": "✦ Enrich with Claude", "빼기": "Remove",
};
Object.assign(SX, { "인쇄": "Print", "인쇄 안 함": "not printed", "체크를 빼면 인쇄·PDF·워드·한글 파일에서 빠져요": "Untick to leave it out of printing and PDF/Word/Hangul files" });
export const tt = (s) => (isEN() ? SX[s] ?? s : s);

let mem = null;
function load() {
  if (mem) return mem;
  try { mem = JSON.parse(localStorage.getItem(KEY) || "null"); } catch { mem = null; }
  if (!mem || !Array.isArray(mem.items)) mem = { title: "수학 실험 학습지", teacher: false, nameRow: true, items: [] };
  // 옛 버전이나 손상된 항목이 있어도 학습지 화면이 멈추지 않게 빠진 값을 채운다
  mem.items = mem.items.filter((x) => x && typeof x === "object" && x.id).map((x) => {
    for (const k of ["controls", "metrics", "obs"]) if (!Array.isArray(x[k])) x[k] = [];
    for (const k of ["title", "desc", "q", "formula", "lesson", "course", "unit", "time"]) if (typeof x[k] !== "string") x[k] = x[k] == null ? "" : String(x[k]);
    return x;
  });
  return mem;
}
function save() { try { localStorage.setItem(KEY, JSON.stringify(mem)); return true; } catch { return false; } }
export const count = () => load().items.length;
export const data = () => load();

// ── 실험 그림: 라이트 테마 색으로 굳힌 SVG 문자열 (캔버스면 PNG) ──
function figure(stage = document.querySelector("#stage")) {
  if (!stage) return null;
  const cv = stage.querySelector("canvas");
  if (cv) { try { return { kind: "png", data: cv.toDataURL("image/png"), w: cv.width, h: cv.height }; } catch { return null; } }
  const svg = stage.querySelector("svg"); if (!svg) return null;
  const root = document.documentElement, prev = root.dataset.theme;
  root.dataset.theme = "light";
  try {
    const cl = svg.cloneNode(true);
    cl.querySelectorAll(".hs-handle").forEach((n) => n.remove());
    const src = svg.querySelectorAll("text"), dst = cl.querySelectorAll("text");
    src.forEach((t, i) => { const cs = getComputedStyle(t), d = dst[i]; if (!d) return; d.setAttribute("font-size", cs.fontSize); d.setAttribute("font-weight", cs.fontWeight); d.setAttribute("font-style", cs.fontStyle); d.setAttribute("font-family", "'IBM Plex Sans KR','Malgun Gothic',sans-serif"); if (!d.getAttribute("fill") || /var\(/.test(d.getAttribute("fill"))) d.setAttribute("fill", cs.fill); d.removeAttribute("class"); });
    const vb = (cl.getAttribute("viewBox") || "0 0 640 440").split(/[\s,]+/).map(Number);
    cl.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    cl.setAttribute("width", vb[2]); cl.setAttribute("height", vb[3]);
    cl.removeAttribute("class");
    const cs = getComputedStyle(stage);
    const str = new XMLSerializer().serializeToString(cl).replace(/var\((--[\w-]+)\)/g, (m, n) => cs.getPropertyValue(n).trim() || "#183b48");
    return { kind: "svg", data: str, w: vb[2], h: vb[3] };
  } finally { if (prev == null) delete root.dataset.theme; else root.dataset.theme = prev; }
}
// 엔진 실험이면 spec에서, 아니면 화면에서 조작 항목과 측정값을 읽는다
function controlsOf(spec, st) {
  if (spec && spec.params) return spec.params.filter((p) => p.label && p.type !== "head" && (!p.when || p.when(st))).map((p) => p.label);
  return [...document.querySelectorAll("#controls .lab-control > span, #controls label > span, #controls .lab-check")].map((el) => (el.childNodes[0]?.textContent || "").trim()).filter(Boolean).slice(0, 8);
}
function metricsOf(spec, st) {
  if (spec && spec.metrics && st) { try { return spec.metrics(st).filter((m) => Array.isArray(m)).map((m) => [String(m[0]), String(m[1])]); } catch { /* 화면에서 읽기 */ } }
  return [...document.querySelectorAll("#metrics > div")].map((d) => [d.querySelector("small")?.dataset.mxs || d.querySelector("small")?.textContent || "", d.querySelector("strong")?.dataset.mxs || d.querySelector("strong")?.textContent || ""]).filter((m) => m[0] || m[1]).slice(0, 8);
}
function predictOf(spec, st, id, alt) {
  const P = spec?.predict || alt || bankFor(id);
  if (!P) return [];
  return P.map((it) => {
    const s2 = JSON.parse(JSON.stringify(st || {}));
    try { it.set?.(s2); spec?.derive?.(s2); } catch {}
    let ans = ""; try { ans = it.answer(s2); } catch {}
    const label = it.options ? it.options.find(([v]) => String(v) === String(ans))?.[1] ?? ans : typeof ans === "number" ? fmtN(ans) : ans;
    const q = typeof it.q === "function" ? it.q(s2) : it.q, why = typeof it.why === "function" ? it.why(s2) : it.why;
    return { q, ans: String(label), why: why || "", options: it.options ? it.options.map((o) => o[1]) : null };
  });
}
function makeItem(lab, meta = {}) {
  const st = meta.state || null, spec = meta.spec || null;
  return {
    key: lab.id + "-" + Date.now().toString(36), id: lab.id, title: lab.title, color: lab.color || "", time: lab.time || "", course: meta.course || "", unit: meta.unit || "", lesson: lab.lesson || "",
    desc: lab.desc || "", obs: lab.obs || [], q: lab.q || "", formula: lab.formula || "",
    fig: figure(), controls: controlsOf(spec, st), drags: !!document.querySelector("#stage [data-drag]"), space: !!document.querySelector("#stage.hs-stage-3d"),
    metrics: metricsOf(spec, st), predict: predictOf(spec, st, lab.id, meta.pred), at: new Date().toISOString().slice(0, 10),
  };
}
export function add(lab, meta = {}) {
  const S = load(), item = makeItem(lab, meta);
  S.items.push(item);
  if (!save()) { S.items.pop(); if (item.fig) { item.fig = null; S.items.push(item); save(); } }
  return S.items.length;
}

export function addStatic(lab, meta = {}) {
  const S = load(), spec = meta.spec || null;
  let st = null, fig = null;
  const box = document.createElement("div");
  box.className = "stage hs-stage"; box.style.cssText = "position:absolute;left:-9999px;top:0;width:640px";
  document.body.append(box);
  try {
    if (spec) { st = defaults(spec); spec.derive?.(st); box.innerHTML = renderSpec(spec, st).svg(spec.title); }
    else if (meta.thumb) box.innerHTML = meta.thumb;
    meta.prep?.(box); // 영어 모드: 그림 속 글자를 먼저 번역
    fig = figure(box);
  } catch (e) { console.error(e); } finally { box.remove(); }
  S.items.push({
    key: lab.id + "-" + Date.now().toString(36) + S.items.length, id: lab.id, title: lab.title, color: lab.color || "", course: meta.course || "", unit: meta.unit || "", lesson: lab.lesson || "", time: lab.time || "",
    desc: lab.desc || "", obs: lab.obs || [], q: lab.q || "", formula: lab.formula || "",
    fig, controls: spec ? controlsOf(spec, st) : [], drags: !!(spec && (spec.drags || Object.keys(spec.points || {}).length)), space: !!(spec && spec.space),
    metrics: spec ? metricsOf(spec, st) : [], predict: predictOf(spec, st, lab.id, meta.pred), at: new Date().toISOString().slice(0, 10),
  });
  if (!save()) { S.items.pop(); return -1; }
  return S.items.length;
}

// ── 관찰 문장 → 빈칸 ──
const MATHRUN = /[^가-힣‘’“”]+/g;
const PARTICLE = /(을|를|이|가|은|는|의|에서|에|로|으로|와|과|도|만)$/;
// 영어 문장: 가장 긴 '수식 덩어리'(숫자·기호가 든 낱말이 이어진 곳)를 비우고, 없으면 뒤쪽의 긴 낱말 하나를 비운다
const ENSTOP = /^(the|and|that|this|with|from|into|when|which|their|there|these|those|always|other|each|than|then|they|have|been|does|only|same|also|both|more|less|will|would|about|between)$/i;
function blankifyEN(sent) {
  const tok = sent.split(/(\s+)/), isM = (w) => /[=<>≤≥≠²³√πⁿ⊂∈∞∫∑×÷±−+/^()\d′″]/.test(w) || /^[a-zA-Z][,.;:]?$/.test(w);
  let best = null, cur = null;
  for (let i = 0; i < tok.length; i += 2) {
    if (isM(tok[i]) && !/^[.,:;()]+$/.test(tok[i])) { cur = cur ? { a: cur.a, b: i } : { a: i, b: i }; }
    else { if (cur && (!best || cur.b - cur.a > best.b - best.a)) best = cur; cur = null; }
  }
  if (cur && (!best || cur.b - cur.a > best.b - best.a)) best = cur;
  const cut = (a, b) => { let mid = tok.slice(a, b + 1).join(""); const tail = (mid.match(/[.,:;]+$/) || [""])[0]; mid = mid.slice(0, mid.length - tail.length); return [tok.slice(0, a).join(""), mid, tail + tok.slice(b + 1).join("")]; };
  if (best) { const r = cut(best.a, best.b); if (r[1].replace(/\s/g, "").length >= 2) return r; }
  for (let i = tok.length - 1; i >= 2; i -= 2) { const w = tok[i].replace(/[.,:;!?]+$/, ""); if (/^[A-Za-z-]{5,}$/.test(w) && !ENSTOP.test(w)) return cut(i, i); }
  return [sent, "", ""];
}
export function blankify(sent) {
  if (!/[가-힣]/.test(sent)) return blankifyEN(sent);
  let best = null;
  for (const m of sent.matchAll(MATHRUN)) {
    const raw = m[0], t = raw.trim();
    if (t.length < 2 || !/[=<>≤≥≠²³√πⁿ⊂∈A-Za-z0-9]/.test(t) || /^[.,:()\s]+$/.test(t)) continue;
    const lead = raw.length - raw.trimStart().length;
    if (!best || t.length > best.t.length) best = { t: t.replace(/[.,:]+$/, ""), at: m.index + lead };
  }
  if (best && best.t.length >= 2) return [sent.slice(0, best.at), best.t, sent.slice(best.at + best.t.length)];
  const w = sent.replace(/[.。]$/, "").split(" ");
  for (let i = w.length - 2; i >= 1; i--) {
    const word = w[i], pm = word.match(PARTICLE);
    if (!pm || word.length < pm[0].length + 2) continue;
    const pre = w.slice(0, i).join(" ") + " ", post = pm[0] + " " + w.slice(i + 1).join(" ") + (/[.。]$/.test(sent) ? "." : "");
    return [pre, word.slice(0, -pm[0].length), post];
  }
  return [sent, "", ""];
}
export function stepsOf(it) {
  const s = [];
  if (!/[가-힣]/.test(it.title + it.desc)) { // 영어로 담은 실험
    const C = it.controls.filter((c) => !/^(Scene|View|Mode)$/i.test(c));
    if (C.length) s.push({ text: `On the control panel, change ${C.slice(0, 3).map((c) => `“${c}”`).join(", ")}${C.length > 3 ? " and so on" : ""} and observe how the figure changes.`, html: `On the control panel, change ${C.slice(0, 3).map((c) => `<b class="sh-ctl">${M(c)}</b>`).join(", ")}${C.length > 3 ? " and so on" : ""} and observe how the figure changes.` });
    else s.push("Use the buttons and sliders on the experiment screen and observe how the figure and values change.");
    if (it.drags) s.push("Drag the points with orange rings and watch how the values change.");
    if (it.space) s.push("Drag the figure to rotate it and view the solid from several directions.");
    if (it.metrics.length) s.push("Write the values below the experiment in the record table, then change the conditions and record twice more.");
    if (it.predict.length) s.push("Write your predictions for “Predict and check” first, then check them in the experiment.");
    s.push("Sum up what you observed and answer the “Think about it” question.");
    return s;
  }
  const C = it.controls.filter((c) => !/^(장면|보기|모드)$/.test(c));
  if (C.length) s.push({ text: `조작판에서 ${C.slice(0, 3).map((c) => `「${c}」`).join(", ")}${C.length > 3 ? " 등" : ""}을 바꾸며 그림이 어떻게 달라지는지 관찰한다.`, html: `조작판에서 ${C.slice(0, 3).map((c) => `<b class="sh-ctl">${M(c)}</b>`).join(", ")}${C.length > 3 ? " 등" : ""}을 바꾸며 그림이 어떻게 달라지는지 관찰한다.` });
  else s.push("실험 화면의 단추와 슬라이더를 조작하며 그림과 값이 어떻게 달라지는지 관찰한다.");
  if (it.drags) s.push("주황 고리가 있는 점을 끌어 옮기며 값의 변화를 살펴본다.");
  if (it.space) s.push("그림을 끌어 돌리며 여러 방향에서 입체를 관찰한다.");
  if (it.metrics.length) s.push("실험 화면 아래의 값을 기록표에 적고, 조건을 바꾸어 두 번 더 기록한다.");
  if (it.predict.length) s.push("「예측하고 확인하기」 문항에 먼저 예측을 적은 뒤, 실험에서 확인한다.");
  s.push("관찰한 내용을 정리하고 「생각해 보기」 질문에 답한다.");
  return s;
}

// ── 학습지 화면 ──
const M = (s) => mathHTML(String(s ?? ""));
function figHTML(f) {
  if (!f) return "";
  const src = f.kind === "svg" ? "data:image/svg+xml;charset=utf-8," + encodeURIComponent(f.data) : f.data;
  return `<figure class="sh-fig"><img src="${src}" alt="${tt("실험 그림")}" width="${f.w}" height="${f.h}"></figure>`;
}
export function itemHTML(it, i, n, T, no = i + 1) {
  const blank = (s) => { const [a, b, c] = blankify(s); return b ? `${M(a)}<span class="${T ? "sh-ans" : "sh-blank"}">${T ? M(b) : ""}</span>${M(c)}` : `${M(a)} <span class="sh-check">☐</span>`; };
  return `<section class="sh-item${it.skip ? " sh-skip" : ""}" data-key="${esc(it.key)}" style="--c:${esc(it.color || "#9a7a3c")};--ct:${tint(it.color, 0.15)};--ch:${tint(it.color, 0.16, "#ffffff")}">
    <div class="sh-item-head"><h2><span class="sh-no">${it.skip ? "–" : no}</span>${esc(it.title)}${it.skip ? ` <small class="sh-skip-note">${tt("인쇄 안 함")}</small>` : ""}</h2>
      <div class="sh-tools" role="group" aria-label="${esc(it.title)} ${tt("순서 바꾸기")}"><label class="sh-pick" title="${tt("체크를 빼면 인쇄·PDF·워드·한글 파일에서 빠져요")}"><input type="checkbox" data-sh-pick ${it.skip ? "" : "checked"}>${tt("인쇄")}</label><button type="button" data-sh="up" ${i ? "" : "disabled"} aria-label="${tt("위로")}">▲</button><button type="button" data-sh="down" ${i < n - 1 ? "" : "disabled"} aria-label="${tt("아래로")}">▼</button><a href="#/lab/${esc(it.id)}" aria-label="${tt("실험 열기")}">${tt("실험 열기")}</a><button type="button" data-sh="ai" aria-label="${tt("Claude로 문항 더하기")}">${tt("✦ Claude로 더 풍부하게")}</button><button type="button" data-sh="del" aria-label="${tt("빼기")}">${tt("빼기")}</button></div></div>
    <p class="sh-meta">${esc([it.course, it.unit, it.lesson].filter(Boolean).join(" · "))}</p>
    <div class="sh-goal"><b>${tt("학습 목표")}</b><p>${M(it.desc)}</p></div>
    ${it.formula ? `<div class="sh-formula"><b>${tt("핵심 식")}</b><div>${mathBlock(it.formula)}</div></div>` : ""}
    ${figHTML(it.fig)}
    <div class="sh-block"><h3>${tt("활동")}</h3><ol>${stepsOf(it).map((s) => `<li>${s.html || esc(s)}</li>`).join("")}</ol></div>
    ${it.metrics.length ? `<div class="sh-block k-table"><h3>${tt("실험 기록표")}</h3><table class="sh-table"><thead><tr><th>${tt("항목")}</th><th>${tt("담을 때의 값 (예시)")}</th><th>${tt("내 실험 1")}</th><th>${tt("내 실험 2")}</th></tr></thead><tbody>${it.metrics.map(([k, v]) => `<tr><th>${M(k)}</th><td>${M(v)}</td><td></td><td></td></tr>`).join("")}</tbody></table></div>` : ""}
    ${it.predict.length ? `<div class="sh-block k-pred"><h3>${tt("예측하고 확인하기")}</h3><ol class="sh-pred">${it.predict.map((p) => `<li><p>${M(p.q)}</p>${p.options ? `<p class="sh-opts">${p.options.map((o, j) => `<span>${"①②③④⑤⑥"[j]} ${esc(o)}</span>`).join("")}</p>` : ""}<div class="sh-pq"><span>${tt("내 예측")}</span><span class="sh-line"></span><span>${tt("확인한 결과")}</span><span class="sh-line"></span></div>${T ? `<p class="sh-key">${tt("답: ")}${M(p.ans)}${p.why ? ` — ${M(p.why)}` : ""}</p>` : ""}</li>`).join("")}</ol></div>` : ""}
    ${it.obs.length ? `<div class="sh-block k-obs"><h3>${tt("관찰 정리")}</h3><ul class="sh-obs">${it.obs.map((o) => `<li>${blank(o)}</li>`).join("")}</ul></div>` : ""}
    ${it.extra ? `<div class="sh-block k-ai"><h3>${tt("더 생각해 보기")} <small>${tt("(Claude가 더한 문항)")}</small></h3><ol>${(it.extra.questions || []).map((x) => `<li><p>${M(x.q)}</p>${T ? `<p class="sh-key">${tt("답: ")}${M(x.answer)}</p>` : `<div class="sh-write" style="height:62px"></div>`}</li>`).join("")}</ol>${T && it.extra.prompts?.length ? `<p><b>${tt("핵심 발문")}</b></p><ul>${it.extra.prompts.map((x) => `<li>${M(x)}</li>`).join("")}</ul>` : ""}${T && it.extra.misconceptions?.length ? `<p><b>${tt("예상 오개념과 지도")}</b></p><ul>${it.extra.misconceptions.map((x) => `<li>${M(x)}</li>`).join("")}</ul>` : ""}</div>` : ""}
    ${it.q ? `<div class="sh-block k-think"><h3>${tt("생각해 보기")}</h3><p>${M(it.q)}</p>${T ? `<p class="sh-key">${tt("지도 포인트: ")}${M(it.obs[0] || "")}</p>` : `<div class="sh-write"></div>`}</div>` : ""}
  </section>`;
}
let OPT = {};
export function render(el, notice = () => {}, opt) {
  if (opt) OPT = opt;
  const S = load(), T = !!S.teacher, n = S.items.length, np = S.items.filter((x) => !x.skip).length;
  let k = 0; const nos = S.items.map((x) => (x.skip ? 0 : ++k)); // 인쇄할 실험끼리 번호를 다시 매긴다
  el.innerHTML = `<section class="at-page-head sh-head"><p class="at-eyebrow">이 기기에 저장된 학습지 · 실험 ${n}개</p><h1>학습지</h1><p class="at-desc">실험 화면의 <b>학습지에 담기</b>를 누르면 그 순간의 그림과 값이 여기에 모입니다. 학생용과 교사용을 바꿔 볼 수 있어요.</p></section>
  <div class="sh-bar" role="toolbar" aria-label="학습지 도구">
    <div class="hs-seg" role="group" aria-label="학습지 종류"><button type="button" data-sh="stu" aria-pressed="${!T}">학생용</button><button type="button" data-sh="tea" aria-pressed="${T}">교사용 (답 포함)</button></div>
    <label class="lab-check"><input type="checkbox" data-sh="name" ${S.nameRow ? "checked" : ""}>이름 칸</label>
    <span class="sh-gap"></span>
    <div class="sh-dl" role="group" aria-label="내려받기"><button type="button" class="btn primary" data-sh="pdf" ${np ? "" : "disabled"}>PDF</button><button type="button" class="btn" data-sh="docx" ${np ? "" : "disabled"}>워드 DOCX</button><button type="button" class="btn" data-sh="hwpx" ${np ? "" : "disabled"}>한글 HWPX</button><button type="button" class="btn" data-sh="print" ${np ? "" : "disabled"}>인쇄</button></div>
    ${n ? `<div class="sh-picks"><span class="sh-count">인쇄할 실험 <b>${np}</b> / ${n}개</span><button type="button" class="btn" data-sh="all">모두 고르기</button><button type="button" class="btn" data-sh="none">모두 빼기</button></div>` : ""}
    <button type="button" class="btn" data-sh="clear" ${n ? "" : "disabled"}>모두 비우기</button>
    <div class="sh-unit"><label for="sh-unit-sel">단원 통째로 담기</label><select id="sh-unit-sel"><option value="">— 과정과 단원을 고르세요 —</option>${(OPT.units || []).map(([v, l]) => `<option value="${esc(v)}">${esc(l)}</option>`).join("")}</select><span class="sh-gap"></span><button type="button" class="btn primary" data-sh="ebook" ${n ? "" : "disabled"}>교사용 e-book (HTML)</button></div>
    <div class="sh-unit-list" id="sh-unit-list" hidden></div>
    <p class="sh-msg" id="sh-msg" role="status" aria-live="polite">한글 파일은 사이트 저장 규칙 때문에 zip으로 묶어 내려받아요. 압축을 풀면 .hwpx 파일이 나와요.</p>
  </div>
  ${n ? `<article class="sh-paper${T ? " teacher" : ""}">
    <header class="sh-paper-head"><h1 class="sh-title" contenteditable="true" spellcheck="false" data-sh-title>${esc(tt(S.title))}</h1>${T ? `<p class="sh-badge">${tt("교사용")}</p>` : ""}
    ${S.nameRow ? `<div class="sh-name"><span>${tt("학교")}</span><i></i><span>${tt("학년")}</span><i class="s"></i><span>${tt("반")}</span><i class="s"></i><span>${tt("번호")}</span><i class="s"></i><span>${tt("이름")}</span><i></i></div>` : ""}</header>
    ${S.items.map((it, i) => itemHTML(it, i, n, T, nos[i])).join("")}
    <footer class="sh-foot">McKay Math Atelier · ${esc(S.items[0].at)}</footer>
  </article>` : `<div class="sh-empty"><p>아직 담은 실험이 없어요.</p><p>실험 화면 위쪽의 <b>학습지에 담기</b> 단추를 눌러 보세요.</p><a class="btn primary" href="#/list">실험 목록으로</a></div>`}`;
  el.onclick = (e) => {
    const b = e.target.closest("[data-sh]"); if (!b || b.tagName === "INPUT") return;
    const act = b.dataset.sh, key = b.closest("[data-key]")?.dataset.key, ix = S.items.findIndex((x) => x.key === key);
    if (act === "stu" || act === "tea") S.teacher = act === "tea";
    else if (act === "up" && ix > 0) [S.items[ix - 1], S.items[ix]] = [S.items[ix], S.items[ix - 1]];
    else if (act === "down" && ix >= 0 && ix < S.items.length - 1) [S.items[ix + 1], S.items[ix]] = [S.items[ix], S.items[ix + 1]];
    else if (act === "del" && ix >= 0) S.items.splice(ix, 1);
    else if (act === "clear") { if (b.dataset.sure !== "1") { b.dataset.sure = "1"; b.textContent = "정말 비울까요? 한 번 더 누르세요"; return; } S.items = []; }
    else if (act === "pdf" || act === "docx" || act === "hwpx") { exportAs(act, b, el); return; }
    else if (act === "all" || act === "none") S.items.forEach((x) => { if (act === "all") delete x.skip; else x.skip = true; });
    else if (act === "upick-all" || act === "upick-none") { el.querySelectorAll("[data-unit-pick]").forEach((c) => (c.checked = act === "upick-all")); unitCount(); return; }
    else if (act === "unit") { const v = el.querySelector("#sh-unit-sel")?.value, ids = [...el.querySelectorAll("[data-unit-pick]:checked")].map((c) => c.value); if (!v || !OPT.addUnit) { msg("먼저 과정과 단원을 골라 주세요."); return; } if (!ids.length) { msg("담을 실험을 하나 이상 골라 주세요."); return; } msg("담는 중…"); Promise.resolve(OPT.addUnit(v, ids)).then((k) => { save(); render(el, notice); updateBadge(); msg(k > 0 ? `실험 ${k}개를 담았어요.` : "담지 못했어요. 브라우저 저장 공간이 가득 찼을 수 있어요. 학습지를 조금 비워 주세요."); }); return; }
    else if (act === "ebook") { makeEbook(b); return; }
    else if (act === "ai" && ix >= 0) { enrich(S.items[ix], b, el, notice); return; }
    else if (act === "print") { if (!np) { msg("인쇄할 실험을 하나 이상 골라 주세요."); return; } try { window.print(); } catch { notice("인쇄 창을 열지 못했어요. 다음 단계의 PDF 내려받기를 이용해 주세요."); } return; }
    else return;
    save(); render(el, notice); updateBadge();
  };
  // 단원을 고르면 그 단원의 실험을 체크 칸 목록으로 펼친다
  const unitCount = () => { const b = el.querySelector('[data-sh="unit"]'), k2 = el.querySelectorAll("[data-unit-pick]:checked").length; if (b) { b.textContent = `고른 실험 담기 (${k2}개)`; b.disabled = !k2; } };
  const unitList = (v) => {
    const box = el.querySelector("#sh-unit-list"), labs = v && OPT.unitLabs ? OPT.unitLabs(v) : [];
    box.hidden = !labs.length; if (!labs.length) { box.innerHTML = ""; return; }
    const have = new Set(S.items.map((x) => x.id));
    box.innerHTML = `<p class="sh-unit-head"><b>이 단원의 실험 ${labs.length}개</b> — 담을 것만 고르세요. <button type="button" class="btn" data-sh="upick-all">모두 고르기</button><button type="button" class="btn" data-sh="upick-none">모두 빼기</button></p><ul>${labs.map(([id, title, lesson]) => `<li><label><input type="checkbox" data-unit-pick value="${esc(id)}" ${have.has(id) ? "" : "checked"}><span class="sh-unit-l">${esc(lesson || "")}</span> ${esc(title)}${have.has(id) ? ` <small>(이미 담음)</small>` : ""}</label></li>`).join("")}</ul><button type="button" class="btn primary" data-sh="unit">고른 실험 담기</button>`;
    unitCount();
  };
  el.onchange = (e) => {
    if (e.target.matches('[data-sh="name"]')) { S.nameRow = e.target.checked; save(); render(el, notice); }
    else if (e.target.matches("#sh-unit-sel")) unitList(e.target.value);
    else if (e.target.matches("[data-unit-pick]")) unitCount();
    else if (e.target.matches("[data-sh-pick]")) { const it = S.items.find((x) => x.key === e.target.closest("[data-key]")?.dataset.key); if (it) { if (e.target.checked) delete it.skip; else it.skip = true; save(); const y = scrollY; render(el, notice); scrollTo(0, y); } }
  };
  el.oninput = (e) => { if (e.target.matches("[data-sh-title]")) { S.title = e.target.textContent.trim() || "수학 실험 학습지"; save(); } };
}
// ── 이 실험만 바로 인쇄 (모아 둔 학습지는 그대로 둔다) ──
// 인쇄할 때는 종이 폭에 맞춰 글자 크기 규칙이 바뀌므로, 종이 폭(188mm)과 같은 보이지 않는 창에서 높이를 잰다
async function measureA4(html) {
  const ifr = document.createElement("iframe");
  ifr.setAttribute("aria-hidden", "true"); ifr.tabIndex = -1;
  ifr.style.cssText = "position:absolute;left:-10000px;top:0;width:" + Math.round((188 * 96) / 25.4) + "px;height:1200px;border:0;visibility:hidden";
  document.body.append(ifr);
  try {
    const links = [...document.querySelectorAll('link[rel="stylesheet"]')].map((l) => `<link rel="stylesheet" href="${esc(l.href)}">`).join("");
    const H = document.documentElement, d = ifr.contentDocument;
    d.open(); d.write(`<!doctype html><html lang="${esc(H.lang)}" class="${esc(H.className)}" data-theme="light"><head><meta charset="utf-8">${links}</head><body class="${esc(document.body.className.replace("printing-one", ""))}" style="margin:0;background:#fff">${html}</body></html>`); d.close();
    await Promise.race([Promise.all([...d.querySelectorAll("link")].map((l) => new Promise((r) => { if (l.sheet) r(); else { l.onload = l.onerror = r; } }))), new Promise((r) => setTimeout(r, 2500))]);
    if (d.fonts) await Promise.race([d.fonts.ready, new Promise((r) => setTimeout(r, 1500))]);
    const box = d.getElementById("print-one"); box.style.display = "block";
    return box.querySelector(".sh-paper").getBoundingClientRect().height;
  } catch { return 0; } finally { ifr.remove(); }
}
export function printOne(lab, meta = {}, teacher = false) {
  const it = makeItem(lab, meta);
  document.getElementById("print-one")?.remove();
  const box = document.createElement("div");
  box.id = "print-one";
  box.innerHTML = `<article class="sh-paper${teacher ? " teacher" : ""}"><header class="sh-paper-head"><h1 class="sh-title">${esc(it.title)}</h1>${teacher ? `<p class="sh-badge">${tt("교사용")}</p>` : ""}<div class="sh-name"><span>${tt("학년")}</span><i class="s"></i><span>${tt("반")}</span><i class="s"></i><span>${tt("번호")}</span><i class="s"></i><span>${tt("이름")}</span><i></i></div></header>${itemHTML(it, 0, 1, teacher)}<footer class="sh-foot">McKay Math Atelier · ${esc(location.origin + location.pathname)}#/lab/${esc(it.id)} · ${esc(it.at)}</footer></article>`;
  document.body.append(box);
  document.body.classList.add("printing-one");
  const done = () => { document.body.classList.remove("printing-one"); box.remove(); window.removeEventListener("afterprint", done); };
  window.addEventListener("afterprint", done);
  const imgs = [...box.querySelectorAll("img")].map((im) => (im.complete ? 0 : new Promise((r) => { im.onload = im.onerror = r; })));
  return Promise.all(imgs).then(() => measureA4(box.outerHTML)).then((h) => {
    // A4(여백 11mm) 한 장 높이를 넘으면 그 비율만큼 줄인다 (60%까지)
    const maxH = ((297 - 22) * 96) / 25.4 - 8;
    box.style.zoom = h > maxH ? Math.max(0.6, maxH / h).toFixed(3) : "";
    try { window.print(); } catch { done(); return false; } return true; });
}

export function updateBadge() { document.querySelectorAll(".at-sheet-n").forEach((b) => (b.textContent = count() || "")); }

// ── 내려받기 ──
const msg = (t) => { const m = document.getElementById("sh-msg"); if (m) m.textContent = t; };
async function exportAs(kind, btn, el) {
  const S = load(), T = !!S.teacher, base = tt(S.title || "학습지").replace(/[\\/:*?"<>|]/g, " ").trim() + (T ? tt(" (교사용)") : "");
  const label = btn.textContent; btn.setAttribute("aria-busy", "true"); btn.textContent = "만드는 중…"; msg("파일을 만들고 있어요. 그림이 많으면 몇 초 걸려요.");
  try {
    const X = await import("./sheet-export.js");
    let blob, name;
    if (kind === "pdf") { blob = await X.toPdf(el.querySelector(".sh-paper")); name = base + ".pdf"; }
    else if (kind === "docx") { blob = await X.toDocx(T); name = base + ".docx"; }
    else { blob = await X.toHwpxZip(T, base); name = base + (isEN() ? " (Hangul).zip" : " (한글).zip"); }
    const r = await X.saveFile(name, blob);
    msg(r === "declined" ? "저장을 취소했어요." : `‘${name}’ 파일을 저장했어요.${kind === "hwpx" ? " 압축을 풀어 .hwpx 파일을 한글에서 여세요." : ""}`);
  } catch (e) { console.error(e); msg("파일을 만들지 못했어요: " + (e?.message || e) + " — 잠시 뒤 다시 눌러 주세요."); }
  finally { btn.removeAttribute("aria-busy"); btn.textContent = label; }
}

// ── Claude로 더 풍부하게 (누르는 사람의 Claude 사용량을 씀) ──
// 연결은 파일을 읽자마자 미리 시작한다(응답에 10초까지 걸릴 수 있음). 한 번 받은 결과는 다시 쓴다.
let samplePending = null;
function sampleFn() {
  const p = (samplePending ??= (async () => { try { if (!window.claude?.use) return null; return await Promise.race([window.claude.use("sample"), new Promise((r) => setTimeout(() => r(null), 12000))]); } catch { return null; } })());
  p.then((v) => { if (!v) samplePending = null; }); // 실패는 기억하지 않고 다음에 다시 연결
  return p;
}
sampleFn();
async function enrich(it, btn, el, notice) {
  btn.disabled = true; msg("Claude와 연결하는 중이에요…");
  const sample = await sampleFn();
  btn.disabled = false;
  if (!sample) { msg("Claude 연결은 claude.ai에서 사이트를 열었을 때만 쓸 수 있어요."); return; }
  btn.disabled = true; btn.textContent = "Claude가 쓰는 중…"; msg(`‘${it.title}’에 더할 문항을 Claude가 쓰고 있어요. 30초쯤 걸릴 수 있어요.`);
  const prompt = `당신은 한국 중·고등학교 수학 교사를 돕는 수업 설계자입니다. 아래 인터랙티브 수학 실험으로 학습지를 만들고 있습니다.
실험 제목: ${it.title}
과정·단원: ${[it.course, it.unit, it.lesson].join(" / ")}
학습 목표: ${it.desc}
핵심 식: ${it.formula}
관찰할 점: ${it.obs.join(" / ")}
조작 항목: ${it.controls.join(", ")}
담을 때의 측정값: ${it.metrics.map((m) => m.join(" = ")).join(" / ")}
이미 있는 질문: ${it.q}

다음 JSON 하나만 답하세요(설명 문장 없이).
{"questions":[{"q":"학생이 실험을 직접 조작해 확인할 수 있는 문항","answer":"간단한 답과 근거"}],"prompts":["수업에서 던질 핵심 발문"],"misconceptions":["예상 오개념 — 지도 방법"]}
조건: questions 3개(쉬움→어려움), prompts 3개, misconceptions 2개. 수식은 유니코드(², ³, √, π, ₙCₖ, ≤, ≠)로 쓰고 LaTeX·마크다운을 쓰지 마세요. 교과서 수준의 존댓말 문장으로 쓰세요.${isEN() ? "\n단, 학습지가 영어판이므로 모든 문장(문항·답·발문·오개념)을 자연스러운 영어로 쓰세요." : ""}`;
  try {
    const out = await sample.json(prompt, { modelTier: "default" });
    if (!out || !Array.isArray(out.questions)) throw { code: "bad_output" };
    it.extra = { questions: out.questions.slice(0, 5).map((x) => ({ q: String(x.q || ""), answer: String(x.answer || "") })), prompts: (out.prompts || []).slice(0, 5).map(String), misconceptions: (out.misconceptions || []).slice(0, 4).map(String) };
    save(); render(el, notice); msg(`‘${it.title}’에 Claude가 문항 ${it.extra.questions.length}개를 더했어요. 교사용으로 바꾸면 답과 발문이 보여요.`);
  } catch (e) {
    const t = { not_granted: "Claude 사용을 허락하지 않아서 문항을 만들지 못했어요.", rate_limited: "잠시 요청이 많아요. 조금 뒤에 다시 눌러 주세요.", cancelled: "멈췄어요.", invalid_json: "Claude의 답이 중간에 끊겼어요. 한 번 더 눌러 주세요.", upstream_error: "Claude 쪽이 잠시 바빠요. 조금 뒤에 다시 눌러 주세요." }[e?.code] || "Claude가 문항을 만들지 못했어요. 잠시 뒤 다시 눌러 주세요.";
    msg(t); btn.disabled = false; btn.textContent = "✦ Claude로 더 풍부하게";
  }
}

// ── 교사용 HTML e-book: 화면에 그린 교사용 학습지(수식은 이미 SVG)를 파일 하나로 ──
// 공개판(Vercel, <html class="public">)에서는 그 사이트 주소로, claude.ai 판에서는 아티팩트 주소로
const SITE = document.documentElement.classList.contains("public") ? location.origin + "/" : "https://claude.ai/artifact/V5oXxfvkiifzZkp95Aodt2";
function sheetCSS() {
  const out = [];
  for (const ss of document.styleSheets) { let rules; try { rules = ss.cssRules; } catch { continue; } for (const r of rules) if (r.selectorText && /\.sh-|\.mx/.test(r.selectorText) && !/sh-bar|sh-tools|sh-head|sh-dl|sh-unit|sh-msg|sh-empty/.test(r.selectorText)) out.push(r.cssText); }
  const mj = document.getElementById("MJX-SVG-styles")?.textContent || "";
  return mj + "\nmjx-assistive-mml { position: absolute !important; top: 0; left: 0; clip: rect(1px, 1px, 1px, 1px); padding: 1px 0 0 0 !important; border: 0 !important; display: block !important; width: auto !important; overflow: hidden !important; user-select: none; }\n" + out.join("\n");
}
function flow(it) {
  const steps = stepsOf(it);
  return `<div class="eb-flow"><div><b>${tt("도입")}</b><p>${M(it.q || it.desc)}</p><small>${tt("질문을 던지고 학생이 결과를 먼저 예측하게 합니다.")}</small></div><div><b>${tt("탐구")}</b><ol>${steps.slice(0, -1).map((s) => `<li>${s.html || esc(s)}</li>`).join("")}</ol></div><div><b>${tt("정리")}</b><ul>${it.obs.slice(0, 3).map((o) => `<li>${M(o)}</li>`).join("")}</ul></div></div>`;
}
export function ebookHTML() {
  const S0 = load(), S = { ...S0, items: S0.items.filter((x) => !x.skip) }, n = S.items.length, date = new Date().toISOString().slice(0, 10); // 인쇄에서 뺀 실험은 빼고
  const courses = [...new Set(S.items.map((it) => it.course).filter(Boolean))];
  const toc = S.items.map((it, i) => `<li><a href="#c${i + 1}" style="--c:${esc(it.color || "#c9a25f")}"><span>${i + 1}</span>${esc(it.title)}</a></li>`).join("");
  const chapters = S.items.map((it, i) => `<article class="sh-paper teacher eb-ch" id="c${i + 1}">${flow(it)}${itemHTML(it, i, n, true)}<p class="eb-open">${isEN() ? `Open the experiment: find ‘${esc(it.title)}’ in <a href="${SITE}" target="_blank" rel="noopener">McKay Math Atelier</a>.${it.time ? ` · Suggested time ${esc(it.time)}` : ""}` : `실험 열기: <a href="${SITE}" target="_blank" rel="noopener">McKay Math Atelier</a>에서 ‘${esc(it.title)}’를 찾아 여세요.${it.time ? ` · 예상 시간 ${esc(it.time)}` : ""}`}</p></article>`).join("");
  return `<!doctype html><html lang="${isEN() ? "en" : "ko"}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(tt(S.title))} — ${isEN() ? "Teacher's e-book" : "교사용 e-book"}</title><style>
:root { --at-brass: #c9a25f; --f-kr-serif: "Nanum Myeongjo", "Batang", serif; --f-mono: ui-monospace, Consolas, monospace; --at-muted: #6b6458; }
* { box-sizing: border-box; } html { scroll-behavior: smooth; }
body { margin: 0; background: #ece5d6; color: #1f2a2e; font-family: "Malgun Gothic", "Apple SD Gothic Neo", "Noto Sans KR", sans-serif; }
.eb-side { position: fixed; inset: 0 auto 0 0; width: 270px; overflow: auto; background: #2b2416; color: #f4ecd8; padding: 26px 18px; }
.eb-side h1 { font-family: var(--f-kr-serif); font-size: 20px; margin: 0 0 4px; } .eb-side p { margin: 0 0 18px; font-size: 12px; color: #cdbf9f; }
.eb-side ol { list-style: none; margin: 0; padding: 0; } .eb-side li a { display: flex; gap: 10px; align-items: baseline; padding: 8px 10px; border-radius: 8px; color: #f4ecd8; text-decoration: none; font-size: 13.5px; line-height: 1.4; border-left: 3px solid var(--c); margin-bottom: 4px; }
.eb-side li a:hover { background: rgba(255,255,255,.08); } .eb-side li span { font-family: var(--f-mono); font-size: 11px; color: #cdbf9f; }
.eb-main { margin-left: 270px; padding: 34px 28px 60px; }
.eb-cover { max-width: 860px; margin: 0 auto 34px; padding: 56px 48px; border-radius: 14px; background: linear-gradient(130deg, #f1e6cc, #f6efe0 50%, #e3eee9); box-shadow: 0 12px 40px rgba(60,48,20,.14); }
.eb-cover small { letter-spacing: .14em; color: #8a6d3b; font-weight: 700; } .eb-cover h2 { font-family: var(--f-kr-serif); font-size: 34px; margin: 10px 0 12px; } .eb-cover p { margin: 4px 0; color: #4b4436; }
.eb-flow { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin: 0 0 18px; } .eb-flow > div { background: #fff8ea; border: 1px solid #ecdcb8; border-radius: 12px; padding: 10px 12px; font-size: 13px; } .eb-flow b { color: #8a6d3b; } .eb-flow p, .eb-flow ol, .eb-flow ul { margin: 6px 0 0; padding-left: 18px; } .eb-flow p { padding: 0; } .eb-flow small { color: #8a7f6c; }
.eb-open { font-size: 12.5px; color: #6b6458; margin: 6px 0 0; } .eb-open a { color: #8a6d3b; }
.sh-tools { display: none !important; }
${sheetCSS()}
.sh-paper { margin-bottom: 34px; }
@media (max-width: 860px) { .eb-side { position: static; width: auto; } .eb-main { margin: 0; padding: 18px 10px; } .eb-flow { grid-template-columns: 1fr; } .eb-cover { padding: 32px 22px; } }
@media print { .eb-side { display: none; } .eb-main { margin: 0; padding: 0; } .eb-ch { break-before: page; } * { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
</style></head><body>
<nav class="eb-side" aria-label="${isEN() ? "Contents" : "차례"}"><h1>${esc(tt(S.title))}</h1><p>${isEN() ? `Teacher's e-book · ${n} experiments` : `교사용 e-book · 실험 ${n}개`}</p><ol><li><a href="#cover" style="--c:#c9a25f"><span>0</span>${isEN() ? "Cover" : "표지"}</a></li>${toc}</ol></nav>
<main class="eb-main"><section class="eb-cover" id="cover"><small>McKay Math Atelier · TEACHER'S E-BOOK</small><h2>${esc(tt(S.title))}</h2><p>${esc(courses.join(" · "))}</p>${isEN() ? `<p>${n} experiments · made ${date}</p><p style="margin-top:18px;font-size:13px">Each chapter runs: <b>lesson flow (opening · explore · wrap-up)</b> → learning goal and key formula → experiment figure → activity and record table → predictions with answers → observation answers → teaching point. Answers are in red.</p>` : `<p>실험 ${n}개 · 만든 날 ${date}</p><p style="margin-top:18px;font-size:13px">각 장은 <b>수업 흐름(도입·탐구·정리)</b> → 학습 목표와 핵심 식 → 실험 그림 → 활동·기록표 → 예측 문항과 답 → 관찰 정리 답 → 지도 포인트 순서입니다. 빨간 글씨가 답입니다.</p>`}</section>${chapters}</main></body></html>`;
}
async function makeEbook(btn) {
  const label = btn.textContent; btn.setAttribute("aria-busy", "true"); btn.textContent = "만드는 중…";
  try {
    const X = await import("./sheet-export.js"), S = load();
    const name = tt(S.title || "학습지").replace(/[\\/:*?"<>|]/g, " ").trim() + (isEN() ? " teacher's e-book.html" : " 교사용 e-book.html");
    const r = await X.saveFile(name, new Blob([ebookHTML()], { type: "text/html" }));
    msg(r === "declined" ? "저장을 취소했어요." : `‘${name}’을 저장했어요. 두 번 눌러 열면 인터넷 없이도 볼 수 있어요.`);
  } catch (e) { console.error(e); msg("e-book을 만들지 못했어요: " + (e?.message || e)); }
  finally { btn.removeAttribute("aria-busy"); btn.textContent = label; }
}
