// Strict arithmetic parser for classroom answers. No eval and no silent removal of letters.
export function parseAnswer(input){
 if(typeof input!=='string'&&typeof input!=='number')return NaN;
 let s=String(input).trim();if(!s||s.length>256)return NaN;s=s.replace(/(?:°|도|명|개|번|회|가지|원|cm[²³]?|mm[²³]?|km[²³]?|m[²³]?|㎝|㎜|㎞)$/,'').trim();
 s=s.replace(/−|–/g,'-').replace(/×|·/g,'*').replace(/÷/g,'/').replace(/\\(?:left|right)/g,'').replace(/\\(?:pi)/g,'π').replace(/\\sqrt\s*\{([^{}]+)\}/g,'sqrt($1)').replace(/\\sqrt/g,'sqrt').replace(/\\(?:d?frac)\s*\{([^{}]+)\}\s*\{([^{}]+)\}/g,'(($1)/($2))').replace(/[{}]/g,c=>c==='{'?'(':')').replace(/√/g,'sqrt').replace(/\s+/g,'');
 // Commas are accepted only as correctly grouped thousands separators.
 s=s.replace(/(?<![\d.,])\d{1,3}(?:,\d{3})+(?:\.\d+)?(?![\d.,])/g,v=>v.replaceAll(',',''));
 const tokens=[];let i=0;
 while(i<s.length){const m=s.slice(i).match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/);if(m){tokens.push({type:'n',value:Number(m[0])});i+=m[0].length;continue;}if(s.startsWith('sqrt',i)){tokens.push({type:'sqrt'});i+=4;continue;}if(s.startsWith('pi',i)){tokens.push({type:'n',value:Math.PI});i+=2;continue;}if(s[i]==='π'){tokens.push({type:'n',value:Math.PI});i++;continue;}if('+-*/^()%'.includes(s[i])){tokens.push({type:s[i++]});continue;}return NaN;}
 if(tokens.length>128)return NaN;let at=0,depth=0;
 const peek=()=>tokens[at]?.type;
 function primary(){if(++depth>32)throw Error('depth');let v;const t=tokens[at++];if(!t)throw Error('input');if(t.type==='n')v=t.value;else if(t.type==='('){v=expr();if(peek()!==')')throw Error('paren');at++;}else if(t.type==='sqrt'){v=Math.sqrt(unary());}else throw Error('token');if(peek()==='%'){at++;v/=100;}depth--;return v;}
 function power(){let v=primary();if(peek()==='^'){at++;v=v**unary();}return v;}
 function unary(){if(peek()==='+'){at++;return unary();}if(peek()==='-'){at++;return -unary();}return power();}
 function product(){let v=unary();while(true){const op=peek();if(op==='*'||op==='/'){at++;const q=unary();v=op==='*'?v*q:v/q;}else if(op==='n'||op==='('||op==='sqrt'){v*=unary();}else break;}return v;}
 function expr(){let v=product();while(peek()==='+'||peek()==='-'){const op=tokens[at++].type,q=product();v=op==='+'?v+q:v-q;}return v;}
 try{const v=expr();return at===tokens.length&&Number.isFinite(v)?v:NaN;}catch{return NaN;}
}
export function feedbackFingerprint(state){return JSON.stringify(Object.fromEntries(Object.entries(state).filter(([k])=>!k.startsWith('_'))));}
export function normalizePreset(spec,pre,initial){
 const state=structuredClone(initial);if(!pre||typeof pre!=='object'||Array.isArray(pre))return state;
 for(const k of Object.keys(state)){const value=pre[k],old=state[k];if(Array.isArray(old)&&Array.isArray(value)&&value.length===old.length&&value.every(Number.isFinite))state[k]=[...value];else if(typeof old==='number'&&typeof value==='number'&&Number.isFinite(value))state[k]=value;else if(typeof old==='boolean'&&typeof value==='boolean')state[k]=value;else if(typeof old==='string'&&typeof value==='string'&&value.length<=200)state[k]=value;}
 for(let pass=0;pass<3;pass++)for(const p of spec.params||[]){if(!p.key)continue;if(p.options&&!p.options.some(([v])=>String(v)===String(state[p.key])))state[p.key]=p.value;else if(p.min!=null&&typeof state[p.key]==='number'){const max=typeof p.max==='function'?p.max(state):p.max;if(!Number.isFinite(max))continue;state[p.key]=Math.max(p.min,Math.min(max,state[p.key]));const step=p.step??.1;if(step>=1&&Number.isInteger(step))state[p.key]=Math.max(p.min,Math.min(max,Math.round(state[p.key]/step)*step));}}
 for(const k of ['_yaw','_pitch'])if(k in state)state[k]=Math.max(k==='_pitch'?-85:-360,Math.min(k==='_pitch'?85:360,state[k]));return state;
}
export function reconcileParams(spec,state){
 for(let pass=0;pass<3;pass++)for(const p of spec.params||[]){if(!p.key||p.min==null||typeof state[p.key]!=='number')continue;const max=typeof p.max==='function'?p.max(state):p.max;if(!Number.isFinite(max))continue;let v=Number.isFinite(state[p.key])?state[p.key]:p.value;v=Math.max(p.min,Math.min(max,v));const step=p.step??.1;if(step>=1&&Number.isInteger(step))v=Math.max(p.min,Math.min(max,Math.round(v/step)*step));state[p.key]=v;}
 return state;
}
