// 영어판 실험 자료 모음 — 영어 모드를 켤 때만 불러온다
import * as P from "./en/index.js";
import TAGS from "./en/tags.js";
export const EN = Object.assign({}, ...Object.values(P));
// 그림·측정값 속 글자 사전: 일반 키는 문장 전체, "/정규식/"으로 시작하면 틀 규칙
// TX = 모든 화면에 쓰는 문장 사전, TXL[실험 id] = 그 실험 화면에서만 쓰는 사전과 틀 규칙(다른 실험과 겹치지 않게)
export const TX = {}, TXL = {};
for (const [id, e] of Object.entries(EN)) {
  const L = (TXL[id] = { ex: {}, pats: [] });
  for (const [k, v] of Object.entries(e.x || {})) {
    if (k.startsWith("/")) L.pats.push([new RegExp(k.slice(1, k.lastIndexOf("/"))), v]);
    else { L.ex[k] = v; if (!(k in TX)) TX[k] = v; }
  }
}
// 태그 사전: 실험 문장 사전에 없는 것만 더한다
for (const [k, v] of Object.entries(TAGS)) if (!(k in TX)) TX[k] = v;
