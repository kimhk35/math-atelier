const TAU=2*Math.PI;
const I='#263d5b',S='#6255c7',C='#c55337',G='#087d75';
const txt=(x,y,t,c=I,z=18,a='start')=>`<text x="${x}" y="${y}" fill="${c}" font-size="${z}" text-anchor="${a}" font-family="system-ui, sans-serif">${t}</text>`;
const line=(p,c=I,w=2,dash='',op=1)=>`<polyline points="${p.map(x=>x.join(',')).join(' ')}" fill="none" stroke="${c}" stroke-width="${w}" stroke-linejoin="round" stroke-dasharray="${dash}" opacity="${op}"/>`;
const dot=(p,c=G)=>`<circle cx="${p[0]}" cy="${p[1]}" r="6" fill="${c}" stroke="#faf7ef" stroke-width="2"/>`;
const curve=(fn,end,n=1200)=>Array.from({length:n+1},(_,i)=>fn(end*i/n));
export function extraValues(s,t=s.angle*Math.PI/180){const delta=s.delta??.2;return {x:Math.sin(t),y:s.a*Math.sin(s.b*t+s.phase*Math.PI/180),first:Math.sin(t),second:Math.sin((1+delta)*t),sum:Math.sin(t)+Math.sin((1+delta)*t),envelope:2*Math.abs(Math.cos(delta*t/2)),beatPeriod:360/delta};}
export function extraScene(s){
 const beat=s.view==='beats',t=s.angle*Math.PI/180,v=extraValues(s),end=beat?10*TAU:TAU;
 let out=`<rect width="960" height="640" rx="18" fill="#faf7ef"/><rect width="960" height="96" rx="18" fill="${I}"/>${txt(30,33,'MATH ATELIER / WAVE EXPLORATIONS','#cfdaeb',13)}${txt(30,72,beat?'비슷한 두 파동이 만드는 맥놀이':'서로 수직인 두 진동이 그리는 리사주 곡선','#fffaf2',24)}`;
 if(!beat){
  const P=(x,y)=>[595+90*x,350-90*y],Q=u=>{const z=extraValues(s,u);return P(z.x,z.y);};
  for(let x=-1;x<=1;x++)out+=line([P(x,-2.15),P(x,2.15)],I,1,'',.15)+txt(P(x,0)[0],567,String(x),I,15,'middle');
  for(let y=-2;y<=2;y++)out+=line([P(-1.3,y),P(1.3,y)],I,1,'',.15)+txt(385,P(0,y)[1]+5,String(y),I,15,'end');
  out+=line([P(-1.3,0),P(1.3,0)],I,1.5)+line([P(0,-2.15),P(0,2.15)],I,1.5);
  out+=line(curve(Q,end),G,2,'4 6',.22)+line(curve(Q,t),G,4)+dot(Q(t));
  const px=P(v.x,0),py=P(0,v.y);
  if(s.guides)out+=line([px,Q(t),py],G,1.5,'5 6',.7);
  out+=dot(px,S)+dot(py,C)+txt(796,355,'x',S)+txt(607,144,'y',C);
  for(const [y,col,fn,name] of [[230,S,u=>Math.sin(u),'가로 진동 x = sin θ'],[430,C,u=>extraValues(s,u).y,'세로 진동 y = A sin(Bθ + φ)']]){
   const R=u=>[40+270*u/TAU,y-42*fn(u)];out+=txt(35,y-108,name,col,16)+line([[40,y],[310,y]],I,1,'',.3)+line(curve(R,TAU),col,1.5,'4 5',.25)+line(curve(R,t),col,3)+dot(R(t),col);
  }
  out+=txt(390,125,`진동 비 1 : ${s.b}    위상 차이 ${s.phase}°`,G,18)+txt(35,607,'같은 각도에서 가로 좌표와 세로 좌표를 짝지으면 하나의 점이 됩니다.',I,17);
 }else{
  const P=(x,y)=>[65+835*x/end,350-85*y],draw=(fn,c,w=2,dash='',op=1,upto=end)=>line(curve(u=>P(u,fn(u)),upto),c,w,dash,op);
  for(let y=-2;y<=2;y++)out+=line([P(0,y),P(end,y)],I,1,'',.15)+txt(49,P(0,y)[1]+5,String(y),I,14,'end');
  for(let j=0;j<=10;j++)out+=line([P(j*TAU,-2.15),P(j*TAU,2.15)],I,1,'',.12)+txt(P(j*TAU,0)[0],558,j===0?'0':`${j*2}π`,I,14,'middle');
  out+=txt(35,132,`y = sin θ + sin(${(1+(s.delta??.2)).toFixed(2)}θ)`,G,23)+txt(35,162,'두 파동의 진폭은 각각 1입니다. 가로축은 θ이며 시간 단위가 아닙니다.',I,16);
  out+=draw(Math.sin,S,1.2,'',.25)+draw(u=>extraValues(s,u).second,C,1.2,'',.25);
  out+=draw(u=>extraValues(s,u).envelope,C,2,'6 6',.8)+draw(u=>-extraValues(s,u).envelope,C,2,'6 6',.8);
  out+=draw(u=>extraValues(s,u).sum,G,1.8,'',.18)+draw(u=>extraValues(s,u).sum,G,3,'',1,t)+dot(P(t,v.sum));
  if(s.guides)out+=line([P(t,-2.15),P(t,2.15)],I,1.5,'5 6',.65);
  out+=txt(35,594,`주황 점선: 진폭 포락선 ±2|cos(Δθ/2)|    /    세기 반복 간격 ${(360/(s.delta??.2)).toFixed(0)}°`,I,17)+txt(35,623,'Δ가 작을수록 커졌다 작아지는 변화가 느립니다. 초록색은 두 파동의 합입니다.',I,16);
 }
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 640" role="img" aria-label="${beat?'맥놀이':'리사주 곡선'} 탐구">${out}</svg>`;
}
