// 23차 묶음 7 — 수학실험실 (곡선 · 프랙털 · 그래프와 알고리즘 · 세상을 재는 수학)
import { fmt, clamp } from "./hs-core.js";

const LB = 9;
const O = (...xs) => xs.map((x, i) => [String.fromCharCode(97 + i), x]);

// ── 쾨니히스베르크 ──
const KN = { A: [-1.2, 0], B: [0.4, 2.6], C: [0.4, -2.6], D: [3.6, 0] };
const KE = [["A", "B", -0.55], ["A", "B", 0.55], ["A", "C", 0.55], ["A", "C", -0.55], ["A", "D", 0], ["B", "D", 0], ["C", "D", 0], ["B", "C", 0]];
function euler(edges) {
  const deg = {}; Object.keys(KN).forEach((k) => (deg[k] = 0)); edges.forEach(([a, b]) => { deg[a]++; deg[b]++; });
  const odd = Object.keys(deg).filter((k) => deg[k] % 2), used = edges.map(() => false);
  if (!edges.length || (odd.length !== 0 && odd.length !== 2)) return { deg, odd, path: null };
  const start = odd[0] || edges[0][0], stack = [[start, -1]], path = [];
  while (stack.length) { const [v] = stack[stack.length - 1]; const i = edges.findIndex((e, j) => !used[j] && (e[0] === v || e[1] === v)); if (i < 0) path.push(stack.pop()); else { used[i] = true; stack.push([edges[i][0] === v ? edges[i][1] : edges[i][0], i]); } }
  return { deg, odd, path: used.every(Boolean) ? path.reverse() : null };
}
const bez = (P, Q, k) => { const M = [(P[0] + Q[0]) / 2, (P[1] + Q[1]) / 2], d = [Q[1] - P[1], P[0] - Q[0]], L = Math.hypot(...d) || 1, C = [M[0] + (d[0] / L) * k * 2, M[1] + (d[1] / L) * k * 2]; return (t) => [(1 - t) ** 2 * P[0] + 2 * (1 - t) * t * C[0] + t * t * Q[0], (1 - t) ** 2 * P[1] + 2 * (1 - t) * t * C[1] + t * t * Q[1]]; };

// ── 4색 지도 ──
const MAP = ["AABBBCCD", "AABEECDD", "FFGEEHHD", "FGGGIHHJ", "KKGLIIJJ", "KKLLLIJJ"];
const REG = [...new Set(MAP.join(""))].sort();
const ADJ = (() => { const s = new Set(); for (let r = 0; r < 6; r++) for (let c = 0; c < 8; c++) { const a = MAP[r][c]; [[0, 1], [1, 0]].forEach(([dr, dc]) => { const b = MAP[r + dr]?.[c + dc]; if (b && b !== a) s.add([a, b].sort().join("")); }); } return [...s].map((x) => x.split("")); })();
function colorMap(k) { const col = {}; const nb = (x) => ADJ.filter((e) => e.includes(x)).map((e) => (e[0] === x ? e[1] : e[0])); const go = (i) => { if (i === REG.length) return true; const r = REG[i]; for (let c = 0; c < k; c++) if (nb(r).every((n) => col[n] !== c)) { col[r] = c; if (go(i + 1)) return true; } delete col[r]; return false; }; const ok = go(0); return { ok, col }; }
const MCOL = ["a", "b", "c", "d"];

// ── 최단강하선 ──
const CURV = {
  line: { n: "직선", c: "muted", p: (u) => [Math.PI * u, -2 * u] },
  cyc: { n: "사이클로이드", c: "a", p: (u) => { const t = Math.PI * u; return [t - Math.sin(t), -(1 - Math.cos(t))]; } },
  sine: { n: "완만한 곡선", c: "b", p: (u) => [Math.PI * u, -2 * Math.sin((Math.PI * u) / 2)] },
};
function timeTable(K) { const N = 1200, T = [0], P = [K.p(0)]; for (let i = 1; i <= N; i++) { const q = K.p(i / N), p = P[i - 1], ds = Math.hypot(q[0] - p[0], q[1] - p[1]), depth = -(p[1] + q[1]) / 2, v = Math.sqrt(2 * 9.8 * Math.max(depth, 1e-9)); T.push(T[i - 1] + ds / v); P.push(q); } return { T, P }; }
const TT = {}; const tbl = (k) => (TT[k] ??= timeTable(CURV[k]));
const posAt = (k, t) => { const { T, P } = tbl(k); if (t >= T[T.length - 1]) return P[P.length - 1]; let i = T.findIndex((x) => x > t); i = Math.max(1, i); const f = (t - T[i - 1]) / (T[i] - T[i - 1]); return [P[i - 1][0] + (P[i][0] - P[i - 1][0]) * f, P[i - 1][1] + (P[i][1] - P[i - 1][1]) * f]; };

// ── 푸리에 ──
const WAVE = {
  sq: { n: "네모 파동", term: (k, x) => ((4 / Math.PI) * Math.sin((2 * k - 1) * x)) / (2 * k - 1), f: (x) => Math.sign(Math.sin(x)) },
  saw: { n: "톱니 파동", term: (k, x) => ((2 / Math.PI) * (k % 2 ? 1 : -1) * Math.sin(k * x)) / k, f: (x) => { const y = ((x + Math.PI) % (2 * Math.PI) + 2 * Math.PI) % (2 * Math.PI) - Math.PI; return y / Math.PI; } },
  tri: { n: "세모 파동", term: (k, x) => ((8 / (Math.PI * Math.PI)) * (k % 2 ? 1 : -1) * Math.sin((2 * k - 1) * x)) / (2 * k - 1) ** 2, f: (x) => (2 / Math.PI) * Math.asin(Math.sin(x)) },
};

// ── 망델브로 ──
const MV = { all: { n: "전체", x: [-2.4, 1.1], y: [-1.22, 1.22] }, sea: { n: "해마 골짜기", x: [-0.86, -0.66], y: [0.03, 0.17] }, tip: { n: "꼬리 끝의 작은 복제", x: [-1.8, -1.72], y: [-0.028, 0.028] } };
const MCACHE = {};
function mandelURL(key, xr, yr, W = 360, H = 250, it = 80) {
  if (MCACHE[key]) return MCACHE[key];
  if (typeof document === "undefined") return "";
  const cv = document.createElement("canvas"); cv.width = W; cv.height = H; const ctx = cv.getContext("2d"), im = ctx.createImageData(W, H);
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const cr = xr[0] + ((xr[1] - xr[0]) * (i + 0.5)) / W, ci = yr[1] - ((yr[1] - yr[0]) * (j + 0.5)) / H; let x = 0, y = 0, n = 0;
    while (n < it && x * x + y * y < 4) { const t = x * x - y * y + cr; y = 2 * x * y + ci; x = t; n++; }
    const o = (j * W + i) * 4, v = n === it ? 0 : Math.sqrt(n / it);
    im.data[o] = n === it ? 18 : 40 + 200 * v; im.data[o + 1] = n === it ? 40 : 70 + 150 * v; im.data[o + 2] = n === it ? 80 : 120 + 135 * (1 - v * 0.3); im.data[o + 3] = 255;
  }
  ctx.putImageData(im, 0, 0);
  return (MCACHE[key] = cv.toDataURL("image/png"));
}

// ── 지도 투영 ──
const PROJ = {
  merc: { n: "메르카토르", y: (p) => Math.log(Math.tan(Math.PI / 4 + p / 2)), sx: (p) => 1 / Math.cos(p), sy: (p) => 1 / Math.cos(p) },
  area: { n: "등적 원통 (람베르트)", y: (p) => Math.sin(p), sx: (p) => 1 / Math.cos(p), sy: (p) => Math.cos(p) },
  eq: { n: "정거 원통", y: (p) => p, sx: (p) => 1 / Math.cos(p), sy: () => 1 },
};
const D2R = Math.PI / 180;

export default [
  // ───────── 주제 5 그래프와 알고리즘 ─────────
  {
    id: "lab-konigsberg", grade: LB, unit: 5, lesson: "주제 5", title: "쾨니히스베르크의 다리 — 한붓그리기가 되는 조건", type: "조작", time: "12분",
    tags: ["그래프", "오일러 경로", "한붓그리기"], links: ["lab-four-color"],
    desc: "네 땅(점)과 일곱 다리(선)로 이루어진 쾨니히스베르크에서 모든 다리를 한 번씩만 건너는 산책이 가능한지 알아봅니다. 다리를 더하거나 빼며 각 땅에 이어진 다리 수(차수)가 홀수인 땅의 개수가 0개 또는 2개일 때만 한붓그리기가 됨을 확인합니다.",
    obs: ["한 땅을 지나갈 때마다 들어오는 다리와 나가는 다리가 한 쌍씩 쓰입니다.", "그래서 출발점과 도착점이 아닌 땅의 차수는 짝수여야 합니다.", "차수가 홀수인 점이 0개이면 제자리로 돌아오고, 2개이면 그 두 점이 출발점과 도착점입니다."],
    q: "다리 하나만 새로 놓아 한붓그리기가 되게 하려면 어느 두 땅을 이어야 할까요?",
    formula: "한붓그리기 가능 ⇔ 연결되어 있고, 차수가 홀수인 점이 0개 또는 2개",
    en: { title: "The Bridges of Königsberg", desc: "When can you cross every bridge exactly once?" },
    view: { x: [-3.6, 5.8], y: [-3.6, 3.6] },
    params: [
      ...KE.map((e, i) => ({ key: "e" + i, label: `다리 ${i + 1} (${e[0]}–${e[1]})`, type: "check", value: i < 7 })),
      { key: "st", label: "산책 따라가기", min: 0, max: 8, step: 1, value: 0 },
    ],
    anim: { key: "st", min: 0, max: 8, speed: 1.2, label: "산책하기" },
    edges(s) { return KE.map((e, i) => [e, i]).filter(([, i]) => s["e" + i]); },
    draw(s, g) {
      const E = this.edges(s), R = euler(E.map(([e]) => e)), walked = new Set();
      if (R.path) R.path.slice(1, 1 + s.st).forEach(([, j]) => walked.add(E[j][1]));
      g.poly([[-3.6, 0.9], [2.7, 0.9], [2.7, -0.9], [-3.6, -0.9]], { fill: "b", fo: 0.14, stroke: false }); g.text([-3.2, 0.55], "강", { anchor: "start", size: 12, color: "b", bold: true });
      E.forEach(([e, i]) => { const f = bez(KN[e[0]], KN[e[1]], e[2]); const pts = []; for (let t = 0; t <= 20; t++) pts.push(f(t / 20)); g.path(pts, { color: walked.has(i) ? "a" : "ink", w: walked.has(i) ? 5 : 2.6 }); const m = f(0.5); g.text(m, String(i + 1), { dy: -6, size: 11, color: "muted", bold: true }); });
      Object.entries(KN).forEach(([k, p]) => { const odd = R.deg[k] % 2; g.circle(p, 0.42, { fill: odd ? "e" : "c", fo: 0.6, color: odd ? "e" : "c", w: 2 }); g.text(p, k, { dy: 5, bold: true, size: 15 }); g.text(p, `차수 ${R.deg[k]}`, { dy: 30, size: 11, color: odd ? "e" : "c", bold: true }); });
      if (R.path && s.st) { const v = R.path[Math.min(s.st, R.path.length - 1)][0]; g.point(KN[v], "", { color: "a", r: 8 }); }
    },
    metrics(s) { const E = this.edges(s), R = euler(E.map(([e]) => e)); return [["차수가 홀수인 땅", R.odd.length ? `${R.odd.join(", ")} (${R.odd.length}개)` : "없음"], ["한붓그리기", R.path ? (R.odd.length ? `가능 — ${R.path.map(([v]) => v).join(" → ")}` : `가능 (제자리로) — ${R.path.map(([v]) => v).join(" → ")}`) : "불가능", "key"]]; },
    predict: [
      { q: "원래의 일곱 다리를 모두 한 번씩 건너는 산책이 가능할까요?", options: O("불가능하다", "가능하다"), set: (s) => { KE.forEach((_, i) => (s["e" + i] = i < 7)); s.st = 0; }, answer: () => "a", why: "네 땅의 차수가 5, 3, 3, 3으로 모두 홀수입니다. 홀수인 점이 4개라 불가능합니다." },
      { q: "B와 C를 잇는 여덟째 다리를 놓으면 차수가 홀수인 땅은 몇 개가 될까요?", set: (s) => { KE.forEach((_, i) => (s["e" + i] = i < 7)); s.st = 0; }, reveal: (s) => (s.e7 = true), answer: () => 2, why: "B와 C의 차수가 4로 짝수가 되고 A, D만 홀수로 남아 A에서 D로 가는 한붓그리기가 됩니다." },
    ],
  },
  {
    id: "lab-four-color", grade: LB, unit: 5, lesson: "주제 5", title: "네 가지 색으로 지도 칠하기", type: "조작", time: "10분",
    tags: ["4색 정리", "그래프 색칠", "인접"], links: ["lab-konigsberg"],
    desc: "이웃한 나라끼리 다른 색이 되도록 지도를 칠합니다. 색의 수를 2, 3, 4가지로 바꾸어 컴퓨터가 차례로 시도하게 하면, 이 지도는 몇 가지 색부터 칠할 수 있는지 알 수 있습니다. 어떤 평면 지도도 4가지 색이면 충분하다는 '4색 정리'를 체험합니다.",
    obs: ["한 점에서만 맞닿은 나라는 이웃으로 보지 않습니다.", "세 나라가 서로 모두 이웃하면 적어도 3가지 색이 필요합니다.", "4색 정리는 1976년 컴퓨터의 도움으로 처음 증명되었습니다."],
    q: "5가지 색이 반드시 필요한 지도를 그릴 수 있을까요? 그려 보려고 하면 어떤 일이 생기나요?",
    formula: "평면의 모든 지도는 4가지 색으로 칠할 수 있다 (4색 정리)",
    en: { title: "Four-Coloring a Map", desc: "Neighbors must get different colors." },
    view: { x: [-0.4, 12.6], y: [-0.6, 8.4] },
    params: [{ key: "k", label: "쓸 수 있는 색의 수", type: "seg", value: 4, options: [[2, "2가지"], [3, "3가지"], [4, "4가지"]] }],
    draw(s, g) {
      const R = colorMap(s.k), u = 1.25, x0 = 0.4, y0 = 7.8;
      for (let r = 0; r < 6; r++) for (let c = 0; c < 8; c++) { const k = MAP[r][c], ci = R.col[k]; g.poly([[x0 + c * u, y0 - r * u], [x0 + (c + 1) * u, y0 - r * u], [x0 + (c + 1) * u, y0 - (r + 1) * u], [x0 + c * u, y0 - (r + 1) * u]], { fill: ci == null ? "paper" : MCOL[ci], fo: ci == null ? 1 : 0.55, stroke: false }); }
      for (let r = 0; r < 6; r++) for (let c = 0; c < 8; c++) { const a = MAP[r][c]; if (MAP[r][c + 1] && MAP[r][c + 1] !== a) g.seg([x0 + (c + 1) * u, y0 - r * u], [x0 + (c + 1) * u, y0 - (r + 1) * u], { color: "ink", w: 2.6 }); if (MAP[r + 1] && MAP[r + 1][c] !== a) g.seg([x0 + c * u, y0 - (r + 1) * u], [x0 + (c + 1) * u, y0 - (r + 1) * u], { color: "ink", w: 2.6 }); }
      g.poly([[x0, y0], [x0 + 8 * u, y0], [x0 + 8 * u, y0 - 6 * u], [x0, y0 - 6 * u]], { color: "ink", w: 3 });
      REG.forEach((k) => { let sr = 0, sc = 0, n = 0; for (let r = 0; r < 6; r++) for (let c = 0; c < 8; c++) if (MAP[r][c] === k) { sr += r; sc += c; n++; } g.text([x0 + (sc / n + 0.5) * u, y0 - (sr / n + 0.5) * u], k, { dy: 5, bold: true, size: 14 }); });
      g.text([11, 6.8], R.ok ? `${s.k}가지 색으로 성공!` : `${s.k}가지 색으로는 실패`, { bold: true, size: 15, color: R.ok ? "c" : "e" });
    },
    metrics(s) { const R = colorMap(s.k); let need = 1; while (!colorMap(need).ok) need++; return [["나라 수", `${REG.length}개`], ["이웃한 쌍", `${ADJ.length}쌍`], [`${s.k}가지 색`, R.ok ? "칠할 수 있음" : "칠할 수 없음", "key"], ["이 지도에 필요한 최소 색 수", `${need}가지`]]; },
    predict: [
      { q: "이 지도는 최소 몇 가지 색이 있어야 칠할 수 있을까요?", set: (s) => (s.k = 2), reveal: (s) => (s.k = 4), answer: () => { let n = 1; while (!colorMap(n).ok) n++; return n; }, why: "3가지 색으로는 서로 이웃한 나라들 사이에서 막히는 곳이 생깁니다. 4색 정리에 따라 4가지면 늘 충분합니다." },
      { q: "어떤 평면 지도라도 칠할 수 있는 색의 수는?", options: O("4가지면 충분하다", "5가지가 필요할 때가 있다", "3가지면 충분하다"), answer: () => "a", why: "4색 정리입니다. 3가지로는 부족한 지도가 있습니다." },
    ],
  },
  {
    id: "lab-cellular", grade: LB, unit: 5, lesson: "주제 5", title: "규칙 하나로 자라는 무늬 — 1차원 세포 자동자", type: "조작", time: "10분",
    tags: ["세포 자동자", "규칙", "알고리즘"], links: ["lab-sierpinski"],
    desc: "한 줄의 칸이 위의 세 칸(왼쪽·자신·오른쪽)의 상태만 보고 다음 줄의 색을 정합니다. 가능한 규칙은 2⁸ = 256가지이고, 규칙 번호를 바꾸면 시에르핀스키 삼각형(90번), 예측하기 어려운 무늬(30번), 복잡한 구조(110번)가 저절로 자라납니다.",
    obs: ["위 세 칸의 경우는 2³ = 8가지이고, 각 경우의 결과(0 또는 1)를 이어 쓰면 규칙 번호의 이진수가 됩니다.", "90번 규칙은 파스칼 삼각형을 2로 나눈 나머지와 같은 시에르핀스키 무늬를 만듭니다.", "30번 규칙의 가운데 줄은 무작위 수처럼 보일 만큼 불규칙합니다."],
    q: "규칙 90에서 생기는 무늬가 파스칼 삼각형의 홀수·짝수와 같은 까닭을 생각해 봅시다.",
    formula: "다음 칸 = 규칙 번호의 (4·왼쪽 + 2·자신 + 1·오른쪽)번째 비트",
    en: { title: "Elementary Cellular Automata", desc: "256 rules, one row at a time." },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [
      { key: "rule", label: "규칙 번호", min: 0, max: 255, step: 1, value: 90 },
      { key: "rows", label: "자란 줄 수", min: 1, max: 32, step: 1, value: 32 },
    ],
    buttons: [["r30", "30번"], ["r90", "90번"], ["r110", "110번"], ["r184", "184번"]],
    onDo(a, s) { s.rule = +a.slice(1); },
    anim: { key: "rows", min: 1, max: 32, speed: 8, label: "자라게 하기" },
    grid(s) { const W = 49, G = [Array.from({ length: W }, (_, i) => (i === 24 ? 1 : 0))]; for (let r = 1; r < 32; r++) { const p = G[r - 1]; G.push(p.map((_, i) => (s.rule >> ((p[i - 1] || 0) * 4 + p[i] * 2 + (p[i + 1] || 0))) & 1)); } return G; },
    draw(s, g) {
      const G = this.grid(s), u = 0.3, x0 = 0.3, y0 = 10.6;
      for (let r = 0; r < s.rows; r++) { let d = ""; G[r].forEach((v, i) => { if (v) { const [X, Y] = g.X([x0 + i * u, y0 - r * u]); d += `M${g.n(X)},${g.n(Y)}h${g.n(u * g.s)}v${g.n(u * g.s)}h${g.n(-u * g.s)}z`; } }); if (d) g.L.fill.push(`<path d="${d}" fill="var(--pl-b)"/>`); }
      g.poly([[x0, y0], [x0 + 49 * u, y0], [x0 + 49 * u, y0 - 32 * u], [x0, y0 - 32 * u]], { color: "grid", w: 1 });
      for (let k = 7; k >= 0; k--) { const x = 1 + (7 - k) * 1.85, bits = [(k >> 2) & 1, (k >> 1) & 1, k & 1], out = (s.rule >> k) & 1; bits.forEach((b, j) => g.poly([[x + j * 0.45, 0.95], [x + (j + 1) * 0.45, 0.95], [x + (j + 1) * 0.45, 0.5], [x + j * 0.45, 0.5]], { fill: b ? "ink" : "paper", fo: b ? 0.85 : 1, color: "muted", w: 0.8 })); g.poly([[x + 0.45, 0.45], [x + 0.9, 0.45], [x + 0.9, 0], [x + 0.45, 0]], { fill: out ? "b" : "paper", fo: out ? 1 : 1, color: "muted", w: 0.8 }); }
    },
    metrics(s) { return [["규칙 번호", String(s.rule), "key"], ["이진수 (111 → 000 순서)", s.rule.toString(2).padStart(8, "0")], ["색칠된 칸", String(this.grid(s).slice(0, s.rows).flat().reduce((a, b) => a + b, 0))]]; },
    predict: [
      { q: "규칙은 모두 몇 가지일까요?", answer: () => 256, why: "위 세 칸의 경우가 8가지이고 각각 0 또는 1을 정하므로 2⁸ = 256가지입니다." },
      { q: "규칙 90의 무늬는 무엇과 닮았을까요?", options: O("시에르핀스키 삼각형", "체스판", "한 줄 직선"), set: (s) => Object.assign(s, { rule: 30, rows: 32 }), reveal: (s) => (s.rule = 90), answer: () => "a", why: "다음 칸 = 왼쪽 XOR 오른쪽이라 파스칼 삼각형의 홀짝 무늬, 곧 시에르핀스키 삼각형이 됩니다." },
    ],
  },

  // ───────── 주제 6 세상을 재는 수학 ─────────
  {
    id: "lab-brachistochrone", grade: LB, unit: 6, lesson: "주제 6", title: "최단강하선 — 가장 빠른 미끄럼틀은 직선이 아니다", type: "조작", time: "12분",
    tags: ["사이클로이드", "최단강하선", "속력"], links: ["lab-cycloid", "calc2-cycloid"],
    desc: "높이가 같은 출발점에서 공 세 개를 직선, 완만한 곡선, 사이클로이드 미끄럼틀로 동시에 굴립니다. 거리는 직선이 가장 짧지만, 처음에 가파르게 떨어져 속력을 빨리 얻는 사이클로이드가 가장 먼저 도착함을 시뮬레이션으로 확인합니다. (마찰은 없다고 가정합니다.)",
    obs: ["공의 속력은 떨어진 높이 h로 정해집니다: v = √(2gh).", "처음에 많이 떨어질수록 빨리 속력을 얻어 남은 길을 빠르게 갑니다.", "베르누이 형제와 뉴턴 등이 1697년에 이 곡선이 사이클로이드임을 밝혔습니다."],
    q: "사이클로이드 미끄럼틀에서는 어느 높이에서 출발해도 바닥에 닿는 시간이 같다고 합니다. 어떻게 확인해 볼 수 있을까요?",
    formula: "걸리는 시간 T = ∫ ds / √(2gh)",
    en: { title: "The Brachistochrone", desc: "The fastest slide is not a straight line." },
    view: { x: [-0.4, 3.6], y: [-2.5, 0.6] },
    params: [{ key: "t", label: "시간 (초)", min: 0, max: 1.2, step: 0.005, value: 0.6 }],
    anim: { key: "t", min: 0, max: 1.2, speed: 0.25, label: "동시에 출발", loop: "wrap" },
    draw(s, g) {
      g.seg([-0.3, 0], [3.5, 0], { color: "grid", w: 1 });
      Object.entries(CURV).forEach(([k, K]) => { g.param(K.p, 0, 1, { color: K.c, w: 3, n: 200 }); const p = posAt(k, s.t); g.circle(p, 0.07, { fill: K.c, fo: 1, color: "ink", w: 1.2 }); });
      g.point([0, 0], "A", { color: "ink", r: 4 }).point([Math.PI, -2], "B", { color: "ink", r: 4, dy: 18 });
      Object.entries(CURV).forEach(([k, K], i) => { const T = tbl(k).T.at(-1); g.text([0.1, -1.3 - i * 0.32], `${K.n}: ${fmt(T, 3)}초 ${s.t >= T ? "✓ 도착" : ""}`, { anchor: "start", bold: true, color: K.c, size: 14 }); });
    },
    metrics(s) { const R = Object.keys(CURV).map((k) => [CURV[k].n, tbl(k).T.at(-1)]).sort((a, b) => a[1] - b[1]); return [["가장 빠른 길", R[0][0], "key"], ["도착 시간", R.map(([n, t]) => `${n} ${fmt(t, 3)}초`).join(" · ")], ["길이 (직선)", `${fmt(Math.hypot(Math.PI, 2), 3)} m`]]; },
    predict: [
      { q: "세 미끄럼틀 가운데 가장 먼저 도착하는 것은?", options: O("사이클로이드", "직선", "완만한 곡선"), set: (s) => (s.t = 0), reveal: (s) => (s.t = 1.2), answer: () => "a", why: "처음에 거의 수직으로 떨어져 속력을 빨리 얻기 때문에, 길이는 길어도 시간이 가장 짧습니다." },
      { q: "길이가 가장 짧은 미끄럼틀은?", options: O("직선", "사이클로이드", "완만한 곡선"), answer: () => "a", why: "두 점을 잇는 가장 짧은 선은 직선이지만, 가장 빠른 선은 아닙니다." },
    ],
  },
  {
    id: "lab-map-projection", grade: LB, unit: 6, lesson: "주제 6", title: "지도 투영 — 그린란드는 왜 아프리카만큼 커 보일까", type: "조작", time: "12분",
    tags: ["지도 투영", "메르카토르", "넓이"], links: ["lab-brachistochrone"],
    desc: "둥근 지구를 평평한 종이에 옮기면 어딘가가 반드시 늘어납니다. 지구 위에서 크기가 같은 원들을 여러 위도에 놓고, 메르카토르·등적 원통·정거 원통 도법으로 옮겼을 때 모양과 넓이가 어떻게 달라지는지 비교합니다.",
    obs: ["메르카토르 도법은 모양(각)은 지키지만 위도 φ에서 넓이가 1/cos²φ배로 커집니다.", "위도 60°에서는 넓이가 4배, 72°(그린란드 근처)에서는 약 10배로 커집니다.", "등적 도법은 넓이를 지키는 대신 높은 위도에서 모양이 납작해집니다."],
    q: "모양과 넓이를 동시에 정확하게 지키는 평면 지도는 왜 만들 수 없을까요?",
    formula: "메르카토르: y = ln tan(π/4 + φ/2), 늘어나는 비율 = 1/cos φ",
    en: { title: "Map Projections", desc: "Why Greenland looks as big as Africa." },
    view: { x: [-3.6, 3.6], y: [-2.5, 2.5] },
    params: [
      { key: "pr", label: "도법", type: "seg", value: "merc", options: Object.entries(PROJ).map(([k, v]) => [k, v.n]) },
      { key: "lat", label: "움직이는 원의 위도 (°)", min: 0, max: 80, step: 1, value: 72 },
    ],
    anim: { key: "lat", min: 0, max: 80, speed: 12, loop: "bounce", label: "위로 옮기기" },
    draw(s, g) {
      const P = PROJ[s.pr], k = 1.05, Y = (deg) => k * P.y(deg * D2R), lim = 80;
      for (let d = -lim; d <= lim; d += 20) { const y = Y(d); if (Math.abs(y) < 2.5) { g.seg([-Math.PI * k, y], [Math.PI * k, y], { color: "grid", w: 1 }); g.text([-Math.PI * k, y], `${Math.abs(d)}°${d > 0 ? "N" : d < 0 ? "S" : ""}`, { dx: -4, anchor: "end", dy: 4, size: 10, color: "muted" }); } }
      for (let L = -180; L <= 180; L += 30) { const x = k * L * D2R; g.seg([x, Math.max(Y(-lim), -2.4)], [x, Math.min(Y(lim), 2.4)], { color: "grid", w: 1 }); }
      const blob = (lon, latD, col) => { const r = 9 * D2R, pts = []; for (let i = 0; i <= 48; i++) { const a = (2 * Math.PI * i) / 48, la = latD * D2R + r * Math.sin(a), lo = lon * D2R + (r * Math.cos(a)) / Math.cos(latD * D2R); pts.push([k * lo, k * P.y(clamp(la, -1.5, 1.5))]); } g.poly(pts, { fill: col, fo: 0.4, color: col, w: 1.6 }); };
      [0, 30, 60].forEach((d, i) => blob(-120 + i * 60, d, "b"));
      blob(110, s.lat, "a");
      g.text([k * 110 * D2R, Y(s.lat)], "같은 크기의 원", { dy: -4, size: 11, bold: true, color: "a" });
      g.text([0, 2.35], P.n, { bold: true, size: 14 });
    },
    metrics(s) { const P = PROJ[s.pr], p = s.lat * D2R, ax = P.sx(p), ay = s.pr === "merc" ? P.sx(p) : P.sy(p); return [["가로 늘어남", `${fmt(ax, 2)}배`], ["세로 늘어남", `${fmt(ay, 2)}배`], ["넓이 (지구 위의 실제 대비)", `${fmt(ax * ay, 2)}배`, "key"]]; },
    predict: [
      { q: "메르카토르 지도에서 위도 60°의 땅은 실제보다 넓이가 몇 배로 보일까요?", set: (s) => Object.assign(s, { pr: "merc", lat: 0 }), reveal: (s) => (s.lat = 60), answer: () => 4, tol: 0.05, why: "가로·세로가 모두 1/cos 60° = 2배라 넓이는 4배입니다." },
      { q: "넓이를 실제와 같은 비율로 지키는 도법은?", options: O("등적 원통 도법", "메르카토르 도법", "정거 원통 도법"), set: (s) => Object.assign(s, { pr: "merc", lat: 72 }), reveal: (s) => (s.pr = "area"), answer: () => "a", why: "가로로 1/cos φ배 늘어나는 만큼 세로를 cos φ배 줄여 넓이를 지킵니다." },
    ],
  },

  // ───────── 주제 1 곡선과 무늬 ─────────
  {
    id: "lab-catenary", grade: LB, unit: 1, lesson: "주제 1", title: "늘어진 쇠사슬 — 포물선일까, 현수선일까", type: "조작", time: "10분",
    tags: ["현수선", "포물선", "쌍곡선함수"], links: ["lab-cycloid"],
    desc: "두 기둥 사이에 늘어진 쇠사슬은 포물선처럼 보이지만 사실은 현수선 y = c·cosh(x/c)입니다. 같은 세 점(양 끝과 가장 낮은 점)을 지나는 포물선과 겹쳐 그려 처짐이 작을 때는 거의 같고, 깊게 처질수록 차이가 커지는 것을 확인합니다.",
    obs: ["갈릴레이는 늘어진 사슬을 포물선이라고 생각했습니다.", "현수선은 cosh x = (eˣ + e⁻ˣ)/2로 나타내는 곡선입니다.", "처짐이 얕으면 cosh x ≈ 1 + x²/2이라 포물선과 거의 같습니다."],
    q: "현수교의 케이블은 다리 상판을 고르게 매달고 있어 포물선에 가깝다고 합니다. 쇠사슬과 무엇이 다를까요?",
    formula: "현수선 y = c(cosh(x/c) − 1), cosh t = (eᵗ + e⁻ᵗ)/2",
    en: { title: "Hanging Chains — Catenary vs Parabola", desc: "Compare with the parabola through the same points." },
    view: { x: [-4.6, 4.6], y: [-0.6, 5.6] },
    params: [
      { key: "a", label: "기둥 사이의 반 거리", min: 1, max: 4, step: 0.1, value: 4 },
      { key: "c", label: "처짐 (작을수록 깊게)", min: 0.8, max: 6, step: 0.1, value: 1.6 },
    ],
    draw(s, g) {
      const cat = (x) => s.c * (Math.cosh(x / s.c) - 1), H = cat(s.a), par = (x) => (H * x * x) / (s.a * s.a), top = Math.min(H, 5.3), k = top / H;
      g.seg([-4.5, 0], [4.5, 0], { color: "grid", w: 1 });
      [-s.a, s.a].forEach((x) => g.seg([x, 0], [x, top + 0.2], { color: "ink", w: 4 }));
      g.fx((x) => par(x) * k, { color: "b", w: 2.4, dash: "7 5", from: -s.a, to: s.a });
      g.fx((x) => cat(x) * k, { color: "a", w: 3.4, from: -s.a, to: s.a });
      g.text([0, 5.2], "주황: 현수선 (쇠사슬)  파랑 점선: 포물선", { bold: true, size: 13 });
      if (k < 0.999) g.text([0, 4.7], `세로를 ${fmt(k, 2)}배로 줄여 그렸어요`, { size: 11, color: "muted" });
    },
    metrics(s) { const cat = (x) => s.c * (Math.cosh(x / s.c) - 1), H = cat(s.a); let m = 0; for (let i = 0; i <= 200; i++) { const x = -s.a + (2 * s.a * i) / 200; m = Math.max(m, Math.abs(cat(x) - (H * x * x) / (s.a * s.a))); } return [["처진 깊이", fmt(H, 3)], ["두 곡선의 가장 큰 차", fmt(m, 3), "key"], ["깊이에 대한 차의 비율", `${fmt((100 * m) / H, 1)}%`]]; },
    predict: [
      { q: "늘어진 쇠사슬의 모양은?", options: O("현수선", "포물선", "원의 일부"), set: (s) => Object.assign(s, { a: 2, c: 6 }), reveal: (s) => Object.assign(s, { a: 4, c: 1 }), answer: () => "a", why: "깊게 처지게 하면 포물선과 확실히 달라집니다. 1691년 요한 베르누이 등이 현수선임을 밝혔습니다." },
      { q: "처짐이 아주 얕을 때 현수선과 포물선의 차는?", options: O("거의 없다", "아주 크다"), set: (s) => Object.assign(s, { a: 2, c: 1 }), reveal: (s) => (s.c = 6), answer: () => "a", why: "cosh t ≈ 1 + t²/2라서 얕게 처질 때는 거의 같은 곡선입니다." },
    ],
  },
  {
    id: "lab-fourier", grade: LB, unit: 1, lesson: "주제 1", title: "푸리에 급수 — 사인 곡선을 더해 네모 파동 만들기", type: "조작", time: "12분",
    tags: ["푸리에 급수", "삼각함수", "파동"], links: ["lab-lissajous"],
    desc: "sin x, sin 3x/3, sin 5x/5, …를 차례로 더하면 매끄러운 사인 곡선이 점점 네모 모양 파동에 가까워집니다. 더하는 항의 수를 늘리며 모양이 다가가는 모습과, 모서리 근처에 끝까지 남는 약 9%의 튀어 오름(깁스 현상)을 관찰합니다. 톱니·세모 파동도 만들어 봅니다.",
    obs: ["주기가 같은 모양은 여러 진동수의 사인 곡선을 더해 만들 수 있습니다.", "항을 늘릴수록 평평한 부분은 더 평평해지고 모서리는 더 가팔라집니다.", "모서리 옆의 튀어 오름은 항을 아무리 늘려도 약 9%로 남습니다(깁스 현상)."],
    q: "MP3나 JPEG 같은 압축이 '작은 항을 버린다'는 말은 이 그림에서 무슨 뜻일까요?",
    formula: "네모 파동 = (4/π)(sin x + sin 3x/3 + sin 5x/5 + ⋯)",
    en: { title: "Fourier Series", desc: "Add sine waves to build a square wave." },
    view: { x: [-0.3, 13], y: [-1.9, 1.9] },
    params: [
      { key: "w", label: "만들 파동", type: "seg", value: "sq", options: Object.entries(WAVE).map(([k, v]) => [k, v.n]) },
      { key: "n", label: "더한 항의 수", min: 1, max: 40, step: 1, value: 5 },
      { key: "show", label: "각 항도 보이기", type: "check", value: true },
    ],
    anim: { key: "n", min: 1, max: 40, speed: 6, label: "항 늘리기" },
    S(s, x) { const W = WAVE[s.w]; let t = 0; for (let k = 1; k <= s.n; k++) t += W.term(k, x); return t; },
    draw(s, g) {
      const W = WAVE[s.w], L = 4 * Math.PI;
      g.seg([0, 0], [12.8, 0], { color: "axis", w: 1.2 });
      g.fx(W.f, { color: "muted", w: 1.6, dash: "5 5", from: 0, to: L, n: 1400 });
      if (s.show) for (let k = 1; k <= Math.min(s.n, 6); k++) g.fx((x) => W.term(k, x), { color: k % 2 ? "b" : "c", w: 1.2, from: 0, to: L, opacity: 0.55, n: 600 });
      g.fx((x) => this.S(s, x), { color: "a", w: 3, from: 0, to: L, n: 1600 });
      g.text([0.2, 1.75], `${W.n}: 항 ${s.n}개를 더한 합`, { anchor: "start", bold: true });
    },
    metrics(s) { let mx = -9; for (let i = 1; i <= 2000; i++) { const x = (Math.PI * i) / 2000; mx = Math.max(mx, this.S(s, x)); } const W = WAVE[s.w], tgt = Math.max(...Array.from({ length: 200 }, (_, i) => W.f((Math.PI * (i + 0.5)) / 200))); return [["더한 항", `${s.n}개`], ["가장 높이 튄 값", fmt(mx, 4)], ["목표보다 튄 비율", `${fmt((100 * (mx - tgt)) / tgt, 1)}%`, "key"]]; },
    predict: [
      { q: "네모 파동에서 항을 아주 많이 더해도 모서리 옆에 튀어 오른 부분은?", options: O("약 9%로 남는다", "0으로 사라진다", "점점 커진다"), set: (s) => Object.assign(s, { w: "sq", n: 3 }), reveal: (s) => (s.n = 40), answer: () => "a", why: "깁스 현상입니다. 튄 폭은 좁아지지만 높이는 약 9%로 남습니다." },
      { q: "네모 파동을 만드는 데 쓰이는 사인 곡선의 진동수는?", options: O("1, 3, 5, … 홀수만", "1, 2, 3, … 모두", "2, 4, 6, … 짝수만"), set: (s) => Object.assign(s, { w: "sq", n: 4, show: true }), answer: () => "a", why: "네모 파동은 반 주기마다 뒤집히는 대칭이 있어 홀수 배 진동수만 남습니다." },
    ],
  },

  // ───────── 주제 2 프랙털과 무한 ─────────
  {
    id: "lab-mandelbrot", grade: LB, unit: 2, lesson: "주제 2", title: "망델브로 집합 — z ← z² + c를 되풀이하면", type: "조작", time: "12분",
    tags: ["망델브로 집합", "복소수", "프랙털"], links: ["lab-koch", "cm1-i-power"],
    desc: "복소수 c를 하나 고르고 0에서 시작해 z ← z² + c를 되풀이합니다. 점들이 원점 근처에 머무르면 c는 망델브로 집합(검은 부분)에 속하고, 멀리 달아나면 속하지 않습니다. 점 c를 끌어 궤적을 보고, 경계를 확대하면 끝없이 복잡한 무늬와 작은 복제가 나타남을 확인합니다.",
    obs: ["|z|가 한 번이라도 2를 넘으면 그 뒤로는 한없이 커집니다.", "검은 부분은 되풀이해도 달아나지 않는 c들의 모임입니다.", "경계를 확대하면 전체와 닮은 작은 모양이 계속 나타나는 프랙털입니다."],
    q: "c = −1이면 z는 0, −1, 0, −1, …이 됩니다. c = 1이면 어떻게 될까요?",
    formula: "z₀ = 0, zₙ₊₁ = zₙ² + c (|zₙ| ≤ 2를 유지하면 c는 집합에 속함)",
    en: { title: "The Mandelbrot Set", desc: "Iterate z ← z² + c." },
    view: (s) => MV[s.v],
    init: () => ({ c: [-0.12, 0.75] }),
    params: [
      { key: "v", label: "보는 곳", type: "seg", value: "all", options: Object.entries(MV).map(([k, v]) => [k, v.n]) },
      { key: "it", label: "되풀이 횟수 (궤적)", min: 1, max: 40, step: 1, value: 20 },
    ],
    drags: { c: { at: (s) => (s.v === "all" ? s.c : null), when: (s) => s.v === "all", move: (s, p) => (s.c = [clamp(Math.round(p[0] * 100) / 100, -2.2, 1), clamp(Math.round(p[1] * 100) / 100, -1.15, 1.15)]), label: "c", color: "a" } },
    orbit(s) { let x = 0, y = 0; const P = [[0, 0]]; for (let i = 0; i < s.it; i++) { [x, y] = [x * x - y * y + s.c[0], 2 * x * y + s.c[1]]; P.push([x, y]); if (x * x + y * y > 16) break; } return P; },
    draw(s, g) {
      const V = MV[s.v], url = mandelURL(s.v + (g.thumb ? "t" : ""), V.x, V.y, g.thumb ? 160 : 400, g.thumb ? 110 : 280, g.thumb ? 50 : 90), A = g.X([V.x[0], V.y[1]]), B = g.X([V.x[1], V.y[0]]);
      if (url) g.L.grid.push(`<image href="${url}" x="${g.n(A[0])}" y="${g.n(A[1])}" width="${g.n(B[0] - A[0])}" height="${g.n(B[1] - A[1])}" preserveAspectRatio="none"/>`);
      if (s.v === "all") {
        g.seg([V.x[0], 0], [V.x[1], 0], { color: "muted", w: 0.8, opacity: 0.6 }).seg([0, V.y[0]], [0, V.y[1]], { color: "muted", w: 0.8, opacity: 0.6 });
        g.circle([0, 0], 2, { color: "e", w: 1.2, dash: "4 4" });
        const P = this.orbit(s); g.path(P.map((p) => [clamp(p[0], -3, 2), clamp(p[1], -1.3, 1.3)]), { color: "a", w: 1.6 }); P.forEach((p, i) => i && Math.abs(p[0]) < 3 && Math.abs(p[1]) < 1.3 && g.point(p, "", { color: "a", r: 2.6 }));
      }
    },
    metrics(s) { const P = this.orbit(s), out = P.some(([x, y]) => x * x + y * y > 4); return [["c", `${fmt(s.c[0], 2)} ${s.c[1] < 0 ? "−" : "+"} ${fmt(Math.abs(s.c[1]), 2)}i`], [`${P.length - 1}번 되풀이한 뒤 |z|`, fmt(Math.hypot(...P[P.length - 1]), 3)], ["판정", out ? "달아남 → 집합 밖" : "머무름 → 집합 안(으로 보임)", "key"]]; },
    predict: [
      { q: "c = −1이면 z는 어떻게 될까요?", options: O("0과 −1을 오간다", "한없이 커진다", "1로 다가간다"), set: (s) => Object.assign(s, { v: "all", c: [0.3, 0.6], it: 6 }), reveal: (s) => (s.c = [-1, 0]), answer: () => "a", why: "0² − 1 = −1, (−1)² − 1 = 0이 되풀이되어 집합 안에 있습니다." },
      { q: "c = 1은 망델브로 집합에 속할까요?", options: O("속하지 않는다", "속한다"), set: (s) => Object.assign(s, { v: "all", c: [-0.5, 0], it: 8 }), reveal: (s) => (s.c = [1, 0]), answer: () => "a", why: "0, 1, 2, 5, 26, …으로 한없이 커집니다." },
    ],
  },
];
