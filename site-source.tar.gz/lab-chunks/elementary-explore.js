// A shared exploration workbench. Mathematical states always go through clean.
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = value => String(Number(Number(value).toFixed(8)));
const same = (a, b, controls) => controls.every(c => a[c.key] === b[c.key]);

export function sampleStates(lab, state, key, clean) {
  const c = lab.controls.find(c => c.key === key);
  if (!c) return [];
  const low = clean(lab.id, {...state, [key]: c.min});
  const high = clean(lab.id, {...state, [key]: c.max});
  const middle = clean(lab.id, {...state, [key]: (low[key] + high[key]) / 2});
  return [low, middle, high].filter((s, i, all) => all.findIndex(x => same(x, s, lab.controls)) === i);
}

export function advanceState(lab, state, key, direction, clean) {
  const c = lab.controls.find(c => c.key === key);
  if (!c || c.min === c.max) return {state: clean(lab.id, state), moved: false};
  const next = clean(lab.id, {...state, [key]: state[key] + (direction < 0 ? -1 : 1) * c.step});
  return {state: next, moved: !same(state, next, lab.controls)};
}

export function stateChanges(lab, before, after) {
  return lab.controls.filter(c => before[c.key] !== after[c.key]).map(c => ({
    key: c.key, label: c.label, before: before[c.key], after: after[c.key],
    delta: Number((after[c.key] - before[c.key]).toFixed(8))
  }));
}

export function diagramMarkup(svg) {
  return svg.replace(/viewBox="[^"]*"/, 'viewBox="0 100 800 435"')
    .replace(/<g class="em-svg-heading">[\s\S]*?<\/g>/, '')
    .replace(/<g class="em-svg-footer">[\s\S]*?<\/g>/, '');
}

export function recordHTML({lab, state, pinned, prediction, note, samples, selectedLabel, scene, readings, date = new Date()}) {
  const conditions = s => lab.controls.map(c => `${c.label} ${fmt(s[c.key])}`).join(' / ');
  const picture = (s, title) => `<section class="picture"><h2>${esc(title)}</h2><p>${esc(conditions(s))}</p>${scene(lab.id,s)}<p>${readings(lab.id,s).map(([label,value])=>`${esc(label)}: ${esc(value)}`).join(' / ')}</p></section>`;
  return `<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(lab.title)} 탐구 기록</title><style>body{margin:0;background:#edf3f3;color:#203a59;font:18px/1.8 system-ui,sans-serif}main{max-width:900px;margin:auto;padding:28px}h1{font-size:30px;line-height:1.5}h2{font-size:23px}header,.writing,.picture{background:white;border:1px solid #bacbd7;border-radius:14px;padding:24px;margin:20px 0;overflow-wrap:anywhere}svg{display:block;width:100%;height:auto}pre{font:inherit;white-space:pre-wrap}.meta{font-size:15px}.picture{break-inside:avoid}@media print{body{background:white;font-size:14px}main{padding:0}.picture{break-before:page;border:0;padding:0}header,.writing{border-color:#ccc}svg{max-height:220mm}@page{size:A4;margin:16mm}}</style><main><header><p>McKay Math Atelier / ${esc(lab.gradeName)}</p><h1>${esc(lab.title)}</h1><p>${esc(lab.q)}</p><p class="meta">${esc(date.toLocaleString('ko-KR'))}</p></header><section class="writing"><h2>1. 먼저 예상했어요</h2><pre>${esc(prediction || '예상을 적지 않았어요.')}</pre><h2>2. 그림을 보고 발견했어요</h2><pre>${esc(note || '발견한 내용을 적지 않았어요.')}</pre><p>바꾼 조건: ${esc(selectedLabel)}</p></section>${pinned ? picture(pinned,'고정한 그림') : ''}${picture(state,'지금 그림')}${samples.map((s,i)=>picture(s,`연속 그림 ${i+1}`)).join('')}<p>이 파일은 인터넷 없이 열 수 있어요. 브라우저의 인쇄 기능으로 종이에 출력할 수 있어요.</p></main></html>`;
}

export const EXPLORE_CSS = `
body.at .em-stage>.em-comparison{width:100%!important;max-width:100%;justify-self:stretch}
.em-stage .em-picture,.em-stage .em-picture-scroll{width:100%;min-width:0;box-sizing:border-box}
.em-explore{border-top:1px solid #afc4ce66;padding:18px;min-width:0}
.em-explore summary{font-size:21px;font-weight:700;min-height:48px;cursor:pointer;line-height:1.6}
.em-explore p{font-size:16px;line-height:1.8;margin:10px 0}
.em-explore-tools{display:flex;align-items:end;flex-wrap:wrap;gap:12px;margin:12px 0}
.em-explore label{display:grid;gap:6px;min-width:0;font-size:17px}
.em-explore select,.em-explore button,.em-notes button{font:inherit;min-height:48px;border:1px solid #a8bfc9;border-radius:10px;padding:10px;background:var(--at-bg,#fff);color:inherit;cursor:pointer;box-sizing:border-box;max-width:100%}
.em-explore select{width:100%}.em-explore-tools label:first-child{flex:1 1 200px}.em-explore-tools label{flex:0 1 160px}
.em-explore-actions{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0}.em-explore-actions button{flex:1 1 140px}.em-explore [data-em-play]{background:#087f71;color:white}.em-explore [data-em-play][aria-pressed=true]{background:#7954b9}
.em-explore button:disabled{opacity:.45;cursor:default}.em-explore progress{width:100%;height:14px;accent-color:#087f71}
.em-explore-position{display:flex;justify-content:space-between;gap:10px;font-variant-numeric:tabular-nums;font-size:16px}.em-explore-position strong{color:var(--at-ink,#203a59)}
.em-story{display:flex;overflow-x:auto;scroll-snap-type:x proximity;gap:16px;padding:12px 2px 18px;max-width:100%;overscroll-behavior-x:contain}
.em-story-card{flex:1 0 min(100%,380px);min-width:0;border:1px solid #b4c9cd;border-radius:14px;overflow:hidden;background:#fffaf0;color:#203a59;scroll-snap-align:start;box-sizing:border-box}
.em-story-card h3{font-size:20px;margin:0;padding:14px 16px;background:#e8f2ed;line-height:1.6}.em-story-card p{padding:0 16px;font-size:17px;overflow-wrap:anywhere}.em-story-card svg{display:block;width:100%;height:auto}.em-story-card button{display:block;margin:14px 16px;width:calc(100% - 32px);background:#203a59;color:white}
.em-story-card [aria-pressed=true]{background:#087f71}.em-story-card [data-em-conditions]{font-size:15px}.em-explore-status{min-height:3.6em}
.em-change-summary{border-left:4px solid #7954b9;margin:0 16px 16px;padding:10px 16px;background:var(--at-bg,#fff);line-height:1.7}.em-change-summary ul{padding-left:22px;margin:6px 0}.em-change-summary li{overflow-wrap:anywhere}.em-change-summary strong{font-size:18px}
.em-notes .em-note-step{font-size:18px;font-weight:700;margin:6px 0}.em-notes .em-record-help{font-size:15px;line-height:1.7}.em-notes button{justify-self:start;background:#203a59;color:white}
@media(max-width:560px){.em-explore{padding:14px 10px}.em-story-card{flex-basis:100%}.em-explore-tools label{flex:1 1 100%}.em-explore-actions button{flex-basis:100%}.em-story-card p{font-size:16px}.em-change-summary{margin:0 10px 12px}}
[data-theme=dark] .em-explore-position strong{color:inherit}
`;

export function mountExplorer({lab, host, getState, setState, scene, clean, readings, signal, pinStart}) {
  const variable = lab.controls.filter(c => c.min < c.max);
  if (!variable.length) return {update(){},stop(){},destroy(){},getSamples(){return [];},get label(){return '';}};
  const root = document.createElement('section');
  root.className = 'em-explore';
  root.dataset.mathPlain = '';
  root.innerHTML = `<details><summary>연속 그림으로 변화 살펴보기</summary><p>조건 하나를 골라 한 칸씩 바꾸어 보세요. 아래 그림을 누르면 그 조건으로 바로 탐구할 수 있어요.</p><div class="em-explore-tools"><label>바꿀 조건<select data-em-variable>${variable.map(c=>`<option value="${c.key}">${esc(c.label)}</option>`).join('')}</select></label><label>재생 방향<select data-em-direction><option value="1">늘리기</option><option value="-1">줄이기</option></select></label></div><div class="em-explore-actions"><button type="button" data-em-prev>한 칸 줄이기</button><button type="button" data-em-play aria-pressed="false">천천히 재생</button><button type="button" data-em-next>한 칸 늘리기</button></div><div class="em-explore-position"><span data-em-low></span><strong data-em-position></strong><span data-em-high></span></div><progress data-em-progress aria-label="선택한 조건의 현재 위치" max="100" value="0"></progress><p class="em-explore-status" role="status">움직이기 전에 그림이 어떻게 달라질지 예상해 보세요.</p><p>연속 그림은 작은 조건부터 큰 조건 순서예요. 함께 달라지는 조건과 각 그림의 눈금도 확인하세요. 옆으로 넘겨 다른 그림을 볼 수 있어요.</p><div class="em-story" tabindex="0" role="region" aria-label="3단계 연속 그림"></div></details>`;
  host.append(root);
  const $ = selector => root.querySelector(selector);
  let key=variable[0].key, timer=null, playing=false, dead=false, samples=[], signature='';
  const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
  function stop(message) {
    clearTimeout(timer); timer=null; playing=false;
    $('[data-em-play]').textContent='천천히 재생';
    $('[data-em-play]').setAttribute('aria-pressed','false');
    if(message) $('.em-explore-status').textContent=message;
  }
  function update() {
    if(dead)return;
    const state=getState(), c=lab.controls.find(c=>c.key===key);
    const low=clean(lab.id,{...state,[key]:c.min})[key], high=clean(lab.id,{...state,[key]:c.max})[key];
    $('[data-em-low]').textContent=fmt(low);
    $('[data-em-high]').textContent=fmt(high);
    $('[data-em-position]').textContent=c.label+' '+fmt(state[key]);
    $('[data-em-progress]').value=high===low?0:(state[key]-low)/(high-low)*100;
    $('[data-em-progress]').setAttribute('aria-valuetext',c.label+' '+fmt(state[key]));
    $('[data-em-prev]').disabled=!advanceState(lab,state,key,-1,clean).moved;
    $('[data-em-next]').disabled=!advanceState(lab,state,key,1,clean).moved;
    $('[data-em-play]').disabled=motion.matches;
    $('[data-em-play]').title=motion.matches?'움직임 줄이기 설정 중이에요. 한 칸 버튼으로 탐구하세요.':'';
    samples=sampleStates(lab,state,key,clean);
    const nextSignature=JSON.stringify([key,samples]);
    if(signature!==nextSignature && $('details').open){
      signature=nextSignature;
      $('.em-story').innerHTML=samples.map((s,i)=>`<article class="em-story-card"><h3>${i+1}. ${esc(c.label)} ${fmt(s[key])}</h3>${diagramMarkup(scene(lab.id,s))}<p data-em-conditions>${lab.controls.map(control=>esc(control.label)+' '+fmt(s[control.key])).join(' / ')}</p><p>${readings(lab.id,s).map(([label,value])=>esc(label)+' '+esc(value)).join(' / ')}</p><button type="button" data-em-sample="${i}">이 조건으로 탐구</button></article>`).join('');
    }
    root.querySelectorAll('[data-em-sample]').forEach(b=>b.setAttribute('aria-pressed',String(same(samples[Number(b.dataset.emSample)],state,lab.controls))));
  }
  function step(direction, automatic=false) {
    if(!automatic)stop();
    const next=advanceState(lab,getState(),key,direction,clean);
    if(!next.moved){stop('이 방향의 마지막 조건이에요. 방향을 바꾸어 탐구해 보세요.');return false;}
    setState(next.state);
    if(!automatic)$('.em-explore-status').textContent='그림과 수가 어떻게 함께 달라졌는지 살펴보세요.';
    return true;
  }
  function tick() {
    if(dead||!playing)return;
    if(step(Number($('[data-em-direction]').value),true)){
      const next=advanceState(lab,getState(),key,Number($('[data-em-direction]').value),clean);
      if(next.moved)timer=setTimeout(tick,1200);
      else stop('마지막 조건까지 살펴봤어요. 고정한 그림과 비교해 보세요.');
    }
  }
  $('[data-em-variable]').addEventListener('change',event=>{stop();key=event.target.value;signature='';update();},{signal});
  $('[data-em-direction]').addEventListener('change',()=>stop(),{signal});
  $('[data-em-prev]').addEventListener('click',()=>step(-1),{signal});
  $('[data-em-next]').addEventListener('click',()=>step(1),{signal});
  $('[data-em-play]').addEventListener('click',()=>{
    if(playing){stop('재생을 멈췄어요. 지금 그림을 자세히 살펴보세요.');return;}
    if(motion.matches)return;
    if(!advanceState(lab,getState(),key,Number($('[data-em-direction]').value),clean).moved){stop('이 방향의 마지막 조건이에요. 재생 방향을 바꾸어 보세요.');return;}
    pinStart();playing=true;
    $('[data-em-play]').textContent='잠깐 멈추기';$('[data-em-play]').setAttribute('aria-pressed','true');
    $('.em-explore-status').textContent='시작 그림을 고정했어요. 선택한 조건을 한 칸씩 바꿉니다.';
    timer=setTimeout(tick,1200);
  },{signal});
  $('.em-story').addEventListener('click',event=>{const b=event.target.closest('[data-em-sample]');if(!b)return;stop();setState({...samples[Number(b.dataset.emSample)]});$('.em-explore-status').textContent='고른 그림의 조건으로 바꾸었어요.';},{signal});
  $('details').addEventListener('toggle',()=>{if($('details').open)update();else stop();},{signal});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();},{signal});
  motion.addEventListener('change',()=>{stop();update();},{signal});
  signal.addEventListener('abort',()=>{dead=true;stop();root.remove();},{once:true});
  update();
  return {update,stop,destroy(){dead=true;stop();root.remove();},getSamples(){return samples.map(s=>({...s}));},get label(){return lab.controls.find(c=>c.key===key).label;}};
}
