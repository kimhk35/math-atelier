// 교과서 본문 예제에서 뽑은 실험 (공통수학1 경우의 수 · 공통수학2 집합 · 기하 · 중1 · 확률과 통계)
import { fmt, frac, surd, dist, sub, add, mul, norm, dot, len, cross, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const V = { x: [-7, 7], y: [-5, 5] };
const COLS = ["a", "b", "c", "e", "f", "d"];
const fact = (n) => { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r; };
const C = (n, k) => (k < 0 || k > n ? 0 : Math.round(fact(n) / (fact(k) * fact(n - k))));
const rot = (p, a) => [p[0] * Math.cos(a) - p[1] * Math.sin(a), p[0] * Math.sin(a) + p[1] * Math.cos(a)];
const angAt = (v, p, q) => Math.acos(clamp(dot(sub(p, v), sub(q, v)) / (len(sub(p, v)) * len(sub(q, v)) || 1), -1, 1));
function wedge(g, v, a0, w, r, o) { const pts = [v]; for (let i = 0; i <= 30; i++) { const t = a0 + (w * i) / 30; pts.push([v[0] + r * Math.cos(t), v[1] + r * Math.sin(t)]); } g.poly(pts, { fill: o.color, fo: o.fo ?? 0.6, color: o.color, w: 1.4 }); if (o.label) { const m = a0 + w / 2; g.text([v[0] + (r + 0.5) * Math.cos(m), v[1] + (r + 0.5) * Math.sin(m)], o.label, { color: o.color, bold: true, size: 13 }); } }
const SETPROP = { even: ["짝수", (x) => x % 2 === 0], m3: ["3의 배수", (x) => x % 3 === 0], prime: ["소수", (x) => x > 1 && [...Array(x).keys()].slice(2).every((d) => x % d)], le10: ["10 이하", (x) => x <= 10], sq: ["제곱수", (x) => Number.isInteger(Math.sqrt(x))], m5: ["5의 배수", (x) => x % 5 === 0], odd: ["홀수", (x) => x % 2 === 1] };
const setOpts = Object.entries(SETPROP).map(([k, v]) => [k, v[0]]);

export default [
  // ───────── 공통수학1 Ⅴ 경우의 수 ─────────
  {
    id: "cm1-sum-product", grade: 14, unit: 5, lesson: "Ⅴ-1", title: "합의 법칙과 곱의 법칙 — 길 찾기", type: "조작", time: "8분",
    tags: ["합의 법칙", "곱의 법칙", "수형도"], links: ["pst-perm-comb", "g2-counting"],
    desc: "A 마을에서 B 마을을 거쳐 C 마을로 가는 길과 A에서 C로 바로 가는 길을 하나씩 짚어 보며, 이어지는 선택은 곱하고(곱의 법칙) 겹치지 않는 선택은 더한다(합의 법칙)는 것을 확인합니다.",
    obs: ["A → B의 길 p개 각각에 대해 B → C의 길이 q개씩 있으므로 p × q가지입니다.", "B를 거치는 길과 바로 가는 길은 동시에 일어나지 않으므로 더합니다.", "모든 경로에 번호를 붙이면 빠짐없이, 중복 없이 셀 수 있습니다."],
    q: "A → B 3가지, B → C 4가지, A → C 직통 2가지일 때 A에서 C로 가는 방법은 모두 몇 가지일까요?",
    formula: "곱의 법칙 p × q · 합의 법칙 p × q + r",
    en: { title: "Sum and Product Rules", desc: "Count routes through B (multiply) and direct routes (add)." },
    view: BOX,
    params: [{ key: "p", label: "A → B 길의 수 p", min: 1, max: 5, step: 1, value: 3 }, { key: "q", label: "B → C 길의 수 q", min: 1, max: 5, step: 1, value: 4 }, { key: "r", label: "A → C 직통 길의 수 r", min: 0, max: 3, step: 1, value: 2 }, { key: "k", label: "경로 번호", min: 1, max: (s) => s.p * s.q + s.r, step: 1, value: 5 }],
    anim: { key: "k", min: 1, max: 23, speed: 2, loop: "wrap", label: "경로 하나씩 보기" },
    derive(s) { const tot = s.p * s.q + s.r; if (s.k > tot) s.k = tot; },
    draw(s, g) {
      const A = [1.6, 4.4], B = [8, 8.2], Cc = [14.4, 4.4];
      const curve = (P, Q, off, o) => { const m = add(lerp(P, Q, 0.5), mul(norm([-(Q[1] - P[1]), Q[0] - P[0]]), off)); g.param((t) => add(add(mul(P, (1 - t) ** 2), mul(m, 2 * t * (1 - t))), mul(Q, t * t)), 0, 1, { n: 40, ...o }); };
      const k = s.k - 1, via = k < s.p * s.q, i = via ? Math.floor(k / s.q) : -1, j = via ? k % s.q : -1, d = via ? -1 : k - s.p * s.q;
      for (let a = 0; a < s.p; a++) curve(A, B, (a - (s.p - 1) / 2) * 0.7, { color: a === i ? "a" : "muted", w: a === i ? 4 : 1.6, opacity: a === i ? 1 : 0.6 });
      for (let b = 0; b < s.q; b++) curve(B, Cc, (b - (s.q - 1) / 2) * 0.7, { color: b === j ? "a" : "muted", w: b === j ? 4 : 1.6, opacity: b === j ? 1 : 0.6 });
      for (let c = 0; c < s.r; c++) curve(A, Cc, -1.6 - c * 0.9, { color: c === d ? "b" : "muted", w: c === d ? 4 : 1.6, dash: "6 4", opacity: c === d ? 1 : 0.6 });
      [[A, "A"], [B, "B"], [Cc, "C"]].forEach(([p, n]) => { g.circle(p, 0.55, { color: "ink", fill: "paper", fo: 1, w: 2, layer: "point" }); g.text(p, n, { dy: 6, size: 18, bold: true }); });
      g.text([8, 1.2], via ? `${i + 1}번 길 → ${j + 1}번 길` : `직통 ${d + 1}번 길`, { size: 16, bold: true, color: via ? "a" : "b" });
    },
    metrics(s) { return [["B를 거쳐 가기 (곱의 법칙)", `${s.p} × ${s.q} = ${s.p * s.q}가지`], ["직통 (합의 법칙으로 더함)", `${s.r}가지`], ["전체", `${s.p * s.q} + ${s.r} = ${s.p * s.q + s.r}가지`, "key"], ["지금 경로", `${s.k}번째`]]; },
  },
  {
    id: "cm1-books", grade: 14, unit: 5, lesson: "Ⅴ-2", title: "책꽂이에 책 꽂기 — 이웃하게, 떨어지게", type: "조작", time: "10분",
    tags: ["순열", "묶어서 세기", "사이에 넣기"], links: ["pst-perm-comb", "cm1-sum-product"],
    desc: "소설책과 시집을 일렬로 꽂을 때, 시집끼리 이웃하게 하려면 한 묶음으로 보고, 시집끼리 떨어지게 하려면 소설책 사이사이의 자리에 넣는 방법으로 셉니다.",
    obs: ["이웃하는 것은 한 덩어리로 묶어 줄 세운 뒤, 묶음 안의 순서를 곱합니다.", "이웃하지 않는 것은 나머지를 먼저 세우고 그 양 끝과 사이의 빈자리에 넣습니다.", "제한 없음 = 이웃함 + 적어도 두 권이 이웃 … 처럼 여러 방법으로 검산할 수 있습니다."],
    q: "소설책 4권과 시집 2권을 시집끼리 이웃하게 꽂는 방법은 몇 가지일까요?",
    formula: "이웃: (n + 1)! × m! · 떨어짐: n! × ₙ₊₁Pₘ",
    en: { title: "Arranging Books on a Shelf", desc: "Glue neighbors together or slot them into gaps to count arrangements." },
    view: BOX,
    params: [{ key: "n", label: "소설책 수 n", min: 2, max: 6, step: 1, value: 4 }, { key: "m", label: "시집 수 m", min: 1, max: 3, step: 1, value: 2 }, { key: "mode", label: "조건", type: "seg", value: "adj", options: [["free", "제한 없음"], ["adj", "시집끼리 이웃"], ["sep", "시집끼리 떨어짐"]] }],
    init: () => ({ seedk: 1 }),
    buttons: [["shuffle", "다른 배열 보기"]],
    onDo(k, s) { if (k === "shuffle") s.seedk = Math.floor(Math.random() * 1e6); },
    arrangement(s) {
      let x = s.seedk || 1; const rnd = () => ((x = (x * 16807) % 2147483647) / 2147483647);
      const N = Array.from({ length: s.n }, (_, i) => `소${i + 1}`), P = Array.from({ length: s.m }, (_, i) => `시${i + 1}`), sh = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
      if (s.mode === "free") return sh([...N, ...P]);
      if (s.mode === "adj") { const items = sh([...N, "BLOCK"]); const blk = sh([...P]); return items.flatMap((it) => (it === "BLOCK" ? blk : [it])); }
      const order = sh([...N]), slots = sh([...Array(s.n + 1).keys()]).slice(0, s.m).sort((a, b) => a - b), pp = sh([...P]); const out = []; let pi = 0;
      for (let i = 0; i <= s.n; i++) { if (slots.includes(i)) out.push(pp[pi++]); if (i < s.n) out.push(order[i]); }
      return out;
    },
    count(s) { const n = s.n, m = s.m; return s.mode === "free" ? fact(n + m) : s.mode === "adj" ? fact(n + 1) * fact(m) : n + 1 >= m ? fact(n) * (fact(n + 1) / fact(n + 1 - m)) : 0; },
    draw(s, g) {
      const A = this.arrangement(s), w = Math.min(1.4, 13.6 / A.length), x0 = 8 - (A.length * w) / 2;
      g.seg([0.8, 3], [15.2, 3], { color: "ink", w: 4 });
      A.forEach((b, i) => { const x = x0 + i * w, poet = b.startsWith("시"), h = poet ? 3.4 : 4.4; g.poly([[x + 0.08, 3], [x + w - 0.08, 3], [x + w - 0.08, 3 + h], [x + 0.08, 3 + h]], { fill: poet ? "d" : "b", fo: 0.55, color: poet ? "d" : "b", w: 1.6 }); g.text([x + w / 2, 3 + h / 2], b, { dy: 5, size: 13, bold: true }); });
      if (s.mode === "adj") { const i0 = A.findIndex((b) => b.startsWith("시")); g.poly([[x0 + i0 * w, 2.7], [x0 + (i0 + s.m) * w, 2.7], [x0 + (i0 + s.m) * w, 7.7], [x0 + i0 * w, 7.7]], { color: "a", w: 2.4, dash: "6 4" }); g.text([x0 + (i0 + s.m / 2) * w, 7.7], "한 묶음", { dy: -8, color: "a", bold: true, size: 13 }); }
      if (s.mode === "sep") for (let i = 0; i <= s.n; i++) { const nov = A.map((b, j) => [b, j]).filter(([b]) => b.startsWith("소")); const xs = i === 0 ? x0 - 0.2 : i === s.n ? x0 + A.length * w + 0.2 : x0 + ((nov[i - 1][1] + nov[i][1] + 1) / 2) * w; g.text([xs, 2.2], "∨", { color: "e", bold: true, size: 16 }); }
    },
    metrics(s) { const n = s.n, m = s.m, f = { free: `(${n} + ${m})! = ${fact(n + m)}`, adj: `(${n} + 1)! × ${m}! = ${fact(n + 1)} × ${fact(m)}`, sep: `${n}! × ${n + 1}P${m} = ${fact(n)} × ${fact(n + 1) / fact(n + 1 - m)}` }[s.mode]; return [["계산", f], ["방법의 수", `${this.count(s)}가지`, "key"]]; },
  },
  {
    id: "cm1-sandwich", grade: 14, unit: 5, lesson: "Ⅴ-3 프로젝트", title: "샌드위치 재료 고르기 — 조합과 부분집합", type: "조작", time: "10분",
    tags: ["조합", "2ⁿ", "조건이 있는 선택"], links: ["cm2-subsets", "pst-pascal"],
    desc: "재료 n가지 가운데 몇 가지를 골라 샌드위치를 만들 때, 정확히 r가지를 고르는 방법(ₙCᵣ)과 아무렇게나 고르는 방법(2ⁿ)을 비교하고, 반드시 넣거나 빼는 재료가 있을 때 수가 어떻게 줄어드는지 봅니다.",
    obs: ["재료마다 ‘넣는다/뺀다’ 두 가지 선택이 있으므로 모두 2ⁿ가지입니다.", "정확히 r가지를 고르는 방법은 ₙCᵣ가지이고, 이를 r = 0부터 n까지 더하면 2ⁿ입니다.", "반드시 넣는 재료는 이미 정해졌으므로 나머지 재료만 고르면 됩니다."],
    q: "재료 6가지 중 치즈는 반드시 넣고 양파는 넣지 않으면서 3가지를 고르는 방법은 몇 가지일까요?",
    formula: "ₙC₀ + ₙC₁ + … + ₙCₙ = 2ⁿ · 반드시 포함 a개, 제외 b개 ⇒ ₙ₋ₐ₋ᵦCᵣ₋ₐ",
    en: { title: "Choosing Sandwich Fillings", desc: "Compare nCr with 2ⁿ and see how required or excluded fillings change the count." },
    view: BOX,
    params: [{ key: "r", label: "고르는 재료 수 r", min: 0, max: 6, step: 1, value: 3 }, { key: "must", label: "치즈는 반드시 넣기", type: "check", value: true }, { key: "no", label: "양파는 넣지 않기", type: "check", value: false }, { key: "k", label: "고른 조합 번호", min: 1, max: 20, step: 1, value: 1 }],
    anim: { key: "k", min: 1, max: 20, speed: 2.5, loop: "wrap", label: "조합 하나씩 보기" },
    ING: [["치즈", "f"], ["햄", "d"], ["양상추", "c"], ["토마토", "a"], ["양파", "e"], ["달걀", "b"]],
    combos(s) { const n = 6, out = []; for (let m = 0; m < 1 << n; m++) { const set = [...Array(n).keys()].filter((i) => (m >> i) & 1); if (set.length !== s.r) continue; if (s.must && !set.includes(0)) continue; if (s.no && set.includes(4)) continue; out.push(set); } return out; },
    derive(s) { const L = this.combos(s).length; if (s.k > Math.max(1, L)) s.k = Math.max(1, L); },
    draw(s, g) {
      const L = this.combos(s), cur = L[s.k - 1] || [];
      this.ING.forEach(([nm, c], i) => { const on = cur.includes(i), x = 1.6 + i * 2.4; g.circle([x, 8], 0.85, { color: c, fill: on ? c : "paper", fo: on ? 0.75 : 1, w: 2.2 }); g.text([x, 8], nm, { dy: 5, size: 12, bold: true }); if ((i === 0 && s.must) || (i === 4 && s.no)) g.text([x, 6.7], i === 0 ? "필수" : "제외", { size: 12, bold: true, color: i === 0 ? "c" : "d" }); });
      g.poly([[3.5, 2.6], [12.5, 2.6], [13, 3.3], [3, 3.3]], { fill: "f", fo: 0.5, color: "f", w: 1.4 });
      cur.forEach((i, k) => g.poly([[3.8, 3.3 + k * 0.45], [12.2, 3.3 + k * 0.45], [12.2, 3.72 + k * 0.45], [3.8, 3.72 + k * 0.45]], { fill: this.ING[i][1], fo: 0.7, stroke: false }));
      const top = 3.3 + cur.length * 0.45; g.poly([[3, top], [13, top], [12.5, top + 0.8], [3.5, top + 0.8]], { fill: "f", fo: 0.5, color: "f", w: 1.4 });
      if (!L.length) g.text([8, 5], "조건에 맞는 조합이 없어요", { size: 16, bold: true, color: "d" });
    },
    metrics(s) { const free = 6 - (s.must ? 1 : 0) - (s.no ? 1 : 0), need = s.r - (s.must ? 1 : 0); return [["정확히 r가지 (조건 없음)", `₆C${s.r} = ${C(6, s.r)}`], ["조건에 맞는 방법", `${free}C${Math.max(0, need)} = ${need < 0 ? 0 : C(free, need)}가지`, "key"], ["아무렇게나 고르기", "2⁶ = 64가지"]]; },
  },
  // ───────── 공통수학2 Ⅲ 집합 ─────────
  {
    id: "cm2-venn", grade: 4, unit: 3, lesson: "Ⅲ-2", title: "벤 다이어그램으로 보는 집합의 연산", type: "조작", time: "12분",
    tags: ["합집합", "교집합", "원소의 개수"], links: ["pst-venn", "cm2-subsets"],
    desc: "1부터 20까지의 수를 성질에 따라 두 집합(또는 세 집합)의 벤 다이어그램에 넣고, 합집합·교집합·차집합·여집합을 색칠하며 원소의 개수 사이의 관계를 확인합니다.",
    obs: ["n(A ∪ B) = n(A) + n(B) − n(A ∩ B)입니다. 겹친 부분을 두 번 세지 않게 한 번 뺍니다.", "A − B = A ∩ Bᶜ입니다.", "세 집합이면 두 개씩 겹친 부분을 빼고 세 개가 겹친 부분을 다시 더합니다."],
    q: "1부터 100까지의 수 중 2의 배수도 3의 배수도 아닌 수는 몇 개일까요?",
    formula: "n(A ∪ B) = n(A) + n(B) − n(A ∩ B) · n(A ∪ B ∪ C) = Σn(A) − Σn(A ∩ B) + n(A ∩ B ∩ C)",
    en: { title: "Set Operations with Venn Diagrams", desc: "Sort 1–20 into sets and shade unions, intersections, differences and complements." },
    view: BOX,
    params: [
      { key: "three", label: "집합 개수", type: "seg", value: 2, options: [[2, "두 집합"], [3, "세 집합"]] },
      { key: "A", label: "집합 A", type: "select", value: "even", options: setOpts },
      { key: "B", label: "집합 B", type: "select", value: "m3", options: setOpts },
      { key: "Cs", label: "집합 C", type: "select", value: "prime", options: setOpts, when: (s) => s.three === 3 },
      { key: "op", label: "색칠할 집합", type: "seg", value: "union", options: [["union", "A ∪ B"], ["inter", "A ∩ B"], ["diff", "A − B"], ["comp", "Aᶜ"], ["all", "모두 합"]] },
    ],
    inside(s, x, y) { const ca = [5.8, 6], cb = [9.2, 6], cc = [7.5, 3.4], r = 2.9; return [Math.hypot(x - ca[0], y - ca[1]) < r, Math.hypot(x - cb[0], y - cb[1]) < r, s.three === 3 && Math.hypot(x - cc[0], y - cc[1]) < r]; },
    sel(s, a, b, c) { return { union: a || b, inter: a && b, diff: a && !b, comp: !a, all: a || b || c }[s.op]; },
    mem(s, x) { return [SETPROP[s.A][1](x), SETPROP[s.B][1](x), s.three === 3 && SETPROP[s.Cs][1](x)]; },
    draw(s, g) {
      g.poly([[0.6, 0.5], [15.4, 0.5], [15.4, 10.4], [0.6, 10.4]], { color: "ink", w: 1.6 });
      g.text([1, 10], "U = {1, 2, …, 20}", { anchor: "start", dy: -2, size: 12, bold: true, color: "muted" });
      for (let x = 0.7; x < 15.3; x += 0.36) for (let y = 0.6; y < 10.3; y += 0.36) { const [a, b, c] = this.inside(s, x + 0.18, y + 0.18); if (this.sel(s, a, b, c)) g.poly([[x, y], [x + 0.36, y], [x + 0.36, y + 0.36], [x, y + 0.36]], { fill: "a", fo: 0.22, stroke: false }); }
      const cs = [[5.8, 6, "A", "b"], [9.2, 6, "B", "c"], ...(s.three === 3 ? [[7.5, 3.4, "C", "e"]] : [])];
      cs.forEach(([x, y, n, col]) => { g.circle([x, y], 2.9, { color: col, w: 2.4 }); });
      g.text([3.4, 8.9], `A: ${SETPROP[s.A][0]}`, { anchor: "middle", size: 12, bold: true, color: "b" }).text([11.6, 8.9], `B: ${SETPROP[s.B][0]}`, { size: 12, bold: true, color: "c" });
      if (s.three === 3) g.text([7.5, 0.9], `C: ${SETPROP[s.Cs][0]}`, { size: 12, bold: true, color: "e" });
      // 영역별 대표 위치에 원소 배치
      const anchor = (a, b, c) => { const key = `${+a}${+b}${+c}`; return { "100": [4.4, 6.6], "010": [10.6, 6.6], "110": [7.5, 7], "001": [7.5, 2.1], "101": [5.9, 3.9], "011": [9.1, 3.9], "111": [7.5, 5.1], "000": [13.6, 2.2] }[key]; };
      const bucket = {};
      for (let x = 1; x <= 20; x++) { const m = this.mem(s, x), key = m.map(Number).join(""); (bucket[key] = bucket[key] || []).push(x); }
      Object.entries(bucket).forEach(([key, xs]) => { const [a, b, c] = [...key].map((d) => d === "1"); const p = anchor(a, b, c); xs.forEach((x, i) => { const cols = key === "000" ? 4 : 3, q = add(p, [((i % cols) - (cols - 1) / 2) * 0.62, -Math.floor(i / cols) * 0.5 + (key === "000" ? 2.4 : 0.5)]); g.text(q, String(x), { dy: 4, size: 12.5, bold: this.sel(s, a, b, c), color: this.sel(s, a, b, c) ? "a" : "ink" }); }); });
    },
    metrics(s) {
      const U = [...Array(20)].map((_, i) => i + 1), M = U.map((x) => this.mem(s, x)), n = (f) => M.filter(f).length;
      const nA = n((m) => m[0]), nB = n((m) => m[1]), nAB = n((m) => m[0] && m[1]), picked = n((m) => this.sel(s, m[0], m[1], m[2]));
      const out = [["n(A) · n(B) · n(A ∩ B)", `${nA} · ${nB} · ${nAB}`], ["n(A ∪ B)", `${nA} + ${nB} − ${nAB} = ${nA + nB - nAB}`], ["색칠한 집합의 원소 수", `${picked}개`, "key"]];
      if (s.three === 3) { const nC = n((m) => m[2]), nAC = n((m) => m[0] && m[2]), nBC = n((m) => m[1] && m[2]), nABC = n((m) => m[0] && m[1] && m[2]); out.push(["n(A ∪ B ∪ C)", `${nA}+${nB}+${nC}−${nAB}−${nBC}−${nAC}+${nABC} = ${nA + nB + nC - nAB - nBC - nAC + nABC}`]); }
      return out;
    },
  },
  {
    id: "cm2-subsets", grade: 4, unit: 3, lesson: "Ⅲ-1", title: "부분집합의 개수 — 넣을까, 뺄까", type: "조작", time: "8분",
    tags: ["부분집합", "2ⁿ", "수형도"], links: ["cm1-sandwich", "cm2-venn"],
    desc: "원소마다 ‘넣는다/뺀다’를 차례로 정하는 수형도로 부분집합을 모두 만들고, 원소가 하나 늘 때마다 부분집합의 개수가 두 배가 되는 이유를 봅니다.",
    obs: ["원소 n개인 집합의 부분집합은 2ⁿ개입니다.", "특정 원소를 반드시 포함하는 부분집합은 그 원소를 빼고 센 2ⁿ⁻¹개입니다.", "공집합과 자기 자신도 부분집합입니다."],
    q: "{a, b, c, d, e}의 부분집합 중 a는 포함하고 b는 포함하지 않는 것은 몇 개일까요?",
    formula: "부분집합의 개수 2ⁿ · 특정 원소 k개를 반드시 포함 2ⁿ⁻ᵏ",
    en: { title: "Counting Subsets", desc: "Decide in or out for each element; the number of subsets doubles each time." },
    view: BOX,
    params: [{ key: "n", label: "원소의 개수 n", min: 1, max: 5, step: 1, value: 3 }, { key: "must", label: "a를 반드시 포함", type: "check", value: false }],
    draw(s, g) {
      const n = s.n, E = "abcde", x = (i, l) => 0.6 + ((i + 0.5) / 2 ** l) * 14.8, yv = (l) => 10.3 - (l * 8.2) / n;
      g.text([8, 10.3], "{ }", { dy: -8, size: 12, color: "muted" });
      const walk = (l, i, set) => {
        if (l === n) { const ok = !s.must || set.includes("a"); g.text([x(i, l), yv(l)], set.length ? `{${set.join(",")}}` : "∅", { dy: 18, size: n > 4 ? 8.5 : 11, color: ok ? "a" : "muted", bold: ok }); return; }
        [[1, "넣기"], [0, "빼기"]].forEach(([on], t) => { const ni = i * 2 + t, P0 = [l === 0 ? 8 : x(i, l), yv(l)], P1 = [x(ni, l + 1), yv(l + 1)], blocked = s.must && l === 0 && !on; g.seg(P0, P1, { color: blocked ? "grid" : on ? "c" : "b", w: 1.8 }); if (n <= 3) g.text(lerp(P0, P1, 0.5), `${on ? "+" : "−"}${E[l]}`, { size: 11, color: on ? "c" : "b", bold: true, dx: t ? 10 : -10 }); walk(l + 1, ni, on ? [...set, E[l]] : set); });
      };
      walk(0, 0, []);
    },
    metrics(s) { return [["부분집합의 개수", `2${"⁰¹²³⁴⁵"[s.n]} = ${2 ** s.n}개`], ["a를 반드시 포함", `2${"⁰¹²³⁴⁵"[s.n - 1]} = ${2 ** (s.n - 1)}개`, s.must ? "key" : ""]]; },
  },
  // ───────── 기하 ─────────
  {
    id: "geo-cylinder-cut", grade: 6, unit: 2, lesson: "Ⅱ-3 예제", title: "원기둥을 비스듬히 자른 단면은 타원", type: "3D", time: "10분",
    tags: ["단면", "정사영", "타원"], links: ["geo-projection", "cross-section"],
    desc: "원기둥을 밑면과 θ의 각을 이루는 평면으로 자르면 단면이 타원이 되고, 그 정사영이 밑면의 원이라는 사실로 단면의 넓이가 πr²/cos θ임을 구합니다.",
    obs: ["단면의 정사영은 밑면의 원과 같습니다.", "그러므로 (단면의 넓이) × cos θ = πr²입니다.", "단면 타원의 짧은 반지름은 r, 긴 반지름은 r/cos θ입니다."],
    q: "반지름이 3인 원기둥을 밑면과 30°를 이루는 평면으로 자른 단면의 넓이는 얼마일까요?",
    formula: "S′ = S cos θ ⇒ S = πr² / cos θ",
    en: { title: "Slicing a Cylinder at an Angle", desc: "A tilted cut of a cylinder is an ellipse whose projection is the base circle." },
    space: true, cam: { yaw: 30, pitch: 18, scale: 56 },
    params: [{ key: "r", label: "반지름 r", min: 1, max: 2.2, step: 0.1, value: 1.6 }, { key: "t", label: "자르는 각 θ", min: 0, max: 60, step: 1, value: 30, unit: "°" }],
    anim: { key: "t", min: 0, max: 60, speed: 12, label: "기울이기" },
    draw(s, g) {
      const r = s.r, H = 2.6, th = deg(s.t), E = [1, 0, 0], F = [0, 1, 0];
      g.circle([0, 0, -H], E, F, r, { color: "b", w: 1.8, fill: "b", fo: 0.12 }).circle([0, 0, H], E, F, r, { color: "b", w: 1.4 });
      for (let k = 0; k < 16; k++) { const a = (k * Math.PI) / 8; g.seg([r * Math.cos(a), r * Math.sin(a), -H], [r * Math.cos(a), r * Math.sin(a), H], { color: "b", w: 0.8, opacity: 0.4 }); }
      const cut = Array.from({ length: 73 }, (_, i) => { const a = (2 * Math.PI * i) / 72, x = r * Math.cos(a), y = r * Math.sin(a); return [x, y, x * Math.tan(th)]; });
      g.face(cut, { fill: "a", color: "a", fo: 0.45, w: 2.6, bias: 2 });
      cut.filter((_, i) => i % 9 === 0).forEach((p) => g.seg(p, [p[0], p[1], -H], { color: "muted", w: 0.8, dash: "3 4", bias: 1 }));
    },
    metrics(s) { const c = Math.cos(deg(s.t)), base = Math.PI * s.r * s.r; return [["긴 반지름 r/cos θ", fmt(s.r / c, 3)], ["짧은 반지름", fmt(s.r, 3)], ["단면의 넓이 πr²/cos θ", fmt(base / c, 3), "key"], ["정사영(밑면)의 넓이", fmt(base, 3)]]; },
  },
  {
    id: "geo-plane-angle", grade: 6, unit: 4, lesson: "Ⅳ-2 예제", title: "법선벡터로 구하는 두 평면·직선과 평면의 각", type: "3D", time: "12분",
    tags: ["법선벡터", "이면각", "직선과 평면의 각"], links: ["geo-dihedral", "geo-plane-eq", "geo-dot-product"],
    desc: "두 평면이 이루는 각은 두 법선벡터가 이루는 각으로, 직선과 평면이 이루는 각은 방향벡터와 법선벡터가 이루는 각의 여각으로 구합니다.",
    obs: ["두 평면이 이루는 각 θ에 대해 cos θ = |n₁ · n₂| / (|n₁||n₂|)입니다.", "직선과 평면이 이루는 각 θ에 대해 sin θ = |u · n| / (|u||n|)입니다.", "법선벡터끼리 수직이면 두 평면도 수직입니다."],
    q: "평면 2x + y + z + 1 = 0과 xy평면이 이루는 각의 코사인 값은 얼마일까요?",
    formula: "cos θ = |n₁ · n₂| / (|n₁||n₂|) · sin θ = |u · n| / (|u||n|)",
    en: { title: "Angles Between Planes and Lines via Normals", desc: "Use normal and direction vectors to find angles between planes and between a line and a plane." },
    space: true, cam: { yaw: 36, pitch: 22, scale: 48 },
    params: [{ key: "mode", label: "구하는 각", type: "seg", value: "pp", options: [["pp", "두 평면"], ["lp", "직선과 평면"]] }, { key: "a", label: "a", min: -2, max: 2, step: 1, value: 2 }, { key: "b", label: "b", min: -2, max: 2, step: 1, value: 1 }, { key: "c", label: "c", min: -2, max: 2, step: 1, value: 1 }],
    draw(s, g) {
      const v = [s.a, s.b, s.c]; if (len(v) < 1e-9) { g.note(20, 30, "벡터가 0이 되지 않게 해 주세요", { color: "d", bold: true }); return; }
      const n1 = [0, 0, 1]; g.plane([0, 0, 0], [1, 0, 0], [0, 1, 0], 2.6, 2.6, { fill: "b", color: "b", fo: 0.12, grid: 0.65 }); g.vec([0, 0, 0], [0, 0, 1.8], { color: "b", w: 3, label: "n₁" });
      if (s.mode === "pp") { const nn = norm(v), e1 = norm(Math.abs(nn[2]) < 0.95 ? cross(nn, [0, 0, 1]) : cross(nn, [1, 0, 0])), e2 = norm(cross(nn, e1)); g.plane([0, 0, 0], e1, e2, 2.2, 2.2, { fill: "a", color: "a", fo: 0.16 }); g.vec([0, 0, 0], mul(nn, 1.8), { color: "a", w: 3, label: "n₂" }); }
      else { const u = norm(v); g.seg(mul(u, -2.6), mul(u, 2.6), { color: "a", w: 3.2, bias: 2 }); g.vec([0, 0, 0], mul(u, 1.6), { color: "a", w: 3, label: "u" }); g.seg(mul(u, 2.6), [2.6 * u[0], 2.6 * u[1], 0], { color: "muted", w: 1.2, dash: "4 4" }); g.seg([0, 0, 0], [2.6 * u[0], 2.6 * u[1], 0], { color: "e", w: 2, dash: "5 4" }); }
    },
    metrics(s) { const v = [s.a, s.b, s.c]; if (len(v) < 1e-9) return ["벡터가 영벡터예요."]; const c = Math.abs(v[2]) / len(v); if (s.mode === "pp") return [["n₁ · n₂", String(s.c)], ["cos θ", `|${s.c}| / √${dot(v, v)} = ${fmt(c, 4)}`], ["두 평면이 이루는 각", `${fmt(rad2deg(Math.acos(c)), 2)}°`, "key"]]; return [["u · n", String(s.c)], ["sin θ", fmt(c, 4)], ["직선과 평면이 이루는 각", `${fmt(rad2deg(Math.asin(c)), 2)}°`, "key"]]; },
  },
  {
    id: "geo-sphere-diameter", grade: 6, unit: 4, lesson: "Ⅳ-2 생각 키우기", title: "AP · BP = 0인 점 P는 어디에 있을까", type: "3D", time: "10분",
    tags: ["내적", "구", "지름"], links: ["geo-sphere-eq", "g3-inscribed-angle", "geo-dot-product"],
    desc: "좌표공간에서 두 점 A, B에 대해 AP와 BP가 수직(내적 0)인 점 P를 움직여 보며, 그 자취가 선분 AB를 지름으로 하는 구임을 확인합니다. 평면에서는 원(탈레스 정리)이 됩니다.",
    obs: ["P가 구 위에 있으면 ∠APB = 90°, 즉 AP · BP = 0입니다.", "P가 구 안쪽이면 내적이 음수(둔각), 바깥이면 양수(예각)입니다.", "중점 M에서 P까지의 거리가 AB/2일 때 내적이 0입니다."],
    q: "AP · BP = (p − a) · (p − b) = 0을 전개해 구의 방정식을 얻어 보세요.",
    formula: "(p − a) · (p − b) = 0 ⇔ |p − (a + b)/2| = |a − b|/2",
    en: { title: "Where Is AP · BP = 0?", desc: "Points with perpendicular AP and BP form the sphere on diameter AB." },
    space: true, cam: { yaw: 30, pitch: 20, scale: 56 },
    params: [{ key: "u", label: "P의 경도", min: 0, max: 360, step: 1, value: 60, unit: "°" }, { key: "w", label: "P의 위도", min: -85, max: 85, step: 1, value: 35, unit: "°" }, { key: "k", label: "중점에서의 거리 (반지름 배)", min: 0.4, max: 1.6, step: 0.05, value: 1 }],
    anim: { key: "u", min: 0, max: 360, speed: 40, loop: "wrap", label: "P 돌리기" },
    draw(s, g) {
      const A = [-2, 0, 0], B = [2, 0, 0], R = 2, P = [R * s.k * Math.cos(deg(s.w)) * Math.cos(deg(s.u)), R * s.k * Math.cos(deg(s.w)) * Math.sin(deg(s.u)), R * s.k * Math.sin(deg(s.w))];
      g.sphere([0, 0, 0], R, { color: "b" });
      g.seg(A, B, { color: "ink", w: 2, dash: "5 4" });
      const d = dot(sub(P, A), sub(P, B));
      g.seg(A, P, { color: "a", w: 2.8, bias: 3 }).seg(B, P, { color: "a", w: 2.8, bias: 3 });
      if (Math.abs(d) < 0.05) g.right(P, A, B, { size: 0.3, color: "d" });
      g.point(A, "A", { color: "ink" }).point(B, "B", { color: "ink" }).point(P, "P", { color: Math.abs(d) < 0.05 ? "d" : "a", r: 6 });
    },
    metrics(s) { const A = [-2, 0, 0], B = [2, 0, 0], R = 2, P = [R * s.k * Math.cos(deg(s.w)) * Math.cos(deg(s.u)), R * s.k * Math.cos(deg(s.w)) * Math.sin(deg(s.u)), R * s.k * Math.sin(deg(s.w))], d = dot(sub(P, A), sub(P, B)); return [["AP · BP", fmt(d, 3), "key"], ["∠APB", `${fmt(rad2deg(Math.acos(clamp(d / (len(sub(P, A)) * len(sub(P, B))), -1, 1))), 1)}°`], ["P의 위치", Math.abs(s.k - 1) < 1e-9 ? "구 위" : s.k < 1 ? "구 안쪽 (내적 < 0)" : "구 바깥 (내적 > 0)"]]; },
  },
  {
    id: "geo-slope-tangent", grade: 6, unit: 1, lesson: "Ⅰ-5 탐구하기", title: "기울기가 주어진 이차곡선의 접선", type: "조작", time: "10분",
    tags: ["접선", "판별식", "기울기"], links: ["geo-tangent-reflect", "c2-tangent"],
    desc: "기울기가 m인 직선을 위아래로 옮기며 이차곡선에 접하는 순간을 찾고, 타원·쌍곡선·포물선에서 기울기 m인 접선의 공식을 확인합니다.",
    obs: ["타원에는 기울기가 m인 접선이 항상 두 개 있습니다.", "쌍곡선에서는 |m|이 점근선의 기울기보다 커야 접선이 생깁니다.", "포물선 y² = 4px에서 기울기 m인 접선은 하나입니다."],
    q: "쌍곡선 x²/9 − y²/4 = 1에 기울기 1/2인 접선을 그을 수 있을까요?",
    formula: "타원 y = mx ± √(a²m² + b²) · 쌍곡선 y = mx ± √(a²m² − b²) · 포물선 y = mx + p/m",
    en: { title: "Tangents with a Given Slope", desc: "Slide a line of slope m until it touches a conic and compare with the formulas." },
    view: V,
    params: [{ key: "kind", label: "곡선", type: "seg", value: "ell", options: [["ell", "타원 x²/16 + y²/9 = 1"], ["hyp", "쌍곡선 x²/9 − y²/4 = 1"], ["par", "포물선 y² = 8x"]] }, { key: "m", label: "기울기 m", min: -3, max: 3, step: 0.1, value: 0.8 }, { key: "k", label: "직선의 y절편 k", min: -8, max: 8, step: 0.05, value: 2 }],
    anim: { key: "k", min: -8, max: 8, speed: 3, label: "직선 옮기기" },
    drags: { K: { at: (s) => [0, s.k], move: (s, p) => (s.k = p[1]), color: "b", label: "y절편" } },
    ks(s) { const m = s.m; if (s.kind === "ell") { const v = Math.sqrt(16 * m * m + 9); return [v, -v]; } if (s.kind === "hyp") { const q = 9 * m * m - 4; return q > 0 ? [Math.sqrt(q), -Math.sqrt(q)] : []; } return Math.abs(m) > 1e-6 ? [2 / m] : []; },
    touch(s, k) { const m = s.m; if (s.kind === "ell") return [(-16 * m) / k, 9 / k]; if (s.kind === "hyp") return [(-9 * m) / k, -4 / k]; return [2 / (m * m), 4 / m]; },
    draw(s, g) {
      g.grid();
      if (s.kind === "ell") g.param((u) => [4 * Math.cos(u), 3 * Math.sin(u)], 0, 6.3, { color: "a", w: 3 });
      if (s.kind === "hyp") [1, -1].forEach((sg) => g.param((u) => [sg * 3 * Math.cosh(u), 2 * Math.sinh(u)], -2.2, 2.2, { color: "a", w: 3 }));
      if (s.kind === "par") g.param((y) => [(y * y) / 8, y], -5, 5, { color: "a", w: 3 });
      this.ks(s).forEach((k) => { g.line([0, k], [1, k + s.m], { color: "c", w: 1.6, dash: "6 4" }); const T = this.touch(s, k); g.point(T, "접점", { color: "c", r: 5 }); });
      g.line([0, s.k], [1, s.k + s.m], { color: "b", w: 3 });
    },
    metrics(s) { const K = this.ks(s), near = K.some((k) => Math.abs(k - s.k) < 0.06); return [["접하는 y절편", K.length ? K.map((k) => fmt(k, 3)).join(", ") : "없음 (접선이 없음)"], ["지금 직선", `y = ${fmt(s.m)}x ${s.k >= 0 ? "+" : "−"} ${fmt(Math.abs(s.k), 2)}`], ["상태", near ? "접함" : "접하지 않음", "key"]]; },
  },
  // ───────── 중1 ─────────
  {
    id: "m1-triangle-tear", grade: 1, unit: 6, lesson: "6.3 생각해요", title: "삼각형 세 각을 오려 한 점에 모으기", type: "조작", time: "8분",
    tags: ["내각의 합", "180°", "평각"], links: ["m1-triangle-exterior", "interior-sum"],
    desc: "삼각형 모양 종이의 세 귀퉁이를 오려 한 점에 나란히 모으면 일직선(평각)이 된다는 것을 애니메이션으로 보고, 삼각형 모양을 바꿔도 항상 180°임을 확인합니다.",
    obs: ["세 조각을 모으면 빈틈없이 일직선이 됩니다.", "삼각형의 모양이 달라도 결과는 같습니다.", "그래서 삼각형의 세 내각의 크기의 합은 180°입니다."],
    q: "사각형의 네 귀퉁이를 오려 모으면 어떻게 될까요?",
    formula: "∠A + ∠B + ∠C = 180°",
    en: { title: "Tear Off the Three Corners", desc: "Gather the three torn corners of a triangle at one point to form a straight angle." },
    view: V, points: { A: [-0.8, 3.2], B: [-5.2, -1.2], C: [3.8, -1.6] },
    params: [{ key: "t", label: "모으기", min: 0, max: 1, step: 0.01, value: 1, show: (v) => `${Math.round(v * 100)}%` }],
    anim: { key: "t", min: 0, max: 1, speed: 0.45, label: "오려서 모으기" },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const { A, B, C: Cc } = s, O = [0, -3.8], tt = (1 - Math.cos(Math.PI * s.t)) / 2;
      g.seg([-6.5, O[1]], [6.5, O[1]], { color: "ink", w: 2, dash: "6 4" });
      g.poly([A, B, Cc], { fill: "b", fo: 0.06, color: "ink", w: 2.4, dash: s.t > 0.05 ? "4 4" : null });
      const vs = [[A, B, Cc, "a"], [B, Cc, A, "c"], [Cc, A, B, "e"]]; let start = 0;
      vs.forEach(([v, p, q, col]) => {
        const a1 = Math.atan2(p[1] - v[1], p[0] - v[0]), a2 = Math.atan2(q[1] - v[1], q[0] - v[0]); let a0 = a1, w = a2 - a1; while (w < 0) w += 2 * Math.PI; if (w > Math.PI) { a0 = a2; w = 2 * Math.PI - w; }
        const vv = lerp(v, O, tt), aa = a0 + (((start - a0 + 3 * Math.PI) % (2 * Math.PI)) - Math.PI) * tt;
        wedge(g, vv, aa, w, 1.3, { color: col, fo: 0.65, label: `${fmt(rad2deg(w), 0)}°` });
        start += w;
      });
      [[A, "A"], [B, "B"], [Cc, "C"]].forEach(([p, n]) => { g.point(p, n); g.handle(p, n); });
    },
    metrics(s) { const a = rad2deg(angAt(s.A, s.B, s.C)), b = rad2deg(angAt(s.B, s.C, s.A)), c = rad2deg(angAt(s.C, s.A, s.B)); return [["∠A + ∠B + ∠C", `${fmt(a, 1)}° + ${fmt(b, 1)}° + ${fmt(c, 1)}°`], ["합", `${fmt(a + b + c, 1)}° (평각)`, "key"]]; },
  },
  // ───────── 확률과 통계 ─────────
  {
    id: "pst-total-prob", grade: 8, unit: 2, lesson: "Ⅱ-5 예제", title: "두 공장의 불량품 — 확률 나무와 베이즈", type: "조작", time: "12분",
    tags: ["전확률", "곱셈정리", "베이즈"], links: ["pst-bayes", "pst-trials"],
    desc: "A 공장과 B 공장의 생산 비율과 불량률로 확률 나무를 그려 불량품이 나올 전체 확률을 구하고, 불량품 하나가 A 공장 제품일 확률을 거꾸로 계산합니다.",
    obs: ["한 가지의 확률은 그 경로의 확률을 곱한 것입니다(곱셈정리).", "불량품이 나오는 모든 경로의 확률을 더하면 전체 불량률입니다.", "P(A | 불량) = P(A ∩ 불량) / P(불량)입니다."],
    q: "A 공장 70%, B 공장 30%, 불량률이 각각 2%, 5%일 때 불량품이 A 공장 제품일 확률은?",
    formula: "P(E) = P(A)P(E | A) + P(B)P(E | B) · P(A | E) = P(A)P(E | A) / P(E)",
    en: { title: "Two Factories: Probability Trees and Bayes", desc: "Build a tree to get the total defect rate and reverse it with Bayes' rule." },
    view: BOX,
    params: [{ key: "pa", label: "A 공장 생산 비율", min: 0.05, max: 0.95, step: 0.05, value: 0.7 }, { key: "da", label: "A 공장 불량률", min: 0.01, max: 0.2, step: 0.01, value: 0.02 }, { key: "db", label: "B 공장 불량률", min: 0.01, max: 0.2, step: 0.01, value: 0.05 }],
    draw(s, g) {
      const pb = 1 - s.pa, R = [1, 5.5], A = [5.6, 8.4], B = [5.6, 2.6], leaf = [[11, 9.8], [11, 7], [11, 4], [11, 1.2]];
      const e = (P, Q, lab, col, w) => { g.seg(P, Q, { color: col, w }); g.text(lerp(P, Q, 0.5), lab, { dy: -6, size: 12.5, bold: true, color: col, mono: true }); };
      e(R, A, fmt(s.pa, 2), "b", 2.4); e(R, B, fmt(pb, 2), "c", 2.4);
      e(A, leaf[0], fmt(s.da, 2), "d", 3); e(A, leaf[1], fmt(1 - s.da, 2), "muted", 1.6); e(B, leaf[2], fmt(s.db, 2), "d", 3); e(B, leaf[3], fmt(1 - s.db, 2), "muted", 1.6);
      [[A, "A 공장"], [B, "B 공장"]].forEach(([p, n]) => { g.circle(p, 0.5, { color: "ink", fill: "paper", fo: 1, w: 1.6, layer: "point" }); g.text(p, n, { dx: -8, dy: -16, anchor: "end", size: 12, bold: true }); });
      const vals = [s.pa * s.da, s.pa * (1 - s.da), pb * s.db, pb * (1 - s.db)], nm = ["불량", "정상", "불량", "정상"];
      leaf.forEach((p, i) => g.text(p, `${nm[i]}  ${fmt(vals[i], 4)}`, { dx: 10, dy: 5, anchor: "start", size: 13, bold: nm[i] === "불량", color: nm[i] === "불량" ? "d" : "muted", mono: true }));
      const tot = vals[0] + vals[2], X = 13.6, W = 1.6; g.poly([[X, 1], [X + W, 1], [X + W, 1 + 8.6 * (vals[0] / tot)], [X, 1 + 8.6 * (vals[0] / tot)]], { fill: "b", fo: 0.55, color: "b", w: 1 }); g.poly([[X, 1 + 8.6 * (vals[0] / tot)], [X + W, 1 + 8.6 * (vals[0] / tot)], [X + W, 9.6], [X, 9.6]], { fill: "c", fo: 0.55, color: "c", w: 1 });
      g.text([X + W / 2, 9.6], "불량품의 출처", { dy: -8, size: 11.5, bold: true, color: "muted" });
    },
    metrics(s) { const pb = 1 - s.pa, E = s.pa * s.da + pb * s.db; return [["P(불량)", `${fmt(s.pa, 2)}·${fmt(s.da, 2)} + ${fmt(pb, 2)}·${fmt(s.db, 2)} = ${fmt(E, 4)}`], ["P(A | 불량)", fmt((s.pa * s.da) / E, 4), "key"], ["P(B | 불량)", fmt((pb * s.db) / E, 4)]]; },
  },
  {
    id: "pst-sample-enum", grade: 8, unit: 4, lesson: "Ⅳ-2 예제", title: "표본을 모두 나열해 구하는 표본평균의 분포", type: "데이터", time: "10분",
    tags: ["표본평균", "복원추출", "모든 경우"], links: ["pst-sample-mean", "pst-expectation"],
    desc: "숫자가 적힌 공 몇 개로 이루어진 모집단에서 크기 n인 표본을 복원추출하는 모든 경우를 나열해 표본평균의 확률분포를 정확히 그리고, 평균은 그대로이고 분산은 σ²/n이 됨을 확인합니다.",
    obs: ["크기 n인 표본은 (모집단 크기)ⁿ가지이고, 모두 같은 확률로 뽑힙니다.", "E(X̄)는 모평균 m과 같습니다.", "n이 커질수록 X̄의 분포는 가운데로 모이고 종 모양에 가까워집니다."],
    q: "모집단이 {1, 3, 5, 7}일 때 크기 2인 표본의 표본평균이 4일 확률은 얼마일까요?",
    formula: "E(X̄) = m · V(X̄) = σ²/n",
    en: { title: "Sampling Distribution by Enumeration", desc: "List every sample to get the exact distribution of the sample mean." },
    view: BOX,
    params: [{ key: "pop", label: "모집단 (공에 적힌 수)", type: "seg", value: "a", options: [["a", "{1, 3, 5, 7}"], ["b", "{2, 2, 4, 8}"], ["c", "{0, 1, 1, 6}"]] }, { key: "n", label: "표본의 크기 n", min: 1, max: 5, step: 1, value: 2 }],
    anim: { key: "n", min: 1, max: 5, speed: 0.8, label: "n 늘리기" },
    P: { a: [1, 3, 5, 7], b: [2, 2, 4, 8], c: [0, 1, 1, 6] },
    dist(s) { const P = this.P[s.pop], N = P.length, tot = N ** s.n, map = new Map(); for (let i = 0; i < tot; i++) { let x = i, sum = 0; for (let k = 0; k < s.n; k++) { sum += P[x % N]; x = Math.floor(x / N); } const m = Math.round((sum / s.n) * 1000) / 1000; map.set(m, (map.get(m) || 0) + 1); } return { tot, pts: [...map.entries()].sort((a, b) => a[0] - b[0]) }; },
    draw(s, g) {
      const P = this.P[s.pop], mn = Math.min(...P), mx = Math.max(...P), { tot, pts } = this.dist(s), ymax = Math.max(...pts.map(([, c]) => c / tot)) * 1.15;
      const M = (x, y) => [1.6 + ((x - mn + 0.5) / (mx - mn + 1)) * 13.8, 1.4 + (y / ymax) * 8.4];
      g.seg(M(mn - 0.5, 0), M(mx + 0.5, 0), { color: "axis", w: 1.4 });
      for (let x = mn; x <= mx; x++) g.text(M(x, 0), String(x), { dy: 17, size: 11.5, color: "muted" });
      const bw = Math.min(0.9, 13.8 / (mx - mn + 1) / Math.max(1, s.n) * 0.8);
      pts.forEach(([x, c]) => { const p0 = M(x, 0), p1 = M(x, c / tot); g.poly([[p0[0] - bw / 2, p0[1]], [p0[0] + bw / 2, p0[1]], [p0[0] + bw / 2, p1[1]], [p0[0] - bw / 2, p1[1]]], { fill: "b", fo: 0.5, color: "b", w: 1 }); if (pts.length <= 13) g.text(p1, `${c}/${tot}`, { dy: -6, size: 10.5, color: "b", mono: true }); });
      const m = P.reduce((a, b) => a + b, 0) / P.length; g.seg(M(m, 0), M(m, ymax * 0.95), { color: "d", w: 1.6, dash: "5 4" }).text(M(m, ymax * 0.95), `m = ${fmt(m)}`, { dy: -4, color: "d", bold: true, size: 12 });
      g.text([8, 10.5], `모집단 {${P.join(", ")}}에서 크기 ${s.n}인 표본 ${tot}가지`, { size: 13, bold: true, color: "muted" });
    },
    metrics(s) { const P = this.P[s.pop], m = P.reduce((a, b) => a + b, 0) / P.length, v = P.reduce((a, b) => a + (b - m) ** 2, 0) / P.length, { tot, pts } = this.dist(s), E = pts.reduce((a, [x, c]) => a + (x * c) / tot, 0), VV = pts.reduce((a, [x, c]) => a + ((x - E) ** 2 * c) / tot, 0); return [["표본의 수", `${P.length}^${s.n} = ${tot}`], ["E(X̄) (모평균 m)", `${fmt(E, 4)} (${fmt(m, 4)})`], ["V(X̄) (σ²/n)", `${fmt(VV, 4)} (${fmt(v / s.n, 4)})`, "key"]]; },
  },
];
