// 대수 — Ⅱ 지수함수와 로그함수 · Ⅴ 등차수열과 등비수열 · Ⅵ 수열의 합 (16차 이후 추가)
import { fmt, frac, clamp, lerp } from "./hs-core.js";

const G = 5;
const BOX = { x: [0, 16], y: [0, 11], pad: 6 };
const baseStr = (a) => (Math.abs(a - 0.5) < 1e-9 ? "1/2" : Math.abs(a - 1 / 3) < 1e-3 ? "1/3" : Math.abs(a - 0.25) < 1e-9 ? "1/4" : fmt(a, 2));
const SUBS = "₀₁₂₃₄₅₆₇₈₉";
const logOf = (a) => "log" + (Math.abs(a - 0.5) < 1e-9 ? "½" : Math.abs(a - 0.25) < 1e-9 ? "¼" : String(a).replace(/[0-9]/g, (d) => SUBS[d]));
// 정육면체 하나 (공간)
function cube(g, x, y, z, s, o) {
  const P = (u, v, w) => [x + u * s, y + v * s, z + w * s];
  [[P(0, 0, 0), P(1, 0, 0), P(1, 1, 0), P(0, 1, 0)], [P(0, 0, 1), P(1, 0, 1), P(1, 1, 1), P(0, 1, 1)], [P(0, 0, 0), P(1, 0, 0), P(1, 0, 1), P(0, 0, 1)], [P(0, 1, 0), P(1, 1, 0), P(1, 1, 1), P(0, 1, 1)], [P(0, 0, 0), P(0, 1, 0), P(0, 1, 1), P(0, 0, 1)], [P(1, 0, 0), P(1, 1, 0), P(1, 1, 1), P(1, 0, 1)]]
    .forEach((f) => g.face(f, { fill: o.fill, color: "ink", fo: o.fo ?? 0.55, w: 0.6 }));
}
const SUPC = { x: "ˣ", "−": "⁻", "+": "⁺", "(": "⁽", ")": "⁾", 0: "⁰", 1: "¹", 2: "²", 3: "³", 4: "⁴", 5: "⁵", 6: "⁶", 7: "⁷", 8: "⁸", 9: "⁹", ".": "·" };
const supS = (t) => [...String(t).replace(/\s/g, "")].map((c) => SUPC[c] ?? c).join("");
const BASES = [["0.25", "1/4"], ["0.5", "1/2"], ["2", "2"], ["3", "3"], ["10", "10"]];

export default [
  // ───────── Ⅱ 지수함수와 로그함수 ─────────
  {
    id: "alg-exp-graph", grade: G, unit: 2, lesson: "Ⅱ-1", title: "지수함수 y = aˣ의 그래프 — 밑 바꾸기와 평행이동", type: "조작", time: "12분",
    tags: ["지수함수", "점근선", "평행이동"], links: ["alg-exp-log-inverse", "alg-tablet"],
    desc: "밑 a를 바꾸며 y = aˣ의 그래프가 항상 점 (0, 1)을 지나고 x축을 점근선으로 가짐을 확인하고, a > 1과 0 < a < 1에서 증가·감소가 바뀌는 것, y = aˣ⁻ᵖ + q로 평행이동한 그래프를 관찰합니다.",
    obs: ["모든 밑 a에 대하여 y = aˣ의 그래프는 점 (0, 1)을 지납니다.", "a > 1이면 x가 커질 때 y도 커지고, 0 < a < 1이면 y는 작아집니다.", "y = aˣ와 y = (1/a)ˣ의 그래프는 y축에 대하여 대칭입니다.", "y = aˣ⁻ᵖ + q의 그래프의 점근선은 y = q입니다."],
    q: "y = 2ˣ⁻¹ + 3의 그래프가 지나는 점 가운데 y = 2ˣ의 (0, 1)이 옮겨 간 점은 어디일까요?",
    formula: "y = aˣ (a > 0, a ≠ 1) · 점근선 y = 0 · 지나는 점 (0, 1)",
    en: { title: "Graphs of Exponential Functions", desc: "Change the base and translate y = a^x." },
    view: { x: [-5.5, 5.5], y: [-2.5, 7.5] },
    params: [
      { key: "a", label: "밑 a", min: 0.2, max: 4, step: 0.05, value: 2 },
      { key: "p", label: "x축 방향 이동 p", min: -3, max: 3, step: 0.5, value: 0 },
      { key: "q", label: "y축 방향 이동 q", min: -2, max: 3, step: 0.5, value: 0 },
      { key: "mirror", label: "y = (1/a)ˣ 같이 보기", type: "check", value: true },
    ],
    anim: { key: "a", min: 0.2, max: 4, speed: 0.8, loop: "bounce", label: "밑 바꾸기" },
    derive(s) { if (Math.abs(s.a - 1) < 0.02) s.a = s.a < 1 ? 0.95 : 1.05; },
    drags: { O: { at: (s) => [s.p, 1 + s.q], move: (s, p) => { s.p = clamp(Math.round(p[0] * 2) / 2, -3, 3); s.q = clamp(Math.round((p[1] - 1) * 2) / 2, -2, 3); }, color: "a", label: "(0, 1)이 옮겨 간 점" } },
    draw(s, g) {
      const f = (x) => s.a ** (x - s.p) + s.q;
      g.grid();
      if (s.mirror) g.fx((x) => (1 / s.a) ** x, { color: "e", w: 2, dash: "6 5" });
      if (s.p || s.q) g.fx((x) => s.a ** x, { color: "muted", w: 1.6, dash: "4 4", opacity: 0.8 });
      g.line([0, s.q], [1, s.q], { color: "d", w: 1.4, dash: "7 5" });
      g.fx(f, { color: "a", w: 3.4 });
      g.point([s.p + 1, s.a + s.q], `(${fmt(s.p + 1)}, ${fmt(s.a + s.q, 2)})`, { color: "b", r: 4.5 });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], `y = ${baseStr(s.a).includes("/") ? `(${baseStr(s.a)})` : baseStr(s.a)}${supS(s.p ? `x ${s.p > 0 ? "−" : "+"} ${fmt(Math.abs(s.p))}` : "x")}${s.q ? ` ${s.q > 0 ? "+" : "−"} ${fmt(Math.abs(s.q))}` : ""}`, { anchor: "start", bold: true, color: "a" });
      if (s.mirror) g.text([g.xr[0] + 0.3, g.yr[1] - 1.4], `y = (1/${baseStr(s.a)})ˣ`, { anchor: "start", bold: true, color: "e" });
    },
    metrics(s) {
      return [
        ["증가·감소", s.a > 1 ? "a > 1 → 증가하는 함수" : "0 < a < 1 → 감소하는 함수", "key"],
        ["점근선", `y = ${fmt(s.q)}`],
        ["(0, 1)이 옮겨 간 점", `(${fmt(s.p)}, ${fmt(1 + s.q)})`],
        ["치역", `y > ${fmt(s.q)}`],
      ];
    },
    predict: [
      { q: "y = 2ˣ와 y = (1/2)ˣ의 그래프는 어떤 관계일까요?", options: [["y", "y축에 대하여 대칭"], ["x", "x축에 대하여 대칭"], ["o", "원점에 대하여 대칭"], ["yx", "직선 y = x에 대하여 대칭"]], set: (s) => Object.assign(s, { a: 2, p: 0, q: 0, mirror: false }), reveal: (s) => (s.mirror = true), answer: () => "y", why: "(1/2)ˣ = 2⁻ˣ이므로 x 대신 −x를 넣은 그래프, 곧 y축 대칭입니다." },
      { q: "y = 3ˣ⁻² − 1의 그래프의 점근선은 y = □입니다. □는?", set: (s) => Object.assign(s, { a: 3, p: 0, q: 0 }), reveal: (s) => Object.assign(s, { p: 2, q: -1 }), answer: () => -1, why: "y = 3ˣ의 점근선 y = 0을 y축 방향으로 −1만큼 옮기면 y = −1입니다." },
      { q: "밑 a가 1보다 크면서 점점 커지면, x > 0 부분의 그래프는 어떻게 될까요?", options: [["up", "더 가파르게 올라간다"], ["down", "더 완만해진다"], ["same", "변하지 않는다"]], set: (s) => Object.assign(s, { a: 1.5, p: 0, q: 0 }), reveal: (s) => (s.a = 3.5), answer: () => "up", why: "x > 0에서는 밑이 클수록 aˣ가 커집니다. 반대로 x < 0에서는 0에 더 빨리 가까워집니다." },
    ],
  },
  {
    id: "alg-exp-log-inverse", grade: G, unit: 2, lesson: "Ⅱ-2", title: "지수함수와 로그함수는 서로 역함수", type: "2D", time: "10분",
    tags: ["로그함수", "역함수", "y = x 대칭"], links: ["alg-exp-graph", "cm2-inverse"],
    desc: "y = aˣ 위의 점 P(t, aᵗ)를 직선 y = x에 대칭이동하면 P′(aᵗ, t)가 y = logₐ x 위에 놓임을 확인하고, 두 그래프의 정의역·치역·점근선이 서로 바뀌는 것을 봅니다.",
    obs: ["y = logₐ x는 y = aˣ의 역함수이므로 두 그래프는 직선 y = x에 대하여 대칭입니다.", "y = aˣ가 지나는 (0, 1)은 y = logₐ x에서 (1, 0)이 됩니다.", "y = aˣ의 점근선 y = 0은 y = logₐ x에서 x = 0(y축)이 됩니다."],
    q: "log₂ 8 = 3임을 두 그래프 위의 어떤 두 점으로 설명할 수 있을까요?",
    formula: "y = aˣ ⇔ x = logₐ y · aᵗ = s ⇔ logₐ s = t",
    en: { title: "Exponential and Logarithmic Functions are Inverses", desc: "Reflect points of y = a^x in y = x." },
    view: { x: [-4, 8], y: [-4, 8] },
    params: [
      { key: "a", label: "밑 a", type: "seg", value: "2", options: BASES },
      { key: "t", label: "점 P의 x좌표 t", min: -3, max: 3, step: 0.1, value: 1.5 },
    ],
    anim: { key: "t", min: -3, max: 3, speed: 1, loop: "bounce", label: "점 P 움직이기" },
    drags: { P: { at: (s) => [s.t, (+s.a) ** s.t], move: (s, p) => (s.t = clamp(Math.round(p[0] * 10) / 10, -2.5, 2.5)), color: "a", label: "P" } },
    draw(s, g) {
      const a = +s.a, P = [s.t, a ** s.t], Q = [P[1], P[0]];
      g.grid();
      g.line([0, 0], [1, 1], { color: "muted", w: 1.4, dash: "7 5" });
      g.fx((x) => a ** x, { color: "a", w: 3.2 }).fx((x) => (x > 0 ? Math.log(x) / Math.log(a) : NaN), { color: "b", w: 3.2, from: 0.001, n: 900 });
      g.seg(P, Q, { color: "e", w: 1.6, dash: "4 4" });
      g.point([0, 1], "(0, 1)", { color: "a", r: 4, dx: -48 }).point([1, 0], "(1, 0)", { color: "b", r: 4, dy: 20 });
      g.point(P, `P(${fmt(s.t)}, ${fmt(P[1], 2)})`, { color: "a" }).point(Q, `P′(${fmt(Q[0], 2)}, ${fmt(s.t)})`, { color: "b", dy: 22 });
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], `y = ${baseStr(a).includes("/") ? `(${baseStr(a)})` : baseStr(a)}ˣ`, { anchor: "start", bold: true, color: "a" });
      g.text([g.xr[0] + 0.3, g.yr[1] - 1.4], `y = ${logOf(a)} x`, { anchor: "start", bold: true, color: "b" });
    },
    metrics(s) {
      const a = +s.a, v = a ** s.t, b = baseStr(a);
      return [
        [`${b}의 ${fmt(s.t)}제곱`, fmt(v, 4)],
        [`${logOf(a)} ${fmt(v, 4)}`, `${fmt(s.t)} (지수로 되돌아옴)`, "key"],
        ["정의역 ↔ 치역", "aˣ: 모든 실수 → 양수 · logₐ x: 양수 → 모든 실수"],
        ["점근선", "y = aˣ: y = 0 · y = logₐ x: x = 0"],
      ];
    },
    predict: [
      { q: "log₂ 8의 값은?", set: (s) => Object.assign(s, { a: "2", t: 1 }), reveal: (s) => (s.t = 3), answer: () => 3, why: "2³ = 8이므로 log₂ 8 = 3. P(3, 8)과 P′(8, 3)이 대칭입니다." },
      { q: "y = log₂ x의 그래프는 반드시 어느 점을 지날까요? x좌표를 적으세요.", set: (s) => Object.assign(s, { a: "2", t: 1.5 }), reveal: (s) => (s.t = 0), answer: () => 1, why: "logₐ 1 = 0이므로 (1, 0)을 지납니다. y = aˣ의 (0, 1)을 y = x에 대칭이동한 점입니다." },
      { q: "y = log₀.₅ x는 x가 커질 때 어떻게 될까요?", options: [["dec", "감소한다"], ["inc", "증가한다"]], set: (s) => Object.assign(s, { a: "2" }), reveal: (s) => (s.a = "0.5"), answer: () => "dec", why: "밑이 0과 1 사이이면 지수함수와 로그함수 모두 감소합니다." },
    ],
  },
  // ───────── Ⅴ 등차수열과 등비수열 ─────────
  {
    id: "alg-arith-sum", grade: G, unit: 5, lesson: "Ⅴ-3", title: "등차수열의 합 — 거꾸로 하나 더 붙이면 직사각형", type: "조작", time: "10분",
    tags: ["등차수열", "가우스", "합 공식"], links: ["alg-geo-seq", "alg-square-sum"],
    desc: "첫째항 a, 공차 d인 등차수열의 각 항을 막대로 쌓고, 같은 계단을 거꾸로 하나 더 붙여 가로 n, 세로 (첫째항 + 끝항)인 직사각형을 만들어 합 공식을 얻습니다.",
    obs: ["거꾸로 붙인 두 계단은 모든 열의 높이가 첫째항 + 끝항으로 같습니다.", "직사각형의 넓이는 n(a₁ + aₙ)이고, 합은 그 절반입니다.", "끝항 aₙ = a + (n − 1)d를 넣으면 Sₙ = n{2a + (n − 1)d}/2입니다."],
    q: "1 + 2 + 3 + ⋯ + 100을 가우스는 어떻게 빨리 계산했을까요?",
    formula: "Sₙ = n(a₁ + aₙ)/2 = n{2a + (n − 1)d}/2",
    en: { title: "Sum of an Arithmetic Sequence", desc: "Two copies of the staircase make a rectangle." },
    view: BOX,
    params: [
      { key: "a", label: "첫째항 a", min: 1, max: 5, step: 1, value: 1 },
      { key: "d", label: "공차 d", min: 0, max: 3, step: 1, value: 1 },
      { key: "n", label: "항의 수 n", min: 2, max: 12, step: 1, value: 8 },
      { key: "flip", label: "거꾸로 하나 더 붙이기", type: "check", value: true },
    ],
    term(s, k) { return s.a + (k - 1) * s.d; },
    draw(s, g) {
      const an = this.term(s, s.n), H = s.a + an, u = Math.min(13 / s.n, 9 / H), x0 = 1.5, y0 = 1;
      for (let k = 1; k <= s.n; k++) {
        const h = this.term(s, k), x = x0 + (k - 1) * u;
        g.poly([[x, y0], [x + u, y0], [x + u, y0 + h * u], [x, y0 + h * u]], { fill: "a", fo: 0.55, color: "a", w: 1.2 });
        if (!g.thumb && u > 0.55) g.text([x + u / 2, y0 + (h * u) / 2], String(h), { dy: 5, bold: true, size: 12 });
        if (s.flip) { const h2 = this.term(s, s.n + 1 - k); g.poly([[x, y0 + h * u], [x + u, y0 + h * u], [x + u, y0 + (h + h2) * u], [x, y0 + (h + h2) * u]], { fill: "b", fo: 0.35, color: "b", w: 1.2 }); if (!g.thumb && u > 0.55) g.text([x + u / 2, y0 + (h + h2 / 2) * u], String(h2), { dy: 5, size: 12, color: "b" }); }
      }
      if (s.flip) { g.poly([[x0, y0], [x0 + s.n * u, y0], [x0 + s.n * u, y0 + H * u], [x0, y0 + H * u]], { color: "ink", w: 2.4 }); g.text([x0 + s.n * u + 0.2, y0 + (H * u) / 2], `a₁ + aₙ = ${H}`, { anchor: "start", bold: true, size: 13 }); }
      g.text([x0 + (s.n * u) / 2, y0], `n = ${s.n}`, { dy: 18, bold: true, size: 13 });
    },
    metrics(s) {
      const an = this.term(s, s.n), S = (s.n * (s.a + an)) / 2;
      return [
        ["수열", Array.from({ length: Math.min(s.n, 8) }, (_, i) => this.term(s, i + 1)).join(", ") + (s.n > 8 ? ", …" : "")],
        ["끝항 aₙ", `${s.a} + (${s.n} − 1)·${s.d} = ${an}`],
        ["직사각형 넓이", `${s.n} × ${s.a + an} = ${s.n * (s.a + an)}`],
        ["합 Sₙ", `${s.n}(${s.a} + ${an})/2 = ${S}`, "key"],
      ];
    },
    predict: [
      { q: "1 + 2 + 3 + ⋯ + 100의 값은?", set: (s) => Object.assign(s, { a: 1, d: 1, n: 10, flip: false }), reveal: (s) => (s.flip = true), answer: () => 5050, why: "거꾸로 더하면 각 쌍이 101이고 100쌍이므로 100 × 101 ÷ 2 = 5050입니다." },
      { q: "2 + 5 + 8 + ⋯ (8개 항)의 합은?", set: (s) => Object.assign(s, { a: 2, d: 3, n: 8, flip: false }), reveal: (s) => (s.flip = true), answer: () => 100, why: "끝항 2 + 7·3 = 23, 합 8(2 + 23)/2 = 100입니다." },
    ],
  },
  {
    id: "alg-geo-seq", grade: G, unit: 5, lesson: "Ⅴ-4", title: "등비수열 — 종이 접기 두께와 복리", type: "조작", time: "12분",
    tags: ["등비수열", "등비수열의 합", "복리"], links: ["alg-arith-sum", "alg-tablet", "alg-exp-graph"],
    desc: "두께 0.1 mm인 종이를 반으로 접을 때마다 두께가 2배가 되는 수열과, 매년 같은 비율로 불어나는 복리 예금을 막대로 그려 등비수열의 일반항과 합이 빠르게 커지는 것을 확인합니다.",
    obs: ["공비가 r인 등비수열은 aₙ = a·rⁿ⁻¹입니다.", "종이를 27번쯤 접으면 두께가 에베레스트산(약 8.8 km)보다 두꺼워집니다.", "등비수열의 합은 Sₙ = a(rⁿ − 1)/(r − 1) (r ≠ 1)입니다."],
    q: "종이를 42번 접으면 두께는 대략 얼마일까요? 지구에서 달까지(약 38만 km)와 비교해 봅시다.",
    formula: "aₙ = a·rⁿ⁻¹ · Sₙ = a(rⁿ − 1)/(r − 1)",
    en: { title: "Geometric Sequences: Folding Paper and Compound Interest", desc: "Watch geometric sequences grow." },
    view: BOX,
    params: [
      { key: "mode", label: "상황", type: "seg", value: "fold", options: [["fold", "종이 접기"], ["bank", "복리 예금"]] },
      { key: "n", label: "접은 횟수 n", min: 1, max: 45, step: 1, value: 10, when: (s) => s.mode === "fold" },
      { key: "r", label: "연 이율 (%)", min: 1, max: 10, step: 0.5, value: 5, when: (s) => s.mode === "bank" },
      { key: "y", label: "햇수 n", min: 1, max: 40, step: 1, value: 20, when: (s) => s.mode === "bank" },
      { key: "save", label: "매년 초 100만 원씩 넣기 (합)", type: "check", value: false, when: (s) => s.mode === "bank" },
    ],
    anim: { key: "n", min: 1, max: 45, speed: 4, label: "계속 접기", when: (s) => s.mode === "fold" },
    thick(n) { return 0.1 * 2 ** n; }, // mm
    lenStr(mm) { return mm < 10 ? `${fmt(mm, 2)} mm` : mm < 1e3 ? `${fmt(mm / 10, 2)} cm` : mm < 1e6 ? `${fmt(mm / 1e3, 2)} m` : `${fmt(mm / 1e6, 2)} km`; },
    bank(s, k) { return 100 * (1 + s.r / 100) ** k; }, // 만 원
    draw(s, g) {
      const x0 = 1.2, y0 = 0.8, W = 13.8, H = 8.6;
      if (s.mode === "fold") {
        const N = s.n, vals = Array.from({ length: N + 1 }, (_, k) => this.thick(k)), mx = vals[N], w = W / (N + 1);
        vals.forEach((v, k) => { const h = (v / mx) * H; g.poly([[x0 + k * w, y0], [x0 + (k + 0.82) * w, y0], [x0 + (k + 0.82) * w, y0 + h], [x0 + k * w, y0 + h]], { fill: k === N ? "a" : "b", fo: k === N ? 0.7 : 0.45, color: k === N ? "a" : "b", w: 0.8 }); });
        const refs = [[8848e3, "에베레스트산 8.8 km"], [384400e6, "달까지 38만 km"], [1e3, "1 m"], [1.7e3, "키 1.7 m"]].filter(([v]) => v < mx && v > mx / 400);
        refs.forEach(([v, t]) => { const h = (v / mx) * H; g.seg([x0, y0 + h], [x0 + W, y0 + h], { color: "d", w: 1.3, dash: "6 4" }); g.text([x0 + 0.1, y0 + h], t, { anchor: "start", dy: -4, size: 12, color: "d", bold: true }); });
        g.text([x0 + W, y0 + H + 0.5], `${N}번 접으면 ${this.lenStr(mx)}`, { anchor: "end", bold: true, size: 15, color: "a" });
      } else {
        const N = s.y, vals = Array.from({ length: N + 1 }, (_, k) => (s.save ? (100 * (1 + s.r / 100) * ((1 + s.r / 100) ** k - 1)) / (s.r / 100) : this.bank(s, k))), mx = Math.max(...vals), w = W / (N + 1);
        vals.forEach((v, k) => { const h = (v / mx) * H; g.poly([[x0 + k * w, y0], [x0 + (k + 0.82) * w, y0], [x0 + (k + 0.82) * w, y0 + h], [x0 + k * w, y0 + h]], { fill: k === N ? "a" : "c", fo: k === N ? 0.7 : 0.45, color: k === N ? "a" : "c", w: 0.8 }); });
        const base = s.save ? 100 * N : 100, hb = (base / mx) * H;
        g.seg([x0, y0 + hb], [x0 + W, y0 + hb], { color: "d", w: 1.3, dash: "6 4" }); g.text([x0 + 0.1, y0 + hb], s.save ? `넣은 돈 ${base}만 원` : "원금 100만 원", { anchor: "start", dy: -4, size: 12, color: "d", bold: true });
        g.text([x0 + W, y0 + H + 0.5], `${N}년 뒤 ${fmt(vals[N], 1)}만 원`, { anchor: "end", bold: true, size: 15, color: "a" });
      }
      g.seg([x0, y0], [x0 + W, y0], { color: "axis", w: 1.4 });
    },
    metrics(s) {
      if (s.mode === "fold") return [["두께 aₙ", `0.1 mm × 2^${s.n}`], ["두께", this.lenStr(this.thick(s.n)), "key"], ["2ⁿ", fmt(2 ** s.n)], ["공비", "r = 2"]];
      const R = 1 + s.r / 100;
      return s.save
        ? [["매년 초 100만 원, n년 뒤 합", `100·${fmt(R, 3)}(${fmt(R, 3)}^${s.y} − 1)/(${fmt(R, 3)} − 1)`], ["원리합계", `${fmt((100 * R * (R ** s.y - 1)) / (R - 1), 1)}만 원`, "key"], ["넣은 돈", `${100 * s.y}만 원`]]
        : [["n년 뒤 원리합계", `100 × ${fmt(R, 3)}^${s.y}`], ["금액", `${fmt(this.bank(s, s.y), 1)}만 원`, "key"], ["처음의 몇 배", `${fmt(R ** s.y, 3)}배`]];
    },
    predict: [
      { q: "두께 0.1 mm인 종이를 최소 몇 번 접으면 두께가 1 m를 넘을까요?", set: (s) => Object.assign(s, { mode: "fold", n: 5 }), reveal: (s) => (s.n = 14), answer: () => 14, why: "0.1 × 2¹³ = 819.2 mm, 0.1 × 2¹⁴ = 1638.4 mm이므로 14번입니다." },
      { q: "연 이율 6%의 복리로 100만 원을 맡기면 약 몇 년 뒤에 두 배(200만 원)가 넘을까요?", set: (s) => Object.assign(s, { mode: "bank", r: 6, y: 5, save: false }), reveal: (s) => (s.y = 12), answer: () => 12, tol: 0.5, why: "1.06¹¹ ≈ 1.898, 1.06¹² ≈ 2.012이므로 12년입니다. 72 ÷ 6 = 12라는 '72의 법칙'과도 맞습니다." },
    ],
  },
  // ───────── Ⅵ 수열의 합 ─────────
  {
    id: "alg-square-sum", grade: G, unit: 6, lesson: "Ⅵ-2", title: "자연수 제곱의 합 — 블록 피라미드", type: "3D", time: "12분",
    tags: ["∑", "제곱의 합", "피라미드"], links: ["alg-arith-sum", "alg-hanoi"],
    desc: "한 변이 1, 2, …, n인 정사각형 층을 쌓은 블록 피라미드의 블록 수가 1² + 2² + ⋯ + n²임을 확인하고, 그 값이 n(n + 1)(2n + 1)/6과 같음을 n을 바꾸며 검증합니다.",
    obs: ["k번째 층에는 k² 개의 블록이 있습니다.", "∑ₖ₌₁ⁿ k² = n(n + 1)(2n + 1)/6입니다.", "같은 피라미드 6개를 맞추면 n × (n + 1) × (2n + 1) 상자가 됩니다."],
    q: "피라미드 블록 수가 처음으로 1000개를 넘는 층수 n은 몇일까요?",
    formula: "∑ₖ₌₁ⁿ k² = 1² + 2² + ⋯ + n² = n(n + 1)(2n + 1)/6",
    en: { title: "Sum of Squares: a Block Pyramid", desc: "Count blocks in a square pyramid." },
    space: true, cam: (s) => ({ yaw: 34, pitch: 26, scale: 300 / (s.n + 2.5) }),
    params: [
      { key: "n", label: "층수 n", min: 1, max: 10, step: 1, value: 5 },
      { key: "hl", label: "강조할 층 k", min: 1, max: (s) => s.n, step: 1, value: 3 },
    ],
    anim: { key: "n", min: 1, max: 10, speed: 1.5, label: "한 층씩 쌓기" },
    derive(s) { s.hl = clamp(s.hl, 1, s.n); },
    draw(s, g) {
      const n = s.n;
      for (let k = n; k >= 1; k--) {
        const z = (n - k) - n / 2, off = (n - k) / 2;
        for (let i = 0; i < k; i++) for (let j = 0; j < k; j++) cube(g, i + off - n / 2, j + off - n / 2, z, 1, { fill: k === s.hl ? "a" : ["b", "c", "e"][k % 3], fo: k === s.hl ? 0.75 : 0.35 });
      }
      g.note(20, 30, `강조한 층: 한 변 ${s.hl}, 블록 ${s.hl}² = ${s.hl * s.hl}개`, { bold: true, color: "ink" });
    },
    metrics(s) {
      const n = s.n, S = (n * (n + 1) * (2 * n + 1)) / 6;
      return [
        ["층별 블록 수", Array.from({ length: n }, (_, i) => (i + 1) ** 2).join(" + ")],
        ["블록 전체", `${S}개`, "key"],
        ["공식", `${n}·${n + 1}·${2 * n + 1}/6 = ${S}`],
      ];
    },
    predict: [
      { q: "10층 피라미드의 블록은 모두 몇 개일까요?", set: (s) => Object.assign(s, { n: 4, hl: 4 }), reveal: (s) => (s.n = 10), answer: () => 385, why: "10·11·21/6 = 385개입니다." },
      { q: "피라미드 블록 수가 처음으로 100개를 넘는 층수는?", set: (s) => Object.assign(s, { n: 3, hl: 3 }), reveal: (s) => (s.n = 7), answer: () => 7, why: "6층은 91개, 7층은 140개이므로 7층입니다." },
    ],
  },
];
