// 중학교 기하·통계 보강 — 기존 사이트에 없던 교과서 주제
import { fmt, frac, surd, dist, sub, add, mul, norm, dot, len, cross, lerp, clamp, deg, rad2deg } from "./hs-core.js";

const UC = { 5: "#db712f", 6: "#2e79bd", 7: "#198574", 8: "#d75e59" };
const V = { x: [-7, 7], y: [-5, 5] };
const ang = (v, p, q) => rad2deg(Math.acos(clamp(dot(sub(p, v), sub(q, v)) / (len(sub(p, v)) * len(sub(q, v)) || 1), -1, 1)));
const area3 = (a, b, c) => Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])) / 2;
let seed = 7;
const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-12)) * Math.cos(2 * Math.PI * rnd());
const NOISE = Array.from({ length: 60 }, () => [gauss(), gauss()]);
const PHI = (1 + Math.sqrt(5)) / 2;

function solid(kind, n) {
  let P = [], F = null;
  if (kind === "prism" || kind === "frustum" || kind === "pyramid") {
    const top = kind === "prism" ? 1 : kind === "frustum" ? 0.5 : 0;
    for (let i = 0; i < n; i++) { const a = (2 * Math.PI * i) / n; P.push([1.8 * Math.cos(a), 1.8 * Math.sin(a), -1.4]); }
    if (top) for (let i = 0; i < n; i++) { const a = (2 * Math.PI * i) / n; P.push([1.8 * top * Math.cos(a), 1.8 * top * Math.sin(a), 1.4]); }
    else P.push([0, 0, 1.6]);
    F = [Array.from({ length: n }, (_, i) => i)];
    if (top) { F.push(Array.from({ length: n }, (_, i) => n + i)); for (let i = 0; i < n; i++) F.push([i, (i + 1) % n, n + ((i + 1) % n), n + i]); }
    else for (let i = 0; i < n; i++) F.push([i, (i + 1) % n, n]);
  } else {
    const s = (a) => [a, -a];
    if (kind === "tet") P = [[1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]];
    if (kind === "cube") for (const x of s(1)) for (const y of s(1)) for (const z of s(1)) P.push([x, y, z]);
    if (kind === "oct") P = [[1.4, 0, 0], [-1.4, 0, 0], [0, 1.4, 0], [0, -1.4, 0], [0, 0, 1.4], [0, 0, -1.4]];
    if (kind === "ico") for (const a of s(1)) for (const b of s(PHI)) P.push([0, a, b], [a, b, 0], [b, 0, a]);
    if (kind === "dod") { for (const x of s(1)) for (const y of s(1)) for (const z of s(1)) P.push([x, y, z]); for (const a of s(1 / PHI)) for (const b of s(PHI)) P.push([0, a, b], [a, b, 0], [b, 0, a]); }
    const k = kind === "ico" || kind === "dod" ? 0.85 : 1.2; P = P.map((p) => mul(p, k));
  }
  let E = [];
  if (F) { const set = new Set(); F.forEach((f) => f.forEach((a, i) => { const b = f[(i + 1) % f.length], key = a < b ? `${a},${b}` : `${b},${a}`; if (!set.has(key)) { set.add(key); E.push([a, b]); } })); }
  else { let m = Infinity; for (let i = 0; i < P.length; i++) for (let j = i + 1; j < P.length; j++) m = Math.min(m, len(sub(P[i], P[j]))); for (let i = 0; i < P.length; i++) for (let j = i + 1; j < P.length; j++) if (Math.abs(len(sub(P[i], P[j])) - m) < 1e-6) E.push([i, j]); }
  const faces = { tet: 4, cube: 6, oct: 8, ico: 20, dod: 12 }[kind] ?? F.length;
  return { P, E, F, v: P.length, e: E.length, f: faces };
}

export default [
  // ───── 중1 ─────
  {
    id: "m1-points-lines", grade: 1, unit: 5, lesson: "5.1", title: "직선·반직선·선분과 점의 개수", type: "2D", time: "8분",
    tags: ["직선", "반직선", "선분"], color: UC[5], links: ["vertical-angles"],
    desc: "두 점으로 직선, 반직선, 선분을 구분해 그리고, 여러 점 가운데 두 점을 지나는 직선이 몇 개인지 셉니다.",
    obs: ["반직선 AB와 반직선 BA는 시작점과 방향이 달라 서로 다릅니다.", "세 점이 한 직선 위에 있지 않으면 두 점을 지나는 직선은 3개입니다.", "어느 세 점도 한 직선 위에 있지 않은 n개의 점으로 n(n − 1)/2개의 직선을 그을 수 있습니다."],
    q: "5개의 점 중 세 점이 한 직선 위에 있으면 직선의 개수는 어떻게 달라질까요?",
    formula: "직선 AB = 직선 BA · 반직선 AB ≠ 반직선 BA · 선분 AB = 선분 BA",
    en: { title: "Lines, Rays and Segments", desc: "Distinguish lines, rays and segments, and count the lines through pairs of points." },
    view: V, snap: 0.5, points: { A: [-3, -1], B: [2, 1.5] },
    params: [
      { key: "mode", label: "그리기", type: "seg", value: "ray", options: [["line", "직선 AB"], ["ray", "반직선 AB"], ["ray2", "반직선 BA"], ["seg", "선분 AB"], ["many", "여러 점"]] },
      { key: "n", label: "점의 개수", min: 2, max: 8, step: 1, value: 5, when: (s) => s.mode === "many" },
    ],
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      if (s.mode === "many") {
        const P = Array.from({ length: s.n }, (_, i) => [4 * Math.cos((2 * Math.PI * i) / s.n + 0.3), 3.6 * Math.sin((2 * Math.PI * i) / s.n + 0.3)]);
        for (let i = 0; i < s.n; i++) for (let j = i + 1; j < s.n; j++) g.line(P[i], P[j], { color: ["a", "b", "c", "d", "e", "f"][(i + j) % 6], w: 1.4, opacity: 0.7 });
        P.forEach((p, i) => g.point(p, "ABCDEFGH"[i], { color: "ink" }));
        return;
      }
      const { A, B } = s, d = sub(B, A);
      if (s.mode === "line") g.line(A, B, { color: "a", w: 3.2 });
      if (s.mode === "ray") g.ray(A, d, { color: "a", w: 3.2 });
      if (s.mode === "ray2") g.ray(B, mul(d, -1), { color: "b", w: 3.2 });
      if (s.mode === "seg") g.seg(A, B, { color: "c", w: 3.6 });
      g.point(A, "A", { color: "ink" }).point(B, "B", { color: "ink" }).handle(A, "A").handle(B, "B");
    },
    metrics(s) {
      if (s.mode === "many") return [["점의 개수", String(s.n)], ["두 점을 지나는 직선", `${s.n}×${s.n - 1}/2 = ${(s.n * (s.n - 1)) / 2}개`, "key"], ["선분의 개수", `${(s.n * (s.n - 1)) / 2}개`], ["반직선의 개수", `${s.n * (s.n - 1)}개`]];
      return [["그린 도형", { line: "직선 AB (양쪽으로 끝없이)", ray: "반직선 AB (A에서 B 쪽으로)", ray2: "반직선 BA (B에서 A 쪽으로)", seg: "선분 AB (A부터 B까지)" }[s.mode], "key"], ["선분 AB의 길이", fmt(dist(s.A, s.B))]];
    },
  },
  {
    id: "m1-perpendicular", grade: 1, unit: 5, lesson: "5.2", title: "수직과 수선의 발 — 가장 짧은 길", type: "2D", time: "8분",
    tags: ["수직", "수선의 발", "거리"], color: UC[5], links: ["c2-point-line"],
    desc: "직선 밖의 점 P에서 직선 위의 점 Q까지 거리를 재며, 수선의 발 H에서 가장 짧아지는 것을 확인합니다.",
    obs: ["PH ⟂ l일 때 PH가 가장 짧습니다.", "점 P와 직선 l 사이의 거리는 선분 PH의 길이입니다.", "Q가 H에서 멀어질수록 PQ는 길어집니다."],
    q: "학교에서 도로까지 가장 가까운 길을 내려면 어떻게 해야 할까요?",
    formula: "점과 직선 사이의 거리 = PH (PH ⟂ l)",
    en: { title: "Perpendiculars and the Shortest Distance", desc: "Measure PQ along a line and find its minimum at the foot of the perpendicular." },
    view: V, points: { P: [-1, 3], Q: [3, -1.2] },
    constrain(s, k, p) { return k === "Q" ? [clamp(p[0], -6.5, 6.5), -1.2 + 0.2 * clamp(p[0], -6.5, 6.5)] : [clamp(p[0], -6.5, 6.5), clamp(p[1], -4.5, 4.5)]; },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const L = (x) => -1.2 + 0.2 * x, u = norm([1, 0.2]), A = [0, -1.2], H = add(A, mul(u, dot(sub(s.P, A), u)));
      g.line([0, L(0)], [1, L(1)], { color: "ink", w: 2.6 }).text([6.5, L(6.5)], "l", { dy: -8, italic: true, color: "ink" });
      g.seg(s.P, H, { color: "a", w: 3 }).right(H, s.P, add(H, u), { size: 12 });
      g.seg(s.P, s.Q, { color: "b", w: 2.4, dash: "6 4" });
      g.point(H, "H", { color: "a", dy: 20 }).point(s.P, "P", { color: "ink" }).point(s.Q, "Q", { color: "b", dy: 20 });
      g.handle(s.P, "P", { color: "a" }).handle(s.Q, "Q", { color: "b" });
    },
    metrics(s) { const u = norm([1, 0.2]), A = [0, -1.2], H = add(A, mul(u, dot(sub(s.P, A), u))); return [["PH (거리)", fmt(dist(s.P, H)), "key"], ["PQ", fmt(dist(s.P, s.Q))], ["비교", dist(s.P, s.Q) - dist(s.P, H) < 0.01 ? "Q가 수선의 발에 있음" : "PQ > PH"]]; },
  },
  {
    id: "m1-triangle-exterior", grade: 1, unit: 6, lesson: "6.3", title: "삼각형의 내각과 외각", type: "2D", time: "10분",
    tags: ["내각의 합", "외각", "평행선"], color: UC[6], links: ["exterior-walk", "parallel-angles"],
    desc: "꼭짓점 C를 지나고 AB에 평행한 직선을 그어, 내각의 합이 180°이고 한 외각이 이웃하지 않는 두 내각의 합과 같음을 엇각과 동위각으로 확인합니다.",
    obs: ["엇각에 의해 ∠A가 C 위쪽으로, 동위각에 의해 ∠B가 옮겨집니다.", "∠ACD = ∠A + ∠B입니다.", "꼭짓점을 움직여도 관계는 유지됩니다."],
    q: "삼각형의 세 외각의 합은 몇 도일까요?",
    formula: "∠A + ∠B + ∠C = 180° · (∠C의 외각) = ∠A + ∠B",
    en: { title: "Interior and Exterior Angles of a Triangle", desc: "Use a parallel line to show the angle sum and the exterior angle theorem." },
    view: V, points: { A: [-1.5, 3], B: [-5, -2.5], C: [1.5, -2.5] },
    params: [{ key: "par", label: "C를 지나는 평행선으로 설명", type: "check", value: true }],
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const { A, B, C } = s, D = add(C, mul(norm(sub(C, B)), 4));
      g.seg(C, D, { color: "muted", w: 2, dash: "6 4" });
      g.poly([A, B, C], { fill: "b", fo: 0.08, color: "ink", w: 2.6 });
      g.arc(A, C, B, { r: 28, color: "a", ccw: false, label: `${fmt(ang(A, B, C), 0)}°` });
      g.arc(B, C, A, { r: 28, color: "c", ccw: false, label: `${fmt(ang(B, A, C), 0)}°` });
      g.arc(C, A, B, { r: 24, color: "e", ccw: false });
      if (s.par) { const E = add(C, sub(A, B)); g.line(C, E, { color: "f", w: 1.6, dash: "4 5" }); g.arc(C, D, E, { r: 40, color: "c", ccw: false }); g.arc(C, E, A, { r: 40, color: "a", ccw: false }); }
      else g.arc(C, D, A, { r: 40, color: "d", ccw: false, label: `${fmt(180 - ang(C, A, B), 0)}°` });
      g.point(A, "A").point(B, "B", { dy: 20 }).point(C, "C", { dy: 20 }).point(D, "D", { dy: 20, r: 3.5 });
      g.handle(A, "A").handle(B, "B").handle(C, "C");
    },
    metrics(s) { const a = ang(s.A, s.B, s.C), b = ang(s.B, s.A, s.C), c = ang(s.C, s.A, s.B); return [["∠A + ∠B + ∠C", `${fmt(a, 1)}° + ${fmt(b, 1)}° + ${fmt(c, 1)}° = 180°`], ["외각 ∠ACD", `${fmt(180 - c, 1)}°`, "key"], ["∠A + ∠B", `${fmt(a + b, 1)}°`]]; },
  },
  {
    id: "m1-polyhedra", grade: 1, unit: 7, lesson: "7.1", title: "다면체의 꼭짓점·모서리·면 세기", type: "3D", time: "10분",
    tags: ["다면체", "정다면체", "v − e + f"], color: UC[7], links: ["net-fold", "m1-why-five"],
    desc: "각기둥·각뿔·각뿔대와 다섯 가지 정다면체를 돌려 보며 꼭짓점·모서리·면의 수를 세고, 그 사이의 관계를 찾습니다.",
    obs: ["n각기둥은 꼭짓점 2n, 모서리 3n, 면 n + 2개입니다.", "n각뿔은 꼭짓점 n + 1, 모서리 2n, 면 n + 1개입니다.", "모든 볼록 다면체에서 v − e + f = 2입니다(오일러 공식, 탐구)."],
    q: "정이십면체의 모서리 수를 면의 수로부터 계산해 보세요.",
    formula: "v − e + f = 2",
    en: { title: "Counting Vertices, Edges and Faces", desc: "Rotate prisms, pyramids, frustums and the five Platonic solids and count v, e, f." },
    space: true, cam: { yaw: 28, pitch: 18, scale: 70 },
    params: [
      { key: "kind", label: "입체", type: "select", value: "prism", options: [["prism", "각기둥"], ["pyramid", "각뿔"], ["frustum", "각뿔대"], ["tet", "정사면체"], ["cube", "정육면체"], ["oct", "정팔면체"], ["dod", "정십이면체"], ["ico", "정이십면체"]] },
      { key: "n", label: "밑면의 변의 수 n", min: 3, max: 10, step: 1, value: 5, when: (s) => ["prism", "pyramid", "frustum"].includes(s.kind) },
    ],
    draw(s, g) {
      const S = solid(s.kind, s.n);
      if (S.F) S.F.forEach((f, i) => g.face(f.map((k) => S.P[k]), { fill: i < 2 && s.kind !== "pyramid" ? "e" : "c", color: "c", fo: 0.12, w: 0.8 }));
      S.E.forEach(([a, b]) => { const m = lerp(S.P[a], S.P[b], 0.5), back = dot(m, g.d) < -0.3; g.seg(S.P[a], S.P[b], { color: "c", w: back ? 1.4 : 2.6, dash: back ? "5 5" : null, bias: 1 }); });
      S.P.forEach((p) => g.point(p, "", { color: "a", r: 4, bias: 2 }));
    },
    metrics(s) { const S = solid(s.kind, s.n); return [["꼭짓점 v", String(S.v)], ["모서리 e", String(S.e)], ["면 f", String(S.f)], ["v − e + f", String(S.v - S.e + S.f), "key"]]; },
  },
  {
    id: "m1-why-five", grade: 1, unit: 7, lesson: "7.2", title: "정다면체는 왜 5가지뿐일까?", type: "조작", time: "10분",
    tags: ["정다면체", "꼭짓점에 모인 각", "360°"], color: UC[7], links: ["m1-polyhedra", "lab-tessellation"],
    desc: "한 꼭짓점에 정다각형을 q개 모아 붙일 때 각의 합이 360°보다 작아야 입체로 접을 수 있음을 펼친 그림으로 확인합니다.",
    obs: ["각의 합이 360°보다 작으면 틈이 생겨 접어 올릴 수 있습니다.", "360°이면 평면을 빈틈없이 덮고(테셀레이션), 넘으면 겹칩니다.", "가능한 경우는 정삼각형 3·4·5개, 정사각형 3개, 정오각형 3개뿐입니다."],
    q: "정육각형 3개를 한 꼭짓점에 모으면 어떻게 될까요?",
    formula: "q × (한 내각) < 360°",
    en: { title: "Why Only Five Platonic Solids?", desc: "Gather regular polygons at a vertex and check whether the angle sum stays under 360°." },
    view: V,
    params: [{ key: "p", label: "정 p각형", min: 3, max: 6, step: 1, value: 3 }, { key: "q", label: "한 꼭짓점에 모이는 면의 수 q", min: 3, max: 7, step: 1, value: 5 }],
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const inner = 180 - 360 / s.p, R = 2.8, sum = inner * s.q;
      for (let k = 0; k < s.q; k++) {
        const a0 = deg(k * inner + 90), pts = [[0, 0]];
        let cur = [0, 0], dir = a0;
        for (let i = 0; i < s.p - 1; i++) { cur = add(cur, [R * Math.cos(dir), R * Math.sin(dir)]); pts.push(cur); dir += deg(360 / s.p); }
        const over = (k + 1) * inner > 360 + 1e-9;
        g.poly(pts, { fill: over ? "d" : ["a", "b", "c", "e", "f"][k % 5], fo: over ? 0.35 : 0.22, color: over ? "d" : "ink", w: 1.6 });
      }
      if (sum < 360 - 1e-9) g.arc([0, 0], [Math.cos(deg(90 + sum)), Math.sin(deg(90 + sum))], [0, 1], { r: 50, color: "c", label: `틈 ${fmt(360 - sum)}°` });
      g.point([0, 0], "", { color: "ink" });
    },
    metrics(s) {
      const inner = 180 - 360 / s.p, sum = inner * s.q;
      const name = { "3,3": "정사면체", "3,4": "정팔면체", "3,5": "정이십면체", "4,3": "정육면체", "5,3": "정십이면체" }[`${s.p},${s.q}`];
      return [["한 내각", `${fmt(inner)}°`], ["모인 각의 합", `${fmt(sum)}°`], ["결과", sum < 360 - 1e-9 ? `접을 수 있음 → ${name}` : Math.abs(sum - 360) < 1e-9 ? "평면을 덮음 (입체 불가)" : "겹침 (입체 불가)", "key"]];
    },
  },
  {
    id: "m1-surface-area", grade: 1, unit: 7, lesson: "7.7", title: "기둥과 뿔의 겉넓이 — 전개도로 계산", type: "2D", time: "12분",
    tags: ["겉넓이", "전개도", "원뿔의 옆면"], color: UC[7], links: ["net-fold", "sector"],
    desc: "원기둥·원뿔·정각기둥·정각뿔의 전개도를 펼쳐 밑넓이와 옆넓이를 따로 구해 더합니다.",
    obs: ["원기둥 옆면은 가로 2πr, 세로 h인 직사각형입니다.", "원뿔 옆면은 반지름이 모선 l, 호의 길이가 2πr인 부채꼴입니다.", "겉넓이 = 밑넓이 × (기둥은 2, 뿔은 1) + 옆넓이입니다."],
    q: "원뿔의 옆면 부채꼴의 중심각은 r과 l로 어떻게 나타낼까요?",
    formula: "원기둥 2πr² + 2πrh · 원뿔 πr² + πrl",
    en: { title: "Surface Area from Nets", desc: "Unfold cylinders, cones, prisms and pyramids and add base and lateral areas." },
    view: { x: [-8, 8], y: [-5.5, 5.5] },
    params: [
      { key: "kind", label: "입체", type: "seg", value: "cone", options: [["cyl", "원기둥"], ["cone", "원뿔"], ["prism", "정각기둥"], ["pyr", "정각뿔"]] },
      { key: "r", label: "반지름 r (또는 한 변 a)", min: 0.6, max: 2, step: 0.1, value: 1.2 },
      { key: "h", label: "높이 h (뿔은 모선 l)", min: 1.5, max: 4.5, step: 0.1, value: 3.2 },
      { key: "n", label: "밑면의 변의 수", min: 3, max: 8, step: 1, value: 4, when: (s) => s.kind === "prism" || s.kind === "pyr" },
    ],
    derive(s) { if (s.kind === "cone" && s.h < s.r + 0.2) s.h = s.r + 0.2; },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const { r, h, n } = s;
      if (s.kind === "cyl") {
        const W = 2 * Math.PI * r, x0 = -W / 2;
        g.poly([[x0, -h / 2], [x0 + W, -h / 2], [x0 + W, h / 2], [x0, h / 2]], { fill: "b", fo: 0.18, color: "b" });
        g.circle([x0 + r, h / 2 + r], r, { fill: "a", fo: 0.2, color: "a" }).circle([x0 + r, -h / 2 - r], r, { fill: "a", fo: 0.2, color: "a" });
        g.text([0, -h / 2], `2πr = ${fmt(W)}`, { dy: 20, color: "b", bold: true }).text([x0 + W, 0], `h = ${fmt(h)}`, { dx: 10, anchor: "start", color: "b", bold: true });
      } else if (s.kind === "cone") {
        const th = (2 * Math.PI * r) / h, C0 = [0, 3.4], a0 = -Math.PI / 2 - th / 2;
        g.poly([C0, ...Array.from({ length: 61 }, (_, i) => add(C0, [h * Math.cos(a0 + (th * i) / 60), h * Math.sin(a0 + (th * i) / 60)]))], { fill: "b", fo: 0.18, color: "b" });
        g.circle([0, 3.4 - h - r], r, { fill: "a", fo: 0.2, color: "a" });
        g.text(lerp(C0, add(C0, [h * Math.cos(a0), h * Math.sin(a0)]), 0.5), `l = ${fmt(h)}`, { dx: -12, anchor: "end", color: "b", bold: true });
        g.text(C0, `중심각 ${fmt(rad2deg(th), 1)}°`, { dy: -10, color: "e", bold: true });
      } else {
        const a = r * 1.3;
        if (s.kind === "prism") {
          const W = n * a, x0 = -W / 2;
          for (let i = 0; i < n; i++) g.poly([[x0 + i * a, -h / 2], [x0 + (i + 1) * a, -h / 2], [x0 + (i + 1) * a, h / 2], [x0 + i * a, h / 2]], { fill: "b", fo: 0.16, color: "b" });
          const poly = (base, up) => { const pts = [base[0], base[1]]; let dir = up ? 0 : 0; let cur = base[1], d = 0; for (let i = 0; i < n - 2; i++) { d += (up ? 1 : -1) * (360 / n); cur = add(cur, [a * Math.cos(deg(d)), a * Math.sin(deg(d))]); pts.push(cur); } return pts; };
          g.poly(poly([[x0, h / 2], [x0 + a, h / 2]], true), { fill: "a", fo: 0.2, color: "a" });
          g.poly(poly([[x0, -h / 2], [x0 + a, -h / 2]], false), { fill: "a", fo: 0.2, color: "a" });
        } else {
          const Rb = a / (2 * Math.sin(Math.PI / n)), ap = a / (2 * Math.tan(Math.PI / n)), l = Math.max(h, ap + 0.2);
          const B = Array.from({ length: n }, (_, i) => [Rb * Math.cos((2 * Math.PI * i) / n + Math.PI / n - Math.PI / 2), Rb * Math.sin((2 * Math.PI * i) / n + Math.PI / n - Math.PI / 2)]);
          g.poly(B, { fill: "a", fo: 0.2, color: "a" });
          B.forEach((p, i) => { const q = B[(i + 1) % n], m = lerp(p, q, 0.5), out = norm(m); g.poly([p, q, add(m, mul(out, Math.sqrt(Math.max(0.01, l * l - (a * a) / 4))))], { fill: "b", fo: 0.16, color: "b" }); });
        }
      }
    },
    metrics(s) {
      const { r, h, n } = s;
      if (s.kind === "cyl") return [["밑넓이 × 2", fmt(2 * Math.PI * r * r, 2)], ["옆넓이 2πrh", fmt(2 * Math.PI * r * h, 2)], ["겉넓이", fmt(2 * Math.PI * r * (r + h), 2), "key"]];
      if (s.kind === "cone") return [["밑넓이 πr²", fmt(Math.PI * r * r, 2)], ["옆넓이 πrl", fmt(Math.PI * r * h, 2)], ["겉넓이", fmt(Math.PI * r * (r + h), 2), "key"]];
      const a = r * 1.3, base = (n * a * a) / (4 * Math.tan(Math.PI / n));
      if (s.kind === "prism") return [["밑넓이 × 2", fmt(2 * base, 2)], ["옆넓이 (둘레 × 높이)", fmt(n * a * h, 2)], ["겉넓이", fmt(2 * base + n * a * h, 2), "key"]];
      const ap = a / (2 * Math.tan(Math.PI / n)), l = Math.max(h, ap + 0.2), side = n * 0.5 * a * Math.sqrt(Math.max(0.01, l * l - (a * a) / 4));
      return [["밑넓이", fmt(base, 2)], ["옆넓이 (삼각형 n개)", fmt(side, 2)], ["겉넓이", fmt(base + side, 2), "key"]];
    },
  },
  {
    id: "m1-prism-volume", grade: 1, unit: 7, lesson: "7.8", title: "기둥의 부피 — 밑면을 쌓아 올리기", type: "3D", time: "8분",
    tags: ["부피", "밑넓이 × 높이", "쌓기"], color: UC[7], links: ["cone-volume", "calc-volume-slice"],
    desc: "밑면과 같은 얇은 판을 높이만큼 쌓아 올리며 기둥의 부피가 밑넓이 × 높이가 되는 까닭을 봅니다.",
    obs: ["모든 층의 단면은 밑면과 합동입니다.", "밑면의 모양과 상관없이 부피 = 밑넓이 × 높이입니다."],
    q: "밑넓이는 같고 높이가 2배인 기둥의 부피는 몇 배일까요?",
    formula: "V = S × h (원기둥 V = πr²h)",
    en: { title: "Volume of Prisms by Stacking", desc: "Stack base-shaped layers to see V = base area × height." },
    space: true, cam: { yaw: 36, pitch: 22, scale: 52 },
    params: [{ key: "shape", label: "밑면", type: "seg", value: "tri", options: [["rect", "직사각형"], ["tri", "삼각형"], ["circ", "원"]] }, { key: "h", label: "높이 h", min: 0.5, max: 4, step: 0.1, value: 3 }],
    anim: { key: "h", min: 0.5, max: 4, speed: 0.8, label: "쌓아 올리기" },
    base(s) { if (s.shape === "rect") return { pts: [[-1.5, -1, 0], [1.5, -1, 0], [1.5, 1, 0], [-1.5, 1, 0]], S: 6 }; if (s.shape === "tri") return { pts: [[-1.8, -1.2, 0], [1.8, -1.2, 0], [0.3, 1.6, 0]], S: 0.5 * 3.6 * 2.8 }; return { pts: Array.from({ length: 48 }, (_, i) => [1.4 * Math.cos((2 * Math.PI * i) / 48), 1.4 * Math.sin((2 * Math.PI * i) / 48), 0]), S: Math.PI * 1.96 }; },
    draw(s, g) {
      const B = this.base(s), layers = Math.ceil(s.h * 2), dz = s.h / layers, z0 = -1.8;
      for (let k = 0; k <= layers; k++) g.face(B.pts.map((p) => add(p, [0, 0, z0 + k * dz])), { fill: k === 0 ? "a" : "c", color: k === 0 ? "a" : "c", fo: k === 0 ? 0.35 : 0.1, w: k === layers || k === 0 ? 2 : 0.8 });
      B.pts.forEach((p, i) => { if (s.shape !== "circ" || i % 12 === 0) g.seg(add(p, [0, 0, z0]), add(p, [0, 0, z0 + s.h]), { color: "c", w: 1.4 }); });
      g.text(add(B.pts[1], [0, 0, z0 + s.h / 2]), `h = ${fmt(s.h)}`, { dx: 14, anchor: "start", color: "c", bold: true });
    },
    metrics(s) { const B = this.base(s); return [["밑넓이 S", fmt(B.S, 3)], ["높이 h", fmt(s.h)], ["부피 S × h", fmt(B.S * s.h, 3), "key"]]; },
  },
  {
    id: "m1-sphere-volume", grade: 1, unit: 7, lesson: "7.9", title: "구의 부피 — 아르키메데스의 단면 비교", type: "3D", time: "12분",
    tags: ["구의 부피", "카발리에리", "원기둥 − 원뿔"], color: UC[7], links: ["sphere-area", "cone-volume", "calc-volume-slice"],
    desc: "반구와 '원기둥에서 원뿔을 파낸 입체'를 같은 높이에서 잘라 단면의 넓이가 항상 같음을 보고, 구의 부피 4/3πr³을 얻습니다.",
    obs: ["높이 z에서 반구의 단면은 π(r² − z²)입니다.", "원기둥 − 원뿔의 단면은 πr² − πz²으로 같습니다.", "단면이 모두 같으므로 부피도 같습니다: 반구 = πr³ − ⅓πr³ = ⅔πr³."],
    q: "원뿔 : 구 : 원기둥의 부피비가 1 : 2 : 3인 이유를 설명해 보세요.",
    formula: "V구 = 2 × (πr³ − ⅓πr³) = 4/3 πr³",
    en: { title: "Volume of a Sphere by Archimedes", desc: "Compare slices of a hemisphere and a cylinder minus a cone to derive 4/3πr³." },
    space: true, cam: { yaw: -90, pitch: 18, scale: 62 },
    params: [{ key: "z", label: "자르는 높이 z", min: 0, max: 1, step: 0.01, value: 0.5, show: (v) => `${fmt(v * 100, 0)}% × r` }],
    anim: { key: "z", min: 0, max: 1, speed: 0.3, label: "평면 올리기" },
    draw(s, g) {
      const r = 1.7, z = s.z * r, L = [-2.3, 0, -1], Rt = [2.3, 0, -1], E = [1, 0, 0], Fv = [0, 1, 0];
      for (let k = 0; k <= 4; k++) { const h = (r * k) / 4, rr = Math.sqrt(r * r - h * h); g.circle(add(L, [0, 0, h]), E, Fv, rr, { color: "b", w: 1, opacity: 0.6 }); }
      for (let k = 0; k < 6; k++) { const a = (k * Math.PI) / 6; g.circle(L, [Math.cos(a), Math.sin(a), 0], [0, 0, 1], r, { color: "b", w: 1, opacity: 0.5, from: 0, to: Math.PI }); }
      g.circle(Rt, E, Fv, r, { color: "c", w: 1.6 }).circle(add(Rt, [0, 0, r]), E, Fv, r, { color: "c", w: 1.6 });
      [0, 1, 2, 3].forEach((k) => { const a = (k * Math.PI) / 2, p = [r * Math.cos(a), r * Math.sin(a), 0]; g.seg(add(Rt, p), add(Rt, add(p, [0, 0, r])), { color: "c", w: 1.2 }); g.seg(Rt, add(Rt, add(p, [0, 0, r])), { color: "d", w: 1.2, dash: "4 4" }); });
      const rs = Math.sqrt(r * r - z * z);
      g.circle(add(L, [0, 0, z]), E, Fv, rs, { color: "a", w: 3, fill: "a", fo: 0.4, bias: 3 });
      g.circle(add(Rt, [0, 0, z]), E, Fv, r, { color: "a", w: 3, fill: "a", fo: 0.4, bias: 3 });
      if (z > 0.02) g.circle(add(Rt, [0, 0, z]), E, Fv, z, { color: "d", w: 2.4, fill: "paper", fo: 1, bias: 4 });
      g.text(add(L, [0, 0, r + 0.4]), "반구", { bold: true, color: "b" }).text(add(Rt, [0, 0, r + 0.4]), "원기둥 − 원뿔", { bold: true, color: "c" });
    },
    metrics(s) { const r = 1, z = s.z; return [["반구의 단면 π(r² − z²)", `${fmt(Math.PI * (1 - z * z), 4)} (r = 1)`], ["원기둥 − 원뿔의 단면 π(r² − z²)", fmt(Math.PI * (1 - z * z), 4)], ["구의 부피", "4/3 πr³", "key"]]; },
  },
  {
    id: "m1-relative-freq", grade: 1, unit: 8, lesson: "8.6", title: "크기가 다른 두 집단 비교 — 상대도수", type: "데이터", time: "10분",
    tags: ["상대도수", "도수분포다각형", "비교"], color: UC[8], links: ["histogram"],
    desc: "학생 수가 다른 두 학교의 통학 시간을 도수와 상대도수의 도수분포다각형으로 각각 그려, 어떤 비교가 공정한지 봅니다.",
    obs: ["도수로 비교하면 학생 수가 많은 학교가 모든 계급에서 커 보입니다.", "상대도수는 각 계급의 도수를 전체 도수로 나눈 값으로 합이 1입니다.", "크기가 다른 집단은 상대도수로 비교해야 합니다."],
    q: "B학교에서 통학 시간이 20분 이상인 학생의 비율이 더 높을까요?",
    formula: "상대도수 = (그 계급의 도수) / (도수의 총합)",
    en: { title: "Comparing Groups with Relative Frequency", desc: "Compare two schools of different sizes by frequency and by relative frequency." },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [{ key: "mode", label: "세로축", type: "seg", value: "rel", options: [["freq", "도수"], ["rel", "상대도수"]] }],
    A: [3, 8, 7, 4, 2, 1], B: [10, 24, 36, 40, 26, 14],
    draw(s, g) {
      const tA = this.A.reduce((a, b) => a + b), tB = this.B.reduce((a, b) => a + b);
      const yA = s.mode === "rel" ? this.A.map((v) => v / tA) : this.A, yB = s.mode === "rel" ? this.B.map((v) => v / tB) : this.B;
      const ym = s.mode === "rel" ? 0.4 : 45;
      const X0 = 1.8, X1 = 15.2, Y0 = 1.4, Y1 = 10.2, M = (x, y) => [X0 + ((x + 5) / 70) * (X1 - X0), Y0 + (y / ym) * (Y1 - Y0)];
      g.seg([X0, Y0], [X1, Y0], { color: "axis", w: 1.4 }).seg([X0, Y0], [X0, Y1], { color: "axis", w: 1.4 });
      for (let k = 0; k <= 4; k++) { const v = (ym * k) / 4, p = M(-5, v); g.seg([X0, p[1]], [X1, p[1]], { color: "grid", w: 1 }); g.text(p, s.mode === "rel" ? fmt(v, 2) : fmt(v), { dx: -6, dy: 4, anchor: "end", size: 11.5, color: "muted" }); }
      for (let c = 0; c <= 60; c += 10) g.text(M(c, 0), String(c), { dy: 17, size: 11.5, color: "muted" });
      g.text([X1, Y0], "통학 시간(분)", { dy: 34, anchor: "end", color: "muted", size: 12 });
      const pl = (ys, col) => g.path([M(-5, 0), ...ys.map((v, i) => M(i * 10 + 5, v)), M(65, 0)], { color: col, w: 3 });
      pl(yA, "a"); pl(yB, "b");
      g.note(430, 30, `A학교 (${tA}명)`, { color: "a", bold: true }); g.note(430, 54, `B학교 (${tB}명)`, { color: "b", bold: true });
    },
    metrics(s) { const tA = this.A.reduce((a, b) => a + b), tB = this.B.reduce((a, b) => a + b), a20 = this.A.slice(2).reduce((a, b) => a + b) / tA, b20 = this.B.slice(2).reduce((a, b) => a + b) / tB; return [["20분 이상 (A)", `${this.A.slice(2).reduce((a, b) => a + b)}명 · ${fmt(a20 * 100, 1)}%`], ["20분 이상 (B)", `${this.B.slice(2).reduce((a, b) => a + b)}명 · ${fmt(b20 * 100, 1)}%`], ["비율이 더 높은 학교", b20 > a20 ? "B학교" : "A학교", "key"]]; },
  },
  {
    id: "m1-graph-scale", grade: 1, unit: 8, lesson: "8.7", title: "그래프 눈금이 만드는 착시", type: "데이터", time: "8분",
    tags: ["그래프 해석", "눈금", "비판적 읽기"], color: UC[8], links: ["histogram"],
    desc: "세로축이 0에서 시작하지 않을 때 막대의 높이 차이가 실제 차이보다 훨씬 크게 보이는 현상을 조절해 봅니다.",
    obs: ["세로축 시작값을 올리면 작은 차이가 크게 보입니다.", "막대그래프·히스토그램은 막대의 높이(넓이)로 크기를 비교하므로 0에서 시작해야 합니다.", "눈금의 물결 표시(≈)는 생략이 있음을 알려 줍니다."],
    q: "광고에 나온 그래프를 볼 때 무엇부터 확인해야 할까요?",
    formula: "보이는 비 = (큰 값 − 시작값) / (작은 값 − 시작값)",
    en: { title: "Misleading Axis Scales", desc: "Raise the axis starting value and see small differences look huge." },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [{ key: "y0", label: "세로축 시작값", min: 0, max: 40, step: 1, value: 36 }],
    D: [["가", 41], ["나", 43], ["다", 44], ["라", 46], ["마", 48]],
    draw(s, g) {
      const X0 = 2, X1 = 15, Y0 = 1.4, Y1 = 10, top = 50, M = (y) => Y0 + ((y - s.y0) / (top - s.y0)) * (Y1 - Y0);
      g.seg([X0, Y0], [X1, Y0], { color: "axis", w: 1.4 }).seg([X0, Y0], [X0, Y1], { color: "axis", w: 1.4 });
      for (let k = 0; k <= 5; k++) { const v = s.y0 + ((top - s.y0) * k) / 5; g.seg([X0, M(v)], [X1, M(v)], { color: "grid", w: 1 }); g.text([X0, M(v)], fmt(v, 1), { dx: -6, dy: 4, anchor: "end", size: 11.5, color: "muted" }); }
      if (s.y0 > 0) g.text([X0, Y0 + 0.3], "≈", { dx: 0, size: 18, color: "d", bold: true });
      this.D.forEach(([n, v], i) => { const x = X0 + 1.4 + i * 2.5; g.poly([[x, Y0], [x + 1.6, Y0], [x + 1.6, M(v)], [x, M(v)]], { fill: "b", fo: 0.45, color: "b" }); g.text([x + 0.8, M(v)], String(v), { dy: -6, size: 12, color: "b", bold: true }); g.text([x + 0.8, Y0], n, { dy: 17, color: "muted" }); });
    },
    metrics(s) { const lo = 41, hi = 48; return [["실제 비 (마 : 가)", fmt(hi / lo, 3)], ["그래프에서 보이는 비", s.y0 < lo ? fmt((hi - s.y0) / (lo - s.y0), 2) : "—", "key"], s.y0 > 0 ? "세로축이 0에서 시작하지 않아 차이가 부풀려 보입니다." : "세로축이 0에서 시작하므로 높이 비가 실제 비와 같습니다."]; },
  },

  // ───── 중2 ─────
  {
    id: "m2-triangle-centers", grade: 2, unit: 5, lesson: "5.5", title: "외심·내심·무게중심의 위치 비교", type: "2D", time: "10분",
    tags: ["외심", "내심", "무게중심"], color: UC[5], links: ["g2-circumcenter", "g2-incenter", "g2-centroid", "lab-euler-line"],
    desc: "삼각형의 모양을 바꾸며 외심·내심·무게중심이 어디에 놓이는지, 정삼각형에서는 어떻게 되는지 한 화면에서 비교합니다.",
    obs: ["내심과 무게중심은 항상 삼각형의 내부에 있습니다.", "외심은 예각삼각형에서 내부, 직각삼각형에서 빗변의 중점, 둔각삼각형에서 외부에 있습니다.", "정삼각형에서는 세 점이 한 점에서 만납니다."],
    q: "이등변삼각형에서 세 중심은 어떤 직선 위에 있을까요?",
    formula: "외심 O: OA = OB = OC · 내심 I: 세 변까지 거리 같음 · 무게중심 G: 중선을 2 : 1로 내분",
    en: { title: "Comparing Triangle Centers", desc: "See where the circumcenter, incenter and centroid lie as the triangle changes." },
    view: V, points: { A: [-0.5, 3.6], B: [-4.5, -2.6], C: [4, -2.6] },
    params: [{ key: "O", label: "외심과 외접원", type: "check", value: true }, { key: "I", label: "내심과 내접원", type: "check", value: true }, { key: "Gc", label: "무게중심과 중선", type: "check", value: true }],
    centers(s) {
      const { A, B, C } = s, a = dist(B, C), b = dist(C, A), c = dist(A, B);
      const d = 2 * (A[0] * (B[1] - C[1]) + B[0] * (C[1] - A[1]) + C[0] * (A[1] - B[1]));
      const ux = ((A[0] ** 2 + A[1] ** 2) * (B[1] - C[1]) + (B[0] ** 2 + B[1] ** 2) * (C[1] - A[1]) + (C[0] ** 2 + C[1] ** 2) * (A[1] - B[1])) / d;
      const uy = ((A[0] ** 2 + A[1] ** 2) * (C[0] - B[0]) + (B[0] ** 2 + B[1] ** 2) * (A[0] - C[0]) + (C[0] ** 2 + C[1] ** 2) * (B[0] - A[0])) / d;
      const I = mul(add(add(mul(A, a), mul(B, b)), mul(C, c)), 1 / (a + b + c)), S = area3(A, B, C);
      return { O: [ux, uy], R: dist([ux, uy], A), I, r: (2 * S) / (a + b + c), G: mul(add(add(A, B), C), 1 / 3) };
    },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const { A, B, C } = s, K = this.centers(s);
      g.poly([A, B, C], { fill: "b", fo: 0.06, color: "ink", w: 2.6 });
      if (s.O && Number.isFinite(K.R)) { g.circle(K.O, K.R, { color: "a", w: 1.6, dash: "5 5" }); [A, B, C].forEach((p) => g.seg(K.O, p, { color: "a", w: 1, opacity: 0.6 })); g.point(K.O, "O", { color: "a" }); }
      if (s.I) { g.circle(K.I, K.r, { color: "c", w: 1.6 }); g.point(K.I, "I", { color: "c" }); }
      if (s.Gc) { [[A, lerp(B, C, 0.5)], [B, lerp(C, A, 0.5)], [C, lerp(A, B, 0.5)]].forEach(([p, m]) => g.seg(p, m, { color: "e", w: 1.2, opacity: 0.7 })); g.point(K.G, "G", { color: "e" }); }
      g.point(A, "A").point(B, "B", { dy: 20 }).point(C, "C", { dy: 20 });
      g.handle(A, "A").handle(B, "B").handle(C, "C");
    },
    metrics(s) { const { A, B, C } = s, angs = [ang(A, B, C), ang(B, A, C), ang(C, A, B)], mx = Math.max(...angs), K = this.centers(s); return [["삼각형", Math.abs(mx - 90) < 0.5 ? "직각삼각형" : mx > 90 ? "둔각삼각형" : "예각삼각형"], ["외심의 위치", Math.abs(mx - 90) < 0.5 ? "빗변의 중점" : mx > 90 ? "외부" : "내부", "key"], ["외접원 R · 내접원 r", `${fmt(K.R)} · ${fmt(K.r)}`]]; },
  },
  {
    id: "m2-quad-family", grade: 2, unit: 6, lesson: "6.4", title: "사각형 가족 — 조건에 따라 이름이 바뀐다", type: "조작", time: "12분",
    tags: ["사각형의 포함 관계", "사다리꼴", "마름모"], color: UC[6], links: ["g2-quadrilaterals", "g2-parallel-condition"],
    desc: "네 꼭짓점을 자유롭게 움직이면 변의 평행·길이, 각, 대각선의 성질을 자동으로 검사해 사각형의 이름과 포함 관계를 알려 줍니다.",
    obs: ["정사각형은 직사각형이면서 마름모입니다.", "평행사변형은 사다리꼴의 한 종류입니다.", "조건을 하나씩 더할수록 더 특별한 사각형이 됩니다."],
    q: "대각선이 서로 수직이등분하는 사각형은 무엇일까요?",
    formula: "사다리꼴 ⊃ 평행사변형 ⊃ 직사각형·마름모 ⊃ 정사각형",
    en: { title: "The Quadrilateral Family", desc: "Drag four vertices and let the page name the quadrilateral and its family." },
    view: V, snap: 0.5, points: { A: [-4, -2.5], B: [3, -2.5], C: [4.5, 2], D: [-2.5, 2] },
    buttons: [["par", "평행사변형으로"], ["rect", "직사각형으로"], ["rho", "마름모로"], ["sq", "정사각형으로"]],
    onDo(k, s) {
      if (k === "par") s.C = add(s.B, sub(s.D, s.A));
      if (k === "rect") { const u = sub(s.B, s.A), n = [-u[1], u[0]], L = 4 / (len(u) || 1); s.D = add(s.A, mul(n, L)); s.C = add(s.B, mul(n, L)); }
      if (k === "rho") { const u = sub(s.B, s.A), L = len(u), v = mul([Math.cos(1.1), Math.sin(1.1)], L); s.D = add(s.A, v); s.C = add(s.B, v); }
      if (k === "sq") { const u = sub(s.B, s.A), n = [-u[1], u[0]]; s.D = add(s.A, n); s.C = add(s.B, n); }
    },
    props(s) {
      const P = [s.A, s.B, s.C, s.D], e = (i) => sub(P[(i + 1) % 4], P[i]), par = (u, v) => Math.abs(u[0] * v[1] - u[1] * v[0]) < 1e-6 * (len(u) * len(v) + 1);
      const p1 = par(e(0), e(2)), p2 = par(e(1), e(3)), L = [0, 1, 2, 3].map((i) => len(e(i))), eqs = Math.max(...L) - Math.min(...L) < 1e-6, right = Math.abs(dot(e(0), e(1))) < 1e-6 && Math.abs(dot(e(1), e(2))) < 1e-6;
      const d1 = sub(s.C, s.A), d2 = sub(s.D, s.B), diagEq = Math.abs(len(d1) - len(d2)) < 1e-6, diagPerp = Math.abs(dot(d1, d2)) < 1e-6;
      let name = "일반 사각형";
      if (p1 || p2) name = "사다리꼴";
      if ((p1 || p2) && !(p1 && p2) && diagEq) name = "등변사다리꼴";
      if (p1 && p2) name = "평행사변형";
      if (p1 && p2 && right) name = "직사각형";
      if (p1 && p2 && eqs) name = "마름모";
      if (p1 && p2 && eqs && right) name = "정사각형";
      return { name, p1, p2, eqs, right, diagEq, diagPerp };
    },
    draw(s, g) {
      g.grid({ labels: false });
      const P = [s.A, s.B, s.C, s.D], pr = this.props(s);
      g.poly(P, { fill: "b", fo: 0.12, color: "ink", w: 2.8 });
      g.seg(s.A, s.C, { color: pr.diagEq ? "c" : "muted", w: 1.6, dash: "5 4" }).seg(s.B, s.D, { color: pr.diagEq ? "c" : "muted", w: 1.6, dash: "5 4" });
      if (pr.p1) { g.seg(s.A, s.B, { color: "a", w: 4.4, opacity: 0.6 }); g.seg(s.C, s.D, { color: "a", w: 4.4, opacity: 0.6 }); }
      if (pr.p2) { g.seg(s.B, s.C, { color: "e", w: 4.4, opacity: 0.6 }); g.seg(s.D, s.A, { color: "e", w: 4.4, opacity: 0.6 }); }
      const tree = [["일반 사각형", 0], ["사다리꼴", 1], ["평행사변형", 2], ["직사각형", 3], ["마름모", 3], ["정사각형", 4]];
      tree.forEach(([n, lv], i) => g.note(470 + (n === "마름모" ? 88 : 0), 26 + lv * 22, (n === pr.name ? "● " : "○ ") + n, { color: n === pr.name ? "d" : "muted", bold: n === pr.name, size: 13 }));
      P.forEach((p, i) => { g.point(p, "ABCD"[i], { color: "ink" }); g.handle(p, "ABCD"[i]); });
    },
    metrics(s) { const pr = this.props(s); return [["이름", pr.name, "key"], ["평행한 대변", `${(pr.p1 ? 1 : 0) + (pr.p2 ? 1 : 0)}쌍`], ["대각선", `${pr.diagEq ? "길이 같음" : "길이 다름"} · ${pr.diagPerp ? "수직" : "수직 아님"}`]]; },
  },
  {
    id: "m2-parallel-area", grade: 2, unit: 6, lesson: "6.5", title: "평행선과 넓이 — 모양은 바뀌어도 넓이는 그대로", type: "조작", time: "8분",
    tags: ["등적변형", "평행선", "높이"], color: UC[6], links: ["m2-quad-family"],
    desc: "밑변 AB가 같고 꼭짓점 P가 AB에 평행한 직선 위를 움직이는 삼각형의 넓이가 변하지 않음을 보고, 이를 이용해 사각형을 넓이가 같은 삼각형으로 바꿉니다.",
    obs: ["평행선 사이의 거리(높이)가 같으므로 넓이가 같습니다.", "사각형 ABCD에서 D를 AC에 평행하게 옮기면 넓이가 같은 삼각형이 됩니다."],
    q: "땅의 경계선을 넓이 변화 없이 곧게 펴려면 어떻게 할까요?",
    formula: "l ∥ m이면 △ABP = △ABQ (P, Q는 l 위의 점)",
    en: { title: "Parallel Lines and Equal Areas", desc: "Slide a vertex along a parallel line; the area stays the same." },
    view: V,
    params: [{ key: "mode", label: "활동", type: "seg", value: "tri", options: [["tri", "삼각형"], ["quad", "사각형 → 삼각형"]] }, { key: "x", label: "꼭짓점 위치", min: -6, max: 6, step: 0.05, value: -1 }],
    anim: { key: "x", min: -6, max: 6, speed: 2.4, label: "꼭짓점 밀기" },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      if (s.mode === "tri") {
        const A = [-3, -2.5], B = [2.5, -2.5], P = [s.x, 2.5];
        g.seg([-7, 2.5], [7, 2.5], { color: "muted", w: 1.6, dash: "6 5" }).seg([-7, -2.5], [7, -2.5], { color: "muted", w: 1.6, dash: "6 5" });
        g.poly([A, B, P], { fill: "a", fo: 0.25, color: "a", w: 2.6 });
        g.seg(P, [P[0], -2.5], { color: "e", w: 1.6, dash: "4 4" }).text([P[0], 0], "높이 5", { dx: 8, anchor: "start", color: "e", bold: true, size: 13 });
        g.point(A, "A", { dy: 20 }).point(B, "B", { dy: 20 }).point(P, "P", { color: "a" });
      } else {
        const A = [-4, -2.5], B = [3, -2.5], C = [4, 1.5], D = [-1.5, 3.2], dir = norm(sub(C, A)), t = (s.x + 6) / 12, E0 = D, lineP = (u) => add(D, mul(dir, u));
        const ux = (() => { const tt = (-2.5 - D[1]) / dir[1]; return tt; })(), E = lineP(ux * t);
        g.poly([A, B, C, D], { color: "muted", w: 1.4, dash: "4 4" });
        g.line(D, add(D, dir), { color: "e", w: 1.4, dash: "6 5" });
        g.seg(A, C, { color: "muted", w: 1.2 });
        g.poly([A, B, C, E], { fill: "c", fo: 0.25, color: "c", w: 2.6 });
        g.point(A, "A", { dy: 20 }).point(B, "B", { dy: 20 }).point(C, "C").point(D, "D", { color: "muted" }).point(E, "D′", { color: "c" });
      }
    },
    metrics(s) {
      if (s.mode === "tri") return [["밑변 × 높이 ÷ 2", "5.5 × 5 ÷ 2"], ["넓이", "13.75 (변하지 않음)", "key"]];
      const A = [-4, -2.5], B = [3, -2.5], C = [4, 1.5], D = [-1.5, 3.2], S = area3(A, B, C) + area3(A, C, D);
      return [["사각형 ABCD의 넓이", fmt(S, 3), "key"], ["D′를 AC에 평행하게 옮김", "△ACD = △ACD′"], "D′가 AB의 연장선에 닿으면 사각형이 넓이가 같은 삼각형이 됩니다."];
    },
  },
  {
    id: "m2-right-similar", grade: 2, unit: 7, lesson: "7.2", title: "직각삼각형의 닮음과 넓이", type: "2D", time: "10분",
    tags: ["직각삼각형의 닮음", "수선", "비례"], color: UC[7], links: ["g2-similar-triangles", "g2-pythagoras"],
    desc: "직각삼각형의 직각인 꼭짓점에서 빗변에 수선을 내리면 생기는 세 직각삼각형이 모두 닮음이고, AB² = BH·BC 같은 관계가 성립함을 확인합니다.",
    obs: ["△ABC ∽ △HBA ∽ △HAC입니다(AA 닮음).", "AB² = BH × BC, AC² = CH × CB, AH² = BH × CH입니다.", "앞의 두 식을 더하면 피타고라스 정리가 나옵니다."],
    q: "AB² + AC² = BC²를 이 관계로 증명해 보세요.",
    formula: "AB² = BH·BC · AC² = CH·CB · AH² = BH·CH",
    en: { title: "Similarity in Right Triangles", desc: "The altitude to the hypotenuse makes three similar right triangles." },
    view: V, points: { A: [-1.2, 3] },
    constrain(s, k, p) { const B = [-5, -2.5], C = [5, -2.5], M = [0, -2.5], r = 5, d = sub(p, M), l = len(d) || 1; let q = add(M, mul(d, r / l)); if (q[1] < -2.2) q = [clamp(q[0], -4.6, 4.6), -2.5 + Math.sqrt(Math.max(0.1, 25 - clamp(q[0], -4.6, 4.6) ** 2))]; return q; },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const B = [-5, -2.5], C = [5, -2.5], A = s.A, H = [A[0], -2.5];
      g.circle([0, -2.5], 5, { color: "muted", w: 1, dash: "3 6" });
      g.poly([A, B, H], { fill: "a", fo: 0.2, color: "a", w: 2 }).poly([A, H, C], { fill: "b", fo: 0.2, color: "b", w: 2 });
      g.poly([A, B, C], { color: "ink", w: 2.6 });
      g.right(A, B, C, { size: 12 }).right(H, A, C, { size: 10 });
      g.text(lerp(B, H, 0.5), `BH = ${fmt(dist(B, H))}`, { dy: 20, color: "a", bold: true, size: 13 }).text(lerp(H, C, 0.5), `CH = ${fmt(dist(H, C))}`, { dy: 20, color: "b", bold: true, size: 13 });
      g.point(A, "A").point(B, "B", { dy: 20 }).point(C, "C", { dy: 20 }).point(H, "H", { dy: 20 });
      g.handle(A, "A");
    },
    metrics(s) { const B = [-5, -2.5], C = [5, -2.5], A = s.A, H = [A[0], -2.5]; return [["AB²", fmt(dist(A, B) ** 2, 3)], ["BH × BC", fmt(dist(B, H) * 10, 3)], ["AH²", fmt(dist(A, H) ** 2, 3)], ["BH × CH", fmt(dist(B, H) * dist(H, C), 3), "key"]]; },
  },
  {
    id: "m2-shadow-height", grade: 2, unit: 7, lesson: "7.2", title: "닮음으로 높이 재기 — 그림자와 막대", type: "조작", time: "8분",
    tags: ["닮음의 활용", "그림자", "탈레스"], color: UC[7], links: ["g2-similar-triangles", "g3-trig-height"],
    desc: "같은 시각에 막대와 나무의 그림자는 닮은 직각삼각형을 만든다는 사실로 직접 잴 수 없는 높이를 구합니다.",
    obs: ["햇빛은 평행하게 들어오므로 두 삼각형의 각이 같습니다(AA 닮음).", "(나무 높이) : (나무 그림자) = (막대 높이) : (막대 그림자)입니다."],
    q: "탈레스는 피라미드의 높이를 어떻게 재었을까요?",
    formula: "H = h × (L / l)",
    en: { title: "Measuring Height with Shadows", desc: "Use similar triangles from shadows to find an unreachable height." },
    view: { x: [-7, 7], y: [-3.6, 6.2] },
    params: [{ key: "sun", label: "태양의 고도", min: 20, max: 70, step: 1, value: 40, unit: "°" }, { key: "h", label: "막대 높이 (m)", min: 0.5, max: 2, step: 0.1, value: 1 }, { key: "H", label: "나무의 실제 높이 (m)", min: 3, max: 9, step: 0.5, value: 6 }],
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const k = 0.62, t = Math.tan(deg(s.sun)), gr = -3;
      g.seg([-7, gr], [7, gr], { color: "ink", w: 2 });
      const T0 = [-5.2, gr], T1 = [-5.2, gr + s.H * k], TS = [-5.2 + (s.H * k) / t, gr];
      g.poly([T0, T1, TS], { fill: "c", fo: 0.12, stroke: false }); g.seg(T0, T1, { color: "c", w: 6 }); g.circle(T1, 0.5, { color: "c", fill: "c", fo: 0.5 });
      g.seg(T1, TS, { color: "f", w: 1.6, dash: "6 4" }); g.seg(T0, TS, { color: "muted", w: 5, opacity: 0.6 });
      const S0 = [3, gr], S1 = [3, gr + s.h * k], SS = [3 + (s.h * k) / t, gr];
      g.seg(S0, S1, { color: "a", w: 4 }); g.seg(S1, SS, { color: "f", w: 1.6, dash: "6 4" }); g.seg(S0, SS, { color: "muted", w: 5, opacity: 0.6 });
      g.arc(TS, T0, T1, { r: 24, color: "f", ccw: false }).arc(SS, S0, S1, { r: 24, color: "f", ccw: false });
      g.text(lerp(T0, TS, 0.5), `그림자 ${fmt(s.H / t, 2)} m`, { dy: 20, size: 13 }).text(lerp(S0, SS, 0.5), `${fmt(s.h / t, 2)} m`, { dy: 20, size: 13 });
      g.text(T1, "나무 높이 = ?", { dy: -16, color: "c", bold: true }).text(S1, `막대 ${fmt(s.h)} m`, { dy: -10, color: "a", bold: true });
    },
    metrics(s) { const t = Math.tan(deg(s.sun)), L = s.H / t, l = s.h / t; return [["나무 그림자 L", `${fmt(L, 2)} m`], ["막대 그림자 l", `${fmt(l, 2)} m`], ["H = h × L / l", `${fmt((s.h * L) / l, 2)} m`, "key"]]; },
  },
  {
    id: "m2-midpoint-quad", grade: 2, unit: 7, lesson: "7.3", title: "사각형의 중점을 이으면 — 바리뇽의 평행사변형", type: "조작", time: "8분",
    tags: ["중점 연결 정리", "평행사변형", "넓이 절반"], color: UC[7], links: ["g2-parallel-ratios", "m2-quad-family"],
    desc: "어떤 사각형이든 네 변의 중점을 차례로 이으면 평행사변형이 되고, 그 넓이는 처음 사각형의 절반임을 확인합니다.",
    obs: ["각 변은 대각선과 평행하고 길이가 대각선의 절반입니다(중점 연결 정리).", "대각선의 길이가 같으면 마름모, 대각선이 수직이면 직사각형이 됩니다.", "넓이는 항상 원래 사각형의 1/2입니다."],
    q: "처음 사각형이 직사각형이면 중점을 이은 사각형은 무엇일까요?",
    formula: "PQ ∥ AC, PQ = ½AC (P, Q는 AB, BC의 중점)",
    en: { title: "Varignon's Parallelogram", desc: "Join the midpoints of any quadrilateral to get a parallelogram of half the area." },
    view: V, snap: 0.5, points: { A: [-5, -2], B: [2, -3.5], C: [5, 2.5], D: [-2, 3.5] },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const P = [s.A, s.B, s.C, s.D], M = P.map((p, i) => lerp(p, P[(i + 1) % 4], 0.5));
      g.poly(P, { fill: "b", fo: 0.08, color: "ink", w: 2.6 });
      g.seg(s.A, s.C, { color: "muted", w: 1.4, dash: "5 4" }).seg(s.B, s.D, { color: "muted", w: 1.4, dash: "5 4" });
      g.poly(M, { fill: "a", fo: 0.25, color: "a", w: 2.8 });
      M.forEach((m, i) => g.point(m, "PQRS"[i], { color: "a", r: 4.5 }));
      P.forEach((p, i) => { g.point(p, "ABCD"[i]); g.handle(p, "ABCD"[i], { color: "b" }); });
    },
    metrics(s) { const P = [s.A, s.B, s.C, s.D], M = P.map((p, i) => lerp(p, P[(i + 1) % 4], 0.5)), S = area3(P[0], P[1], P[2]) + area3(P[0], P[2], P[3]), Sm = area3(M[0], M[1], M[2]) + area3(M[0], M[2], M[3]); return [["PQ · SR", `${fmt(dist(M[0], M[1]))} · ${fmt(dist(M[3], M[2]))}`], ["½AC", fmt(dist(s.A, s.C) / 2)], ["넓이 비", `${fmt(Sm, 2)} : ${fmt(S, 2)} = 1 : 2`, "key"]]; },
  },
  {
    id: "m2-pythag-proof", grade: 2, unit: 7, lesson: "7.5", title: "피타고라스 정리 증명 퍼즐", type: "조작", time: "12분",
    tags: ["피타고라스", "넓이 증명", "재배열"], color: UC[7], links: ["g2-pythagoras", "alg-cosine-law"],
    desc: "한 변이 a + b인 정사각형 안에 합동인 직각삼각형 4개를 옮겨 놓아, 남는 부분이 c² 하나에서 a² + b² 두 개로 바뀌는 것을 애니메이션으로 봅니다.",
    obs: ["두 배치에서 큰 정사각형과 삼각형 4개의 넓이는 같습니다.", "따라서 남은 부분의 넓이도 같아 c² = a² + b²입니다."],
    q: "직각삼각형이 아니어도 이 퍼즐이 성립할까요?",
    formula: "(a + b)² − 4 × ½ab = c² = a² + b²",
    en: { title: "Pythagorean Theorem Puzzle", desc: "Rearrange four right triangles inside an (a + b) square to turn c² into a² + b²." },
    view: { x: [-6, 6], y: [-4.2, 4.2] },
    params: [{ key: "a", label: "a", min: 1, max: 4.5, step: 0.1, value: 2.2 }, { key: "t", label: "옮기기", min: 0, max: 1, step: 0.01, value: 0, show: (v) => `${Math.round(v * 100)}%` }],
    anim: { key: "t", min: 0, max: 1, speed: 0.45, label: "재배열하기" },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const a = s.a, b = 6 - a, O = [-3, -3], P = (x, y) => add(O, [x, y]);
      g.poly([P(0, 0), P(6, 0), P(6, 6), P(0, 6)], { color: "ink", w: 2.4 });
      const T1 = [[P(0, 0), P(a, 0), P(0, b)], [P(a, 0), P(6, 0), P(6, a)], [P(6, a), P(6, 6), P(b, 6)], [P(b, 6), P(0, 6), P(0, b)]];
      const T2 = [[P(0, 0), P(a, 0), P(0, b)].map((q) => q), [P(a, b), P(a, 0), P(0, b)], [P(a, b), P(6, b), P(a, 6)], [P(6, 6), P(6, b), P(a, 6)]];
      const tt = (1 - Math.cos(Math.PI * s.t)) / 2, cols = ["a", "b", "e", "f"];
      T1.forEach((tri, i) => g.poly(tri.map((p, j) => lerp(p, T2[i][j], tt)), { fill: cols[i], fo: 0.55, color: cols[i], w: 1.6 }));
      if (s.t < 0.02) g.text(P(3, 3), "c²", { size: 24, bold: true, color: "c" });
      if (s.t > 0.98) { g.text(P(a / 2, b + a / 2), "a²", { size: 22, bold: true, color: "c" }); g.text(P(a + b / 2, b / 2), "b²", { size: 22, bold: true, color: "c" }); }
    },
    metrics(s) { const a = s.a, b = 6 - a, c2 = a * a + b * b; return [["a · b", `${fmt(a)} · ${fmt(b)}`], ["a² + b²", fmt(a * a + b * b, 3)], ["c²", fmt(c2, 3), "key"]]; },
  },

  // ───── 중3 ─────
  {
    id: "m3-trig-table", grade: 3, unit: 5, lesson: "5.3", title: "삼각비의 표 읽기 — 사분원 위의 길이", type: "2D", time: "8분",
    tags: ["삼각비의 표", "사분원", "근삿값"], color: UC[5], links: ["g3-acute-trig", "alg-unit-circle"],
    desc: "반지름 1인 사분원에서 각을 1°씩 바꾸며 sin, cos, tan에 해당하는 선분의 길이를 읽고 삼각비의 표와 비교합니다.",
    obs: ["반지름이 1이면 sin x°는 높이, cos x°는 밑변의 길이입니다.", "tan x°는 x = 1에 세운 접선 위의 길이입니다.", "표는 소수 넷째 자리까지의 근삿값을 보여 줍니다."],
    q: "sin 40°와 cos 50°의 값이 같은 까닭은 무엇일까요?",
    formula: "sin x° = BC, cos x° = OB, tan x° = AD (반지름 1)",
    en: { title: "Reading a Trigonometric Table", desc: "Read segment lengths on a unit quarter circle and compare with the table." },
    view: { x: [-0.6, 9.2], y: [-0.6, 5.8] },
    params: [{ key: "x", label: "각 x°", min: 0, max: 89, step: 1, value: 37, unit: "°" }],
    draw(s, g) {
      g.grid({ labels: false });
      const R = 5, t = deg(s.x), P = [R * Math.cos(t), R * Math.sin(t)], T = [R, R * Math.tan(t)];
      g.param((u) => [R * Math.cos(u), R * Math.sin(u)], 0, Math.PI / 2, { color: "muted", w: 1.6 });
      if (T[1] < 5.8) { g.seg([R, 0], T, { color: "d", w: 3.2 }); g.seg([0, 0], T, { color: "muted", w: 1.2, dash: "4 4" }); }
      g.seg([0, 0], P, { color: "ink", w: 2.2 }).seg([P[0], 0], P, { color: "a", w: 3.4 }).seg([0, 0], [P[0], 0], { color: "b", w: 3.4 });
      g.arc([0, 0], [1, 0], P, { r: 30, color: "e", label: `${s.x}°` });
      const rows = [s.x - 2, s.x - 1, s.x, s.x + 1, s.x + 2].filter((v) => v >= 0 && v <= 89);
      g.note(412, 36, "각     sin     cos     tan", { color: "muted", mono: true, bold: true });
      rows.forEach((v, i) => { const r = deg(v); g.note(412, 62 + i * 24, `${String(v).padStart(2, " ")}°  ${Math.sin(r).toFixed(4)}  ${Math.cos(r).toFixed(4)}  ${Math.tan(r).toFixed(4)}`, { color: v === s.x ? "d" : "ink", mono: true, bold: v === s.x }); });
    },
    metrics(s) { const r = deg(s.x); return [["sin x° (높이)", Math.sin(r).toFixed(4)], ["cos x° (밑변)", Math.cos(r).toFixed(4)], ["tan x° (접선 길이)", Math.tan(r).toFixed(4), "key"]]; },
  },
  {
    id: "m3-trig-distance", grade: 3, unit: 5, lesson: "5.4", title: "삼각비로 두 지점 사이의 거리 구하기", type: "조작", time: "10분",
    tags: ["삼각비의 활용", "수선", "거리"], color: UC[5], links: ["g3-trig-height", "alg-cosine-law"],
    desc: "호수 양쪽의 두 지점 B, C 사이 거리를, 두 변과 끼인각을 알고 C에서 AB에 수선을 내려 삼각비로 계산합니다.",
    obs: ["수선을 그으면 일반 삼각형이 두 직각삼각형으로 나뉩니다.", "CH = b sin A, AH = b cos A로 구합니다.", "BC = √(CH² + BH²)입니다."],
    q: "끼인각이 둔각이면 수선의 발은 어디에 생길까요?",
    formula: "BC = √((b sin A)² + (c − b cos A)²)",
    en: { title: "Distance Between Two Points by Trigonometry", desc: "Drop a perpendicular and use trigonometric ratios to find an unreachable distance." },
    view: { x: [-6, 6.6], y: [-3.6, 4.6] },
    params: [{ key: "b", label: "AC (m)", min: 40, max: 120, step: 5, value: 80 }, { key: "c", label: "AB (m)", min: 40, max: 120, step: 5, value: 100 }, { key: "A", label: "∠A", min: 20, max: 140, step: 1, value: 60, unit: "°" }],
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const k = 0.07, A = [-4.6, -2.6], B = add(A, [s.c * k, 0]), C = add(A, [s.b * k * Math.cos(deg(s.A)), s.b * k * Math.sin(deg(s.A))]), H = [C[0], A[1]];
      g.circle(lerp(B, C, 0.5), dist(B, C) * 0.28, { color: "b", fill: "b", fo: 0.25, w: 1 });
      g.text(lerp(B, C, 0.5), "호수", { dy: 4, color: "b", bold: true });
      g.poly([A, B, C], { color: "ink", w: 2.4 });
      g.seg(C, H, { color: "e", w: 2, dash: "6 4" }); if (H[0] < A[0] || H[0] > B[0]) g.seg(H[0] < A[0] ? H : B, H[0] < A[0] ? A : H, { color: "muted", w: 1.2, dash: "3 4" });
      g.right(H, C, B, { size: 10 });
      g.seg(B, C, { color: "d", w: 3.4 });
      g.arc(A, B, C, { r: 26, color: "a", label: `${s.A}°` });
      g.point(A, "A", { dy: 20 }).point(B, "B", { dy: 20 }).point(C, "C").point(H, "H", { dy: 20, r: 3.5 });
    },
    metrics(s) { const r = deg(s.A), CH = s.b * Math.sin(r), AH = s.b * Math.cos(r), BH = s.c - AH; return [["CH = b sin A", `${fmt(CH, 2)} m`], ["BH = c − b cos A", `${fmt(BH, 2)} m`], ["BC", `${fmt(Math.hypot(CH, BH), 2)} m`, "key"]]; },
  },
  {
    id: "m3-tangent-quad", grade: 3, unit: 6, lesson: "6.2", title: "원에 외접하는 사각형", type: "조작", time: "10분",
    tags: ["접선의 길이", "외접사각형", "AB + CD = AD + BC"], color: UC[6], links: ["g3-circle-tangent", "c2-tangent"],
    desc: "원 위의 네 접점을 움직여 접선으로 만든 사각형에서, 한 꼭짓점에서 그은 두 접선의 길이가 같다는 사실로 마주 보는 두 변의 합이 같음을 확인합니다.",
    obs: ["같은 색 선분은 한 점에서 그은 두 접선으로 길이가 같습니다.", "그래서 AB + CD와 AD + BC는 같은 네 길이의 합입니다."],
    q: "마주 보는 두 변의 합이 같은 사각형은 항상 원에 외접할까요?",
    formula: "AB + CD = AD + BC",
    en: { title: "Quadrilaterals Circumscribed about a Circle", desc: "Equal tangent lengths make opposite side sums equal." },
    view: V,
    params: [0, 1, 2, 3].map((i) => ({ key: `t${i}`, label: `접점 ${"PQRS"[i]}의 위치`, min: i * 90 + 15, max: i * 90 + 85, step: 1, value: [30, 140, 215, 310][i], unit: "°" })),
    quad(s) {
      const r = 2.4, T = [0, 1, 2, 3].map((i) => deg(s[`t${i}`])), pts = [];
      for (let i = 0; i < 4; i++) { const a = T[i], b = T[(i + 1) % 4], m = (a + (b < a ? b + 2 * Math.PI : b)) / 2, h = ((b < a ? b + 2 * Math.PI : b) - a) / 2; pts.push([(r / Math.cos(h)) * Math.cos(m), (r / Math.cos(h)) * Math.sin(m)]); }
      return { r, T, V: pts };
    },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const { r, T, V: Q } = this.quad(s), Tp = T.map((a) => [r * Math.cos(a), r * Math.sin(a)]), cols = ["a", "b", "c", "e"];
      g.circle([0, 0], r, { color: "muted", w: 1.8, fill: "b", fo: 0.05 });
      if (Q.every((p) => len(p) < 30)) Q.forEach((v, i) => { g.seg(v, Tp[i], { color: cols[i], w: 3.4 }); g.seg(v, Tp[(i + 1) % 4], { color: cols[i], w: 3.4 }); g.point(v, "ABCD"[i], { color: "ink" }); });
      Tp.forEach((p, i) => g.point(p, "PQRS"[i], { color: "muted", r: 3.5 }));
    },
    metrics(s) { const { V: Q } = this.quad(s), d = (i) => dist(Q[i], Q[(i + 1) % 4]); return [["AB + CD", fmt(d(0) + d(2), 3)], ["BC + DA", fmt(d(1) + d(3), 3)], ["결과", Math.abs(d(0) + d(2) - d(1) - d(3)) < 1e-6 ? "같음" : "다름", "key"]]; },
  },
  {
    id: "m3-horizon", grade: 3, unit: 6, lesson: "6.2", title: "전망대에서 보이는 수평선까지의 거리", type: "조작", time: "8분",
    tags: ["접선과 반지름", "피타고라스", "실생활"], color: UC[6], links: ["g3-circle-tangent", "m3-tangent-quad"],
    desc: "지구를 원으로, 시선을 접선으로 보고 높이 h인 전망대에서 수평선까지의 거리 √((R + h)² − R²)를 계산합니다.",
    obs: ["수평선은 시선이 지구에 접하는 점입니다.", "접점에서 반지름과 접선은 수직이므로 피타고라스 정리를 씁니다.", "h가 R보다 아주 작으면 거리 ≈ √(2Rh)입니다."],
    q: "전망대 높이를 4배로 하면 보이는 거리는 몇 배가 될까요?",
    formula: "d = √((R + h)² − R²) ≈ √(2Rh)",
    en: { title: "Distance to the Horizon", desc: "Model Earth as a circle and the line of sight as a tangent." },
    view: { x: [-6, 6], y: [-5.5, 4.2] },
    params: [{ key: "h", label: "전망대 높이 h (m)", min: 10, max: 900, step: 10, value: 480 }],
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const R = 4.4, hh = 0.35 + (s.h / 900) * 2.4, O = [0, -R + 1], P = add(O, [0, R + hh]), d = Math.sqrt((R + hh) ** 2 - R * R), th = Math.acos(R / (R + hh)), T = add(O, [R * Math.sin(th), R * Math.cos(th)]);
      g.circle(O, R, { color: "b", fill: "b", fo: 0.12, w: 2.4 });
      g.seg(add(O, [0, R]), P, { color: "ink", w: 4 });
      g.seg(P, T, { color: "a", w: 3 }).seg(O, T, { color: "muted", w: 1.6, dash: "5 4" }).seg(O, P, { color: "muted", w: 1.6, dash: "5 4" });
      g.right(T, O, P, { size: 12 });
      g.point(P, "전망대", { color: "ink" }).point(T, "수평선", { color: "a" }).point(O, "지구 중심", { color: "ink", dy: 20, r: 3.5 });
      g.note(18, 424, "※ 높이는 보기 좋게 과장해 그렸습니다", { color: "muted", size: 12 });
    },
    metrics(s) { const R = 6400000, h = s.h, d = Math.sqrt((R + h) ** 2 - R * R); return [["지구 반지름 R", "약 6400 km"], ["수평선까지 거리", `${fmt(d / 1000, 1)} km`, "key"], ["근삿값 √(2Rh)", `${fmt(Math.sqrt(2 * R * h) / 1000, 1)} km`]]; },
  },
  {
    id: "m3-arc-angle", grade: 3, unit: 6, lesson: "6.3", title: "원주각의 크기와 호의 길이", type: "2D", time: "8분",
    tags: ["원주각", "호의 길이", "정비례"], color: UC[6], links: ["g3-inscribed-angle", "m3-concyclic"],
    desc: "한 원에서 두 호에 대한 원주각을 비교하며 원주각의 크기가 호의 길이에 정비례함을 확인합니다.",
    obs: ["길이가 같은 호에 대한 원주각은 크기가 같습니다.", "호의 길이가 2배이면 원주각도 2배입니다.", "원주각이 모두 같으면 그 호들의 길이도 같습니다."],
    q: "원을 12등분한 점들로 만든 원주각은 몇 도 단위로 커질까요?",
    formula: "(원주각) : (원주각) = (호의 길이) : (호의 길이)",
    en: { title: "Inscribed Angles and Arc Lengths", desc: "Inscribed angles are proportional to the arcs they subtend." },
    view: V,
    params: [{ key: "a1", label: "호 AB의 중심각", min: 20, max: 160, step: 5, value: 60, unit: "°" }, { key: "a2", label: "호 CD의 중심각", min: 20, max: 160, step: 5, value: 120, unit: "°" }],
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const R = 3.8, P = (d) => [R * Math.cos(deg(d)), R * Math.sin(deg(d))];
      g.circle([0, 0], R, { color: "muted", w: 1.8 });
      const A = P(200), B = P(200 + s.a1), Cc = P(20), D = P(20 + s.a2), X = P(200 + s.a1 + (360 - s.a1 - s.a2) * 0.2 + 5), Y = P(20 + s.a2 + 10);
      g.param((u) => P(u), 200, 200 + s.a1, { color: "a", w: 6, opacity: 0.6 }).param((u) => P(u), 20, 20 + s.a2, { color: "b", w: 6, opacity: 0.6 });
      const vAB = P(100), vCD = P(190);
      g.seg(vAB, A, { color: "a", w: 2 }).seg(vAB, B, { color: "a", w: 2 }).arc(vAB, A, B, { r: 30, color: "a", ccw: false, label: `${fmt(s.a1 / 2)}°` });
      g.seg(vCD, Cc, { color: "b", w: 2 }).seg(vCD, D, { color: "b", w: 2 }).arc(vCD, Cc, D, { r: 30, color: "b", ccw: false, label: `${fmt(s.a2 / 2)}°` });
      [[A, "A"], [B, "B"], [Cc, "C"], [D, "D"]].forEach(([p, n]) => g.point(p, n));
    },
    metrics(s) { return [["원주각 비", `${fmt(s.a1 / 2)} : ${fmt(s.a2 / 2)}`], ["호의 길이 비", `${fmt(s.a1)} : ${fmt(s.a2)} = ${frac(s.a1 / s.a2)}`, "key"]]; },
  },
  {
    id: "m3-concyclic", grade: 3, unit: 6, lesson: "6.4", title: "네 점이 한 원 위에 있을 조건", type: "조작", time: "10분",
    tags: ["원주각의 역", "공원점", "판정"], color: UC[6], links: ["g3-inscribed-angle", "g3-cyclic-quad"],
    desc: "선분 AB와 같은 쪽에 있는 두 점 C, D를 움직여 ∠ACB = ∠ADB일 때 네 점이 한 원 위에 있음을 확인합니다.",
    obs: ["∠ACB = ∠ADB이면 A, B, C, D는 한 원 위에 있습니다.", "D가 원 안에 있으면 ∠ADB가 더 크고, 밖에 있으면 더 작습니다.", "사각형에서 대각의 합이 180°일 때도 한 원 위에 있습니다."],
    q: "야구장에서 같은 시야각으로 골대를 볼 수 있는 자리들은 어떤 곡선 위에 있을까요?",
    formula: "∠ACB = ∠ADB ⇒ A, B, C, D는 한 원 위",
    en: { title: "When Four Points Lie on a Circle", desc: "Equal angles subtending AB mean the four points are concyclic." },
    view: V, points: { C: [-1.5, 3.2], D: [2.4, 2.4] },
    draw(s, g) {
      g.grid({ labels: false, axes: false });
      const A = [-4, -1.5], B = [4, -1.5], C = s.C, D = s.D;
      const d = 2 * (A[0] * (B[1] - C[1]) + B[0] * (C[1] - A[1]) + C[0] * (A[1] - B[1]));
      const O = [((A[0] ** 2 + A[1] ** 2) * (B[1] - C[1]) + (B[0] ** 2 + B[1] ** 2) * (C[1] - A[1]) + (C[0] ** 2 + C[1] ** 2) * (A[1] - B[1])) / d, ((A[0] ** 2 + A[1] ** 2) * (C[0] - B[0]) + (B[0] ** 2 + B[1] ** 2) * (A[0] - C[0]) + (C[0] ** 2 + C[1] ** 2) * (B[0] - A[0])) / d];
      g.circle(O, dist(O, A), { color: "muted", w: 1.6, dash: "5 5" });
      g.seg(A, B, { color: "ink", w: 2.6 });
      g.seg(A, C, { color: "a", w: 2 }).seg(B, C, { color: "a", w: 2 }).seg(A, D, { color: "b", w: 2 }).seg(B, D, { color: "b", w: 2 });
      g.arc(C, A, B, { r: 24, color: "a", ccw: false, label: `${fmt(ang(C, A, B), 1)}°` }).arc(D, A, B, { r: 24, color: "b", ccw: false, label: `${fmt(ang(D, A, B), 1)}°` });
      g.point(A, "A", { dy: 20 }).point(B, "B", { dy: 20 }).point(C, "C", { color: "a" }).point(D, "D", { color: "b" });
      g.handle(C, "C").handle(D, "D", { color: "b" });
    },
    constrain(s, k, p) { return [clamp(p[0], -6.5, 6.5), clamp(p[1], -1, 4.8)]; },
    metrics(s) { const A = [-4, -1.5], B = [4, -1.5], a = ang(s.C, A, B), b = ang(s.D, A, B); return [["∠ACB", `${fmt(a, 1)}°`], ["∠ADB", `${fmt(b, 1)}°`], ["판정", Math.abs(a - b) < 0.6 ? "네 점이 한 원 위에 있음" : b > a ? "D가 원의 안쪽" : "D가 원의 바깥쪽", "key"]]; },
  },
  {
    id: "m3-correlation", grade: 3, unit: 7, lesson: "7.3", title: "상관관계의 강약 — 점들이 모이는 정도", type: "데이터", time: "8분",
    tags: ["산점도", "양·음의 상관", "강약"], color: UC[8], links: ["g3-scatter"],
    desc: "상관의 세기를 조절하며 산점도의 점들이 한 직선 둘레에 얼마나 모이는지 보고 양·음의 상관관계와 강약을 판단합니다.",
    obs: ["점들이 오른쪽 위로 향하면 양의 상관관계, 오른쪽 아래로 향하면 음의 상관관계입니다.", "직선 둘레에 가까이 모일수록 상관관계가 강합니다.", "상관관계가 있다고 해서 원인과 결과의 관계인 것은 아닙니다."],
    q: "아이스크림 판매량과 물놀이 사고 수의 양의 상관관계를 어떻게 해석해야 할까요?",
    formula: "양의 상관 · 음의 상관 · 상관관계 없음 (강함 ↔ 약함)",
    en: { title: "Strength of Correlation", desc: "Adjust the strength and watch scatter points gather around a line." },
    view: { x: [-5.5, 5.5], y: [-4.2, 4.2] },
    params: [{ key: "r", label: "상관의 세기", min: -1, max: 1, step: 0.05, value: 0.7 }],
    anim: { key: "r", min: -1, max: 1, speed: 0.35, label: "세기 바꾸기" },
    pts(s) { const r = s.r; return NOISE.map(([a, b]) => [a * 1.5, (r * a + Math.sqrt(Math.max(0, 1 - r * r)) * b) * 1.4]); },
    draw(s, g) {
      g.grid({ labels: false, xName: "변량 x", yName: "변량 y" });
      this.pts(s).forEach((p) => g.circle(p, 0.12, { color: "d", fill: "d", fo: 0.7, w: 1 }));
      if (Math.abs(s.r) > 0.1) g.line([0, 0], [1.5, s.r * 1.4], { color: "b", w: 1.6, dash: "6 5" });
    },
    metrics(s) { const a = Math.abs(s.r), kind = a < 0.15 ? "상관관계가 거의 없음" : `${s.r > 0 ? "양" : "음"}의 상관관계 (${a > 0.75 ? "강함" : a > 0.4 ? "보통" : "약함"})`; return [["판단", kind, "key"]]; },
  },
];
