import {enhancedBody} from './elementary-visuals.js';
// Shared mathematical models for the elementary exploration catalogue.
const colors=['#087f71','#d37b35','#7954b9'];
const ink='#203a59',grid='#bacbd7';
const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=x=>Number.isFinite(x)?String(Number(x.toFixed(5))):'정의되지 않음';
const gcd=(a,b)=>{a=Math.abs(a);b=Math.abs(b);while(b){[a,b]=[b,a%b];}return a;};
const fraction=(n,d)=>{if(!d)return '정의되지 않음';if(d<0){n=-n;d=-d;}const g=gcd(n,d)||1;return d/g===1?fmt(n/g):`${fmt(n/g)}/${fmt(d/g)}`;};
const txt=(x,y,t,size=24,color=ink,anchor='middle')=>`<text x="${x}" y="${y}" font-size="${size}" fill="${color}" text-anchor="${anchor}">${esc(t)}</text>`;
const rect=(x,y,w,h,fill='white',stroke=grid)=>`<rect x="${x}" y="${y}" width="${Math.max(0,w)}" height="${Math.max(0,h)}" fill="${fill}" stroke="${stroke}" stroke-width="2" rx="3"/>`;
const line=(x,y,u,v,color=ink,width=2,dash='')=>`<line x1="${x}" y1="${y}" x2="${u}" y2="${v}" stroke="${color}" stroke-width="${width}" stroke-dasharray="${dash}"/>`;
const dot=(x,y,r=9,color=colors[0])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${color}"/>`;
const poly=(pts,fill=colors[0],stroke=ink)=>`<polygon points="${pts.map(p=>p.join(',')).join(' ')}" fill="${fill}" stroke="${stroke}" stroke-width="2"/>`;
const textLines=(text,len=42)=>{const out=[''];for(const word of text.split(' ')){if((out.at(-1)+' '+word).length>len)out.push(word);else out[out.length-1]+=(out.at(-1)?' ':'')+word;}return out;};
export function extraClean(l,p={}){p=p&&typeof p==='object'?p:{};const s={};for(const c of l.controls){const n=Number.isFinite(p[c.key])?p[c.key]:c.value;s[c.key]=Number(Math.min(c.max,Math.max(c.min,c.min+Math.round((n-c.min)/c.step)*c.step)).toFixed(8));}if(l.mode==='ordinal')s.b=Math.min(s.b,s.a);if(l.mode==='ten')s.a=Math.min(s.a,s.b);return s;}
export function extraMeasure(l,raw={}){
 const s=extraClean(l,raw),a=s.a??0,b=s.b??1,c=s.c??1,d=s.d??1,m=l.mode;let value=0,formula='',detail='',data={};
 if(l.kind==='number'){
  if(m==='count'){value=a;formula=`${fmt(a)}개`;detail=`${b}개씩 가득 찬 줄 ${Math.floor(a/b)}개와 남은 ${a%b}개`;}
  if(m==='ten'){value=b-a;formula=`${fmt(a)} + ${fmt(value)} = ${fmt(b)}`;detail='전체를 두 부분으로 나눕니다';}
  if(m==='ordinal'){value=b;formula=`왼쪽에서 ${b}번째`;detail=`오른쪽에서 ${a-b+1}번째`;}
  if(m==='odd_even'){value=a%2;formula=`${a}은 ${a%2?'홀수':'짝수'}`;detail=`두 개씩 ${Math.floor(a/2)}쌍과 남은 ${a%2}개`;}
  if(m==='add'){value=a+b;formula=`${fmt(a)} + ${fmt(b)} = ${fmt(value)}`;detail='두 부분을 합한 전체';}
  if(m==='sub'){value=a-b;formula=`${fmt(a)} − ${fmt(b)} = ${fmt(value)}`;detail='처음 양에서 덜어 낸 양을 뺍니다';}
  if(m==='mul'){value=a*b;formula=`${fmt(a)} × ${fmt(b)} = ${fmt(value)}`;detail='같은 크기의 묶음';}
  if(m==='div'){value=b?a/b:0;data.quotient=Math.floor(value);data.remainder=a%b;formula=Number.isInteger(a)&&Number.isInteger(b)?`${a} ÷ ${b} = ${data.quotient}  나머지 ${data.remainder}`:`${fmt(a)} ÷ ${fmt(b)} = ${fmt(value)}`;detail=Number.isInteger(a)&&Number.isInteger(b)?`${b} × ${data.quotient} + ${data.remainder} = ${a}`:'몫을 곱하면 원래 수가 됩니다';}
  if(m==='compare'){value=a-b;formula=`${fmt(a)} ${a===b?'=':a>b?'>':'<'} ${fmt(b)}`;detail=`두 수의 차이 ${fmt(Math.abs(value))}`;}
  if(m==='place'){value=(l.modelUnit??l.unit)==='thousands'?1000*a+100*b+c:100*a+10*b+c;formula=(l.modelUnit??l.unit)==='thousands'?`${a} × 1000 + ${b} × 100 + ${c} = ${value}`:`${a} × 100 + ${b} × 10 + ${c} = ${value}`;detail='각 자리의 값으로 수를 만듭니다';}
  if(m==='round'){value=Math.round(a/b)*b;formula=`${fmt(a)} → ${fmt(value)}`;detail=`${fmt(b)}의 자리까지 반올림`;data.low=Math.floor(a/b)*b;data.high=data.low+b;}
  if(m==='multiple'){value=a*b;formula=`${a} × ${b} = ${value}`;detail=`${a}의 ${b}번째 양의 배수`;}
  if(m==='gcd'||m==='lcm'){const g=gcd(a,b);value=m==='gcd'?g:(g?a*b/g:0);formula=`${a}과 ${b}의 ${m==='gcd'?'최대공약수':'최소공배수'} ${value}`;detail=m==='gcd'?'공통으로 나누어떨어지는 가장 큰 수':'공통인 양의 배수 중 가장 작은 수';data.left=Array.from({length:a},(_,i)=>i+1).filter(x=>a%x===0);data.right=Array.from({length:b},(_,i)=>i+1).filter(x=>b%x===0);}
  if(m==='equation'){value=b-a;formula=`${fmt(a)} + □ = ${fmt(b)}`;detail=`□ = ${fmt(value)}`;}
 }
 if(l.kind==='fraction'){
  const x=a/b,y=c/d;value=x;data={x,y};
  if(m==='show'||m==='mixed'){formula=`${a}/${b} = ${fraction(a,b)}`;detail=m==='mixed'?`자연수 부분 ${Math.floor(x)}와 남은 ${a%b}/${b}`:`1을 ${b}등분한 조각 ${a}개`;}
  if(m==='compare'){value=x-y;formula=`${a}/${b} ${Math.abs(x-y)<1e-9?'=':x>y?'>':'<'} ${c}/${d}`;detail='두 전체의 크기를 같게 두고 비교합니다';}
  if(m==='add'||m==='sub'){const sign=m==='add'?1:-1,n=a*d+sign*c*b;value=n/(b*d);formula=`${a}/${b} ${sign===1?'+':'−'} ${c}/${d} = ${fraction(n,b*d)}`;detail=`같은 분모 ${b*d/gcd(b,d)}로 나타내어 계산합니다`;}
  if(m==='mul'){value=x*y;formula=`${a}/${b} × ${c}/${d} = ${fraction(a*c,b*d)}`;detail='첫째 분수의 둘째 분수만큼을 찾습니다';}
  if(m==='div'){value=x/y;formula=`${a}/${b} ÷ ${c}/${d} = ${fraction(a*d,b*c)}`;detail='첫째 양 안에 둘째 양이 몇 번 들어가는지 잽니다';}
  if(m==='equivalent'){value=x;if(s.d!==undefined){formula=`${a}/${b} ${Math.abs(x-y)<1e-9?'=':'≠'} ${c}/${d}`;detail='같은 크기의 전체에서 색칠한 길이가 같은지 봅니다';}else{formula=`${a}/${b} = ${a*c}/${b*c}`;detail=`분자와 분모에 같은 수 ${c}를 곱합니다`;data.y=x;}}
 }
 if(l.kind==='geometry'){
  if(m==='rectangle'){value=a*b;formula=l.focus==='properties'||l.year<=4?`가로 ${a}  세로 ${b}`:`${a} × ${b} = ${fmt(value)} cm²`;detail=a===b?'네 변이 같고 네 각이 직각인 정사각형':'마주 보는 변이 같고 네 각이 직각인 직사각형';}
  if(m==='triangle'){value=a*b/2;formula=l.focus==='properties'||l.year<=4?`밑변 ${a}  높이 ${b}`:`${a} × ${b} ÷ 2 = ${fmt(value)} cm²`;detail='높이는 밑변에 수직으로 잰 거리입니다';}
  if(m==='parallelogram'){value=a*b;formula=`${a} × ${b} = ${fmt(value)} cm²`;detail='밑변과 높이가 같으면 넓이가 같습니다';}
  if(m==='trapezoid'){value=(a+c)*b/2;formula=`(${a} + ${c}) × ${b} ÷ 2 = ${fmt(value)} cm²`;detail='평행한 두 변의 합에 높이를 곱한 값의 절반';}
  if(m==='rhombus'){value=a*b/2;formula=`${a} × ${b} ÷ 2 = ${fmt(value)} cm²`;detail='두 대각선의 곱의 절반입니다';}
  if(m==='polygon'||m==='shapes'){value=a;formula=`변 ${a}개  꼭짓점 ${a}개`;detail='변의 길이가 같고 각의 크기도 같은 정다각형';}
  if(m==='angle'){value=a;formula=`${a}°`;detail=a===0?'벌어지지 않은 각':a<90?'예각':a===90?'직각':a<180?'둔각':a===180?'평각':a<360?'180°보다 큰 각':'한 바퀴';}
  if(m==='symmetry'){value=Math.abs(c===1?b:a)*2;formula=`${c===1?'가로':'세로'} 대칭축을 기준으로 뒤집기`;detail='대응하는 점은 대칭축에서 같은 거리입니다';}
  if(m==='translate'){value=Math.hypot(a,b);formula=`가로 ${a}칸  세로 ${b}칸 이동`;detail='방향과 길이를 같게 옮기면 모양과 크기가 유지됩니다';}
  if(m==='rotate'){value=a;formula=`중심 주위로 ${a}° 돌리기`;detail='중심에서 각 꼭짓점까지의 거리는 같습니다';}
 }
 if(l.kind==='measure'){
  if(m==='length'){const big=(l.modelUnit??l.unit)==='m-cm'?100:10;value=big*a+b;formula=(l.modelUnit??l.unit)==='m-cm'?`${a} m ${b} cm = ${value} cm`:`${a} cm ${b} mm = ${value} mm`;detail=(l.modelUnit??l.unit)==='m-cm'?'1 m = 100 cm':'1 cm = 10 mm';}
  if(m==='mass'||m==='capacity'){value=1000*a+b;formula=m==='mass'?`${a} kg ${b} g = ${value} g`:`${a} L ${b} mL = ${value} mL`;detail=m==='mass'?'1 kg = 1000 g':'1 L = 1000 mL';}
  if(m==='time'){value=60*a+b+(s.c??0);formula=`${a}시간 ${b}분${s.c?` + ${c}분`:''} = ${value}분`;if((l.modelUnit??l.unit)==='elapsed-clock'){formula=`${a}시 ${b}분에서 ${s.c??0}분 뒤`;detail=`${value>=1440?'다음 날 ':''}${Math.floor(value/60)%24}시 ${value%60}분`;}else detail=`${Math.floor(value/60)}시간 ${value%60}분`;}
  if(m==='clock'){value=(a%12)*60+b;formula=`${a}시 ${b}분`;detail='긴바늘은 분을 나타내고 짧은바늘은 시를 나타냅니다';}
  if(m==='compare'){value=a-b;formula=`${a} ${a===b?'=':a>b?'>':'<'} ${b}`;detail=`길이의 차이 ${Math.abs(value)}`;}
  if(m==='perimeter'){value=2*(a+b);formula=`(${a} + ${b}) × 2 = ${value} cm`;detail='네 변의 길이를 모두 더합니다';}
 }
 if(l.kind==='chart'){
  const total=a+b+c,vs=[a,b,c];data={values:vs,total,mean:total/3};value=m==='average'?total/3:m==='probability'?(total?a/total:0):total;
  formula=m==='average'?`(${a} + ${b} + ${c}) ÷ 3 ${Number.isInteger(value)?'=':'≈'} ${fmt(value)}`:m==='probability'?`첫째 색의 가능성 ${total?fraction(a,total):'전체가 0이라 정할 수 없음'}`:`전체 ${fmt(total)}`;
  detail=m==='pie'?'전체를 100%로 보아 각 부분의 비율을 비교합니다':m==='line'?'순서에 따른 값의 변화를 선으로 잇습니다':m==='probability'?'각 물건이 뽑힐 가능성이 같다고 가정합니다':`가장 큰 값과 가장 작은 값의 차이 ${Math.max(...vs)-Math.min(...vs)}`;
 }
 if(l.kind==='sequence'){
  const length=Math.min(12,Math.max(1,c));data.values=Array.from({length},(_,i)=>m==='mul'?a*b**i:m==='table'?((l.modelUnit??l.unit)==='start-groups'?a*(b+i):(l.modelUnit??l.unit)==='offset-step'?a+b*(i+1):a*(i+1)+b):a+b*i);value=data.values.at(-1);
  formula=m==='pattern'?`한 묶음 ${a}개를 ${b}번 반복`:m==='mul'?`처음 ${a}에서 ${b}배씩`:m==='table'?((l.modelUnit??l.unit)==='start-groups'?`${a}개씩 ${b}묶음부터`:(l.modelUnit??l.unit)==='offset-step'?`입력 × ${b} + ${a}`:`입력 × ${a} + ${b}`):`처음 ${a}에서 ${b}씩 ${b<0?'작아지기':'커지기'}`;
  detail=m==='pattern'?'묶음이 끝나면 첫 모양부터 다시 시작합니다':'이웃한 값 사이의 규칙을 찾아보세요';
 }
 if(l.kind==='ratio'){
  if(m==='percent'){value=a*b/100;formula=`${a}의 ${b}% = ${fmt(value)}`;detail='전체를 100으로 볼 때의 부분';}
  else if(m==='scale'){const factor=s.c??b;value=a*factor;formula=`그림의 ${a} cm × ${factor} = 실제 ${fmt(value)} cm`;detail='같은 비율로 길이를 확대하거나 축소합니다';}
  else{value=s.c===undefined?a/b:a*c;formula=s.c===undefined?`${a} : ${b}  비율 ${fraction(a,b)}`:`${a} : ${b} = ${fmt(a*c)} : ${fmt(b*c)}`;detail=m==='proportion'?'대응하는 두 수에 같은 수를 곱합니다':'비의 두 항을 같은 비율로 바꿉니다';}
 }
 if(l.kind==='solid'){
  value=m==='surface'?2*(a*b+b*c+c*a):m==='cylinder'?Math.PI*a*a*b:m==='cone'?Math.PI*a*a*b/3:m==='sphere'?4*Math.PI*a**3/3:a*b*c;
  formula=m==='surface'?`2 × (${a}×${b} + ${b}×${c} + ${c}×${a}) = ${fmt(value)} cm²`:['cylinder','cone','sphere'].includes(m)?`반지름 ${a}${m==='sphere'?'':`  높이 ${b}`}`:`${a} × ${b} × ${c} = ${fmt(value)} cm³`;
  detail=m==='surface'?'마주 보는 면의 넓이가 같아 세 쌍을 더합니다':['cylinder','cone','sphere'].includes(m)?'입체의 모양과 구성 요소를 살펴봅니다':`한 층 ${a*b}개를 ${c}층 쌓은 부피`;
 }
 if(l.kind==='circle'){
  const pi=(s.b??314)/100;data.pi=pi;value=m==='area'?pi*a*a:m==='diameter'?2*a:2*pi*a;
  formula=m==='area'?`${pi} × ${a} × ${a} = ${fmt(value)} cm²`:m==='diameter'?`2 × ${a} = ${fmt(value)} cm`:`2 × ${pi} × ${a} = ${fmt(value)} cm`;
  detail=m==='diameter'?'지름은 반지름의 2배입니다':`원주율을 ${pi}로 정한 근삿값입니다`;
 }

 if(l.kind==='decimal'){
  const scale=1000,ai=Math.round(a*scale),bi=Math.round(b*scale),x=ai/scale,y=bi/scale;
  if(m==='show'){value=x;formula=`${fmt(x)} = ${fraction(ai,scale)}`;detail='전체 1을 같은 크기로 나눈 부분입니다';}
  if(m==='compare'){value=x-y;formula=`${fmt(x)} ${ai===bi?'=':ai>bi?'>':'<'} ${fmt(y)}`;detail='같은 자리끼리 비교합니다';}
  if(m==='place'){value=a/10+b/100+c/1000;formula=`0.${a}${b}${c} = ${a}/10 + ${b}/100 + ${c}/1000`;detail='바로 오른쪽 자리의 단위는 왼쪽의 10분의 1입니다';}
  if(m==='add'||m==='sub'){value=(ai+(m==='add'?bi:-bi))/scale;formula=`${fmt(x)} ${m==='add'?'+':'−'} ${fmt(y)} = ${fmt(value)}`;detail='같은 자리값끼리 더하거나 뺍니다';}
  if(m==='mul'){value=ai*bi/(scale*scale);formula=`${fmt(x)} × ${fmt(y)} = ${fmt(value)}`;detail='가로와 세로의 곱을 직사각형의 넓이로 봅니다';}
  if(m==='div'){value=ai/bi;const exact=fraction(ai,bi),approx=Math.abs(value-Number(fmt(value)))>1e-10;formula=`${fmt(x)} ÷ ${fmt(y)} ${approx?'≈':'='} ${fmt(value)}`;detail=`같은 비율로 1000배 하면 ${ai} ÷ ${bi}입니다${approx?'  정확한 몫 '+exact:''}`;}
  if(m==='round'){value=Math.round((ai+1e-8)/bi)*bi/scale;formula=`${fmt(x)} → ${fmt(value)}`;detail=`${fmt(b)}의 자리까지 반올림합니다`;data.low=Math.floor(ai/bi)*bi/scale;data.high=data.low+b;}
 }
 if(l.kind==='money'){
  if(m==='compose'){value=500*a+100*b+50*c+10*(s.d??0);formula=`500 × ${a} + 100 × ${b} + 50 × ${c} + 10 × ${s.d??0} = ${value}원`;detail='동전의 액면과 개수를 함께 봅니다';}
  else{value=b-a;formula=`${b}원 − ${a}원 = ${value}원`;detail='낸 돈에서 물건값을 빼면 거스름돈입니다';}
 }
 if(l.kind==='number'&&m==='range'){
  const unit=(l.modelUnit??l.unit),lo=Math.min(b,c),hi=Math.max(b,c);value=unit==='at-least'?a>=b:unit==='at-most'?a<=b:unit==='more-than'?a>b:unit==='less-than'?a<b:a>=lo&&a<=hi;
  const rule=unit==='at-least'?`${b} 이상`:unit==='at-most'?`${b} 이하`:unit==='more-than'?`${b} 초과`:unit==='less-than'?`${b} 미만`:`${lo} 이상 ${hi} 이하`;
  formula=`${a}은 ${rule}에 ${value?'포함':'포함되지 않음'}`;detail=['at-least','at-most','between'].includes(unit)?'경계값도 범위에 들어갑니다':'경계값은 범위에 들어가지 않습니다';data.lo=lo;data.hi=hi;
 }
 if(l.kind==='ratio'&&m==='sharing'){
  value=a*b/(b+c);data.second=a*c/(b+c);data.firstExact=fraction(a*b,b+c);data.secondExact=fraction(a*c,b+c);formula=`${a}을 ${b} : ${c}로 → ${data.firstExact}와 ${data.secondExact}`;detail=`전체를 ${b+c}묶음으로 나누어 ${b}묶음과 ${c}묶음을 가져갑니다`;
 }
 if(l.kind==='geometry'&&['parallel','perpendicular','angle-sum','segment','ray','line'].includes(m)){
  if(m==='parallel'){value=b;formula=`기울기 ${a}°  두 직선 사이 거리 ${b}`;detail='두 직선은 나란하고 수직으로 잰 거리가 일정합니다';}
  if(m==='perpendicular'){value=90;formula='만나는 각은 언제나 90°';detail=`전체를 ${a}° 돌려도 두 직선은 수직입니다`;}
  if(m==='angle-sum'){value=a+b;formula=`${a}° + ${b}° = ${value}°`;detail=`평각 180°까지 남은 각은 ${180-value}°입니다`;}
  if(['segment','ray','line'].includes(m)){value=a;formula=m==='segment'?`두 끝점 사이의 선분 길이 ${a}`:m==='ray'?'한 끝점에서 한쪽으로 계속 이어지는 반직선':'양쪽으로 끝없이 이어지는 직선';detail=`표시한 두 기준점 사이 거리 ${a}  전체 길이와 구별하세요`;}
 }
 if(l.kind==='solid'&&l.focus==='properties'){formula=`가로 ${a}  세로 ${b}  높이 ${c}`;detail=a===b&&b===c?'세 방향의 길이가 같은 정육면체입니다':'세 방향의 길이를 같게 하면 정육면체가 됩니다';}if(l.kind==='solid'&&l.focus==='count'){formula=`${a} × ${b} × ${c} = ${a*b*c}개`;detail=`한 층 ${a*b}개를 ${c}층 쌓습니다`;}
 return {value,formula,detail,...data};
}
const bars=(values,labels=values.map(fmt),max=Math.max(1,...values.map(Math.abs)))=>values.map((v,i)=>{const y=165+i*105;return txt(65,y-14,labels[i],22,colors[i%3],'start')+rect(65,y,500,40,'#edf2ef')+rect(65,y,Math.abs(v)/max*500,40,colors[i%3])+txt(615,y+29,fmt(v),25,ink,'start');}).join('');
function axis(points){const min=Math.min(0,...points),max=Math.max(1,...points),span=max-min||1,X=n=>70+(n-min)/span*660;let o=line(70,345,730,345);const integer=points.every(Number.isInteger),step=integer?Math.max(1,Math.ceil(span/10)):span/10;for(let n=min;n<=max+1e-8;n+=step)o+=line(X(n),338,X(n),355)+txt(X(n),385,fmt(n),17);points.forEach((n,i)=>{o+=dot(X(n),345-i*55,10,colors[i%3])+line(X(n),345-i*55,X(n),345,colors[i%3],2,'4 4')+txt(X(n),325-i*55,fmt(n),24,colors[i%3]);});return o;}

function strip(n,d,y,color,max=1){const val=n/d;let o=rect(65,y,670,60);const width=670/max;for(let i=1;i<Math.min(100,Math.ceil(max*d));i++)o+=line(65+i*width/d,y,65+i*width/d,y+60,grid,1);o+=rect(65,y,Math.max(0,val)*width,60,color)+'<g opacity=".4">';for(let i=1;i<Math.min(100,Math.ceil(val*d));i++)o+=line(65+i*width/d,y,65+i*width/d,y+60,'white',1);o+='</g>';for(let i=0;i<=Math.floor(max);i++)o+=line(65+i*width,y-6,65+i*width,y+66,ink,2);return o;}
export function extraScene(l,raw={}){
 const s=extraClean(l,raw),r=extraMeasure(l,s),a=s.a??0,b=s.b??1,c=s.c??1,d=s.d??1,m=l.mode;let o='';
 if(l.kind==='number'){
  if(['count','ten','ordinal','odd_even'].includes(m)){
   const n=m==='ten'?b:a,cols=m==='odd_even'?2:m==='count'?Math.max(1,Math.min(10,b)):Math.min(10,Math.max(1,n)),rows=Math.ceil(n/cols),cell=Math.min(54,260/Math.max(1,rows)),x=(800-cols*cell)/2;
   for(let i=0;i<Math.min(100,n);i++){const xx=x+(i%cols+.5)*cell,yy=155+Math.floor(i/cols)*cell;const col=m==='ten'&&i>=a?colors[1]:m==='ordinal'&&i===b-1?colors[1]:colors[0];o+=dot(xx,yy,cell*.3,col);if(m==='ordinal')o+=txt(xx,yy+cell*.72,i+1,16);}
  }else if(m==='compare'&&l.year<=2&&Math.max(a,b)<=30){
   for(let row=0;row<2;row++){const n=row?b:a;for(let j=0;j<n;j++){const cell=Math.min(24,650/Math.max(1,a,b));o+=dot(75+j*cell,210+row*105,cell*.35,colors[row]);if(!row&&j<Math.min(a,b))o+=line(75+j*cell,225,75+j*cell,300,grid,1,'4 4');}}o+=txt(400,420,`짝을 짓고 남는 수 ${Math.abs(a-b)}`,26);
  }else if(m==='place'){
   let vs=[a,b,c],labs=(l.modelUnit??l.unit)==='thousands'?['천의 묶음','백의 묶음','남은 수']:['백의 묶음','십의 묶음','낱개'];if(l.year===1&&a===0){vs=vs.slice(1);labs=labs.slice(1);}for(let i=0;i<vs.length;i++){const x=65+i*670/vs.length;o+=rect(x,160,650/vs.length,220,'#eff6f3')+txt(x+325/vs.length,210,labs[i],23)+txt(x+325/vs.length,300,vs[i],52,colors[i]);}
  }else if(m==='gcd'){
   [r.left,r.right].forEach((vs,i)=>{o+=txt(70,160+i*135,`${i?b:a}의 약수`,22,ink,'start');vs.forEach((v,j)=>o+=rect(60+j*660/vs.length,178+i*135,Math.min(55,640/vs.length),48,(i?r.left:r.right).includes(v)?'#bde5d9':'white')+txt(60+(j+.4)*660/vs.length,211+i*135,v,20));});
  }else if(m==='lcm'){o+=bars([a,b,r.value],[`${a}의 한 묶음`,`${b}의 한 묶음`,'최소공배수']);}
  else if(m==='round'){o+=axis([r.low,a,r.high])+txt(400,420,`가운데 수 ${fmt((r.low+r.high)/2)}`,24);}
  else if(m==='mul'||m==='multiple'){
   if(Number.isInteger(a)&&Number.isInteger(b)&&a<=30&&b<=20){const cell=Math.min(38,660/Math.max(1,a),250/Math.max(1,b)),x=(800-a*cell)/2;for(let j=0;j<b;j++)for(let i=0;i<a;i++)o+=rect(x+i*cell,155+j*cell,cell,cell,colors[j%2]);o+=txt(400,440,`한 줄 ${a}개 × ${b}줄`,24);}
   else o+=bars([a,b,r.value],['첫째 수','둘째 수','곱']);
  }else if(m==='div'){
   const grouped=/묶음.*개수|한 묶음|한 번에/.test(l.controls.find(x=>x.key==='b')?.label||'');const q=r.quotient,rem=r.remainder,groups=grouped?q:b,each=grouped?b:q;const count=Math.max(0,Math.min(12,groups));for(let i=0;i<count;i++)o+=rect(65+i*670/count,180,650/count,170,'#e1f0eb')+txt(65+(i+.48)*670/count,267,fmt(each),Math.min(30,500/count));o+=txt(400,402,`${fmt(groups)}묶음에 ${fmt(each)}개씩  남은 수 ${fmt(rem)}${groups>12?'  일부 묶음만 표시':''}`,24);
  }else if(m==='add'||m==='ten'||m==='equation'){
   const first=a,second=m==='equation'?b-a:b,total=first+second,scale=660/Math.max(1,total);o+=rect(70,200,Math.max(0,first)*scale,90,colors[0])+rect(70+Math.max(0,first)*scale,200,Math.max(0,second)*scale,90,colors[1])+txt(400,350,`${fmt(first)}와 ${fmt(second)}를 합친 전체 ${fmt(total)}`,25);}
  else if(m!=='range')o+=axis([a,b,...(m==='sub'?[r.value]:[])]);
 }
 if(l.kind==='fraction'){
  const max=Math.max(1,Math.ceil(r.x),Math.ceil(r.y),m==='add'?Math.ceil(r.x+r.y):1);
  o+=txt(70,146,`${a}/${b}`,23,colors[0],'start')+strip(a,b,162,colors[0],max);
  if(m==='equivalent')o+=txt(70,270,s.d!==undefined?`${c}/${d}`:`${a*c}/${b*c}`,23,colors[1],'start')+strip(s.d!==undefined?c:a*c,s.d!==undefined?d:b*c,286,colors[1],max);
  else if(!['show','mixed'].includes(m))o+=txt(70,270,`${c}/${d}`,23,colors[1],'start')+strip(c,d,286,colors[1],max);
  else o+=txt(400,320,`전체 1의 크기는 굵은 눈금 사이`,24)+txt(400,375,`색칠한 양 ${fraction(a,b)}`,32,colors[0]);
  if(['add','sub','mul','div'].includes(m))o+=txt(400,414,`결과 ${fmt(r.value)}`,30,colors[2]);
 }
 if(l.kind==='geometry'||l.kind==='measure'&&m==='perimeter'){
  if(['rectangle','triangle','parallelogram','trapezoid','rhombus','perimeter'].includes(m)){
   const w=a,h=b,top=m==='trapezoid'?c:w,skew=m==='parallelogram'?(s.c??2):0,k=Math.min(48,540/Math.max(l.controls.find(c=>c.key==='a')?.max??1,m==='trapezoid'?(l.controls.find(c=>c.key==='c')?.max??1):0,m==='parallelogram'?(l.controls.find(c=>c.key==='a')?.max??1)+(l.controls.find(c=>c.key==='c')?.max??0):0),245/Math.max(l.controls.find(c=>c.key==='b')?.max??1,1)),x=(800-Math.max(w,top)*k)/2,y=155,W=w*k,H=h*k;
   let pts=[[x,y+H],[x+W,y+H],[x+W,y],[x,y]];
   if(m==='triangle')pts=[[x,y+H],[x+W,y+H],[x+W/2,y]];
   if(m==='parallelogram')pts=[[x,y+H],[x+W,y+H],[x+W+skew*k,y],[x+skew*k,y]];
   if(m==='trapezoid')pts=[[x,y+H],[x+W,y+H],[x+(W+top*k)/2,y],[x+(W-top*k)/2,y]];
   if(m==='rhombus')pts=[[400-W/2,y+H/2],[400,y],[400+W/2,y+H/2],[400,y+H]];
   if(m==='triangle'&&l.year>=5)o+=rect(x,y,W,H,'white');o+=poly(pts,'#bde5d9',colors[0]);if(m==='rectangle'&&l.year>=5){for(let gx=1;gx<a;gx++)o+=line(x+gx*k,y,x+gx*k,y+H,grid,1);for(let gy=1;gy<b;gy++)o+=line(x,y+gy*k,x+W,y+gy*k,grid,1);}if(m==='parallelogram')o+=line(x,y,x+skew*k,y,colors[2],2,'4 4');if(m==='rhombus')o+=line(400-W/2,y+H/2,400+W/2,y+H/2,colors[1],2,'5 4')+line(400,y,400,y+H,colors[2],2,'5 4');else o+=line(x,y,x,y+H,colors[2],2,'5 4');o+=txt(400,y+H+35,`${m==='rhombus'?'가로 대각선':'밑변'} ${a}`,23)+txt(x-15,y+H/2,`${b}`,22,colors[2],'end');if(m==='trapezoid')o+=txt(400,y-15,`윗변 ${c}`,22);
  }else if(m==='polygon'||m==='shapes'){
   const n=Math.max(3,Math.round(a)),rot=(s.b??0)*Math.PI/180;const pts=Array.from({length:n},(_,i)=>[400+145*Math.cos(2*Math.PI*i/n-Math.PI/2+rot),285+145*Math.sin(2*Math.PI*i/n-Math.PI/2+rot)]);o+=poly(pts,'#bde5d9');pts.forEach((p,i)=>o+=dot(...p,7,colors[1])+txt(p[0]+(p[0]-400)*.15,p[1]+(p[1]-285)*.15,i+1,19));
  }else if(m==='angle'){
   const t=a*Math.PI/180,cx=380,cy=330;o+=line(cx,cy,cx+230,cy,colors[0],5)+line(cx,cy,cx+230*Math.cos(t),cy-230*Math.sin(t),colors[1],5);if(a>0&&a<360)o+=`<path d="M ${cx+80} ${cy} A 80 80 0 ${a>180?1:0} 0 ${cx+80*Math.cos(t)} ${cy-80*Math.sin(t)}" fill="none" stroke="${colors[2]}" stroke-width="4"/>`;o+=dot(cx,cy,8)+txt(400,160,`${a}°`,42);
  }else if(['symmetry','translate','rotate'].includes(m)){
   
   const base=m==='symmetry'?[[a,b],[a+1,b],[a,b+1]]:[[0,0],[2,0],[1,2]],t=a*Math.PI/180;
   const second=base.map(([x,y])=>m==='symmetry'?(c===1?[x,-y]:[-x,y]):m==='translate'?[x+a,y+b]:[x*Math.cos(t)-y*Math.sin(t),x*Math.sin(t)+y*Math.cos(t)]);
   const scale=Math.min(28,160/Math.max(6,...base.flat().map(Math.abs),...second.flat().map(Math.abs))),pt=([x,y])=>[400+x*scale,288-y*scale];for(let i=-6;i<=6;i++)o+=line(400+i*scale,120,400+i*scale,456,grid,1)+line(232,288+i*scale,568,288+i*scale,grid,1);o+=line(400,115,400,460,ink,2)+line(225,288,575,288,ink,2);o+=poly(base.map(pt),'#a9d6cc',colors[0])+poly(second.map(pt),'#f1c69f',colors[1]);base.forEach((p,i)=>o+=line(...pt(p),...pt(second[i]),colors[2],1,'4 4'));o+=txt(400,485,'초록은 처음 모양  주황은 바뀐 모양',21);
  }
 }
 if(l.kind==='measure'&&m!=='perimeter'){
  if(m==='clock'){
   o+=`<circle cx="400" cy="285" r="150" fill="white" stroke="${ink}" stroke-width="3"/>`;for(let i=1;i<=12;i++){const t=i*Math.PI/6;o+=txt(400+125*Math.sin(t),293-125*Math.cos(t),i,24);}for(const [v,len,col]of[[(a%12+b/60)*30,80,colors[2]],[b*6,115,colors[0]]]){const t=v*Math.PI/180;o+=line(400,285,400+len*Math.sin(t),285-len*Math.cos(t),col,7);}o+=dot(400,285,7);
  }else if(m==='compare')o+=bars([a,b],['첫째 길이','둘째 길이']);
  else if(m==='time')o+=bars([60*a,b,s.c??0],['시간 부분을 분으로','분 부분','더 흐른 분'])+txt(400,450,r.detail,27);
  else{
   const factor=m==='length'?((l.modelUnit??l.unit)==='m-cm'?100:10):1000;const total=factor*a+b,max=Math.max(factor,total),k=660/max;o+=rect(70,215,factor*a*k,85,colors[0])+rect(70+factor*a*k,215,b*k,85,colors[1]);for(let i=0;i<=10;i++)o+=line(70+i*66,315,70+i*66,330)+txt(70+i*66,360,fmt(max*i/10),17);o+=txt(400,160,r.detail,30)+txt(400,420,`초록 ${factor*a} + 주황 ${b}`,24);
  }
 }
 if(l.kind==='chart'){
  const vs=r.values,max=Math.max(1,...vs),total=r.total;
  if(m==='pie'){
   let start=-Math.PI/2;vs.forEach((v,i)=>{const angle=total?v/total*2*Math.PI:0,end=start+angle,cx=300,cy=280,rr=145;if(angle>=2*Math.PI-1e-9)o+=`<circle cx="${cx}" cy="${cy}" r="${rr}" fill="${colors[i]}"/>`;else if(angle>0)o+=`<path d="M ${cx} ${cy} L ${cx+rr*Math.cos(start)} ${cy+rr*Math.sin(start)} A ${rr} ${rr} 0 ${angle>Math.PI?1:0} 1 ${cx+rr*Math.cos(end)} ${cy+rr*Math.sin(end)} Z" fill="${colors[i]}" stroke="white"/>`;o+=txt(555,210+i*70,`${i+1}번째 ${total?fmt(v/total*100):0}%`,25,colors[i]);start=end;});if(!total)o+=txt(300,280,'자료를 넣어 주세요',25);
  }else if(m==='line'){
   const pts=vs.map((v,i)=>[150+i*250,420-v/max*230]);o+=line(100,420,710,420);for(let i=0;i<2;i++)o+=line(...pts[i],...pts[i+1],colors[0],4);pts.forEach((p,i)=>o+=dot(...p,10,colors[i])+txt(p[0],p[1]-20,vs[i],26)+txt(p[0],460,`${i+1}번째`,22));
  }else if(m==='sort'||m==='probability'){
   const rows=vs.map(v=>Math.ceil(v/10)),cell=Math.min(30,80/Math.max(1,...rows));vs.forEach((v,i)=>{o+=txt(70,180+i*95,`${i+1}번째`,22,colors[i],'start');for(let j=0;j<Math.min(100,v);j++)o+=dot(250+j%10*35,160+i*95+Math.floor(j/10)*cell,Math.min(12,cell*.4),colors[i]);o+=txt(725,180+i*95,v,24);});
  }else{
   for(let i=0;i<3;i++)o+=rect(140+i*210,425-vs[i]/max*240,100,vs[i]/max*240,colors[i])+txt(190+i*210,405-vs[i]/max*240,vs[i],25)+txt(190+i*210,462,`${i+1}번째`,22);o+=line(95,425,705,425);if(m==='average')o+=line(95,425-r.mean/max*240,705,425-r.mean/max*240,ink,3,'6 4')+txt(710,415-r.mean/max*240,`평균 ${fmt(r.mean)}`,18,ink,'end');
  }
 }
 if(l.kind==='sequence'){
  if(m==='pattern'){
   const count=a*b,cell=Math.min(50,660/Math.max(1,Math.min(count,12)));for(let i=0;i<count;i++){const x=80+i%12*cell,y=180+Math.floor(i/12)*100,j=i%a;if(j===0)o+=dot(x,y,17,colors[0]);else if(j===1)o+=poly([[x,y-20],[x-20,y+18],[x+20,y+18]],colors[1]);else o+=rect(x-17,y-17,34,34,colors[j%3]);o+=txt(x,y+40,i+1,15);}
  }else{
   r.values.forEach((v,i)=>{const x=65+i%4*180,y=160+Math.floor(i/4)*100;o+=rect(x,y,155,74,'#eff6f3')+txt(x+77,y+46,fmt(v),String(fmt(v)).length>8?16:27);});
  }
 }
 if(l.kind==='ratio'){
  if(m==='percent'){
   const whole=100;for(let i=0;i<whole;i++)o+=rect(80+i%10*27,145+Math.floor(i/10)*27,27,27,i<b?colors[0]:'white');o+=txt(570,225,`${b}%`,48,colors[0])+txt(570,300,`전체 ${a}`,26)+txt(570,370,`부분 ${fmt(r.value)}`,30,colors[1]);
  }else if(m==='scale')o+=bars([a,r.value],['그림의 길이','실제 길이']);
  else if(m!=='sharing'){const max=Math.max(1,a,b,a*c,b*c);o+=bars([a,b],['처음의 첫째 양','처음의 둘째 양'],max)+rect(220,350,a*c/max*510,34,colors[0])+rect(220,397,b*c/max*510,34,colors[1])+txt(70,375,`${c}배 한 첫째`,18,ink,'start')+txt(70,422,`${c}배 한 둘째`,18,ink,'start');}
 }
 if(l.kind==='circle'){
  const rr=Math.min(150,30+a*12);o+=`<circle cx="350" cy="285" r="${rr}" fill="${m==='area'?'#bde5d9':'white'}" stroke="${colors[0]}" stroke-width="4"/>`+dot(350,285,5)+line(m==='diameter'?350-rr:350,285,350+rr,285,colors[1],4)+txt(350,275,`${m==='diameter'?2*a:a} cm`,23,colors[1])+txt(620,275,m==='area'?'넓이':m==='diameter'?'지름':'원주',30);
 }
 if(l.kind==='solid'){
  if(['box','surface','cubes'].includes(m)){
   const scale=Math.min(35,390/Math.max(1,a+b),210/Math.max(1,c)),pt=(x,y,z)=>[400+(x-y)*scale,370+(x+y-(a+b)/2)*scale*.42-z*scale];o+=poly([pt(0,0,c),pt(a,0,c),pt(a,b,c),pt(0,b,c)],'#bde5d9')+poly([pt(a,0,0),pt(a,b,0),pt(a,b,c),pt(a,0,c)],'#81b7bd')+poly([pt(0,b,0),pt(a,b,0),pt(a,b,c),pt(0,b,c)],'#399a89');
   if(m==='cubes'||m==='box'){for(let x=1;x<a;x++)o+=line(...pt(x,b,0),...pt(x,b,c),'white',1)+line(...pt(x,0,c),...pt(x,b,c),'white',1);for(let y=1;y<b;y++)o+=line(...pt(a,y,0),...pt(a,y,c),'white',1)+line(...pt(0,y,c),...pt(a,y,c),'white',1);for(let z=1;z<c;z++)o+=line(...pt(0,b,z),...pt(a,b,z),'white',1)+line(...pt(a,0,z),...pt(a,b,z),'white',1);}
   o+=txt(400,450,`가로 ${a}  세로 ${b}  높이 ${c}`,25);
  }else{
   const rr=Math.min(130,50+a*8),hh=Math.min(230,80+b*10);if(m==='sphere')o+=`<circle cx="400" cy="290" r="${rr}" fill="#bde5d9" stroke="${ink}"/><ellipse cx="400" cy="290" rx="${rr}" ry="${rr*.3}" fill="none" stroke="${colors[0]}" stroke-dasharray="5 4"/>`;else if(m==='cone')o+=poly([[400,155],[400-rr,155+hh],[400+rr,155+hh]],'#bde5d9');else o+=rect(400-rr,155,rr*2,hh,'#bde5d9')+`<ellipse cx="400" cy="155" rx="${rr}" ry="30" fill="#e3f3ed" stroke="${ink}"/>`;if(m!=='sphere')o+=`<ellipse cx="400" cy="${155+hh}" rx="${rr}" ry="30" fill="#bde5d9" stroke="${ink}"/>`;o+=txt(400,475,`반지름 ${a}${m==='sphere'?'':`  높이 ${b}`}`,25);
  }
 }

 if(l.kind==='decimal'){
  if(m==='show'){
   const units=Math.max(1,Math.ceil(a)),cells=100*units,cols=10*units,k=Math.min(28,650/cols),filled=Math.round(a*100);for(let i=0;i<cells;i++)o+=rect(70+i%cols*k,155+Math.floor(i/cols)*k,k,k,i<filled?colors[0]:'white');o+=txt(400,465,'작은 칸 1개는 0.01  큰 묶음 100칸은 1',23);
  }else if(m==='place'){
   [a,b,c].forEach((n,i)=>{o+=rect(65+i*230,160,210,230,'#eff6f3')+txt(170+i*230,205,['0.1의 자리','0.01의 자리','0.001의 자리'][i],23)+txt(170+i*230,290,n,48,colors[i])+txt(170+i*230,352,`${n} × ${[.1,.01,.001][i]}`,22);});
  }else if(m==='mul'&&b>=10){o+=rect(80,180,270,190,'#eff6f3')+rect(450,180,270,190,'#eff6f3')+txt(215,240,'처음 수',25)+txt(215,310,fmt(a),43,colors[0])+txt(585,240,`${b}배 한 수`,25)+txt(585,310,fmt(r.value),43,colors[1])+txt(400,285,'→',40)+txt(400,430,'숫자는 그대로여도 각 숫자의 자리값이 커집니다',24);
  }else if(m==='mul'){
   const mx=Math.max(1,Math.ceil(a)),my=Math.max(1,Math.ceil(b)),kx=480/mx,ky=260/my,x=140,y=165;for(let i=0;i<=mx*10;i++)o+=line(x+i*kx/10,y,x+i*kx/10,y+260,i%10?grid:ink,i%10?1:2);for(let i=0;i<=my*10;i++)o+=line(x,y+i*ky/10,x+480,y+i*ky/10,i%10?grid:ink,i%10?1:2);o+=`<rect x="${x}" y="${y+260-b*ky}" width="${a*kx}" height="${b*ky}" fill="${colors[0]}" opacity=".45"/>`+txt(x+a*kx/2,460,`가로 ${fmt(a)}`,25)+txt(120,y+260-b*ky/2,fmt(b),23,colors[1],'end')+txt(400,140,'작은 눈금 한 칸은 각 방향에서 0.1',20);
  }else if(m==='div'&&l.controls.find(c=>c.key==='b')?.label==='같게 나눌 수'){for(let i=0;i<b;i++)o+=rect(65+i*670/b,190,650/b,180,'#d8eee5')+txt(65+(i+.48)*670/b,270,fmt(r.value),Math.min(27,230/b));o+=txt(400,430,`${a}을 ${b}개로 똑같이 나눈 한 몫 ${fmt(r.value)}`,25);
  }else if(m==='div'){
   const max=Math.max(a,b,1),k=650/max;o+=rect(75,200,a*k,70,colors[0])+txt(75,180,`나누어지는 양 ${fmt(a)}`,24,ink,'start')+rect(75,325,b*k,55,colors[1])+txt(75,415,`한 묶음의 양 ${fmt(b)}`,24,ink,'start');for(let i=1;i<=Math.min(30,Math.floor(a/b));i++)o+=line(75+i*b*k,190,75+i*b*k,280,'white',3);o+=txt(400,465,`들어가는 묶음 수 ${fmt(r.value)}`,27);
  }else if(m==='round')o+=axis([r.low,a,r.high]);
  else if(m==='compare')o+=bars([a,b],['첫째 소수','둘째 소수']);
  else{const max=Math.max(a,b,r.value,1),k=650/max;o+=bars([a,b],['첫째 소수','둘째 소수'],max)+rect(220,350,Math.max(0,r.value)/max*510,50,colors[2])+txt(70,382,'계산 결과',21,ink,'start')+txt(735,382,fmt(r.value),24,ink,'end');}
 }
 if(l.kind==='money'){
  if(m==='compose'){
   [500,100,50,10].forEach((v,i)=>{const x=135+i*175,n=[a,b,c,s.d??0][i];o+=`<circle cx="${x}" cy="235" r="60" fill="#f4e2b8" stroke="#af8540" stroke-width="3"/>`+txt(x,244,`${v}원`,27)+txt(x,350,`${n}개`,30,colors[i%3])+txt(x,405,`${v*n}원`,24);});
  }else o+=bars([b,a,r.value],['낸 돈','물건값','거스름돈']);
 }
 if(l.kind==='number'&&m==='range'){
  const lower=Math.min(0,a,b,s.c??b),upper=Math.max(a,b,s.c??b)+Math.max(2,Math.ceil(Math.max(a,b,s.c??b)/10)),X=x=>65+(x-lower)/(upper-lower)*670,y=290;const closed=['at-least','at-most','between'].includes((l.modelUnit??l.unit)),right=['at-least','more-than'].includes((l.modelUnit??l.unit));o+=line(65,y,735,y,grid,3);if((l.modelUnit??l.unit)==='between')o+=line(X(r.lo),y,X(r.hi),y,colors[0],9);else o+=line(right?X(b):65,y,right?735:X(b),y,colors[0],9);for(const edge of (l.modelUnit??l.unit)==='between'?[r.lo,r.hi]:[b])o+=`<circle cx="${X(edge)}" cy="${y}" r="9" fill="${closed?colors[0]:'white'}" stroke="${colors[0]}" stroke-width="3"/>`+txt(X(edge),y+40,edge,23);o+=dot(X(a),y-55,10,r.value?colors[0]:colors[1])+line(X(a),y-45,X(a),y-15,colors[2],2,'4 4')+txt(X(a),y-80,a,30)+txt(400,420,closed?'채운 원은 경계를 포함합니다':'빈 원은 경계를 포함하지 않습니다',25);
 }
 if(l.kind==='ratio'&&m==='sharing'){
  const count=b+c,k=650/count;for(let i=0;i<count;i++)o+=rect(75+i*k,215,k,100,i<b?colors[0]:colors[1]);o+=txt(400,170,`전체 ${a}`,30)+txt(230,380,`${b}묶음 = ${r.firstExact}`,25,colors[0])+txt(570,380,`${c}묶음 = ${r.secondExact}`,25,colors[1]);
 }
 if(l.kind==='geometry'&&['parallel','perpendicular'].includes(m)){
  const t=a*Math.PI/180,ux=Math.cos(t),uy=-Math.sin(t),nx=-uy,ny=ux,len=m==='parallel'?190:Math.min(190,70+b*15),gap=b*10;
  if(m==='parallel'){for(const sign of [-1,1])o+=line(400+sign*gap/2*nx-len*ux,290+sign*gap/2*ny-len*uy,400+sign*gap/2*nx+len*ux,290+sign*gap/2*ny+len*uy,sign<0?colors[0]:colors[1],5);o+=line(400-gap/2*nx,290-gap/2*ny,400+gap/2*nx,290+gap/2*ny,colors[2],3,'5 4');}
  else{o+=line(400-len*ux,290-len*uy,400+len*ux,290+len*uy,colors[0],5)+line(400-len*nx,290-len*ny,400+len*nx,290+len*ny,colors[1],5)+poly([[400+20*ux,290+20*uy],[400+20*(ux+nx),290+20*(uy+ny)],[400+20*nx,290+20*ny],[400,290]],'none',colors[2]);}o+=txt(400,465,m==='parallel'?`두 직선 사이의 수직거리 ${b}`:'회전해도 직각 표시가 유지됩니다',25);
 }
 if(l.kind==='geometry'&&m==='angle-sum'){
  const aa=a*Math.PI/180,bb=b*Math.PI/180,cangle=180-a-b,tx=Math.sin(bb)*Math.cos(aa)/Math.sin(aa+bb),ty=Math.sin(bb)*Math.sin(aa)/Math.sin(aa+bb),scale=Math.min(280,220/ty),px=55,py=415,pts=[[px,py],[px+scale,py],[px+tx*scale,py-ty*scale]];
  o+=poly(pts,'#d8eee5')+txt(px-10,py-8,`${a}°`,21,colors[0],'end')+txt(px+scale+10,py-8,`${b}°`,21,colors[1],'start')+txt(px+tx*scale,py-ty*scale-16,`${cangle}°`,24,colors[2])+txt(200,465,'삼각형의 세 각',23);
  const angles=[0,a,a+b,180],cx=610,cy=385,rr=145;for(let i=0;i<3;i++){const start=angles[i]*Math.PI/180,end=angles[i+1]*Math.PI/180,points=[[cx,cy]];for(let k=0;k<=30;k++){const t=start+(end-start)*k/30;points.push([cx+rr*Math.cos(t),cy-rr*Math.sin(t)]);}o+=poly(points,colors[i],'white');const mid=(start+end)/2;o+=txt(cx+rr*.65*Math.cos(mid),cy-rr*.65*Math.sin(mid),`${angles[i+1]-angles[i]}°`,20,'white');}o+=txt(600,465,'나란히 모으면 180°',23);
 }
 if(l.kind==='geometry'&&['segment','ray','line'].includes(m)){
  const angle=b*Math.PI/180,ux=Math.cos(angle),uy=-Math.sin(angle),scale=Math.min(25,180/Math.max(1,a)),cx=370+(s.c??0)*8,cy=290,p=[cx-a*scale/2*ux,cy-a*scale/2*uy],q=[cx+a*scale/2*ux,cy+a*scale/2*uy],start=m==='line'?[cx-175*ux,cy-175*uy]:p,end=m==='segment'?q:[cx+175*ux,cy+175*uy];o+=line(...start,...end,colors[0],4);if(m!=='segment')o+=poly([end,[end[0]-15*ux+7*uy,end[1]-15*uy-7*ux],[end[0]-15*ux-7*uy,end[1]-15*uy+7*ux]],colors[0]);if(m==='line')o+=poly([start,[start[0]+15*ux+7*uy,start[1]+15*uy-7*ux],[start[0]+15*ux-7*uy,start[1]+15*uy+7*ux]],colors[0]);o+=dot(...p,8,colors[1])+dot(...q,8,colors[2])+txt(p[0]-12,p[1]+27,'A',22,colors[1])+txt(q[0]+12,q[1]+27,'B',22,colors[2])+txt(400,465,m==='segment'?'A와 B에서 끝납니다':m==='ray'?'A에서 시작해 B를 지나 계속 이어집니다':'A와 B를 지나 양쪽으로 계속 이어집니다',23);
 }
 const upgraded=enhancedBody(l,s,r);if(upgraded!==null)o=upgraded;
 const title=l.title.split(' — ')[0],titleLines=textLines(title,27),formulaLines=textLines(r.formula,32),note=textLines(r.detail,40),footerHeight=56+formulaLines.length*34+note.length*28,sceneHeight=550+footerHeight;
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 ${sceneHeight}" role="img" aria-label="${esc(l.title)}" font-family="system-ui,sans-serif"><title>${esc(l.title)}</title><desc>${esc(l.q+' '+r.formula+' '+r.detail)}</desc>${rect(0,0,800,sceneHeight,'#fffaf0','#fffaf0')}<g class="em-svg-heading">${rect(18,10,764,100,ink,ink)}${txt(40,36,`초등 ${l.year}학년 / 수학 탐구`,16,'#b8dfd9','start')}${titleLines.map((t,i)=>txt(40,67+i*30,t,25,'white','start')).join('')}</g><g class="em-svg-diagram" transform="translate(0 30)">${o}</g><g class="em-svg-footer">${rect(25,550,750,footerHeight-12,'#edf4ef','#d1e0d8')}${formulaLines.map((t,i)=>txt(400,592+i*34,t,28,ink)).join('')}${note.map((t,i)=>txt(400,610+formulaLines.length*34+i*28,t,21)).join('')}</g></svg>`;
}
export function extraReadings(l,s){const r=extraMeasure(l,s);return [['그림에서 읽기',r.formula],['관찰하기',r.detail]];}
