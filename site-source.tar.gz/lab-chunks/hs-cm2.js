// 공통수학2 — Ⅳ 명제 · Ⅴ 함수 · Ⅵ 유리함수와 무리함수 (11차 이후 추가)
import { fmt, frac, poly, clamp, sub, add, mul, lerp, norm } from "./hs-core.js";

const G = 4; // grade code: 공통수학2
// x − p 꼴
const xm = (p) => (Math.abs(p) < 1e-9 ? "x" : `x ${p > 0 ? "−" : "+"} ${fmt(Math.abs(p))}`);
const plusC = (q) => (Math.abs(q) < 1e-9 ? "" : ` ${q > 0 ? "+" : "−"} ${fmt(Math.abs(q))}`);
// 수직선 위 구간 막대
function bar(g, lo, hi, y, color, name) {
  g.seg([lo, y], [hi, y], { color, w: 9, opacity: 0.55 });
  g.point([lo, y], "", { color, r: 5.5 }).point([hi, y], "", { color, r: 5.5 });
  g.text([g.xr[0] + 0.15, y], name, { anchor: "start", dy: 5, bold: true, color, size: 15 });
}

export default [
  // ───────── Ⅳ 명제 ─────────
  {
    id: "cm2-truth-set", grade: G, unit: 4, lesson: "Ⅳ-2", title: "진리집합으로 보는 필요조건과 충분조건", type: "조작", time: "12분",
    tags: ["명제", "진리집합", "필요조건·충분조건"], links: ["cm2-venn", "cm2-subsets"],
    desc: "두 조건 p: a ≤ x ≤ b, q: c ≤ x ≤ d의 진리집합 P, Q를 수직선 위 막대로 나타내고, P ⊂ Q인지 Q ⊂ P인지로 명제 p → q의 참·거짓과 필요조건·충분조건을 판단합니다.",
    obs: ["P ⊂ Q이면 명제 p → q는 참이고, p는 q이기 위한 충분조건입니다.", "Q ⊂ P이면 q → p가 참이고, p는 q이기 위한 필요조건입니다.", "P = Q이면 필요충분조건입니다. p → q가 거짓이면 P에는 있지만 Q에는 없는 반례가 있습니다."],
    q: "p: 1 ≤ x ≤ 2, q: 0 ≤ x ≤ 3이면 p는 q이기 위한 어떤 조건일까요?",
    formula: "P ⊂ Q ⇔ (p → q가 참) ⇔ p는 q이기 위한 충분조건",
    en: { title: "Truth Sets, Necessary and Sufficient Conditions", desc: "Compare truth sets on a number line to judge p → q." },
    view: { x: [-6.4, 6.4], y: [-1.6, 3.6] },
    params: [
      { key: "head1", label: "조건 p의 범위", type: "head" },
      { key: "a", label: "a (p의 왼쪽 끝)", min: -5, max: 5, step: 0.5, value: -1 },
      { key: "b", label: "b (p의 오른쪽 끝)", min: -5, max: 5, step: 0.5, value: 2 },
      { key: "head2", label: "조건 q의 범위", type: "head" },
      { key: "c", label: "c (q의 왼쪽 끝)", min: -5, max: 5, step: 0.5, value: -2 },
      { key: "d", label: "d (q의 오른쪽 끝)", min: -5, max: 5, step: 0.5, value: 3 },
    ],
    derive(s) { if (s.b < s.a) s.b = s.a; if (s.d < s.c) s.d = s.c; },
    drags: {
      A: { at: (s) => [s.a, 2.4], move: (s, p) => (s.a = clamp(Math.round(p[0] * 2) / 2, -5, s.b)), color: "b", label: "a" },
      B: { at: (s) => [s.b, 2.4], move: (s, p) => (s.b = clamp(Math.round(p[0] * 2) / 2, s.a, 5)), color: "b", label: "b" },
      C: { at: (s) => [s.c, 1.2], move: (s, p) => (s.c = clamp(Math.round(p[0] * 2) / 2, -5, s.d)), color: "c", label: "c" },
      D: { at: (s) => [s.d, 1.2], move: (s, p) => (s.d = clamp(Math.round(p[0] * 2) / 2, s.c, 5)), color: "c", label: "d" },
    },
    judge(s) {
      const PinQ = s.c <= s.a && s.b <= s.d, QinP = s.a <= s.c && s.d <= s.b;
      const cx = PinQ ? null : s.a < s.c ? s.a : s.b > s.d ? s.b : null; // p → q의 반례
      const cy = QinP ? null : s.c < s.a ? s.c : s.d > s.b ? s.d : null; // q → p의 반례
      const kind = PinQ && QinP ? "필요충분조건" : PinQ ? "충분조건" : QinP ? "필요조건" : "필요조건도 충분조건도 아니다";
      return { PinQ, QinP, cx, cy, kind };
    },
    draw(s, g) {
      const J = this.judge(s);
      g.seg([-6, 0], [6, 0], { color: "axis", w: 1.6 });
      for (let x = -6; x <= 6; x++) { g.seg([x, -0.12], [x, 0.12], { color: "axis", w: 1.2 }); g.text([x, 0], fmt(x), { dy: 22, size: 12, color: "muted" }); }
      bar(g, s.a, s.b, 2.4, "b", "P");
      bar(g, s.c, s.d, 1.2, "c", "Q");
      [s.a, s.b].forEach((x) => g.seg([x, 2.4], [x, 0], { color: "b", w: 1, dash: "3 4" }));
      [s.c, s.d].forEach((x) => g.seg([x, 1.2], [x, 0], { color: "c", w: 1, dash: "3 4" }));
      if (J.cx != null) g.point([J.cx, 2.4], "p → q의 반례", { color: "d", r: 7, dy: -16, anchor: "middle", dx: 0 });
      g.text([0, 3.25], `p는 q이기 위한 ${J.kind}`, { bold: true, size: 16, color: J.PinQ || J.QinP ? "a" : "muted" });
    },
    metrics(s) {
      const J = this.judge(s);
      return [
        ["P = {x | p}", `{x | ${fmt(s.a)} ≤ x ≤ ${fmt(s.b)}}`],
        ["Q = {x | q}", `{x | ${fmt(s.c)} ≤ x ≤ ${fmt(s.d)}}`],
        ["p → q", J.PinQ ? "참 (P ⊂ Q)" : `거짓 (반례 x = ${fmt(J.cx)})`],
        ["q → p", J.QinP ? "참 (Q ⊂ P)" : `거짓 (반례 x = ${fmt(J.cy)})`],
        ["결론", J.kind, "key"],
      ];
    },
  },
  // ───────── Ⅴ 함수 ─────────
  {
    id: "cm2-composition", grade: G, unit: 5, lesson: "Ⅴ-2", title: "합성함수 — 화살표를 두 번 따라가기", type: "조작", time: "10분",
    tags: ["합성함수", "대응", "g∘f"], links: ["c2-ladder", "cm2-inverse"],
    desc: "X → Y로 가는 함수 f와 Y → Z로 가는 함수 g의 대응을 직접 정하고, X의 원소에서 화살표를 두 번 따라가 (g∘f)(x) = g(f(x))를 찾습니다.",
    obs: ["(g∘f)(x)는 f를 먼저, g를 나중에 적용합니다. 기호의 오른쪽부터 읽습니다.", "f, g가 모두 일대일대응이면 g∘f도 일대일대응입니다.", "f의 치역이 g의 정의역에 포함되어야 g∘f를 만들 수 있습니다."],
    q: "f는 일대일대응이 아니어도 g∘f가 일대일대응일 수 있을까요?",
    formula: "(g∘f)(x) = g(f(x))",
    en: { title: "Composite Functions with Arrow Diagrams", desc: "Follow f then g to find g(f(x))." },
    view: { x: [0, 16], y: [0, 11], pad: 6 },
    params: [
      { key: "x", label: "따라갈 원소 x", type: "seg", value: "1", options: [["1", "1"], ["2", "2"], ["3", "3"]] },
      { key: "head1", label: "f : X → Y", type: "head" },
      { key: "f1", label: "f(1)", type: "seg", value: "a", options: [["a", "a"], ["b", "b"], ["c", "c"]] },
      { key: "f2", label: "f(2)", type: "seg", value: "c", options: [["a", "a"], ["b", "b"], ["c", "c"]] },
      { key: "f3", label: "f(3)", type: "seg", value: "b", options: [["a", "a"], ["b", "b"], ["c", "c"]] },
      { key: "head2", label: "g : Y → Z", type: "head" },
      { key: "ga", label: "g(a)", type: "seg", value: "q", options: [["p", "p"], ["q", "q"], ["r", "r"]] },
      { key: "gb", label: "g(b)", type: "seg", value: "p", options: [["p", "p"], ["q", "q"], ["r", "r"]] },
      { key: "gc", label: "g(c)", type: "seg", value: "r", options: [["p", "p"], ["q", "q"], ["r", "r"]] },
      { key: "all", label: "g∘f의 화살표 모두 보기", type: "check", value: false },
    ],
    X: ["1", "2", "3"], Y: ["a", "b", "c"], Z: ["p", "q", "r"],
    f(s, x) { return s["f" + x]; },
    g(s, y) { return s["g" + y]; },
    draw(s, g) {
      const cx = [2.6, 8, 13.4], pos = (k, i) => [cx[k], 7.4 - i * 2.2];
      [["X", this.X, "b"], ["Y", this.Y, "c"], ["Z", this.Z, "e"]].forEach(([n, els, c], k) => {
        const pts = []; for (let i = 0; i <= 48; i++) { const t = (i / 48) * 2 * Math.PI; pts.push([cx[k] + 1.6 * Math.cos(t), 5.2 + 3.6 * Math.sin(t)]); }
        g.poly(pts, { fill: c, fo: 0.08, color: c, w: 2 });
        g.text([cx[k], 9.6], n, { bold: true, size: 18, color: c });
        els.forEach((e, i) => { g.point(pos(k, i), "", { color: "ink", r: 5 }); g.text(pos(k, i), e, { dx: k === 0 ? -16 : k === 2 ? 16 : 0, dy: k === 1 ? -12 : 5, bold: true, size: 15 }); });
      });
      const arrow = (k, i, j, o) => { const A = pos(k, i), B = pos(k + 1, j), u = norm(sub(B, A)); g.vec(add(A, mul(u, 0.3)), sub(B, mul(u, 0.3)), o); };
      this.X.forEach((x, i) => { const y = this.f(s, x), on = x === s.x; arrow(0, i, this.Y.indexOf(y), { color: on ? "a" : "muted", w: on ? 3.4 : 1.6, opacity: on ? 1 : 0.55 }); });
      const yx = this.f(s, s.x);
      this.Y.forEach((y, i) => { const z = this.g(s, y), on = y === yx; arrow(1, i, this.Z.indexOf(z), { color: on ? "a" : "muted", w: on ? 3.4 : 1.6, opacity: on ? 1 : 0.55 }); });
      const curve = (x, o) => { const i = this.X.indexOf(x), j = this.Z.indexOf(this.g(s, this.f(s, x))), A = pos(0, i), B = pos(2, j), M = [8, 0.9 - 0.25 * i]; const P = (t) => add(add(mul(A, (1 - t) ** 2), mul(M, 2 * t * (1 - t))), mul(B, t * t)); g.param(P, 0.04, 0.9, { n: 40, ...o }); g.vec(P(0.88), P(0.96), { color: o.color, w: o.w }); };
      (s.all ? this.X : [s.x]).forEach((x) => curve(x, { color: "d", w: x === s.x ? 3 : 1.8, dash: "6 4" }));
      g.text([8, 0.5], "g∘f", { bold: true, color: "d", size: 15 });
    },
    metrics(s) {
      const y = this.f(s, s.x), z = this.g(s, y), imgs = this.X.map((x) => this.g(s, this.f(s, x)));
      const fOne = new Set(this.X.map((x) => this.f(s, x))).size === 3, gOne = new Set(this.Y.map((y) => this.g(s, y))).size === 3, gfOne = new Set(imgs).size === 3;
      return [
        ["(g∘f)(" + s.x + ")", `g(f(${s.x})) = g(${y}) = ${z}`, "key"],
        ["g∘f의 대응", this.X.map((x, i) => `${x} → ${imgs[i]}`).join(",  ")],
        ["일대일대응?", `f ${fOne ? "○" : "×"},  g ${gOne ? "○" : "×"},  g∘f ${gfOne ? "○" : "×"}`],
      ];
    },
  },
  {
    id: "cm2-inverse", grade: G, unit: 5, lesson: "Ⅴ-3", title: "역함수의 그래프 — 직선 y = x에 비친 모습", type: "2D", time: "10분",
    tags: ["역함수", "대칭이동", "y = x"], links: ["cm2-composition", "c2-reflection"],
    desc: "함수 y = f(x)의 그래프 위의 점 P(a, b)를 직선 y = x에 대칭이동한 점 P′(b, a)가 역함수 y = f⁻¹(x)의 그래프 위에 있음을 확인합니다.",
    obs: ["f(a) = b이면 f⁻¹(b) = a이므로 (b, a)는 역함수의 그래프 위에 있습니다.", "선분 PP′은 직선 y = x에 수직이고, 그 중점은 y = x 위에 있습니다.", "역함수를 구할 때는 x와 y를 바꾼 뒤 y에 대하여 풉니다."],
    q: "y = 2x + 1의 역함수는 무엇이고, 두 그래프는 어디에서 만날까요?",
    formula: "y = f(x) ⇔ x = f⁻¹(y) · (a, b) ↔ (b, a)",
    en: { title: "Inverse Functions as Reflections", desc: "Reflect points of y = f(x) in y = x to get the inverse graph." },
    view: { x: [-5, 7], y: [-4, 7] },
    params: [
      { key: "fn", label: "함수", type: "select", value: "lin", options: [["lin", "일차함수 y = mx + k"], ["sq", "y = x² (x ≥ 0)"], ["cube", "y = x³/4"]] },
      { key: "m", label: "기울기 m", min: -3, max: 3, step: 0.5, value: 2, when: (s) => s.fn === "lin" },
      { key: "k", label: "y절편 k", min: -3, max: 3, step: 0.5, value: 1, when: (s) => s.fn === "lin" },
      { key: "t", label: "점 P의 x좌표 a", min: -3, max: 3, step: 0.1, value: 1 },
    ],
    anim: { key: "t", min: -3, max: 3, speed: 1, loop: "bounce", label: "점 P 움직이기" },
    derive(s) { if (Math.abs(s.m) < 1e-9) s.m = 0.5; if (s.fn === "sq" && s.t < 0) s.t = 0; },
    F(s) {
      if (s.fn === "lin") return { f: (x) => s.m * x + s.k, fi: (x) => (x - s.k) / s.m, from: -6, txt: `y = ${poly([[s.m, "x"]], s.k)}`, inv: Math.abs(Math.abs(s.m) - 1) < 1e-9 ? `y = ${poly([[s.m, "x"]], -s.k * s.m)}` : `y = ${s.m < 0 ? "−" : ""}${Math.abs(s.k) < 1e-9 ? "x" : `(${xm(s.k)})`}/${fmt(Math.abs(s.m))}` };
      if (s.fn === "sq") return { f: (x) => (x >= 0 ? x * x : NaN), fi: (x) => (x >= 0 ? Math.sqrt(x) : NaN), from: 0, txt: "y = x² (x ≥ 0)", inv: "y = √x" };
      return { f: (x) => x ** 3 / 4, fi: (x) => Math.cbrt(4 * x), from: -6, txt: "y = x³/4", inv: "y = ∛(4x)" };
    },
    drags: { P: { at: (s) => { const F = (s.fn === "lin" ? (x) => s.m * x + s.k : s.fn === "sq" ? (x) => x * x : (x) => x ** 3 / 4); return [s.t, F(s.t)]; }, move: (s, p) => (s.t = clamp(Math.round(p[0] * 10) / 10, s.fn === "sq" ? 0 : -3, 3)), color: "b", label: "P" } },
    draw(s, g) {
      const F = this.F(s), a = s.t, b = F.f(a), P = [a, b], Q = [b, a];
      g.grid();
      g.line([0, 0], [1, 1], { color: "muted", w: 1.6, dash: "7 5" });
      g.text([5.6, 5.6], "y = x", { dx: -8, dy: -10, color: "muted", bold: true, anchor: "end" });
      g.fx(F.f, { color: "b", w: 3.2, from: F.from }).fx(F.fi, { color: "a", w: 3.2 });
      if (Number.isFinite(b)) {
        g.seg(P, Q, { color: "e", w: 1.6, dash: "4 4" });
        g.point(lerp(P, Q, 0.5), "", { color: "e", r: 3.5 });
        g.point(P, `P(${fmt(a)}, ${fmt(b)})`, { color: "b" }).point(Q, `P′(${fmt(b)}, ${fmt(a)})`, { color: "a", dy: 20 });
      }
      g.text([g.xr[0] + 0.3, g.yr[1] - 0.6], F.txt, { anchor: "start", bold: true, color: "b" });
      g.text([g.xr[0] + 0.3, g.yr[1] - 1.4], `역함수 ${F.inv}`, { anchor: "start", bold: true, color: "a" });
    },
    metrics(s) {
      const F = this.F(s), a = s.t, b = F.f(a);
      return [
        ["f(a) = b", `f(${fmt(a)}) = ${fmt(b, 3)}`],
        ["f⁻¹(b) = a", `f⁻¹(${fmt(b, 3)}) = ${fmt(a)}`],
        ["역함수", F.inv, "key"],
        ["PP′의 중점", `(${fmt((a + b) / 2, 3)}, ${fmt((a + b) / 2, 3)}), y = x 위의 점`],
      ];
    },
  },
  // ───────── Ⅵ 유리함수와 무리함수 ─────────
  {
    id: "cm2-rational", grade: G, unit: 6, lesson: "Ⅵ-1", title: "유리함수 y = k/(x − p) + q와 점근선", type: "조작", time: "12분",
    tags: ["유리함수", "점근선", "평행이동"], links: ["cm2-irrational", "cm2-inverse"],
    desc: "y = k/x의 그래프를 x축 방향으로 p, y축 방향으로 q만큼 평행이동하며 점근선 x = p, y = q와 정의역·치역이 어떻게 바뀌는지 확인합니다. k의 부호와 크기에 따른 모양 변화도 봅니다.",
    obs: ["그래프는 두 점근선 x = p, y = q에 한없이 가까워지지만 만나지 않습니다.", "k > 0이면 그래프가 제1·3사분면 쪽, k < 0이면 제2·4사분면 쪽에 놓입니다.", "|k|가 클수록 그래프가 점근선의 교점에서 멀어집니다."],
    q: "y = (2x + 1)/(x − 1)을 y = k/(x − p) + q 꼴로 바꾸면 점근선은 무엇일까요?",
    formula: "y = k/(x − p) + q · 점근선 x = p, y = q",
    en: { title: "Rational Functions and Asymptotes", desc: "Translate y = k/x and watch the asymptotes, domain and range." },
    view: { x: [-7, 7], y: [-5, 5] },
    params: [
      { key: "k", label: "k", min: -4, max: 4, step: 0.5, value: 2 },
      { key: "p", label: "x축 방향 이동 p", min: -3, max: 3, step: 0.5, value: 1 },
      { key: "q", label: "y축 방향 이동 q", min: -3, max: 3, step: 0.5, value: 2 },
      { key: "ghost", label: "y = k/x 같이 보기", type: "check", value: true },
    ],
    anim: { key: "k", min: -4, max: 4, speed: 1.6, loop: "bounce", label: "k 바꾸기" },
    derive(s) { if (Math.abs(s.k) < 1e-9) s.k = 0.5; },
    drags: { O: { at: (s) => [s.p, s.q], move: (s, p) => { s.p = clamp(Math.round(p[0] * 2) / 2, -3, 3); s.q = clamp(Math.round(p[1] * 2) / 2, -3, 3); }, color: "e", label: "점근선의 교점" } },
    draw(s, g) {
      const f = (x) => s.k / (x - s.p) + s.q;
      g.grid();
      if (s.ghost) g.fx((x) => s.k / x, { color: "muted", w: 1.6, dash: "6 5", opacity: 0.8 });
      g.line([s.p, 0], [s.p, 1], { color: "e", w: 1.8, dash: "7 5" }).line([0, s.q], [1, s.q], { color: "e", w: 1.8, dash: "7 5" });
      g.text([s.p, g.yr[1]], `x = ${fmt(s.p)}`, { dx: 8, dy: 20, anchor: "start", color: "e", bold: true });
      g.text([g.xr[1], s.q], `y = ${fmt(s.q)}`, { dx: -8, dy: -8, anchor: "end", color: "e", bold: true });
      g.fx(f, { color: "a", w: 3.2, from: g.xr[0], to: s.p - 1e-3 }).fx(f, { color: "a", w: 3.2, from: s.p + 1e-3, to: g.xr[1] });
    },
    metrics(s) {
      const { k, p, q } = s, num = poly([[q, "x"]], k - p * q);
      return [
        ["식", `y = ${frac(k)}/(${xm(p)})${plusC(q)}`, "key"],
        ["분수식으로", `y = (${num})/(${xm(p)})`],
        ["점근선", `x = ${fmt(p)}, y = ${fmt(q)}`],
        ["정의역 · 치역", `x ≠ ${fmt(p)}인 실수 / y ≠ ${fmt(q)}인 실수`],
      ];
    },
  },
  {
    id: "cm2-irrational", grade: G, unit: 6, lesson: "Ⅵ-2", title: "무리함수 y = ±√(a(x − p)) + q의 그래프", type: "조작", time: "12분",
    tags: ["무리함수", "정의역", "평행이동"], links: ["cm2-rational", "cm2-inverse"],
    desc: "y = √(ax)의 그래프를 대칭이동하고 평행이동하며, 그래프가 시작하는 점 (p, q)와 정의역·치역이 a의 부호와 √ 앞의 부호에 따라 어떻게 정해지는지 확인합니다.",
    obs: ["근호 안이 0 이상인 x만 정의역에 들어갑니다. a > 0이면 x ≥ p, a < 0이면 x ≤ p입니다.", "√ 앞이 +이면 y ≥ q, −이면 y ≤ q입니다.", "y = √(ax)와 y = x²/a (x ≥ 0)은 서로 역함수 관계입니다."],
    q: "y = √(2 − x) + 1의 정의역과 치역은 무엇일까요?",
    formula: "y = ±√(a(x − p)) + q · 시작점 (p, q)",
    en: { title: "Graphs of Irrational Functions", desc: "Reflect and translate y = √(ax) and read the domain and range." },
    view: { x: [-7, 7], y: [-5, 5] },
    params: [
      { key: "sg", label: "√ 앞의 부호", type: "seg", value: "+", options: [["+", "+√"], ["-", "−√"]] },
      { key: "a", label: "a", min: -4, max: 4, step: 0.5, value: 2 },
      { key: "p", label: "x축 방향 이동 p", min: -4, max: 4, step: 0.5, value: -2 },
      { key: "q", label: "y축 방향 이동 q", min: -3, max: 3, step: 0.5, value: -1 },
      { key: "ghost", label: "y = √(ax) 같이 보기", type: "check", value: true },
    ],
    anim: { key: "a", min: -4, max: 4, speed: 1.6, loop: "bounce", label: "a 바꾸기" },
    derive(s) { if (Math.abs(s.a) < 1e-9) s.a = 0.5; },
    drags: { S: { at: (s) => [s.p, s.q], move: (s, p) => { s.p = clamp(Math.round(p[0] * 2) / 2, -4, 4); s.q = clamp(Math.round(p[1] * 2) / 2, -3, 3); }, color: "e", label: "시작점" } },
    draw(s, g) {
      const sg = s.sg === "+" ? 1 : -1, r = (x, p, q) => { const u = s.a * (x - p); return u < -1e-12 ? NaN : sg * Math.sqrt(Math.max(0, u)) + q; };
      g.grid();
      if (s.ghost) g.fx((x) => r(x, 0, 0), { color: "muted", w: 1.6, dash: "6 5", opacity: 0.8, n: 900 });
      const lo = s.a > 0 ? s.p : g.xr[0], hi = s.a > 0 ? g.xr[1] : s.p;
      g.param((x) => [x, r(x, s.p, s.q)], lo, hi, { color: "a", w: 3.2, n: 900 });
      g.seg([s.p, s.q], [s.a > 0 ? g.xr[1] : g.xr[0], s.q], { color: "e", w: 1, dash: "3 4" });
      g.point([s.p, s.q], `(${fmt(s.p)}, ${fmt(s.q)})`, { color: "e", dy: sg > 0 ? 22 : -12 });
    },
    metrics(s) {
      const sg = s.sg === "+" ? "" : "−", inner = Math.abs(s.p) < 1e-9 ? `${fmt(s.a)}x` : `${fmt(s.a)}(${xm(s.p)})`;
      return [
        ["식", `y = ${sg}√(${inner})${plusC(s.q)}`, "key"],
        ["정의역", s.a > 0 ? `x ≥ ${fmt(s.p)}` : `x ≤ ${fmt(s.p)}`],
        ["치역", s.sg === "+" ? `y ≥ ${fmt(s.q)}` : `y ≤ ${fmt(s.q)}`],
        ["그래프가 놓인 방향", `${s.a > 0 ? "오른쪽" : "왼쪽"}${s.sg === "+" ? " 위" : " 아래"}`],
      ];
    },
  },
];
