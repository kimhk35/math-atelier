import { parseAnswer } from "./answer-input.js";
// 옛 실험에 붙이는 '예측하고 확인하기' 칸 (엔진 실험의 예측 칸과 같은 모양)
import { mathHTML } from "./mathtex.js";
import BANK from "./predict-bank.js";

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const fmt = (x) => (Number.isFinite(x) ? String(Math.round(x * 1e4) / 1e4).replace("-", "−") : String(x));
// 은행 문항 → 엔진 예측 문항 형식
export const norm = (b) => ({ q: b.q, options: b.opt || null, answer: () => b.a, tol: b.tol, rel: b.rel, why: b.why, show: b.show ? () => b.show : undefined });
export const bankFor = (id) => (BANK[id] ? BANK[id].map(norm) : null);
const parseNum = parseAnswer;

export function mountPredict(el, items) {
  const st = { i: 0, ans: {}, res: {} };
  const draw = () => {
    const it = items[st.i], r = st.res[st.i], a = st.ans[st.i] ?? "";
    const input = it.options
      ? `<div class="hs-seg hs-pred-opts" role="group">${it.options.map(([v, l]) => `<button type="button" data-pred-opt="${esc(v)}" aria-pressed="${String(a) === String(v)}">${esc(l)}</button>`).join("")}</div>`
      : `<input class="hs-pred-in" data-pred-in type="text" inputmode="decimal" value="${esc(a)}" placeholder="내 예측" aria-label="내 예측">`;
    el.innerHTML = `<section class="hs-pred" aria-label="예측하고 확인하기"><h3>예측하고 확인하기 <small>${st.i + 1} / ${items.length}</small></h3><p class="hs-pred-q">${mathHTML(it.q)}</p>
      <div class="hs-pred-row">${input}<button type="button" class="btn primary" data-pred="check">확인</button></div>
      ${r ? `<div class="hs-pred-res ${r.ok == null ? "" : r.ok ? "ok" : "no"}">${r.ok == null ? "" : `<strong>${r.ok ? "✓ 예측이 맞았어요" : "✗ 다시 생각해 볼까요?"}</strong>`}${r.showAnswer ? `<p>${mathHTML("답: " + r.ans)}</p>` : ""}${r.showWhy && r.why ? `<p>${mathHTML(r.why)}</p>` : ""}</div>` : ""}
      <div class="hs-actions"><button type="button" class="btn" data-pred="answer">${r?.showAnswer ? "정답 숨기기" : "정답 보기"}</button><button type="button" class="btn" data-pred="why">${r?.showWhy ? "풀이 숨기기" : "풀이 보기"}</button></div><div class="hs-pred-nav"><button type="button" class="btn" data-pred="prev"${st.i ? "" : " disabled"}>◀ 이전</button><button type="button" class="btn" data-pred="next"${st.i < items.length - 1 ? "" : " disabled"}>다음 ▶</button></div></section>`;
  };
  const check = (mode="check") => {
    const it = items[st.i], ans = it.answer(), mine = st.ans[st.i] ?? "";
    let ok;
    if (typeof ans === "number") { const v = parseNum(mine), tol = it.tol ?? 1e-6; ok = Number.isFinite(v) && Math.abs(v - ans) <= tol * (it.rel ? Math.abs(ans) : 1) + 1e-9; }
    else ok = String(mine) === String(ans);
    const before=st.res[st.i];
    st.res[st.i] = { ok: mode === "check" ? ok : before?.ok ?? null, showAnswer: mode === "answer" ? !before?.showAnswer : mode === "check" || !!before?.showAnswer, showWhy: mode === "why" ? !before?.showWhy : !!before?.showWhy, ans: it.show ? it.show() : typeof ans === "number" ? fmt(ans) : it.options?.find(([v]) => String(v) === String(ans))?.[1] ?? ans, why: it.why };
    draw();
  };
  el.onclick = (e) => {
    const o = e.target.closest("[data-pred-opt]"); if (o) { st.ans[st.i] = o.dataset.predOpt; draw(); return; }
    const b = e.target.closest("[data-pred]"); if (!b) return;
    if (["check","answer","why"].includes(b.dataset.pred)) check(b.dataset.pred);
    else { st.i = Math.max(0, Math.min(items.length - 1, st.i + (b.dataset.pred === "next" ? 1 : -1))); draw(); }
  };
  el.oninput = (e) => { if (e.target.matches("[data-pred-in]")) st.ans[st.i] = e.target.value; };
  el.onkeydown = (e) => { if (e.key === "Enter" && e.target.matches("[data-pred-in]")) { st.ans[st.i] = e.target.value; check(); } };
  draw();
}
