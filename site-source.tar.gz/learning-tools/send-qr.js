// 학생에게 보내기 — 지금 실험(조건 포함) 주소를 큰 QR 코드로 띄운다.
// QR 그리기는 vendor/qrcode-generator-1.4.4.js(MIT, 사이트 안에 포함)를 처음 쓸 때만 불러온다.
const LIB = new URL("../vendor/qrcode-generator-1.4.4.js", import.meta.url).href;
const MAX = 1400; // 이보다 긴 주소는 QR 칸이 너무 촘촘해져 교실 화면에서 찍기 어렵다

let loading = null;
function loadLib() {
  if (window.qrcode) return Promise.resolve(window.qrcode);
  if (!loading) loading = new Promise((ok, fail) => {
    const s = document.createElement("script");
    s.src = LIB; s.onload = () => (window.qrcode ? ok(window.qrcode) : fail(new Error("QR 도구를 읽지 못했어요.")));
    s.onerror = () => { loading = null; fail(new Error("QR 도구를 불러오지 못했어요. 인터넷 연결을 확인해 주세요.")); };
    document.head.append(s);
  });
  return loading;
}

const CSS = `.sq-shade{position:fixed;inset:0;z-index:300;background:rgba(10,22,40,.72);display:grid;place-items:center;padding:16px}
.sq-card{background:var(--hm-sheet,#fff);color:var(--hm-ink,#13294b);border-radius:20px;padding:24px;width:min(560px,100%);max-height:calc(100vh - 32px);overflow:auto;box-shadow:0 30px 80px -30px rgba(0,0,0,.6);text-align:center}
.sq-card h2{margin:0 0 4px;font-size:22px;line-height:1.35;word-break:keep-all}
.sq-card p{margin:0 0 14px;color:var(--hm-muted,#5b6b7c);font-size:15px;word-break:keep-all}
.sq-qr{background:#fff;border-radius:14px;padding:14px;display:inline-block;width:min(420px,100%)}
.sq-qr svg{display:block;width:100%;height:auto}
.sq-url{margin:12px 0 0;font:500 13px/1.5 "IBM Plex Mono",ui-monospace,monospace;color:var(--hm-muted,#5b6b7c);word-break:break-all;max-height:4.5em;overflow:hidden}
.sq-note{margin-top:10px;font-size:14px;color:#9a6a12}
.sq-opt{display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:4px 8px;margin-top:12px;font-size:15px;cursor:pointer}.sq-opt input{width:20px;height:20px}.sq-opt small{width:100%;color:var(--hm-muted,#5b6b7c);font-size:13px}
.sq-row{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:16px}
.sq-row button{min-height:46px;padding:0 18px;border-radius:12px;border:1px solid var(--hm-line,#dfe5ea);background:transparent;color:inherit;font:inherit;font-weight:600;cursor:pointer}
.sq-row button.sq-primary{background:#13294b;color:#fff;border-color:#13294b}
:root[data-theme="dark"] .sq-card{background:#132138;color:#e4ebf3}
:root[data-theme="dark"] .sq-row button.sq-primary{background:#47b8ad;border-color:#47b8ad;color:#0f1a2b}
.sq-shade.sq-big .sq-card{width:min(92vh,100%);padding:18px}.sq-shade.sq-big .sq-qr{width:min(78vh,100%)}`;

function svgOf(qr) {
  const n = qr.getModuleCount(), q = 2, size = n + q * 2;
  let d = "";
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (qr.isDark(r, c)) d += `M${c + q} ${r + q}h1v1h-1z`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" role="img" aria-label="실험 주소 QR 코드" shape-rendering="crispEdges"><rect width="${size}" height="${size}" fill="#fff"/><path d="${d}" fill="#0b1a30"/></svg>`;
}

export async function openSendQR({ url, shortUrl, title, notify }) {
  const tooLong = url.length > MAX, full = url;
  let qrcode;
  try { qrcode = await loadLib(); } catch (e) { notify?.(e.message); return; }
  const make = (u) => { const qr = qrcode(0, "M"); qr.addData(u, "Byte"); qr.make(); return svgOf(qr); };
  if (tooLong) url = shortUrl;
  if (!document.getElementById("send-qr-css")) { const st = document.createElement("style"); st.id = "send-qr-css"; st.textContent = CSS; document.head.append(st); }
  const back = document.activeElement;
  const shade = document.createElement("div");
  shade.className = "sq-shade";
  shade.innerHTML = `<div class="sq-card" role="dialog" aria-modal="true" aria-labelledby="sq-title"><h2 id="sq-title"></h2><p>휴대폰 카메라로 찍으면 지금 보고 있는 실험이 그대로 열려요.</p><div class="sq-qr">${make(url)}</div><div class="sq-url"></div>${tooLong ? `<div class="sq-note">설정이 너무 길어서 QR에는 처음 상태의 실험 주소를 담았어요.</div>` : full !== shortUrl ? `<label class="sq-opt"><input type="checkbox" checked> 지금 설정(조건)까지 함께 보내기 <small>끄면 QR 무늬가 단순해져 멀리서도 잘 찍혀요</small></label>` : ""}<div class="sq-row"><button type="button" class="sq-primary" data-sq="big">크게 보기</button><button type="button" data-sq="copy">링크 복사</button><button type="button" data-sq="close">닫기 (Esc)</button></div></div>`;
  shade.querySelector("#sq-title").textContent = title;
  shade.querySelector(".sq-url").textContent = url;
  shade.querySelector(".sq-opt input")?.addEventListener("change", (e) => { url = e.target.checked ? full : shortUrl; shade.querySelector(".sq-qr").innerHTML = make(url); shade.querySelector(".sq-url").textContent = url; });
  const close = () => { shade.remove(); document.removeEventListener("keydown", onKey, true); back?.focus?.(); };
  const onKey = (e) => { if (e.key === "Escape") { e.preventDefault(); close(); } };
  document.addEventListener("keydown", onKey, true);
  shade.addEventListener("click", async (e) => {
    if (e.target === shade) return close();
    const act = e.target.closest("[data-sq]")?.dataset.sq;
    if (act === "close") close();
    if (act === "big") { const big = shade.classList.toggle("sq-big"); e.target.textContent = big ? "작게 보기" : "크게 보기"; }
    if (act === "copy") { try { await navigator.clipboard.writeText(url); notify?.("링크를 복사했어요."); } catch { notify?.("링크를 복사하지 못했어요. 아래 주소를 직접 복사해 주세요."); } }
  });
  document.body.append(shade);
  shade.querySelector('[data-sq="big"]').focus();
}
