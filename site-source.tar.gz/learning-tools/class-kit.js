// 수업 도구 묶음 — 키보드 단축키 · 예측 맞힘 기록(진도) · 타이머와 번호 뽑기 · 수업 꾸러미
// 모두 이 기기의 브라우저에만 저장한다(학생 정보는 어디로도 보내지 않음).
import { openSendQR } from "./send-qr.js";

const LS = {
  get(k, d) { try { const v = JSON.parse(localStorage.getItem(k)); return v ?? d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};
const SS = {
  get(k, d) { try { const v = JSON.parse(sessionStorage.getItem(k)); return v ?? d; } catch { return d; } },
  set(k, v) { try { v == null ? sessionStorage.removeItem(k) : sessionStorage.setItem(k, JSON.stringify(v)); } catch {} },
};
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const labId = () => decodeURIComponent((location.hash.match(/^#\/lab\/([^?&]+)/) || [])[1] || "") || null;
const hashQuery = () => new URLSearchParams((location.hash.split("?")[1] || ""));
const isTyping = (t) => t && (t.isContentEditable || /^(TEXTAREA|SELECT)$/.test(t.tagName) || (t.tagName === "INPUT" && !/^(checkbox|radio|button)$/i.test(t.type)));
const onSlider = (t) => t && t.closest?.('[role="slider"],input[type="range"],.hs-handle,[data-drag]');
const say = (m) => { const el = document.getElementById("lab-status"); if (el) el.textContent = m; };
const KO = () => document.documentElement.lang !== "en";
const L = (ko, en) => (KO() ? ko : en);

// ── F2 예측 맞힘 기록 ─────────────────────────────────
const PKEY = "mckay-pred-ok";
export const predOk = (id) => { const r = LS.get(PKEY, {})[id]; return r && Array.isArray(r.ok) ? r.ok.length : 0; };
export const predOkTotal = () => Object.values(LS.get(PKEY, {})).reduce((s, r) => s + (Array.isArray(r?.ok) ? r.ok.length : 0), 0);
document.addEventListener("click", (e) => {
  const b = e.target.closest?.('[data-pred="check"]'); if (!b) return;
  const sec = b.closest(".hs-pred"), id = labId(); if (!sec || !id) return;
  // 예측 칸이 결과를 다시 그린 뒤에 맞았는지 읽는다
  requestAnimationFrame(() => requestAnimationFrame(() => {
    const now = document.querySelector(".hs-pred"); if (!now?.querySelector(".hs-pred-res.ok")) return;
    const m = (now.querySelector("h3 small")?.textContent || "").match(/(\d+)\s*\/\s*(\d+)/); if (!m) return;
    const all = LS.get(PKEY, {}), r = all[id] || { n: +m[2], ok: [] };
    if (!r.ok.includes(+m[1])) r.ok.push(+m[1]);
    r.n = +m[2]; all[id] = r; LS.set(PKEY, all);
  }));
}, true);
export function resetProgress() {
  if (!confirm(L("이 기기에 저장된 진도(해 본 실험과 예측 맞힘 기록)를 모두 지울까요?", "Clear all progress saved on this device (visited experiments and correct predictions)?"))) return false;
  try { localStorage.removeItem("mckay-visited"); localStorage.removeItem(PKEY); } catch {}
  return true;
}

// ── F3 수업 도구 상자: 타이머와 번호 뽑기 ──────────────────
const CSS = `.ck-panel{position:fixed;right:18px;bottom:18px;z-index:250;width:300px;max-width:calc(100vw - 24px);background:var(--hm-sheet,#fff);color:var(--hm-ink,#13294b);border:1px solid var(--hm-line,#dfe5ea);border-radius:16px;box-shadow:0 24px 60px -24px rgba(10,22,40,.55);font:15px/1.5 "IBM Plex Sans KR","Malgun Gothic",sans-serif;user-select:none}
:root[data-theme="dark"] .ck-panel{background:#132138;color:#e4ebf3;border-color:#24344f}
.ck-panel.ck-big{width:min(520px,calc(100vw - 24px))}
.ck-head{display:flex;align-items:center;gap:6px;padding:8px 8px 8px 14px;border-bottom:1px solid var(--hm-line,#dfe5ea);cursor:move;touch-action:none}
.ck-head b{flex:1;font-size:15px}
.ck-panel button{font:inherit;cursor:pointer;color:inherit}
.ck-x{width:36px;height:36px;border:0;border-radius:10px;background:transparent;font-size:18px}
.ck-tabs{display:flex;gap:4px;padding:8px 10px 0}
.ck-tabs button{flex:1;min-height:38px;border:1px solid var(--hm-line,#dfe5ea);border-radius:10px;background:transparent;font-weight:600}
.ck-tabs button[aria-pressed="true"]{background:#13294b;color:#fff;border-color:#13294b}
:root[data-theme="dark"] .ck-tabs button[aria-pressed="true"]{background:#47b8ad;color:#0f1a2b;border-color:#47b8ad}
.ck-body{padding:12px 14px 14px}
.ck-big-num{font:600 64px/1.05 "IBM Plex Mono",ui-monospace,monospace;text-align:center;font-variant-numeric:tabular-nums;letter-spacing:-.02em;margin:4px 0 10px}
.ck-panel.ck-big .ck-big-num{font-size:120px}
.ck-big-num.ck-end{color:#c8553d;animation:ckblink .6s steps(2) 6}
@keyframes ckblink{50%{opacity:.25}}
@media (prefers-reduced-motion:reduce){.ck-big-num.ck-end{animation:none}}
.ck-row{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin-top:8px}
.ck-row button{min-width:46px;min-height:42px;padding:0 12px;border:1px solid var(--hm-line,#dfe5ea);border-radius:10px;background:transparent;font-weight:600}
.ck-row button.ck-go{background:#0f7a73;border-color:#0f7a73;color:#fff;min-width:96px}
.ck-row label{display:flex;align-items:center;gap:6px;font-size:14px}
.ck-row input[type=number]{width:70px;min-height:38px;border:1px solid var(--hm-line,#dfe5ea);border-radius:8px;padding:0 8px;font:inherit;background:transparent;color:inherit}
.ck-drawn{margin-top:8px;font-size:13px;color:var(--hm-muted,#5b6b7c);text-align:center;word-break:keep-all;min-height:1.5em}
.ck-help{position:fixed;inset:0;z-index:320;background:rgba(10,22,40,.6);display:grid;place-items:center;padding:16px}
.ck-help>div{background:var(--hm-sheet,#fff);color:var(--hm-ink,#13294b);border-radius:18px;padding:22px 24px;width:min(520px,100%);box-shadow:0 30px 80px -30px rgba(0,0,0,.6)}
:root[data-theme="dark"] .ck-help>div{background:#132138;color:#e4ebf3}
.ck-help h2{margin:0 0 12px;font-size:21px}.ck-help table{width:100%;border-collapse:collapse;font-size:15px}.ck-help td{padding:7px 4px;border-bottom:1px solid var(--hm-line,#dfe5ea)}
.ck-help kbd{display:inline-block;min-width:28px;padding:2px 7px;margin-right:3px;border:1px solid currentColor;border-radius:6px;font:500 13px "IBM Plex Mono",monospace;text-align:center;opacity:.85}
.ck-help button{margin-top:14px;min-height:44px;padding:0 18px;border-radius:10px;border:1px solid currentColor;background:transparent;color:inherit;font:inherit;font-weight:600;cursor:pointer}
.ck-pack{display:flex;flex-wrap:wrap;align-items:center;gap:8px 12px;margin:0 0 14px;padding:10px 14px;border:1.5px solid #b5862e;border-radius:14px;background:color-mix(in srgb,#b5862e 9%,transparent)}
.ck-pack b{font-size:15px}.ck-pack .ck-dots{display:flex;flex-wrap:wrap;gap:6px;flex:1}
.ck-pack .ck-dots a{display:inline-grid;place-items:center;min-width:34px;height:34px;border-radius:999px;border:1px solid currentColor;text-decoration:none;color:inherit;font-weight:600;font-size:14px;opacity:.7}
.ck-pack .ck-dots a[aria-current="step"]{background:#13294b;color:#fff;border-color:#13294b;opacity:1}
.ck-pack .ck-dots a.ck-seen{opacity:1}
.ck-pack button,.ck-pack a.ck-step{min-height:40px;padding:0 14px;border-radius:10px;border:1px solid currentColor;background:transparent;color:inherit;font:inherit;font-weight:600;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center}
.ck-pack a.ck-step.ck-next{background:#0f7a73;border-color:#0f7a73;color:#fff}`;
function css() { if (!document.getElementById("ck-css")) { const s = document.createElement("style"); s.id = "ck-css"; s.textContent = CSS; document.head.append(s); } }

let audio = null;
function chime() {
  try {
    audio = audio || new (window.AudioContext || window.webkitAudioContext)();
    const t = audio.currentTime;
    [0, 0.35, 0.7].forEach((d, i) => { const o = audio.createOscillator(), g = audio.createGain(); o.type = "triangle"; o.frequency.value = [880, 988, 1175][i]; g.gain.setValueAtTime(0.0001, t + d); g.gain.exponentialRampToValueAtTime(0.25, t + d + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.5); o.connect(g); g.connect(audio.destination); o.start(t + d); o.stop(t + d + 0.55); });
  } catch {}
}
const T = { total: 300, left: 300, run: false, end: 0, tick: 0 };
const P = { n: LS.get("ck-pick-n", 30), noRepeat: LS.get("ck-pick-norep", true), drawn: [], cur: null };
let panel = null, tab = "timer";
const mmss = (s) => { s = Math.max(0, Math.ceil(s)); return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`; };
function timerTick() {
  if (!T.run) return;
  T.left = (T.end - performance.now()) / 1000;
  if (T.left <= 0) { T.left = 0; T.run = false; chime(); say(L("타이머가 끝났어요.", "Time is up.")); draw(true); return; }
  const n = panel?.querySelector(".ck-big-num"); if (n && tab === "timer") n.textContent = mmss(T.left);
  T.tick = requestAnimationFrame(timerTick);
}
function draw(ended = false) {
  if (!panel) return;
  const big = panel.classList.contains("ck-big");
  const body = tab === "timer"
    ? `<div class="ck-big-num${ended ? " ck-end" : ""}" aria-live="polite">${mmss(T.left)}</div>
       <div class="ck-row">${[1, 3, 5, 10].map((m) => `<button type="button" data-ck="set" data-v="${m * 60}">${m}${L("분", " min")}</button>`).join("")}</div>
       <div class="ck-row"><button type="button" data-ck="add" data-v="-60" aria-label="${L("1분 빼기", "Minus 1 minute")}">−1</button><button type="button" class="ck-go" data-ck="go">${T.run ? L("멈춤", "Pause") : L("시작", "Start")}</button><button type="button" data-ck="add" data-v="60" aria-label="${L("1분 더하기", "Plus 1 minute")}">+1</button><button type="button" data-ck="reset">${L("처음으로", "Reset")}</button></div>`
    : `<div class="ck-big-num" aria-live="polite">${P.cur ?? "–"}</div>
       <div class="ck-row"><label>${L("1번부터", "From 1 to")} <input type="number" min="2" max="999" value="${P.n}" data-ck="n" aria-label="${L("마지막 번호", "Last number")}">${L("번까지", "")}</label></div>
       <div class="ck-row"><button type="button" class="ck-go" data-ck="pick">${L("뽑기", "Draw")}</button><button type="button" data-ck="clear">${L("다시 시작", "Start over")}</button></div>
       <div class="ck-row"><label><input type="checkbox" data-ck="norep" ${P.noRepeat ? "checked" : ""}> ${L("한 번 뽑힌 번호는 빼기", "Don't repeat numbers")}</label></div>
       <div class="ck-drawn">${P.drawn.length ? L("뽑은 번호: ", "Drawn: ") + P.drawn.join(", ") : ""}</div>`;
  panel.innerHTML = `<div class="ck-head" data-ck-drag><b>${L("수업 도구", "Class tools")}</b><button type="button" class="ck-x" data-ck="big" aria-label="${big ? L("작게", "Smaller") : L("크게", "Larger")}" title="${big ? L("작게", "Smaller") : L("크게 (프로젝터용)", "Larger (for projector)")}">${big ? "⤡" : "⤢"}</button><button type="button" class="ck-x" data-ck="close" aria-label="${L("닫기", "Close")}">×</button></div>
    <div class="ck-tabs" role="tablist"><button type="button" role="tab" data-ck="tab" data-v="timer" aria-pressed="${tab === "timer"}">⏱ ${L("타이머", "Timer")}</button><button type="button" role="tab" data-ck="tab" data-v="pick" aria-pressed="${tab === "pick"}">🎲 ${L("번호 뽑기", "Pick a number")}</button></div>
    <div class="ck-body">${body}</div>`;
}
function pick() {
  const pool = []; for (let i = 1; i <= P.n; i++) if (!P.noRepeat || !P.drawn.includes(i)) pool.push(i);
  if (!pool.length) { say(L("모든 번호를 다 뽑았어요. ‘다시 시작’을 누르세요.", "All numbers have been drawn. Press Start over.")); return; }
  const n = panel.querySelector(".ck-big-num"), reduce = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
  if (P.spinning) return; // 숫자가 도는 중에는 다시 뽑지 않는다
  const final = pool[Math.floor(Math.random() * pool.length)];
  let k = 0; P.spinning = true;
  const spin = () => { if (k++ < (reduce ? 0 : 12)) { n.textContent = pool[Math.floor(Math.random() * pool.length)]; setTimeout(spin, 30 + k * 5); return; } P.spinning = false; P.cur = final; P.drawn.push(final); draw(); };
  spin();
}
export function openTools(which) {
  css();
  if (which) tab = which;
  if (!panel) {
    panel = document.createElement("section"); panel.className = "ck-panel"; panel.setAttribute("aria-label", L("수업 도구", "Class tools"));
    document.body.append(panel);
    panel.addEventListener("click", (e) => {
      const b = e.target.closest("[data-ck]"); if (!b) return;
      const a = b.dataset.ck, v = +b.dataset.v;
      if (a === "close") { panel.remove(); panel = null; return; }
      if (a === "big") panel.classList.toggle("ck-big");
      if (a === "tab") tab = b.dataset.v;
      if (a === "set") { T.total = T.left = v; T.run = false; cancelAnimationFrame(T.tick); }
      if (a === "add") { T.left = Math.max(0, T.left + v); T.total = Math.max(T.total, T.left); if (T.run) T.end = performance.now() + T.left * 1000; }
      if (a === "go") { if (T.run) { T.run = false; cancelAnimationFrame(T.tick); } else if (T.left > 0) { T.run = true; T.end = performance.now() + T.left * 1000; audio?.resume?.(); cancelAnimationFrame(T.tick); T.tick = requestAnimationFrame(timerTick); } }
      if (a === "reset") { T.run = false; cancelAnimationFrame(T.tick); T.left = T.total; }
      if (a === "pick") { pick(); return; }
      if (a === "clear") { P.drawn = []; P.cur = null; }
      if (a !== "norep") draw();
    });
    panel.addEventListener("change", (e) => {
      if (e.target.matches('[data-ck="n"]')) { P.n = Math.max(2, Math.min(999, Math.round(+e.target.value) || 30)); LS.set("ck-pick-n", P.n); P.drawn = P.drawn.filter((x) => x <= P.n); draw(); }
      if (e.target.matches('[data-ck="norep"]')) { P.noRepeat = e.target.checked; LS.set("ck-pick-norep", P.noRepeat); }
    });
    // 머리 부분을 끌어 옮기기
    let drag = null;
    panel.addEventListener("pointerdown", (e) => { if (!e.target.closest("[data-ck-drag]") || e.target.closest("button")) return; const r = panel.getBoundingClientRect(); drag = { dx: e.clientX - r.left, dy: e.clientY - r.top, id: e.pointerId }; panel.setPointerCapture(e.pointerId); });
    panel.addEventListener("pointermove", (e) => { if (!drag || drag.id !== e.pointerId) return; const x = Math.max(4, Math.min(innerWidth - panel.offsetWidth - 4, e.clientX - drag.dx)), y = Math.max(4, Math.min(innerHeight - 60, e.clientY - drag.dy)); Object.assign(panel.style, { left: x + "px", top: y + "px", right: "auto", bottom: "auto" }); });
    panel.addEventListener("pointerup", () => (drag = null));
  }
  draw();
  panel.querySelector(".ck-go")?.focus();
}
export const toggleTools = () => (panel ? (panel.remove(), (panel = null)) : openTools());

// ── F1 수업 꾸러미 ───────────────────────────────────
const KPACK = "ck-pack";
const titleOf = (id) => (window.__atelierTitle ? window.__atelierTitle(id) : id);
function currentPack() {
  const q = hashQuery(), raw = q.get("pack");
  if (raw) {
    const ids = raw.split(",").map((s) => s.trim()).filter(Boolean).slice(0, 40);
    if (ids.length) { const p = { ids, title: (q.get("pt") || "").slice(0, 80) }; SS.set(KPACK, p); return p; }
  }
  const p = SS.get(KPACK, null), id = labId();
  if (p && id && p.ids.includes(id)) return p;
  if (p && id && !p.ids.includes(id)) SS.set(KPACK, null);
  return null;
}
function packStep(d) { const p = currentPack(), id = labId(); if (!p || !id) return false; const i = p.ids.indexOf(id) + d; if (i < 0 || i >= p.ids.length) { say(i < 0 ? L("꾸러미의 첫 실험이에요.", "This is the first experiment in the set.") : L("꾸러미의 마지막 실험이에요. 수고했어요!", "That was the last experiment in the set. Well done!")); return true; } location.hash = "#/lab/" + p.ids[i]; return true; }
function renderPack() {
  const box = document.getElementById("content"); if (!box) return;
  const p = currentPack(), id = labId(), old = box.querySelector(":scope > .ck-pack");
  const key = p && id ? id + "|" + p.ids.join(",") + "|" + document.documentElement.lang : "";
  if (old && old.dataset.key === key) return; // 같은 막대가 이미 있으면 그대로 둔다(다시 그리면 끝없이 반복됨)
  old?.remove();
  if (!p || !id) return;
  css();
  const i = p.ids.indexOf(id), seen = LS.get("mckay-visited", []);
  const bar = document.createElement("nav"); bar.className = "ck-pack"; bar.dataset.key = key; bar.setAttribute("aria-label", L("수업 꾸러미", "Lesson set"));
  bar.innerHTML = `<b>📚 ${esc(p.title || L("수업 꾸러미", "Lesson set"))} · ${i + 1} / ${p.ids.length}</b>
    <span class="ck-dots">${p.ids.map((x, k) => `<a href="#/lab/${esc(x)}" title="${esc(titleOf(x))}" ${k === i ? 'aria-current="step"' : ""} class="${seen.includes(x) ? "ck-seen" : ""}">${k + 1}</a>`).join("")}</span>
    ${i > 0 ? `<a class="ck-step" href="#/lab/${esc(p.ids[i - 1])}">◀ ${L("이전", "Prev")}</a>` : ""}${i < p.ids.length - 1 ? `<a class="ck-step ck-next" href="#/lab/${esc(p.ids[i + 1])}">${L("다음", "Next")} ▶</a>` : `<span>${L("마지막 실험이에요", "Last one")} 🎉</span>`}
    <button type="button" data-ck-pack="end">${L("꾸러미 끝내기", "Leave set")}</button>`;
  bar.querySelector('[data-ck-pack="end"]').onclick = () => { SS.set(KPACK, null); bar.remove(); };
  box.prepend(bar);
}
// 학습지 화면에 ‘수업 꾸러미로 보내기’ 단추를 붙인다
function sheetButton() {
  if (!/^#\/sheet/.test(location.hash)) return;
  const dl = document.querySelector(".sh-dl"); if (!dl || dl.querySelector("[data-ck-sendpack]")) return;
  const S = LS.get("mckay-sheet-v1", { items: [] }), ids = [...new Set((S.items || []).map((x) => x.id))];
  const b = document.createElement("button"); b.type = "button"; b.className = "btn"; b.dataset.ckSendpack = "1"; b.disabled = !ids.length;
  b.textContent = L("수업 꾸러미로 보내기 (QR)", "Send as lesson set (QR)");
  b.title = L("담은 실험을 순서대로 넘기며 하도록 학생 휴대폰에 보내요", "Send these experiments to students' phones to work through in order");
  b.onclick = () => {
    const S2 = LS.get("mckay-sheet-v1", { items: [] }), list = [...new Set((S2.items || []).map((x) => x.id))]; if (!list.length) return;
    const t = (S2.title || "").replace(/^수학 실험 학습지$/, "") || L("수업 꾸러미", "Lesson set");
    const url = location.origin + location.pathname + "#/lab/" + encodeURIComponent(list[0]) + "?pack=" + list.map(encodeURIComponent).join(",") + "&pt=" + encodeURIComponent(t);
    openSendQR({ url, shortUrl: url, title: L("수업 꾸러미", "Lesson set") + " · " + t + " (" + list.length + L("개", "") + ")", notify: say });
  };
  dl.append(b);
}

// ── F4 키보드 단축키 ─────────────────────────────────
const KEYS = () => [
  [["PageDown", "Alt+→"], L("다음 실험 (꾸러미 안에서는 꾸러미 순서)", "Next experiment (follows the lesson set)")],
  [["PageUp", "Alt+←"], L("이전 실험", "Previous experiment")],
  [["P"], L("발표 모드 켜고 끄기", "Presentation mode")],
  [["Q"], L("학생에게 보내기 (QR)", "Send to students (QR)")],
  [["T"], L("수업 도구 — 타이머", "Class tools — timer")],
  [["N"], L("수업 도구 — 번호 뽑기", "Class tools — pick a number")],
  [["F"], L("전체 화면", "Full screen")],
  [["Ctrl+K", "/"], L("실험 찾기", "Find an experiment")],
  [["?"], L("이 안내 보기", "Show this help")],
  [["Esc"], L("창 닫기 · 발표 모드 끝내기", "Close · leave presentation")],
];
function help() {
  css();
  if (document.querySelector(".ck-help")) return;
  const ov = document.createElement("div"); ov.className = "ck-help";
  ov.innerHTML = `<div role="dialog" aria-modal="true" aria-labelledby="ck-help-t"><h2 id="ck-help-t">${L("키보드 단축키", "Keyboard shortcuts")}</h2><table>${KEYS().map(([ks, d]) => `<tr><td>${ks.map((k) => `<kbd>${esc(k)}</kbd>`).join(" ")}</td><td>${esc(d)}</td></tr>`).join("")}</table><p style="margin:12px 0 0;font-size:14px;opacity:.8">${L("발표용 리모컨의 ‘다음/이전’ 단추(PageDown/PageUp)로도 실험을 넘길 수 있어요.", "Presentation clickers (PageDown/PageUp) also move between experiments.")}</p><button type="button">${L("닫기", "Close")}</button></div>`;
  const close = () => ov.remove();
  ov.addEventListener("click", (e) => { if (e.target === ov || e.target.closest("button")) close(); });
  document.body.append(ov); ov.querySelector("button").focus();
}
const click = (sel) => { const el = document.querySelector(sel); if (el) { el.click(); return true; } return false; };
window.addEventListener("keydown", (e) => {
  if (e.defaultPrevented || isTyping(e.target)) return;
  if (e.key === "Escape") { document.querySelector(".ck-help")?.remove(); return; }
  const alt = e.altKey && !e.ctrlKey && !e.metaKey;
  if ((e.key === "PageDown" && !e.ctrlKey) || (alt && e.key === "ArrowRight")) { if (!labId()) return; e.preventDefault(); packStep(1) || click(".at-lab-nav-next") || say(L("이 과정의 마지막 실험이에요.", "This is the last experiment in the course.")); return; }
  if ((e.key === "PageUp" && !e.ctrlKey) || (alt && e.key === "ArrowLeft")) { if (!labId()) return; e.preventDefault(); packStep(-1) || click(".at-lab-nav-prev") || say(L("이 과정의 첫 실험이에요.", "This is the first experiment in the course.")); return; }
  if (e.ctrlKey || e.metaKey || e.altKey || onSlider(e.target)) return;
  const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  if (k === "?") { e.preventDefault(); help(); return; }
  if (!labId()) return;
  if (k === "p") { e.preventDefault(); click('[data-action="present"]'); }
  else if (k === "q") { e.preventDefault(); click('[data-action="qr"]'); }
  else if (k === "t") { e.preventDefault(); openTools("timer"); }
  else if (k === "n") { e.preventDefault(); openTools("pick"); }
  else if (k === "f") { e.preventDefault(); if (document.fullscreenElement) document.exitFullscreen?.(); else document.documentElement.requestFullscreen?.().catch(() => {}); }
});

// 화면이 다시 그려질 때마다 꾸러미 막대와 학습지 단추를 붙인다
let pend = 0;
const refresh = () => { pend = 0; renderPack(); sheetButton(); offlineButton(); };
new MutationObserver(() => { if (!pend) pend = requestAnimationFrame(refresh); }).observe(document.getElementById("lab-app") || document.body, { childList: true, subtree: true });
addEventListener("hashchange", () => { if (!pend) pend = requestAnimationFrame(refresh); });
export const showHelp = help;
// ── 수업 전에 모두 받아 두기: 사이트 파일 전부를 오프라인 보관함에 저장한다 ──
const fmtMB = (b) => (b / 1048576).toFixed(0) + "MB";
function offlineLabel(btn, list) {
  const st = LS.get("ck-offline", null);
  btn.textContent = st ? L(`모두 받아 둠 ✓ (${st.at}) · 다시 받기`, `Saved for offline ✓ (${st.at}) · update`) : L(`인터넷 없이 쓰도록 모두 받아 두기 (약 ${fmtMB(list?.bytes || 16e6)})`, `Save everything for offline use (about ${fmtMB(list?.bytes || 16e6)})`);
}
async function saveAll(btn) {
  if (btn.dataset.busy) return; btn.dataset.busy = "1";
  try {
    const list = await (await fetch("/offline-list.json", { cache: "no-store" })).json();
    const keys = (await caches.keys()).filter((k) => k.startsWith("atelier-")).sort(), c = await caches.open(keys[keys.length - 1] || "atelier-manual");
    const urls = [...list.files, ...(list.cdn || [])]; let done = 0, fail = 0;
    for (let i = 0; i < urls.length; i += 6) {
      await Promise.all(urls.slice(i, i + 6).map(async (u) => { try { const r = await fetch(u, { cache: "no-cache" }); if (r.ok && !r.redirected) await c.put(u, r); else fail++; } catch { fail++; } done++; }));
      btn.textContent = L(`받는 중… ${Math.round((done / urls.length) * 100)}%`, `Saving… ${Math.round((done / urls.length) * 100)}%`);
    }
    const d = new Date(); LS.set("ck-offline", { at: `${d.getMonth() + 1}/${d.getDate()}`, made: list.made, fail });
    say(fail ? L(`${urls.length - fail}개 파일을 받아 두었어요. ${fail}개는 받지 못했어요(인터넷 연결 확인).`, `Saved ${urls.length - fail} files; ${fail} failed (check the connection).`) : L("모두 받아 두었어요. 이제 인터넷이 끊겨도 모든 실험을 열 수 있어요.", "Everything is saved. All experiments now open without internet."));
    offlineLabel(btn, list);
  } catch (e) { say(L("받아 두지 못했어요. 인터넷 연결을 확인하고 다시 눌러 주세요.", "Could not save. Check the connection and try again.")); offlineLabel(btn, null); }
  finally { delete btn.dataset.busy; }
}
let offlineList = null;
function offlineButton() {
  const btn = document.querySelector("[data-offline-all]"); if (!btn || btn.dataset.ready) return;
  if (!("caches" in window) || !navigator.serviceWorker?.controller) return; // 오프라인 장치가 켜진 뒤에만 보인다
  btn.dataset.ready = "1"; btn.hidden = false; offlineLabel(btn, offlineList);
  if (!offlineList) fetch("/offline-list.json").then((r) => r.json()).then((j) => { offlineList = j; if (!btn.dataset.busy) offlineLabel(btn, j); }).catch(() => {});
  btn.onclick = () => saveAll(btn);
}
document.addEventListener("click", (e) => { if (e.target.closest?.("[data-ck-reset]") && resetProgress()) location.reload(); });
