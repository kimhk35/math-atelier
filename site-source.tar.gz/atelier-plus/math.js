// Pure mathematics. No DOM and no external dependencies.
export const add=(a,b)=>a.map((v,i)=>v+b[i]);
export const sub=(a,b)=>a.map((v,i)=>v-b[i]);
export const mul=(a,s)=>a.map(v=>v*s);
export const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
export const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
export const norm=a=>mul(a,1/(Math.hypot(...a)||1));
export const lerp=(a,b,t)=>add(mul(a,1-t),mul(b,t));
export const rad=x=>x*Math.PI/180;
export function basis(n){const u=norm(cross(n,Math.abs(n[2])<.9?[0,0,1]:[0,1,0]));return [u,cross(n,u)];}
export function normal(yaw,pitch){return [Math.cos(rad(pitch))*Math.cos(rad(yaw)),Math.cos(rad(pitch))*Math.sin(rad(yaw)),Math.sin(rad(pitch))];}
export function solid(kind){
 if(kind==='tetra')return [[ [1,1,1],[-1,-1,1],[-1,1,-1],[1,-1,-1] ],[[0,1,2],[0,3,1],[0,2,3],[1,3,2]]];
 if(kind==='octa')return [[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],[[0,2,4],[2,1,4],[1,3,4],[3,0,4],[2,0,5],[1,2,5],[3,1,5],[0,3,5]]];
 if(kind==='pyramid')return [[[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[0,0,1]],[[0,3,2,1],[0,1,4],[1,2,4],[2,3,4],[3,0,4]]];
 if(kind==='prism')return [[[1,0,-1],[-.5,.8660254038,-1],[-.5,-.8660254038,-1],[1,0,1],[-.5,.8660254038,1],[-.5,-.8660254038,1]],[[0,2,1],[3,4,5],[0,1,4,3],[1,2,5,4],[2,0,3,5]]];
 return [[[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]],[[0,3,2,1],[4,5,6,7],[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7]]];
}
export function clip(poly,n,d,sign=1){
 const out=[];
 for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],fa=sign*(dot(n,a)-d),fb=sign*(dot(n,b)-d);if(fa>=-1e-9)out.push(a);if((fa>1e-9&&fb< -1e-9)||(fa< -1e-9&&fb>1e-9))out.push(lerp(a,b,fa/(fa-fb)));}
 return out;
}
export function section(vertices,faces,n,d){
 const pts=[];const put=p=>{if(!pts.some(q=>Math.hypot(...sub(p,q))<1e-7))pts.push(p);};
 for(const f of faces)for(let i=0;i<f.length;i++){const a=vertices[f[i]],b=vertices[f[(i+1)%f.length]],fa=dot(n,a)-d,fb=dot(n,b)-d;if(Math.abs(fa)<1e-8)put(a);if(fa*fb< -1e-14)put(lerp(a,b,fa/(fa-fb)));}
 const [u,v]=basis(n);if(!pts.length)return {points:[],xy:[],area:0,perimeter:0};
 const center=mul(pts.reduce(add,[0,0,0]),1/pts.length);
 pts.sort((a,b)=>Math.atan2(dot(sub(a,center),v),dot(sub(a,center),u))-Math.atan2(dot(sub(b,center),v),dot(sub(b,center),u)));
 const xy=pts.map(p=>[dot(p,u),dot(p,v)]);let area=0,perimeter=0;
 if(pts.length>=3)for(let i=0;i<pts.length;i++){const a=xy[i],b=xy[(i+1)%xy.length];area+=a[0]*b[1]-a[1]*b[0];perimeter+=Math.hypot(...sub(a,b));}
 return {points:pts,xy,area:Math.abs(area)/2,perimeter};
}
export function deCasteljau(points,t){const levels=[points];while(levels.at(-1).length>1){const a=levels.at(-1);levels.push(a.slice(1).map((p,i)=>lerp(a[i],p,t)));}return levels;}
export const functions={square:{f:x=>x*x-1,F:x=>x*x*x/3-x,tex:'x^2-1'},sine:{f:Math.sin,F:x=>-Math.cos(x),tex:'\\sin x'},cubic:{f:x=>x*x*x-x,F:x=>x**4/4-x*x/2,tex:'x^3-x'}};
export function riemann(key,a,b,n,rule){const {f,F}=functions[key],dx=(b-a)/n;let sum=0;const bars=[];for(let i=0;i<n;i++){const x=a+i*dx,y=f(x+dx*({left:0,mid:.5,right:1}[rule]??.5));bars.push([x,y,dx]);sum+=y*dx;}return {sum,exact:F(b)-F(a),bars};}
export function integrateAbs(key,a,b){const {F}=functions[key],roots=key==='sine'?Array.from({length:21},(_,i)=>(i-10)*Math.PI):key==='square'?[-1,1]:[-1,0,1];const xs=[a,...roots.filter(x=>x>a&&x<b),b].sort((a,b)=>a-b);return xs.slice(1).reduce((s,x,i)=>s+Math.abs(F(x)-F(xs[i])),0);}
export function random(seed){let a=seed>>>0;return ()=>{a=(1664525*a+1013904223)>>>0;return (a+.5)/4294967296;};}
export function gaussian(rng){return Math.sqrt(-2*Math.log(rng()))*Math.cos(2*Math.PI*rng());}
export function confidence(seed,n,count,level=95){const rng=random(seed),z=level===99?2.5758293035489004:1.959963984540054,mu=50,sigma=10,half=z*sigma/Math.sqrt(n);return Array.from({length:count},()=>{let m=0;for(let j=0;j<n;j++)m+=mu+sigma*gaussian(rng);m/=n;return {mean:m,lo:m-half,hi:m+half,covers:Math.abs(m-mu)<=half};});}
export function bayes(prevalence,sensitivity,specificity){const tp=prevalence*sensitivity,fp=(1-prevalence)*(1-specificity);return {tp,fp,fn:prevalence*(1-sensitivity),tn:(1-prevalence)*specificity,posterior:tp+fp>0?tp/(tp+fp):null};}
export function regressionStep(data,a,b,eta){const n=data.length;let da=0,db=0,loss=0;for(const [x,y] of data){const e=a*x+b-y;loss+=e*e;da+=2*x*e;db+=2*e;}return {a:a-eta*da/n,b:b-eta*db/n,loss:loss/n,da:da/n,db:db/n};}
export function learningLimit(data){const mx=data.reduce((s,p)=>s+p[0],0)/data.length,mx2=data.reduce((s,p)=>s+p[0]**2,0)/data.length;const eigen=mx2+1+Math.sqrt((mx2-1)**2+4*mx*mx);return 2/eigen;}
export function normalizeCells(cells){const minx=Math.min(...cells.map(p=>p[0])),miny=Math.min(...cells.map(p=>p[1]));return cells.map(([x,y])=>[x-minx,y-miny]).sort((a,b)=>a[1]-b[1]||a[0]-b[0]);}
export function canonical(cells){return Array.from({length:8},(_,i)=>JSON.stringify(normalizeCells(cells.map(([x,y])=>{if(i>=4)x=-x;for(let k=0;k<i%4;k++)[x,y]=[-y,x];return [x,y];})))).sort()[0];}
export function checkNet(cells){
 if(cells.length!==6)return {valid:false,reason:'정사각형 6개를 선택하세요.'};
 const map=new Map(cells.map((p,i)=>[p.join(':'),i])),frames=new Map([[0,[[1,0,0],[0,1,0],[0,0,1]]]]),queue=[0];let conflict=false;
 for(let k=0;k<queue.length;k++){const i=queue[k],[x,y]=cells[i],[u,v,n]=frames.get(i);for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const j=map.get([x+dx,y+dy].join(':'));if(j===undefined)continue;const next=dx===1?[mul(n,-1),v,u]:dx===-1?[n,v,mul(u,-1)]:dy===1?[u,mul(n,-1),v]:[u,n,mul(v,-1)];if(frames.has(j)){if(JSON.stringify(frames.get(j))!==JSON.stringify(next))conflict=true;}else{frames.set(j,next);queue.push(j);}}}
 if(frames.size!==6)return {valid:false,reason:'모든 면이 모서리로 연결되어야 합니다.'};
 const normals=[...frames.values()].map(f=>f[2].join(':')),unique=new Set(normals).size;
 return {valid:!conflict&&unique===6,frames:[...frames],reason:conflict?'접는 방향이 서로 충돌합니다.':unique!==6?'접었을 때 같은 방향에 놓이는 면이 겹칩니다.':'6개 면이 서로 다른 방향에 놓여 정육면체가 됩니다.'};
}
export function allHexominoes(){let shapes=[[[0,0]]];for(let n=1;n<6;n++){const map=new Map;for(const sh of shapes)for(const [x,y] of sh)for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const p=[x+dx,y+dy];if(sh.some(q=>q[0]===p[0]&&q[1]===p[1]))continue;const k=canonical([...sh,p]);map.set(k,JSON.parse(k));}shapes=[...map.values()];}return shapes;}
