// Student reading preferences and navigation. Mathematical renderers stay independent.
export const TEXT_SIZES = { standard: 16, large: 18, extra: 21 };
export function normalizeSize(value) { return Object.hasOwn(TEXT_SIZES, value) ? value : 'large'; }
const prefKey = 'atelier-reading:v1';
function readSize() { try { return normalizeSize(localStorage.getItem(prefKey)); } catch { return 'large'; } }
export function readingHTML() {
  const size = readSize();
  return `<section class="sv-reading" aria-label="학습 화면 설정"><span>내게 편한 글자 크기</span><div role="group" aria-label="글자 크기">${[['standard','기본'],['large','크게'],['extra','더 크게']].map(([id,label])=>`<button type="button" data-sv-size="${id}" aria-pressed="${size===id}">${label}</button>`).join('')}</div><small>이 기기에 저장돼요</small></section>`;
}
export function lessonHTML(question, observation) {
  return `<section class="sv-start" aria-label="실험 시작 안내"><div><span class="sv-eyebrow">오늘의 질문</span><p>${question}</p><details><summary>어디부터 시작할까요?</summary><p>${observation || '조건을 하나씩 바꾸며 그림과 측정값이 어떻게 달라지는지 살펴보세요.'}</p><p>먼저 답을 예상해 보세요. 조건을 바꿔 확인한 뒤 내 말로 이유를 남겨 보세요.</p></details></div><nav class="sv-journey" aria-label="실험 안에서 이동"><button type="button" data-sv-go="diagram"><b>1</b>그림 보기</button><button type="button" data-sv-go="controls"><b>2</b>조건 바꾸기</button><button type="button" data-sv-go="predict"><b>3</b>예측과 풀이</button><button type="button" data-sv-go="notes"><b>4</b>관찰 기록</button></nav></section>`;
}
export function steppedValue(value, min, max, step, direction) {
  if (![value,min,max,step,direction].every(Number.isFinite) || step<=0 || max<min) return value;
  const index=(value-min)/step;
  const next=direction>0 ? Math.floor(index+1e-8)+1 : Math.ceil(index-1e-8)-1;
  return Math.max(min,Math.min(max,Number((min+next*step).toPrecision(12))));
}
function applySize(value) {
  const size=normalizeSize(value);
  document.documentElement.dataset.reading=size;
  document.querySelectorAll('[data-sv-size]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.svSize===size)));
}
export function initStudentUI() {
  applySize(readSize());
  document.addEventListener('click',e=>{
    const b=e.target.closest('[data-sv-size]');if(!b)return;
    applySize(b.dataset.svSize);try{localStorage.setItem(prefKey,normalizeSize(b.dataset.svSize));}catch{}
  });
  window.addEventListener('storage',e=>{if(e.key===prefKey)applySize(e.newValue);});
}
export function mountStudentLab() {
  const controls=document.getElementById('controls'),side=document.querySelector('.v3-sidepanel');
  if(!controls||!side)return {destroy(){}};
  const abort=new AbortController();let frame=0,disposed=false;
  const on=(el,event,fn)=>el?.addEventListener(event,fn,{signal:abort.signal});
  // Match tabs to panels and support the standard keyboard interaction.
  const tabs=[...side.querySelectorAll('[role=tab]')];
  tabs.forEach(t=>{t.id='sv-tab-'+t.dataset.tab;t.setAttribute('aria-controls','sv-panel-'+t.dataset.tab);t.tabIndex=t.getAttribute('aria-selected')==='true'?0:-1;});
  side.querySelectorAll('[role=tabpanel]').forEach(p=>{p.id='sv-panel-'+p.dataset.panel;p.setAttribute('aria-labelledby','sv-tab-'+p.dataset.panel);});
  on(side,'click',e=>{const t=e.target.closest('[role=tab]');if(t)tabs.forEach(b=>b.tabIndex=b===t?0:-1);});
  on(side,'keydown',e=>{
    const current=e.target.closest('[role=tab]');if(!current)return;
    const i=tabs.indexOf(current),n=tabs.length;
    const next={ArrowRight:(i+1)%n,ArrowLeft:(i+n-1)%n,Home:0,End:n-1}[e.key];
    if(next==null)return;e.preventDefault();tabs[next].click();tabs[next].focus();
  });
  function enhanceRanges(){
    frame=0;if(disposed)return;
    controls.querySelectorAll('input[type=range][data-key]').forEach(input=>{
      if(input.parentElement.querySelector('.sv-stepper'))return;
      const row=document.createElement('div');row.className='sv-stepper';
      const title=input.parentElement.querySelector('span')?.childNodes[0]?.textContent?.trim() || '값';
      for(const [dir,label] of [[-1,'줄이기'],[1,'늘리기']]){const b=document.createElement('button');b.type='button';b.dataset.svStep=dir;b.textContent=dir<0?'−':'+';b.setAttribute('aria-label',title+' '+label);row.append(b);}
      const hint=document.createElement('span');hint.textContent='한 칸씩 바꾸기';row.append(hint);input.after(row);
    });
  }
  on(controls,'click',e=>{
    const b=e.target.closest('[data-sv-step]');if(!b)return;e.preventDefault();
    const input=b.closest('.lab-control')?.querySelector('input[type=range]');if(!input||input.disabled)return;
    input.value=steppedValue(Number(input.value),Number(input.min),Number(input.max),Number(input.step)||1,Number(b.dataset.svStep));
    input.dispatchEvent(new Event('input',{bubbles:true}));
  });
  function reveal(target){
    const panel=target.closest('[role=tabpanel]');if(panel)side.querySelector(`[data-tab="${panel.dataset.panel}"]`)?.click();
    for(let p=target.parentElement;p;p=p.parentElement)if(p.tagName==='DETAILS')p.open=true;
    target.scrollIntoView({block:'start',behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
    if(!target.matches('input,textarea,button,select,a'))target.tabIndex=-1;
    target.focus({preventScroll:true});
  }
  on(document.querySelector('.sv-journey'),'click',e=>{
    const b=e.target.closest('[data-sv-go]');if(!b)return;
    const selectors={diagram:'.stage-head',controls:'#controls',predict:'.hs-pred, #legacy-pred, .ap-question, .wf-missions [data-wf-check], .em-missions [data-em-check], .cw-missions [data-mission-check], .cw-quiz',notes:'[data-st-note], [data-ap-note], .wf-notes textarea, .em-notes textarea, .cw-records textarea'};
    const target=document.querySelector(selectors[b.dataset.svGo]);
    if(target)reveal(target);
    else {const status=document.getElementById('lab-status');if(status)status.textContent='이 실험은 오늘의 질문을 보고 직접 예측해 보세요.';}
  });
  const observer=new MutationObserver(()=>{if(!frame)frame=requestAnimationFrame(enhanceRanges);});
  observer.observe(controls,{childList:true,subtree:true});enhanceRanges();
  return {destroy(){disposed=true;abort.abort();observer.disconnect();cancelAnimationFrame(frame);}};
}
