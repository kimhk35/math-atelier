// 첫 화면의 움직이는 삼각형 — 꼭짓점을 끌어도 세 내각의 합은 180°
const W = 560, H = 400, GRID = 20;
const P0 = [[300, 70], [90, 330], [470, 320]];
const NAMES = ["A", "B", "C"];
const NS = "http://www.w3.org/2000/svg";

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const sub = (p, q) => [p[0] - q[0], p[1] - q[1]];
const ang = (v) => Math.atan2(v[1], v[0]);
// 꼭짓점 p에서 두 변 사이의 내각(도)
function interior(p, q, r) {
  const a = sub(q, p), b = sub(r, p);
  const c = (a[0] * b[0] + a[1] * b[1]) / (Math.hypot(...a) * Math.hypot(...b));
  return (Math.acos(clamp(c, -1, 1)) * 180) / Math.PI;
}
// 반올림한 세 각의 합이 늘 180이 되도록 맞춘다 (가장 큰 오차를 가진 각에서 조정)
function rounded(degs) {
  const r = degs.map(Math.round), diff = 180 - r.reduce((s, x) => s + x, 0);
  if (!diff) return r;
  // 합이 모자라면 가장 많이 깎인 각을 올리고, 넘치면 가장 많이 올라간 각을 내린다
  const err = degs.map((d, k) => d - r[k]);
  const i = err.indexOf(diff > 0 ? Math.max(...err) : Math.min(...err));
  r[i] += diff;
  return r;
}
function arcPath(p, q, r, rad) {
  let a1 = ang(sub(q, p)), a2 = ang(sub(r, p)), d = a2 - a1;
  while (d <= -Math.PI) d += 2 * Math.PI;
  while (d > Math.PI) d -= 2 * Math.PI;
  const s = [p[0] + rad * Math.cos(a1), p[1] + rad * Math.sin(a1)], e = [p[0] + rad * Math.cos(a1 + d), p[1] + rad * Math.sin(a1 + d)];
  return { d: `M${p[0]} ${p[1]} L${s[0].toFixed(1)} ${s[1].toFixed(1)} A${rad} ${rad} 0 0 ${d > 0 ? 1 : 0} ${e[0].toFixed(1)} ${e[1].toFixed(1)} Z`, mid: a1 + d / 2 };
}
const el = (tag, attrs = {}) => { const n = document.createElementNS(NS, tag); for (const k in attrs) n.setAttribute(k, attrs[k]); return n; };

export function mountHomeFigure(root) {
  if (!root) return () => {};
  const pts = P0.map((p) => p.slice());
  const svg = el("svg", { viewBox: `0 0 ${W} ${H}`, class: "hm-fig-svg", role: "group", "aria-label": "꼭짓점을 끌 수 있는 삼각형" });
  const defs = el("defs"), pat = el("pattern", { id: "hm-grid", width: GRID, height: GRID, patternUnits: "userSpaceOnUse" });
  pat.append(el("path", { d: `M${GRID} 0H0V${GRID}`, class: "hm-grid-line" }));
  const pat5 = el("pattern", { id: "hm-grid5", width: GRID * 5, height: GRID * 5, patternUnits: "userSpaceOnUse" });
  pat5.append(el("rect", { width: GRID * 5, height: GRID * 5, fill: "url(#hm-grid)" }), el("path", { d: `M${GRID * 5} 0H0V${GRID * 5}`, class: "hm-grid-major" }));
  defs.append(pat, pat5);
  svg.append(defs, el("rect", { width: W, height: H, fill: "url(#hm-grid5)" }));
  const arcs = [0, 1, 2].map((i) => el("path", { class: `hm-arc hm-arc${i}` }));
  const tri = el("polygon", { class: "hm-tri" });
  const labels = [0, 1, 2].map(() => el("text", { class: "hm-deg" }));
  const names = [0, 1, 2].map((i) => { const t = el("text", { class: "hm-name" }); t.textContent = NAMES[i]; return t; });
  const handles = [0, 1, 2].map((i) => {
    const g = el("g", { class: "hm-handle", tabindex: "0", role: "slider", "aria-label": `꼭짓점 ${NAMES[i]} — 방향키로 움직일 수 있어요` });
    g.append(el("circle", { r: 22, class: "hm-hit" }), el("circle", { r: 7, class: "hm-dot" }));
    return g;
  });
  svg.append(...arcs, tri, ...labels, ...names, ...handles);
  root.prepend(svg);
  const sumEl = root.querySelector("[data-hm-sum]");

  function draw() {
    tri.setAttribute("points", pts.map((p) => p.join(",")).join(" "));
    const degs = [0, 1, 2].map((i) => interior(pts[i], pts[(i + 1) % 3], pts[(i + 2) % 3])), shown = rounded(degs);
    const cx = (pts[0][0] + pts[1][0] + pts[2][0]) / 3, cy = (pts[0][1] + pts[1][1] + pts[2][1]) / 3;
    for (let i = 0; i < 3; i++) {
      const p = pts[i], q = pts[(i + 1) % 3], r = pts[(i + 2) % 3];
      const short = Math.min(Math.hypot(...sub(q, p)), Math.hypot(...sub(r, p)));
      const rad = clamp(short * 0.28, 16, 42), a = arcPath(p, q, r, rad);
      arcs[i].setAttribute("d", a.d);
      const lr = rad + 20;
      labels[i].setAttribute("x", (p[0] + lr * Math.cos(a.mid)).toFixed(1));
      labels[i].setAttribute("y", (p[1] + lr * Math.sin(a.mid) + 5).toFixed(1));
      labels[i].textContent = shown[i] + "°";
      const away = sub(p, [cx, cy]), len = Math.hypot(...away) || 1;
      names[i].setAttribute("x", (p[0] + (away[0] / len) * 24).toFixed(1));
      names[i].setAttribute("y", (p[1] + (away[1] / len) * 24 + 6).toFixed(1));
      handles[i].setAttribute("transform", `translate(${p[0]} ${p[1]})`);
      handles[i].setAttribute("aria-valuetext", `${NAMES[i]}의 내각 ${shown[i]}도`);
    }
    if (sumEl) sumEl.innerHTML = shown.map((s, i) => `<span class="hm-sum-term hm-c${i}">${s}°</span>`).join(" + ") + ` = <b>180°</b>`;
  }
  // 세 점이 거의 한 줄이 되면 삼각형이 아니므로 그 움직임은 받지 않는다
  const area = (a, b, c) => Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (b[1] - a[1])) / 2;
  function moveTo(i, x, y) {
    const next = [clamp(Math.round(x), 18, W - 18), clamp(Math.round(y), 18, H - 18)];
    const trial = pts.map((p, k) => (k === i ? next : p));
    if (area(...trial) < 2400) return;
    pts[i] = next;
    draw();
  }
  const toSvg = (e) => { const b = svg.getBoundingClientRect(); return [((e.clientX - b.left) / b.width) * W, ((e.clientY - b.top) / b.height) * H]; };
  let drag = null;
  handles.forEach((h, i) => {
    h.addEventListener("pointerdown", (e) => { drag = { i, id: e.pointerId }; h.setPointerCapture(e.pointerId); h.classList.add("is-drag"); e.preventDefault(); });
    h.addEventListener("pointermove", (e) => { if (drag && drag.id === e.pointerId) moveTo(i, ...toSvg(e)); });
    const end = () => { drag = null; h.classList.remove("is-drag"); };
    h.addEventListener("pointerup", end);
    h.addEventListener("pointercancel", end);
    h.addEventListener("keydown", (e) => {
      const step = e.shiftKey ? 20 : 5, k = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] }[e.key];
      if (k) { e.preventDefault(); moveTo(i, pts[i][0] + k[0], pts[i][1] + k[1]); }
    });
  });
  root.querySelector("[data-hm-reset]")?.addEventListener("click", () => { P0.forEach((p, i) => (pts[i] = p.slice())); draw(); });
  draw();
  return () => svg.remove();
}
